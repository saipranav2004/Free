// pam/internal/webproxy/upgrade_stripped_audit.go
//
// Making a stripped WebSocket upgrade visible from inside PAM, not just in
// server logs an admin may not have access to.
//
// upgrade_stripped.go already detects the failure and answers 502 with the
// remedy in the body — but only a client reading raw HTTP (curl, a support
// engineer) ever sees that text. The browser's WebSocket API exposes no
// response body on a failed handshake, so the operator gets exactly what the
// package's own header comment describes: a spinner that never resolves and
// nothing to click on. Two gaps followed from that:
//
//   - The org-wide Audit page had no row for it at all. An admin who does
//     have log access could grep for webproxy.upgrade.stripped; one who only
//     has the console could not tell a broken ingress from a broken target.
//   - The PER-SESSION recording (the replay an admin opens from that
//     session's row) had no row for it either, because UpgradeWasStripped is
//     checked and answered BEFORE RecordActivity ever runs — so a session
//     that spent its whole lifetime retrying a broken handshake left a
//     transcript of just the opening banner and the closing footer, which
//     reads exactly like nothing happened rather than like dozens of refused
//     attempts.
//
// Both are fixed by recordUpgradeStripped: it writes one line into the
// session's own transcript for EVERY occurrence (that IS the session's
// history, and the cast writer already bounds it), and one coalesced row into
// the org-wide audit trail so a flood of browser retries — "every few
// seconds" per the failure this exists for — cannot turn a broken deployment
// into a write amplifier against the hash-chained log.
package webproxy

import (
	"context"
	"sync"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
)

const (
	// upgradeStripAuditWindow is how long one subdomain's refusals coalesce
	// into a single audit row. Matches the window used for the machine data
	// plane's own refusal coalescing (internal/middleware/service_auth_audit.go)
	// for the same reason: short enough that a live outage shows as a run of
	// rows over time, long enough that a retry storm cannot outpace the chain.
	upgradeStripAuditWindow = 60 * time.Second

	// upgradeStripAuditMaxSubjects bounds the tracking map across many
	// concurrently-broken subdomains. Past this many, refusals collapse into
	// one overflow bucket so the worst case stays one row per window
	// regardless of how many sessions are affected at once.
	upgradeStripAuditMaxSubjects = 4096

	upgradeStripAuditOverflowKey = "\x00overflow"
)

type upgradeStripBucket struct {
	lastWrite  time.Time
	suppressed int
}

// auditAppender is the slice of *services.AuditService this file needs,
// named so a test can drive the coalescing logic without a database.
type auditAppender interface {
	Append(ctx context.Context, e services.AuditEntry) (*models.AuditLog, error)
}

// upgradeStripAuditor coalesces webproxy.upgrade.stripped audit writes by
// subdomain — every session on a broken ingress fails at the same directive,
// so per-subdomain is the right granularity to see "this target is affected"
// without one row per retry.
type upgradeStripAuditor struct {
	audit auditAppender
	// onWriteFail reports an audit write that did not land, so the failure
	// is not entirely silent. Optional — nil simply means "swallow it",
	// which matches how every other best-effort audit write in this package
	// already behaves when unset.
	onWriteFail func(error)

	mu      sync.Mutex
	buckets map[string]*upgradeStripBucket
}

func newUpgradeStripAuditor(audit auditAppender, onWriteFail func(error)) *upgradeStripAuditor {
	return &upgradeStripAuditor{
		audit:       audit,
		onWriteFail: onWriteFail,
		buckets:     make(map[string]*upgradeStripBucket),
	}
}

func (a *upgradeStripAuditor) admit(key string, now time.Time) (record bool, suppressed int) {
	a.mu.Lock()
	defer a.mu.Unlock()

	for k, b := range a.buckets {
		if now.Sub(b.lastWrite) >= upgradeStripAuditWindow && b.suppressed == 0 {
			delete(a.buckets, k)
		}
	}

	b, ok := a.buckets[key]
	if !ok {
		if len(a.buckets) >= upgradeStripAuditMaxSubjects {
			key = upgradeStripAuditOverflowKey
			b, ok = a.buckets[key]
		}
		if !ok {
			a.buckets[key] = &upgradeStripBucket{lastWrite: now}
			return true, 0
		}
	}

	if now.Sub(b.lastWrite) >= upgradeStripAuditWindow {
		n := b.suppressed
		b.suppressed = 0
		b.lastWrite = now
		return true, n
	}
	b.suppressed++
	return false, 0
}

// record writes one coalesced row for this subdomain, if the window admits
// it, using rs (when the session resolved) to attribute the row to a user,
// resource and session — an unresolved request (no cookie yet, a bare probe)
// still produces a row, just without that attribution.
func (a *upgradeStripAuditor) record(subdomain, path, sourceIP string, rs *ResolvedSession) {
	if a == nil || a.audit == nil {
		return
	}
	ok, suppressed := a.admit(subdomain, time.Now())
	if !ok {
		return
	}

	entry := services.AuditEntry{
		Action:   models.AuditWebSocketUpgradeStripped,
		Category: models.SessionLifecycle,
		Outcome:  models.AuditOutcomeFailure,
		Severity: models.AuditSeverityWarn,
		SourceIP: sourceIP,
		Details: map[string]interface{}{
			"subdomain":             subdomain,
			"path":                  path,
			"remedy":                UpgradeStrippedHint,
			"suppressed_since_last": suppressed,
		},
	}
	if rs != nil {
		entry.ActorUserID = rs.Session.UserID
		entry.ActorUsername = rs.Session.Username
		entry.ResourceID = rs.Session.ResourceID
		entry.SessionID = rs.Session.ConnectionSessionID
	}

	// Detached and asynchronous for the same reason every other best-effort
	// audit write in this codebase is: this fires from the hot proxy path
	// answering an already-failed request, and a slow or blocked audit write
	// must never add latency to that 502, let alone hold the connection open.
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		if _, err := a.audit.Append(ctx, entry); err != nil {
			a.logFailure(err)
		}
	}()
}

// logFailure is a narrow seam so a lost audit row is at least visible in the
// server log, without pulling a *zap.Logger through every call site above —
// this auditor is constructed once per Service and the Service already logs
// everything else about this failure mode.
func (a *upgradeStripAuditor) logFailure(err error) {
	if a.onWriteFail != nil {
		a.onWriteFail(err)
	}
}
