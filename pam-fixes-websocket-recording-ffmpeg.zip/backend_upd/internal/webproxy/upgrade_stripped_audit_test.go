package webproxy

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
)

// recordingAppender stands in for AuditService so these tests exercise the
// coalescing rules without a database and its hash chain.
type recordingAppender struct {
	mu      sync.Mutex
	entries []services.AuditEntry
}

func (r *recordingAppender) Append(_ context.Context, e services.AuditEntry) (*models.AuditLog, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.entries = append(r.entries, e)
	return &models.AuditLog{}, nil
}

func (r *recordingAppender) all() []services.AuditEntry {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]services.AuditEntry, len(r.entries))
	copy(out, r.entries)
	return out
}

func (r *recordingAppender) wait(t *testing.T, want int) []services.AuditEntry {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if got := r.all(); len(got) >= want {
			return got
		}
		time.Sleep(5 * time.Millisecond)
	}
	got := r.all()
	if len(got) != want {
		t.Fatalf("wanted %d audit rows, got %d", want, len(got))
	}
	return got
}

func TestUpgradeStripRefusalsCoalescePerSubdomainWithinTheWindow(t *testing.T) {
	a := newUpgradeStripAuditor(&recordingAppender{}, nil)
	now := time.Now()

	if rec, sup := a.admit("minio-real-abc123", now); !rec || sup != 0 {
		t.Fatalf("the first refusal must be recorded immediately, got record=%v suppressed=%d", rec, sup)
	}
	// The failure this exists for retries "every few seconds" for as long as
	// the tab is open; simulate a burst of those inside one window.
	for i := 0; i < 40; i++ {
		if rec, _ := a.admit("minio-real-abc123", now.Add(time.Duration(i)*time.Second)); rec {
			t.Fatalf("retry %d inside the window should have been suppressed", i)
		}
	}

	rec, sup := a.admit("minio-real-abc123", now.Add(upgradeStripAuditWindow+time.Second))
	if !rec {
		t.Fatal("a refusal after the window must be recorded")
	}
	if sup != 40 {
		t.Fatalf("suppressed count = %d, want 40", sup)
	}
}

func TestUpgradeStripDifferentSubdomainsDoNotSuppressEachOther(t *testing.T) {
	a := newUpgradeStripAuditor(&recordingAppender{}, nil)
	now := time.Now()

	for _, sub := range []string{"minio-real-abc", "metabase-def", "langfuse-ghi"} {
		if rec, _ := a.admit(sub, now); !rec {
			t.Fatalf("first refusal for %q must be recorded, one broken target must not mute another", sub)
		}
	}
}

func TestUpgradeStripOverflowBucketBoundsTheRowRate(t *testing.T) {
	a := newUpgradeStripAuditor(&recordingAppender{}, nil)
	now := time.Now()

	recorded := 0
	for i := 0; i < upgradeStripAuditMaxSubjects*3; i++ {
		if rec, _ := a.admit(fmt.Sprintf("subdomain-%d", i), now); rec {
			recorded++
		}
	}
	if recorded != upgradeStripAuditMaxSubjects+1 {
		t.Fatalf("recorded %d rows for %d distinct subdomains, want %d",
			recorded, upgradeStripAuditMaxSubjects*3, upgradeStripAuditMaxSubjects+1)
	}
}

func TestUpgradeStripRecordWritesTheRemedyAndAttribution(t *testing.T) {
	app := &recordingAppender{}
	a := newUpgradeStripAuditor(app, nil)

	rs := &ResolvedSession{Session: &models.WebProxySession{
		UserID: "u-1", Username: "das_admin", ResourceID: "minio-real",
		ConnectionSessionID: "sess-1",
	}}
	a.record("minio-real-abdae10b", "/ws/objectManager", "203.0.113.9", rs)

	got := app.wait(t, 1)[0]
	if got.Action != models.AuditWebSocketUpgradeStripped {
		t.Fatalf("action = %q", got.Action)
	}
	if got.Category != models.SessionLifecycle {
		t.Fatalf("category = %q, want SessionLifecycle so this shows up in a session-scoped audit query", got.Category)
	}
	if got.Outcome != models.AuditOutcomeFailure {
		t.Fatalf("outcome = %q", got.Outcome)
	}
	if got.ActorUserID != "u-1" || got.ActorUsername != "das_admin" || got.ResourceID != "minio-real" || got.SessionID != "sess-1" {
		t.Fatalf("attribution missing/wrong: %+v", got)
	}
	d := got.Details.(map[string]interface{})
	if d["subdomain"] != "minio-real-abdae10b" || d["path"] != "/ws/objectManager" {
		t.Fatalf("details = %v", d)
	}
	if d["remedy"] != UpgradeStrippedHint {
		t.Fatalf("remedy not carried through — an admin without server-log access would see nothing actionable")
	}
	if d["suppressed_since_last"] != 0 {
		t.Fatalf("suppressed_since_last = %v, want 0 for the first row", d["suppressed_since_last"])
	}
}

func TestUpgradeStripRecordWorksWithNoResolvedSession(t *testing.T) {
	// UpgradeWasStripped fires BEFORE the session is resolved, deliberately
	// (see upgrade_stripped.go) — so an unresolved request must still
	// produce a usable row, just without user/resource/session attribution.
	app := &recordingAppender{}
	a := newUpgradeStripAuditor(app, nil)

	a.record("minio-real-abdae10b", "/ws/objectManager", "203.0.113.9", nil)

	got := app.wait(t, 1)[0]
	if got.ActorUserID != "" || got.SessionID != "" {
		t.Fatalf("expected no attribution without a resolved session, got %+v", got)
	}
	if got.SourceIP != "203.0.113.9" {
		t.Fatalf("source IP must still be recorded even without a session")
	}
}

func TestUpgradeStripANilAuditorIsAWorkingNoOp(t *testing.T) {
	var a *upgradeStripAuditor
	a.record("x", "/p", "1.2.3.4", nil) // must not panic
}

func TestUpgradeStripAWriteFailureIsReportedNotSwallowedSilently(t *testing.T) {
	var reported error
	var mu sync.Mutex
	a := newUpgradeStripAuditor(failingAppender{}, func(err error) {
		mu.Lock()
		defer mu.Unlock()
		reported = err
	})
	a.record("x", "/p", "1.2.3.4", nil)

	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		mu.Lock()
		got := reported
		mu.Unlock()
		if got != nil {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal("a failed audit write was never reported to onWriteFail")
}

type failingAppender struct{}

func (failingAppender) Append(context.Context, services.AuditEntry) (*models.AuditLog, error) {
	return nil, fmt.Errorf("simulated audit backend failure")
}
