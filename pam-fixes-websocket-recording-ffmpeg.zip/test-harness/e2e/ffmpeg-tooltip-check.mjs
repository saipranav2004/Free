// The "No ffmpeg" badge names the problem; it did not use to name the fix.
// This confirms the added tooltip does, per-OS, for the exact device shape
// the reported screenshot showed (a Windows agent with screen_recorder:false).
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const APP = 'http://127.0.0.1:4180'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } })
const page = await ctx.newPage()

// Inject exactly the device shape from the reported screenshot: a Windows
// agent, active, no ffmpeg.
await ctx.route('**/api/v1/auth/me', async (route) => {
  const resp = await route.fetch()
  const body = await resp.json()
  if (body?.data) { body.data.mfa_verified = true; body.data.mfa_enrolment_required = false }
  await route.fulfill({ response: resp, json: body })
})

await ctx.route('**/api/v1/pam/agent/devices', async (route) => {
  await route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify({
      success: true,
      data: {
        devices: [{
          id: 'dev-win-1',
          hostname: 'DESKTOP-ETQ5PKL',
          os: 'windows',
          arch: 'amd64',
          status: 'ACTIVE',
          agent_version: '2026.09.18.2',
          last_seen_at: new Date().toISOString(),
          capabilities_at: new Date().toISOString(),
          capabilities: {
            screen_recorder: false,
            types: [
              { resource_type: 'postgresql', kinds: ['cli'] },
              { resource_type: 'guitest', kinds: ['gui'] },
            ],
          },
        }],
        count: 1,
      },
      message: 'ok',
    }),
  })
})

await page.addInitScript((tok) => {
  sessionStorage.setItem('pam_session', JSON.stringify({
    accessToken: tok, refreshToken: 'r',
    expiresAt: new Date(Date.now() + 36e5).toISOString(), user: null,
  }))
}, token)

await page.goto(`${APP}/settings?tab=devices`, { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)

const bodyText = await page.locator('body').innerText()
check('the badge renders for a Windows device with no ffmpeg',
  /No ffmpeg/i.test(bodyText))

const titledSpan = page.locator('span[title]', { hasText: 'No ffmpeg' }).first()
const title = await titledSpan.getAttribute('title').catch(() => null)
check('the tooltip is present', Boolean(title))
check('the tooltip names the Windows-specific installer (winget)',
  Boolean(title) && /winget install ffmpeg/i.test(title), title || '')
check('the tooltip does NOT suggest brew (the macOS installer) for a Windows device',
  Boolean(title) && !/brew install/i.test(title))

await browser.close()

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) process.exit(1)
console.log('ALL CHECKS PASSED')
