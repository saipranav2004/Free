// The websocket-upgrade-stripped failure, verified from the operator/admin
// side rather than the ingress side: does PAM make it visible from INSIDE
// the product, not just in a server log an admin may not have access to?
//
// wss-ingress.mjs already proves the DETECTION (a real TLS ingress with the
// three nginx lines missing produces exactly the reported symptom, and PAM
// refuses the handshake rather than hanging). This suite proves the
// CONSEQUENCE of that detection reaches two places an admin actually looks:
//   1. the org-wide audit trail, coalesced so a retry storm is one row, and
//   2. the affected session's own replay transcript, so a reviewer watching
//      it back sees exactly when and how often the handshake was refused.
//
// Driven against the API directly (transcript, audit) plus a live browser
// for the console's own explanatory banner, all against data seeded by an
// EARLIER run of wss-ingress.mjs — this suite is read-only against whatever
// stripped-upgrade session already exists, and skips cleanly if none does.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const H = { Authorization: 'Bearer ' + token }

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const auditRows = await (
  await fetch(`${API}/api/v1/pam/admin/audit?action=WEBSOCKET_UPGRADE_STRIPPED&limit=10`, { headers: H })
).json()
const events = auditRows?.data?.events || []

if (events.length === 0) {
  console.log('No WEBSOCKET_UPGRADE_STRIPPED audit rows exist yet — run e2e/wss-ingress.mjs against the')
  console.log('broken-lane ingress (port 9443) first, which is what seeds the scenario this suite checks.')
  console.log('SKIPPED (nothing to verify)')
  process.exit(0)
}

const row = events[0]
check('the audit row is coalesced (one row, not one per retry)', typeof row.details === 'string' || typeof row.details === 'object')
const details = typeof row.details === 'string' ? JSON.parse(row.details) : row.details
check('the row carries the exact remedy an admin needs', typeof details.remedy === 'string' && details.remedy.includes('proxy_http_version'))
check('the row carries a suppressed_since_last count', typeof details.suppressed_since_last === 'number')
check('the row is categorised SESSION, not OTHER', row.category === 'SESSION')
check('the row is attributed to a resource', Boolean(row.resource_id))
check('the row is attributed to a session', Boolean(row.session_id))
check('the row does NOT carry a secret or credential', !JSON.stringify(row).match(/password|secret_plaintext/i))

// The same session's own transcript must show one line PER ATTEMPT, not just
// the coalesced audit summary — that is the forensic record for THIS session.
const recRows = await (
  await fetch(`${API}/api/v1/pam/admin/recordings?session_id=${row.session_id}`, { headers: H })
).json()
const recording = (recRows?.data?.recordings || [])[0]
check('the affected session has a recording', Boolean(recording), row.session_id)

if (recording) {
  const raw = await (
    await fetch(`${API}/api/v1/pam/admin/recordings/${recording.id}/transcript`, { headers: H })
  ).text()
  const strippedLines = raw.split('\n').filter((l) => l.includes('502') && l.toLowerCase().includes('get'))
  check('the transcript has at least one 502 line for the refused handshake', strippedLines.length > 0,
    `${strippedLines.length} line(s)`)

  // ── Console: the explanatory banner ────────────────────────────────────
  const browser = await chromium.launch({
    executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    args: ['--no-sandbox', '--no-proxy-server'],
  })
  const ctx = await browser.newContext({ viewport: { width: 1600, height: 1000 } })
  const page = await ctx.newPage()
  // Root is MFA-enforced by policy; forcing mfa_verified on /auth/me only,
  // with every other call passed straight through, exercises the real
  // component against the real data rather than a mocked page.
  await ctx.route('**/api/v1/auth/me', async (route) => {
    const resp = await route.fetch()
    const body = await resp.json()
    if (body?.data) { body.data.mfa_verified = true; body.data.mfa_enrolment_required = false }
    await route.fulfill({ response: resp, json: body })
  })
  await page.addInitScript((tok) => {
    sessionStorage.setItem('pam_session', JSON.stringify({
      accessToken: tok, refreshToken: 'r',
      expiresAt: new Date(Date.now() + 36e5).toISOString(), user: null,
    }))
  }, token)

  await page.goto(`${APP}/admin/audit?tab=recordings`, { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(2000)
  await page.getByPlaceholder(/search/i).first().fill(recording.resource_name || '').catch(() => {})
  await page.waitForTimeout(1000)

  const rows = page.locator('table tbody tr, [role="row"]')
  const count = await rows.count()
  let bannerSeen = false
  for (let i = 0; i < Math.min(count, 15) && !bannerSeen; i++) {
    await rows.nth(i).click({ timeout: 2000 }).catch(() => {})
    await page.waitForTimeout(1000)
    const text = await page.locator('body').innerText()
    if (/WebSocket connection was refused/i.test(text)) {
      bannerSeen = true
      check('the console explains the empty-looking replay rather than leaving it a mystery',
        text.includes('deployment issue, not a problem with the recording'))
    } else {
      await page.keyboard.press('Escape').catch(() => {})
      await page.waitForTimeout(300)
    }
  }
  check('the banner is found on the affected session’s recording', bannerSeen)
  await browser.close()
}

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
