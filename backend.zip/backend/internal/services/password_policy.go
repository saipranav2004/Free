// pam/internal/services/password_policy.go
package services

import (
	"crypto/rand"
	"encoding/json"
	"fmt"
	"math/big"
	"strings"
	"unicode"
)

// PasswordRules mirrors Python PasswordPolicyRulesSchema defaults.
type PasswordRules struct {
	MinLength                int    `json:"min_length"`
	MaxLength                int    `json:"max_length"`
	RequireUppercase         bool   `json:"require_uppercase"`
	RequireLowercase         bool   `json:"require_lowercase"`
	RequireDigit             bool   `json:"require_digit"`
	RequireSpecial           bool   `json:"require_special"`
	AllowedSpecialCharacters string `json:"allowed_special_characters"`
	ForbiddenCharacters      string `json:"forbidden_characters"`
	MinimumUniqueCharacters  int    `json:"minimum_unique_characters"`
	MaximumConsecutiveRepeat int    `json:"maximum_consecutive_repeat"`
}

func DefaultPasswordRules() PasswordRules {
	return PasswordRules{
		MinLength:                20,
		MaxLength:                64,
		RequireUppercase:         true,
		RequireLowercase:         true,
		RequireDigit:             true,
		RequireSpecial:           true,
		AllowedSpecialCharacters: "!@#$%^&*_-+=",
		ForbiddenCharacters:      "",
		MinimumUniqueCharacters:  12,
		MaximumConsecutiveRepeat: 2,
	}
}

func ParsePasswordRules(raw []byte) (PasswordRules, error) {
	r := DefaultPasswordRules()
	if len(raw) == 0 {
		return r, nil
	}
	if err := json.Unmarshal(raw, &r); err != nil {
		return r, err
	}
	return r, nil
}

// ValidatePassword returns a list of human-readable rule violations (empty = ok).
func ValidatePassword(password string, rules PasswordRules) []string {
	var errs []string
	if len(password) < rules.MinLength {
		errs = append(errs, fmt.Sprintf("password shorter than min_length (%d)", rules.MinLength))
	}
	if rules.MaxLength > 0 && len(password) > rules.MaxLength {
		errs = append(errs, fmt.Sprintf("password longer than max_length (%d)", rules.MaxLength))
	}
	if rules.RequireUppercase && !containsFunc(password, unicode.IsUpper) {
		errs = append(errs, "missing uppercase letter")
	}
	if rules.RequireLowercase && !containsFunc(password, unicode.IsLower) {
		errs = append(errs, "missing lowercase letter")
	}
	if rules.RequireDigit && !containsFunc(password, unicode.IsDigit) {
		errs = append(errs, "missing digit")
	}
	if rules.RequireSpecial {
		if !containsAny(password, rules.AllowedSpecialCharacters) {
			errs = append(errs, "missing special character")
		}
	}
	if rules.ForbiddenCharacters != "" && containsAny(password, rules.ForbiddenCharacters) {
		errs = append(errs, "contains forbidden character")
	}
	if rules.MinimumUniqueCharacters > 0 {
		uniq := map[rune]struct{}{}
		for _, r := range password {
			uniq[r] = struct{}{}
		}
		if len(uniq) < rules.MinimumUniqueCharacters {
			errs = append(errs, "insufficient unique characters")
		}
	}
	if rules.MaximumConsecutiveRepeat > 0 && hasConsecutiveRepeat(password, rules.MaximumConsecutiveRepeat) {
		errs = append(errs, "too many consecutive repeated characters")
	}
	return errs
}

// GeneratePassword creates a CSPRNG password satisfying rules.
func GeneratePassword(rules PasswordRules) (string, error) {
	if rules.MinLength < 8 {
		rules.MinLength = 8
	}
	if rules.MaxLength < rules.MinLength {
		rules.MaxLength = rules.MinLength
	}
	length := rules.MinLength
	if length < 16 {
		length = 16
		if length > rules.MaxLength {
			length = rules.MaxLength
		}
	}

	var sets []string
	if rules.RequireLowercase {
		sets = append(sets, "abcdefghijklmnopqrstuvwxyz")
	}
	if rules.RequireUppercase {
		sets = append(sets, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
	}
	if rules.RequireDigit {
		sets = append(sets, "0123456789")
	}
	if rules.RequireSpecial {
		sp := rules.AllowedSpecialCharacters
		if sp == "" {
			sp = "!@#$%^&*_-+"
		}
		sets = append(sets, sp)
	}
	if len(sets) == 0 {
		sets = []string{"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"}
	}
	all := strings.Join(sets, "")
	// strip forbidden
	if rules.ForbiddenCharacters != "" {
		var b strings.Builder
		for _, r := range all {
			if !strings.ContainsRune(rules.ForbiddenCharacters, r) {
				b.WriteRune(r)
			}
		}
		all = b.String()
	}
	if all == "" {
		return "", fmt.Errorf("empty character set after applying forbidden characters")
	}

	for attempt := 0; attempt < 100; attempt++ {
		out := make([]byte, 0, length)
		// ensure one from each required set
		for _, set := range sets {
			ch, err := randChar(set)
			if err != nil {
				return "", err
			}
			out = append(out, ch)
		}
		for len(out) < length {
			ch, err := randChar(all)
			if err != nil {
				return "", err
			}
			out = append(out, ch)
		}
		// shuffle
		if err := shuffle(out); err != nil {
			return "", err
		}
		pwd := string(out)
		if len(ValidatePassword(pwd, rules)) == 0 {
			return pwd, nil
		}
	}
	return "", fmt.Errorf("failed to generate compliant password")
}

func randChar(set string) (byte, error) {
	n, err := rand.Int(rand.Reader, big.NewInt(int64(len(set))))
	if err != nil {
		return 0, err
	}
	return set[n.Int64()], nil
}

func shuffle(b []byte) error {
	for i := len(b) - 1; i > 0; i-- {
		jBig, err := rand.Int(rand.Reader, big.NewInt(int64(i+1)))
		if err != nil {
			return err
		}
		j := int(jBig.Int64())
		b[i], b[j] = b[j], b[i]
	}
	return nil
}

func containsFunc(s string, f func(rune) bool) bool {
	for _, r := range s {
		if f(r) {
			return true
		}
	}
	return false
}

func containsAny(s, chars string) bool {
	for _, r := range s {
		if strings.ContainsRune(chars, r) {
			return true
		}
	}
	return false
}

func hasConsecutiveRepeat(s string, max int) bool {
	if max < 1 || len(s) == 0 {
		return false
	}
	run := 1
	for i := 1; i < len(s); i++ {
		if s[i] == s[i-1] {
			run++
			if run > max {
				return true
			}
		} else {
			run = 1
		}
	}
	return false
}
