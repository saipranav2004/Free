// pam/internal/services/resource_access_default_deny_test.go
//
// Regression coverage for the "resources are deny-by-default" fix: a
// standard user must NOT see or connect to any resource until an admin
// explicitly grants it (via a role-attached or directly-attached policy
// scoped to that resource's "pam:resource/<id>" pattern) — see
// opa/policies/default_bundle.json's "standard-user-access" and
// "resource-access-default-deny" policies. Runs against the REAL embedded
// seed bundle (opa.DefaultSeedBundle) on an in-memory sqlite DB, so a future
// edit to that bundle that accidentally reintroduces a blanket
// resources:["*"] grant on pam:resource:Read/Connect fails this test, not
// just a live deployment.
package services

import (
	"testing"

	"github.com/glebarez/sqlite"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

func newRBACTestDB(t *testing.T) *gorm.DB {
	t.Helper()
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open in-memory sqlite: %v", err)
	}
	if err := db.AutoMigrate(
		&models.Role{},
		&models.Policy{},
		&models.RolePolicy{},
		&models.UserRole{},
		&models.UserPolicy{},
	); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

func TestStandardUserHasNoResourceAccessByDefault(t *testing.T) {
	db := newRBACTestDB(t)
	logger := zap.NewNop()

	if err := SeedRBACDefaults(db, logger); err != nil {
		t.Fatalf("SeedRBACDefaults: %v", err)
	}

	var userRole models.Role
	if err := db.Where("name = ?", "user").First(&userRole).Error; err != nil {
		t.Fatalf("find seeded 'user' role: %v", err)
	}

	const userID = "standard-user-1"
	if err := db.Create(&models.UserRole{UserID: userID, RoleID: userRole.ID}).Error; err != nil {
		t.Fatalf("assign user role: %v", err)
	}

	engine := NewPolicyEngineService(db, logger)

	// A brand-new resource nobody has granted anything for must be invisible
	// (List), unreadable (Read), and unconnectable (Connect) — the actual
	// bug this fixes. All three tiers of the model are per-resource only;
	// there is no more blanket grant for any of them, on any pattern.
	someResourcePattern := "pam:resource/some-postgres-resource-id"
	for _, action := range []string{"pam:resource:List", "pam:resource:Read", "pam:resource:Connect", "pam:session:Start"} {
		res := engine.Authorize(nil, userID, action, someResourcePattern)
		if res.Allowed {
			t.Fatalf("expected %s on an ungranted resource to be denied by default, got allowed (matched policy %q)", action, res.MatchedPolicy)
		}
	}
}

// TestGrantingListOnlyMakesResourceVisibleButNotOpenable covers the
// three-tier model directly: granting ONLY pam:resource:List for a resource
// must make it show up in the catalog (ListGroups/List, via
// canSeeResourceInCatalog) while pam:resource:Read (view full details) and
// pam:resource:Connect (open a session) both stay denied until separately
// granted.
func TestGrantingListOnlyMakesResourceVisibleButNotOpenable(t *testing.T) {
	db := newRBACTestDB(t)
	logger := zap.NewNop()

	if err := SeedRBACDefaults(db, logger); err != nil {
		t.Fatalf("SeedRBACDefaults: %v", err)
	}

	var userRole models.Role
	if err := db.Where("name = ?", "user").First(&userRole).Error; err != nil {
		t.Fatalf("find seeded 'user' role: %v", err)
	}

	const userID = "list-only-user"
	if err := db.Create(&models.UserRole{UserID: userID, RoleID: userRole.ID}).Error; err != nil {
		t.Fatalf("assign user role: %v", err)
	}

	listOnly := &models.Policy{
		Name:      "grant-bob-minio-list-only",
		Effect:    string(models.PolicyEffectAllow),
		Actions:   []string{"pam:resource:List"},
		Resources: []string{"pam:resource/minio-2"},
	}
	if err := db.Create(listOnly).Error; err != nil {
		t.Fatalf("create list-only grant: %v", err)
	}
	if err := db.Create(&models.UserPolicy{UserID: userID, PolicyID: listOnly.ID}).Error; err != nil {
		t.Fatalf("attach list-only grant: %v", err)
	}

	engine := NewPolicyEngineService(db, logger)
	actx, err := engine.ResolveAuthzContext(userID)
	if err != nil {
		t.Fatalf("ResolveAuthzContext: %v", err)
	}

	if !actx.Allowed("pam:resource:List", "pam:resource/minio-2") {
		t.Fatal("expected pam:resource:List to be allowed for the list-only-granted resource")
	}
	if actx.Allowed("pam:resource:Read", "pam:resource/minio-2") {
		t.Fatal("expected pam:resource:Read to stay denied — List alone must not imply Read")
	}
	if actx.Allowed("pam:resource:Connect", "pam:resource/minio-2") {
		t.Fatal("expected pam:resource:Connect to stay denied — List alone must not imply Connect")
	}

	// Mirrors resource_handler.go's canSeeResourceInCatalog exactly (that
	// helper lives in package handlers, which imports this package — can't
	// import it back here without a cycle, so the same three-way OR is
	// inlined): a resource is catalog-visible the moment ANY of
	// List/Read/Connect is granted for it.
	isVisible := func(resourceID string) bool {
		pattern := "pam:resource/" + resourceID
		return actx.Allowed("pam:resource:List", pattern) ||
			actx.Allowed("pam:resource:Read", pattern) ||
			actx.Allowed("pam:resource:Connect", pattern)
	}
	if !isVisible("minio-2") {
		t.Fatal("expected the list-only-granted resource to be visible in the catalog")
	}
	if isVisible("some-other-resource") {
		t.Fatal("expected an ungranted resource to stay invisible in the catalog")
	}
}

func TestAdminGrantedResourceIsVisibleOnlyToThatResource(t *testing.T) {
	db := newRBACTestDB(t)
	logger := zap.NewNop()

	if err := SeedRBACDefaults(db, logger); err != nil {
		t.Fatalf("SeedRBACDefaults: %v", err)
	}

	var userRole models.Role
	if err := db.Where("name = ?", "user").First(&userRole).Error; err != nil {
		t.Fatalf("find seeded 'user' role: %v", err)
	}

	const userID = "standard-user-2"
	if err := db.Create(&models.UserRole{UserID: userID, RoleID: userRole.ID}).Error; err != nil {
		t.Fatalf("assign user role: %v", err)
	}

	// Simulates exactly what an admin does via POST /admin/rbac/policies +
	// POST /admin/identity/users/:id/policies to grant one specific
	// resource — no code change, just the RBAC/PBAC admin API already
	// wired in main.go.
	grant := &models.Policy{
		Name:      "grant-alice-minio",
		Effect:    string(models.PolicyEffectAllow),
		Actions:   []string{"pam:resource:Read", "pam:resource:Connect", "pam:session:Start"},
		Resources: []string{"pam:resource/minio-1"},
		IsSystem:  false,
	}
	if err := db.Create(grant).Error; err != nil {
		t.Fatalf("create grant policy: %v", err)
	}
	if err := db.Create(&models.UserPolicy{UserID: userID, PolicyID: grant.ID}).Error; err != nil {
		t.Fatalf("attach grant policy to user: %v", err)
	}

	engine := NewPolicyEngineService(db, logger)

	// Granted resource: visible and connectable.
	for _, action := range []string{"pam:resource:Read", "pam:resource:Connect", "pam:session:Start"} {
		res := engine.Authorize(nil, userID, action, "pam:resource/minio-1")
		if !res.Allowed {
			t.Fatalf("expected %s on the granted resource to be allowed, got denied: %s", action, res.Reason)
		}
	}

	// A DIFFERENT, ungranted resource must still be denied — the grant must
	// not leak into a blanket allow.
	res := engine.Authorize(nil, userID, "pam:resource:Read", "pam:resource/postgres-2")
	if res.Allowed {
		t.Fatalf("expected an ungranted resource to stay denied even after granting a different one, got allowed (matched policy %q)", res.MatchedPolicy)
	}

	// ── Also exercise the actual list-filtering helper used by
	// resource_handler.go's ListGroups/List, via ResolveAuthzContext. ──────
	actx, err := engine.ResolveAuthzContext(userID)
	if err != nil {
		t.Fatalf("ResolveAuthzContext: %v", err)
	}
	if !actx.Allowed("pam:resource:Read", "pam:resource/minio-1") {
		t.Fatal("AuthzContext: expected the granted resource to be readable")
	}
	if actx.Allowed("pam:resource:Read", "pam:resource/postgres-2") {
		t.Fatal("AuthzContext: expected the ungranted resource to stay unreadable")
	}
}

func TestRootBypassesResourceAccessChecks(t *testing.T) {
	db := newRBACTestDB(t)
	logger := zap.NewNop()

	if err := SeedRBACDefaults(db, logger); err != nil {
		t.Fatalf("SeedRBACDefaults: %v", err)
	}

	var rootRole models.Role
	if err := db.Where("name = ?", "root").First(&rootRole).Error; err != nil {
		t.Fatalf("find seeded 'root' role: %v", err)
	}

	const userID = "root-user"
	if err := db.Create(&models.UserRole{UserID: userID, RoleID: rootRole.ID}).Error; err != nil {
		t.Fatalf("assign root role: %v", err)
	}

	engine := NewPolicyEngineService(db, logger)
	res := engine.Authorize(nil, userID, "pam:resource:Connect", "pam:resource/anything-at-all")
	if !res.Allowed || res.Reason != "root_bypass" {
		t.Fatalf("expected root to bypass every check, got allowed=%v reason=%q", res.Allowed, res.Reason)
	}
}
