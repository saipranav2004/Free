package graph

import "strings"

// System account types — not created RBAC roles.
// They still live in pam_roles (so JSON kind stays "role" for the existing
// frontend) but derive/build treat them as the account class: user, admin, root.
const (
	AccountTypeUser  = "user"
	AccountTypeAdmin = "admin"
	AccountTypeRoot  = "root"
)

// EdgeCanDelegate is root-only admin delegation
// (POST /admin/identity/users/:id/delegate-admin).
// New kind; existing clients that ignore unknown kinds keep working.
const EdgeCanDelegate EdgeKind = "CAN_DELEGATE"

// IsSystemAccountType is true for the three fixed account classes.
func IsSystemAccountType(name string) bool {
	switch strings.ToLower(strings.TrimSpace(name)) {
	case AccountTypeUser, AccountTypeAdmin, AccountTypeRoot:
		return true
	default:
		return false
	}
}
