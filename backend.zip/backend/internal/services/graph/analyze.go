// pam/internal/services/graph/analyze.go
//
// Path-finding and scoring over a built graph.
//
// Three questions, three algorithms:
//
//  1. PathsTo(target)      — who can reach a crown jewel, and how?
//     Reverse BFS from the target, cheapest-edge-first.
//  2. Chokepoints()        — which single edge, if removed, severs the most
//     paths? This is the remediation ROI calculation and the reason to
//     build a graph rather than a checklist.
//  3. Summary()            — the handful of numbers worth trending on a
//     dashboard (standing vs JIT, shortest path, orphaned privilege).
package graph

import (
	"sort"
	"strings"
)

// ── PATHS ─────────────────────────────────────────────────────────────────

// Hop is one step along a path.
type Hop struct {
	FromID    string   `json:"from_id"`
	FromLabel string   `json:"from_label"`
	ToID      string   `json:"to_id"`
	ToLabel   string   `json:"to_label"`
	Kind      EdgeKind `json:"kind"`
	Via       string   `json:"via"`
	Finding   string   `json:"finding,omitempty"`
	Cost      int      `json:"cost"`
}

// Path is one route from a starting principal to a target capability.
type Path struct {
	SourceID    string `json:"source_id"`
	SourceLabel string `json:"source_label"`
	TargetID    string `json:"target_id"`
	TargetLabel string `json:"target_label"`
	Hops        []Hop  `json:"hops"`
	// TotalCost is the sum of hop costs — the difficulty score. Length alone
	// is a poor proxy: a 4-hop path of free structural edges is far more
	// dangerous than a 2-hop path requiring MFA plus a second approver.
	TotalCost int `json:"total_cost"`
	// AllStanding is true when every hop is permanent. These are the
	// findings that matter most: they are true right now and stay true.
	AllStanding bool `json:"all_standing"`
	// Findings is the deduplicated set of review IDs implicated.
	Findings []string `json:"findings,omitempty"`
}

func (p Path) Length() int { return len(p.Hops) }

// Analyzer runs queries against an immutable graph snapshot.
type Analyzer struct{ g *Graph }

func NewAnalyzer(g *Graph) *Analyzer { return &Analyzer{g: g} }

func (a *Analyzer) Graph() *Graph { return a.g }

// reverseIndex builds target -> incoming edges. Built lazily per query
// rather than stored on the Graph, because most callers only ever ask about
// a handful of targets and the full reverse index doubles memory.
func (a *Analyzer) reverseIndex() map[string][]Edge {
	in := make(map[string][]Edge, len(a.g.Nodes))
	for _, e := range a.g.Edges {
		in[e.To] = append(in[e.To], e)
	}
	return in
}

// PathsTo finds, for every user who can reach target, the cheapest path.
//
// Reverse BFS from the target rather than forward BFS from every user:
// there are many users and few targets, so working backwards visits each
// edge once total instead of once per user. Cheapest-first ordering (the
// Freeze sort, plus cost-ordered frontier insertion) means the first path
// found to any node is its cheapest, so we can stop expanding it.
//
// maxDepth bounds pathological graphs; 0 means the default of 8, which is
// well beyond any real escalation chain and keeps output readable.
func (a *Analyzer) PathsTo(target string, maxDepth int) []Path {
	if maxDepth <= 0 {
		maxDepth = 8
	}
	if _, ok := a.g.Nodes[target]; !ok {
		return nil
	}
	in := a.reverseIndex()

	// best[node] = cheapest known (cost, edge-to-next-node-toward-target)
	type crumb struct {
		next Edge // edge FROM this node, heading toward the target
		cost int
	}
	best := map[string]crumb{target: {cost: 0}}

	frontier := []string{target}
	for depth := 0; depth < maxDepth && len(frontier) > 0; depth++ {
		var next []string
		for _, cur := range frontier {
			curCrumb := best[cur]
			for _, e := range in[cur] {
				if e.From == e.To {
					continue // self-loop, never useful
				}
				newCost := curCrumb.cost + e.Cost
				existing, seen := best[e.From]
				if seen && existing.cost <= newCost {
					continue
				}
				best[e.From] = crumb{next: e, cost: newCost}
				next = append(next, e.From)
			}
		}
		frontier = next
	}

	// Walk each reachable USER forward to the target using the crumbs.
	var paths []Path
	for id, n := range a.g.Nodes {
		if n.Kind != KindUser {
			continue
		}
		_, ok := best[id]
		if !ok || id == target {
			continue
		}
		p := Path{
			SourceID: id, SourceLabel: n.Label,
			TargetID: target, TargetLabel: a.g.Nodes[target].Label,
			AllStanding: true,
		}
		findingSet := map[string]bool{}
		cursor := id
		guard := 0
		for cursor != target && guard <= maxDepth {
			guard++
			cc, ok := best[cursor]
			if !ok || cc.next.To == "" {
				break
			}
			e := cc.next
			fromNode, toNode := a.g.Nodes[e.From], a.g.Nodes[e.To]
			hop := Hop{
				FromID: e.From, ToID: e.To, Kind: e.Kind,
				Via: e.Via, Finding: e.Finding, Cost: e.Cost,
			}
			if fromNode != nil {
				hop.FromLabel = fromNode.Label
			}
			if toNode != nil {
				hop.ToLabel = toNode.Label
			}
			p.Hops = append(p.Hops, hop)
			p.TotalCost += e.Cost
			if !e.Standing {
				p.AllStanding = false
			}
			if e.Finding != "" {
				findingSet[e.Finding] = true
			}
			cursor = e.To
		}
		if len(p.Hops) == 0 {
			continue
		}
		for f := range findingSet {
			p.Findings = append(p.Findings, f)
		}
		sort.Strings(p.Findings)
		paths = append(paths, p)
	}

	// Rank: cheapest first, then shortest, then alphabetical for stable
	// output (stability matters — this gets diffed between runs).
	sort.SliceStable(paths, func(i, j int) bool {
		if paths[i].TotalCost != paths[j].TotalCost {
			return paths[i].TotalCost < paths[j].TotalCost
		}
		if len(paths[i].Hops) != len(paths[j].Hops) {
			return len(paths[i].Hops) < len(paths[j].Hops)
		}
		return paths[i].SourceLabel < paths[j].SourceLabel
	})
	return paths
}

// ── CHOKEPOINTS ───────────────────────────────────────────────────────────

// Chokepoint is one edge ranked by how much reachability it carries.
type Chokepoint struct {
	Edge Edge `json:"edge"`
	// PathsSevered is how many (user, target) paths traverse this edge.
	PathsSevered int `json:"paths_severed"`
	// UsersCutOff is how many distinct users lose at least one path.
	UsersCutOff int      `json:"users_cut_off"`
	Targets     []string `json:"targets"`
	FromLabel   string   `json:"from_label"`
	ToLabel     string   `json:"to_label"`
}

// Chokepoints ranks edges by the number of crown-jewel paths crossing them.
//
// This is the question a checklist cannot answer. Twenty findings all
// downstream of one missing guard are one fix, not twenty — and the graph
// is what proves it. Sorting remediation by severed-path count consistently
// finds the single change with the largest blast-radius reduction.
func (a *Analyzer) Chokepoints(targets []string, limit int) []Chokepoint {
	type agg struct {
		edge    Edge
		paths   int
		users   map[string]bool
		targets map[string]bool
	}
	tally := map[string]*agg{}

	for _, t := range targets {
		for _, p := range a.PathsTo(t, 0) {
			for _, h := range p.Hops {
				key := h.FromID + "|" + h.ToID + "|" + string(h.Kind)
				e, ok := tally[key]
				if !ok {
					e = &agg{
						edge:    Edge{From: h.FromID, To: h.ToID, Kind: h.Kind, Via: h.Via, Finding: h.Finding, Cost: h.Cost},
						users:   map[string]bool{},
						targets: map[string]bool{},
					}
					tally[key] = e
				}
				e.paths++
				e.users[p.SourceID] = true
				e.targets[t] = true
			}
		}
	}

	out := make([]Chokepoint, 0, len(tally))
	for _, e := range tally {
		cp := Chokepoint{
			Edge: e.edge, PathsSevered: e.paths, UsersCutOff: len(e.users),
		}
		if n := a.g.Nodes[e.edge.From]; n != nil {
			cp.FromLabel = n.Label
		}
		if n := a.g.Nodes[e.edge.To]; n != nil {
			cp.ToLabel = n.Label
		}
		for t := range e.targets {
			if tn := a.g.Nodes[t]; tn != nil {
				cp.Targets = append(cp.Targets, tn.Label)
			}
		}
		sort.Strings(cp.Targets)
		out = append(out, cp)
	}

	sort.SliceStable(out, func(i, j int) bool {
		if out[i].PathsSevered != out[j].PathsSevered {
			return out[i].PathsSevered > out[j].PathsSevered
		}
		return out[i].UsersCutOff > out[j].UsersCutOff
	})
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out
}

// ── SUMMARY ───────────────────────────────────────────────────────────────

type TargetSummary struct {
	TargetID       string `json:"target_id"`
	TargetLabel    string `json:"target_label"`
	ReachableUsers int    `json:"reachable_users"`
	ShortestHops   int    `json:"shortest_hops"`
	CheapestCost   int    `json:"cheapest_cost"`
	StandingPaths  int    `json:"standing_paths"`
}

type Summary struct {
	Stats   Stats           `json:"stats"`
	Targets []TargetSummary `json:"targets"`
	// TotalUsers / UsersWithAnyPath give the headline "% of identities with
	// a path to a crown jewel" metric.
	TotalUsers       int `json:"total_users"`
	UsersWithAnyPath int `json:"users_with_any_path"`
	// StandingVsJIT contrasts permanent edges against time-boxed grants —
	// the single best measure of whether the JIT programme is working.
	StandingEdges int `json:"standing_edges"`
	JITGrantEdges int `json:"jit_grant_edges"`
	// OrphanedPrivilege counts role/policy attachments held by users who are
	// soft-deleted or DISABLED — privilege nobody is watching.
	OrphanedPrivilege []string `json:"orphaned_privilege,omitempty"`
	// FindingCounts aggregates how many paths implicate each review item,
	// which is what drives the fix ordering.
	FindingCounts map[string]int `json:"finding_counts,omitempty"`
}

func (a *Analyzer) Summarize(targets []string) Summary {
	s := Summary{Stats: a.g.Stats(), FindingCounts: map[string]int{}}

	reached := map[string]bool{}
	for _, t := range targets {
		tn := a.g.Nodes[t]
		if tn == nil {
			continue
		}
		paths := a.PathsTo(t, 0)
		ts := TargetSummary{TargetID: t, TargetLabel: tn.Label, ReachableUsers: len(paths)}
		ts.ShortestHops, ts.CheapestCost = -1, -1
		for _, p := range paths {
			reached[p.SourceID] = true
			if ts.ShortestHops < 0 || len(p.Hops) < ts.ShortestHops {
				ts.ShortestHops = len(p.Hops)
			}
			if ts.CheapestCost < 0 || p.TotalCost < ts.CheapestCost {
				ts.CheapestCost = p.TotalCost
			}
			if p.AllStanding {
				ts.StandingPaths++
			}
			for _, f := range p.Findings {
				s.FindingCounts[f]++
			}
		}
		s.Targets = append(s.Targets, ts)
	}

	for _, n := range a.g.Nodes {
		if n.Kind == KindUser {
			s.TotalUsers++
			// Orphaned privilege: a disabled or deleted account that still
			// holds outbound role/policy edges.
			if n.Attrs["soft_deleted"] == "true" || n.Attrs["status"] == "DISABLED" {
				for _, e := range a.g.Out[n.ID] {
					if e.Kind == EdgeHasRole || e.Kind == EdgeHasPolicy {
						s.OrphanedPrivilege = append(s.OrphanedPrivilege,
							n.Label+" ("+n.Attrs["status"]+") still holds "+
								strings.TrimPrefix(e.To, "role:"))
						break
					}
				}
			}
		}
	}
	s.UsersWithAnyPath = len(reached)
	s.StandingEdges = s.Stats.StandingEdges
	s.JITGrantEdges = s.Stats.ByEdgeKind[string(EdgeHoldsGrant)]
	sort.Strings(s.OrphanedPrivilege)
	return s
}
