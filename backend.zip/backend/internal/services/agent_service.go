// pam/internal/services/agent_service.go
//
// AgentService implements the local-agent pairing and launch-token
// handshake that lets PAM open a real desktop CLI/GUI already authenticated
// — the same outcome the browser session gateway gives you, but for tools
// that only make sense running natively on the operator's own machine
// (psql, mongosh, redis-cli, or an installed GUI client).
//
// Trust model, spelled out because it's the part worth reviewing hardest:
//
//  1. Pairing (once per machine): the user requests a short, human-typed,
//     5-minute pairing code from an authenticated PAM session. The agent
//     generates an Ed25519 keypair locally, sends its PUBLIC key + the code
//     to PAM once. PAM never sees the private key. From here on, the agent
//     proves its identity by signing requests — nothing it holds locally is
//     a bearer secret an attacker could just copy and replay from elsewhere
//     (a signature is only useful with the private key it was made with).
//
//  2. Launch (every connect): the browser asks PAM for a one-time, 60-second
//     launch token scoped to exactly one resource + user — this call is
//     gated by the exact same pam:resource:Connect RBAC/PBAC check as the
//     browser session gateway, plus the identical RequireActiveGrant check
//     for JIT-gated resources. The browser hands that token to the OS via a
//     pam-agent:// URL; the OS launches the locally-installed agent with it.
//     The agent redeems the token directly against PAM, signing the
//     request with its enrolled key. PAM verifies the signature, verifies
//     the token belongs to THAT SAME user, consumes it exactly once, then
//     resolves the vaulted credential and hands it to the agent — never to
//     the browser, never twice.
package services

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/recorder"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrPairingCodeInvalid = errors.New("pairing code is invalid, expired, or already used")
	ErrDeviceNotFound     = errors.New("agent device not found")
	ErrDeviceRevoked      = errors.New("agent device has been revoked")
	ErrLaunchTokenInvalid = errors.New("launch token is invalid, expired, or already used")
	ErrSignatureInvalid   = errors.New("agent signature verification failed")

	// ErrConnectMethodNotAllowed means the resource's policy closed the
	// native-agent path (see models.PAMResource.AllowedConnectMethods).
	//
	// This is the gate that makes every data-protection control credible.
	// PAM proxies the two brokered paths and can enforce on them, but the
	// agent receives the plaintext credential and connects DIRECT to the
	// target — so clipboard, download and egress controls on a resource that
	// still permits the agent are bypassed by choosing a different connect
	// button. Without this check those controls are decoration.
	ErrConnectMethodNotAllowed = errors.New("this resource does not permit the native agent connect method")
)

const (
	pairingCodeLength = 8
	pairingCodeTTL    = 5 * time.Minute
	// pairingCodeMaxTTL bounds how long-lived a caller can ask a pairing
	// code to be (see InitPairing's ttl parameter) — long enough to cover
	// an installer-embedded pairing code that might sit on a USB stick or
	// in a deployment pipeline for a while before the agent actually runs
	// pam-agent install && pam-agent pair on the target machine, but still
	// bounded so a leaked code can't be replayed indefinitely.
	pairingCodeMaxTTL = 24 * time.Hour
	launchTokenTTL    = 60 * time.Second
	signatureMaxSkew  = 30 * time.Second
)

type AgentService struct {
	db               *gorm.DB
	resourceSvc      *ResourceService
	recordingStorage recorder.Storage

	// audit records policy decisions taken here rather than leaving them to
	// callers. A refusal to release a credential is exactly the kind of event
	// that must not depend on every caller remembering to log it. Nil-safe:
	// writes are skipped when unset, so existing constructions (tests) keep
	// working without an audit backend.
	audit *AuditService

	logger *zap.Logger
}

func NewAgentService(db *gorm.DB, resourceSvc *ResourceService, recordingStorage recorder.Storage,
	audit *AuditService, logger *zap.Logger) *AgentService {
	return &AgentService{
		db: db, resourceSvc: resourceSvc, recordingStorage: recordingStorage,
		audit: audit, logger: logger,
	}
}

// ──────────────────────────────────────────────────────────────────────────
// PAIRING
// ──────────────────────────────────────────────────────────────────────────

// InitPairing issues a short, human-typed pairing code for the given
// authenticated PAM user. The raw code is returned exactly once and never
// stored — only its hash is persisted, the same treatment as vault
// credentials.
//
// ttl lets a caller ask for a longer-lived code than the 5-minute default —
// e.g. an installer that embeds a one-time setup token so `pam-agent
// install && pam-agent pair` can run unattended sometime after the browser
// session that requested it is long gone. A zero ttl means "use the
// default"; anything requested above pairingCodeMaxTTL is silently capped,
// never rejected outright, so a slightly-too-generous caller still gets a
// safe code instead of an error.
func (s *AgentService) InitPairing(userID string, ttl time.Duration) (code string, expiresAt time.Time, err error) {
	code, err = generateHumanCode(pairingCodeLength)
	if err != nil {
		return "", time.Time{}, fmt.Errorf("failed to generate pairing code: %w", err)
	}

	effectiveTTL := pairingCodeTTL
	if ttl > 0 {
		effectiveTTL = ttl
		if effectiveTTL > pairingCodeMaxTTL {
			effectiveTTL = pairingCodeMaxTTL
		}
	}

	expiresAt = time.Now().Add(effectiveTTL)
	rec := &models.AgentPairingCode{
		UserID:    userID,
		CodeHash:  hashSecret(code),
		Status:    "PENDING",
		ExpiresAt: expiresAt,
	}
	if err := s.db.Create(rec).Error; err != nil {
		return "", time.Time{}, fmt.Errorf("failed to store pairing code: %w", err)
	}

	s.logger.Info("agent.pairing.init", zap.String("user_id", userID))
	return code, expiresAt, nil
}

// ValidatePairingCode checks a code is real, still PENDING and unexpired,
// WITHOUT consuming it.
//
// Needed because one-click enrolment serves two unauthenticated things — the
// generated installer and the agent binary — gated by the pairing code carried
// in their URL. Those fetches must not spend the code: the agent itself
// redeems it moments later via CompletePairing, and a fetch that consumed it
// would leave the operator holding an installer that can no longer pair. The
// retry a browser or a proxy performs on either URL must also be harmless.
//
// Same acceptance rules as CompletePairing, deliberately no side effects.
// Returns the owning user so a caller can scope what it serves to that person.
func (s *AgentService) ValidatePairingCode(code string) (userID string, expiresAt time.Time, err error) {
	if code == "" {
		return "", time.Time{}, ErrPairingCodeInvalid
	}

	var rec models.AgentPairingCode
	if err := s.db.Where("code_hash = ?", hashSecret(code)).First(&rec).Error; err != nil {
		return "", time.Time{}, ErrPairingCodeInvalid
	}
	if rec.Status != "PENDING" || time.Now().After(rec.ExpiresAt) {
		return "", time.Time{}, ErrPairingCodeInvalid
	}
	return rec.UserID, rec.ExpiresAt, nil
}

// CompletePairing is called by the agent itself (not through a browser
// session — the agent has no PAM JWT yet at this point) with the code the
// user typed plus the public half of a freshly generated Ed25519 keypair.
func (s *AgentService) CompletePairing(code, deviceName, publicKeyB64 string) (*models.AgentDevice, error) {
	pubBytes, err := base64.StdEncoding.DecodeString(publicKeyB64)
	if err != nil || len(pubBytes) != ed25519.PublicKeySize {
		return nil, fmt.Errorf("invalid device public key")
	}

	var rec models.AgentPairingCode
	if err := s.db.Where("code_hash = ?", hashSecret(code)).First(&rec).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrPairingCodeInvalid
		}
		return nil, err
	}
	if rec.Status != "PENDING" || time.Now().After(rec.ExpiresAt) {
		return nil, ErrPairingCodeInvalid
	}

	device := &models.AgentDevice{
		UserID:     rec.UserID,
		DeviceName: deviceName,
		PublicKey:  publicKeyB64,
		Status:     "ACTIVE",
	}
	if err := s.db.Create(device).Error; err != nil {
		return nil, fmt.Errorf("failed to register agent device: %w", err)
	}

	now := time.Now()
	result := s.db.Model(&models.AgentPairingCode{}).
		Where("id = ? AND status = 'PENDING'", rec.ID).
		Updates(map[string]interface{}{"status": "CONSUMED", "consumed_at": now})
	if result.Error != nil {
		return nil, result.Error
	}
	if result.RowsAffected == 0 {
		// Lost a race against a concurrent redemption of the same code —
		// undo the device we just created rather than leaving two devices
		// paired off one single-use code.
		s.db.Delete(&models.AgentDevice{}, "id = ?", device.ID)
		return nil, ErrPairingCodeInvalid
	}

	s.logger.Info("agent.paired",
		zap.String("user_id", rec.UserID),
		zap.String("device_id", device.ID),
		zap.String("device_name", deviceName),
	)
	return device, nil
}

func (s *AgentService) ListDevices(userID string) ([]models.AgentDevice, error) {
	var devices []models.AgentDevice
	err := s.db.Where("user_id = ?", userID).Order("created_at DESC").Find(&devices).Error
	return devices, err
}

// RevokeDevice immediately invalidates a paired device — e.g. a lost laptop.
// Scoped to userID so a user can only revoke their own devices.
func (s *AgentService) RevokeDevice(userID, deviceID string) error {
	result := s.db.Model(&models.AgentDevice{}).
		Where("id = ? AND user_id = ?", deviceID, userID).
		Update("status", "REVOKED")
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return ErrDeviceNotFound
	}
	return nil
}

// HasActiveDevice tells the launch-token endpoint whether it's even worth
// issuing a token — if the user has no paired agent yet, fail fast with a
// clear "go install the agent" message instead of a token that can never be
// redeemed.
func (s *AgentService) HasActiveDevice(userID string) (bool, error) {
	var count int64
	err := s.db.Model(&models.AgentDevice{}).
		Where("user_id = ? AND status = 'ACTIVE'", userID).Count(&count).Error
	return count > 0, err
}

// ──────────────────────────────────────────────────────────────────────────
// LAUNCH TOKENS
// ──────────────────────────────────────────────────────────────────────────

// LaunchGrantContext is the subset of middleware.GrantContext the launch
// flow needs to carry from token issuance (inside the authenticated
// request, where RequireActiveGrant already resolved it) through to token
// redemption (the agent's bare signed POST, with no gin.Context at all).
// Defined here rather than importing middleware.GrantContext directly to
// avoid a services -> middleware import (middleware already imports
// services; that would be circular).
type LaunchGrantContext struct {
	GrantID           string
	JITRequestID      string
	IsBreakglass      bool
	RecordingRequired bool
}

// CreateLaunchToken issues a one-time, 60-second token for a resource the
// caller has already been authorized (via the embedded policy engine, and —
// for JIT-gated resources — RequireActiveGrant) to connect to. grant is the
// zero value for a resource that isn't JIT-gated.
func (s *AgentService) CreateLaunchToken(userID, resourceID, authzDecisionID string, grant LaunchGrantContext) (rawToken string, expiresAt time.Time, err error) {
	rawToken, err = generateOpaqueToken(32)
	if err != nil {
		return "", time.Time{}, fmt.Errorf("failed to generate launch token: %w", err)
	}

	expiresAt = time.Now().Add(launchTokenTTL)
	rec := &models.LaunchToken{
		TokenHash:         hashSecret(rawToken),
		ResourceID:        resourceID,
		UserID:            userID,
		Status:            "PENDING",
		ExpiresAt:         expiresAt,
		IsBreakglass:      grant.IsBreakglass,
		RecordingRequired: grant.RecordingRequired,
	}
	if authzDecisionID != "" {
		rec.AuthzDecisionID = &authzDecisionID
	}
	if grant.GrantID != "" {
		rec.GrantID = &grant.GrantID
	}
	if grant.JITRequestID != "" {
		rec.JITRequestID = &grant.JITRequestID
	}
	if err := s.db.Create(rec).Error; err != nil {
		return "", time.Time{}, fmt.Errorf("failed to store launch token: %w", err)
	}
	return rawToken, expiresAt, nil
}

// ResolvedLaunch is everything the agent needs to build a local command.
// The plaintext credential lives here only in memory, for the duration of
// one HTTP response to the agent — it is never logged and never sent
// anywhere else.
type ResolvedLaunch struct {
	SessionID         string
	RecordingRequired bool

	// DataProtection is the effective egress policy the agent enforces
	// locally, in the shape the agent's own guard expects. DeniedCommands is
	// resolved to a concrete list here (built-in defaults substituted for an
	// empty one) so the agent never has to know which defaults apply to which
	// tool — that decision stays server-side with the rest of the policy.
	DataProtection AgentDataProtection `json:"data_protection"`

	*ConnectionInfo
}

// AgentDataProtection is the wire shape sent to pam-agent. Deliberately a
// separate type from models.DataProtection: the agent enforces three of those
// controls and has no use for the two that are browser-only, and sending
// fields it cannot act on would imply it does.
type AgentDataProtection struct {
	BlockClipboard bool     `json:"block_clipboard"`
	MaxEgressBytes int64    `json:"max_egress_bytes"`
	DeniedCommands []string `json:"denied_commands"`
}

// ResolveLaunchToken verifies the agent's signature over the raw token,
// confirms the redeeming device is active and belongs to the same user the
// token was issued for, consumes the token exactly once, resolves the
// vaulted credential, and opens the same grant-aware tracked-session record
// (StartTrackedSession) the browser session gateway uses — including
// recording obligations for JIT-gated, always-record, or break-glass
// resources, using the grant context captured at issuance time (see
// models.LaunchToken's doc comment for why that capture is necessary).
func (s *AgentService) ResolveLaunchToken(rawToken, agentDeviceID, signatureB64 string,
	timestamp time.Time, sourceIP string) (*ResolvedLaunch, error) {

	var device models.AgentDevice
	if err := s.db.Where("id = ?", agentDeviceID).First(&device).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrDeviceNotFound
		}
		return nil, err
	}
	if device.Status != "ACTIVE" {
		return nil, ErrDeviceRevoked
	}

	if err := verifySignature(device.PublicKey, rawToken, timestamp, signatureB64); err != nil {
		s.logger.Warn("agent.launch.signature_invalid",
			zap.String("device_id", agentDeviceID), zap.Error(err))
		return nil, ErrSignatureInvalid
	}

	var tok models.LaunchToken
	if err := s.db.Where("token_hash = ?", hashSecret(rawToken)).First(&tok).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrLaunchTokenInvalid
		}
		return nil, err
	}
	if tok.Status != "PENDING" || time.Now().After(tok.ExpiresAt) {
		return nil, ErrLaunchTokenInvalid
	}
	if tok.UserID != device.UserID {
		// The token looks structurally valid but was issued to a different
		// user than the redeeming device belongs to — never honor it.
		s.logger.Warn("agent.launch.user_mismatch",
			zap.String("token_user", tok.UserID), zap.String("device_user", device.UserID))
		return nil, ErrLaunchTokenInvalid
	}

	now := time.Now()
	result := s.db.Model(&models.LaunchToken{}).
		Where("id = ? AND status = 'PENDING'", tok.ID).
		Updates(map[string]interface{}{
			"status": "CONSUMED", "consumed_at": now, "agent_device_id": device.ID,
		})
	if result.Error != nil {
		return nil, result.Error
	}
	if result.RowsAffected == 0 {
		// Lost a race against a concurrent redemption of the same token.
		return nil, ErrLaunchTokenInvalid
	}

	// Checked ahead of ResolveConnection, which decrypts the vaulted
	// credential: a path the policy has closed must not cause a secret to be
	// unwrapped, let alone handed to a device.
	//
	// This is the authoritative gate rather than CreateLaunchToken's, because
	// this is the call that actually releases the credential — a token issued
	// before an admin tightened the policy must still be refused here.
	resource, err := s.resourceSvc.GetResource(tok.ResourceID)
	if err != nil {
		return nil, fmt.Errorf("failed to resolve resource: %w", err)
	}
	if !resource.AllowsConnectMethod(models.ConnectMethodAgent) {
		s.auditWrite(AuditEntry{
			ActorUserID: tok.UserID,
			Action:      models.AuditConnectMethodDenied,
			Category:    models.SessionLifecycle,
			Outcome:     models.AuditOutcomeDenied,
			Severity:    models.AuditSeverityWarn,
			ResourceID:  tok.ResourceID,
			Details: map[string]interface{}{
				"connect_method":          models.ConnectMethodAgent,
				"allowed_connect_methods": resource.AllowedConnectMethods,
				"agent_device_id":         device.ID,
			},
		})
		return nil, ErrConnectMethodNotAllowed
	}

	connInfo, err := s.resourceSvc.ResolveConnection(tok.ResourceID)
	if err != nil {
		return nil, fmt.Errorf("failed to resolve resource connection: %w", err)
	}

	// The data-protection policy the agent will enforce locally.
	//
	// Composed here rather than captured on the launch token: the resource is
	// already loaded above for the connect-method gate, and the grant is one
	// lookup away, so there is no reason to duplicate four columns onto the
	// token and then have them drift from the resource they describe.
	//
	// Resolved server-side on principle. An agent that decided its own policy
	// would be asking the operator's machine how restricted the operator ought
	// to be.
	policy := resource.DataProtectionProfile()
	if tok.GrantID != nil && *tok.GrantID != "" {
		var grant models.AccessGrant
		if err := s.db.Where("id = ?", *tok.GrantID).First(&grant).Error; err == nil {
			policy = models.MostRestrictive(policy, grant.DataProtectionProfile())
		}
	}
	// An empty deny list with command blocking wanted means "use the built-in
	// patterns for this tool", so enabling it does not require an administrator
	// to know every dump verb for every client.
	denied := policy.DeniedCommandList()
	if len(denied) == 0 && policy.Any() {
		denied = models.DefaultDeniedCommands(resource.ResourceType)
	}

	authzDecisionID := ""
	if tok.AuthzDecisionID != nil {
		authzDecisionID = *tok.AuthzDecisionID
	}
	grantID := ""
	if tok.GrantID != nil {
		grantID = *tok.GrantID
	}
	jitRequestID := ""
	if tok.JITRequestID != nil {
		jitRequestID = *tok.JITRequestID
	}

	session, _, err := s.resourceSvc.StartTrackedSession(StartSessionInput{
		UserID:            device.UserID,
		Username:          s.lookupUsername(device.UserID),
		ResourceID:        tok.ResourceID,
		SourceIP:          sourceIP,
		Protocol:          connInfo.ResourceType,
		AuthzDecisionID:   authzDecisionID,
		GrantID:           grantID,
		JITRequestID:      jitRequestID,
		IsBreakglass:      tok.IsBreakglass,
		RecordingRequired: tok.RecordingRequired,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to start session record: %w", err)
	}

	s.db.Model(&models.AgentDevice{}).Where("id = ?", device.ID).Update("last_seen_at", now)

	s.logger.Info("agent.launch.resolved",
		zap.String("session_id", session.ID),
		zap.String("resource_id", tok.ResourceID),
		zap.String("user_id", device.UserID),
		zap.String("device_id", device.ID),
		zap.String("grant_id", grantID),
	)

	return &ResolvedLaunch{
		SessionID:         session.ID,
		RecordingRequired: session.RecordingRequired,
		DataProtection: AgentDataProtection{
			BlockClipboard: policy.BlockClipboard,
			MaxEgressBytes: policy.MaxEgressBytes,
			DeniedCommands: denied,
		},
		ConnectionInfo: connInfo,
	}, nil
}

// EndLaunchSession lets the agent report that the locally-launched process
// exited, closing the audit record — the native-launch equivalent of the
// browser session gateway's own EndSession call. agentDeviceID is who is
// reporting this (already signature-verified by the caller); status
// COMPLETED ends the session normally, anything else (e.g. FAILED) records
// it as killed with that reason instead of a clean completion.
func (s *AgentService) EndLaunchSession(sessionID, agentDeviceID, status string) error {
	var device models.AgentDevice
	if err := s.db.Where("id = ?", agentDeviceID).First(&device).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrDeviceNotFound
		}
		return err
	}

	if status == "" || status == "COMPLETED" {
		_, err := s.resourceSvc.EndTrackedSession(sessionID, device.UserID, true)
		return err
	}
	// killed_by is a varchar(36) actor-id column everywhere else it's
	// written (see admin_handler.go/resource_handler.go) — it holds a
	// plain user ID, not a free-form label. Pass the device's owning
	// user ID there and put the "which device reported this" detail in
	// kill_reason instead, which is unbounded (models.ConnectionSession.
	// KillReason is `text`). An earlier version of this line passed
	// "agent-device:"+device.ID directly as killed_by, which overflows
	// the varchar(36) column for any device ID and made every non-clean
	// (status=FAILED) agent-reported session end fail with a Postgres
	// "value too long for type character varying(36)" error.
	return s.resourceSvc.KillSession(sessionID, device.UserID,
		fmt.Sprintf("Local agent reported launch status=%s (agent_device_id=%s)", status, device.ID))
}

// CapturedCommand is one line pam-agent's ConPTY input relay reconstructed
// from raw keystrokes (see pam-agent's internal/launcher/keylog.go) — a
// best-effort approximation of "what did the operator type," not a real
// command/result pair the way the browser gateway's protocol runners
// produce. OffsetMs is milliseconds since the session started; there is no
// other per-line timestamp signal available from a raw keystroke stream, so
// OccurredAt gets reconstructed from it rather than measured directly.
type CapturedCommand struct {
	Input    string `json:"input"`
	OffsetMs int64  `json:"offset_ms"`
}

// UploadLaunchRecording accepts the finished recording a native agent
// captured locally (see pam-agent's ConPTY-backed Windows launch path) and
// closes out the recording obligation StartTrackedSession created when this
// session was resolved — the native-launch equivalent of gateway.go's
// finalizeRecording. Signature verification is the caller's job (the agent
// signs sessionID the same way EndLaunch does); this just needs to know
// which device is asserting the upload for logging.
//
// gz is trusted for its bytes but not for its own claimed hash/size — sha256
// and length are always recomputed here from what was actually received,
// the same posture every other artifact-attach path in this codebase takes.
func (s *AgentService) UploadLaunchRecording(sessionID, agentDeviceID string, gz []byte, status, failureReason string, commands []CapturedCommand) error {
	var device models.AgentDevice
	if err := s.db.Where("id = ?", agentDeviceID).First(&device).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrDeviceNotFound
		}
		return err
	}

	sess, err := s.resourceSvc.GetSession(sessionID)
	if err != nil {
		return err
	}
	if sess.RecordingID == nil || *sess.RecordingID == "" {
		return fmt.Errorf("session %s has no recording obligation to attach an artifact to", sessionID)
	}
	recordingID := *sess.RecordingID

	// Independent of whether the video artifact itself saves successfully
	// below — the structured command log is the searchable half of a
	// recording (see models.SessionRecordingCommand's doc comment) and
	// losing it isn't contingent on the cast blob's own fate.
	if len(commands) > 0 {
		s.storeCapturedCommands(recordingID, sessionID, sess.StartedAt, commands)
	}

	if status == "FAILED" {
		if failureReason == "" {
			failureReason = "local agent reported a recording capture failure"
		}
		s.logger.Warn("agent.recording.upload.client_failed",
			zap.String("session_id", sessionID), zap.String("recording_id", recordingID), zap.String("reason", failureReason))
		return s.resourceSvc.MarkRecordingFailed(recordingID, failureReason)
	}

	if s.recordingStorage == nil {
		return s.resourceSvc.MarkRecordingFailed(recordingID, "recording storage was not configured/available on the PAM server")
	}

	sum := sha256.Sum256(gz)
	sha256Hex := hex.EncodeToString(sum[:])
	key := fmt.Sprintf("recordings/%s/%s.cast.gz", time.Now().UTC().Format("2006/01/02"), recordingID)

	if err := s.recordingStorage.Save(context.Background(), key, gz); err != nil {
		s.logger.Error("agent.recording.upload.save_fail",
			zap.String("session_id", sessionID), zap.String("recording_id", recordingID), zap.Error(err))
		return s.resourceSvc.MarkRecordingFailed(recordingID, "failed to persist agent-uploaded recording: "+err.Error())
	}

	if err := s.resourceSvc.AttachRecordingArtifact(recordingID, s.recordingStorage.Label(), key, int64(len(gz)), sha256Hex, false); err != nil {
		return err
	}
	s.logger.Info("agent.recording.upload.ok",
		zap.String("session_id", sessionID), zap.String("recording_id", recordingID), zap.Int("bytes", len(gz)))
	return nil
}

// storeCapturedCommands persists pam-agent's best-effort keystroke-derived
// command list — the native-launch counterpart to AppendRecordingCommand's
// callers in gateway.go's protocol runners (redis.go/postgres.go/mongo.go/
// ssh.go). Unlike those, a raw keystroke stream carries no real
// success/failure/output signal for what it captured, which OutputSummary
// says explicitly rather than fabricating one. Best-effort by design: one
// row failing to save is logged and skipped, not returned as an error — the
// caller's video-artifact upload (already committed by the time this runs)
// shouldn't be undone by a lesser compliance gap in this secondary log.
func (s *AgentService) storeCapturedCommands(recordingID, sessionID string, sessionStartedAt time.Time, commands []CapturedCommand) {
	for i, cmd := range commands {
		masked := recorder.MaskSecrets(cmd.Input)
		row := &models.SessionRecordingCommand{
			RecordingID:   recordingID,
			SessionID:     sessionID,
			Sequence:      i + 1,
			Input:         masked,
			InputMasked:   masked != cmd.Input,
			Outcome:       "SUCCESS",
			OutputSummary: "captured via native agent keystroke relay — command result not available",
			OccurredAt:    sessionStartedAt.Add(time.Duration(cmd.OffsetMs) * time.Millisecond),
		}
		if err := s.resourceSvc.AppendRecordingCommand(row); err != nil {
			s.logger.Warn("agent.recording.commands.append_fail",
				zap.String("session_id", sessionID), zap.String("recording_id", recordingID), zap.Error(err))
		}
	}
}

// VerifyDeviceSignature checks that agentDeviceID is ACTIVE and that
// signatureB64 is a valid Ed25519 signature — from that device's enrolled
// public key, within the allowed clock skew — over the given value. Used
// for lower-stakes agent-authenticated calls (like reporting a session
// ended) that don't need the full launch-token consumption dance.
func (s *AgentService) VerifyDeviceSignature(agentDeviceID, value, signatureB64 string, timestamp time.Time) error {
	var device models.AgentDevice
	if err := s.db.Where("id = ?", agentDeviceID).First(&device).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return ErrDeviceNotFound
		}
		return err
	}
	if device.Status != "ACTIVE" {
		return ErrDeviceRevoked
	}
	return verifySignature(device.PublicKey, value, timestamp, signatureB64)
}

func (s *AgentService) lookupUsername(userID string) string {
	var user models.User
	if err := s.db.Where("user_id = ?", userID).First(&user).Error; err != nil {
		return ""
	}
	return user.Username
}

// ──────────────────────────────────────────────────────────────────────────
// CRYPTO / TOKEN HELPERS
// ──────────────────────────────────────────────────────────────────────────

func hashSecret(v string) string {
	sum := sha256.Sum256([]byte(v))
	return hex.EncodeToString(sum[:])
}

func generateOpaqueToken(nBytes int) (string, error) {
	b := make([]byte, nBytes)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

// generateHumanCode returns an uppercase code drawn from an alphabet with
// visually ambiguous characters (0/O, 1/I/L) removed, so it's easy to read
// off one screen and type into another without transcription errors.
func generateHumanCode(n int) (string, error) {
	const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
	raw := make([]byte, n)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	code := make([]byte, n)
	for i, b := range raw {
		code[i] = alphabet[int(b)%len(alphabet)]
	}
	return string(code), nil
}

// signingMessage is the exact canonical string an agent must sign — the
// same construction is documented and implemented independently in the
// agent module (pam-agent/internal/apiclient), since the two are separate
// Go modules. Keep this comment in sync if the format ever changes:
// "<value>|<unix-seconds-timestamp>". value is the launch token when
// redeeming a launch, or the session ID when reporting a session ended.
func signingMessage(value string, timestamp time.Time) string {
	return fmt.Sprintf("%s|%d", value, timestamp.Unix())
}

func verifySignature(publicKeyB64, value string, timestamp time.Time, signatureB64 string) error {
	if absDuration(time.Since(timestamp)) > signatureMaxSkew {
		return fmt.Errorf("timestamp outside allowed skew")
	}

	pubBytes, err := base64.StdEncoding.DecodeString(publicKeyB64)
	if err != nil || len(pubBytes) != ed25519.PublicKeySize {
		return fmt.Errorf("invalid stored device public key")
	}

	sig, err := base64.StdEncoding.DecodeString(signatureB64)
	if err != nil {
		return fmt.Errorf("invalid signature encoding")
	}

	message := []byte(signingMessage(value, timestamp))
	if !ed25519.Verify(ed25519.PublicKey(pubBytes), message, sig) {
		return fmt.Errorf("signature does not verify")
	}
	return nil
}

func absDuration(d time.Duration) time.Duration {
	if d < 0 {
		return -d
	}
	return d
}

// auditWrite is a nil-safe audit write, so a service constructed without an
// audit backend (tests) degrades to the logger instead of panicking on a
// policy decision.
func (s *AgentService) auditWrite(e AuditEntry) {
	if s.audit == nil {
		s.logger.Warn("agent.audit.unavailable",
			zap.String("action", e.Action),
			zap.String("resource_id", e.ResourceID))
		return
	}
	s.audit.Write(e)
}
