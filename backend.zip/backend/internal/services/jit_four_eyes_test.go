package services

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/glebarez/sqlite"
	"go.uber.org/zap"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"github.com/yourorg/pam/internal/config"
	"github.com/yourorg/pam/internal/models"
)

// ---------------------------------------------------------------------------
// Four-eyes (dual control) on STANDARD JIT approval
// ---------------------------------------------------------------------------
//
// The rule under test, stated once:
//
//	admin A approves        -> PARTIALLY_APPROVED, NO grant
//	admin A approves again  -> ErrDuplicateApprover (HTTP 409)
//	admin B approves        -> APPROVED, grant issued
//	root approves           -> APPROVED, grant issued, on its own
//	anyone denies           -> DENIED, immediately, never waits for a second
//
// These are the semantics the console already implements client-side in
// src/lib/fourEyes.js, so they are a contract between two repos rather than an
// internal detail — which is why each one gets its own test here.

func fourEyesDB(t *testing.T) *gorm.DB {
	t.Helper()

	// models.AuditLog names its table as PAM_DATABASE_SCHEMA + ".pam_audit_log".
	// Unset, that is a leading dot and sqlite rejects the DDL outright. "main"
	// is sqlite's own default schema, so it is both valid here and a faithful
	// stand-in for the qualified name Postgres gets in production.
	t.Setenv("PAM_DATABASE_SCHEMA", "main")

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		t.Fatalf("open in-memory sqlite: %v", err)
	}
	if err := db.AutoMigrate(
		&models.JITRequest{},
		&models.JITApproval{},
		&models.AccessGrant{},
		&models.AuditLog{},
	); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

func fourEyesService(t *testing.T, db *gorm.DB) *JITService {
	t.Helper()
	log := zap.NewNop()
	audit := NewAuditService(db, []byte("test-hmac-secret"), "test-org", log)
	return NewJITService(db, audit, nil, nil, config.JITConfig{
		DefaultDurationMin:      60,
		MaxDurationMin:          480,
		RequireSeparationOfDuty: true,
	}, log)
}

// pendingRequest seeds a STANDARD request that is ready to be decided.
func pendingRequest(t *testing.T, db *gorm.DB) *models.JITRequest {
	t.Helper()
	now := time.Now().UTC()
	req := &models.JITRequest{
		ID:                "req-4eyes-1",
		RequestType:       "STANDARD",
		RequesterUserID:   "user-requester",
		RequesterUsername: "requester",
		ResourceID:        "res-1",
		ResourceName:      "prod-db",
		ResourceType:      "postgresql",
		Action:            "pam:resource:Connect",
		DurationMinutes:   60,
		Reason:            "investigating a production incident",
		Status:            models.JITStatusPending,
		RequestedAt:       now,
		RequestExpiresAt:  now.Add(2 * time.Hour),
	}
	if err := db.Create(req).Error; err != nil {
		t.Fatalf("seed request: %v", err)
	}
	return req
}

func approveAs(s *JITService, userID, username string, roles ...string) (*models.JITRequest, *models.AccessGrant, error) {
	return s.Approve(context.Background(), DecisionInput{
		RequestID:        "req-4eyes-1",
		ApproverUserID:   userID,
		ApproverUsername: username,
		ApproverRoles:    roles,
		Reason:           "approved for the incident window",
		SourceIP:         "10.0.0.1",
	})
}

// The whole point: one admin is not enough. No grant may exist after it.
func TestFirstAdminApprovalIssuesNoGrant(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	req, grant, err := approveAs(svc, "admin-a", "alice", RoleAdmin)
	if err != nil {
		t.Fatalf("first approval: %v", err)
	}
	if grant != nil {
		t.Fatalf("a single admin approval must NOT issue a grant, got %+v", grant)
	}
	if req.Status != models.JITStatusPartiallyApproved {
		t.Fatalf("status = %q, want %q", req.Status, models.JITStatusPartiallyApproved)
	}

	// Nothing entitled: the whole reason dual control exists is that the
	// half-approved state grants nothing at all.
	var grants int64
	db.Model(&models.AccessGrant{}).Count(&grants)
	if grants != 0 {
		t.Fatalf("%d grant(s) exist after one approval; want 0", grants)
	}
}

// The same person cannot be both eyes.
func TestSameAdminApprovingTwiceIsRefused(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	if _, _, err := approveAs(svc, "admin-a", "alice", RoleAdmin); err != nil {
		t.Fatalf("first approval: %v", err)
	}

	_, grant, err := approveAs(svc, "admin-a", "alice", RoleAdmin)
	if !errors.Is(err, ErrDuplicateApprover) {
		t.Fatalf("second approval by the same admin: err = %v, want ErrDuplicateApprover", err)
	}
	if grant != nil {
		t.Fatalf("a refused approval must not issue a grant, got %+v", grant)
	}

	var approvals int64
	db.Model(&models.JITApproval{}).Count(&approvals)
	if approvals != 1 {
		t.Fatalf("%d decision rows written; the refused one must not be recorded as a second", approvals)
	}
}

// Two distinct admins are quorum.
func TestSecondDistinctAdminApprovalIssuesTheGrant(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	if _, _, err := approveAs(svc, "admin-a", "alice", RoleAdmin); err != nil {
		t.Fatalf("first approval: %v", err)
	}

	req, grant, err := approveAs(svc, "admin-b", "bob", RoleAdmin)
	if err != nil {
		t.Fatalf("second approval: %v", err)
	}
	if grant == nil {
		t.Fatal("two distinct admins are quorum — a grant must be issued")
	}
	if req.Status != models.JITStatusApproved {
		t.Fatalf("status = %q, want %q", req.Status, models.JITStatusApproved)
	}
	if req.GrantID == nil || *req.GrantID != grant.ID {
		t.Fatalf("request is not linked to the grant it authorised: %+v", req.GrantID)
	}
}

// Root is final on its own — that is the documented escape hatch, and it must
// not require a second person to be usable in an incident.
func TestRootApprovalAloneIssuesTheGrant(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	req, grant, err := approveAs(svc, "root-1", "root", RoleRoot)
	if err != nil {
		t.Fatalf("root approval: %v", err)
	}
	if grant == nil {
		t.Fatal("a root approval is final on its own — a grant must be issued")
	}
	if req.Status != models.JITStatusApproved {
		t.Fatalf("status = %q, want %q", req.Status, models.JITStatusApproved)
	}
}

// Root arriving second must settle a request an admin already half-approved,
// rather than being rejected because the request is no longer PENDING.
func TestRootCanSettleAPartiallyApprovedRequest(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	if _, _, err := approveAs(svc, "admin-a", "alice", RoleAdmin); err != nil {
		t.Fatalf("first approval: %v", err)
	}

	req, grant, err := approveAs(svc, "root-1", "root", RoleRoot)
	if err != nil {
		t.Fatalf("root approval on a partially-approved request: %v", err)
	}
	if grant == nil || req.Status != models.JITStatusApproved {
		t.Fatalf("root must settle it; status=%q grant=%v", req.Status, grant)
	}
}

// The decision trail is the evidence. Rank is recorded so an auditor can see
// WHY a lone approval was final.
func TestApprovalTrailRecordsEachDecisionWithItsRank(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	if _, _, err := approveAs(svc, "admin-a", "alice", RoleAdmin); err != nil {
		t.Fatalf("first approval: %v", err)
	}
	if _, _, err := approveAs(svc, "admin-b", "bob", RoleAdmin); err != nil {
		t.Fatalf("second approval: %v", err)
	}

	var rows []models.JITApproval
	if err := db.Where("request_id = ?", "req-4eyes-1").Order("created_at").Find(&rows).Error; err != nil {
		t.Fatalf("read trail: %v", err)
	}
	if len(rows) != 2 {
		t.Fatalf("%d decision rows, want 2", len(rows))
	}
	for _, r := range rows {
		if r.Decision != models.JITApprovalDecisionApproved {
			t.Fatalf("decision = %q, want %q", r.Decision, models.JITApprovalDecisionApproved)
		}
		if r.ApproverRank != models.JITApproverRankAdmin {
			t.Fatalf("approver %q rank = %d, want %d",
				r.ApproverUsername, r.ApproverRank, models.JITApproverRankAdmin)
		}
	}
	if rows[0].ApproverUserID == rows[1].ApproverUserID {
		t.Fatal("the two decision rows must belong to two different people")
	}
}

// Separation of duty still applies, and applies FIRST: a requester must not be
// able to put their own approval on the board even as the first of two.
func TestRequesterCannotApproveTheirOwnRequest(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	_, _, err := approveAs(svc, "user-requester", "requester", RoleAdmin)
	if !errors.Is(err, ErrSelfApproval) {
		t.Fatalf("err = %v, want ErrSelfApproval", err)
	}

	var approvals int64
	db.Model(&models.JITApproval{}).Count(&approvals)
	if approvals != 0 {
		t.Fatalf("%d decision rows written for a refused self-approval; want 0", approvals)
	}
}

// Deny is the fail-safe direction and must never wait for a second person.
func TestDenyIsFinalOnTheFirstDecision(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	req, err := svc.Deny(context.Background(), DecisionInput{
		RequestID:        "req-4eyes-1",
		ApproverUserID:   "admin-a",
		ApproverUsername: "alice",
		ApproverRoles:    []string{RoleAdmin},
		Reason:           "not justified",
	})
	if err != nil {
		t.Fatalf("deny: %v", err)
	}
	if req.Status != models.JITStatusDenied {
		t.Fatalf("status = %q, want %q — deny must never wait for a second approver",
			req.Status, models.JITStatusDenied)
	}

	var grants int64
	db.Model(&models.AccessGrant{}).Count(&grants)
	if grants != 0 {
		t.Fatalf("%d grant(s) after a denial; want 0", grants)
	}
}

// A request that has already been settled must not accept further approvals.
func TestApprovingAnAlreadyApprovedRequestIsRefused(t *testing.T) {
	db := fourEyesDB(t)
	svc := fourEyesService(t, db)
	pendingRequest(t, db)

	if _, _, err := approveAs(svc, "root-1", "root", RoleRoot); err != nil {
		t.Fatalf("root approval: %v", err)
	}

	_, _, err := approveAs(svc, "admin-b", "bob", RoleAdmin)
	if !errors.Is(err, ErrInvalidState) {
		t.Fatalf("err = %v, want ErrInvalidState", err)
	}
}
