// pam/internal/services/policy_engine_service.go
//
// The Policy Enforcement Point's data-resolution layer: given a user ID,
// figure out which roles they hold and which policies apply to them (via
// those roles, plus any policy attached directly to them), then hand that
// resolved input to the embedded OPA-style engine (opa/engine.go) for the
// actual allow/deny decision.
//
// This is the direct replacement for pkg/iamclient.Client's CheckAuthzCtx:
// same job (PEP asks PDP "can this user do this action on this resource?"),
// same fail-closed posture, but resolved entirely in-process against PAM's
// own database — no network call, no other service, ever.
package services

import (
	"context"
	"fmt"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/opa"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

// AuthzResult mirrors the old iamclient.AuthzResponse.Data shape closely so
// the calling middleware's logging/audit fields didn't need to change names.
type AuthzResult struct {
	Allowed       bool
	Reason        string
	MatchedPolicy string
	DecisionID    string
}

type PolicyEngineService struct {
	db     *gorm.DB
	engine *opa.Engine
	logger *zap.Logger
}

func NewPolicyEngineService(db *gorm.DB, logger *zap.Logger) *PolicyEngineService {
	return &PolicyEngineService{db: db, engine: opa.New(), logger: logger}
}

// RoleNamesForUser returns the names of every role a user holds. Used by
// AuthService at login/MFA-verify time to embed roles into the issued JWT
// (so most requests never need a DB round trip just to know "is this an
// admin" — middleware.RequireAdmin reads the JWT's roles claim directly).
func (s *PolicyEngineService) RoleNamesForUser(userID string) ([]string, error) {
	var roles []models.Role
	err := s.db.
		Joins("JOIN pam_user_roles ON pam_user_roles.role_id = pam_roles.id").
		Where("pam_user_roles.user_id = ?", userID).
		Find(&roles).Error
	if err != nil {
		return nil, fmt.Errorf("resolve role names: %w", err)
	}
	names := make([]string, 0, len(roles))
	for _, r := range roles {
		names = append(names, r.Name)
	}
	return names, nil
}

// ResolveEffectivePolicies returns the union of every policy that applies to
// a user: policies attached to any role they hold, plus policies attached
// directly to them. Deduplicated by policy ID (a user could conceivably
// reach the same policy through two different roles).
func (s *PolicyEngineService) ResolveEffectivePolicies(userID string) ([]models.Policy, error) {
	seen := make(map[string]bool)
	var result []models.Policy

	var viaRoles []models.Policy
	if err := s.db.
		Joins("JOIN pam_role_policies ON pam_role_policies.policy_id = pam_policies.id").
		Joins("JOIN pam_user_roles ON pam_user_roles.role_id = pam_role_policies.role_id").
		Where("pam_user_roles.user_id = ?", userID).
		Find(&viaRoles).Error; err != nil {
		return nil, fmt.Errorf("resolve role policies: %w", err)
	}
	for _, p := range viaRoles {
		if !seen[p.ID] {
			seen[p.ID] = true
			result = append(result, p)
		}
	}

	var direct []models.Policy
	if err := s.db.
		Joins("JOIN pam_user_policies ON pam_user_policies.policy_id = pam_policies.id").
		Where("pam_user_policies.user_id = ?", userID).
		Find(&direct).Error; err != nil {
		return nil, fmt.Errorf("resolve direct policies: %w", err)
	}
	for _, p := range direct {
		if !seen[p.ID] {
			seen[p.ID] = true
			result = append(result, p)
		}
	}

	return result, nil
}

// IsAdminOrRoot reports whether the given role names grant Admin Center
// access. A small, pure helper (no DB call) so both the JWT-claims fast
// path (middleware.RequireAdmin) and any DB-resolved path can share one
// definition of "what counts as admin."
func IsAdminOrRoot(roleNames []string) bool {
	for _, r := range roleNames {
		if r == "root" || r == "admin" {
			return true
		}
	}
	return false
}

// IsRoot reports whether the given role names include the root bypass role.
func IsRoot(roleNames []string) bool {
	for _, r := range roleNames {
		if r == "root" {
			return true
		}
	}
	return false
}

// AuthzContext is a user's resolved roles/policies, snapshotted once so a
// caller checking many (action, resource) pairs for the same user — e.g.
// filtering a resource list down to only what this user is actually
// authorized to see — pays one DB round trip total instead of one per item.
// Safe to reuse across many Allowed() calls; holds no live DB handle.
type AuthzContext struct {
	root     bool
	policies []opa.PolicyDoc
	engine   *opa.Engine
}

// ResolveAuthzContext resolves userID's effective roles/policies once. See
// AuthzContext's doc comment for why this exists alongside Authorize rather
// than callers just calling Authorize in a loop.
func (s *PolicyEngineService) ResolveAuthzContext(userID string) (*AuthzContext, error) {
	roleNames, err := s.RoleNamesForUser(userID)
	if err != nil {
		return nil, fmt.Errorf("resolve role names: %w", err)
	}
	root := IsRoot(roleNames)

	var policyDocs []opa.PolicyDoc
	if !root {
		policies, err := s.ResolveEffectivePolicies(userID)
		if err != nil {
			return nil, fmt.Errorf("resolve effective policies: %w", err)
		}
		policyDocs = make([]opa.PolicyDoc, 0, len(policies))
		for _, p := range policies {
			policyDocs = append(policyDocs, opa.PolicyDoc{
				Name:      p.Name,
				Effect:    opa.Effect(p.Effect),
				Actions:   p.Actions,
				Resources: p.Resources,
			})
		}
	}
	return &AuthzContext{root: root, policies: policyDocs, engine: s.engine}, nil
}

// Allowed evaluates one (action, resource) pair against the snapshotted
// policy set — no DB access, safe to call in a tight loop.
func (a *AuthzContext) Allowed(action, resource string) bool {
	return a.engine.Evaluate(opa.Input{
		IsRoot:   a.root,
		Action:   action,
		Resource: resource,
		Policies: a.policies,
	}).Allowed
}

// Authorize is the full PDP call: resolve roles + policies for userID, then
// evaluate. Fail-closed: any resolution error is logged and denied, exactly
// as the old IAM client's "unreachable => deny" posture, just without a
// network hop that can actually BE unreachable anymore.
func (s *PolicyEngineService) Authorize(ctx context.Context, userID, action, resource string) AuthzResult {
	if userID == "" || action == "" {
		return AuthzResult{Allowed: false, Reason: "invalid_authz_request"}
	}

	roleNames, err := s.RoleNamesForUser(userID)
	if err != nil {
		s.logger.Error("policy_engine.resolve_roles.fail", zap.String("user_id", userID), zap.Error(err))
		return AuthzResult{Allowed: false, Reason: "policy_resolution_error"}
	}

	root := IsRoot(roleNames)

	var policyDocs []opa.PolicyDoc
	if !root {
		policies, err := s.ResolveEffectivePolicies(userID)
		if err != nil {
			s.logger.Error("policy_engine.resolve_policies.fail", zap.String("user_id", userID), zap.Error(err))
			return AuthzResult{Allowed: false, Reason: "policy_resolution_error"}
		}
		policyDocs = make([]opa.PolicyDoc, 0, len(policies))
		for _, p := range policies {
			policyDocs = append(policyDocs, opa.PolicyDoc{
				Name:      p.Name,
				Effect:    opa.Effect(p.Effect),
				Actions:   p.Actions,
				Resources: p.Resources,
			})
		}
	}

	decision := s.engine.Evaluate(opa.Input{
		UserID:   userID,
		IsRoot:   root,
		Action:   action,
		Resource: resource,
		Policies: policyDocs,
	})

	if decision.Allowed {
		s.logger.Info("policy_engine.allowed",
			zap.String("user_id", userID), zap.String("action", action),
			zap.String("resource", resource), zap.String("matched_policy", decision.MatchedPolicy),
			zap.String("decision_id", decision.DecisionID))
	} else {
		s.logger.Warn("policy_engine.denied",
			zap.String("user_id", userID), zap.String("action", action),
			zap.String("resource", resource), zap.String("reason", decision.Reason),
			zap.String("decision_id", decision.DecisionID))
	}

	return AuthzResult{
		Allowed:       decision.Allowed,
		Reason:        decision.Reason,
		MatchedPolicy: decision.MatchedPolicy,
		DecisionID:    decision.DecisionID,
	}
}
