package services

import (
	"testing"
	"time"

	"github.com/glebarez/sqlite"
	"go.uber.org/zap"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/argon2"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
)

// ---------------------------------------------------------------------------
// Role-gated MFA policy — ENFORCEMENT at login
// ---------------------------------------------------------------------------
//
// These exist because the feature shipped once without them and the gap was
// invisible: the rules stored, the console rendered them, the compliance
// screen counted them, and login never asked. A user in a gated role who had
// never enrolled simply logged in.
//
// The thing under test is therefore not "does Evaluate compute the right
// answer" (mfa_policy_test.go covers that) but "does LOGIN act on it".

type fixedRoles struct{ roles []string }

func (f fixedRoles) RoleNamesForUser(string) ([]string, error) { return f.roles, nil }

func enforcementDB(t *testing.T) *gorm.DB {
	t.Helper()
	t.Setenv("PAM_DATABASE_SCHEMA", "main")
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&models.User{}, &models.PAMMFA{}, &MFAPolicyRule{}); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

// seedUser creates an account with a known password and, optionally, an
// ACTIVE second factor.
func seedUser(t *testing.T, db *gorm.DB, userID, username string, enrolled bool) {
	t.Helper()
	hash, err := argon2.Hash("correct-horse-battery-staple")
	if err != nil {
		t.Fatalf("hash: %v", err)
	}
	if err := db.Create(&models.User{
		UserID: userID, Username: username, Email: username + "@example.com",
		PasswordHash: &hash, Status: "ACTIVE",
	}).Error; err != nil {
		t.Fatalf("seed user: %v", err)
	}
	if enrolled {
		if err := db.Create(&models.PAMMFA{
			UserID: userID, Status: "ACTIVE", SecretEncrypted: "encrypted-placeholder",
		}).Error; err != nil {
			t.Fatalf("seed mfa: %v", err)
		}
	}
}

func enforcementAuth(t *testing.T, db *gorm.DB, roles []string, withPolicy bool) *AuthService {
	t.Helper()
	log := zap.NewNop()
	issuer := pamjwt.New("test-secret-key-at-least-32-bytes-long!!", "pam-test", 30, 7)
	auth := NewAuthService(db, issuer, fixedRoles{roles: roles}, "0123456789abcdef0123456789abcdef", 5, 15, log)
	if withPolicy {
		auth.SetMFAPolicy(NewMFAPolicyService(db, fixedRoles{roles: roles}, log))
	}
	return auth
}

// gateRole turns the policy on for one role.
func gateRole(t *testing.T, db *gorm.DB, role, mode string) {
	t.Helper()
	if err := db.Create(&MFAPolicyRule{
		RoleName: role, Mode: mode, UpdatedBy: "test", UpdatedAt: time.Now().UTC(),
	}).Error; err != nil {
		t.Fatalf("seed rule: %v", err)
	}
}

// THE REGRESSION. A gated role, no enrolment: login must NOT hand back an
// ordinary session.
func TestGatedRoleWithoutMFAGetsAnEnrolmentOnlySession(t *testing.T) {
	db := enforcementDB(t)
	seedUser(t, db, "u-admin", "alice", false)
	gateRole(t, db, "admin", MFAModeEnforce)

	auth := enforcementAuth(t, db, []string{"admin"}, true)
	res, err := auth.Login("alice", "correct-horse-battery-staple", "10.0.0.1")
	if err != nil {
		t.Fatalf("login: %v", err)
	}
	if !res.MFAEnrolmentRequired {
		t.Fatal("policy gates this role and the account has no second factor — " +
			"the session must be marked enrolment-only")
	}
	if res.AccessToken == "" {
		t.Fatal("a token must still be issued: the enrolment endpoints are " +
			"authenticated, so refusing outright is a lockout, not a control")
	}

	// The restriction has to be on the TOKEN, or a caller ignoring the console
	// is unrestricted.
	issuer := pamjwt.New("test-secret-key-at-least-32-bytes-long!!", "pam-test", 30, 7)
	claims, _, err := issuer.Verify(res.AccessToken)
	if err != nil {
		t.Fatalf("verify token: %v", err)
	}
	if !claims.MFAEnrolmentRequired {
		t.Fatal("mfa_enrolment_required is not on the token — middleware has nothing to enforce")
	}
	if claims.MFAVerified {
		t.Fatal("an unenrolled account must never carry mfa_verified=true")
	}
}

// The same account, once the gate is off, logs in normally. Guards against a
// fix that simply blocks everyone.
func TestUngatedRoleWithoutMFALogsInNormally(t *testing.T) {
	db := enforcementDB(t)
	seedUser(t, db, "u-plain", "bob", false)
	// no rule seeded

	auth := enforcementAuth(t, db, []string{"user"}, true)
	res, err := auth.Login("bob", "correct-horse-battery-staple", "10.0.0.1")
	if err != nil {
		t.Fatalf("login: %v", err)
	}
	if res.MFAEnrolmentRequired {
		t.Fatal("no rule gates this role — the session must not be restricted")
	}
	if res.AccessToken == "" {
		t.Fatal("expected an ordinary session")
	}
}

// Monitor mode reports without blocking. It exists so an estate can measure
// the blast radius before switching to enforce.
func TestMonitorModeDoesNotRestrictTheSession(t *testing.T) {
	db := enforcementDB(t)
	seedUser(t, db, "u-mon", "carol", false)
	gateRole(t, db, "admin", MFAModeMonitor)

	auth := enforcementAuth(t, db, []string{"admin"}, true)
	res, err := auth.Login("carol", "correct-horse-battery-staple", "10.0.0.1")
	if err != nil {
		t.Fatalf("login: %v", err)
	}
	if res.MFAEnrolmentRequired {
		t.Fatal("monitor mode must observe, not block")
	}
}

// An account that DOES hold a factor still gets the ordinary challenge, gated
// role or not — the policy decides who must enrol, not how they authenticate.
func TestEnrolledUserStillGetsTheMFAChallenge(t *testing.T) {
	db := enforcementDB(t)
	seedUser(t, db, "u-enrolled", "dave", true)
	gateRole(t, db, "admin", MFAModeEnforce)

	auth := enforcementAuth(t, db, []string{"admin"}, true)
	res, err := auth.Login("dave", "correct-horse-battery-staple", "10.0.0.1")
	if err != ErrMFARequired {
		t.Fatalf("err = %v, want ErrMFARequired", err)
	}
	if res == nil || !res.MFARequired || res.ChallengeToken == "" {
		t.Fatalf("expected an MFA challenge, got %+v", res)
	}
	if res.MFAEnrolmentRequired {
		t.Fatal("this account is enrolled — it must not be sent to enrolment")
	}
}

// With no policy service wired, behaviour is exactly what it was before the
// feature existed. This is what lets the rest of the suite construct
// AuthService without knowing about MFA policy at all.
func TestNoPolicyServiceLeavesLoginUnchanged(t *testing.T) {
	db := enforcementDB(t)
	seedUser(t, db, "u-nopolicy", "erin", false)
	gateRole(t, db, "admin", MFAModeEnforce) // rule exists but nothing consults it

	auth := enforcementAuth(t, db, []string{"admin"}, false)
	res, err := auth.Login("erin", "correct-horse-battery-staple", "10.0.0.1")
	if err != nil {
		t.Fatalf("login: %v", err)
	}
	if res.MFAEnrolmentRequired {
		t.Fatal("no policy service is wired — nothing should be enforced")
	}
}
