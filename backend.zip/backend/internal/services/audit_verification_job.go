// pam/internal/services/audit_verification_job.go
//
// Background job: walks the audit hash chain on a schedule and pages
// the on-call if any row fails verification. Production deployment runs
// this as a Kubernetes CronJob, or via a goroutine started in main.go
// with a graceful-shutdown hook.

package services

import (
	"context"
	"sync"
	"time"

	"go.uber.org/zap"
)

// AuditVerificationJob runs VerifyChain on a ticker. It is safe to Stop()
// from a signal handler; the goroutine will exit before the next tick.
type AuditVerificationJob struct {
	audit    *AuditService
	interval time.Duration
	logger   *zap.Logger

	mu      sync.Mutex
	running bool
	stopCh  chan struct{}
	doneCh  chan struct{}
}

func NewAuditVerificationJob(audit *AuditService, interval time.Duration, logger *zap.Logger) *AuditVerificationJob {
	if interval <= 0 {
		interval = 24 * time.Hour
	}
	return &AuditVerificationJob{
		audit:    audit,
		interval: interval,
		logger:   logger,
		stopCh:   make(chan struct{}),
		doneCh:   make(chan struct{}),
	}
}

// Start launches the goroutine. Calling Start twice is a no-op.
func (j *AuditVerificationJob) Start() {
	j.mu.Lock()
	defer j.mu.Unlock()
	if j.running {
		return
	}
	j.running = true
	go j.loop()
}

// Stop signals the goroutine to exit and waits for it.
func (j *AuditVerificationJob) Stop() {
	j.mu.Lock()
	if !j.running {
		j.mu.Unlock()
		return
	}
	j.running = false
	close(j.stopCh)
	j.mu.Unlock()
	<-j.doneCh
}

func (j *AuditVerificationJob) loop() {
	defer close(j.doneCh)
	t := time.NewTicker(j.interval)
	defer t.Stop()
	// Run once at startup so we don't have to wait `interval` for the first check.
	j.runOnce()
	for {
		select {
		case <-j.stopCh:
			return
		case <-t.C:
			j.runOnce()
		}
	}
}

func (j *AuditVerificationJob) runOnce() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	res, err := j.audit.VerifyChain(ctx, "default")
	if err != nil {
		j.logger.Error("audit.verify.job.error", zap.Error(err))
		return
	}
	if !res.Valid {
		// CRITICAL — page the on-call. The chain is broken.
		j.logger.Error("audit.chain.TAMPERED",
			zap.String("org_id", res.OrgID),
			zap.Int("total_rows", res.TotalRows),
			zap.Int64("first_bad_seq", res.FirstBadSeq),
			zap.String("reason", res.Reason),
		)
		return
	}
	j.logger.Info("audit.chain.ok",
		zap.String("org_id", res.OrgID),
		zap.Int("total_rows", res.TotalRows),
	)
}
