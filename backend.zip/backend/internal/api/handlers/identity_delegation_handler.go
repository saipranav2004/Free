// pam/internal/api/handlers/identity_delegation_handler.go
//
// Admin delegation APIs — additive extension to IdentityHandler.
//
// Only ROOT may grant or revoke delegated admin access.
// Admins cannot mint further admins (enforced in the service layer).
//
// Wire in main.go alongside existing identity routes (same RequireAdmin group):
//
//	ident.POST  ("/users/:id/delegate-admin", identityHandler.DelegateAdmin)
//	ident.DELETE("/users/:id/delegate-admin", identityHandler.RevokeAdminDelegation)
//	ident.GET   ("/users/:id/delegation",     identityHandler.GetDelegation)
package handlers

import (
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// ---------------------------------------------------------------------------
// Request bodies
// ---------------------------------------------------------------------------

type delegateAdminRequest struct {
	// Reason is mandatory for audit — every privilege grant needs justification.
	Reason string `json:"reason" binding:"required"`

	// ScopeResourceIDs optionally limits the delegated admin to specific PAM resources.
	// Empty/omitted = full operational admin with the role default resource set.
	ScopeResourceIDs []string `json:"scope_resource_ids"`

	// ExpiresAt is optional RFC3339. Null/omitted = until root revokes.
	ExpiresAt *time.Time `json:"expires_at"`
}

type revokeDelegationRequest struct {
	Reason string `json:"reason" binding:"required"`
}

// ---------------------------------------------------------------------------
// POST /api/v1/pam/admin/identity/users/:id/delegate-admin
// ---------------------------------------------------------------------------

// DelegateAdmin grants the target user the admin role (delegated by root).
// Root only — service returns ErrDelegationForbidden for non-root actors.
func (h *IdentityHandler) DelegateAdmin(c *gin.Context) {
	var req delegateAdminRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request: "+err.Error())
		return
	}

	reason := strings.TrimSpace(req.Reason)
	if reason == "" {
		response.Error(c, http.StatusBadRequest, "reason is required for admin delegation")
		return
	}
	if req.ExpiresAt != nil && !req.ExpiresAt.After(time.Now().UTC()) {
		response.Error(c, http.StatusBadRequest, "expires_at must be in the future")
		return
	}

	actorID, _ := middleware.AdminIdentityFromContext(c)
	result, err := h.identity.DelegateAdmin(services.DelegateAdminInput{
		TargetUserID:     c.Param("id"),
		ActorID:          actorID,
		Reason:           reason,
		ScopeResourceIDs: sanitizeDelegationIDs(req.ScopeResourceIDs),
		ExpiresAt:        req.ExpiresAt,
	})
	if err != nil {
		h.respondDelegationErr(c, err, "identity.delegate_admin.fail")
		return
	}

	response.Success(c, gin.H{
		"user_id":            result.UserID,
		"delegated_role":     result.DelegatedRole,
		"delegated_by":       result.DelegatedBy,
		"reason":             result.Reason,
		"scope_resource_ids": result.ScopeResourceIDs,
		"expires_at":         result.ExpiresAt,
		"delegated_at":       result.DelegatedAt,
	}, "Admin delegated")
}

// ---------------------------------------------------------------------------
// DELETE /api/v1/pam/admin/identity/users/:id/delegate-admin
// ---------------------------------------------------------------------------

// RevokeAdminDelegation removes the admin role granted via delegation.
// Root only. Leaves the baseline user role intact.
func (h *IdentityHandler) RevokeAdminDelegation(c *gin.Context) {
	var req revokeDelegationRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request: "+err.Error())
		return
	}
	reason := strings.TrimSpace(req.Reason)
	if reason == "" {
		response.Error(c, http.StatusBadRequest, "reason is required to revoke admin delegation")
		return
	}

	actorID, _ := middleware.AdminIdentityFromContext(c)
	if err := h.identity.RevokeAdminDelegation(services.RevokeDelegationInput{
		TargetUserID: c.Param("id"),
		ActorID:      actorID,
		Reason:       reason,
	}); err != nil {
		h.respondDelegationErr(c, err, "identity.revoke_delegation.fail")
		return
	}

	response.Success(c, gin.H{
		"user_id": c.Param("id"),
		"revoked": "admin",
	}, "Admin delegation revoked")
}

// ---------------------------------------------------------------------------
// GET /api/v1/pam/admin/identity/users/:id/delegation
// ---------------------------------------------------------------------------

// GetDelegation returns the current admin-delegation record for a user
// (active / expired / revoked / none). Readable by any admin; grant/revoke
// remain root-only in the service.
func (h *IdentityHandler) GetDelegation(c *gin.Context) {
	rec, err := h.identity.GetAdminDelegation(c.Param("id"))
	if err != nil {
		if errors.Is(err, services.ErrUserNotFound) {
			response.Error(c, http.StatusNotFound, "User not found")
			return
		}
		h.logger.Error("identity.get_delegation.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch delegation")
		return
	}
	response.Success(c, gin.H{"delegation": rec}, "Delegation fetched")
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

func (h *IdentityHandler) respondDelegationErr(c *gin.Context, err error, logKey string) {
	switch {
	case errors.Is(err, services.ErrUserNotFound):
		response.Error(c, http.StatusNotFound, "User not found")
	case errors.Is(err, services.ErrUserProtected):
		response.Error(c, http.StatusForbidden, err.Error())
	case errors.Is(err, services.ErrDelegationForbidden):
		// Not root, or admin trying to mint another admin, etc.
		response.Error(c, http.StatusForbidden, err.Error())
	case errors.Is(err, services.ErrDelegationConflict):
		response.Error(c, http.StatusConflict, err.Error())
	case errors.Is(err, services.ErrDelegationNotFound):
		response.Error(c, http.StatusNotFound, err.Error())
	case errors.Is(err, services.ErrInvalidScope):
		response.Error(c, http.StatusBadRequest, err.Error())
	case errors.Is(err, services.ErrRoleNotFound):
		response.Error(c, http.StatusInternalServerError, "admin role is not provisioned")
	default:
		h.logger.Error(logKey, zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to process admin delegation")
	}
}

func sanitizeDelegationIDs(ids []string) []string {
	if len(ids) == 0 {
		return nil
	}
	out := make([]string, 0, len(ids))
	seen := make(map[string]struct{}, len(ids))
	for _, id := range ids {
		id = strings.TrimSpace(id)
		if id == "" {
			continue
		}
		if _, ok := seen[id]; ok {
			continue
		}
		seen[id] = struct{}{}
		out = append(out, id)
	}
	return out
}
