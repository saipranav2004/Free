// pam/internal/api/handlers/session_handler.go
//
// Tracked connection sessions.
//
// Start binds the session to the JIT grant that authorised it (when the
// resource is JIT-gated), which is what allows the auto-revoke sweeper to find
// and kill live sessions when the grant expires or is revoked.
package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type SessionHandler struct {
	res    *services.ResourceService
	audit  *services.AuditService
	logger *zap.Logger
}

func NewSessionHandler(res *services.ResourceService, audit *services.AuditService, logger *zap.Logger) *SessionHandler {
	return &SessionHandler{res: res, audit: audit, logger: logger}
}

type startSessionRequest struct {
	// ResourceID is optional in the body: the canonical source is the :id path
	// parameter, which the RequireActiveGrant middleware also reads. Keeping the
	// resource id out of the body is what lets the PEP evaluate the grant
	// without consuming the request body before the handler binds it.
	ResourceID string `json:"resource_id"`
	Protocol   string `json:"protocol"`
}

// Start handles POST /api/v1/pam/resources/:id/sessions
//
// Route chain: PAMAuth → RequirePermission (IAM/OPA) → RequireActiveGrant (JIT)
// → this handler. By the time we get here both policy layers have passed.
func (h *SessionHandler) Start(c *gin.Context) {
	var req startSessionRequest
	// Body is optional — bind errors on an empty body are not fatal.
	_ = c.ShouldBindJSON(&req)

	if id := c.Param("id"); id != "" {
		req.ResourceID = id
	}
	if req.ResourceID == "" {
		response.Error(c, http.StatusBadRequest, "resource id is required")
		return
	}

	userID, _ := c.Get("user_id")
	username, _ := c.Get("username")
	decisionID, _ := c.Get("authz_decision_id")
	uid, _ := userID.(string)
	uname, _ := username.(string)
	did, _ := decisionID.(string)

	grantCtx := middleware.GrantFromContext(c)

	session, recording, err := h.res.StartTrackedSession(services.StartSessionInput{
		UserID:            uid,
		Username:          uname,
		ResourceID:        req.ResourceID,
		SourceIP:          c.ClientIP(),
		Protocol:          req.Protocol,
		AuthzDecisionID:   did,
		GrantID:           grantCtx.GrantID,
		JITRequestID:      grantCtx.JITRequestID,
		IsBreakglass:      grantCtx.IsBreakglass,
		RecordingRequired: grantCtx.RecordingRequired,
	})
	if err != nil {
		switch {
		case errors.Is(err, services.ErrResourceNotFound):
			response.Error(c, http.StatusNotFound, "Resource not found")
		case errors.Is(err, services.ErrResourceInactive):
			response.Error(c, http.StatusUnprocessableEntity, "Resource is not active")
		default:
			h.logger.Error("session.start.fail", zap.Error(err))
			response.Error(c, http.StatusInternalServerError, "Failed to start session")
		}
		return
	}

	severity := models.AuditSeverityInfo
	if grantCtx.IsBreakglass {
		severity = models.AuditSeverityCritical
	}
	h.audit.Write(services.AuditEntry{
		ActorUserID:     uid,
		ActorUsername:   uname,
		Action:          models.AuditSessionStarted,
		Severity:        severity,
		ResourceType:    session.ResourceType,
		ResourceID:      session.ResourceID,
		ResourceName:    session.ResourceName,
		SessionID:       session.ID,
		GrantID:         grantCtx.GrantID,
		RequestID:       grantCtx.JITRequestID,
		SourceIP:        c.ClientIP(),
		UserAgent:       c.Request.UserAgent(),
		AuthzDecisionID: did,
		Details: map[string]interface{}{
			"protocol":           session.Protocol,
			"grant_required":     grantCtx.Required,
			"is_breakglass":      session.IsBreakglass,
			"recording_required": session.RecordingRequired,
		},
	})

	payload := gin.H{"session": session}
	if recording != nil {
		payload["recording"] = recording
		payload["notice"] = "This session is recorded."
	}
	response.Created(c, payload, "Session started")
}

// End handles POST /api/v1/pam/sessions/:id/end
// Idempotent: ending an already-closed session returns 200.
func (h *SessionHandler) End(c *gin.Context) {
	sessionID := c.Param("id")

	userID, _ := c.Get("user_id")
	username, _ := c.Get("username")
	uid, _ := userID.(string)
	uname, _ := username.(string)

	// This route is only ever mounted under the self-service group (see
	// main.go — /sessions/:id/end is not reachable from the Admin Center,
	// which has its own KillSession action instead), so allowAny is always
	// false here: a user may only end their OWN tracked session. Checking
	// the role anyway (rather than hardcoding false) costs nothing and
	// keeps this handler correct if it's ever also mounted for admins.
	rolesRaw, _ := c.Get("roles")
	roles, _ := rolesRaw.([]string)
	allowAny := services.IsAdminOrRoot(roles)

	session, err := h.res.EndTrackedSession(sessionID, uid, allowAny)
	if err != nil {
		switch {
		case errors.Is(err, services.ErrSessionNotFound):
			response.Error(c, http.StatusNotFound, "Session not found")
		case errors.Is(err, services.ErrSessionNotOwned):
			response.Error(c, http.StatusForbidden, "This session belongs to another user")
		default:
			h.logger.Error("session.end.fail", zap.Error(err))
			response.Error(c, http.StatusInternalServerError, "Failed to end session")
		}
		return
	}

	grantID := ""
	if session.GrantID != nil {
		grantID = *session.GrantID
	}
	h.audit.Write(services.AuditEntry{
		ActorUserID:   uid,
		ActorUsername: uname,
		Action:        models.AuditSessionEnded,
		ResourceType:  session.ResourceType,
		ResourceID:    session.ResourceID,
		ResourceName:  session.ResourceName,
		SessionID:     session.ID,
		GrantID:       grantID,
		SourceIP:      c.ClientIP(),
		Details: map[string]interface{}{
			"status":           session.Status,
			"duration_seconds": session.DurationSeconds,
		},
	})

	response.Success(c, gin.H{"session": session}, "Session ended")
}

// Mine handles GET /api/v1/pam/sessions/mine — the caller's own sessions.
func (h *SessionHandler) Mine(c *gin.Context) {
	userID, _ := c.Get("user_id")
	uid, _ := userID.(string)

	page, size := pagingFrom(c)
	rows, total, err := h.res.ListSessions(services.SessionFilter{
		UserID:     uid,
		Status:     strings.ToUpper(c.Query("status")),
		ActiveOnly: c.Query("active") == "true",
		Page:       page,
		PageSize:   size,
	})
	if err != nil {
		h.logger.Error("session.mine.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch sessions")
		return
	}
	response.Success(c, paged(rows, total, page, size, "sessions"), "Sessions fetched")
}
