package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services/graph"
)

// GET /api/v1/pam/admin/identity/users/:id/graph
func (h *PrivPathHandler) MemberGraph(c *gin.Context) {
	userID := strings.TrimSpace(c.Param("id"))
	if userID == "" {
		response.Error(c, http.StatusBadRequest, "user id is required")
		return
	}

	g, err := h.svc.MemberGraph(c.Request.Context(), userID)
	if err != nil {
		if errors.Is(err, graph.ErrUserNotFound) {
			response.Error(c, http.StatusNotFound, "User not found")
			return
		}
		h.fail(c, err, "Failed to build user identity graph")
		return
	}

	response.Success(c, gin.H{"graph": g}, "User identity graph")
}