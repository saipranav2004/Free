// pam/internal/api/handlers/agent_install_handler.go
//
// One-click agent enrolment.
//
// THE PROBLEM. Enrolling the native agent used to be six manual steps: find
// the download, unpack it, put it on PATH, run `pam-agent pair`, read an
// 8-character code off the console, and type it before it expired. The two in
// the middle are the ones every operator gets wrong, and the last one is a
// race against a five-minute timer.
//
// WHAT THIS REDUCES IT TO. The console asks for an installer for a platform;
// the server mints a one-time pairing code and renders a script that already
// knows the download URL, the expected checksum, and the code. The operator
// pastes one line — or double-clicks one file — and the script downloads,
// verifies, registers the pam-agent:// handler, and pairs. Two steps, and only
// one of them is a decision.
//
// WHAT IT CANNOT DO, stated because the request is usually "make it fully
// automatic". A web page cannot execute an installer on the operator's
// machine: that is the browser sandbox, and it is the same boundary that makes
// loading a PAM console safe at all. One human action is the floor. Every
// vendor that advertises one-click enrolment — Tailscale, Teleport, Datadog —
// is describing exactly this shape.
//
// WHY THE SCRIPT AND BINARY URLS ARE UNAUTHENTICATED. `curl … | sh` cannot
// carry a Bearer token, so the pairing code in the URL is the credential. That
// is a deliberate, bounded exposure: the code is single-use, expires in
// minutes, is scoped to one user, and grants exactly one capability —
// enrolling a device that the console then lists and can revoke. It does land
// in shell history and possibly a proxy log, which is the same property
// Tailscale's --authkey and Teleport's join tokens have, and the reason the
// TTL is short rather than convenient.
package handlers

import (
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/agentdist"
	"github.com/yourorg/pam/internal/response"
	"go.uber.org/zap"
)

// AgentInstallHandler serves platform discovery, installer generation, and the
// two unauthenticated fetches an installer performs.
type AgentInstallHandler struct {
	agent    *AgentHandler
	store    *agentdist.Store
	enrolTTL time.Duration
	logger   *zap.Logger
}

func NewAgentInstallHandler(agent *AgentHandler, store *agentdist.Store,
	enrolTTLMinutes int, logger *zap.Logger) *AgentInstallHandler {
	ttl := time.Duration(enrolTTLMinutes) * time.Minute
	if ttl <= 0 {
		ttl = 15 * time.Minute
	}
	return &AgentInstallHandler{agent: agent, store: store, enrolTTL: ttl, logger: logger}
}

// Targets handles GET /api/v1/pam/agent/install/targets
//
// Returns only platforms that actually have a binary on disk, so the console
// can render buttons that are all guaranteed to work. An empty list is a
// legitimate answer — it means agent.binary_dir is unset or empty — and the
// console shows the manual instructions instead of a dead button.
func (h *AgentInstallHandler) Targets(c *gin.Context) {
	targets := h.store.Targets()
	response.Success(c, gin.H{
		"enabled": len(targets) > 0,
		"targets": targets,
	}, "Agent install targets fetched")
}

type bootstrapRequest struct {
	OS   string `json:"os"`
	Arch string `json:"arch"`
}

// Bootstrap handles POST /api/v1/pam/agent/install/bootstrap
//
// MFA-gated for the same reason PairInit is: this mints a credential that
// enrols a new device against the caller's account, which is precisely the
// action an attacker with a stolen session would want.
func (h *AgentInstallHandler) Bootstrap(c *gin.Context) {
	userID, _ := c.Get("user_id")
	uid := toString(userID)
	if uid == "" {
		response.Error(c, http.StatusUnauthorized, "Not authenticated")
		return
	}

	var req bootstrapRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Specify the os and arch to build an installer for")
		return
	}

	target, ok := h.store.Lookup(req.OS, req.Arch)
	if !ok {
		response.Error(c, http.StatusNotFound,
			fmt.Sprintf("No agent build is available for %s/%s on this server", req.OS, req.Arch))
		return
	}

	code, expiresAt, err := h.agent.svc.InitPairing(uid, h.enrolTTL)
	if err != nil {
		h.logger.Error("agent.install.bootstrap.code_fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Could not generate an enrolment code")
		return
	}

	serverURL := h.agent.resolveServerURL(c)
	boot := agentdist.Bootstrap{
		ServerURL:   serverURL,
		PairingCode: code,
		BinaryURL:   binaryURL(serverURL, target.OS, target.Arch, code),
		SHA256:      target.SHA256,
		ExpiresAt:   agentdist.FormatExpiry(expiresAt),
		Target:      target,
	}.WithScriptURL(scriptURL(serverURL, target.OS, target.Arch, code))

	script, err := agentdist.Render(boot)
	if err != nil {
		h.logger.Error("agent.install.bootstrap.render_fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Could not generate the installer")
		return
	}

	h.logger.Info("agent.install.bootstrap.issued",
		zap.String("user_id", uid),
		zap.String("os", target.OS), zap.String("arch", target.Arch),
		zap.Time("expires_at", expiresAt))

	response.Success(c, gin.H{
		"target":      target,
		"command":     script.Command,
		"script_url":  boot.ScriptURL(),
		"filename":    script.Filename,
		"expires_at":  expiresAt,
		"ttl_seconds": int(time.Until(expiresAt).Seconds()),
		// The rendered body, so the console can offer a download without a
		// second round trip — and without the browser having to fetch an
		// unauthenticated URL just to save a file.
		"script": script.Body,
	}, "Installer generated")
}

// Script handles GET /api/v1/pam/agent/install/script
//
// Unauthenticated by necessity (see the file header): the pairing code in the
// query string is the credential. Validated without being consumed, so a
// retry — or the console fetching it to preview — does not burn the operator's
// one chance to pair.
func (h *AgentInstallHandler) Script(c *gin.Context) {
	code := strings.TrimSpace(c.Query("t"))
	goos := strings.ToLower(strings.TrimSpace(c.Query("os")))
	arch := strings.ToLower(strings.TrimSpace(c.Query("arch")))

	_, expiresAt, err := h.agent.svc.ValidatePairingCode(code)
	if err != nil {
		// Deliberately terse and identical for "wrong", "expired" and
		// "already used": an unauthenticated caller learns nothing about
		// which codes exist.
		c.String(http.StatusUnauthorized,
			"# This installer link is no longer valid.\n"+
				"# Generate a fresh one from Settings -> Local Agent in the PAM console.\n")
		return
	}

	target, ok := h.store.Lookup(goos, arch)
	if !ok {
		c.String(http.StatusNotFound, "# No agent build for %s/%s on this server.\n", goos, arch)
		return
	}

	serverURL := h.agent.resolveServerURL(c)
	boot := agentdist.Bootstrap{
		ServerURL:   serverURL,
		PairingCode: code,
		BinaryURL:   binaryURL(serverURL, target.OS, target.Arch, code),
		SHA256:      target.SHA256,
		ExpiresAt:   agentdist.FormatExpiry(expiresAt),
		Target:      target,
	}.WithScriptURL(scriptURL(serverURL, target.OS, target.Arch, code))

	script, err := agentdist.Render(boot)
	if err != nil {
		h.logger.Error("agent.install.script.render_fail", zap.Error(err))
		c.String(http.StatusInternalServerError, "# Could not generate the installer.\n")
		return
	}

	// no-store because the body contains a live enrolment credential; a
	// caching proxy holding it would extend the exposure well past the TTL.
	c.Header("Cache-Control", "no-store, no-cache, must-revalidate")
	c.Header("Content-Disposition", `attachment; filename="`+script.Filename+`"`)
	c.Data(http.StatusOK, script.ContentType, []byte(script.Body))
}

// Binary handles GET /api/v1/pam/agent/install/binary/:os/:arch
//
// Streamed rather than buffered: these are ~15MB and there is no reason to
// hold one per concurrent enrolment in memory.
func (h *AgentInstallHandler) Binary(c *gin.Context) {
	code := strings.TrimSpace(c.Query("t"))
	if _, _, err := h.agent.svc.ValidatePairingCode(code); err != nil {
		response.Error(c, http.StatusUnauthorized, "This download link is no longer valid")
		return
	}

	goos := strings.ToLower(c.Param("os"))
	arch := strings.ToLower(c.Param("arch"))

	rc, target, err := h.store.Open(goos, arch)
	if err != nil {
		response.Error(c, http.StatusNotFound,
			fmt.Sprintf("No agent build is available for %s/%s on this server", goos, arch))
		return
	}
	defer rc.Close()

	name := "pam-agent"
	if target.OS == "windows" {
		name += ".exe"
	}
	c.Header("Cache-Control", "no-store")
	c.Header("Content-Disposition", `attachment; filename="`+name+`"`)
	c.Header("X-Content-Type-Options", "nosniff")
	// The installer verifies this against what it downloaded; sending it as a
	// header too lets an operator check by hand.
	c.Header("X-PAM-Agent-SHA256", target.SHA256)
	c.DataFromReader(http.StatusOK, target.Size, "application/octet-stream", rc, nil)
}

func scriptURL(serverURL, goos, arch, code string) string {
	return fmt.Sprintf("%s/api/v1/pam/agent/install/script?os=%s&arch=%s&t=%s",
		strings.TrimRight(serverURL, "/"),
		url.QueryEscape(goos), url.QueryEscape(arch), url.QueryEscape(code))
}

func binaryURL(serverURL, goos, arch, code string) string {
	return fmt.Sprintf("%s/api/v1/pam/agent/install/binary/%s/%s?t=%s",
		strings.TrimRight(serverURL, "/"),
		url.PathEscape(goos), url.PathEscape(arch), url.QueryEscape(code))
}

var _ = io.Discard
