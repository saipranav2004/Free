// pam/internal/api/handlers/web_proxy_handler.go
//
// The API surface for brokered web-application sessions (see
// internal/webproxy). Two audiences:
//
//   - Operator: POST /resources/:id/web-session opens a session and returns
//     a single-use launch URL. Gated by exactly the same middleware chain as
//     every other connect method — PAMAuth → RequirePermission
//     (pam:resource:Connect) → RequireActiveGrant — so a brokered web
//     session is neither easier nor harder to obtain than a terminal or
//     native-agent one.
//   - Admin: list live brokered sessions, read one session's per-request
//     activity trail, and force-end a session.
package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/webproxy"
	"go.uber.org/zap"
)

type WebProxyHandler struct {
	svc    *webproxy.Service
	logger *zap.Logger
}

func NewWebProxyHandler(svc *webproxy.Service, logger *zap.Logger) *WebProxyHandler {
	return &WebProxyHandler{svc: svc, logger: logger}
}

// Open handles POST /api/v1/pam/resources/:id/web-session
//
// Returns a launch_url the browser should navigate to. That URL carries a
// single-use, seconds-lived handoff token — the response deliberately
// contains no target credential of any kind, which is the entire point of
// this connect method versus handing the operator a password.
func (h *WebProxyHandler) Open(c *gin.Context) {
	resourceID := c.Param("id")
	userID, _ := c.Get("user_id")
	username, _ := c.Get("username")
	authzDecisionID, _ := c.Get("authz_decision_id")
	grantCtx := middleware.GrantFromContext(c)

	result, err := h.svc.StartSession(c.Request.Context(), webproxy.StartSessionInput{
		UserID:            toString(userID),
		Username:          toString(username),
		ResourceID:        resourceID,
		SourceIP:          c.ClientIP(),
		UserAgent:         c.Request.UserAgent(),
		AuthzDecisionID:   toString(authzDecisionID),
		GrantID:           grantCtx.GrantID,
		JITRequestID:      grantCtx.JITRequestID,
		IsBreakglass:      grantCtx.IsBreakglass,
		RecordingRequired: grantCtx.RecordingRequired,
		DataProtection:    grantCtx.DataProtection,
	})
	if err != nil {
		switch {
		case errors.Is(err, webproxy.ErrDisabled):
			c.JSON(http.StatusServiceUnavailable, gin.H{
				"success": false,
				"error":   "The brokered web gateway is not enabled on this server",
				"hint":    "Set PAM_WEBPROXY_ENABLED=true and PAM_WEBPROXY_BASE_DOMAIN=<wildcard domain> to enable it.",
				"code":    "web_proxy_disabled",
			})
		case errors.Is(err, webproxy.ErrConnectMethodNotAllowed):
			// 403, not 404/422: the operator may well be entitled to this
			// resource — the policy has closed this particular route to it,
			// and saying so plainly is what stops them retrying every button.
			c.JSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "This resource cannot be opened in the browser",
				"detail":  err.Error(),
				"hint":    "An administrator has restricted which connect methods this resource permits.",
				"code":    "connect_method_not_allowed",
			})
		case errors.Is(err, webproxy.ErrResourceNotWebApp):
			c.JSON(http.StatusUnprocessableEntity, gin.H{
				"success": false,
				"error":   "This resource has no web console URL configured",
				"hint":    "Set console_url on the resource (e.g. http://host:9001) to open it in a browser.",
				"code":    "web_proxy_no_console_url",
			})
		default:
			h.logger.Error("webproxy.open.fail",
				zap.String("resource_id", resourceID), zap.Error(err))
			c.JSON(http.StatusBadGateway, gin.H{
				"success": false,
				"error":   "Could not open a brokered session with the target application",
				"detail":  err.Error(),
				"code":    "web_proxy_upstream_login_failed",
			})
		}
		return
	}

	response.Success(c, result, "Navigate the browser to launch_url to enter the brokered session")
}

// Mine handles GET /api/v1/pam/web-sessions/mine — the operator's own
// self-service view of their live brokered sessions, the web-proxy
// counterpart to GET /sessions/mine for tracked CLI/native-agent sessions.
func (h *WebProxyHandler) Mine(c *gin.Context) {
	userID, _ := c.Get("user_id")
	sessions, err := h.svc.ListMine(toString(userID))
	if err != nil {
		h.logger.Error("webproxy.mine.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to list your brokered web sessions")
		return
	}
	response.Success(c, gin.H{"sessions": sessions, "count": len(sessions)}, "Your brokered web sessions fetched")
}

// EndMine handles POST /api/v1/pam/web-sessions/:id/end — the operator
// ending their OWN brokered session (as opposed to Admin's End below, which
// can end anyone's). Ownership-checked: ending someone else's session here
// comes back as "not found" rather than a permission error, matching
// EndTrackedSession's own ErrSessionNotOwned handling for regular sessions —
// an operator has no legitimate reason to learn that a session ID they
// don't own exists at all.
func (h *WebProxyHandler) EndMine(c *gin.Context) {
	userID, _ := c.Get("user_id")
	if err := h.svc.End(c.Param("id"), toString(userID), false, "ENDED", "operator ended the brokered web session"); err != nil {
		switch {
		case errors.Is(err, webproxy.ErrSessionNotFound), errors.Is(err, webproxy.ErrSessionNotOwned):
			response.Error(c, http.StatusNotFound, "Brokered web session not found")
		default:
			h.logger.Error("webproxy.mine.end.fail", zap.Error(err))
			response.Error(c, http.StatusInternalServerError, "Failed to end brokered web session")
		}
		return
	}
	response.Success(c, gin.H{"web_proxy_session_id": c.Param("id")}, "Brokered web session ended")
}

// ListActive handles GET /api/v1/pam/admin/web-sessions
func (h *WebProxyHandler) ListActive(c *gin.Context) {
	sessions, err := h.svc.ListActive()
	if err != nil {
		h.logger.Error("webproxy.admin.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to list brokered web sessions")
		return
	}
	response.Success(c, gin.H{"sessions": sessions, "count": len(sessions)}, "Brokered web sessions fetched")
}

// Activity handles GET /api/v1/pam/admin/web-sessions/:id/activity — the
// per-request audit trail for one brokered session (the web-app counterpart
// to a terminal session's recorded command log).
func (h *WebProxyHandler) Activity(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "100"))

	rows, total, err := h.svc.ListActivity(c.Param("id"), page, pageSize)
	if err != nil {
		h.logger.Error("webproxy.admin.activity.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch session activity")
		return
	}
	response.Success(c, gin.H{
		"activity":  rows,
		"total":     total,
		"page":      page,
		"page_size": pageSize,
	}, "Session activity fetched")
}

// End handles POST /api/v1/pam/admin/web-sessions/:id/end — force-terminate
// a brokered session. Takes effect on the operator's very next request,
// since Service.Resolve re-reads authorization from the database every time
// rather than caching it.
func (h *WebProxyHandler) End(c *gin.Context) {
	var body struct {
		Reason string `json:"reason"`
	}
	_ = c.ShouldBindJSON(&body)
	if body.Reason == "" {
		body.Reason = "terminated by an administrator"
	}

	actorID, _ := middleware.AdminIdentityFromContext(c)
	if err := h.svc.End(c.Param("id"), actorID, true, "REVOKED", body.Reason); err != nil {
		if errors.Is(err, webproxy.ErrSessionNotFound) {
			response.Error(c, http.StatusNotFound, "Brokered web session not found")
			return
		}
		h.logger.Error("webproxy.admin.end.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to end brokered web session")
		return
	}
	response.Success(c, gin.H{"web_proxy_session_id": c.Param("id")}, "Brokered web session terminated")
}
