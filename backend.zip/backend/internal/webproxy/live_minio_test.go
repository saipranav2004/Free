// pam/internal/webproxy/live_minio_test.go
//
// End-to-end verification against a REAL MinIO Console, not a mock: performs
// the actual server-side login, then proxies a real authenticated request
// through the real httputil.ReverseProxy and asserts both security
// invariants hold against a live target.
//
// This is the test that would have caught the CORS/415 wall from the
// browser-side approach, and it is the one that proves the brokered path
// genuinely lands the operator inside an authenticated console.
//
// Gated behind PAM_TEST_LIVE_MINIO=1 so a sandboxed/offline CI run never
// fails on a network dependency — the mock-based tests in
// authenticator_test.go and proxy_test.go cover the same logic unconditionally.
//
//	PAM_TEST_LIVE_MINIO=1 \
//	PAM_TEST_MINIO_CONSOLE=http://13.206.221.6:9001 \
//	PAM_TEST_MINIO_USER=minioadmin \
//	PAM_TEST_MINIO_PASS='DasAdmin@123' \
//	go test ./internal/webproxy/ -run TestLiveMinIO -v
package webproxy

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"testing"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
)

func liveMinIOTarget(t *testing.T) Target {
	t.Helper()
	if os.Getenv("PAM_TEST_LIVE_MINIO") != "1" {
		t.Skip("set PAM_TEST_LIVE_MINIO=1 (plus PAM_TEST_MINIO_CONSOLE/USER/PASS) to run the live MinIO check")
	}
	console := os.Getenv("PAM_TEST_MINIO_CONSOLE")
	user := os.Getenv("PAM_TEST_MINIO_USER")
	pass := os.Getenv("PAM_TEST_MINIO_PASS")
	if console == "" || user == "" || pass == "" {
		t.Fatal("PAM_TEST_MINIO_CONSOLE, PAM_TEST_MINIO_USER and PAM_TEST_MINIO_PASS must all be set")
	}
	return Target{BaseURL: strings.TrimRight(console, "/"), Username: user, Password: pass}
}

func TestLiveMinIOBrokeredSessionEndToEnd(t *testing.T) {
	target := liveMinIOTarget(t)

	// ── 1. Server-side login against the real console ─────────────────────
	auth := &MinIOConsoleAuthenticator{}
	state, err := auth.Login(context.Background(), &http.Client{}, target)
	if err != nil {
		t.Fatalf("server-side login against the live MinIO console failed: %v", err)
	}
	if len(state.Cookies) == 0 {
		t.Fatal("live login returned no session cookie")
	}
	t.Logf("live MinIO login OK — captured %d upstream cookie(s): %v", len(state.Cookies), cookieNames(state.Cookies))

	// ── 2. Proxy a real request using that session ────────────────────────
	targetURL, err := url.Parse(target.BaseURL)
	if err != nil {
		t.Fatalf("parse console URL: %v", err)
	}
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "live-test", Subdomain: "minio-live"},
		Upstream: state,
		Target:   targetURL,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())

	// MinIO Console's own "who am I" endpoint: 200 only for an
	// authenticated session, 401 otherwise — so this single assertion
	// proves the brokered session is genuinely authenticated upstream,
	// rather than just that the proxy forwarded bytes.
	req := httptest.NewRequest(http.MethodGet, "http://minio-live.pam.example.com/api/v1/session", nil)
	req.AddCookie(&http.Cookie{Name: proxyCookieName, Value: "browser-side-pam-token"})
	rec := httptest.NewRecorder()

	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("proxied /api/v1/session returned %d, want 200 — the brokered session is not authenticated upstream. Body: %s",
			rec.Code, truncate(rec.Body.String(), 400))
	}
	t.Logf("proxied authenticated request OK (200) — response: %s", truncate(rec.Body.String(), 200))

	// ── 3. Both security invariants, against the live target ──────────────
	if got := rec.Result().Header.Get("Set-Cookie"); got != "" {
		t.Fatalf("SECURITY: live MinIO's Set-Cookie leaked to the browser: %q", got)
	}
	for name, value := range state.Cookies {
		if strings.Contains(rec.Body.String(), value) {
			t.Fatalf("SECURITY: upstream cookie %q's value appeared in the proxied response body", name)
		}
	}
	t.Log("invariant 1 OK — no upstream session cookie reached the browser")
}

// TestLiveMinIOBeaconIsRunnableUnderTheConsolesOwnCSP proves the fix for the
// failure that made tab-close detection dead in production against the real
// target: MinIO Console serves its pages with a CSP whose script-src omits
// 'unsafe-inline', so the injected beacon was present in the HTML and silently
// never executed. Asserting the tag exists is therefore not enough — this
// checks the browser would actually be permitted to run it.
func TestLiveMinIOBeaconIsRunnableUnderTheConsolesOwnCSP(t *testing.T) {
	target := liveMinIOTarget(t)

	targetURL, err := url.Parse(target.BaseURL)
	if err != nil {
		t.Fatalf("parse console URL: %v", err)
	}
	rs := &ResolvedSession{
		Session:  &models.WebProxySession{ID: "live-test", Subdomain: "minio-live"},
		Upstream: &UpstreamState{},
		Target:   targetURL,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://minio-live.pam.example.com/", nil)
	rec := httptest.NewRecorder()

	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("live console root returned %d, want 200", rec.Code)
	}
	body := rec.Body.String()
	policy := rec.Result().Header.Get(cspHeader)
	t.Logf("live console CSP after rewrite: %s", policy)

	if !strings.Contains(body, heartbeatScriptJS) {
		t.Fatalf("no beacon injected into the live console page:\n%s", truncate(body, 600))
	}
	nonce := nonceFromScriptTag(t, body)
	if policy == "" {
		t.Skip("live console served no CSP on this response — nothing to authorise")
	}
	if nonce == "" {
		t.Fatalf("the live console's CSP forbids inline script, so the beacon needs a nonce or it "+
			"will never run: %s", policy)
	}
	if !strings.Contains(policy, "'nonce-"+nonce+"'") {
		t.Fatalf("script nonce %q is not authorised by the live response's policy: %s", nonce, policy)
	}
	t.Logf("beacon is runnable — nonce %q authorised by the console's own policy", nonce)
}

// TestLiveMinIORecorderIsAdmittedByTheConsolesCSP proves the visual replay
// recorder reaches a real target. It is served from the proxy origin, so the
// console's own `script-src 'self'` admits it with no policy rewrite — the
// property that makes rrweb viable here at all, and one that only a live
// target's real headers can confirm.
func TestLiveMinIORecorderIsAdmittedByTheConsolesCSP(t *testing.T) {
	target := liveMinIOTarget(t)

	targetURL, err := url.Parse(target.BaseURL)
	if err != nil {
		t.Fatalf("parse console URL: %v", err)
	}
	rs := &ResolvedSession{
		Session:           &models.WebProxySession{ID: "live-test", Subdomain: "minio-live"},
		Upstream:          &UpstreamState{},
		Target:            targetURL,
		RecordingRequired: true,
	}
	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	req := httptest.NewRequest(http.MethodGet, "http://minio-live.pam.example.com/", nil)
	rec := httptest.NewRecorder()

	h.buildReverseProxy(rs).ServeHTTP(rec, req)

	body := rec.Body.String()
	if !strings.Contains(body, replayScriptPath) {
		t.Fatalf("recorder was not injected into the live console page:\n%s", truncate(body, 800))
	}

	policy := rec.Result().Header.Get(cspHeader)
	scriptSrc := ""
	for _, seg := range strings.Split(policy, ";") {
		if directiveName(seg) == "script-src" {
			scriptSrc = seg
		}
	}
	t.Logf("live console script-src after rewrite: %s", strings.TrimSpace(scriptSrc))

	// Either route is fine — 'self' covers a same-origin script, and the
	// nonce covers it regardless of source. What must not happen is neither.
	nonce := nonceFromScriptTag(t, body)
	admitted := strings.Contains(scriptSrc, "'self'") ||
		(nonce != "" && strings.Contains(scriptSrc, "'nonce-"+nonce+"'"))
	if scriptSrc != "" && !admitted {
		t.Fatalf("the console's policy would block the recorder: %s", policy)
	}
	t.Log("recorder is admitted by the live console's own policy")
}

func cookieNames(m map[string]string) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}
