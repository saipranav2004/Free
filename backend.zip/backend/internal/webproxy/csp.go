// pam/internal/webproxy/csp.go
//
// Content-Security-Policy handling for the injected heartbeat beacon.
//
// Injecting a <script> into a proxied page is not enough on its own: a target
// that ships a CSP forbidding inline script simply refuses to run it, and the
// failure is completely silent — no console error the operator would ever
// see, no request that fails, the page renders perfectly. MinIO Console is
// exactly this case:
//
//	Content-Security-Policy: default-src 'self' 'unsafe-eval' 'unsafe-inline';
//	                         script-src 'self' https://unpkg.com;
//	                         connect-src 'self' https://unpkg.com;
//
// script-src overrides default-src for <script>, and it carries no
// 'unsafe-inline' — so the beacon never fired, last_heartbeat_at stayed NULL,
// and closing the tab left the session running to its idle timeout with the
// recording (finalised on End) never landing.
//
// The fix is the standard one: give the injected script a per-response nonce
// and add that nonce to the directive that governs it. That grants exactly
// one script — ours — permission to run, and changes nothing else about the
// target's policy.
package webproxy

import (
	"crypto/rand"
	"encoding/base64"
	"net/http"
	"strings"
)

// cspHeader is the enforcing policy. The Report-Only variant is deliberately
// left alone: it cannot block anything, so rewriting it would buy nothing
// while quietly editing the target's own security telemetry.
const cspHeader = "Content-Security-Policy"

// scriptDirectivePrecedence is the order a browser consults when deciding
// whether a <script> ELEMENT may execute: the most specific directive present
// wins outright, and the others are not consulted at all. Adding a nonce to
// script-src would therefore be useless on a page that also sets
// script-src-elem — the nonce has to land on whichever one actually governs.
var scriptDirectivePrecedence = []string{"script-src-elem", "script-src", "default-src"}

// connectDirectivePrecedence is the equivalent for the beacon's own request
// (sendBeacon and XHR are both fetch-directive-governed).
var connectDirectivePrecedence = []string{"connect-src", "default-src"}

// newCSPNonce returns a fresh base64 nonce. Per-response and unpredictable by
// requirement: a reused or guessable nonce would let a script injected into
// the target page (by anyone who can influence its content) borrow our
// exemption and execute under a policy that otherwise forbids it.
func newCSPNonce() (string, error) {
	var raw [16]byte
	if _, err := rand.Read(raw[:]); err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(raw[:]), nil
}

// prepareCSPForBeacon rewrites every enforcing CSP header on the response so
// the injected beacon can both run and reach its endpoint, and reports
// whether the script tag needs to carry the nonce.
//
// A response may legitimately carry several CSP headers; each is enforced
// independently and a script must satisfy ALL of them, so every one has to be
// handled or the strictest still blocks the beacon.
func prepareCSPForBeacon(header http.Header, nonce string) (needNonce bool) {
	policies := header.Values(cspHeader)
	if len(policies) == 0 {
		return false
	}

	rewritten := make([]string, 0, len(policies))
	for _, policy := range policies {
		out, used := rewriteCSPForBeacon(policy, nonce)
		rewritten = append(rewritten, out)
		needNonce = needNonce || used
	}

	header.Del(cspHeader)
	for _, p := range rewritten {
		header.Add(cspHeader, p)
	}
	return needNonce
}

// rewriteCSPForBeacon returns the policy with the beacon permitted, and
// whether it did so by way of a nonce.
func rewriteCSPForBeacon(policy, nonce string) (string, bool) {
	segments := strings.Split(policy, ";")

	usedNonce := false
	if i, ok := governingDirective(segments, scriptDirectivePrecedence); ok {
		// Skip a directive that already permits inline script. Adding a
		// nonce there would be worse than useless: under CSP2+ a policy
		// containing ANY nonce- or hash-source makes 'unsafe-inline' be
		// ignored, so "helping" our own script would silently break every
		// inline script the target app itself relies on.
		if !allowsInlineScript(segments[i]) {
			segments[i] = appendSource(segments[i], "'nonce-"+nonce+"'")
			usedNonce = true
		}
	}
	if i, ok := governingDirective(segments, connectDirectivePrecedence); ok {
		// The beacon posts same-origin (to the proxy host), so 'self' is all
		// it needs — and all it gets.
		if !allowsSameOriginConnect(segments[i]) {
			segments[i] = appendSource(segments[i], "'self'")
		}
	}
	return strings.Join(segments, ";"), usedNonce
}

// governingDirective finds the index of the first directive in precedence
// order that is actually present. A policy naming none of them does not
// restrict the thing at all, so there is nothing to relax.
func governingDirective(segments []string, precedence []string) (int, bool) {
	for _, want := range precedence {
		for i, seg := range segments {
			if directiveName(seg) == want {
				return i, true
			}
		}
	}
	return 0, false
}

func directiveName(segment string) string {
	fields := strings.Fields(segment)
	if len(fields) == 0 {
		return ""
	}
	return strings.ToLower(fields[0])
}

// allowsInlineScript reports whether a directive already lets an inline
// script run as-is. 'unsafe-inline' alone does; 'unsafe-inline' alongside a
// nonce- or hash-source does NOT, because browsers ignore 'unsafe-inline'
// entirely once either is present.
func allowsInlineScript(segment string) bool {
	var hasUnsafeInline, hasNonceOrHash bool
	for _, tok := range strings.Fields(segment)[1:] {
		switch t := strings.ToLower(strings.Trim(tok, "'")); {
		case t == "unsafe-inline":
			hasUnsafeInline = true
		case strings.HasPrefix(t, "nonce-"),
			strings.HasPrefix(t, "sha256-"),
			strings.HasPrefix(t, "sha384-"),
			strings.HasPrefix(t, "sha512-"):
			hasNonceOrHash = true
		}
	}
	return hasUnsafeInline && !hasNonceOrHash
}

// allowsSameOriginConnect reports whether the directive already permits a
// same-origin request, in which case the beacon needs no help.
func allowsSameOriginConnect(segment string) bool {
	for _, tok := range strings.Fields(segment)[1:] {
		if t := strings.ToLower(strings.Trim(tok, "'")); t == "self" || t == "*" {
			return true
		}
	}
	return false
}

// appendSource adds a source expression to a directive, preserving the
// original spacing around it so the rest of the policy round-trips
// byte-for-byte.
func appendSource(segment, source string) string {
	trimmed := strings.TrimRight(segment, " \t")
	return trimmed + " " + source + segment[len(trimmed):]
}
