/* pam/internal/webproxy/assets/pam-replay.js
 *
 * The PAM half of visual session replay. Concatenated after rrweb.min.js and
 * served as one file from /__pam/replay.js on the proxy origin — same-origin
 * so a target's `script-src 'self'` admits it with no policy change at all,
 * which is what makes this work against apps like MinIO Console that forbid
 * inline script outright.
 *
 * Everything here is wrapped so that a failure records nothing rather than
 * breaking the page the operator is trying to work in: a PAM that makes the
 * target unusable is worse than one whose replay is missing.
 */
(function () {
  try {
    if (!window.rrweb || typeof window.rrweb.record !== "function") return;
    // Guard against a double-inject (e.g. a page that re-injects fragments).
    if (window.__pamReplayStarted) return;
    window.__pamReplayStarted = true;

    var ENDPOINT = "/__pam/replay";
    var FLUSH_MS = 5000;
    var MAX_BATCH = 200;
    var buffer = [];
    var dropped = false;

    function post(payload, useBeacon) {
      try {
        if (useBeacon && navigator.sendBeacon) {
          // A Blob keeps the Content-Type intact; sendBeacon is the only
          // transport that reliably survives the page being torn down, which
          // is exactly when the final frames matter most.
          navigator.sendBeacon(ENDPOINT, new Blob([payload], { type: "application/json" }));
          return;
        }
        var xhr = new XMLHttpRequest();
        xhr.open("POST", ENDPOINT, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(payload);
      } catch (e) {
        /* a dropped batch costs frames, never the operator's session */
      }
    }

    function flush(useBeacon) {
      if (!buffer.length) return;
      var batch = buffer;
      buffer = [];
      try {
        post(JSON.stringify(batch), useBeacon);
      } catch (e) {
        /* JSON.stringify can throw on a pathological DOM; drop the batch */
      }
    }

    window.rrweb.record({
      emit: function (event) {
        buffer.push(event);
        // Bound memory if the page is a firehose and flushes are failing.
        if (buffer.length >= MAX_BATCH) {
          flush(false);
          if (buffer.length >= MAX_BATCH * 4) {
            buffer.length = 0;
            dropped = true;
          }
        }
      },
      // Passwords are masked even though PAM's whole design means the
      // operator never learns the target credential — an operator typing a
      // secret of their own into the app must not have it land in an audit
      // artifact that a different team can replay.
      maskInputOptions: { password: true },
      // Stylesheets have to travel with the recording: at replay time the
      // proxy subdomain is long gone, so any asset left as a URL is a 404
      // and the replay renders unstyled.
      inlineStylesheet: true,
      // Off by default — both are large and most consoles are DOM/CSS.
      recordCanvas: false,
      collectFonts: false,
      sampling: {
        mousemove: 50,
        scroll: 150,
        input: "last"
      }
    });

    setInterval(function () {
      flush(false);
    }, FLUSH_MS);

    // pagehide is the event that actually fires on tab close / navigation
    // across browsers (unload does not, under bfcache), so it is what gets
    // the tail of the session out.
    window.addEventListener("pagehide", function () {
      flush(true);
    });
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "hidden") flush(true);
    });

    window.__pamReplayDroppedFrames = function () {
      return dropped;
    };
  } catch (e) {
    /* never break the target application */
  }
})();
