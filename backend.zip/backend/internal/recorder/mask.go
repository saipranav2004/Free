// pam/internal/recorder/mask.go
//
// Best-effort secret redaction for anything that ends up in a session
// recording or a recorded-command log: what a user typed into the in-browser
// terminal, and what came back from the target. This is deliberately
// pattern-based, not a parser for SQL/Redis/Mongo — the same tradeoff the
// masking in a typical keystroke logger makes. It will not catch every way a
// secret could appear (a password split across two WebSocket frames, one
// base64-encoded, etc.), and it is not a substitute for not typing
// literal credentials into a session in the first place. It IS good enough
// to stop the common, accidental case — `ALTER USER x PASSWORD 'y'`, a Redis
// `AUTH`, a Mongo `createUser({..., pwd: "y"})` — from sitting in plaintext
// inside a recording an auditor or a compromised admin console could read.
package recorder

import "regexp"

// sensitiveKeyValue matches "<key><sep><value>" where key is one of the
// common secret-bearing names and value is either a quoted string or a bare
// token. Covers, among others:
//
//	PASSWORD 'S3cr3t!'          (Postgres: ALTER/CREATE USER ... PASSWORD)
//	password: "S3cr3t!"         (Mongo-ish JSON args)
//	pwd="S3cr3t!"
//	secret=abc123
//	api_key: sk-abc123
//
// The key itself is preserved in the redacted output (so an auditor can
// still see "a password was set here"), only the value is replaced.
var sensitiveKeyValue = regexp.MustCompile(
	`(?i)\b(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|auth)\b(\s*[:=]\s*|\s+)('[^']*'|"[^"]*"|` + "`[^`]*`" + `|\S+)`,
)

// MaskSecrets redacts anything sensitiveKeyValue matches, replacing the
// captured value (group 3) with a fixed marker while leaving the key name
// and separator intact.
func MaskSecrets(s string) string {
	return sensitiveKeyValue.ReplaceAllString(s, "$1$2***MASKED***")
}

// LooksSensitive reports whether s contains anything MaskSecrets would
// redact — useful for callers that want to flag a row as masked without
// re-running the substitution.
func LooksSensitive(s string) bool {
	return sensitiveKeyValue.MatchString(s)
}

// sensitiveKeyName matches a bare sensitive key name with NO requirement
// that a value follow it in the same string. This exists for a gap
// sensitiveKeyValue cannot close: a request like "GET password" or
// "SELECT password FROM users" only puts the key name in the INPUT —  the
// actual secret comes back later, alone, in a separate OUTPUT event/column
// with no key attached to it at all ("mysecretpass123" by itself). No
// regex can redact a value it can't distinguish from any other string, so
// the fix has to happen at the point the *request* is known to be
// sensitive: callers use ReferencesSecretKey on the incoming
// command/query to decide whether to withhold or redact the corresponding
// response entirely, rather than trying to pattern-match the response.
var sensitiveKeyName = regexp.MustCompile(`(?i)\b(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|auth)\b`)

// ReferencesSecretKey reports whether s mentions a sensitive field/key name
// anywhere, regardless of whether a value follows. Intended for callers
// deciding whether an upcoming RESPONSE (not this string itself) is about
// to carry a secret value with no key context of its own — see the
// redis/postgres/mongo gateway connectors, which redact returned values
// column-by-column (Postgres), document-key-by-key (Mongo), or wholesale
// (Redis, which has no structured result shape to redact selectively).
func ReferencesSecretKey(s string) bool {
	return sensitiveKeyName.MatchString(s)
}
