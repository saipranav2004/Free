// pam/internal/recorder/cast.go
//
// Cast builds an asciicast v2 stream (https://docs.asciinema.org/manual/asciicast/v2/)
// out of the raw text a session's WebSocket connection reads and writes.
// asciicast v2 is just a JSON header line followed by one JSON array per
// event — [relative_time_seconds, "i"|"o", data] — so any asciinema-compatible
// player (or a few lines of JS, see the frontend's RecordingPlayer) can
// replay it. We reuse the format rather than invent our own because it is
// already a faithful, ordered, timestamped transcript of exactly what a
// terminal showed, which is what "screen recording" means for a text-only
// session gateway — there is no actual video, only the exact bytes and their
// timing.
//
// Every event is mask.go-redacted before being appended, on both input and
// output — a literal password shown during replay would defeat the entire
// point of recording sessions in the first place, which is a gap in the
// keystroke-logger design this was adapted from (it only masked a separate
// command log, not the replay stream itself).
package recorder

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// castHeader is the asciicast v2 header line (always the first line of the file).
type castHeader struct {
	Version   int    `json:"version"`
	Width     int    `json:"width"`
	Height    int    `json:"height"`
	Timestamp int64  `json:"timestamp"`
	Title     string `json:"title,omitempty"`
}

// DefaultMaxBytes bounds an individual cast recording when the caller
// doesn't specify one — see Cast.Truncated for what happens once it's hit.
// 25MB is generous for a text-only session (that's tens of millions of
// characters) while still bounding worst-case memory/storage for a session
// left open for hours.
const DefaultMaxBytes = 25 * 1024 * 1024

// Cast incrementally builds an asciicast v2 recording. Safe for concurrent
// use — RecordingConn (see the gateway package) may be written to from a
// second goroutine (an admin-kill notice) while the main protocol loop is
// still reading/writing, and both need to land in the same ordered stream
// without corrupting it.
type Cast struct {
	mu        sync.Mutex
	buf       bytes.Buffer
	started   time.Time
	maxBytes  int64
	truncated bool
}

// NewCast starts a new recording. width/height are cosmetic metadata only —
// this gateway's terminal is a scrolling text pane, not a real PTY grid, so
// any reasonable fixed size is fine; a player just uses it to size its
// viewport.
func NewCast(width, height int, title string, maxBytes int64) *Cast {
	if maxBytes <= 0 {
		maxBytes = DefaultMaxBytes
	}
	c := &Cast{started: time.Now(), maxBytes: maxBytes}
	hdr := castHeader{Version: 2, Width: width, Height: height, Timestamp: c.started.Unix(), Title: title}
	hdrJSON, _ := json.Marshal(hdr)
	c.buf.Write(hdrJSON)
	c.buf.WriteByte('\n')
	return c
}

// Input records bytes the user sent (a command/line typed into the terminal).
func (c *Cast) Input(data []byte) { c.record("i", data) }

// Output records bytes the terminal sent back (a response, an error, a prompt).
func (c *Cast) Output(data []byte) { c.record("o", data) }

func (c *Cast) record(stream string, data []byte) {
	if len(data) == 0 {
		return
	}
	masked := MaskSecrets(string(data))

	c.mu.Lock()
	defer c.mu.Unlock()
	if c.truncated {
		return
	}
	if int64(c.buf.Len()) >= c.maxBytes {
		c.truncated = true
		notice, _ := json.Marshal([]interface{}{time.Since(c.started).Seconds(), "o", "\r\n*** recording truncated: size limit reached ***\r\n"})
		c.buf.Write(notice)
		c.buf.WriteByte('\n')
		return
	}

	event, err := json.Marshal([]interface{}{time.Since(c.started).Seconds(), stream, masked})
	if err != nil {
		return
	}
	c.buf.Write(event)
	c.buf.WriteByte('\n')
}

// Truncated reports whether the size cap was hit before the session ended.
func (c *Cast) Truncated() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.truncated
}

// Finalize returns the gzip-compressed cast bytes, plus their sha256 (of the
// COMPRESSED bytes, matching what gets written to storage — that's what a
// later integrity check would re-hash) and uncompressed size. Call once,
// after the session's WebSocket has closed.
func (c *Cast) Finalize() (gzipped []byte, sha256Hex string, uncompressedSize int64, err error) {
	c.mu.Lock()
	raw := append([]byte(nil), c.buf.Bytes()...)
	c.mu.Unlock()

	var gz bytes.Buffer
	w := gzip.NewWriter(&gz)
	if _, err = w.Write(raw); err != nil {
		return nil, "", 0, fmt.Errorf("gzip write: %w", err)
	}
	if err = w.Close(); err != nil {
		return nil, "", 0, fmt.Errorf("gzip close: %w", err)
	}

	sum := sha256.Sum256(gz.Bytes())
	return gz.Bytes(), hex.EncodeToString(sum[:]), int64(len(raw)), nil
}
