// pam/internal/models/agent.go
//
// The Local Agent feature — lets a paired desktop/CLI agent (`pam-agent`)
// pop open a real native client (psql/redis-cli/mongosh, or an installed
// GUI tool) already connected, instead of the in-browser tracked-session
// path. This was built and independently verified in an earlier round
// against a pre-Admin-Center snapshot of this backend, and was missed when
// this module was reconstructed for the Admin Center merge — restoring it
// here, unchanged in its trust model, adapted only where the surrounding
// session/grant model has since grown richer (see agent_service.go's
// comments on StartTrackedSession).
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// AgentDevice is one installation of the local PAM agent, paired to exactly
// one PAM user. Pairing happens once per machine (see AgentPairingCode);
// after that, the agent authenticates every request with an Ed25519
// signature over its stored private key — PAM only ever holds the public
// half, so a compromised backend can never impersonate an agent.
type AgentDevice struct {
	ID         string `gorm:"primaryKey;type:varchar(36)" json:"id"`
	UserID     string `gorm:"type:varchar(36);not null;index" json:"user_id"`
	DeviceName string `gorm:"type:varchar(255);not null" json:"device_name"`

	// Base64-encoded raw 32-byte Ed25519 public key. The matching private
	// key never leaves the user's machine.
	PublicKey string `gorm:"type:varchar(255);not null" json:"-"`

	// ACTIVE | REVOKED
	Status     string     `gorm:"type:varchar(20);not null;default:'ACTIVE';index" json:"status"`
	LastSeenAt *time.Time `json:"last_seen_at,omitempty"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (AgentDevice) TableName() string { return "pam_agent_devices" }

func (d *AgentDevice) BeforeCreate(tx *gorm.DB) error {
	if d.ID == "" {
		d.ID = uuid.NewString()
	}
	return nil
}

// AgentPairingCode is the short, human-typed, single-use code that bootstraps
// trust between a fresh agent install and a PAM account — the ONLY secret
// exchanged out-of-band. It is stored hashed, exactly like vault credentials.
type AgentPairingCode struct {
	ID     string `gorm:"primaryKey;type:varchar(36)" json:"id"`
	UserID string `gorm:"type:varchar(36);not null;index" json:"user_id"`

	// SHA-256 hex digest of the code the user actually typed. Never store
	// the plaintext code.
	CodeHash string `gorm:"type:varchar(64);not null;index" json:"-"`

	// PENDING | CONSUMED | EXPIRED
	Status    string    `gorm:"type:varchar(20);not null;default:'PENDING'" json:"status"`
	ExpiresAt time.Time `gorm:"not null" json:"expires_at"`

	CreatedAt  time.Time  `gorm:"autoCreateTime" json:"created_at"`
	ConsumedAt *time.Time `json:"consumed_at,omitempty"`
}

func (AgentPairingCode) TableName() string { return "pam_agent_pairing_codes" }

func (c *AgentPairingCode) BeforeCreate(tx *gorm.DB) error {
	if c.ID == "" {
		c.ID = uuid.NewString()
	}
	return nil
}

// LaunchToken is a short-lived, single-use handoff between "user clicked
// Open in Desktop App in the browser" and "the local agent redeemed it for
// a real, decrypted credential." It never carries the credential itself —
// only a hash of an opaque random value is stored, exactly like vault
// credentials and pairing codes.
//
// GrantID/JITRequestID/IsBreakglass/RecordingRequired are new versus the
// original build of this feature: at the time this token is issued (inside
// the authenticated request, right after middleware.RequireActiveGrant has
// already resolved the grant for this resource+user), that grant context is
// available on the gin.Context. By the time the agent redeems the token
// (ResolveLaunchToken), there is no gin.Context or middleware chain at
// all — the agent is a bare signed POST. So the grant context has to be
// captured into the token row itself at issuance time, or the resulting
// tracked session would silently lose its grant binding (breaking
// cascading auto-revoke) and its recording obligation for any JIT-gated or
// always-record resource launched natively. See agent_handler.go's
// CreateLaunch and agent_service.go's CreateLaunchToken/ResolveLaunchToken.
type LaunchToken struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	// SHA-256 hex digest of the raw token embedded in the pam-agent:// URL.
	TokenHash string `gorm:"type:varchar(64);not null;uniqueIndex" json:"-"`

	ResourceID string `gorm:"type:varchar(36);not null;index" json:"resource_id"`
	UserID     string `gorm:"type:varchar(36);not null;index" json:"user_id"`

	// Set once an agent successfully redeems the token.
	AgentDeviceID *string `gorm:"type:varchar(36)" json:"agent_device_id,omitempty"`

	// PENDING | CONSUMED | EXPIRED | REVOKED
	Status    string    `gorm:"type:varchar(20);not null;default:'PENDING';index" json:"status"`
	ExpiresAt time.Time `gorm:"not null" json:"expires_at"`

	AuthzDecisionID *string `gorm:"type:varchar(255)" json:"authz_decision_id,omitempty"`

	// Grant context, captured at issuance — see doc comment above.
	GrantID           *string `gorm:"type:varchar(36)" json:"grant_id,omitempty"`
	JITRequestID      *string `gorm:"type:varchar(36)" json:"jit_request_id,omitempty"`
	IsBreakglass      bool    `gorm:"default:false" json:"is_breakglass"`
	RecordingRequired bool    `gorm:"default:false" json:"recording_required"`

	CreatedAt  time.Time  `gorm:"autoCreateTime" json:"created_at"`
	ConsumedAt *time.Time `json:"consumed_at,omitempty"`
}

func (LaunchToken) TableName() string { return "pam_launch_tokens" }

func (t *LaunchToken) BeforeCreate(tx *gorm.DB) error {
	if t.ID == "" {
		t.ID = uuid.NewString()
	}
	return nil
}
