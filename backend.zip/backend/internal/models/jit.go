// pam/internal/models/jit.go
//
// JIT (Just-In-Time) access request workflow + time-boxed access grants.
//
//	pam_jit_requests  — the REQUEST  (what the user asked for, who approved it)
//	pam_access_grants — the ENTITLEMENT (the time-boxed permission actually held)
//
// The two are deliberately separate tables (CyberArk / Delinea / Entra PIM all
// model it this way): a request is an immutable-ish workflow artifact kept for
// audit forever, while a grant is a short-lived, revocable object that the PEP
// evaluates on every privileged action.
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// ── JIT request status machine ────────────────────────────────────────────
//
//	PENDING   ──approve──▶ APPROVED  (grant created, ACTIVE)
//	          ──deny────▶ DENIED
//	          ──cancel──▶ CANCELLED
//	          ──ttl─────▶ EXPIRED
//	WAITING   ──wait elapsed──▶ APPROVED   (break-glass only, no human approver)
//	          ──ttl─────▶ EXPIRED
const (
	JITStatusPending   = "PENDING"   // awaiting approver decision
	JITStatusWaiting   = "WAITING"   // break-glass cooling-off period running
	JITStatusApproved  = "APPROVED"  // grant issued
	JITStatusDenied    = "DENIED"    // approver rejected
	JITStatusCancelled = "CANCELLED" // requester withdrew
	JITStatusExpired   = "EXPIRED"   // request TTL elapsed with no decision
)

const (
	JITTypeStandard   = "STANDARD"
	JITTypeBreakglass = "BREAKGLASS"
)

// ── Grant status machine ──────────────────────────────────────────────────
//
//	ACTIVE ──expires_at reached──▶ EXPIRED  (sweeper)
//	       ──admin revoke───────▶ REVOKED  (immediate)
const (
	GrantStatusActive  = "ACTIVE"
	GrantStatusExpired = "EXPIRED"
	GrantStatusRevoked = "REVOKED"
)

// IAM projection status for the temporary policy attached on the IAM side.
// PAM enforcement never depends on this — it is a best-effort projection so
// the IAM console/OPA can also see the temporary entitlement.
const (
	IAMSyncSkipped = "SKIPPED" // IAM grant endpoint not configured
	IAMSyncPending = "PENDING"
	IAMSyncSynced  = "SYNCED"
	IAMSyncFailed  = "FAILED"
)

// JITRequest is a user's request for temporary privileged access.
type JITRequest struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	// IdempotencyKey lets a client retry POST /jit/requests safely.
	IdempotencyKey *string `gorm:"type:varchar(128);uniqueIndex" json:"idempotency_key,omitempty"`

	RequestType string `gorm:"type:varchar(20);not null;default:'STANDARD';index" json:"request_type"`

	RequesterUserID   string `gorm:"type:varchar(36);not null;index" json:"requester_user_id"`
	RequesterUsername string `gorm:"type:varchar(150);not null" json:"requester_username"`

	// Target — denormalised so the IAM admin console can render the queue
	// without joining back into PAM's resource table.
	ResourceID   string `gorm:"type:varchar(36);not null;index" json:"resource_id"`
	ResourceName string `gorm:"type:varchar(255)" json:"resource_name"`
	ResourceType string `gorm:"type:varchar(50)" json:"resource_type"`

	// Action is the PAM action vocabulary string the grant will cover,
	// e.g. "pam:resource:Connect".
	Action string `gorm:"type:varchar(100);not null" json:"action"`

	DurationMinutes int    `gorm:"not null" json:"duration_minutes"`
	Reason          string `gorm:"type:text;not null" json:"reason"`
	TicketRef       string `gorm:"type:varchar(100);index" json:"ticket_ref,omitempty"`

	Status string `gorm:"type:varchar(20);not null;default:'PENDING';index" json:"status"`

	SourceIP        string  `gorm:"type:varchar(45)" json:"source_ip,omitempty"`
	UserAgent       string  `gorm:"type:varchar(512)" json:"-"`
	AuthzDecisionID *string `gorm:"type:varchar(255)" json:"authz_decision_id,omitempty"`

	RequestedAt time.Time `gorm:"not null;index" json:"requested_at"`
	// RequestExpiresAt is the TTL of the REQUEST itself (not the access).
	RequestExpiresAt time.Time `gorm:"not null;index" json:"request_expires_at"`
	// AvailableAt is the break-glass cooling-off deadline. Nil for STANDARD.
	AvailableAt *time.Time `gorm:"index" json:"available_at,omitempty"`

	DecidedAt        *time.Time `json:"decided_at,omitempty"`
	ApproverUserID   *string    `gorm:"type:varchar(36);index" json:"approver_user_id,omitempty"`
	ApproverUsername *string    `gorm:"type:varchar(150)" json:"approver_username,omitempty"`
	DecisionReason   string     `gorm:"type:text" json:"decision_reason,omitempty"`

	GrantID *string `gorm:"type:varchar(36);index" json:"grant_id,omitempty"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (JITRequest) TableName() string { return "pam_jit_requests" }

func (r *JITRequest) BeforeCreate(tx *gorm.DB) error {
	if r.ID == "" {
		r.ID = uuid.NewString()
	}
	return nil
}

// IsTerminal reports whether the request can no longer change state.
func (r *JITRequest) IsTerminal() bool {
	switch r.Status {
	case JITStatusDenied, JITStatusCancelled, JITStatusExpired, JITStatusApproved:
		return true
	}
	return false
}

// AccessGrant is a time-boxed entitlement. This is PAM's authoritative record
// of "user U may perform action A on resource R until T".
type AccessGrant struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	RequestID string `gorm:"type:varchar(36);not null;index" json:"request_id"`

	UserID   string `gorm:"type:varchar(36);not null;index:idx_grant_lookup" json:"user_id"`
	Username string `gorm:"type:varchar(150)" json:"username"`

	ResourceID   string `gorm:"type:varchar(36);not null;index:idx_grant_lookup" json:"resource_id"`
	ResourceName string `gorm:"type:varchar(255)" json:"resource_name"`
	Action       string `gorm:"type:varchar(100);not null" json:"action"`

	IsBreakglass      bool `gorm:"not null;default:false;index" json:"is_breakglass"`
	RecordingRequired bool `gorm:"not null;default:false" json:"recording_required"`

	// Data-protection tightening for this grant only (see
	// data_protection.go). Composed with the resource's baseline by
	// MostRestrictive, so an approver can harden a single grant — a
	// break-glass window, a vendor's access — without editing the resource
	// every other user shares.
	BlockClipboard bool   `gorm:"column:block_clipboard;not null;default:false" json:"block_clipboard"`
	BlockDownload  bool   `gorm:"column:block_download;not null;default:false" json:"block_download"`
	Watermark      bool   `gorm:"column:watermark;not null;default:false" json:"watermark"`
	MaxEgressBytes int64  `gorm:"column:max_egress_bytes;not null;default:0" json:"max_egress_bytes"`
	DeniedCommands string `gorm:"column:denied_commands;type:text" json:"denied_commands,omitempty"`

	Status string `gorm:"type:varchar(20);not null;default:'ACTIVE';index:idx_grant_lookup" json:"status"`

	GrantedAt time.Time `gorm:"not null;index" json:"granted_at"`
	ExpiresAt time.Time `gorm:"not null;index" json:"expires_at"`

	RevokedAt     *time.Time `json:"revoked_at,omitempty"`
	RevokedBy     *string    `gorm:"type:varchar(36)" json:"revoked_by,omitempty"`
	RevokeReason  string     `gorm:"type:text" json:"revoke_reason,omitempty"`
	SessionsKille int        `gorm:"column:sessions_killed;default:0" json:"sessions_killed"`

	// Best-effort projection into IAM (temporary policy attachment).
	IAMPolicyID   *string `gorm:"column:iam_policy_id;type:varchar(128)" json:"iam_policy_id,omitempty"`
	IAMSyncStatus string  `gorm:"column:iam_sync_status;type:varchar(20);default:'SKIPPED'" json:"iam_sync_status"`
	IAMSyncError  string  `gorm:"column:iam_sync_error;type:text" json:"iam_sync_error,omitempty"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (AccessGrant) TableName() string { return "pam_access_grants" }

func (g *AccessGrant) BeforeCreate(tx *gorm.DB) error {
	if g.ID == "" {
		g.ID = uuid.NewString()
	}
	return nil
}

// IsUsable is the in-process guard used by the PEP. The sweeper flips ACTIVE →
// EXPIRED asynchronously, so enforcement must ALSO compare the clock. Never
// trust status alone.
func (g *AccessGrant) IsUsable(now time.Time) bool {
	return g.Status == GrantStatusActive && now.Before(g.ExpiresAt)
}

// RemainingSeconds returns how much access time is left (never negative).
func (g *AccessGrant) RemainingSeconds(now time.Time) int {
	if !g.IsUsable(now) {
		return 0
	}
	return int(g.ExpiresAt.Sub(now).Seconds())
}

// DataProtectionProfile is the grant's egress tightening, to be composed with
// the resource baseline via MostRestrictive.
func (g AccessGrant) DataProtectionProfile() DataProtection {
	return DataProtection{
		BlockClipboard: g.BlockClipboard,
		BlockDownload:  g.BlockDownload,
		Watermark:      g.Watermark,
		MaxEgressBytes: g.MaxEgressBytes,
		DeniedCommands: g.DeniedCommands,
	}
}
