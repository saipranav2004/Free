// pam/internal/models/rotation.go
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type RotationTriggerType string

const (
	RotationTriggerScheduled    RotationTriggerType = "scheduled"
	RotationTriggerManual       RotationTriggerType = "manual"
	RotationTriggerPolicyChange RotationTriggerType = "policy_change"
	RotationTriggerCheckin      RotationTriggerType = "checkin"
	RotationTriggerCompromise   RotationTriggerType = "compromise"
)

// RotationJob tracks an active or historical credential rotation attempt.
type RotationJob struct {
	ID               string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	CredentialID     string         `gorm:"type:varchar(36);not null;index" json:"credential_id"`
	VaultEntryID     string         `gorm:"type:varchar(36);index" json:"vault_entry_id,omitempty"`
	Status           string         `gorm:"type:varchar(30);default:'pending';index" json:"status"`
	TriggerType      string         `gorm:"type:varchar(50);not null" json:"trigger_type"`
	AttemptCount     int            `gorm:"default:1" json:"attempt_count"`
	MaxAttempts      int            `gorm:"default:3" json:"max_attempts"`
	LastErrorMessage string         `gorm:"type:text" json:"last_error_message,omitempty"`
	StartedAt        *time.Time     `json:"started_at,omitempty"`
	CompletedAt      *time.Time     `json:"completed_at,omitempty"`
	CreatedAt        time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt        time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt        gorm.DeletedAt `gorm:"index" json:"-"`
}

func (RotationJob) TableName() string { return "pam_rotation_jobs" }

func (j *RotationJob) BeforeCreate(tx *gorm.DB) error {
	if j.ID == "" {
		j.ID = uuid.NewString()
	}
	if j.Status == "" {
		j.Status = "pending"
	}
	if j.MaxAttempts == 0 {
		j.MaxAttempts = 3
	}
	if j.CredentialID == "" && j.VaultEntryID != "" {
		j.CredentialID = j.VaultEntryID
	}
	if j.VaultEntryID == "" && j.CredentialID != "" {
		j.VaultEntryID = j.CredentialID
	}
	return nil
}

// RotationDependency tracks an external service, IIS pool, scheduled task, or DB connection
// that relies on a privileged credential stored in the PAM Vault.
type RotationDependency struct {
	ID              string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	CredentialID    string         `gorm:"type:varchar(36);not null;index" json:"credential_id"`
	VaultEntryID    string         `gorm:"type:varchar(36);index" json:"vault_entry_id,omitempty"`
	TargetType      string         `gorm:"type:varchar(50);not null;index" json:"target_type"`
	TargetAddress   string         `gorm:"type:varchar(255);not null" json:"target_address"`
	ServiceName     string         `gorm:"type:varchar(255);not null" json:"service_name"`
	RestartRequired bool           `gorm:"default:true" json:"restart_required"`
	Status          string         `gorm:"type:varchar(30);default:'active';index" json:"status"`
	LastUpdated     *time.Time     `json:"last_updated,omitempty"`
	CreatedAt       time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt       time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt       gorm.DeletedAt `gorm:"index" json:"-"`
}

func (RotationDependency) TableName() string { return "pam_rotation_dependencies" }

func (d *RotationDependency) BeforeCreate(tx *gorm.DB) error {
	if d.ID == "" {
		d.ID = uuid.NewString()
	}
	if d.Status == "" {
		d.Status = "active"
	}
	if d.CredentialID == "" && d.VaultEntryID != "" {
		d.CredentialID = d.VaultEntryID
	}
	if d.VaultEntryID == "" && d.CredentialID != "" {
		d.VaultEntryID = d.CredentialID
	}
	return nil
}

// RotationHistory is an immutable audit log of credential rotations and version bumps.
type RotationHistory struct {
	ID           string    `gorm:"primaryKey;type:varchar(36)" json:"id"`
	CredentialID string    `gorm:"type:varchar(36);not null;index" json:"credential_id"`
	VaultEntryID string    `gorm:"type:varchar(36);index" json:"vault_entry_id,omitempty"`
	JobID        string    `gorm:"type:varchar(36);index" json:"job_id,omitempty"`
	OldVersion   int       `gorm:"not null" json:"old_version"`
	NewVersion   int       `gorm:"not null" json:"new_version"`
	RotatedBy    string    `gorm:"type:varchar(150);not null" json:"rotated_by"`
	Status       string    `gorm:"type:varchar(30);not null" json:"status"`
	ErrorMessage string    `gorm:"type:text" json:"error_message,omitempty"`
	RotatedAt    time.Time `gorm:"autoCreateTime" json:"rotated_at"`
}

func (RotationHistory) TableName() string { return "pam_rotation_history" }

func (h *RotationHistory) BeforeCreate(tx *gorm.DB) error {
	if h.ID == "" {
		h.ID = uuid.NewString()
	}
	if h.CredentialID == "" && h.VaultEntryID != "" {
		h.CredentialID = h.VaultEntryID
	}
	if h.VaultEntryID == "" && h.CredentialID != "" {
		h.VaultEntryID = h.CredentialID
	}
	return nil
}
