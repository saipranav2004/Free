// pam/internal/agentdist/store.go
//
// Distribution of the native pam-agent binary to operators.
//
// WHY THIS EXISTS. Enrolling an agent used to mean: find the download, unzip
// it, put it somewhere on PATH, run `pam-agent pair`, read an 8-character code
// off the web console, and type it in before it expired. Six manual steps, and
// the two in the middle are the ones every operator gets wrong. This package
// is the server half of collapsing that to one: the console asks for an
// installer for a platform, and gets back a script that already knows where to
// download the binary, how to verify it, and which one-time code to pair with.
//
// WHAT IT DELIBERATELY DOES NOT DO. It cannot install anything. A web page
// cannot execute code on the operator's machine — that is the browser sandbox,
// and it is the same boundary that makes a PAM console safe to load in the
// first place. So the floor is one action by a human: paste a line, or
// double-click a file. Everything after that point is automatic.
//
// INTEGRITY IS NOT OPTIONAL HERE. This package hands out an executable that
// will hold privileged credentials. Every generated script verifies the
// binary's SHA-256 before running it, and the digest is computed here from the
// bytes on disk rather than taken from a manifest someone could edit
// independently of the file.
package agentdist

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"

	"go.uber.org/zap"
)

// Target is one platform build the server can hand out.
type Target struct {
	OS   string `json:"os"`
	Arch string `json:"arch"`

	// Label is what the console shows a human. Held here rather than in the
	// frontend so a newly supported platform needs no UI change.
	Label string `json:"label"`

	Filename string `json:"filename"`
	Size     int64  `json:"size_bytes"`
	SHA256   string `json:"sha256"`
	Version  string `json:"version,omitempty"`

	path string
}

// labels maps a Go OS/arch pair to the name an operator recognises. Apple
// silicon versus Intel is the distinction users most often get wrong, so both
// are spelled out rather than left as "arm64" and "amd64".
var labels = map[string]string{
	"windows/amd64": "Windows (64-bit)",
	"windows/arm64": "Windows (ARM64)",
	"darwin/arm64":  "macOS (Apple Silicon)",
	"darwin/amd64":  "macOS (Intel)",
	"linux/amd64":   "Linux (x86-64)",
	"linux/arm64":   "Linux (ARM64)",
}

// Store resolves a platform to a binary on disk.
//
// Scanned once at construction and cached: hashing five ~15MB binaries costs
// a few hundred milliseconds at boot, which is the right place to pay it
// rather than on an operator's first click. Refresh re-scans, so dropping in a
// new agent build needs a signal, not a redeploy.
type Store struct {
	dir     string
	logger  *zap.Logger
	mu      sync.RWMutex
	targets map[string]Target
	version string
}

func NewStore(dir string, logger *zap.Logger) *Store {
	s := &Store{dir: strings.TrimSpace(dir), logger: logger, targets: map[string]Target{}}
	if s.dir == "" {
		// Not configured: one-click enrolment is simply absent. The console
		// asks Targets() and shows nothing, rather than offering a button
		// whose only outcome is a 404.
		logger.Info("agentdist.disabled",
			zap.String("reason", "agent.binary_dir is not set; one-click agent enrolment is unavailable"))
		return s
	}
	if err := s.Refresh(); err != nil {
		logger.Warn("agentdist.scan.fail", zap.String("dir", s.dir), zap.Error(err))
	}
	return s
}

// Enabled reports whether any platform can be served.
func (s *Store) Enabled() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return len(s.targets) > 0
}

// Refresh re-scans the directory.
//
// Filenames carry the platform: pam-agent_<os>_<arch> with an optional .exe.
// Anything that does not parse is skipped with a warning rather than failing
// the scan — a stray README in the directory must not take out enrolment for
// every platform.
func (s *Store) Refresh() error {
	entries, err := os.ReadDir(s.dir)
	if err != nil {
		return fmt.Errorf("read agent binary dir: %w", err)
	}

	version := s.readVersion()
	found := map[string]Target{}

	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		name := e.Name()
		goos, arch, ok := parseName(name)
		if !ok {
			continue
		}
		full := filepath.Join(s.dir, name)
		info, err := e.Info()
		if err != nil {
			s.logger.Warn("agentdist.stat.fail", zap.String("file", name), zap.Error(err))
			continue
		}
		sum, err := hashFile(full)
		if err != nil {
			s.logger.Warn("agentdist.hash.fail", zap.String("file", name), zap.Error(err))
			continue
		}
		key := goos + "/" + arch
		label := labels[key]
		if label == "" {
			label = goos + " (" + arch + ")"
		}
		found[key] = Target{
			OS: goos, Arch: arch, Label: label,
			Filename: name, Size: info.Size(), SHA256: sum,
			Version: version, path: full,
		}
	}

	s.mu.Lock()
	s.targets = found
	s.version = version
	s.mu.Unlock()

	s.logger.Info("agentdist.scanned",
		zap.String("dir", s.dir),
		zap.Int("targets", len(found)),
		zap.String("version", version))
	return nil
}

// Targets lists what can be served, in a stable order so the console's
// platform list does not shuffle between requests.
func (s *Store) Targets() []Target {
	s.mu.RLock()
	defer s.mu.RUnlock()

	out := make([]Target, 0, len(s.targets))
	for _, t := range s.targets {
		out = append(out, t)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].OS != out[j].OS {
			return out[i].OS < out[j].OS
		}
		return out[i].Arch < out[j].Arch
	})
	return out
}

// Lookup resolves one platform.
func (s *Store) Lookup(goos, arch string) (Target, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	t, ok := s.targets[strings.ToLower(goos)+"/"+strings.ToLower(arch)]
	return t, ok
}

// Open returns the binary's bytes for streaming to a client.
//
// Re-stats and re-hashes nothing: the digest handed to the installer came from
// Targets/Lookup, and the installer verifies what it actually downloaded. If
// the file changed underneath us the operator's own check fails, which is the
// correct place for that to surface.
func (s *Store) Open(goos, arch string) (io.ReadCloser, Target, error) {
	t, ok := s.Lookup(goos, arch)
	if !ok {
		return nil, Target{}, fmt.Errorf("no agent build for %s/%s", goos, arch)
	}
	f, err := os.Open(t.path)
	if err != nil {
		return nil, Target{}, fmt.Errorf("open agent binary: %w", err)
	}
	return f, t, nil
}

// readVersion reads an optional VERSION file written by the release build.
// Absent is fine — the console then shows the platform without a version
// rather than refusing to offer it.
func (s *Store) readVersion() string {
	b, err := os.ReadFile(filepath.Join(s.dir, "VERSION"))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

// parseName extracts the platform from pam-agent_<os>_<arch>[.exe].
func parseName(name string) (goos, arch string, ok bool) {
	base := strings.TrimSuffix(name, ".exe")
	const prefix = "pam-agent_"
	if !strings.HasPrefix(base, prefix) {
		return "", "", false
	}
	parts := strings.Split(strings.TrimPrefix(base, prefix), "_")
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return "", "", false
	}
	return strings.ToLower(parts[0]), strings.ToLower(parts[1]), true
}

func hashFile(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}
