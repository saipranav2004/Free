// pam/internal/gateway/redis.go
//
// Redis connector for the in-browser terminal. Full RESP command
// passthrough via go-redis's generic Do() — whatever the user types is
// exactly the command redis-cli would send, so anything redis-cli supports
// works here too (this is deliberately NOT a limited subset, unlike the
// MongoDB connector — Redis commands are already a flat, safe-to-parse
// argument list with no embedded query language to worry about).
package gateway

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"github.com/redis/go-redis/v9"
	"github.com/yourorg/pam/internal/recorder"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// redisValueReturningCommands is every read command whose reply can BE the
// stored value itself (as opposed to an ack like "OK" or an integer count).
// Used to scope the sensitive-key redaction above to replies that could
// actually contain a secret.
var redisValueReturningCommands = map[string]bool{
	"GET": true, "MGET": true, "GETSET": true, "GETDEL": true, "GETEX": true,
	"HGET": true, "HMGET": true, "HGETALL": true, "HRANDFIELD": true,
	"LRANGE": true, "LINDEX": true, "LPOP": true, "RPOP": true,
	"SMEMBERS": true, "SRANDMEMBER": true, "SPOP": true,
	"ZRANGE": true, "ZRANGEBYSCORE": true, "ZSCORE": true, "ZPOPMIN": true, "ZPOPMAX": true,
	"GETRANGE": true, "DUMP": true, "OBJECT": true,
}

func runRedisTerminal(ctx context.Context, conn wsConn, info *services.ConnectionInfo, logCmd commandLogger, logger *zap.Logger) error {
	opts := &redis.Options{
		Addr:         fmt.Sprintf("%s:%d", info.Host, info.Port),
		Password:     info.Password,
		DialTimeout:  8 * time.Second,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 10 * time.Second,
	}
	// AccountName is the vaulted account this credential belongs to. Redis
	// ACL (Redis 6+) uses AUTH <username> <password>; legacy Redis just uses
	// AUTH <password>. go-redis's Username field is a no-op against a
	// pre-ACL server, so this is safe either way.
	if info.AccountName != "" && info.AccountName != "default" {
		opts.Username = info.AccountName
	}
	if dbNum, err := strconv.Atoi(info.DatabaseName); err == nil {
		opts.DB = dbNum
	}

	client := redis.NewClient(opts)
	defer client.Close()

	pingCtx, cancel := context.WithTimeout(ctx, 8*time.Second)
	if err := client.Ping(pingCtx).Err(); err != nil {
		cancel()
		_ = writeLine(conn, "Failed to connect to Redis: "+err.Error())
		return err
	}
	cancel()

	_ = writeLine(conn, fmt.Sprintf("Connected to Redis at %s:%d. Type commands as you would in redis-cli; type QUIT to close.", info.Host, info.Port))
	_ = conn.WriteMessage(websocket.TextMessage, []byte("redis> "))

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		_, msg, err := conn.ReadMessage()
		if err != nil {
			return err
		}
		line := strings.TrimSpace(string(msg))
		if line == "" {
			_ = conn.WriteMessage(websocket.TextMessage, []byte("redis> "))
			continue
		}
		if strings.EqualFold(line, "quit") || strings.EqualFold(line, "exit") {
			_ = writeLine(conn, "bye")
			return nil
		}

		args := splitCommandLine(line)
		if len(args) == 0 {
			_ = conn.WriteMessage(websocket.TextMessage, []byte("redis> "))
			continue
		}

		cmdStart := time.Now()
		cmdCtx, cmdCancel := context.WithTimeout(ctx, 20*time.Second)
		anyArgs := make([]interface{}, len(args))
		for i, a := range args {
			anyArgs[i] = a
		}
		result, doErr := client.Do(cmdCtx, anyArgs...).Result()
		cmdCancel()
		elapsedMs := time.Since(cmdStart).Milliseconds()

		// Redact the credential's own AUTH command from the audit trail —
		// everything else is logged verbatim, which is the whole point of
		// a PAM session terminal. recorder.MaskSecrets (applied by the
		// caller to whatever we pass here) is a generic pattern match and
		// would not catch a bare "AUTH <password>" with no key name at all,
		// which is why this protocol-specific special case still exists
		// alongside it.
		auditLine := line
		if strings.EqualFold(args[0], "auth") {
			auditLine = "AUTH ****"
		}

		// A command that merely REFERENCES a sensitive key name (GET
		// password, HGET user:1 password, ...) puts that key name in the
		// request, but Redis hands the actual secret back completely bare
		// — just the value, no key attached — in the reply. Neither
		// recorder.MaskSecrets nor a Postgres-style "redact this column"
		// approach can work on a reply with no structure to anchor on, so
		// the whole reply is withheld here instead of risking a plaintext
		// credential landing in the recording/command-log. Verified live:
		// without this, `GET password` put the real value straight into
		// both the asciicast transcript and pam_session_recording_commands.
		//
		// Scoped to commands whose reply IS (or contains) the stored
		// value — SET/DEL/EXPIRE etc. on a "password" key reply with just
		// an ack ("OK", an integer) that was never sensitive to begin with,
		// and blanking those too would make ordinary writes look broken
		// for no security benefit.
		sensitive := redisValueReturningCommands[strings.ToUpper(args[0])] && recorder.ReferencesSecretKey(line)

		if doErr != nil && doErr != redis.Nil {
			logCmd(auditLine, false, doErr.Error(), elapsedMs)
			_ = writeLine(conn, "(error) "+doErr.Error())
		} else if sensitive {
			logCmd(auditLine, true, "(redacted — command references a sensitive field)", elapsedMs)
			_ = writeLine(conn, "(redacted — this session is recorded; the value for a sensitive-looking key is not echoed or stored)")
		} else {
			logCmd(auditLine, true, formatRedisReplySummary(result), elapsedMs)
			_ = writeLine(conn, formatRedisReply(result, doErr == redis.Nil))
		}
		_ = conn.WriteMessage(websocket.TextMessage, []byte("redis> "))
	}
}

// splitCommandLine does redis-cli-style whitespace splitting with support
// for "double-quoted strings with spaces" — enough for real usage without
// pulling in a full shell-lexer dependency.
func splitCommandLine(line string) []string {
	var args []string
	var cur strings.Builder
	inQuotes := false
	for i := 0; i < len(line); i++ {
		ch := line[i]
		switch {
		case ch == '"':
			inQuotes = !inQuotes
		case ch == ' ' && !inQuotes:
			if cur.Len() > 0 {
				args = append(args, cur.String())
				cur.Reset()
			}
		default:
			cur.WriteByte(ch)
		}
	}
	if cur.Len() > 0 {
		args = append(args, cur.String())
	}
	return args
}

func formatRedisReply(v interface{}, wasNil bool) string {
	if wasNil {
		return "(nil)"
	}
	switch val := v.(type) {
	case nil:
		return "(nil)"
	case string:
		return `"` + val + `"`
	case int64:
		return "(integer) " + strconv.FormatInt(val, 10)
	case []interface{}:
		if len(val) == 0 {
			return "(empty array)"
		}
		var b strings.Builder
		for i, item := range val {
			if i > 0 {
				b.WriteString("\r\n")
			}
			b.WriteString(fmt.Sprintf("%d) %s", i+1, formatRedisReply(item, item == nil)))
		}
		return b.String()
	default:
		return fmt.Sprintf("%v", val)
	}
}

func formatRedisReplySummary(v interface{}) string {
	s := fmt.Sprintf("%v", v)
	if len(s) > 200 {
		return s[:200] + "…"
	}
	return s
}
