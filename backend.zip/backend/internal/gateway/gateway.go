// pam/internal/gateway/gateway.go
//
// The in-browser resource terminal. This is what makes "opening a resource"
// actually work over plain HTTPS with nothing installed and nothing
// pre-configured: a WebSocket connection from the browser, brokered
// entirely server-side, that speaks the target's own protocol (Redis's RESP
// command model, raw SQL over a real PostgreSQL wire connection, a
// constrained mongosh-style command subset for MongoDB). The vaulted
// credential is decrypted here, used to dial the real target, and never
// sent to the browser at any point — the browser only ever sees the
// terminal's text output.
//
// This exists specifically to close a real gap: before this package, the
// only two ways to "open" a resource were (1) copy a CLI hint and connect
// with your own locally-installed client, or (2) install and pair the
// native pam-agent. Neither is guaranteed to work everywhere — (1) assumes
// the operator's machine has redis-cli/psql/mongosh installed and reachable
// network-wise to the target, and (2) requires installing and pairing a
// separate binary first. This package is the third path that has NO such
// dependency: it works from any browser that can reach this PAM server,
// which is why ResourceHandler.ConnectInfo treats "web_terminal" as the
// default *recommended* method whenever a credential is configured and the
// resource type is one of the three protocols below — native agent and an
// embedded external console remain available as additional, optional
// methods layered on top, never as the only way in.
package gateway

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/recorder"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// SupportedResourceTypes lists every resource_type this gateway can actually
// speak a live protocol for. Kept in one place and exported so
// handlers.ResourceHandler.ConnectInfo (which decides whether to advertise
// "web_terminal" as an available method) and this package's own dispatch
// switch can never drift apart.
var SupportedResourceTypes = map[string]bool{
	"redis":      true,
	"postgresql": true,
	"mongodb":    true,
	"ssh":        true,
}

// upgrader is shared across connections — gorilla's websocket.Upgrader is
// safe for concurrent use once constructed. CheckOrigin is set explicitly
// (rather than left at the zero value, which gorilla treats as "reject
// cross-origin") to honor the same PAM_SERVER_ALLOWED_ORIGINS the REST API
// already trusts (see cfg.Server.AllowedOrigins / main.go's CORS
// middleware) — a WebSocket handshake has no CORS preflight for the browser
// to enforce on its own, so this check is the only thing standing in for
// that here.
type Handler struct {
	resources     *services.ResourceService
	audit         *services.AuditService
	allowedOrigin string
	logger        *zap.Logger
	upgrader      websocket.Upgrader

	// recordingStorage/maxCastBytes drive the screen-recording feature (see
	// recording.go and internal/recorder). recordingStorage is nil-checked
	// before use so a misconfigured/unavailable storage backend degrades to
	// "recording obligations are tracked but not captured" rather than
	// taking down every connection — see Connect's finalize step.
	recordingStorage recorder.Storage
	maxCastBytes     int64
}

func NewHandler(resources *services.ResourceService, audit *services.AuditService, allowedOrigin string, recordingStorage recorder.Storage, maxCastBytes int64, logger *zap.Logger) *Handler {
	h := &Handler{
		resources:        resources,
		audit:            audit,
		allowedOrigin:    allowedOrigin,
		recordingStorage: recordingStorage,
		maxCastBytes:     maxCastBytes,
		logger:           logger,
	}
	h.upgrader = websocket.Upgrader{
		ReadBufferSize:  4096,
		WriteBufferSize: 4096,
		CheckOrigin: func(r *http.Request) bool {
			if h.allowedOrigin == "" || h.allowedOrigin == "*" {
				return true
			}
			origin := r.Header.Get("Origin")
			if origin == "" {
				// No Origin header at all (e.g. a non-browser CLI test
				// client, or same-process testing) — nothing to check
				// against, so allow it; browsers always send Origin on a
				// cross-origin WS handshake, so this never weakens the
				// browser-facing check.
				return true
			}
			for _, allowed := range strings.Split(h.allowedOrigin, ",") {
				if strings.TrimSpace(allowed) == origin {
					return true
				}
			}
			return false
		},
	}
	return h
}

// commandLogger is how each protocol runner reports one executed
// command/query back up to Connect for audit logging (and, when the session
// is recorded, the structured command log — see session_recording_command.go),
// without any of the three connectors needing to know about AuditService,
// ConnectionSession, recordings, or gin themselves. durationMs is how long
// the command actually took against the target, measured by the runner
// itself since Connect has no visibility into where the round trip happens.
type commandLogger func(command string, ok bool, detail string, durationMs int64)

// Connect handles GET /api/v1/pam/resources/:id/connect. By the time this
// runs, the route's middleware chain (PAMAuth → RequirePermission →
// RequireActiveGrant) has already decided this specific user may connect to
// this specific resource right now — this handler's only job is to do it.
func (h *Handler) Connect(c *gin.Context) {
	resourceID := c.Param("id")
	userID, _ := c.Get("user_id")
	username, _ := c.Get("username")
	authzDecisionID, _ := c.Get("authz_decision_id")
	uid, _ := userID.(string)
	uname, _ := username.(string)
	did, _ := authzDecisionID.(string)
	grantCtx := middleware.GrantFromContext(c)

	// Connect-method policy, checked ahead of ResolveConnection so a path the
	// policy has closed never causes the vaulted credential to be decrypted.
	// See models.PAMResource.AllowedConnectMethods: this and the equivalent
	// gates in webproxy.StartSession and AgentService.ResolveLaunch are what
	// make a resource's egress controls hold, since a control enforced on one
	// path is bypassed by opening the resource on another.
	if resource, rerr := h.resources.GetResource(resourceID); rerr == nil &&
		!resource.AllowsConnectMethod(models.ConnectMethodWebTerminal) {
		h.audit.Write(services.AuditEntry{
			ActorUserID:   uid,
			ActorUsername: uname,
			Action:        models.AuditConnectMethodDenied,
			Category:      models.SessionLifecycle,
			Outcome:       models.AuditOutcomeDenied,
			Severity:      models.AuditSeverityWarn,
			ResourceID:    resourceID,
			Details: map[string]interface{}{
				"connect_method":          models.ConnectMethodWebTerminal,
				"allowed_connect_methods": resource.AllowedConnectMethods,
			},
		})
		h.logger.Warn("gateway.connect_method.denied",
			zap.String("resource_id", resourceID), zap.String("user_id", uid))
		c.JSON(http.StatusForbidden, gin.H{
			"success": false,
			"error":   "This resource cannot be opened in the browser terminal",
			"hint":    "An administrator has restricted which connect methods this resource permits.",
			"code":    "connect_method_not_allowed",
		})
		return
	}

	info, err := h.resources.ResolveConnection(resourceID)
	if err != nil {
		h.logger.Warn("gateway.resolve_connection.fail", zap.String("resource_id", resourceID), zap.Error(err))
		c.JSON(http.StatusUnprocessableEntity, gin.H{
			"success": false,
			"error":   "This resource has no credential configured yet — store one before connecting.",
		})
		return
	}
	if !SupportedResourceTypes[info.ResourceType] {
		c.JSON(http.StatusUnprocessableEntity, gin.H{
			"success": false,
			"error":   fmt.Sprintf("The in-browser terminal does not support resource type %q yet. Use the console link or the native agent for this resource.", info.ResourceType),
			"code":    "web_terminal_unsupported",
		})
		return
	}

	conn, err := h.upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		// Upgrade already wrote its own error response — nothing more to do.
		h.logger.Warn("gateway.upgrade.fail", zap.Error(err))
		return
	}
	defer conn.Close()

	session, recording, err := h.resources.StartTrackedSession(services.StartSessionInput{
		UserID:            uid,
		Username:          uname,
		ResourceID:        resourceID,
		SourceIP:          c.ClientIP(),
		Protocol:          info.ResourceType,
		AuthzDecisionID:   did,
		GrantID:           grantCtx.GrantID,
		JITRequestID:      grantCtx.JITRequestID,
		IsBreakglass:      grantCtx.IsBreakglass,
		RecordingRequired: grantCtx.RecordingRequired,
	})
	if err != nil {
		h.logger.Error("gateway.session.start.fail", zap.Error(err))
		_ = conn.WriteMessage(websocket.TextMessage, []byte("\r\n*** Unable to start a tracked session — connection refused. ***\r\n"))
		return
	}

	// When this session carries a recording obligation (resource.AlwaysRecord,
	// break-glass, or a grant that requires it — see StartTrackedSession),
	// every message from here on goes through activeConn instead of the raw
	// conn, so it also lands in cast. h.recordingStorage being nil (e.g.
	// local disk unavailable at startup) degrades to "obligation tracked,
	// not captured" rather than refusing the connection — losing a
	// recording is a compliance gap to flag, not a reason to deny a user
	// access they are otherwise entitled to.
	var activeConn wsConn = conn
	var cast *recorder.Cast
	if recording != nil && h.recordingStorage != nil {
		cast = recorder.NewCast(120, 40, fmt.Sprintf("PAM %s session — %s", info.ResourceType, info.ResourceName), h.maxCastBytes)
		activeConn = NewRecordingConn(conn, cast)
		if markErr := h.resources.MarkRecordingActive(recording.ID); markErr != nil {
			h.logger.Warn("gateway.recording.mark_active.fail", zap.String("recording_id", recording.ID), zap.Error(markErr))
		}
	} else if recording != nil {
		h.logger.Warn("gateway.recording.storage_unavailable", zap.String("recording_id", recording.ID), zap.String("session_id", session.ID))
		_ = h.resources.MarkRecordingFailed(recording.ID, "recording storage was not configured/available when this session opened")
	}

	ctx, cancel := context.WithCancel(context.Background())
	h.resources.RegisterLiveSession(session.ID, cancel)
	defer h.resources.UnregisterLiveSession(session.ID)

	// A kill (admin action or grant revoke/expiry) calls the cancel func
	// registered above; the only thing that actually unblocks the
	// protocol runner's blocking reads below is closing the socket itself.
	go func() {
		<-ctx.Done()
		_ = activeConn.WriteMessage(websocket.TextMessage, []byte("\r\n*** Session terminated by an administrator or an expired/revoked grant. ***\r\n"))
		_ = conn.Close()
	}()

	h.audit.Write(services.AuditEntry{
		ActorUserID:     uid,
		ActorUsername:   uname,
		Action:          models.AuditSessionStarted,
		Category:        models.SessionLifecycle,
		ResourceType:    info.ResourceType,
		ResourceID:      resourceID,
		ResourceName:    info.ResourceName,
		SessionID:       session.ID,
		GrantID:         grantCtx.GrantID,
		RequestID:       grantCtx.JITRequestID,
		SourceIP:        c.ClientIP(),
		UserAgent:       c.Request.UserAgent(),
		AuthzDecisionID: did,
		Details: map[string]interface{}{
			"transport":          "web_terminal",
			"grant_required":     grantCtx.Required,
			"is_breakglass":      grantCtx.IsBreakglass,
			"recording_required": grantCtx.RecordingRequired,
		},
	})
	if recording != nil {
		_ = activeConn.WriteMessage(websocket.TextMessage, []byte("*** This session is recorded. ***\r\n"))
	}

	var cmdSeq int
	logCommand := func(command string, ok bool, detail string, durationMs int64) {
		outcome := models.AuditOutcomeSuccess
		if !ok {
			outcome = models.AuditOutcomeFailure
		}
		// Masked once, then reused for BOTH the audit trail and the
		// recording's structured command log — a raw password sitting in
		// the org-wide audit feed would be exactly as bad as one sitting in
		// a recording.
		masked := recorder.MaskSecrets(command)
		h.audit.Write(services.AuditEntry{
			ActorUserID:   uid,
			ActorUsername: uname,
			Action:        "RESOURCE_TERMINAL_COMMAND",
			Category:      models.ResourceLifecycle,
			Outcome:       outcome,
			ResourceType:  info.ResourceType,
			ResourceID:    resourceID,
			ResourceName:  info.ResourceName,
			SessionID:     session.ID,
			SourceIP:      c.ClientIP(),
			Details: map[string]interface{}{
				"command":     masked,
				"detail":      detail,
				"duration_ms": durationMs,
			},
		})
		if recording != nil {
			cmdSeq++
			if err := h.resources.AppendRecordingCommand(&models.SessionRecordingCommand{
				RecordingID:   recording.ID,
				SessionID:     session.ID,
				Sequence:      cmdSeq,
				Input:         masked,
				InputMasked:   masked != command,
				Outcome:       string(outcome),
				OutputSummary: detail,
				DurationMs:    durationMs,
				OccurredAt:    time.Now().UTC(),
			}); err != nil {
				h.logger.Warn("gateway.recording.command.append.fail", zap.String("recording_id", recording.ID), zap.Error(err))
			}
		}
	}

	runErr := h.dispatch(ctx, activeConn, info, logCommand)

	// Best-effort graceful WS close (client sees code 1000 instead of an
	// abrupt 1006) — harmless to attempt even if the socket already died
	// on its own (a write to a dead connection just errors, which we
	// discard) or was already force-closed by the kill goroutine above.
	_ = activeConn.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))

	now := time.Now().UTC()
	// allowAnyOwner=true: whoever/whatever is ending this session at this
	// point (the socket closing on its own, or the kill goroutine having
	// just force-closed it) IS the session's own owner by construction —
	// this handler only ever ends the one session it itself just opened.
	_, endErr := h.resources.EndTrackedSession(session.ID, uid, true)
	if endErr != nil {
		h.logger.Error("gateway.session.end.fail", zap.Error(endErr))
	}
	h.audit.Write(services.AuditEntry{
		ActorUserID:   uid,
		ActorUsername: uname,
		Action:        models.AuditSessionEnded,
		Category:      models.SessionLifecycle,
		ResourceType:  info.ResourceType,
		ResourceID:    resourceID,
		ResourceName:  info.ResourceName,
		SessionID:     session.ID,
		SourceIP:      c.ClientIP(),
		OccurredAt:    now,
		Details: map[string]interface{}{
			"transport": "web_terminal",
			"error":     errString(runErr),
		},
	})

	if recording != nil && cast != nil {
		h.finalizeRecording(recording.ID, session.ID, uid, uname, info, cast)
	}
}

// finalizeRecording persists the finished cast to storage and records the
// outcome on the SessionRecording row. Runs after the WebSocket has already
// closed and the session has already been marked COMPLETED/KILLED — nothing
// here can affect the user's actual session anymore, which is deliberate:
// a storage failure at this point is purely a compliance-visibility problem
// for an admin, never a reason the user's work should have been blocked.
func (h *Handler) finalizeRecording(recordingID, sessionID, uid, uname string, info *services.ConnectionInfo, cast *recorder.Cast) {
	gz, sha256Hex, size, err := cast.Finalize()
	if err != nil {
		h.logger.Error("gateway.recording.finalize.encode_fail", zap.String("recording_id", recordingID), zap.Error(err))
		_ = h.resources.MarkRecordingFailed(recordingID, "failed to encode recording: "+err.Error())
		h.audit.Write(services.AuditEntry{
			ActorUserID: uid, ActorUsername: uname, Action: models.AuditRecordingFailed,
			Category: models.SessionLifecycle, Outcome: models.AuditOutcomeFailure,
			ResourceType: info.ResourceType, ResourceID: info.ResourceID, ResourceName: info.ResourceName,
			SessionID: sessionID, Details: map[string]interface{}{"reason": err.Error()},
		})
		return
	}

	key := fmt.Sprintf("recordings/%s/%s.cast.gz", time.Now().UTC().Format("2006/01/02"), recordingID)
	if err := h.recordingStorage.Save(context.Background(), key, gz); err != nil {
		h.logger.Error("gateway.recording.finalize.save_fail", zap.String("recording_id", recordingID), zap.String("key", key), zap.Error(err))
		_ = h.resources.MarkRecordingFailed(recordingID, "failed to persist recording: "+err.Error())
		h.audit.Write(services.AuditEntry{
			ActorUserID: uid, ActorUsername: uname, Action: models.AuditRecordingFailed,
			Category: models.SessionLifecycle, Outcome: models.AuditOutcomeFailure,
			ResourceType: info.ResourceType, ResourceID: info.ResourceID, ResourceName: info.ResourceName,
			SessionID: sessionID, Details: map[string]interface{}{"reason": err.Error()},
		})
		return
	}

	truncated := cast.Truncated()
	if err := h.resources.AttachRecordingArtifact(recordingID, h.recordingStorage.Label(), key, size, sha256Hex, truncated); err != nil {
		h.logger.Error("gateway.recording.finalize.attach_fail", zap.String("recording_id", recordingID), zap.Error(err))
		return
	}
	h.audit.Write(services.AuditEntry{
		ActorUserID: uid, ActorUsername: uname, Action: models.AuditRecordingSaved,
		Category: models.SessionLifecycle, Outcome: models.AuditOutcomeSuccess,
		ResourceType: info.ResourceType, ResourceID: info.ResourceID, ResourceName: info.ResourceName,
		SessionID: sessionID, Details: map[string]interface{}{
			"storage_key": key, "size_bytes": size, "truncated": truncated,
		},
	})
}

func (h *Handler) dispatch(ctx context.Context, conn wsConn, info *services.ConnectionInfo, logCmd commandLogger) error {
	switch info.ResourceType {
	case "redis":
		return runRedisTerminal(ctx, conn, info, logCmd, h.logger)
	case "postgresql":
		return runPostgresTerminal(ctx, conn, info, logCmd, h.logger)
	case "mongodb":
		return runMongoTerminal(ctx, conn, info, logCmd, h.logger)
	case "ssh":
		return runSSHTerminal(ctx, conn, info, logCmd, h.logger)
	default:
		_ = conn.WriteMessage(websocket.TextMessage, []byte("Unsupported resource type.\r\n"))
		return fmt.Errorf("unsupported resource type %q", info.ResourceType)
	}
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

// writeLine sends one line of terminal output, appending the CRLF a real
// terminal (and xterm.js on the frontend) expects.
func writeLine(conn wsConn, s string) error {
	return conn.WriteMessage(websocket.TextMessage, []byte(s+"\r\n"))
}
