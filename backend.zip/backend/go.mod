module github.com/yourorg/pam

go 1.25.0

// NOTE ON THE replace DIRECTIVES BELOW:
//
// This module was assembled and built in a network-restricted sandbox that
// blocks proxy.golang.org and several "vanity" module domains (gorm.io,
// go.uber.org, golang.org, gopkg.in) at the DNS/HTTP level, while allowing
// direct access to github.com. Each replace below points a vanity-domain
// module path at its real GitHub source, with GOPROXY=direct and
// GOSUMDB=off, so `go build ./...` / `go vet ./...` / `go test ./...` could
// actually be run end-to-end during this merge (all three pass clean).
//
// These replaces are safe to keep on a normal machine with full internet
// access too — Go's module system explicitly supports substituting a
// different source location for a required module regardless of that
// module's own internal path declaration. They are NOT required there,
// though: if you have unrestricted access to proxy.golang.org, you can
// delete every `replace` line below and run `go mod tidy` to resolve
// everything through the normal module proxy instead. Left in place by
// default so `go build` works out of the box in either environment.

require (
	github.com/boombuler/barcode v1.0.2
	github.com/gin-gonic/gin v1.10.0
	github.com/glebarez/sqlite v1.11.0
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.3
	github.com/jackc/pgx/v5 v5.5.5
	github.com/joho/godotenv v1.5.1
	github.com/jung-kurt/gofpdf v1.16.2
	github.com/minio/minio-go/v7 v7.2.1
	github.com/pquerna/otp v1.4.0
	github.com/redis/go-redis/v9 v9.22.0
	github.com/spf13/viper v1.19.0
	go.mongodb.org/mongo-driver v0.0.0-00010101000000-000000000000
	go.uber.org/zap v1.27.0
	golang.org/x/crypto v0.51.0
	gorm.io/driver/postgres v1.5.9
	gorm.io/gorm v1.25.12
)

require (
	github.com/bytedance/sonic v1.11.6 // indirect
	github.com/bytedance/sonic/loader v0.1.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/cloudwego/base64x v0.1.4 // indirect
	github.com/cloudwego/iasm v0.2.0 // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/fsnotify/fsnotify v1.7.0 // indirect
	github.com/gabriel-vasile/mimetype v1.4.3 // indirect
	github.com/gin-contrib/sse v0.1.0 // indirect
	github.com/glebarez/go-sqlite v1.21.2 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/go-playground/validator/v10 v10.20.0 // indirect
	github.com/goccy/go-json v0.10.2 // indirect
	github.com/golang/snappy v0.0.4 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20221227161230-091c0ba34f0a // indirect
	github.com/jackc/puddle/v2 v2.2.1 // indirect
	github.com/jinzhu/inflection v1.0.0 // indirect
	github.com/jinzhu/now v1.1.5 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/klauspost/compress v1.18.6 // indirect
	github.com/klauspost/cpuid/v2 v2.2.11 // indirect
	github.com/klauspost/crc32 v1.3.0 // indirect
	github.com/leodido/go-urn v1.4.0 // indirect
	github.com/magiconair/properties v1.8.7 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/minio/crc64nvme v1.1.1 // indirect
	github.com/minio/md5-simd v1.1.2 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/montanaflynn/stats v0.7.1 // indirect
	github.com/niemeyer/pretty v0.0.0-20200227124842-a10e7caefd8e // indirect
	github.com/pelletier/go-toml/v2 v2.3.1 // indirect
	github.com/philhofer/fwd v1.2.0 // indirect
	github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec // indirect
	github.com/rs/xid v1.6.0 // indirect
	github.com/sagikazarmark/locafero v0.4.0 // indirect
	github.com/sagikazarmark/slog-shim v0.1.0 // indirect
	github.com/sourcegraph/conc v0.3.0 // indirect
	github.com/spf13/afero v1.15.0 // indirect
	github.com/spf13/cast v1.6.0 // indirect
	github.com/spf13/pflag v1.0.10 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	github.com/tinylib/msgp v1.6.1 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	github.com/ugorji/go/codec v1.2.12 // indirect
	github.com/xdg-go/pbkdf2 v1.0.0 // indirect
	github.com/xdg-go/scram v1.1.2 // indirect
	github.com/xdg-go/stringprep v1.0.4 // indirect
	github.com/youmark/pkcs8 v0.0.0-20240726163527-a2c0da244d78 // indirect
	github.com/zeebo/xxh3 v1.1.0 // indirect
	go.uber.org/atomic v1.11.0 // indirect
	go.uber.org/multierr v1.10.0 // indirect
	go.yaml.in/yaml/v3 v3.0.4 // indirect
	golang.org/x/arch v0.8.0 // indirect
	golang.org/x/exp v0.0.0-20230905200255-921286631fa9 // indirect
	golang.org/x/net v0.53.0 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.44.0 // indirect
	golang.org/x/text v0.37.0 // indirect
	google.golang.org/protobuf v1.36.10 // indirect
	gopkg.in/ini.v1 v1.67.2 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
	modernc.org/libc v1.22.5 // indirect
	modernc.org/mathutil v1.5.0 // indirect
	modernc.org/memory v1.5.0 // indirect
	modernc.org/sqlite v1.23.1 // indirect
)

replace golang.org/x/arch => github.com/golang/arch v0.8.0

replace golang.org/x/image => github.com/golang/image v0.18.0

replace golang.org/x/text => github.com/golang/text v0.16.0

replace golang.org/x/net => github.com/golang/net v0.30.0

replace golang.org/x/sys => github.com/golang/sys v0.26.0

replace golang.org/x/sync => github.com/golang/sync v0.9.0

replace golang.org/x/tools => github.com/golang/tools v0.1.12

replace golang.org/x/mod => github.com/golang/mod v0.21.0

replace golang.org/x/term => github.com/golang/term v0.25.0

replace go.uber.org/zap => github.com/uber-go/zap v1.27.0

replace go.uber.org/multierr => github.com/uber-go/multierr v1.11.0

// go-redis/v9's connection pool imports go.uber.org/atomic; same
// vanity-domain block as every other go.uber.org/* import in this file.
replace go.uber.org/atomic => github.com/uber-go/atomic v1.11.0

// go.mongodb.org/mongo-driver is itself a vanity import (mongodb's own
// domain, blocked the same way golang.org/gorm.io/go.uber.org are above) —
// its real source lives on GitHub under the driver's pre-rename path.
replace go.mongodb.org/mongo-driver => github.com/mongodb/mongo-go-driver v1.17.1

replace gorm.io/gorm => github.com/go-gorm/gorm v1.25.12

replace gorm.io/driver/postgres => github.com/go-gorm/postgres v1.5.9

replace golang.org/x/crypto => github.com/golang/crypto v0.31.0

replace golang.org/x/telemetry => github.com/golang/telemetry v0.0.0-20241106142447-58a1122356f6

replace golang.org/x/exp => github.com/golang/exp v0.0.0-20241108190413-2d47ceb2692f

replace gopkg.in/yaml.v3 => github.com/go-yaml/yaml v3.0.1+incompatible

replace gopkg.in/yaml.v2 => github.com/go-yaml/yaml v2.4.0+incompatible

replace gopkg.in/check.v1 => github.com/go-check/check v0.0.0-20200902074654-038fdea0a05b

replace google.golang.org/protobuf => github.com/protocolbuffers/protobuf-go v1.35.2

replace gopkg.in/ini.v1 => github.com/go-ini/ini v1.67.0
