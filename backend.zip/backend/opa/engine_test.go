package opa

import "testing"

func TestEvaluate_RootBypassesEverything(t *testing.T) {
	e := New()
	d := e.Evaluate(Input{UserID: "u1", IsRoot: true, Action: "pam:vault:Reveal", Resource: "pam:vault/x"})
	if !d.Allowed {
		t.Fatalf("expected root to bypass, got denied: %+v", d)
	}
	if d.Reason != "root_bypass" {
		t.Errorf("expected reason root_bypass, got %q", d.Reason)
	}
}

func TestEvaluate_DefaultDenyWithNoPolicies(t *testing.T) {
	e := New()
	d := e.Evaluate(Input{UserID: "u1", Action: "pam:resource:List", Resource: "pam:*"})
	if d.Allowed {
		t.Fatalf("expected default deny with no policies, got allowed: %+v", d)
	}
	if d.Reason != "default_deny_no_matching_policy" {
		t.Errorf("unexpected reason: %q", d.Reason)
	}
}

func TestEvaluate_AllowPolicyMatches(t *testing.T) {
	e := New()
	d := e.Evaluate(Input{
		UserID: "u1", Action: "pam:resource:List", Resource: "pam:*",
		Policies: []PolicyDoc{
			{Name: "standard-user", Effect: EffectAllow, Actions: []string{"pam:resource:List"}, Resources: []string{"*"}},
		},
	})
	if !d.Allowed || d.MatchedPolicy != "standard-user" {
		t.Fatalf("expected allow via standard-user policy, got %+v", d)
	}
}

func TestEvaluate_ExplicitDenyOverridesAllow(t *testing.T) {
	e := New()
	d := e.Evaluate(Input{
		UserID: "u1", Action: "pam:vault:Reveal", Resource: "pam:vault/prod-db",
		Policies: []PolicyDoc{
			{Name: "full-access", Effect: EffectAllow, Actions: []string{"*"}, Resources: []string{"*"}},
			{Name: "deny-prod-reveal", Effect: EffectDeny, Actions: []string{"pam:vault:Reveal"}, Resources: []string{"pam:vault/prod-*"}},
		},
	})
	if d.Allowed {
		t.Fatalf("expected explicit deny to win over allow, got %+v", d)
	}
	if d.Reason != "explicit_deny" || d.MatchedPolicy != "deny-prod-reveal" {
		t.Errorf("unexpected decision: %+v", d)
	}
}

func TestEvaluate_WildcardActionAndResourceSuffix(t *testing.T) {
	e := New()
	cases := []struct {
		name      string
		action    string
		resource  string
		actionPat string
		resPat    string
		want      bool
	}{
		{"action wildcard matches", "pam:vault:Rotate", "pam:vault/abc", "pam:vault:*", "*", true},
		{"resource prefix wildcard matches", "pam:resource:Read", "pam:resource/abc-123", "pam:resource:Read", "pam:resource/*", true},
		{"no match falls through to deny", "pam:audit:Verify", "pam:audit/verify", "pam:vault:*", "*", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			d := e.Evaluate(Input{
				UserID: "u1", Action: tc.action, Resource: tc.resource,
				Policies: []PolicyDoc{{Name: "p", Effect: EffectAllow, Actions: []string{tc.actionPat}, Resources: []string{tc.resPat}}},
			})
			if d.Allowed != tc.want {
				t.Errorf("%s: got allowed=%v, want %v (%+v)", tc.name, d.Allowed, tc.want, d)
			}
		})
	}
}

func TestEvaluate_MissingActionIsDenied(t *testing.T) {
	e := New()
	d := e.Evaluate(Input{UserID: "u1", Resource: "pam:*"})
	if d.Allowed || d.Reason != "missing_action" {
		t.Fatalf("expected missing_action deny, got %+v", d)
	}
}

func TestDefaultSeedBundle_ParsesAndShapesLookSane(t *testing.T) {
	bundle, err := DefaultSeedBundle()
	if err != nil {
		t.Fatalf("DefaultSeedBundle() error: %v", err)
	}
	if len(bundle.Roles) == 0 {
		t.Fatal("expected at least one seeded role")
	}
	names := map[string]bool{}
	for _, r := range bundle.Roles {
		names[r.Name] = true
	}
	for _, want := range []string{"root", "admin", "user"} {
		if !names[want] {
			t.Errorf("expected seeded role %q to be present", want)
		}
	}
	if len(bundle.Policies) == 0 {
		t.Fatal("expected at least one seeded policy")
	}
	for _, p := range bundle.Policies {
		if len(p.AttachToRoles) == 0 {
			t.Errorf("seed policy %q has no attach_to_roles — it would never apply to anyone", p.Name)
		}
	}
}
