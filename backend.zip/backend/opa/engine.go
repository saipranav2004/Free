// pam/opa/engine.go
//
// PAM's embedded policy decision engine — the PDP (Policy Decision Point)
// that replaces the external IAM service's /api/v1/authz/check call. This is
// the "OPA as rule engine" piece: PAM now owns authorization end to end, with
// zero runtime dependency on any other service.
//
// ── WHY THIS IS A HAND-WRITTEN ENGINE, NOT THE UPSTREAM OPA GO MODULE ──
//
// The upstream github.com/open-policy-agent/opa module was evaluated for
// this package first, since "OPA" was the explicit ask. It was not used,
// for two concrete, reproducible reasons found while actually trying it:
//
//  1. The current release line requires Go >= 1.25 and, the moment the Go
//     toolchain tries to self-upgrade to satisfy that, it fetches
//     https://golang.org/toolchain — a domain this build environment (and
//     plausibly other locked-down CI/build environments) cannot reach.
//  2. Older release lines (which target Go 1.24) pull a large transitive
//     dependency graph (OpenTelemetry SDK, Prometheus client, sigs.k8s.io/
//     yaml, and more) purely to support OPA's HTTP server, bundle format,
//     and decision-log features PAM does not use. Attempting to vendor it
//     here produced a hard module-graph conflict: this module's existing
//     `replace gopkg.in/ini.v1 => github.com/go-ini/ini` directive (needed
//     for the network-restricted sandbox this repo was assembled in — see
//     go.mod's own top comment) collides with OPA's own ini dependency,
//     and `go get` fails outright (verified: exit status 1, "used for two
//     different module paths").
//
// Given "production-grade, zero dependency on another service, no config
// error" were the explicit requirements, shipping a dependency that is
// demonstrably fragile to resolve — in THIS environment and plausibly in
// others with similar restrictions — was judged the wrong trade-off for a
// decision this simple: default-deny, explicit-deny-overrides-allow,
// wildcard segment matching over a small actions+resources policy list.
// That is exactly OPA's own recommended authorization pattern; this package
// reimplements just that evaluation semantics, in pure Go, with zero
// third-party imports.
//
// The public surface (Engine.Evaluate, taking a fully-resolved Input and
// returning a Decision) is intentionally narrow and self-contained. If a
// future environment has reliable, unrestricted access to the upstream
// module and wants the full Rego language, bundle API, or decision logs,
// swapping this package's internals for a real rego.PreparedEvalQuery is a
// one-file change — every caller (internal/services/policy_engine_service.go)
// already talks to this package through Input/Decision only.
package opa

import (
	"crypto/rand"
	"encoding/hex"
	"strings"
)

// Effect is a policy's disposition when it matches a request.
type Effect string

const (
	EffectAllow Effect = "allow"
	EffectDeny  Effect = "deny"
)

// PolicyDoc is one policy statement, already resolved to apply to the
// current principal (via direct attachment or role membership) by the
// caller — this package does no database access itself.
type PolicyDoc struct {
	Name      string
	Effect    Effect
	Actions   []string // e.g. "pam:vault:Read", "pam:vault:*", "*"
	Resources []string // e.g. "pam:resource/abc-123", "pam:resource/*", "*"
}

// Input is one authorization question.
type Input struct {
	UserID string
	// IsRoot bypasses policy evaluation entirely when true. This is a
	// hard-coded, always-on escape hatch for the seeded root/superuser
	// account — defense in depth, independent of whatever the Policy table
	// currently contains (a corrupted or over-eagerly-tightened policy set
	// must never be able to lock the root account out of its own system).
	IsRoot   bool
	Action   string
	Resource string
	Policies []PolicyDoc
}

// Decision is the answer to one Input, structurally similar to the old
// iamclient.AuthzResponse.Data shape so the calling middleware's audit
// logging didn't need to change field names.
type Decision struct {
	Allowed       bool
	Reason        string
	MatchedPolicy string
	DecisionID    string
}

// Engine evaluates Input against policy documents. Stateless and safe for
// concurrent use — it holds no mutable state and talks to nothing external.
type Engine struct{}

// New constructs the engine. Takes no arguments (nothing to configure) —
// kept as a constructor rather than a bare zero-value for symmetry with the
// rest of the codebase's service constructors, and to leave room for future
// options (e.g. a decision-log sink) without changing every call site.
func New() *Engine {
	return &Engine{}
}

// Evaluate applies AWS-IAM-style semantics: default deny, any matching
// explicit deny wins outright, otherwise any matching allow wins, otherwise
// deny. Root bypasses evaluation entirely.
func (e *Engine) Evaluate(input Input) Decision {
	decisionID := newDecisionID()

	if input.Action == "" {
		return Decision{Allowed: false, Reason: "missing_action", DecisionID: decisionID}
	}

	if input.IsRoot {
		return Decision{Allowed: true, Reason: "root_bypass", DecisionID: decisionID}
	}

	var matchedAllow *PolicyDoc
	for i := range input.Policies {
		p := &input.Policies[i]
		if !matchesAny(p.Actions, input.Action) {
			continue
		}
		if !matchesAny(p.Resources, input.Resource) {
			continue
		}
		if p.Effect == EffectDeny {
			// Explicit deny always wins — stop evaluating immediately,
			// regardless of any allow that matched earlier or would match
			// later. This mirrors OPA's own recommended "deny overrides"
			// composition pattern and AWS IAM's evaluation logic.
			return Decision{
				Allowed:       false,
				Reason:        "explicit_deny",
				MatchedPolicy: p.Name,
				DecisionID:    decisionID,
			}
		}
		if p.Effect == EffectAllow && matchedAllow == nil {
			matchedAllow = p
		}
	}

	if matchedAllow != nil {
		return Decision{
			Allowed:       true,
			Reason:        "policy_allow",
			MatchedPolicy: matchedAllow.Name,
			DecisionID:    decisionID,
		}
	}

	return Decision{Allowed: false, Reason: "default_deny_no_matching_policy", DecisionID: decisionID}
}

// matchesAny reports whether value matches at least one pattern.
// Supported pattern forms:
//   - "*"            matches anything
//   - exact string    matches only that exact value
//   - "prefix*"      matches any value starting with "prefix" (a single
//     trailing wildcard segment — e.g. "pam:vault:*" matches
//     "pam:vault:Read"; "pam:resource/*" matches "pam:resource/abc-123")
func matchesAny(patterns []string, value string) bool {
	for _, pattern := range patterns {
		if matchOne(pattern, value) {
			return true
		}
	}
	return false
}

func matchOne(pattern, value string) bool {
	if pattern == "*" || pattern == value {
		return true
	}
	if strings.HasSuffix(pattern, "*") {
		prefix := strings.TrimSuffix(pattern, "*")
		return strings.HasPrefix(value, prefix)
	}
	return false
}

// newDecisionID generates a short, non-sequential correlation ID for audit
// logs. Not a UUID (no need to pull the uuid package into this
// zero-dependency package) — 8 random bytes hex-encoded is plenty of
// entropy for a log-correlation token that is never used as a security
// boundary.
func newDecisionID() string {
	b := make([]byte, 8)
	if _, err := rand.Read(b); err != nil {
		return "decision-unavailable"
	}
	return "opa-" + hex.EncodeToString(b)
}
