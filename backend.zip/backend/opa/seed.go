// pam/opa/seed.go
//
// The default role/policy bundle every fresh PAM install starts with. This
// is DATA, not code — internal/services/seed_service.go reads it once at
// startup and idempotently upserts the roles/policies/attachments it
// describes into the database, where the real RBAC/PBAC (Identity, Roles,
// Policies) admin-center screens then take over as the source of truth.
//
// Embedded via go:embed (not read from disk at runtime) so the binary is
// self-contained and this bundle can never go missing in a deployment that
// only ships the compiled binary — "zero dependency" applies here too.
package opa

import (
	_ "embed"
	"encoding/json"
	"fmt"
)

//go:embed policies/default_bundle.json
var defaultBundleJSON []byte

// SeedRole is one role in the default bundle.
type SeedRole struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	IsSystem    bool   `json:"is_system"`
}

// SeedPolicy is one policy in the default bundle, plus the role names it
// should be attached to on first seed.
type SeedPolicy struct {
	Name          string   `json:"name"`
	Description   string   `json:"description"`
	Effect        string   `json:"effect"`
	Actions       []string `json:"actions"`
	Resources     []string `json:"resources"`
	IsSystem      bool     `json:"is_system"`
	AttachToRoles []string `json:"attach_to_roles"`
}

// SeedBundle is the full default bundle shape.
type SeedBundle struct {
	Roles    []SeedRole   `json:"roles"`
	Policies []SeedPolicy `json:"policies"`
}

// DefaultSeedBundle parses and returns the embedded bundle. Returns an error
// rather than panicking so a corrupted embed (which should be impossible —
// it's compiled into the binary — but "should be impossible" is not a
// substitute for handling it) surfaces as a clear startup failure instead of
// a crash deep in a request handler.
func DefaultSeedBundle() (SeedBundle, error) {
	var bundle SeedBundle
	if err := json.Unmarshal(defaultBundleJSON, &bundle); err != nil {
		return SeedBundle{}, fmt.Errorf("opa: failed to parse embedded default policy bundle: %w", err)
	}
	return bundle, nil
}
