// pam/pkg/auditchain/chain.go
//
// auditchain implements the Merkle-style hash chain used by the audit log.
//
// Why a hash chain, not just an append-only table?
//   - An append-only table stops honest mistakes (a bug that writes UPDATE).
//   - It does NOT stop an attacker with DB access: they can issue UPDATE/DELETE
//     directly via psql if they have the role.
//   - Hash chaining makes any such modification detectable: changing any row
//     changes its EntryHash, which breaks the PrevHash link in the next row.
//   - With HMAC-SHA256 (key from a secret), the attacker also can't forge a
//     new valid chain without the key, even with full DB access. This is
//     deliberately stronger than a keyless SHA-256 concatenation (which a
//     second, independent implementation of this same idea used before the
//     merge) — a reader with plain DB access cannot forge a valid entry_hash
//     for a keyless scheme, because there is no secret involved at all.
//
// Timestamp canonical form (IMPORTANT — do not change without bumping
// CurrentCanonicalVersion and writing a migration for old rows):
//
//	We format OccurredAt as millisecond-precision UTC using a fixed-width
//	format: "2006-01-02T15:04:05.000Z". The trailing three zeros are ALWAYS
//	present, making the string length constant regardless of the actual
//	sub-millisecond value.
//
//	Why not RFC3339Nano?
//	  RFC3339Nano strips trailing zeros. Go time.Now() has nanosecond
//	  resolution; PostgreSQL timestamptz stores microseconds. When a
//	  nanosecond-precision time is stored and read back, the nanosecond
//	  digits are lost. RFC3339Nano then produces different strings for
//	  the write-time and verify-time values, breaking the HMAC even though
//	  the data was never tampered with.
//
//	Why milliseconds and not microseconds?
//	  JSON/HTTP layers commonly round timestamps to milliseconds.
//	  Millisecond precision is the lowest common denominator that survives
//	  every serialization path. Sub-millisecond audit precision is not
//	  operationally meaningful.
//
//	Truncation happens in Compute() — callers do NOT need to pre-truncate.
//	services.AuditService's appendTx core also re-reads the row it just
//	built through the same canonicalTime() before returning, so the value
//	in the DB and the value that was hashed always agree.
//
// Schema history:
//
//	v1 — original compliance-branch field set (org/user/category/resource/
//	     justification form).
//	v2 (current) — adds Severity, ActorType, ResourceType, ResourceID,
//	     ResourceName, GrantID (the JIT branch's structured lifecycle-event
//	     fields) as first-class hashed columns instead of leaving them
//	     unhashed/out-of-band. Existing v1 rows remain verifiable: VerifyRow
//	     is only ever called with the Inputs shape matching the row's own
//	     HashVersion in practice, since this is a fresh merge with no live
//	     v1 production data — but the version field is bumped anyway so any
//	     future schema change has a real precedent to follow.
package auditchain

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"strconv"
	"strings"
	"time"
)

// GenesisHash is the sentinel "previous hash" for the very first row.
// 64 lowercase hex characters — the same length a real SHA-256 hex digest
// would have, so it can never accidentally collide with (or be mistaken
// for a truncated/corrupted form of) a genuinely computed hash.
//
// BUGFIX: this used to be a 68-character string (four zeros too many), which
// meant it could never be mistaken for a valid hash for a different, more
// alarming reason — its length alone gave away that it wasn't one. Written
// out as a literal (not a slice expression) because Go does not allow
// string-slicing in a const initializer.
const GenesisHash = "0000000000000000000000000000000000000000000000000000000000000000"

// CurrentCanonicalVersion — bump whenever the canonical field layout changes.
// The verifier reads it from the row (HashVersion) and would dispatch to the
// right builder if multiple versions were ever live simultaneously.
const CurrentCanonicalVersion = 2

// canonicalTimeFormat is a fixed-width millisecond-precision UTC layout.
// "Z" suffix is hardcoded — we always convert to UTC before formatting.
// The three decimal digits are ALWAYS present (no trailing-zero stripping).
//
// Do not use time.RFC3339Nano here — it strips trailing zeros and produces
// variable-length strings that break HMAC stability across DB round-trips.
const canonicalTimeFormat = "2006-01-02T15:04:05.000Z"

// CanonicalRecord is the deterministic JSON form fed to the HMAC.
// Field order in the JSON output is determined by Go's struct field order
// (json.Marshal outputs fields in declaration order for structs).
// Key names are frozen — changing any name requires a version bump.
//
// Must NOT include EntryHash (chicken-and-egg).
// Must NOT include any field computed from other fields.
type CanonicalRecord struct {
	Version         int    `json:"v"`
	OrgID           string `json:"org_id"`
	SequenceNumber  int64  `json:"seq"`
	UserID          string `json:"user_id"`
	Username        string `json:"username"`
	Email           string `json:"email"`
	ServiceName     string `json:"service_name,omitempty"`
	ActorType       string `json:"actor_type,omitempty"`
	Category        string `json:"category"`
	Action          string `json:"action"`
	Outcome         string `json:"outcome"`
	Severity        string `json:"severity,omitempty"`
	Resource        string `json:"resource"`
	ResourceType    string `json:"resource_type,omitempty"`
	ResourceID      string `json:"resource_id,omitempty"`
	ResourceName    string `json:"resource_name,omitempty"`
	Details         string `json:"details"`
	Justification   string `json:"justification,omitempty"`
	SourceIP        string `json:"source_ip"`
	UserAgent       string `json:"user_agent"`
	RequestID       string `json:"request_id"`
	SessionID       string `json:"session_id"`
	GrantID         string `json:"grant_id,omitempty"`
	AuthzDecisionID string `json:"authz_decision_id,omitempty"`
	// OccurredAt is stored as a fixed-width millisecond-precision UTC string.
	// Field name kept as "occurred_at" for JSON readability.
	OccurredAt string `json:"occurred_at"`
	PrevHash   string `json:"prev_hash"`
}

// Inputs is the raw data passed in from the service layer.
// Deliberately decoupled from the GORM model so it can be unit-tested
// without a database.
type Inputs struct {
	OrgID           string
	SequenceNumber  int64
	UserID          string
	Username        string
	Email           string
	ServiceName     string
	ActorType       string
	Category        string
	Action          string
	Outcome         string
	Severity        string
	Resource        string
	ResourceType    string
	ResourceID      string
	ResourceName    string
	Details         string
	Justification   string
	SourceIP        string
	UserAgent       string
	RequestID       string
	SessionID       string
	GrantID         string
	AuthzDecisionID string
	OccurredAt      time.Time
	PrevHash        string
}

// canonicalTime converts t to the fixed-width canonical string.
// Truncates to milliseconds in UTC — same result whether called at
// write time (nanosecond Go time) or verify time (microsecond DB time).
func canonicalTime(t time.Time) string {
	return t.UTC().Truncate(time.Millisecond).Format(canonicalTimeFormat)
}

// Compute returns (canonicalBytes, entryHashHex, error).
// canonicalBytes is the exact JSON fed to HMAC-SHA256.
// entryHashHex is the hex string stored in the EntryHash column.
//
// OccurredAt is truncated to millisecond precision inside this function.
// Callers do not need to pre-truncate.
func Compute(secret []byte, in Inputs) ([]byte, string, error) {
	if in.PrevHash == "" {
		in.PrevHash = GenesisHash
	}

	rec := CanonicalRecord{
		Version:         CurrentCanonicalVersion,
		OrgID:           in.OrgID,
		SequenceNumber:  in.SequenceNumber,
		UserID:          in.UserID,
		Username:        in.Username,
		Email:           in.Email,
		ServiceName:     in.ServiceName,
		ActorType:       in.ActorType,
		Category:        in.Category,
		Action:          in.Action,
		Outcome:         in.Outcome,
		Severity:        in.Severity,
		Resource:        in.Resource,
		ResourceType:    in.ResourceType,
		ResourceID:      in.ResourceID,
		ResourceName:    in.ResourceName,
		Details:         in.Details,
		Justification:   in.Justification,
		SourceIP:        in.SourceIP,
		UserAgent:       in.UserAgent,
		RequestID:       in.RequestID,
		SessionID:       in.SessionID,
		GrantID:         in.GrantID,
		AuthzDecisionID: in.AuthzDecisionID,
		// canonicalTime truncates nanoseconds → milliseconds, converts to UTC,
		// and formats with fixed 3 decimal digits. Idempotent across round-trips.
		OccurredAt: canonicalTime(in.OccurredAt),
		PrevHash:   in.PrevHash,
	}

	canonical, err := canonicalize(rec)
	if err != nil {
		return nil, "", err
	}

	mac := hmac.New(sha256.New, secret)
	mac.Write(canonical)
	sum := mac.Sum(nil)
	return canonical, hex.EncodeToString(sum), nil
}

// VerifyRow recomputes the HMAC from stored fields and compares it to
// claimedHash using a constant-time comparison.
func VerifyRow(secret []byte, in Inputs, claimedHash string) error {
	_, got, err := Compute(secret, in)
	if err != nil {
		return err
	}
	// hmac.Equal is constant-time — prevents timing attacks.
	if !hmac.Equal([]byte(got), []byte(claimedHash)) {
		return ErrHashMismatch
	}
	return nil
}

// ErrHashMismatch is returned when a row's stored hash does not match
// the recomputed value. This indicates tampering or schema drift.
var ErrHashMismatch = errors.New("auditchain: entry hash does not match canonical record")

// canonicalize produces the deterministic byte form we hash.
// json.Marshal outputs struct fields in declaration order, which is
// stable as long as no one reorders the CanonicalRecord fields.
func canonicalize(rec CanonicalRecord) ([]byte, error) {
	b, err := json.Marshal(rec)
	if err != nil {
		return nil, err
	}
	return b, nil
}

// EncodeSequence formats a sequence number as a decimal string.
// Used by migration tooling to generate the genesis row.
func EncodeSequence(seq int64) string { return strconv.FormatInt(seq, 10) }

// SplitGenesis returns (hash, isGenesis) for the verifier.
func SplitGenesis(prev string) (string, bool) {
	if strings.TrimSpace(prev) == "" || prev == GenesisHash {
		return GenesisHash, true
	}
	return prev, false
}
