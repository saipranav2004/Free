// pam/pkg/auditchain/chain_test.go
package auditchain

import (
	"testing"
	"time"
)

func TestComputeAndVerify(t *testing.T) {
	secret := []byte("test-secret-32-bytes-long-aaaaaa")
	in := Inputs{
		OrgID:          "default",
		SequenceNumber: 1,
		UserID:         "u-1",
		Username:       "alice",
		Category:       "AUTH",
		Action:         "pam:auth:Login",
		Outcome:        "SUCCESS",
		Resource:       "/api/v1/auth/login",
		SourceIP:       "10.0.0.5",
		OccurredAt:     time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC),
		PrevHash:       GenesisHash,
	}
	_, hash, err := Compute(secret, in)
	if err != nil {
		t.Fatalf("compute: %v", err)
	}
	if err := VerifyRow(secret, in, hash); err != nil {
		t.Fatalf("verify: %v", err)
	}
}

func TestVerifyDetectsTampering(t *testing.T) {
	secret := []byte("test-secret-32-bytes-long-aaaaaa")
	in := Inputs{
		OrgID:          "default",
		SequenceNumber: 1,
		UserID:         "u-1",
		Username:       "alice",
		Category:       "AUTH",
		Action:         "pam:auth:Login",
		Outcome:        "SUCCESS",
		Resource:       "/api/v1/auth/login",
		SourceIP:       "10.0.0.5",
		OccurredAt:     time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC),
		PrevHash:       GenesisHash,
	}
	_, hash, err := Compute(secret, in)
	if err != nil {
		t.Fatalf("compute: %v", err)
	}

	// Tamper with the user_id
	tampered := in
	tampered.UserID = "u-EVIL"
	if err := VerifyRow(secret, tampered, hash); err == nil {
		t.Fatalf("expected verify to fail after tampering")
	}
}

func TestChainLinking(t *testing.T) {
	secret := []byte("test-secret-32-bytes-long-aaaaaa")
	prev := GenesisHash
	var rows []struct {
		in   Inputs
		hash string
	}
	for i := int64(1); i <= 3; i++ {
		in := Inputs{
			OrgID:          "default",
			SequenceNumber: i,
			UserID:         "u-1",
			Action:         "pam:auth:Login",
			Outcome:        "SUCCESS",
			OccurredAt:     time.Date(2026, 1, 1, 12, 0, int(i), 0, time.UTC),
			PrevHash:       prev,
		}
		_, hash, err := Compute(secret, in)
		if err != nil {
			t.Fatalf("row %d: %v", i, err)
		}
		rows = append(rows, struct {
			in   Inputs
			hash string
		}{in, hash})
		prev = hash
	}
	// Walk the chain and confirm each row's PrevHash equals the prior hash.
	expected := GenesisHash
	for i, r := range rows {
		if r.in.PrevHash != expected {
			t.Fatalf("row %d: prev_hash broken", i+1)
		}
		if err := VerifyRow(secret, r.in, r.hash); err != nil {
			t.Fatalf("row %d: %v", i+1, err)
		}
		expected = r.hash
	}
}

func TestDifferentSecretsProduceDifferentHashes(t *testing.T) {
	in := Inputs{
		OrgID: "default", SequenceNumber: 1, UserID: "u-1",
		Action: "x", Outcome: "SUCCESS", OccurredAt: time.Now(), PrevHash: GenesisHash,
	}
	_, h1, _ := Compute([]byte("secret-one-32-bytes-long-aaaaaa"), in)
	_, h2, _ := Compute([]byte("secret-two-32-bytes-long-aaaaaa"), in)
	if h1 == h2 {
		t.Fatalf("expected different hashes for different secrets")
	}
}
