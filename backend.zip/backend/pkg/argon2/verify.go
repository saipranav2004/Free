// Package argon2 provides PHC-format Argon2id hash verification compatible
// with Python's argon2-cffi (used by the IAM backend).
//
// IAM stores password hashes in the standard PHC string format:
//
//	$argon2id$v=19$m=65536,t=3,p=4$<base64-salt>$<base64-hash>
//
// This package parses that string and verifies a plaintext password against it.
package argon2

import (
	"encoding/base64"
	"errors"
	"fmt"
	"strconv"
	"strings"

	xargon2 "golang.org/x/crypto/argon2"
)

var (
	ErrInvalidHash     = errors.New("invalid argon2 hash format")
	ErrIncompatibleVer = errors.New("incompatible argon2 version")
)

// params holds the parsed Argon2 parameters from the PHC string.
type params struct {
	memory      uint32
	iterations  uint32
	parallelism uint8
	salt        []byte
	hash        []byte
	keyLen      uint32
}

// Verify compares a plaintext password against an Argon2id PHC hash.
// Returns true if they match, false otherwise.
func Verify(password, encodedHash string) (bool, error) {
	p, err := parsePHC(encodedHash)
	if err != nil {
		return false, err
	}

	// Compute the Argon2id key from the plaintext password.
	computed := xargon2.IDKey(
		[]byte(password),
		p.salt,
		p.iterations,
		p.memory,
		p.parallelism,
		p.keyLen,
	)

	// Constant-time comparison.
	if len(computed) != len(p.hash) {
		return false, nil
	}
	var diff byte
	for i := 0; i < len(computed); i++ {
		diff |= computed[i] ^ p.hash[i]
	}
	return diff == 0, nil
}

// parsePHC parses a standard Argon2id PHC string:
//
//	$argon2id$v=19$m=65536,t=3,p=4$<base64-salt>$<base64-hash>
func parsePHC(encoded string) (*params, error) {
	parts := strings.Split(encoded, "$")
	if len(parts) != 6 {
		return nil, ErrInvalidHash
	}

	// parts[0] is empty (leading $)
	// parts[1] = "argon2id"
	algo := parts[1]
	if algo != "argon2id" && algo != "argon2i" && algo != "argon2d" {
		return nil, fmt.Errorf("unsupported argon2 variant: %s", algo)
	}

	// parts[2] = "v=19"
	versionStr := strings.TrimPrefix(parts[2], "v=")
	version, err := strconv.Atoi(versionStr)
	if err != nil {
		return nil, fmt.Errorf("invalid version: %w", err)
	}
	if version != 19 {
		return nil, fmt.Errorf("%w: %d", ErrIncompatibleVer, version)
	}

	// parts[3] = "m=65536,t=3,p=4"
	p := &params{}
	paramParts := strings.Split(parts[3], ",")
	for _, pp := range paramParts {
		kv := strings.SplitN(pp, "=", 2)
		if len(kv) != 2 {
			return nil, ErrInvalidHash
		}
		switch kv[0] {
		case "m":
			m, err := strconv.ParseUint(kv[1], 10, 32)
			if err != nil {
				return nil, fmt.Errorf("invalid memory param: %w", err)
			}
			p.memory = uint32(m)
		case "t":
			t, err := strconv.ParseUint(kv[1], 10, 32)
			if err != nil {
				return nil, fmt.Errorf("invalid iterations param: %w", err)
			}
			p.iterations = uint32(t)
		case "p":
			par, err := strconv.ParseUint(kv[1], 10, 8)
			if err != nil {
				return nil, fmt.Errorf("invalid parallelism param: %w", err)
			}
			p.parallelism = uint8(par)
		default:
			return nil, fmt.Errorf("unknown param: %s", kv[0])
		}
	}

	// parts[4] = base64 salt
	salt, err := base64.RawStdEncoding.DecodeString(parts[4])
	if err != nil {
		// Try standard base64 (with padding).
		salt, err = base64.StdEncoding.DecodeString(parts[4])
		if err != nil {
			return nil, fmt.Errorf("invalid base64 salt: %w", err)
		}
	}
	p.salt = salt

	// parts[5] = base64 hash
	hash, err := base64.RawStdEncoding.DecodeString(parts[5])
	if err != nil {
		hash, err = base64.StdEncoding.DecodeString(parts[5])
		if err != nil {
			return nil, fmt.Errorf("invalid base64 hash: %w", err)
		}
	}
	p.hash = hash
	p.keyLen = uint32(len(hash))

	return p, nil
}
