package argon2

import "testing"

func TestHashAndVerifyRoundTrip(t *testing.T) {
	hash, err := Hash("correct-horse-battery-staple")
	if err != nil {
		t.Fatalf("Hash() error: %v", err)
	}
	ok, err := Verify("correct-horse-battery-staple", hash)
	if err != nil {
		t.Fatalf("Verify() error: %v", err)
	}
	if !ok {
		t.Fatal("expected correct password to verify")
	}

	ok, err = Verify("wrong-password", hash)
	if err != nil {
		t.Fatalf("Verify() error on wrong password: %v", err)
	}
	if ok {
		t.Fatal("expected wrong password to fail verification")
	}
}

func TestHashRejectsEmptyPassword(t *testing.T) {
	if _, err := Hash(""); err == nil {
		t.Fatal("expected an error hashing an empty password")
	}
}

func TestHashProducesUniqueSaltsPerCall(t *testing.T) {
	h1, err := Hash("same-password")
	if err != nil {
		t.Fatalf("Hash() error: %v", err)
	}
	h2, err := Hash("same-password")
	if err != nil {
		t.Fatalf("Hash() error: %v", err)
	}
	if h1 == h2 {
		t.Fatal("expected two hashes of the same password to differ (unique random salt)")
	}
}
