// Package crypto provides AES-256-GCM encryption/decryption for PAM secrets
// (TOTP secrets, vault credentials, session recordings, etc).
package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
)

// Encrypt encrypts plaintext using AES-256-GCM with the given base64-encoded key.
func Encrypt(plaintext, keyB64 string) (string, error) {
	sealed, err := EncryptBytes([]byte(plaintext), keyB64)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(sealed), nil
}

// Decrypt decrypts an AES-256-GCM ciphertext.
func Decrypt(ciphertextB64, keyB64 string) (string, error) {
	data, err := base64.StdEncoding.DecodeString(ciphertextB64)
	if err != nil {
		return "", fmt.Errorf("invalid ciphertext encoding: %w", err)
	}
	plaintext, err := DecryptBytes(data, keyB64)
	if err != nil {
		return "", err
	}
	return string(plaintext), nil
}

// EncryptBytes is the byte-native core Encrypt builds on. Callers with
// already-binary data (e.g. a gzip-compressed session recording — see
// internal/recorder.LocalStorage) use this directly rather than going
// through Encrypt/Decrypt's string+base64 API, which would otherwise add a
// wasteful ~33% base64 round-trip on top of a payload that can be several
// MB, for a value never meant to be read as text in the first place.
func EncryptBytes(plaintext []byte, keyB64 string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(keyB64)
	if err != nil {
		return nil, fmt.Errorf("invalid key encoding: %w", err)
	}
	if len(key) != 32 {
		return nil, errors.New("key must be 32 bytes (base64-encoded)")
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("failed to create cipher: %w", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("failed to create GCM: %w", err)
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, fmt.Errorf("failed to generate nonce: %w", err)
	}

	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

// DecryptBytes is the byte-native core Decrypt builds on. See EncryptBytes.
func DecryptBytes(data []byte, keyB64 string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(keyB64)
	if err != nil {
		return nil, fmt.Errorf("invalid key encoding: %w", err)
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("failed to create cipher: %w", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("failed to create GCM: %w", err)
	}

	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		return nil, errors.New("ciphertext too short")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, fmt.Errorf("decryption failed: %w", err)
	}

	return plaintext, nil
}
