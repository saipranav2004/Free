# This round — everything tested through PAM, against real servers

You asked two things:

1. did I actually test the desktop recording fix, and MinIO / Qdrant / Metabase
   *through PAM*, with real recordings — or had I been testing something else;
2. for the desktop applications, stop giving up and find a mechanism, the way
   the web side has the proxy.

Both answers are below, and neither is what I told you last time.

---

## First, the honest part

**Metabase had never been tested against Metabase.** Every previous pass ran
against `e2e/stub/metabase.cjs` — a stub I wrote from the same documentation I
wrote the authenticator from. It could only ever agree with me. "12/12
passing" meant my stub matched my code.

So this round runs a **real `metabase.jar`**, a **real Qdrant 1.12.4**, and the
real MinIO, each registered as a PAM resource and opened only through PAM.
That found three real bugs — one of them mine, from last round.

**And I was wrong about the desktop clients.** I said pgAdmin 4 and SQL
Developer "cannot be made to open already logged in". That was true of the
mechanism I had tried (`PGPASSFILE`) and false as a general claim. pgAdmin
publishes a credential hook, and RedisInsight publishes a pre-setup mechanism.
Both work. Both are now implemented and verified against the real
applications.

---

## 1. Desktop: pgAdmin 4 now opens connected

pgAdmin documents **`PasswordExecCommand`** — a command it runs at connect
time whose stdout becomes the SQL password. That is the desktop analogue of
what the web proxy already does: the client asks a broker for the credential
at the moment of use. The agent is that broker.

- `internal/launcher/pgadmin_passexec.go` (new) builds the command and writes
  the secret to a `0600` file the agent hands back, never to `argv`.
- `cmd/pam-agent/pgadmin-credential` is the subcommand **pgAdmin itself calls**.
- The servers-import file still contains no password — pgAdmin does not import
  passwords, and its own config database records `server.password = NULL`.

**Proof** — real pgAdmin 4 9.18, desktop mode, against a PostgreSQL role that
requires `scram-sha-256` (a wrong password provably fails), driven by the
**agent's own binary and the agent's own emitted file**:

```
PASS  the PAM-imported server appears in pgAdmin
PASS  NO password dialog was shown — connected without asking
PASS  pgAdmin ran the credential command — INFO pgadmin: Calling passexec
PASS  the command completed successfully for pgAdmin
PASS  the stored command calls back into pam-agent
PASS  PostgreSQL shows an authenticated backend from pgAdmin
          — pam_pgadmin_test / pgAdmin 4 - DB:postgres
PASS  the password was never written to pgAdmin's config database
          — server.password = None
```

And a **control**, because "no dialog appeared" proves nothing if the check
can never fire. The identical server definition with that one key removed:

```
PASS  CONTROL: without the password command pgAdmin DOES ask
PASS  CONTROL: and does not reach PostgreSQL — 0 backend(s)
```

Run both lanes with `harness/pgadmin-lane.sh passexec|control`.

Two details that came from reading pgAdmin's `passexec.py` rather than its
docs, and that shape the code: it runs the command with `shell=True` (so every
path is quoted for the platform shell — `cmd.exe` rules on Windows, POSIX
rules elsewhere), and it takes `stdout.strip()` as the password (so a password
with leading or trailing whitespace **cannot** go through this channel and
falls back to the clipboard rather than authenticating with a silently altered
secret).

## Desktop: RedisInsight now opens connected

RedisInsight reads a pre-setup databases file at startup
(`RI_PRE_SETUP_DATABASES_PATH`) — the same shape of mechanism as pgAdmin's
`--load-servers`. Last round this template went from `none` to `clipboard`;
it now registers the database with its credential.

**Proof** — real RedisInsight 2.70.1 driven over its own remote-debugging
port (so this is the actual Electron UI), against a real Redis with
`requirepass`, from the **agent's own emitted file**:

```
PASS  Redis genuinely requires the password — NOAUTH Authentication required.
PASS  the PAM-registered database appears in RedisInsight
PASS  RedisInsight connected to the real Redis — clients 1 -> 3
PASS  the operator lands inside the database, not on a password form
PASS  the pre-seeded key is reachable through the connection
```

Two things worth knowing, both found by reading RedisInsight's bundled code:

- It **ignores the file until its EULA has been accepted**. True already on any
  machine where someone has opened RedisInsight once; on a brand-new install
  the first launch shows the consent screen and ignores the file. The launch
  now says so, rather than leaving an operator to conclude PAM did nothing.
- Entries are matched by id, and PAM derives a **stable** id per resource, so
  relaunching updates the entry instead of piling up duplicates. The id must
  be UUID-shaped or RedisInsight silently drops it — pinned by a test.

**An honest difference from the pgAdmin route.** RedisInsight has no
fetch-at-connect hook, so the password has to be *in* that file, and
RedisInsight copies it into its own store — encrypted with the system keychain
where one exists, in plain text where none does. That is still better than the
clipboard, which every application on the desktop can read for as long as it
sits there, but it is not the same guarantee. The file is `0600` and deleted
with the session.

## Desktop: SQL Developer — what I found, and why I am not shipping it

SQL Developer takes no connection on its command line, has no credential
command, and encrypts its own stored connections under a key derived from its
installation. There is exactly one mechanism that authenticates it with no
password typed: an **Oracle Wallet used as a Secure External Password Store**
(`mkstore -createCredential`, plus a `sqlnet.ora` carrying
`SQLNET.WALLET_OVERRIDE=TRUE`), which makes `connect /@alias` authenticate from
the wallet.

I have **not** implemented it, and that is deliberate. Minting a wallet needs
Oracle's own `mkstore` on the operator's machine, and I have no Oracle client
or SQL Developer here to verify it end to end. Shipping an unverified
credential path into a privileged access product is worse than a clipboard
that works. It is written down in `gui_credentials_test.go` so the next person
starts from the mechanism rather than from scratch. If you can give me a box
with an Oracle client and SQL Developer on it, this is a day's work with a real
test at the end.

So the desktop scoreboard is now **three of four opening connected**
(MongoDB Compass, pgAdmin 4, RedisInsight), one landing on its own dialog with
the password a paste away (SQL Developer) — against one of four when you wrote.

---

## 2. Qdrant — the other half of the bug, and a worse one behind it

Last round I made `account_name` optional for API keys and showed you `201
Created`. That was the **admin resource route**. The **Vault route**
(`POST /safes/:id/credentials` — the one the console's Vault page and any API
client uses) still had `binding:"required"` and still answered **400**. Same
product, two answers, depending on which page you used. I only found it
because seeding a real Qdrant went through the route I had not fixed.

The rule now lives once, in `models.AccountNameRequiredFor`, and is enforced in
`VaultService.StoreCredential`, which every route passes through. The handler
copy delegates to it.

**Then the real one.** With account-less credentials finally storable, storing
one and opening a session with it failed:

```
additional authenticated data (AAD) mismatch during decryption:
cipher: message authentication failed
```

`account_name` carries a database default of `'Unnamed'`. GORM omits a
zero-value field that has a column default, so Postgres wrote `"Unnamed"` while
the envelope had already been sealed under `""`. The credential stored fine,
listed fine, and **could never be decrypted again**.

This is the identical trap that `safe_id` had — there is a long comment in
`EncryptionAAD` describing it — one column over. It was simply unreachable
until an account-less credential could exist. Fixed by normalising
`account_name` in the same place `safe_id` is normalised, which is a no-op for
every credential that has an account name and cannot disturb anything stored
today. Regression test sits next to the `safe_id` one.

**Qdrant also had Metabase's old problem**: `resource_type: "qdrant"` inferred
`strategyNone`, so PAM brokered and recorded the session and then handed the
operator a 401 — with the key sitting in the vault. `authenticator_qdrant.go`
(new) sends Qdrant's documented `api-key` header. The username is deliberately
unused; reading one would quietly reintroduce the requirement you reported.

---

## 3. All three web apps, through PAM, against real servers

`e2e/real-web.mjs` (new) — **23/23**. Each app is opened **only** through PAM, and each
section starts with a control proving the target really does refuse
unauthenticated access — otherwise "it worked through PAM" says nothing about
PAM.

**Qdrant** (real 1.12.4, API key enforced, credential vaulted with no account
name):

```
PASS  Qdrant genuinely enforces its API key (direct request is refused) — HTTP 401
PASS  PAM opens a brokered session for the qdrant resource
PASS  it injects the API key instead of leaving the operator to paste it — qdrant_api_key
PASS  the operator reaches Qdrant authenticated, with no key in hand
PASS  the API key never reaches the browser
PASS  PAM recorded the qdrant session
PASS  and recorded it as a request transcript, the right artifact for a JSON API
```

**Metabase** (real `metabase.jar`, real admin account):

```
PASS  Metabase genuinely requires a session (direct request is refused) — HTTP 401
PASS  it logs in server-side rather than falling back to "none" — metabase_session
PASS  the operator lands signed in, not on the login form
PASS  Metabase itself reports the vaulted account as the logged-in user
PASS  the password never reaches the browser — DOM, cookies, storage
PASS  the upstream session cookie is not exposed to page script
PASS  the browser delivered rrweb batches
PASS  PAM recorded the metabase session — rrweb ~230 KB, ~60s
PASS  and recorded it as a visual replay, not just a request log
```

That fourth line is the one the stub could not have given me: it asks
**Metabase** who is logged in, through its own `/api/user/current`, rather than
trusting what the page renders.

**MinIO** (real, including the click every earlier suite stopped short of):

```
PASS  the bucket list loads
PASS  the file list INSIDE the bucket loads, not an endless spinner — objects listed
PASS  no WebSocket failed during the object listing
PASS  PAM recorded the minio session — rrweb ~570 KB
```

A note on recording artifacts, since it differs per target and the difference
is deliberate: Qdrant answers JSON, so there is no DOM to reconstruct and the
honest artifact is the **request transcript**; Metabase and MinIO are real
applications, so they record as **rrweb visual replays**. The suite asserts
*which* one lands, because a silent fall-through to no recording at all on a
resource marked `always_record` would be the real failure.

---

## Also fixed: the video replay suite

`replay-video.mjs` looked for the desktop video recording only on page one of
the recordings table. Recordings are never pruned, so this session's own runs
buried it, and its resource-name fallback then opened an rrweb row and reported
"no `<video>`" as if the player were broken. It now pages through and matches
on session id: **9/9**, replaying a genuine ffmpeg-captured desktop recording
at 1920x1080 VP9, playing.

---

## Verified

- backend `go test ./...` — **13 packages, all pass**, including the vault AAD
  tests run against real Postgres
- agent `go test ./...` — **all pass**, plus all five cross-builds
  (linux/darwin/windows, amd64+arm64)
- console `npm run lint` (`--max-warnings 0`) and `npm run build` — clean
- the three new browser suites above, against real servers:
  `real-web.mjs` **23/23**, `pgadmin-passexec.mjs` **7/7** (plus its control
  **3/3**), `redisinsight-presetup.mjs` **5/5**

All of that was re-run from scratch after the test container restarted
mid-sweep: the harness was rebuilt from source, every server restarted, and
the three suites re-confirmed at the same numbers on a cold environment.

Tests that encoded the old, wrong answers were **corrected, not deleted**:
`gui_credentials_test.go` and `templates_test.go` both asserted that pgAdmin
could only get a clipboard handoff. They now assert the stronger property —
that every desktop client except SQL Developer opens already connected — and
each records why, so a future change has to disagree on purpose.

---

## Proof in `proof/`

| file | what it shows |
|---|---|
| `pgadmin-CONNECTED-no-password-dialog.png` | real pgAdmin 4 connected to the PAM-registered server, live dashboard rendering — no password was typed |
| `pgadmin-CONTROL-without-passexec-asks.png` | the identical server without `PasswordExecCommand`: pgAdmin's password dialog, and no connection |
| `redisinsight-CONNECTED-browsing-keys.png` | real RedisInsight inside the PAM-registered database, browsing `pam:demo` on a password-protected Redis |
| `metabase-real-session-replay.mp4` | the PAM console replaying the brokered session against the **real** Metabase — the recording, watchable outside the product |

---

## A note on the strings that look like passwords

`seed-real-web.sh`, `pgadmin-passexec.mjs` and `redisinsight-presetup.mjs`
contain values like `PamTest!2026Metabase` and `Redis!PamTest2026`. Those are
throwaway credentials for servers that only ever existed inside the test
container — a local Metabase, a local Redis, a local Postgres role — created
so the tests could prove authentication really was required. Nothing here
touches your deployment, and `backend_upd/.env` is excluded from this archive
as always. The live secrets in that file still need rotating.
