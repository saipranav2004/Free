// pam/internal/webproxy/authenticator_qdrant.go
//
// Qdrant's API-key auth, so a brokered Qdrant session arrives authenticated
// rather than answering 401 until the operator pastes the key themselves.
//
// WHY THIS EXISTS. Qdrant is the resource type that prompted the question
// "you ask for a username and password, but a Qdrant API key has no
// username" — and the answer had two halves. The vault half (an API key is
// an identity, not an account, so account_name is not required for it) is in
// resource_handler.go. This is the other half: having accepted a key with no
// account, PAM has to be able to USE it. Before this, resource_type "qdrant"
// fell through to strategyNone, so the proxy brokered and recorded the
// session and then handed the operator a 401 — the key sat in the vault
// while they were asked to know it anyway.
//
// THE PROTOCOL. Qdrant authenticates a request by a header, with no login
// call and no session to establish:
//
//	api-key: <key>
//
// Verified against a real Qdrant 1.12.4: no header answers 401 on every path
// including the dashboard, "api-key: <key>" answers 200.
//
// Qdrant also accepts "Authorization: Bearer <key>", confirmed on the same
// build, but "api-key" is the form Qdrant has documented since the feature
// existed, so it is the one that works across the widest range of versions
// an operator might actually be running. A deployment that needs the other
// form can still say so: web_auth_strategy=bearer_token leaves the generic
// authenticator, whose header and prefix are both configurable.
//
// The username is deliberately unused. A Qdrant credential legitimately has
// no account name, and reading one here would quietly reintroduce the
// requirement this was meant to remove.
package webproxy

import (
	"context"
	"fmt"
	"net/http"
	"strings"
)

const strategyQdrantAPIKey = "qdrant_api_key"

// qdrantAPIKeyHeader is Qdrant's documented authentication header.
const qdrantAPIKeyHeader = "api-key"

type QdrantAuthenticator struct{}

func (a *QdrantAuthenticator) Name() string { return strategyQdrantAPIKey }

func (a *QdrantAuthenticator) Login(ctx context.Context, client *http.Client, target Target) (*UpstreamState, error) {
	key := strings.TrimSpace(target.Password)
	if key == "" {
		// Caught here rather than at the first proxied request, where it
		// would surface as an unexplained 401 from Qdrant and read as a
		// wrong key rather than a missing one.
		return nil, fmt.Errorf("this Qdrant resource has no API key in its vaulted credential — " +
			"store the key as the secret of an api_key credential on the resource")
	}
	state := &UpstreamState{}
	state.setHeader(qdrantAPIKeyHeader, key)
	return state, nil
}
