package webproxy

import (
	"context"
	"net/http"
	"strings"
	"testing"
)

// The point of the whole change: a resource typed "qdrant" must not fall
// through to strategyNone, which brokered the session and then left the
// operator at a 401 with the key sitting in the vault.
func TestQdrantResourceInfersTheAPIKeyStrategy(t *testing.T) {
	a, err := NewRegistry().Get("qdrant", nil)
	if err != nil {
		t.Fatal(err)
	}
	if a.Name() != strategyQdrantAPIKey {
		t.Fatalf("qdrant resolved to %q, want %q", a.Name(), strategyQdrantAPIKey)
	}
}

// An explicit strategy still wins, so a Qdrant behind something else (a
// gateway wanting Bearer, an SSO proxy) is not forced into this.
func TestExplicitStrategyStillOverridesQdrantInference(t *testing.T) {
	a, err := NewRegistry().Get("qdrant", map[string]interface{}{"web_auth_strategy": "bearer_token"})
	if err != nil {
		t.Fatal(err)
	}
	if a.Name() != strategyBearerToken {
		t.Fatalf("explicit strategy ignored: got %q", a.Name())
	}
}

func TestQdrantSendsTheDocumentedHeaderAndNoUsername(t *testing.T) {
	state, err := (&QdrantAuthenticator{}).Login(context.Background(), http.DefaultClient, Target{
		BaseURL: "http://qdrant.internal:6333",
		// A Qdrant credential has no account name. If one is present it is
		// incidental and must not reach the wire.
		Username: "",
		Password: "pam-test-qdrant-key-7f3a91",
	})
	if err != nil {
		t.Fatal(err)
	}
	if got := state.Headers[qdrantAPIKeyHeader]; got != "pam-test-qdrant-key-7f3a91" {
		t.Fatalf("%s = %q, want the vaulted key", qdrantAPIKeyHeader, got)
	}
	// No Authorization header: sending both invites a target that rejects
	// unexpected credentials, and it is not what Qdrant documents.
	if got := state.Headers["Authorization"]; got != "" {
		t.Errorf("unexpected Authorization header %q", got)
	}
	// And nothing derived from a username, which a Qdrant credential does
	// not have.
	if len(state.Cookies) != 0 {
		t.Errorf("unexpected cookies: %v", state.Cookies)
	}
}

// An empty key must fail at login with a sentence that says what to do,
// rather than at the first proxied request as a bare 401 that reads like a
// wrong key.
func TestQdrantEmptyKeyFailsWithAnActionableError(t *testing.T) {
	_, err := (&QdrantAuthenticator{}).Login(context.Background(), http.DefaultClient, Target{
		BaseURL: "http://qdrant.internal:6333", Password: "   ",
	})
	if err == nil {
		t.Fatal("expected an error for an empty API key")
	}
	if !strings.Contains(err.Error(), "api_key") {
		t.Errorf("error does not tell the operator what to store: %v", err)
	}
}
