// pam/internal/models/vault.go
//
// Credential is the enterprise envelope-encrypted vault entry (Safes/Folders
// hierarchy, Features 10/13/14). `VaultEntry` is kept as a backward-compatible
// alias since services/resource_service.go (the legacy per-resource
// credential path) and services/jit_service.go (break-glass eligibility)
// both refer to `models.VaultEntry`.
//
// IsBreakglass/BreakglassNote were added here (JIT branch) rather than on a
// second, separate "VaultEntry" struct: the JIT branch's own dump defined a
// simpler, parallel VaultEntry type pointed at a different table
// (pam_vault_entries). That would have split credential storage across two
// tables. Since VaultEntry is already a type alias for Credential in the
// base branch, the break-glass flag belongs here instead, so
// hasBreakglassCredential's `WHERE resource_id = ? AND is_breakglass = ?`
// query (services/jit_service.go) operates on the same table every other
// vault operation uses (pam_credentials).
package models

import (
	"strings"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type CredentialType string

const (
	CredentialTypePassword         CredentialType = "password"
	CredentialTypeSSHKey           CredentialType = "ssh_key"
	CredentialTypeX509Cert         CredentialType = "x509_cert"
	CredentialTypeAPIKey           CredentialType = "api_key"
	CredentialTypeToken            CredentialType = "token"
	CredentialTypeConnectionString CredentialType = "connection_string"
	CredentialTypeKeytab           CredentialType = "kerberos_keytab"
)

func IsValidCredentialType(ct string) bool {
	switch CredentialType(ct) {
	case CredentialTypePassword, CredentialTypeSSHKey, CredentialTypeX509Cert,
		CredentialTypeAPIKey, CredentialTypeToken, CredentialTypeConnectionString,
		CredentialTypeKeytab:
		return true
	default:
		return false
	}
}

// AccountNameRequiredFor answers whether a credential of this type
// authenticates AS a named account.
//
// A password, an SSH key, an X.509 cert and a Kerberos keytab all belong to
// somebody: without the account name they cannot be used, so PAM refuses to
// store one that has none.
//
// An API key, a bearer/OIDC token and a connection string do not. A Qdrant
// instance issues an API key and no username — the key IS the identity — and
// the same is true of most token-authenticated services. Demanding an account
// name for these made the operator type something untrue into the vault,
// which is worse than not asking: it puts a fabricated principal on every
// audit row that credential ever appears in.
//
// THIS LIVES IN models ON PURPOSE. The rule was first written in the admin
// resource handler, which is one of two routes that store a credential — the
// Vault route (POST /safes/:id/credentials, the one the console's Vault page
// and any API client uses) went on rejecting an account-less API key with a
// 400 from its binding tag. One rule, in the package both layers already
// import, so the two cannot answer differently again.
func AccountNameRequiredFor(credentialType string) bool {
	switch CredentialType(strings.ToLower(strings.TrimSpace(credentialType))) {
	case CredentialTypeAPIKey, CredentialTypeToken, CredentialTypeConnectionString:
		return false
	default:
		// Unknown types are treated as account-bearing, which is the safe
		// direction: it asks for one more field rather than silently
		// accepting a credential with no principal attached.
		return true
	}
}

// Credential represents an envelope-encrypted privileged credential in a Safe.
type Credential struct {
	ID             string  `gorm:"primaryKey;type:varchar(36)" json:"id"`
	SafeID         string  `gorm:"type:varchar(36);default:'default';index" json:"safe_id"`
	FolderID       *string `gorm:"type:varchar(36);index" json:"folder_id,omitempty"`
	ResourceID     string  `gorm:"type:varchar(36);index" json:"resource_id,omitempty"`
	Name           string  `gorm:"type:varchar(255);default:'Unnamed';index" json:"name"`
	Description    string  `gorm:"type:text" json:"description,omitempty"`
	AccountName    string  `gorm:"type:varchar(255);default:'Unnamed';index" json:"account_name"`
	CredentialType string  `gorm:"type:varchar(50);not null;default:'password'" json:"credential_type"`

	// AES-256-GCM envelope-encrypted secret. NEVER expose through JSON.
	CredentialEnc string `gorm:"type:text;not null" json:"-"`

	// IsBreakglass marks this credential as an emergency ("break-glass") account.
	// A resource is break-glass eligible only if it has such a credential.
	// Using it skips the human approver but incurs a mandatory waiting period,
	// a CRITICAL alert, forced session recording and an auto-generated report.
	IsBreakglass bool `gorm:"column:is_breakglass;not null;default:false;index" json:"is_breakglass"`

	// BreakglassNote is operator context shown in the emergency-access report.
	BreakglassNote string `gorm:"column:breakglass_note;type:text" json:"breakglass_note,omitempty"`

	MetadataJSON string `gorm:"type:text" json:"metadata_json,omitempty"`
	Status       string `gorm:"type:varchar(30);default:'active';index" json:"status"`
	Version      int    `gorm:"default:1" json:"version"`

	LastRotatedAt        *time.Time `json:"last_rotated_at,omitempty"`
	NextRotationAt       *time.Time `json:"next_rotation_at,omitempty"`
	RotationIntervalDays int        `gorm:"default:0" json:"rotation_interval_days"`

	CreatedBy string         `gorm:"type:varchar(36)" json:"created_by,omitempty"`
	UpdatedBy string         `gorm:"type:varchar(36)" json:"updated_by,omitempty"`
	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Credential) TableName() string { return "pam_credentials" }

// DefaultSafeID is the safe a credential belongs to when none was named.
//
// It exists as a Go constant as well as a column default because the two are
// not interchangeable: a GORM column default applies only once the row reaches
// the database, and the envelope's AAD is computed before that. See
// EncryptionAAD.
const DefaultSafeID = "default"

// DefaultAccountName MUST equal the `default:` on Credential.AccountName.
// The database writes that value when the field is empty, and the AAD has to
// predict what the database will store — see EncryptionAAD.
const DefaultAccountName = "Unnamed"

// EncryptionAAD returns the additional-authenticated-data binding for this
// credential's envelope.
//
// ONE definition, called by both encrypt and decrypt, and that is the whole
// point. The AAD is authenticated but not encrypted by AES-GCM, so encrypt and
// decrypt MUST derive it from exactly the same columns — if they drift, every
// credential already stored becomes permanently undecryptable, and the drift
// is invisible until somebody tries to read an old row.
//
// It had drifted. StoreCredential built the AAD from the REQUEST (before the
// insert) and every read built it from the ROW (after it). SafeID carries
// `default:'default'`, which Postgres fills in during the INSERT, so a
// credential stored with no safe_id was sealed under {account} and read back
// under {account, safe_id:"default"} — a GCM tag mismatch, for ever. It
// stored fine, listed fine, and could never be read. Reproduced in
// vault_aad_binding_test.go.
//
// The binding is also what stops a ciphertext being MOVED between credentials
// by anyone with a database write: a blob re-pointed at a different account or
// safe fails the tag check instead of quietly decrypting.
func (v *Credential) EncryptionAAD() map[string]string {
	// account_name carries `default:'Unnamed'`, and this is the SAME TRAP the
	// paragraph above describes for safe_id — it just could not be reached
	// until credentials without an account name became storable (an API key
	// has no account; see AccountNameRequiredFor). GORM omits a zero-value
	// field that has a column default, so Postgres wrote "Unnamed" while the
	// AAD had already been computed from "": sealed under {account:""}, read
	// back under {account:"Unnamed"}, authentication tag mismatch, and the
	// credential could never be decrypted again. It stored fine and opening a
	// session with it failed with a cipher error that named no cause.
	//
	// Normalising here fixes both directions at once and cannot disturb any
	// existing credential: for a non-empty account name it is a no-op, and an
	// empty one was unstorable before now.
	account := v.AccountName
	if account == "" {
		account = DefaultAccountName
	}
	aad := map[string]string{"account": account}
	// Normalised here too, so a caller that computes the AAD from an
	// in-memory struct it has not yet saved agrees with one that computes it
	// from the row.
	safeID := v.SafeID
	if safeID == "" {
		safeID = DefaultSafeID
	}
	aad["safe_id"] = safeID
	if v.ResourceID != "" {
		aad["resource_id"] = v.ResourceID
	}
	return aad
}

func (v *Credential) BeforeCreate(tx *gorm.DB) error {
	if v.ID == "" {
		v.ID = uuid.NewString()
	}
	if v.Version == 0 {
		v.Version = 1
	}
	if v.Status == "" {
		v.Status = "active"
	}
	if v.Name == "" {
		v.Name = v.AccountName
	}
	// Materialised in Go rather than left to the column default, because the
	// envelope AAD is computed before this row reaches Postgres. See
	// EncryptionAAD.
	if v.SafeID == "" {
		v.SafeID = DefaultSafeID
	}
	return nil
}

// CredentialVersion stores an immutable history record of a credential's secret over time.
type CredentialVersion struct {
	ID            string    `gorm:"primaryKey;type:varchar(36)" json:"id"`
	CredentialID  string    `gorm:"type:varchar(36);not null;index" json:"credential_id"`
	Version       int       `gorm:"not null" json:"version"`
	CredentialEnc string    `gorm:"type:text;not null" json:"-"`
	Reason        string    `gorm:"type:text" json:"reason,omitempty"`
	CreatedBy     string    `gorm:"type:varchar(150)" json:"created_by"`
	CreatedAt     time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (CredentialVersion) TableName() string { return "pam_credential_versions" }

func (v *CredentialVersion) BeforeCreate(tx *gorm.DB) error {
	if v.ID == "" {
		v.ID = uuid.NewString()
	}
	return nil
}

// VaultEntry is a backward-compatible type alias for Credential.
type VaultEntry = Credential
