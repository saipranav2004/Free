package models

import "testing"

// The reported case: a Qdrant API key has no username, and PAM must not make
// the operator invent one.
//
// This rule was previously written twice — once in the admin resource handler
// and not at all in the vault service — so the same product accepted an
// account-less API key on one route and rejected it with a 400 on the other.
// Pinning every type here is what makes a future edit have to choose
// deliberately.
func TestAccountNameIsRequiredOnlyForAccountBearingCredentials(t *testing.T) {
	cases := map[CredentialType]bool{
		// The key, the token or the string IS the identity.
		CredentialTypeAPIKey:           false,
		CredentialTypeToken:            false,
		CredentialTypeConnectionString: false,

		// These belong to somebody and are unusable without knowing who.
		CredentialTypePassword: true,
		CredentialTypeSSHKey:   true,
		CredentialTypeX509Cert: true,
		CredentialTypeKeytab:   true,
	}
	for ct, want := range cases {
		if got := AccountNameRequiredFor(string(ct)); got != want {
			t.Errorf("AccountNameRequiredFor(%q) = %v, want %v", ct, got, want)
		}
	}
}

// Case and stray whitespace come from real form posts and must not change the
// answer — least of all in the direction that lets an account-bearing
// credential through with no principal.
func TestAccountNameRuleIgnoresCaseAndSurroundingSpace(t *testing.T) {
	for _, in := range []string{"API_KEY", " api_key ", "Api_Key"} {
		if AccountNameRequiredFor(in) {
			t.Errorf("%q should not require an account name", in)
		}
	}
	for _, in := range []string{"PASSWORD", " password "} {
		if !AccountNameRequiredFor(in) {
			t.Errorf("%q should require an account name", in)
		}
	}
}

// An unrecognised type must fail SAFE — asking for a principal rather than
// silently storing a credential without one.
func TestUnknownCredentialTypesAreTreatedAsAccountBearing(t *testing.T) {
	for _, in := range []string{"", "something_new", "oauth2_but_misspelled"} {
		if !AccountNameRequiredFor(in) {
			t.Errorf("unknown type %q must default to requiring an account name", in)
		}
	}
}
