import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// Does the console PLAY BACK a desktop (video) recording?
//
// The rrweb path and the video path are different renderers behind the same
// transport (RrwebStage vs VideoStage), and only one of them had ever been
// opened. This drives the video one against a real artifact: a RedisInsight
// session captured by the agent's ffmpeg screen recorder.

const APP = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()
const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok, d }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }

const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
// Page through rather than assuming the video row is on page one: the
// recordings table is never pruned, so every suite run buries older rows
// deeper. The endpoint pages with page/size, not offset.
const isReplayableVideo = (r) => r.format === 'video' && r.status === 'COMPLETED' && (r.size_bytes || 0) > 10000
let vid = null
for (let p = 1; p <= 20 && !vid; p++) {
  const list = (await (await fetch(`${API}/api/v1/pam/admin/recordings?limit=50&page=${p}`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
  const rows = list.recordings || list.items || list
  const batch = Array.isArray(rows) ? rows : []
  if (!batch.length) break
  vid = batch.find(isReplayableVideo) || null
}
check('a completed desktop VIDEO recording exists to replay', !!vid,
  vid ? `${vid.resource_name} ${vid.size_bytes}B ${vid.duration_seconds}s` : 'none found')
if (!vid) process.exit(1)

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const page = await (await browser.newContext({ viewport: { width: 1600, height: 1000 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])
await page.goto(APP + '/admin/audit?tab=recordings', { waitUntil: 'networkidle' })
await page.waitForTimeout(2500)

// Open THIS recording, addressed by its own session id.
//
// Not "the first row", and not "the first row mentioning the resource": both
// pick up whichever session is newest, and a session still in progress opens
// a viewer that correctly says "come back when it is COMPLETED" — which then
// reads as a broken player rather than as a test aimed at the wrong row.
// Filtered to COMPLETED first, so a session still in progress cannot be the
// row that opens: its viewer correctly says "come back when it is COMPLETED",
// which then reads as a broken player rather than as a test aimed wrong.
await page.getByRole('button', { name: /^COMPLETED$/ }).first().click().catch(() => {})
await page.waitForTimeout(1800)

// Walk the console's own pager to the row rather than assuming it is on page
// one: recordings are never pruned, so the table grows past a single page and
// this suite used to fail on its own positional assumption, not on the player.
// Matched on session id only. A resource-name fallback finds the wrong row:
// the same resource also has rrweb and asciicast recordings, and opening one
// of those reports "no <video>" as if the video player were broken.
let rowSel = null
for (let hop = 0; hop < 20; hop++) {
  const byId = page.locator('tbody tr').filter({ hasText: vid.session_id.slice(0, 8) }).first()
  if (await byId.count()) { rowSel = byId; break }
  const next = page.getByRole('button', { name: 'Next page' }).first()
  if (!(await next.count()) || (await next.isDisabled().catch(() => true))) break
  await next.click()
  await page.waitForTimeout(1200)
}
check('the recording is reachable in the console table', !!rowSel,
  rowSel ? `row for ${vid.resource_name}` : 'not found on any page')
if (!rowSel) { await browser.close(); process.exit(1) }
await rowSel.getByRole('button', { name: /play recording/i }).first().click()
await page.waitForTimeout(7000)

const modal = page.locator('.fixed.inset-0').first()
check('the viewer opened', await modal.isVisible().catch(() => false))

// A video recording must render a <video>, not the rrweb stage.
const video = modal.locator('video').first()
const hasVideo = await video.count() > 0
check('it renders a <video> element for a desktop recording', hasVideo)

if (hasVideo) {
  const meta = await video.evaluate((el) => ({
    src: (el.currentSrc || el.src || '').slice(0, 40),
    duration: el.duration,
    w: el.videoWidth, h: el.videoHeight,
    readyState: el.readyState,
    error: el.error ? el.error.code : null,
  }))
  check('the browser decoded it — real dimensions and duration',
    meta.w > 0 && meta.h > 0 && Number.isFinite(meta.duration) && meta.duration > 1,
    `${meta.w}x${meta.h} ${Number(meta.duration || 0).toFixed(1)}s readyState=${meta.readyState}`)
  check('no media error (VP9 must decode in a plain Chromium build)',
    meta.error === null, `error code ${meta.error}`)
  check('it is served from PAM, not a bare file path', /^blob:|^http/.test(meta.src), meta.src)

  // Press play and confirm the position advances.
  const before = await video.evaluate((el) => el.currentTime)
  await page.getByRole('button', { name: /^play$/i }).first().click().catch(() => {})
  await page.waitForTimeout(3000)
  const after = await video.evaluate((el) => el.currentTime)
  check('pressing play advances the video', after > before, `${before.toFixed(2)}s -> ${after.toFixed(2)}s`)
}

const fatal = errors.filter((e) => !/favicon|manifest|ResizeObserver/i.test(e))
check('no page errors while replaying the video', fatal.length === 0, fatal[0] || '')
await page.screenshot({ path: '/tmp/replay-video.png' })
await browser.close()

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) { failed.forEach((f) => console.log(`  FAILED: ${f.n} — ${f.d}`)); process.exit(1) }
