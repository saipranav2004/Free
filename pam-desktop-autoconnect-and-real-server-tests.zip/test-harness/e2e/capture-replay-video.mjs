// Record the PAM console REPLAYING a brokered session, so the replay can be
// watched outside the product as an ordinary video file.
//
// A brokered web session is stored as an rrweb event stream, not as video:
// the console reconstructs the operator's screen from DOM mutations at replay
// time. That is the right artifact to store (searchable, a fraction of the
// size, and it carries the DOM rather than a picture of it) but it cannot be
// opened in a media player, so there is no way to hand someone "the
// recording" to look at. This films the player itself.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const recordingId = process.argv[2] || readFileSync('/tmp/rec-id', 'utf8').trim()
const outDir = process.argv[3] || '/tmp/replay-capture'
const APP = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'

// Paged, not a single large limit: the recordings table is never pruned, so
// a recording made minutes ago can already be off the first page.
let rec = null
for (let p = 1; p <= 20 && !rec; p++) {
  const meta = await (await fetch(`${API}/api/v1/pam/admin/recordings?limit=100&page=${p}`, {
    headers: { Authorization: 'Bearer ' + token },
  })).json()
  const rows = meta.data?.recordings || []
  if (!rows.length) break
  rec = rows.find((r) => r.id === recordingId) || null
}
if (!rec) { console.error('recording not found:', recordingId); process.exit(1) }
console.log(`filming ${rec.resource_name} — ${rec.format}, ${rec.size_bytes} B, ${rec.duration_seconds}s`)

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({
  viewport: { width: 1440, height: 900 },
  recordVideo: { dir: outDir, size: { width: 1440, height: 900 } },
})
const page = await ctx.newPage()

// root is MFA-enforced by policy; forcing mfa_verified on /auth/me only, with
// every other call passed straight through, films the real console against
// the real recording rather than a mock.
await ctx.route('**/api/v1/auth/me', async (route) => {
  const resp = await route.fetch()
  const body = await resp.json()
  if (body?.data) { body.data.mfa_verified = true; body.data.mfa_enrolment_required = false }
  await route.fulfill({ response: resp, json: body })
})
await page.addInitScript((t) => {
  sessionStorage.setItem('pam_session', JSON.stringify({
    accessToken: t, refreshToken: 'r',
    expiresAt: new Date(Date.now() + 36e5).toISOString(), user: null,
  }))
}, token)

await page.goto(`${APP}/admin/audit?tab=recordings`, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2500)

// Open THIS recording by its own session id, not "the first row".
const rows = page.locator('tbody tr')
const n = await rows.count()
let opened = false
for (let i = 0; i < n && !opened; i++) {
  const t = await rows.nth(i).innerText().catch(() => '')
  if (t.includes(rec.session_id.slice(0, 8))) {
    await rows.nth(i).click().catch(() => {})
    await page.waitForTimeout(2500)
    opened = /Command log|Properties/i.test(await page.locator('body').innerText())
  }
}
if (!opened) {
  for (let i = 0; i < n && !opened; i++) {
    const t = await rows.nth(i).innerText().catch(() => '')
    if (t.includes(rec.resource_name)) {
      await rows.nth(i).click().catch(() => {})
      await page.waitForTimeout(2500)
      opened = /Command log|Properties/i.test(await page.locator('body').innerText())
    }
  }
}
console.log('viewer opened:', opened)

// Play it, at speed, and let the player run so the film shows the session.
await page.getByRole('button', { name: /^(play|pause)$/i }).first().click().catch(() => {})
await page.waitForTimeout(1500)
const speed = page.locator('select').filter({ hasText: /x/ }).first()
await speed.selectOption('4').catch(() => {})
console.log('playing…')
await page.waitForTimeout(30000)

await ctx.close()   // finalises the video file
await browser.close()
console.log('done')
