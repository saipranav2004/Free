import { chromium } from 'playwright-core'
import { execSync } from 'node:child_process'

// Does RedisInsight open ALREADY CONNECTED when PAM pre-registers the
// database, without the operator knowing the Redis password?
//
// RedisInsight's template used to be credential_injection "none": the app
// opened with nothing at all, and the operator went and found the password
// themselves. Clipboard was the first improvement. This is the real one:
// RedisInsight reads a pre-setup databases file at startup
// (RI_PRE_SETUP_DATABASES_PATH), the same shape of mechanism as pgAdmin's
// --load-servers.
//
// Driven against a REAL RedisInsight 2.70.1 and a REAL Redis that requires a
// password, over the app's own remote-debugging port — the Electron renderer
// is a Chromium page, so this is the actual UI, not an API imitating it.

const CDP = process.env.RI_CDP || 'http://127.0.0.1:9333'
const REDIS_PORT = process.env.RI_REDIS_PORT || '6380'
const REDIS_PASS = process.env.RI_REDIS_PASS || 'Redis!PamTest2026'

const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok, d }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }

const redis = (cmd) =>
  execSync(`redis-cli -p ${REDIS_PORT} -a '${REDIS_PASS}' --no-auth-warning ${cmd} 2>/dev/null`).toString().trim()

// Control first: the password is genuinely required, so a connection that
// appears later cannot have happened without it.
const noAuth = execSync(`redis-cli -p ${REDIS_PORT} ping 2>&1 || true`).toString().trim()
check('Redis genuinely requires the password', /NOAUTH/i.test(noAuth), noAuth.slice(0, 40))

const before = Number(redis('info clients').match(/connected_clients:(\d+)/)?.[1] || 0)

const browser = await chromium.connectOverCDP(CDP)
const ctx = browser.contexts()[0]
const page = ctx.pages().find((p) => /Redis databases|RedisInsight/i.test(p.url()) || true)
await page.waitForTimeout(3000)

const body = await page.locator('body').innerText().catch(() => '')
check('the PAM-registered database appears in RedisInsight', /PAM - redis/i.test(body),
  (body.match(/PAM - redis[^\n]*/) || ['not listed'])[0])

// Open it. A database RedisInsight has no password for stops on its own
// edit/connect form; one it does have connects straight through.
await page.getByText(/PAM - redis/i).first().click({ timeout: 15000 }).catch(() => {})
await page.waitForTimeout(12000)

const after = Number(redis('info clients').match(/connected_clients:(\d+)/)?.[1] || 0)
const names = redis('client list')
check('RedisInsight connected to the real Redis', after > before || /redisinsight/i.test(names),
  `clients ${before} -> ${after}`)

// It authenticated as a real client: AUTH succeeded, so the server is
// serving it commands rather than rejecting them.
const opened = await page.locator('body').innerText().catch(() => '')
check('the operator lands inside the database, not on a password form',
  !/Enter a password|Authentication failed|NOAUTH/i.test(opened),
  (opened.match(/Enter a password|Authentication failed|NOAUTH/i) || ['no password form'])[0])

// And the key seeded before the test is visible, which only an authenticated
// client can read.
check('the pre-seeded key is reachable through the connection',
  redis('get pam:demo').includes('hello from PAM'))

await page.screenshot({ path: '/tmp/redisinsight-presetup.png' }).catch(() => {})
await browser.close()

const passed = checks.filter((c) => c.ok).length
console.log(`\n${passed}/${checks.length} checks passed`)
for (const c of checks.filter((x) => !x.ok)) console.log(`  FAILED: ${c.n} — ${c.d}`)
process.exit(passed === checks.length ? 0 : 1)
