// The three web applications, through PAM only, against REAL servers.
//
// Every earlier pass at Metabase ran against e2e/stub/metabase.cjs — a stub I
// wrote from the same docs I wrote the authenticator from, so it could only
// ever agree with me. This drives:
//
//   MinIO     a real MinIO (the console on :9001), including the file list
//             INSIDE a bucket, which is the part that rides a WebSocket
//   Metabase  a real metabase.jar on :3200, set up with a real admin account
//   Qdrant    a real qdrant 1.12.4 on :6333 with an API key enforced, whose
//             credential is vaulted with NO account name
//
// For each: the session is opened through PAM, the operator arrives
// authenticated without ever holding the secret, and PAM records it.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  return { ok: r.ok, status: r.status, data: (await r.json().catch(() => ({}))).data }
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})

// Waits for PAM's own recording row to reach COMPLETED, rather than trusting
// that a session that looked fine was also captured.
// The artifact is finalised when the session ends, which is not instant, so
// this waits rather than sampling once. 90s: a JSON target's transcript is
// written on close and has been observed to land ~60s in.
const recordingFor = async (sessionId) => {
  for (let i = 0; i < 45; i++) {
    const r = await api(`pam/admin/recordings?session_id=${sessionId}&limit=10`)
    const rows = r.data?.recordings || []
    const done = rows.find((x) => x.status === 'COMPLETED' && (x.size_bytes || 0) > 0)
    if (done) return done
    await new Promise((res) => setTimeout(res, 2000))
  }
  return null
}

const openSession = async (resourceId) => {
  const open = await api(`pam/resources/${resourceId}/web-session`, { method: 'POST', body: '{}' })
  if (!open.ok) return null
  return open.data
}

const strategyOf = async (webProxySessionId) => {
  const s = await api('pam/admin/web-sessions')
  const row = (s.data?.sessions || s.data || []).find((x) => x.id === webProxySessionId)
  return row?.auth_strategy || 'unknown'
}

// A brokered web session has TWO ends to close, and closing only the first
// leaves the artifact unfinalised:
//
//   /sessions/:id/end        the tracked connection session — marks the
//                            session COMPLETED, but deliberately does NOT
//                            touch the recording's status, because only
//                            whoever saves the artifact knows whether it
//                            saved (see closeRecordingTx)
//   /web-sessions/:id/end    the proxy session — this is what flushes and
//                            finalises the transcript
//
// Ending only the first and then polling for a COMPLETED recording reports a
// missing recording for about two minutes, until an idle sweep closes the
// proxy session. That is the test being wrong, not the product.
const endSession = async (sessionId, webProxySessionId) => {
  if (webProxySessionId) {
    await api(`pam/web-sessions/${webProxySessionId}/end`, { method: 'POST', body: '{}' }).catch(() => {})
  }
  await api(`pam/sessions/${sessionId}/end`, { method: 'POST', body: '{}' }).catch(() => {})
}

// ── 1. Qdrant ─────────────────────────────────────────────────────────────
// The control first: the same URL without PAM must be refused, otherwise
// "it worked through PAM" says nothing about PAM.
{
  const direct = await fetch('http://127.0.0.1:6333/collections').then((r) => r.status).catch(() => 0)
  check('Qdrant genuinely enforces its API key (direct request is refused)', direct === 401, `HTTP ${direct}`)

  const s = await openSession('qdrant-live')
  check('PAM opens a brokered session for the qdrant resource', !!s)
  if (s) {
    check('it injects the API key instead of leaving the operator to paste it',
      (await strategyOf(s.web_proxy_session_id)) === 'qdrant_api_key',
      await strategyOf(s.web_proxy_session_id))

    const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage()
    // launch_url is /__pam/auth?t=<single-use token>; it has to be visited as
    // given, to exchange the token for the session cookie. Everything after
    // that is an ordinary relative navigation on the session's own subdomain.
    await page.goto(s.launch_url, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(2000)
    const origin = new URL(page.url()).origin
    await page.goto(`${origin}/collections`, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(2500)
    const body = await page.locator('body').innerText()
    check('the operator reaches Qdrant authenticated, with no key in hand',
      body.includes('pam_demo') && !/Unauthorized|Must provide an API key/i.test(body),
      body.replace(/\s+/g, ' ').slice(0, 90))

    // The key must not be reachable from the page.
    const leaked = await page.evaluate((k) =>
      document.documentElement.innerHTML.includes(k) || document.cookie.includes(k),
    'pam-test-qdrant-key-7f3a91')
    check('the API key never reaches the browser', !leaked)

    // Browse a little so the session has something to record.
    for (const p of ['/collections/pam_demo', '/telemetry', '/collections']) {
      await page.goto(`${origin}${p}`, { waitUntil: 'domcontentloaded' }).catch(() => {})
      await page.waitForTimeout(1800)
    }
    await page.close()
    await endSession(s.session_id, s.web_proxy_session_id)
    const rec = await recordingFor(s.session_id)
    check('PAM recorded the qdrant session', !!rec,
      rec ? `${rec.format} ${rec.size_bytes}B ${rec.duration_seconds}s` : 'no completed recording')
    // Qdrant answers JSON, so there is no DOM to reconstruct and no rrweb
    // stream to collect. The honest artifact for an API target is the
    // request transcript, and asserting WHICH one lands is the point: a
    // silent fall-through to "no recording at all" on a resource marked
    // always_record would be the real failure.
    check('and recorded it as a request transcript, the right artifact for a JSON API',
      rec?.format === 'asciicast', rec?.format || 'none')
  }
}

// ── 2. Metabase ───────────────────────────────────────────────────────────
{
  const PASSWORD = 'PamTest!2026Metabase'
  const direct = await fetch('http://127.0.0.1:3200/api/user/current').then((r) => r.status).catch(() => 0)
  check('Metabase genuinely requires a session (direct request is refused)', direct === 401, `HTTP ${direct}`)

  const s = await openSession('metabase-live')
  check('PAM opens a brokered session for the metabase resource', !!s)
  if (s) {
    check('it logs in server-side rather than falling back to "none"',
      (await strategyOf(s.web_proxy_session_id)) === 'metabase_session',
      await strategyOf(s.web_proxy_session_id))

    const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage()
    const errors = []
    page.on('pageerror', (e) => errors.push(e.message))
    let replayBatches = 0
    page.on('request', (r) => {
      if (r.url().includes('/__pam/replay') && r.method() === 'POST') replayBatches++
    })

    await page.goto(s.launch_url, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(9000)
    const text = await page.locator('body').innerText()
    check('the operator lands signed in, not on the login form',
      !/Sign in to Metabase|Email address/i.test(text),
      text.replace(/\s+/g, ' ').slice(0, 80))

    // Ask Metabase itself who it thinks is logged in — its own answer, not
    // the rendered page's.
    const who = await page.evaluate(async () => {
      const r = await fetch('/api/user/current', { credentials: 'include' })
      return r.ok ? (await r.json()).email : `HTTP ${r.status}`
    })
    check('Metabase itself reports the vaulted account as the logged-in user',
      who === 'pam-operator@deepalgorithms.test', String(who))

    const leaked = await page.evaluate((pw) => {
      let inStorage = false
      try {
        for (const s of [localStorage, sessionStorage]) {
          for (let i = 0; i < s.length; i++) if ((s.getItem(s.key(i)) || '').includes(pw)) inStorage = true
        }
      } catch { /* storage can be blocked; not a leak */ }
      return document.documentElement.innerHTML.includes(pw) || document.cookie.includes(pw) || inStorage
    }, PASSWORD)
    check('the password never reaches the browser — DOM, cookies, storage', !leaked)

    // The upstream session cookie is the proxy's to hold, not the page's.
    const sessionCookieVisible = await page.evaluate(() => document.cookie.includes('metabase.SESSION'))
    check('the upstream session cookie is not exposed to page script', !sessionCookieVisible)

    // Browse, so the recording is a real session rather than one page load.
    const mbOrigin = new URL(page.url()).origin
    for (const p of ['/browse/databases', '/collection/root', '/browse/models']) {
      await page.goto(`${mbOrigin}${p}`, { waitUntil: 'domcontentloaded' }).catch(() => {})
      await page.waitForTimeout(3000)
    }
    check('the browser delivered rrweb batches', replayBatches > 0, `${replayBatches} batches`)
    check('no page errors while using Metabase through the proxy', errors.length === 0, errors[0] || '')
    await page.close()
    await endSession(s.session_id, s.web_proxy_session_id)
    const rec = await recordingFor(s.session_id)
    check('PAM recorded the metabase session', !!rec,
      rec ? `${rec.format} ${rec.size_bytes}B ${rec.duration_seconds}s` : 'no completed recording')
    check('and recorded it as a visual replay, not just a request log',
      rec?.format === 'rrweb', rec?.format || '')
  }
}

// ── 3. MinIO ──────────────────────────────────────────────────────────────
// The bucket list was never the reported problem. The file list INSIDE a
// bucket is, because that one rides /ws/objectManager.
{
  const s = await openSession('minio-real')
  check('PAM opens a brokered session for the minio resource', !!s)
  if (s) {
    const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage()
    const wsFailures = []
    page.on('websocket', (ws) => ws.on('socketerror', () => wsFailures.push(ws.url())))

    // Same navigation minio-objects.mjs uses — MinIO Console renders its
    // bucket rows virtualised, so a CSS-selector count is not a reliable
    // reading of whether the list loaded; its text is.
    const dismissModal = async () => {
      const d = page.locator('[role="dialog"]').first()
      if (await d.count()) {
        await d.getByRole('button', { name: /acknowledge|accept|close|ok|agree|got it/i })
          .first().click({ timeout: 1500 }).catch(() => {})
        await page.keyboard.press('Escape').catch(() => {})
        await page.waitForTimeout(800)
      }
    }

    await page.goto(s.launch_url, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(6000)
    await dismissModal()
    check('the bucket list loads', /Buckets/i.test(await page.locator('body').innerText()))

    // One click further than every earlier suite went: the object list
    // inside a bucket, which is the part that rides /ws/objectManager.
    await page.goto(new URL(`/browser/${process.env.PAM_TEST_BUCKET || 'pam-objects'}`, page.url()).toString(), { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(2000)
    await dismissModal()

    let listed = false
    const deadline = Date.now() + 25000
    while (Date.now() < deadline && !listed) {
      if (/report-01\.txt/.test(await page.locator('body').innerText().catch(() => ''))) { listed = true; break }
      await page.waitForTimeout(1000)
    }
    const pane = await page.locator('body').innerText().catch(() => '')
    check('the file list INSIDE the bucket loads, not an endless spinner', listed,
      listed ? 'objects listed' : (/Loading\.\.\./i.test(pane) ? 'still "Loading..." after 25s' : pane.replace(/\s+/g, ' ').slice(0, 100)))
    check('no WebSocket failed during the object listing', wsFailures.length === 0,
      wsFailures[0] || '')

    await page.waitForTimeout(3000)
    await page.close()
    await endSession(s.session_id, s.web_proxy_session_id)
    const rec = await recordingFor(s.session_id)
    check('PAM recorded the minio session', !!rec,
      rec ? `${rec.format} ${rec.size_bytes}B ${rec.duration_seconds}s` : 'no completed recording')
  }
}

await browser.close()
const passed = checks.filter((c) => c.ok).length
console.log(`\n${passed}/${checks.length} checks passed`)
for (const c of checks.filter((x) => !x.ok)) console.log(`  FAILED: ${c.name} — ${c.detail}`)
process.exit(passed === checks.length ? 0 : 1)
