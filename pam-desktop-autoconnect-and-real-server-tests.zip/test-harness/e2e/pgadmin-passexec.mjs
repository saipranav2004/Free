import { chromium } from 'playwright-core'
import { readFileSync, existsSync } from 'node:fs'

// Does pgAdmin 4 open ALREADY CONNECTED when the server definition carries a
// PasswordExecCommand instead of a password?
//
// This is the question behind "pgAdmin opens but I still have to connect
// manually". The previous answer was that pgAdmin's Connect dialog is a UI
// gate no credential can pass. That is true of PGPASSFILE, and false in
// general: pgAdmin documents PasswordExecCommand (desktop mode only), whose
// stdout becomes the SQL password at connect time. That turns the agent into
// a credential broker the client calls — the desktop analogue of what the web
// proxy already does — and the password never lands on disk.
//
// Driven against a REAL pgAdmin 4 (pip pgadmin4, desktop mode) and a REAL
// PostgreSQL role that requires scram-sha-256, so a missing password fails.

const PGADMIN = 'http://127.0.0.1:5051'
const HELPER_LOG = process.env.PAM_PASSEXEC_LOG || '/tmp/passexec.log'
const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok, d }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const page = await (await browser.newContext({ viewport: { width: 1600, height: 1000 } })).newPage()

await page.goto(PGADMIN, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(12000)

// The tree renders the imported group collapsed; expand it first.
const group = page.getByText('PAM', { exact: true }).first()
await group.waitFor({ timeout: 30000 }).catch(() => {})
await group.click().catch(() => {})
await page.waitForTimeout(1200)
await group.dblclick().catch(() => {})
await page.waitForTimeout(2500)

const serverLabel = page.getByText('PAM - agent emitted').first()
await serverLabel.waitFor({ timeout: 20000 }).catch(() => {})
check('the PAM-imported server appears in pgAdmin', await serverLabel.count() > 0)
if (await serverLabel.count() === 0) {
  await page.screenshot({ path: '/tmp/pgadmin-passexec.png' })
  await browser.close()
  process.exit(1)
}

// Connect. In pgAdmin a server that needs a password answers this click with
// a modal asking for one; that modal appearing is exactly the failure being
// tested for.
//
// CONTROL MODE (PAM_PASSEXEC_EXPECT=prompt) runs the identical script against
// the identical server definition with PasswordExecCommand removed, and
// asserts the dialog DOES appear. Without it, "no dialog was shown" could
// just mean the locator never matches anything and the check is vacuous.
// Clicks are best-effort: when pgAdmin does prompt, the modal is up before
// the second click lands and intercepts it — which is the control's whole
// point, not a test failure.
const expectPrompt = process.env.PAM_PASSEXEC_EXPECT === 'prompt'
const pwDialog = page.locator('div[role="dialog"], .MuiDialog-root').filter({ hasText: /Connect to Server|password/i }).first()

await serverLabel.click({ timeout: 8000 }).catch(() => {})
await page.waitForTimeout(1500)
if (!(await pwDialog.count())) {
  await serverLabel.dblclick({ timeout: 8000 }).catch(() => {})
}
await page.waitForTimeout(9000)

const sawPrompt = await pwDialog.count() > 0 && await pwDialog.isVisible().catch(() => false)

if (expectPrompt) {
  check('CONTROL: without the password command pgAdmin DOES ask', sawPrompt,
    sawPrompt ? 'the dialog appeared, so the check above is not vacuous' : 'no dialog — the check above proves nothing')
  const stillNoBackend = (await import('node:child_process')).execSync(
    `psql -h /tmp -p 5433 -U postgres -d postgres -At -c "select count(*) from pg_stat_activity where usename='pam_pgadmin_test'"`,
  ).toString().trim()
  check('CONTROL: and does not reach PostgreSQL', stillNoBackend === '0', `${stillNoBackend} backend(s)`)
  await page.screenshot({ path: '/tmp/pgadmin-control-prompt.png' })
  await browser.close()
  const ok = checks.filter((c) => c.ok).length
  console.log(`\n${ok}/${checks.length} checks passed`)
  process.exit(ok === checks.length ? 0 : 1)
}

check('NO password dialog was shown', !sawPrompt, sawPrompt ? 'pgAdmin still asked for a password' : 'connected without asking')

// pgAdmin's OWN log is the evidence that it ran the command — the agent
// deliberately leaves no trace of its own, since anything it wrote would be a
// record that a credential was handed over, sitting in a file next to the
// credential.
const pgLog = existsSync(HELPER_LOG) ? readFileSync(HELPER_LOG, 'utf8') : ''
check('pgAdmin ran the credential command', /Calling passexec/.test(pgLog),
  (pgLog.match(/.*passexec.*/i) || ['not found in pgAdmin\'s log'])[0])
check('the command completed successfully for pgAdmin', /Passexec completed successfully/.test(pgLog))

// And the server definition pgAdmin is working from is the agent's own,
// calling back into the agent binary.
const { execSync: exec0 } = await import('node:child_process')
const storedCmd = exec0(
  `python3 -c "import sqlite3;print(sqlite3.connect('${process.env.PGADMIN_SQLITE}').execute('select passexec_cmd from server').fetchone()[0])"`,
).toString().trim()
check('the stored command calls back into pam-agent', /pam-agent'? pgadmin-credential/.test(storedCmd),
  storedCmd.slice(0, 90) + '…')

// The connection is genuinely open — asserted against PostgreSQL itself
// rather than the tree, because the tree renders asynchronously and a
// backend in pg_stat_activity is the thing that actually proves the password
// was accepted. The role requires scram-sha-256, so this row cannot exist
// unless a correct password was supplied.
const { execSync } = await import('node:child_process')
const backend = execSync(
  `psql -h /tmp -p 5433 -U postgres -d postgres -At -c "select usename||' / '||application_name from pg_stat_activity where usename='pam_pgadmin_test'"`,
).toString().trim()
check('PostgreSQL shows an authenticated backend from pgAdmin', backend.includes('pgAdmin'), backend || 'no backend')

// And the password is not sitting in pgAdmin's own config database.
const stored = process.env.PGADMIN_SQLITE
let pwOnDisk = null
if (stored) {
  const { execSync } = await import('node:child_process')
  pwOnDisk = execSync(`python3 -c "import sqlite3;print(sqlite3.connect('${stored}').execute('select password from server').fetchone()[0])"`).toString().trim()
}
check('the password was never written to pgAdmin\'s config database', pwOnDisk === 'None' || pwOnDisk === '' || pwOnDisk === null,
  `server.password = ${pwOnDisk}`)

await page.screenshot({ path: '/tmp/pgadmin-passexec.png', fullPage: false })
await browser.close()

const passed = checks.filter((c) => c.ok).length
console.log(`\n${passed}/${checks.length} checks passed`)
for (const c of checks.filter((x) => !x.ok)) console.log(`  FAILED: ${c.n} — ${c.d}`)
process.exit(passed === checks.length ? 0 : 1)
