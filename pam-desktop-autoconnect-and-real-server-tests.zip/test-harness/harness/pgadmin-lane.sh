#!/bin/bash
# Puts real pgAdmin 4 into one of the two lanes e2e/pgadmin-passexec.mjs
# drives, and restarts it clean:
#
#   passexec  the server definition the AGENT emits, carrying
#             PasswordExecCommand — the operator should land connected
#   control   the same definition with that one key removed — the operator
#             should get pgAdmin's password dialog and no connection
#
# The two differ by nothing else, which is what makes the comparison mean
# something.
set -e
LANE="${1:-passexec}"
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
P=$S/real/pgadmin-venv/lib/python3.11/site-packages/pgadmin4

case "$LANE" in
  passexec) FILE=$(ls $S/real/agent-out/*.pgadmin-servers.json) ;;
  control)  FILE=$S/real/servers-control.json ;;
  *) echo "usage: $0 [passexec|control]" >&2; exit 2 ;;
esac

lsof -ti:5051 | while read -r pid; do kill "$pid"; done
sleep 4

# Every run starts from no servers and no open backends, so a connection
# observed afterwards can only have come from this run.
python3 -c "import sqlite3;c=sqlite3.connect('$S/real/pgadmin-data/pgadmin4.db');c.execute('delete from server');c.commit()"
psql -h /tmp -p 5433 -U postgres -d postgres -q -c \
  "select pg_terminate_backend(pid) from pg_stat_activity where usename='pam_pgadmin_test';" >/dev/null
rm -f "$S/real/pgadmin-data/pgadmin4.log"

cd "$P"
PGADMIN_DATA_DIR=$S/real/pgadmin-data "$S/real/pgadmin-venv/bin/python" setup.py \
  load-servers "$FILE" --user pgadmin4@pgadmin.org 2>&1 | grep -E "Added|Error" || true
PGADMIN_DATA_DIR=$S/real/pgadmin-data nohup "$S/real/pgadmin-venv/bin/python" pgAdmin4.py \
  > "$S/real/pgadmin.log" 2>&1 &

for _ in $(seq 1 40); do
  if [ "$(curl -s -o /dev/null -w '%{http_code}' --noproxy '*' http://127.0.0.1:5051/)" = "302" ]; then
    echo "pgAdmin up in lane: $LANE"
    exit 0
  fi
  sleep 2
done
echo "pgAdmin did not come up" >&2
exit 1
