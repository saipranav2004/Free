#!/bin/bash
# Registers the REAL Metabase and the REAL Qdrant as PAM resources.
#
# Both replace stand-ins. A stub cannot disagree with the product it imitates,
# so a strategy tested only against one is tested against my own reading of
# the docs — which is exactly how the Metabase gap survived a round of
# "12/12 passing".
#
# Metabase: a real metabase.jar on :3200, set up with a real admin account.
# Qdrant:   a real qdrant 1.12.4 on :6333 with QDRANT__SERVICE__API_KEY set,
#           so a request without the key genuinely answers 401.
#
# The Qdrant credential is stored the way the reported one is: credential_type
# api_key, NO account name.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
PSQL="psql -h 127.0.0.1 -p 5433 -U postgres -d postgres"
T=$(cat /tmp/tok)
API=http://127.0.0.1:8080
RID=$($PSQL -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
SAFE=$($PSQL -At -c "SELECT id FROM pam.pam_safes ORDER BY created_at LIMIT 1;")

seed_resource() {  # id name type host port console_url
  $PSQL -q -c "
    DELETE FROM pam.pam_credentials WHERE resource_id='$1';
    DELETE FROM pam.pam_resources   WHERE id='$1';
    INSERT INTO pam.pam_resources
      (id,name,description,resource_type,host,port,connect_mode,console_url,
       is_active,always_record,created_by,created_at,updated_at)
    VALUES ('$1','$2','real $3 for end-to-end brokered session tests','$3','$4',$5,
            'embed_redirect','$6',true,true,'$RID',NOW(),NOW());"
}

vault_credential() {  # resource_id json
  local cid
  cid=$(curl -s --noproxy '*' -X POST -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
    -d "$2" "$API/api/v1/pam/safes/$SAFE/credentials" \
    | python3 -c "import sys,json;print((json.load(sys.stdin).get('data') or {}).get('id',''))")
  if [ -z "$cid" ]; then echo "could not vault the credential for $1 — is /tmp/tok fresh?" >&2; exit 1; fi
  $PSQL -q -c "UPDATE pam.pam_resources SET vault_entry_id='$cid' WHERE id='$1';"
  echo "$cid"
}

# ── Metabase ──────────────────────────────────────────────────────────────
seed_resource metabase-live metabase-live metabase 127.0.0.1 3200 http://127.0.0.1:3200
MB=$(vault_credential metabase-live '{
  "name":"metabase-live-admin",
  "account_name":"pam-operator@deepalgorithms.test",
  "secret_plaintext":"PamTest!2026Metabase",
  "credential_type":"password",
  "resource_id":"metabase-live",
  "description":"Real Metabase admin"}')
echo "metabase-live  -> credential $MB"

# ── Qdrant ────────────────────────────────────────────────────────────────
# NOTE the absence of account_name. This is the reported case: an API key is
# the identity, so there is no account to name. Before the vault change this
# request was rejected with 400.
seed_resource qdrant-live qdrant-live qdrant 127.0.0.1 6333 http://127.0.0.1:6333
QD=$(vault_credential qdrant-live '{
  "name":"qdrant-live-key",
  "secret_plaintext":"pam-test-qdrant-key-7f3a91",
  "credential_type":"api_key",
  "resource_id":"qdrant-live",
  "description":"Real Qdrant API key, no account name"}')
echo "qdrant-live    -> credential $QD (no account name)"
