package main

import (
	"errors"
	"flag"
	"fmt"
	"os"

	"github.com/yourorg/pam-agent/internal/launcher"
)

// cmdPgAdminCredential answers pgAdmin 4's PasswordExecCommand: it prints the
// password for one launch on stdout and nothing else, anywhere.
//
// This is the desktop counterpart of the web proxy's credential injection —
// the client asks the broker for the secret at the moment it connects, rather
// than the secret being handed to the operator. pgAdmin runs this through the
// platform shell with check=True and takes stdout.strip() as the password,
// so the contract is narrow and worth stating exactly:
//
//	stdout  — the password, with no trailing newline added
//	stderr  — an explanation on failure; pgAdmin logs it for the operator
//	exit 0  — only when a password was printed
//
// Hidden from `pam-agent help`: it is an interface for pgAdmin, not for
// people. The password reaches it through a 0600 file written by the launch
// that created the pgAdmin server entry, never through argv, which any
// process on the machine can read.
func cmdPgAdminCredential(args []string) error {
	fs := flag.NewFlagSet(launcher.PgAdminCredentialSubcommand, flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	secretFile := fs.String("secret-file", "", "path to the credential file written by `pam-agent launch`")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *secretFile == "" {
		return errors.New("--secret-file is required")
	}

	secret, err := launcher.ReadPgAdminSecretFile(*secretFile)
	if err != nil {
		// The session is over (the launch cleaned its temp files up) or this
		// is not the user who owns it. Either way pgAdmin should fall back
		// to asking, and its operator should be told why rather than being
		// shown a bare non-zero exit.
		if errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("this PAM session's credential is no longer available — "+
				"start the session again from the PAM console: %w", err)
		}
		return fmt.Errorf("could not read this session's credential: %w", err)
	}
	if secret == "" {
		return errors.New("this PAM session's credential is empty")
	}

	// No newline: pgAdmin strips whitespace, but a password is not something
	// to rely on someone else's trimming for.
	if _, err := os.Stdout.WriteString(secret); err != nil {
		return err
	}
	return nil
}
