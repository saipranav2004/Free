// pam-agent/internal/launcher/redisinsight_presetup.go
//
// Makes RedisInsight open with the resource already registered and
// connectable, instead of handing the operator an empty app.
//
// RedisInsight reads a "pre-setup databases" file at startup, named by
// RI_PRE_SETUP_DATABASES_PATH, and creates each entry in its own store marked
// isPreSetup. It is the same shape of mechanism as pgAdmin's --load-servers:
// the client's own supported way to be told about a connection.
//
// VERIFIED against a real RedisInsight 2.70.1 and a real Redis requiring a
// password: the entry appeared in the app's database list, opening it
// connected (the server went from 1 to 3 clients), and no password form was
// shown. See e2e/redisinsight-presetup.mjs.
//
// TWO THINGS WORTH KNOWING, both established by reading RedisInsight's own
// bundled code rather than its docs:
//
//   - Discovery is skipped entirely unless the app's EULA has been accepted.
//     On any machine where someone has opened RedisInsight once this is
//     already true, but on a brand-new install the first launch will show the
//     consent screen and ignore the file; the second will pick it up. The
//     launch note says so, rather than leaving the operator to wonder why the
//     entry is missing exactly once.
//   - Entries are matched by id, and PAM uses a stable id per resource, so
//     relaunching the same resource updates its entry instead of piling up
//     duplicates.
//
// AND ONE HONEST DIFFERENCE FROM THE PGADMIN ROUTE. pgAdmin can be given a
// command to fetch the password at connect time, so the secret never lands
// anywhere. RedisInsight has no such hook: the password has to be IN this
// file, and RedisInsight then copies it into its own store — encrypted with
// the system keychain where one is available, and in plain text where none
// is. That is still better than the clipboard, which is readable by every
// application on the desktop for as long as it sits there, but it is not the
// same guarantee, and the file is written 0600 and deleted with the session
// for that reason.
package launcher

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

// RedisInsightPreSetupEnv is RedisInsight's own environment variable for the
// pre-setup databases file.
const RedisInsightPreSetupEnv = "RI_PRE_SETUP_DATABASES_PATH"

// redisInsightDatabase mirrors the entry shape RedisInsight validates. Only
// the fields PAM actually sets are here; everything else RedisInsight
// defaults for itself.
type redisInsightDatabase struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Host     string `json:"host"`
	Port     int    `json:"port"`
	Username string `json:"username,omitempty"`
	Password string `json:"password,omitempty"`
}

// redisInsightDatabaseID derives a stable, RedisInsight-acceptable id for a
// resource.
//
// It must look like a UUID: RedisInsight validates the field and silently
// drops an entry that fails, which presents as "PAM did nothing" with no
// error anywhere. Derived from the resource rather than random so relaunching
// the same resource replaces its entry instead of adding another.
func redisInsightDatabaseID(resourceType, host string, port int) string {
	sum := sha256.Sum256([]byte(fmt.Sprintf("pam-agent/redisinsight/%s/%s/%d", resourceType, host, port)))
	h := hex.EncodeToString(sum[:])
	// 8-4-4-4-12, with the version and variant nibbles set so it is a
	// well-formed v4-shaped UUID.
	return fmt.Sprintf("%s-%s-4%s-8%s-%s", h[0:8], h[8:12], h[13:16], h[17:20], h[20:32])
}

// writeRedisInsightPreSetupFile writes the pre-setup databases file (0600,
// temp dir) for one resource.
func writeRedisInsightPreSetupFile(tempDir string, resolved *apiclient.ResolvedLaunch) (string, error) {
	entry := redisInsightDatabase{
		ID:       redisInsightDatabaseID(resolved.ResourceType, resolved.Host, resolved.Port),
		Name:     fmt.Sprintf("PAM - %s (%s:%d)", resolved.ResourceType, resolved.Host, resolved.Port),
		Host:     resolved.Host,
		Port:     resolved.Port,
		Username: resolved.AccountName,
		Password: resolved.Password,
	}

	// A LIST, not an object: RedisInsight maps over the parsed file, so an
	// object throws inside its own reader and the whole file is discarded.
	raw, err := json.MarshalIndent([]redisInsightDatabase{entry}, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to encode RedisInsight pre-setup file: %w", err)
	}

	f, err := os.CreateTemp(tempDir, "pam-agent-*.redisinsight-databases.json")
	if err != nil {
		return "", fmt.Errorf("failed to create temp RedisInsight pre-setup file: %w", err)
	}
	defer f.Close()
	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp RedisInsight pre-setup file: %w", err)
	}
	if _, err := f.Write(raw); err != nil {
		return "", fmt.Errorf("failed to write temp RedisInsight pre-setup file: %w", err)
	}
	return f.Name(), nil
}
