package launcher

import (
	"encoding/json"
	"os"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

func TestWritePgAdminServersFile(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql",
		Host:         "10.0.3.30",
		Port:         5433,
		AccountName:  "app_reader",
		Password:     "should-never-appear-anywhere",
	}

	path, err := writePgAdminServersFile(tempDir, resolved, "appdb", "")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	fi, err := os.Stat(path)
	if err != nil {
		t.Fatalf("temp file not created: %v", err)
	}
	if perm := fi.Mode().Perm(); perm != 0o600 {
		t.Fatalf("got permissions %o, want 0600", perm)
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	// The password must not appear ANYWHERE in this file. pgAdmin does not
	// import passwords at all, and the passexec route deliberately keeps it
	// that way: the secret lives in a separate 0600 file the agent hands
	// back at connect time. See pgadmin_passexec.go.
	if strings.Contains(string(raw), resolved.Password) {
		t.Fatal("password leaked into the pgAdmin4 servers preseed file — this must only ever contain host/port/database/username")
	}

	var doc pgAdminServersFile
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatalf("written file is not valid JSON: %v\ncontent: %s", err, raw)
	}
	entry, ok := doc.Servers["1"]
	if !ok {
		t.Fatal(`expected a "1" entry under "Servers"`)
	}
	if entry.Host != resolved.Host {
		t.Errorf("host = %q, want %q", entry.Host, resolved.Host)
	}
	if entry.Port != resolved.Port {
		t.Errorf("port = %d, want %d", entry.Port, resolved.Port)
	}
	if entry.Username != resolved.AccountName {
		t.Errorf("username = %q, want %q", entry.Username, resolved.AccountName)
	}
	if entry.MaintenanceDB != "appdb" {
		t.Errorf("maintenance db = %q, want %q", entry.MaintenanceDB, "appdb")
	}
}

func TestWritePgAdminServersFileDefaultsMaintenanceDB(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{Host: "10.0.3.30", Port: 5432, AccountName: "app_reader"}

	path, err := writePgAdminServersFile(tempDir, resolved, "", "")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	raw, _ := os.ReadFile(path)
	var doc pgAdminServersFile
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if doc.Servers["1"].MaintenanceDB != "postgres" {
		t.Errorf("expected default maintenance db %q, got %q", "postgres", doc.Servers["1"].MaintenanceDB)
	}
}

// The passexec variant is what makes pgAdmin open already connected. The
// command goes in; the password still does not.
func TestWritePgAdminServersFileCarriesPassexecButNeverThePassword(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{
		Host: "10.0.3.30", Port: 5432, AccountName: "app_reader",
		Password: "should-never-appear-anywhere",
	}
	command := "/opt/pam/pam-agent pgadmin-credential --secret-file /tmp/x"

	path, err := writePgAdminServersFile(tempDir, resolved, "appdb", command)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	raw, _ := os.ReadFile(path)
	if strings.Contains(string(raw), resolved.Password) {
		t.Fatal("password leaked into the pgAdmin servers file")
	}

	var doc pgAdminServersFile
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if got := doc.Servers["1"].PasswordExecCommand; got != command {
		t.Errorf("PasswordExecCommand = %q, want %q", got, command)
	}
	if got := doc.Servers["1"].PasswordExecExpiration; got != pgAdminPassexecExpiration {
		t.Errorf("PasswordExecExpiration = %d, want %d", got, pgAdminPassexecExpiration)
	}
}

// Without a command the keys must be ABSENT, not present-and-empty: pgAdmin
// stores whatever it is given, and an empty command string would leave a
// server that runs "" at every connect instead of prompting.
func TestWritePgAdminServersFileOmitsPassexecKeysWhenUnused(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{Host: "h", Port: 5432, AccountName: "u"}

	path, err := writePgAdminServersFile(tempDir, resolved, "appdb", "")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	raw, _ := os.ReadFile(path)
	if strings.Contains(string(raw), "PasswordExec") {
		t.Fatalf("passexec keys present with no command:\n%s", raw)
	}
}
