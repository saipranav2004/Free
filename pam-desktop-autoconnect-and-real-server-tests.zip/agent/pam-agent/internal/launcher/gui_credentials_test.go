package launcher

import (
	"encoding/json"
	"os"
	"testing"
)

// What each DESKTOP client is actually handed, stated in one place.
//
// The report behind this: "all 4 desktop applications open without the stored
// credentials — only the mongo one arrives connected."
//
// This test previously recorded a weaker answer than the tools allow. It said
// pgAdmin and RedisInsight could only be given a clipboard handoff because
// they always prompt. That is true of the command line and false in general:
// both publish a mechanism for being told a connection, and both were
// verified working against the real applications —
//
//	pgAdmin 4 9.18   PasswordExecCommand, so it asks the agent for the
//	                 password at connect time. Landed connected with no
//	                 dialog; pg_stat_activity showed the backend; the
//	                 password was never stored.
//	RedisInsight     RI_PRE_SETUP_DATABASES_PATH. The entry appeared in its
//	2.70.1           database list and opening it connected to a real
//	                 password-protected Redis.
//
// — so the expectations here are the stronger ones now. SQL Developer remains
// genuinely without such a hook, and that is recorded as a fact about SQL
// Developer, not as a general rule about GUI clients.
func TestEveryDesktopClientGetsTheBestCredentialHandoffItSupports(t *testing.T) {
	raw, err := os.ReadFile("launch-templates.default.json")
	if err != nil {
		t.Fatal(err)
	}
	var templates map[string][]struct {
		ID                  string `json:"id"`
		Kind                string `json:"kind"`
		CredentialInjection string `json:"credential_injection"`
	}
	if err := json.Unmarshal(raw, &templates); err != nil {
		t.Fatal(err)
	}

	want := map[string]string{
		// Compass takes the whole connection string on its command line, so
		// it opens genuinely connected. This is the one the report saw work.
		"mongodb-compass": "connection_string_arg",
		// pgAdmin's server tree is pre-registered AND given a command to
		// fetch the password with, so it connects without a dialog and
		// without the secret being written anywhere. See pgadmin_passexec.go.
		"pgadmin4": "pgadmin_preseed",
		// RedisInsight is told about the database through its own pre-setup
		// file. See redisinsight_presetup.go.
		"redisinsight": "redisinsight_presetup",
		// SQL Developer takes no connection on its command line, has no
		// credential-command hook, and stores its own connections encrypted
		// under a key derived from its installation — so the clipboard is
		// genuinely the best available from the agent alone.
		//
		// The one mechanism that DOES authenticate SQL Developer with no
		// password typed is an Oracle Wallet used as a Secure External
		// Password Store: a wallet plus a sqlnet.ora carrying
		// SQLNET.WALLET_OVERRIDE=TRUE makes `connect /@alias` authenticate
		// from the wallet. It is deliberately not implemented here, because
		// minting one needs Oracle's own `mkstore` on the operator's machine
		// and this has not been verified end to end against a real SQL
		// Developer and a real Oracle. Shipping an unverified credential path
		// is worse than a clipboard that works. Revisit with an Oracle client
		// available to test against.
		"sqldeveloper": "clipboard",
	}

	seen := map[string]string{}
	for _, cands := range templates {
		for _, c := range cands {
			if c.Kind == "gui" {
				seen[c.ID] = c.CredentialInjection
			}
		}
	}

	for id, expected := range want {
		got, ok := seen[id]
		if !ok {
			t.Errorf("no gui template for %s", id)
			continue
		}
		if got != expected {
			t.Errorf("%s: credential_injection = %q, want %q", id, got, expected)
		}
	}

	// The floor: nothing that opens a desktop client leaves the operator with
	// no way to authenticate at all.
	for id, mode := range seen {
		if mode == "" || mode == "none" {
			t.Errorf("%s hands the operator nothing at all — no argument, no preseed, no clipboard", id)
		}
	}

	// The ceiling, and the thing the report actually asked for: all but one
	// desktop client now arrives CONNECTED rather than merely prepared.
	landsConnected := map[string]bool{
		"connection_string_arg": true,
		"pgadmin_preseed":       true,
		"redisinsight_presetup": true,
	}
	for id, mode := range seen {
		if id == "sqldeveloper" {
			continue
		}
		if !landsConnected[mode] {
			t.Errorf("%s uses %q, which only prepares a login — every desktop client "+
				"except sqldeveloper should open already connected", id, mode)
		}
	}
}
