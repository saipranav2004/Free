// pam-agent/internal/launcher/pgadmin_passexec.go
//
// Makes pgAdmin 4 open ALREADY CONNECTED.
//
// The older note in templates.go is still true as far as it goes: PGPASSFILE
// does not suppress pgAdmin's "Connect to Server" dialog, because that dialog
// is pgAdmin's own UI gate and it is shown before any libpq connection is
// attempted. What that note concluded — that no credential can reach pgAdmin
// headlessly — does not follow. pgAdmin documents a mechanism for exactly
// this: PasswordExecCommand, a command whose stdout becomes the SQL password
// at connect time.
//
//	https://www.pgadmin.org/docs/pgadmin4/latest/server_dialog.html
//	https://www.pgadmin.org/docs/pgadmin4/latest/import_export_servers.html
//
// That is the desktop analogue of what the web proxy already does: the client
// asks a broker for the credential at the moment of use, instead of the
// credential being handed to the operator to type. The agent is that broker.
//
// Two properties this buys over the clipboard handoff it replaces:
//
//   - The password is never placed on the system clipboard, which is global
//     to the whole desktop session and readable by every other application.
//   - "Password fields cannot be imported or exported" (pgAdmin's own words),
//     so the servers.json carries no secret and pgAdmin's config database
//     stores server.password = NULL. Confirmed live.
//
// VERIFIED against a real pgAdmin 4 9.18 in desktop mode, connecting to a
// PostgreSQL role that requires scram-sha-256 (so a missing or wrong password
// provably fails): no password dialog, pg_stat_activity showed an
// authenticated backend named "pgAdmin 4 - DB:postgres", and server.password
// was NULL. See e2e/pgadmin-passexec.mjs.
//
// Details that come from reading pgAdmin's own pgadmin/utils/passexec.py
// rather than from its docs, each of which shapes the code below:
//
//   - It runs the command with subprocess.run(cmd, shell=True), so the string
//     is parsed by the platform shell and every path in it must be quoted for
//     that shell.
//   - It takes p.stdout.strip() as the password, so a password with leading
//     or trailing whitespace cannot survive this channel. That case falls
//     back to the clipboard rather than failing a login mysteriously.
//   - It passes check=True, so the helper must exit 0 and stay silent on
//     stderr.
package launcher

import (
	"fmt"
	"os"
	"strings"
)

// PgAdminCredentialSubcommand is the argv[1] the agent answers with the
// password on stdout. Hidden from `help` on purpose: it is a machine
// interface for pgAdmin, not something an operator runs.
const PgAdminCredentialSubcommand = "pgadmin-credential"

// pgAdminPassexecExpiration is how long pgAdmin may reuse the password it
// already fetched before calling again. It caches in memory per server, so
// this only decides how often the helper runs for a long session.
const pgAdminPassexecExpiration = 300

// passwordSurvivesPassexec reports whether pgAdmin's stdout.strip() would
// return the password unchanged. A password that is empty, or that starts or
// ends with whitespace, would arrive at PostgreSQL altered — which reads to
// the operator as PAM holding the wrong credential, the single most
// misleading failure this code could produce. Those go to the clipboard.
func passwordSurvivesPassexec(password string) bool {
	return password != "" && strings.TrimSpace(password) == password
}

// writePgAdminSecretFile stores the password for the helper to read back:
// 0600, in the session's own temp dir, alongside the .pgpass file the psql
// path already writes for the same resource. Deliberately NOT passed on the
// helper's command line, which would put the password in the process table
// for anything on the machine to read.
func writePgAdminSecretFile(tempDir, password string) (string, error) {
	f, err := os.CreateTemp(tempDir, "pam-agent-*.pgadmin-secret")
	if err != nil {
		return "", fmt.Errorf("failed to create temp pgAdmin credential file: %w", err)
	}
	defer f.Close()
	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp pgAdmin credential file: %w", err)
	}
	if _, err := f.WriteString(password); err != nil {
		return "", fmt.Errorf("failed to write temp pgAdmin credential file: %w", err)
	}
	return f.Name(), nil
}

// ReadPgAdminSecretFile is the helper side: the whole file is the password,
// with no trimming of its own — pgAdmin does the only trimming, and
// passwordSurvivesPassexec has already established there is nothing to trim.
func ReadPgAdminSecretFile(path string) (string, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	return string(raw), nil
}

// pgAdminPassexecCommand builds the shell command string pgAdmin will run.
//
// goos is a parameter for the same reason it is throughout discovery: the
// quoting rules belong to the machine the agent RUNS on, and Go's own quoting
// helpers are fixed at build time, so a linux builder cannot be allowed to
// decide how a Windows path gets quoted.
func pgAdminPassexecCommand(goos, agentPath, secretPath string) string {
	return fmt.Sprintf("%s %s --secret-file %s",
		shellQuoteFor(goos, agentPath),
		PgAdminCredentialSubcommand,
		shellQuoteFor(goos, secretPath))
}

// shellQuoteFor quotes one argument for the shell subprocess.run(shell=True)
// hands the command to.
//
// Windows is cmd.exe: double quotes are the only grouping, there is no escape
// for a double quote inside them, and backslashes are ordinary characters
// (so a path like C:\Program Files\... must NOT be backslash-escaped the way
// a POSIX shell would need). A path containing a double quote cannot be
// expressed at all, which is why it is rejected rather than mangled.
//
// Everywhere else is a POSIX shell: single quotes make everything literal,
// and the only character needing care is the single quote itself.
func shellQuoteFor(goos, s string) string {
	if goos == "windows" {
		if strings.Contains(s, `"`) {
			return ""
		}
		return `"` + s + `"`
	}
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

// pgAdminPassexecUsable reports whether the passexec route can be taken at
// all. Falling back to the clipboard is a worse experience but a working one;
// emitting a command pgAdmin cannot run would leave the operator with a
// server entry that fails to connect and no explanation.
func pgAdminPassexecUsable(goos, agentPath, password string) bool {
	if agentPath == "" || !passwordSurvivesPassexec(password) {
		return false
	}
	return shellQuoteFor(goos, agentPath) != ""
}
