// pam-agent/internal/launcher/pgadmin_preseed.go
//
// Pre-registers the resource as a server in pgAdmin4's own tree via its
// documented --load-servers mechanism.
//
// The password is never written into this file — pgAdmin does not import
// passwords at all. It is supplied at connect time through
// PasswordExecCommand, which calls back into this agent; see
// pgadmin_passexec.go for how that works and what was verified against a
// real pgAdmin. When that route is unavailable (an agent path that cannot be
// expressed to the shell, or a password pgAdmin's stdout.strip() would
// alter), the launch falls back to putting the password on the clipboard and
// the operator types it once.
package launcher

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

// pgAdminServersFile mirrors the shape pgAdmin4's own `--load-servers`
// switch expects (a top-level "Servers" object keyed by an arbitrary
// integer ID). Documented at
// https://www.pgadmin.org/docs/pgadmin4/latest/import_export_servers.html
// — this is pgAdmin4's own supported mechanism, not something reverse
// engineered.
type pgAdminServersFile struct {
	Servers map[string]pgAdminServerEntry `json:"Servers"`
}

type pgAdminServerEntry struct {
	Name          string `json:"Name"`
	Group         string `json:"Group"`
	Host          string `json:"Host"`
	Port          int    `json:"Port"`
	MaintenanceDB string `json:"MaintenanceDB"`
	Username      string `json:"Username"`
	SSLMode       string `json:"SSLMode"`

	// The password is never a field here — pgAdmin does not import one, by
	// design. PasswordExecCommand is how a credential reaches it instead:
	// pgAdmin runs the command at connect time and uses its stdout as the
	// password, so the server entry stays secret-free and pgAdmin's own
	// config database records server.password = NULL. See
	// pgadmin_passexec.go. Omitted entirely when unset so the import file
	// keeps its previous shape for the clipboard fallback.
	PasswordExecCommand    string `json:"PasswordExecCommand,omitempty"`
	PasswordExecExpiration int    `json:"PasswordExecExpiration,omitempty"`
}

// writePgAdminServersFile writes a pgAdmin4 servers-import JSON (0600, temp
// dir) containing host/port/database/username for the resolved resource —
// and, when passexecCommand is non-empty, the command pgAdmin should run to
// obtain the password. The password itself is never written here.
func writePgAdminServersFile(tempDir string, resolved *apiclient.ResolvedLaunch, dbName, passexecCommand string) (string, error) {
	if dbName == "" {
		dbName = "postgres"
	}

	entry := pgAdminServerEntry{
		Name:          fmt.Sprintf("PAM - %s", resolved.Host),
		Group:         "PAM",
		Host:          resolved.Host,
		Port:          resolved.Port,
		MaintenanceDB: dbName,
		Username:      resolved.AccountName,
		SSLMode:       "prefer",
	}
	if passexecCommand != "" {
		entry.PasswordExecCommand = passexecCommand
		entry.PasswordExecExpiration = pgAdminPassexecExpiration
	}

	doc := pgAdminServersFile{Servers: map[string]pgAdminServerEntry{"1": entry}}

	raw, err := json.MarshalIndent(doc, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to encode pgAdmin4 servers file: %w", err)
	}

	f, err := os.CreateTemp(tempDir, "pam-agent-*.pgadmin-servers.json")
	if err != nil {
		return "", fmt.Errorf("failed to create temp pgAdmin4 servers file: %w", err)
	}
	defer f.Close()
	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp pgAdmin4 servers file: %w", err)
	}
	if _, err := f.Write(raw); err != nil {
		return "", fmt.Errorf("failed to write temp pgAdmin4 servers file: %w", err)
	}
	return f.Name(), nil
}

// RunPgAdminPreseed invokes `<pgAdminExec> --load-servers <path>` as a
// best-effort pre-step before the GUI itself is spawned. This is
// deliberately non-fatal and swallows its own error (returning it only for
// logging) — pgAdmin4's exact CLI surface for this varies across install
// types (desktop/Electron build vs. the Python `pip install pgadmin4`
// package vs. server-mode deployments), so a failure here just means the
// operator adds the connection by hand in pgAdmin4 instead of it being
// pre-filled; it must never block the GUI from opening at all.
func RunPgAdminPreseed(execPath, appBundle, serversFilePath string) error {
	target := execPath
	if target == "" && appBundle != "" {
		// macOS app bundle: run its preseed via `open -a <bundle> --args ...`
		// so pgAdmin4 sees the same argv it would from a direct exec.
		c := exec.Command("open", "-a", appBundle, "-W", "--args", "--load-servers", serversFilePath)
		return c.Run()
	}
	if target == "" {
		return fmt.Errorf("no executable path resolved for pgAdmin4 preseed")
	}
	return exec.Command(target, "--load-servers", serversFilePath).Run()
}
