package launcher

import (
	"encoding/json"
	"os"
	"regexp"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/discovery"
)

var uuidShape = regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$`)

// RedisInsight VALIDATES the id and silently drops an entry that fails, with
// nothing in any log. A malformed id would present to the operator as PAM
// having done nothing at all, so the shape is pinned here.
func TestRedisInsightDatabaseIDLooksLikeAUUID(t *testing.T) {
	id := redisInsightDatabaseID("redis", "10.0.0.5", 6379)
	if !uuidShape.MatchString(id) {
		t.Fatalf("id %q is not a well-formed v4-shaped UUID — RedisInsight will drop the entry", id)
	}
}

// Stable per resource, so relaunching replaces the entry instead of leaving
// the operator with a list of near-identical duplicates.
func TestRedisInsightDatabaseIDIsStablePerResourceAndDistinctAcross(t *testing.T) {
	a := redisInsightDatabaseID("redis", "10.0.0.5", 6379)
	if a != redisInsightDatabaseID("redis", "10.0.0.5", 6379) {
		t.Fatal("the same resource produced two different ids")
	}
	for _, other := range []string{
		redisInsightDatabaseID("redis", "10.0.0.5", 6380),
		redisInsightDatabaseID("redis", "10.0.0.6", 6379),
	} {
		if a == other {
			t.Fatalf("two different resources collided on id %s", a)
		}
	}
}

func TestRedisInsightPreSetupFileIsAPrivateListRedisInsightCanRead(t *testing.T) {
	dir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "redis", Host: "10.0.0.5", Port: 6379,
		AccountName: "app", Password: "Redis!PamTest2026",
	}

	path, err := writeRedisInsightPreSetupFile(dir, resolved)
	if err != nil {
		t.Fatal(err)
	}
	fi, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	// The password IS in this file — RedisInsight has no fetch-at-connect
	// hook — so its permissions are the whole protection.
	if perm := fi.Mode().Perm(); perm != 0o600 {
		t.Fatalf("got permissions %o, want 0600", perm)
	}

	raw, _ := os.ReadFile(path)
	// A LIST. RedisInsight maps over the parsed file, so an object throws
	// inside its reader and every entry is lost.
	var entries []redisInsightDatabase
	if err := json.Unmarshal(raw, &entries); err != nil {
		t.Fatalf("RedisInsight could not parse this as a list: %v\n%s", err, raw)
	}
	if len(entries) != 1 {
		t.Fatalf("got %d entries, want 1", len(entries))
	}
	e := entries[0]
	if e.Host != "10.0.0.5" || e.Port != 6379 || e.Password != resolved.Password || e.Username != "app" {
		t.Fatalf("entry does not carry the resolved connection: %+v", e)
	}
	if !strings.Contains(e.Name, "10.0.0.5:6379") {
		t.Errorf("name %q does not identify the target", e.Name)
	}
}

// A redis resource with no password (a local instance with no requirepass) must
// not produce a password field, for the same reason the redis-cli path does not
// set REDISCLI_AUTH: an empty credential means "do not authenticate", not
// "authenticate with nothing".
func TestRedisInsightPreSetupOmitsAnEmptyPassword(t *testing.T) {
	dir := t.TempDir()
	path, err := writeRedisInsightPreSetupFile(dir, &apiclient.ResolvedLaunch{
		ResourceType: "redis", Host: "h", Port: 6379,
	})
	if err != nil {
		t.Fatal(err)
	}
	raw, _ := os.ReadFile(path)
	if strings.Contains(string(raw), `"password"`) || strings.Contains(string(raw), `"username"`) {
		t.Fatalf("empty credential fields were written:\n%s", raw)
	}
}

// End to end through the template the product actually ships: the launch must
// point RedisInsight at the file with RedisInsight's own variable, and clean
// it up when the session ends.
func TestRedisInsightLaunchPointsTheAppAtTheFileAndCleansItUp(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "redis", Host: "10.0.0.5", Port: 6379, Password: "pw",
	}
	candidates := []Candidate{
		{ID: "redisinsight", Kind: "gui", Command: "go", CredentialInjection: "redisinsight_presetup", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}
	cmd, _, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	var envValue string
	for _, e := range cmd.Env {
		if strings.HasPrefix(e, RedisInsightPreSetupEnv+"=") {
			envValue = strings.TrimPrefix(e, RedisInsightPreSetupEnv+"=")
		}
	}
	if envValue == "" {
		t.Fatalf("%s was not set; RedisInsight will never read the file", RedisInsightPreSetupEnv)
	}
	if _, err := os.Stat(envValue); err != nil {
		t.Fatalf("the file it points at does not exist: %v", err)
	}

	var cleaned bool
	for _, f := range cmd.CleanupFiles {
		if f == envValue {
			cleaned = true
		}
	}
	if !cleaned {
		t.Error("the pre-setup file holds the password and is not cleaned up with the session")
	}

	// The clipboard is not also used: the password is already reaching the
	// app, and putting it on a desktop-wide clipboard as well would be a
	// second exposure for no benefit.
	if cmd.CopyPasswordToClipboard {
		t.Error("password was also copied to the clipboard")
	}
}
