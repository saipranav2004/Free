package launcher

import (
	"os"
	"strings"
	"testing"
)

// pgAdmin runs the command with shell=True, so every path in it is parsed by
// the platform shell. The agent's own install paths contain spaces on two of
// the three platforms out of the box, which is exactly the case that breaks
// if this is built by concatenation.
func TestPassexecCommandQuotesPathsForTheTargetPlatform(t *testing.T) {
	cases := []struct {
		name      string
		goos      string
		agent     string
		secret    string
		wantParts []string
	}{
		{
			name:   "windows program files",
			goos:   "windows",
			agent:  `C:\Program Files\PAM Agent\pam-agent.exe`,
			secret: `C:\Users\Sai Pranav\AppData\Local\Temp\pam-agent-123.pgadmin-secret`,
			// cmd.exe: double quotes group, backslashes are literal. A POSIX
			// escaping of the backslashes here would corrupt every path.
			wantParts: []string{
				`"C:\Program Files\PAM Agent\pam-agent.exe"`,
				`"C:\Users\Sai Pranav\AppData\Local\Temp\pam-agent-123.pgadmin-secret"`,
			},
		},
		{
			name:      "macos application support",
			goos:      "darwin",
			agent:     "/Applications/PAM Agent.app/Contents/MacOS/pam-agent",
			secret:    "/var/folders/ab/T/pam-agent-9.pgadmin-secret",
			wantParts: []string{`'/Applications/PAM Agent.app/Contents/MacOS/pam-agent'`},
		},
		{
			name:      "linux",
			goos:      "linux",
			agent:     "/usr/local/bin/pam-agent",
			secret:    "/tmp/pam-agent-9.pgadmin-secret",
			wantParts: []string{`'/usr/local/bin/pam-agent'`, `'/tmp/pam-agent-9.pgadmin-secret'`},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := pgAdminPassexecCommand(tc.goos, tc.agent, tc.secret)
			for _, want := range tc.wantParts {
				if !strings.Contains(got, want) {
					t.Errorf("command does not contain %s\n  got: %s", want, got)
				}
			}
			if !strings.Contains(got, PgAdminCredentialSubcommand) {
				t.Errorf("command does not invoke the credential subcommand: %s", got)
			}
		})
	}
}

// A single quote in a POSIX path must not be able to end the quoted string —
// otherwise a directory name could inject a second command into something
// pgAdmin runs with shell=True.
func TestPassexecCommandCannotBeEscapedByAQuoteInAPath(t *testing.T) {
	got := pgAdminPassexecCommand("linux", "/opt/o'brien/pam-agent", "/tmp/s")
	if strings.Contains(got, `/opt/o'brien`) && !strings.Contains(got, `'\''`) {
		t.Fatalf("single quote was not neutralised: %s", got)
	}
	if strings.Contains(got, "; ") || strings.Contains(got, "&&") {
		t.Fatalf("command separator survived quoting: %s", got)
	}
}

// pgAdmin takes stdout.strip() as the password. A password that strip() would
// alter cannot go through this channel at all, and silently sending the
// altered one would look exactly like PAM holding the wrong credential.
func TestPasswordsThatStripWouldAlterDoNotUsePassexec(t *testing.T) {
	cases := []struct {
		password string
		ok       bool
	}{
		{"ordinary-password", true},
		{"with spaces inside is fine", true},
		{" leading-space", false},
		{"trailing-space ", false},
		{"trailing-newline\n", false},
		{"\ttab", false},
		{"", false},
	}
	for _, tc := range cases {
		if got := passwordSurvivesPassexec(tc.password); got != tc.ok {
			t.Errorf("passwordSurvivesPassexec(%q) = %v, want %v", tc.password, got, tc.ok)
		}
		if got := pgAdminPassexecUsable("linux", "/usr/bin/pam-agent", tc.password); got != tc.ok {
			t.Errorf("pgAdminPassexecUsable(%q) = %v, want %v", tc.password, got, tc.ok)
		}
	}
}

// An agent path that cannot be expressed to cmd.exe must fall back rather
// than emit a command that would fail at connect time with no explanation.
func TestPassexecIsRefusedWhenThePathCannotBeQuoted(t *testing.T) {
	if pgAdminPassexecUsable("windows", `C:\weird"path\pam-agent.exe`, "pw") {
		t.Fatal("a path containing a double quote must not be used on windows")
	}
	if pgAdminPassexecUsable("linux", "", "pw") {
		t.Fatal("an unresolved agent path must not be used")
	}
}

// The secret file is the only place the password lands, and its permissions
// are the whole protection.
func TestSecretFileIsPrivateAndRoundTripsExactly(t *testing.T) {
	dir := t.TempDir()
	const password = "p@ss word-with spaces"

	path, err := writePgAdminSecretFile(dir, password)
	if err != nil {
		t.Fatal(err)
	}
	fi, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if perm := fi.Mode().Perm(); perm != 0o600 {
		t.Fatalf("got permissions %o, want 0600", perm)
	}

	got, err := ReadPgAdminSecretFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if got != password {
		t.Fatalf("round trip altered the password: %q != %q", got, password)
	}
}
