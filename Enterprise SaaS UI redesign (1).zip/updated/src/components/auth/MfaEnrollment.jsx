import { useEffect, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import {
  ShieldCheck, AlertTriangle, RefreshCw, KeyRound, Smartphone, Info,
} from 'lucide-react'
import { mfaSetupInitiate, mfaSetupVerify } from '../../api/auth'
import { apiErrorMessage } from '../../lib/apiError'
import { formatEnabledAt } from '../../lib/mfaStatus'
import { CopyButton } from '../common/CopyButton'
import { Card, CardHeader, CardTitle, CardFooter } from '../common/Layout'
import { Button } from '../common/Button'

// Three-step enrollment: initiate (get QR+secret) -> verify (6-digit code
// activates it, returns backup codes) -> explicit acknowledgement that the
// backup codes were saved, since they are shown exactly once
// (auth_handler.go: "Save these backup codes — they will NOT be shown again").
//
// FIXED HERE: which state this component opens in is now driven by the
// account's real enrolment status (`status`, read from /auth/me via
// lib/mfaStatus) instead of by local "did you just enroll in this tab"
// state. An account with MFA already on can no longer be shown "Enable MFA":
// it opens on the enabled summary, and the only enrolment action offered is
// replacing the authenticator.
//
// The other bug this still guards against: closing/navigating away right
// after verify() succeeds, before the backup codes were copied, permanently
// loses them (the backend never returns them again) — so the backup-codes
// step is never auto-dismissed.
export function MfaEnrollment({ status, onEnrolled }) {
  const enabled = status?.enabled === true
  const [step, setStep] = useState(enabled ? 'enabled' : 'start')
  const [setupData, setSetupData] = useState(null) // { mfa_device_id, secret, qr_code_base64 }
  const [code, setCode] = useState('')
  const [backupCodes, setBackupCodes] = useState(null)
  const [error, setError] = useState(null)

  // /auth/me resolves after first paint, so "start" may be showing when the
  // truth arrives — switch to the enabled summary the moment it does. Only
  // from 'start': never yank someone out of an in-progress enrolment or off
  // the backup-codes screen.
  useEffect(() => {
    if (enabled && step === 'start') setStep('enabled')
    if (!enabled && step === 'enabled') setStep('start')
  }, [enabled, step])

  const initiate = useMutation({
    mutationFn: mfaSetupInitiate,
    onSuccess: (data) => {
      setSetupData(data)
      setStep('qr')
      setError(null)
    },
    onError: (err) => setError(apiErrorMessage(err)),
  })

  const verify = useMutation({
    mutationFn: (c) => mfaSetupVerify(setupData.mfa_device_id, c),
    onSuccess: (data) => {
      setBackupCodes(data.backup_codes || [])
      setStep('backup-codes')
      setError(null)
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      setCode('')
    },
  })

  // -------------------------------------------------------------------------
  // MFA is ON — the state that was previously impossible to reach
  // -------------------------------------------------------------------------
  if (step === 'enabled') {
    const on = formatEnabledAt(status?.enabledAt)
    return (
      <Card>
        <CardHeader>
          <CardTitle icon={ShieldCheck}>Multi-factor authentication</CardTitle>
          <span className="ml-auto flex items-center gap-1.5 rounded-md bg-emerald-50 px-2 py-1 text-2xs font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-hidden="true" />
            MFA enabled
          </span>
        </CardHeader>

        <div className="flex items-start gap-3.5 px-4 py-4">
          <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 ring-1 ring-inset ring-emerald-600/15 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
            <ShieldCheck className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink-100">
              This account is protected by a second factor
            </p>
            <p className="mt-1 text-sm leading-relaxed text-ink-400">
              A code from your authenticator app is required on every new sign-in, and for
              privileged actions such as revealing a vault credential.
            </p>
          </div>
        </div>

        <dl className="divide-y divide-surface-800 border-t border-surface-800">
          <div className="grid grid-cols-[minmax(7rem,32%)_1fr] gap-4 px-4 py-2.5">
            <dt className="text-xs font-medium uppercase tracking-wide text-ink-500">Method</dt>
            <dd className="flex min-w-0 items-center gap-2 text-sm text-ink-100">
              <Smartphone className="h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
              {status?.method || 'Authenticator app (TOTP)'}
            </dd>
          </div>
          <div className="grid grid-cols-[minmax(7rem,32%)_1fr] gap-4 px-4 py-2.5">
            <dt className="text-xs font-medium uppercase tracking-wide text-ink-500">Enabled</dt>
            <dd className="min-w-0 text-sm text-ink-100">
              {on || <span className="text-ink-500">Active — enrolment date not reported by the API</span>}
            </dd>
          </div>
          <div className="grid grid-cols-[minmax(7rem,32%)_1fr] gap-4 px-4 py-2.5">
            <dt className="text-xs font-medium uppercase tracking-wide text-ink-500">This session</dt>
            <dd className="min-w-0 text-sm">
              {status?.verifiedThisSession ? (
                <span className="inline-flex items-center gap-1.5 rounded-md bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
                  Verified
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 rounded-md bg-surface-800 px-2 py-0.5 text-xs font-medium text-ink-400 ring-1 ring-inset ring-surface-700">
                  Not verified — sign in again to unlock reveals
                </span>
              )}
            </dd>
          </div>
        </dl>

        {error && (
          <p className="border-t border-surface-800 px-4 py-3 text-sm text-red-600 dark:text-red-400">{error}</p>
        )}

        <CardFooter className="flex-wrap justify-between gap-y-3">
          <Button
            variant="secondary"
            size="sm"
            icon={RefreshCw}
            loading={initiate.isPending}
            onClick={() => initiate.mutate()}
          >
            Replace authenticator
          </Button>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 text-2xs text-ink-500">
              <Info className="h-3.5 w-3.5 flex-none" strokeWidth={1.75} />
              Turning MFA off is not self-service
            </span>
            <Button
              variant="dangerGhost"
              size="sm"
              disabled
              title="No self-service disable endpoint exists — an administrator must reset MFA for this account."
            >
              Disable MFA
            </Button>
          </div>
        </CardFooter>
      </Card>
    )
  }

  // -------------------------------------------------------------------------
  // MFA is OFF
  // -------------------------------------------------------------------------
  if (step === 'start') {
    return (
      <Card>
        <CardHeader>
          <CardTitle icon={ShieldCheck}>Multi-factor authentication</CardTitle>
          <span className="ml-auto flex items-center gap-1.5 rounded-md bg-amber-50 px-2 py-1 text-2xs font-semibold text-amber-700 ring-1 ring-inset ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-500" aria-hidden="true" />
            Not enabled
          </span>
        </CardHeader>
        <div className="flex items-start gap-3.5 px-4 py-4">
          <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-amber-50 text-amber-600 ring-1 ring-inset ring-amber-600/15 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
            <AlertTriangle className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink-100">Add a second factor</p>
            <p className="mt-1 text-sm leading-relaxed text-ink-400">
              Without MFA, privileged actions that require a verified session — revealing vault
              credentials, approving break-glass — will be refused.
            </p>
          </div>
        </div>
        {error && <p className="px-4 pb-1 text-sm text-red-600 dark:text-red-400">{error}</p>}
        <CardFooter>
          <Button
            variant="primary"
            icon={ShieldCheck}
            loading={initiate.isPending}
            onClick={() => initiate.mutate()}
          >
            Enable MFA
          </Button>
        </CardFooter>
      </Card>
    )
  }

  if (step === 'qr') {
    return (
      <Card>
        <CardHeader>
          <CardTitle icon={Smartphone}>{enabled ? 'Replace authenticator' : 'Set up your authenticator'}</CardTitle>
        </CardHeader>
        <div className="px-4 py-4">
          <p className="text-sm leading-relaxed text-ink-400">
            Scan this code with Google Authenticator, 1Password, or any TOTP app
            {enabled ? ' — the new device replaces the current one once confirmed.' : '.'}
          </p>
          <div className="mt-4 flex flex-col items-center gap-5 sm:flex-row sm:items-start">
            {setupData?.qr_code_base64 && (
              <img
                // auth_service.go's SetupMFAInitiate -> pkg/totp.GenerateQRCodeBase64
                // already returns a full `data:image/png;base64,...` URI, not a
                // bare base64 payload — prepending the prefix again produced a
                // doubly-prefixed, invalid data URI the browser silently failed
                // to render. Use the value as-is.
                src={setupData.qr_code_base64}
                alt="MFA enrollment QR code"
                className="h-40 w-40 flex-none rounded-xl border border-surface-700 bg-white p-2"
              />
            )}
            <div className="w-full min-w-0 space-y-2">
              <p className="text-xs font-medium text-ink-300">Or enter this key manually</p>
              <div className="flex items-center gap-2">
                <code className="min-w-0 flex-1 truncate rounded-lg border border-surface-700 bg-surface-800 px-2.5 py-2 font-mono text-xs text-ink-200">
                  {setupData?.secret}
                </code>
                <CopyButton value={setupData?.secret || ''} />
              </div>
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault()
              if (code.trim()) verify.mutate(code.trim())
            }}
            className="mt-5 border-t border-surface-800 pt-5"
          >
            {error && <p className="mb-3 text-sm text-red-600 dark:text-red-400">{error}</p>}
            <label htmlFor="mfa-setup-code" className="mb-1.5 block text-xs font-medium text-ink-300">
              Enter the 6-digit code to confirm
            </label>
            <div className="flex items-center gap-2.5">
              <input
                id="mfa-setup-code"
                inputMode="numeric"
                maxLength={8}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ''))}
                className="w-40 rounded-lg border border-surface-700 bg-surface-800 px-3 py-2 text-center text-lg tracking-[0.25em] text-ink-50 shadow-sm transition-[border-color,box-shadow] duration-150 hover:border-surface-600 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
                placeholder="000000"
              />
              <Button
                type="submit"
                variant="primary"
                loading={verify.isPending}
                disabled={code.length === 0}
              >
                Activate
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  setCode('')
                  setError(null)
                  setStep(enabled ? 'enabled' : 'start')
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </Card>
    )
  }

  // step === 'backup-codes'
  return (
    <Card className="border-emerald-300/70 dark:border-emerald-800/50">
      <CardHeader className="border-emerald-200/70 bg-emerald-50/60 dark:border-emerald-900/40 dark:bg-emerald-950/20">
        <CardTitle icon={KeyRound}>Save your backup codes now</CardTitle>
      </CardHeader>
      <div className="px-4 py-4">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-amber-50 text-amber-600 ring-1 ring-inset ring-amber-600/15 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
            <AlertTriangle className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
          </span>
          <p className="text-sm leading-relaxed text-ink-400">
            MFA is now active. These codes will <strong className="font-semibold text-ink-100">not</strong> be
            shown again — each can be used once if you lose access to your authenticator app.
          </p>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl border border-surface-700 bg-surface-800 p-3 font-mono text-sm text-ink-100 sm:grid-cols-3">
          {(backupCodes || []).map((c) => (
            <span key={c} className="tabular-nums">{c}</span>
          ))}
        </div>
      </div>
      <CardFooter className="justify-between">
        <CopyButton value={(backupCodes || []).join('\n')} label="Copy all codes" />
        <Button
          variant="primary"
          icon={ShieldCheck}
          onClick={() => {
            setStep('enabled')
            onEnrolled?.()
          }}
        >
          I&apos;ve saved these codes
        </Button>
      </CardFooter>
    </Card>
  )
}
