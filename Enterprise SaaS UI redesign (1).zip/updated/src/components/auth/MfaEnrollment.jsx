import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { ShieldCheck, AlertTriangle } from 'lucide-react'
import { mfaSetupInitiate, mfaSetupVerify } from '../../api/auth'
import { apiErrorMessage } from '../../lib/apiError'
import { CopyButton } from '../common/CopyButton'
import { Spinner } from '../common/Spinner'

// Three-step enrollment: initiate (get QR+secret) -> verify (6-digit code
// activates it, returns backup codes) -> explicit acknowledgement that the
// backup codes were saved, since they are shown exactly once
// (auth_handler.go's own comment: "Save these backup codes — they will NOT
// be shown again").
//
// Bug this specifically guards against: closing/navigating away from this
// component right after verify() succeeds, before the user has actually
// copied the backup codes, permanently loses them (the backend never
// returns them again). The `step === 'backup-codes'` state is NOT
// auto-dismissed and requires an explicit "I've saved these" click, and a
// `beforeunload` warning fires if they try to navigate away first.
export function MfaEnrollment({ onEnrolled }) {
  const [step, setStep] = useState('start') // start | qr | backup-codes
  const [setupData, setSetupData] = useState(null) // { mfa_device_id, secret, qr_code_base64 }
  const [code, setCode] = useState('')
  const [backupCodes, setBackupCodes] = useState(null)
  const [error, setError] = useState(null)

  const initiate = useMutation({
    mutationFn: mfaSetupInitiate,
    onSuccess: (data) => {
      setSetupData(data)
      setStep('qr')
      setError(null)
    },
    onError: (err) => setError(apiErrorMessage(err)),
  })

  const verify = useMutation({
    mutationFn: (code) => mfaSetupVerify(setupData.mfa_device_id, code),
    onSuccess: (data) => {
      setBackupCodes(data.backup_codes || [])
      setStep('backup-codes')
      setError(null)
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      setCode('')
    },
  })

  if (step === 'start') {
    return (
      <div className="rounded-xl border border-surface-700/70 bg-surface-900 shadow-card p-5">
        <div className="flex items-center gap-3">
          <ShieldCheck className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          <div>
            <h3 className="text-sm font-semibold text-ink-50">Two-factor authentication</h3>
            <p className="text-xs text-ink-400">Not enabled on this account.</p>
          </div>
        </div>
        {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}
        <button
          onClick={() => initiate.mutate()}
          disabled={initiate.isPending}
          className="mt-4 flex items-center gap-2 h-10 rounded-lg bg-blue-600 px-4 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
        >
          {initiate.isPending && <Spinner size="h-4 w-4" className="text-white" />}
          Enable MFA
        </button>
      </div>
    )
  }

  if (step === 'qr') {
    return (
      <div className="rounded-xl border border-surface-700/70 bg-surface-900 shadow-card p-5">
        <h3 className="text-sm font-semibold text-ink-50">Scan this QR code</h3>
        <p className="mt-1 text-xs text-ink-400">
          Use Google Authenticator, 1Password, or any TOTP app.
        </p>
        <div className="mt-4 flex flex-col items-center gap-4 sm:flex-row sm:items-start">
          {setupData?.qr_code_base64 && (
            <img
              // auth_service.go's SetupMFAInitiate -> pkg/totp.GenerateQRCodeBase64
              // already returns a full `data:image/png;base64,...` URI, not a bare
              // base64 payload — prepending the prefix again here produced a
              // doubly-prefixed, invalid data URI the browser silently failed to
              // render (no image, no console error), which is why the QR code
              // never showed up. Use the value as-is.
              src={setupData.qr_code_base64}
              alt="MFA enrollment QR code"
              className="h-40 w-40 rounded-md bg-white p-2"
            />
          )}
          <div className="w-full space-y-2">
            <p className="text-xs text-ink-400">Or enter this key manually:</p>
            <div className="flex items-center gap-2">
              <code className="flex-1 truncate rounded-lg bg-surface-800 transition-colors px-2 py-1.5 text-xs text-ink-200">
                {setupData?.secret}
              </code>
              <CopyButton value={setupData?.secret || ''} />
            </div>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault()
            if (code.trim()) verify.mutate(code.trim())
          }}
          className="mt-5 space-y-3"
        >
          {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
          <label className="block text-xs font-medium text-ink-300">
            Enter the 6-digit code to confirm
          </label>
          <input
            inputMode="numeric"
            maxLength={8}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ''))}
            className="w-40 rounded-lg border border-surface-700 bg-surface-800 px-3 py-2 shadow-sm transition-[border-color,box-shadow] duration-150 hover:border-surface-600 text-center text-lg tracking-widest text-ink-50 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
            placeholder="000000"
          />
          <div>
            <button
              type="submit"
              disabled={verify.isPending || code.length === 0}
              className="flex items-center gap-2 h-10 rounded-lg bg-blue-600 px-4 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
            >
              {verify.isPending && <Spinner size="h-4 w-4" className="text-white" />}
              Activate
            </button>
          </div>
        </form>
      </div>
    )
  }

  // step === 'backup-codes'
  return (
    <div className="rounded-lg border border-emerald-300 dark:border-emerald-800/40 bg-emerald-50 dark:bg-emerald-950/20 p-5">
      <div className="flex items-center gap-2">
        <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
        <h3 className="text-sm font-semibold text-ink-50">Save your backup codes now</h3>
      </div>
      <p className="mt-1 text-xs text-ink-300">
        MFA is now active. These codes will <strong>not</strong> be shown again — each can be
        used once if you lose access to your authenticator app.
      </p>
      <div className="mt-3 grid grid-cols-2 gap-2 rounded-md bg-surface-900 p-3 font-mono text-sm text-ink-100">
        {(backupCodes || []).map((c) => (
          <span key={c}>{c}</span>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2">
        <CopyButton value={(backupCodes || []).join('\n')} label="Copy all codes" />
      </div>
      <button
        onClick={() => onEnrolled?.()}
        className="mt-4 rounded-md bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-500"
      >
        I&apos;ve saved these codes
      </button>
    </div>
  )
}
