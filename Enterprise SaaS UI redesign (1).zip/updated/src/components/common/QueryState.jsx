import { AlertTriangle, Inbox, RefreshCw } from 'lucide-react'
import { SkeletonRows } from './Spinner'
import { EmptyState } from './Layout'
import { Button } from './Button'
import { apiErrorMessage } from '../../lib/apiError'

// Wraps the loading/error/empty/success branches every data-fetching view
// needs. This exists specifically to make it HARD to forget one of these
// states — a raw `{data.map(...)}` with no guard is exactly how a blank
// screen (loading), a silent no-op (error swallowed), or a crash (data is
// undefined on first render) sneaks into a component. Centralizing this
// means a fix to how errors render applies everywhere at once.
//
// Only the presentation of those three states changed here: skeleton rows
// instead of a lone spinner, a framed error plate with the retry action, and
// the shared EmptyState. The branch logic is untouched.
export function QueryState({
  query,
  empty, // optional: fn(data) => boolean — when true, renders emptyMessage instead of children
  emptyMessage = 'Nothing here yet.',
  emptyTitle,
  emptyAction,
  loadingLabel = 'Loading…',
  skeletonRows = 5,
  children, // fn(data) => ReactNode
}) {
  if (query.isLoading) {
    return (
      <div role="status" aria-label={loadingLabel}>
        <SkeletonRows rows={skeletonRows} />
      </div>
    )
  }

  if (query.isError) {
    return (
      <div className="flex flex-col items-center gap-4 rounded-xl border border-red-300/70 bg-red-50/70 px-6 py-12 text-center dark:border-red-900/50 dark:bg-red-950/20">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-100 text-red-600 ring-1 ring-inset ring-red-600/15 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25">
          <AlertTriangle className="h-5 w-5" strokeWidth={1.75} />
        </div>
        <div>
          <p className="text-sm font-semibold text-red-800 dark:text-red-200">Couldn&apos;t load this data</p>
          <p className="mx-auto mt-1.5 max-w-sm text-sm leading-relaxed text-red-700/90 dark:text-red-300/90">
            {apiErrorMessage(query.error)}
          </p>
        </div>
        <Button size="sm" variant="secondary" icon={RefreshCw} onClick={() => query.refetch()}>
          Retry
        </Button>
      </div>
    )
  }

  const data = query.data
  const isEmpty = empty ? empty(data) : false

  if (isEmpty) {
    return (
      <EmptyState
        icon={Inbox}
        title={emptyTitle || 'Nothing to show'}
        description={emptyMessage}
        action={emptyAction}
      />
    )
  }

  return children(data)
}
