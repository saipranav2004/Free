import { Sun, Moon, MonitorSmartphone } from 'lucide-react'
import clsx from 'clsx'
import { useThemeStore } from '../../store/themeStore'

const ICONS = { light: Sun, dark: Moon, system: MonitorSmartphone }
const LABELS = { light: 'Light', dark: 'Dark', system: 'System' }
const NEXT_LABEL = { light: 'dark', dark: 'system', system: 'light' }

// A single button that cycles light -> dark -> system, rather than a 3-way
// segmented control — this is meant to live in a compact topbar/sidebar
// footer slot, and one click to the theme you actually want (of 3) is a
// fine trade for the space it saves.
export function ThemeToggle({ compact = false }) {
  const theme = useThemeStore((s) => s.theme)
  const cycleTheme = useThemeStore((s) => s.cycleTheme)
  const Icon = ICONS[theme] || MonitorSmartphone

  return (
    <button
      type="button"
      onClick={cycleTheme}
      title={`Appearance: ${LABELS[theme]} — switch to ${NEXT_LABEL[theme]}`}
      aria-label={`Switch appearance, currently ${LABELS[theme]}`}
      className={clsx(
        'inline-flex flex-none select-none items-center justify-center font-medium transition-colors',
        compact
          ? 'h-9 w-9 rounded-lg text-ink-400 hover:bg-surface-800 hover:text-ink-50'
          : 'h-9 gap-2 rounded-lg border border-surface-700 bg-surface-900 px-3 text-xs text-ink-200 shadow-card hover:border-surface-600 hover:bg-surface-850'
      )}
    >
      <Icon className="h-4 w-4" strokeWidth={1.75} />
      {!compact && LABELS[theme]}
    </button>
  )
}
