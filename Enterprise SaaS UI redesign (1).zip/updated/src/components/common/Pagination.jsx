import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from './Button'

// Every list endpoint in this backend returns the same
// { page, page_size, total, total_pages } shape (see jit_handler.go's
// paged() helper) — one Pagination component for all of them.
//
// Edge cases handled deliberately:
//  - total_pages === 0 (no results at all) -> render nothing rather than a
//    confusing "Page 1 of 0".
//  - Attempting to go below page 1 or above total_pages is a no-op, not a
//    request for a page that doesn't exist (a naive `onPageChange(page+1)`
//    with no bound check is how you get "page 47 of 3" stuck states after
//    a filter change shrinks the result set while the user's page number
//    was left stale).
export function Pagination({ page, pageSize, total, totalPages, onPageChange }) {
  if (!totalPages || totalPages <= 1) return null

  const canPrev = page > 1
  const canNext = page < totalPages
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1
  const end = Math.min(page * pageSize, total)

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-surface-800 bg-surface-850/50 px-4 py-2.5 text-xs text-ink-400">
      <span className="tabular-nums">
        Showing <span className="font-semibold text-ink-100">{start}</span>–
        <span className="font-semibold text-ink-100">{end}</span> of{' '}
        <span className="font-semibold text-ink-100">{total}</span>
      </span>
      <div className="flex items-center gap-2">
        <Button
          size="xs"
          variant="secondary"
          icon={ChevronLeft}
          disabled={!canPrev}
          onClick={() => canPrev && onPageChange(page - 1)}
          aria-label="Previous page"
        >
          Prev
        </Button>
        <span className="px-1 tabular-nums text-ink-300">
          Page <span className="font-semibold text-ink-100">{page}</span> of {totalPages}
        </span>
        <Button
          size="xs"
          variant="secondary"
          iconRight={ChevronRight}
          disabled={!canNext}
          onClick={() => canNext && onPageChange(page + 1)}
          aria-label="Next page"
        >
          Next
        </Button>
      </div>
    </div>
  )
}
