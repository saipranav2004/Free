import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Page & surface primitives
// ---------------------------------------------------------------------------
// Every page in the console is built from these three (plus Card's slots), so
// vertical rhythm, heading weight, border colour and corner radius are
// decided once here rather than per page.

export function PageHeader({ title, description, actions, eyebrow, meta, breadcrumb }) {
  return (
    <header className="mb-6 border-b border-surface-800 pb-5">
      {breadcrumb && <div className="mb-2">{breadcrumb}</div>}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          {eyebrow && (
            <p className="mb-1.5 text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">{eyebrow}</p>
          )}
          <h1 className="truncate text-[1.35rem] font-semibold leading-tight text-ink-50">{title}</h1>
          {description && (
            <p className="mt-1.5 max-w-3xl text-sm leading-relaxed text-ink-400">{description}</p>
          )}
          {meta && <div className="mt-3 flex flex-wrap items-center gap-2">{meta}</div>}
        </div>
        {actions && <div className="flex flex-none flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </header>
  )
}

// A section band — a labelled horizontal rule that divides a page into
// named zones. Enterprise consoles lean on this instead of stacking cards
// with no hierarchy: the label is chrome (small caps, muted), the rule
// carries the eye across, and an optional action sits at the far end.
export function Section({ label, action, children, className = '' }) {
  return (
    <section className={clsx('mt-9 first:mt-0', className)}>
      <div className="mb-3.5 flex items-center gap-3">
        <h2 className="flex-none text-2xs font-semibold uppercase tracking-[0.11em] text-ink-500">{label}</h2>
        <span className="h-px flex-1 bg-surface-800" aria-hidden="true" />
        {action && <div className="flex-none">{action}</div>}
      </div>
      {children}
    </section>
  )
}

// The console's one list row. Every list in the app (resources, safes,
// sessions, requests, grants, users, audit entries) is this shape: a framed
// leading glyph, a two-line identity block, and a trailing cluster of status
// and actions. Centralizing it is what makes the app feel like one product
// instead of nine screens that each invented their own row.
export function ListRow({ icon: Icon, iconNode, title, subtitle, trailing, className = '' }) {
  return (
    <div className={clsx('flex items-center justify-between gap-4 px-4 py-3.5', className)}>
      <div className="flex min-w-0 items-center gap-3.5">
        {(Icon || iconNode) && (
          <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-ink-400 transition-colors group-hover:border-surface-600">
            {iconNode || <Icon className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />}
          </span>
        )}
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold text-ink-100">{title}</div>
          {subtitle && <div className="mt-0.5 truncate text-xs text-ink-500">{subtitle}</div>}
        </div>
      </div>
      {trailing && <div className="flex flex-none items-center gap-2.5">{trailing}</div>}
    </div>
  )
}

// Status presence dot — pairs with a Badge when a row needs to signal
// "live" at a glance without another badge competing for attention.
export function StatusDot({ tone = 'ink', live = false, className = '' }) {
  const color = {
    emerald: 'bg-emerald-500',
    amber: 'bg-amber-500',
    red: 'bg-red-500',
    blue: 'bg-blue-500',
    ink: 'bg-ink-500',
  }[tone] || 'bg-ink-500'
  return (
    <span className={clsx('relative flex h-2 w-2 flex-none rounded-full', color, className)} aria-hidden="true">
      {live && <span className={clsx('dot-live absolute inset-0 rounded-full', color)} />}
    </span>
  )
}

// A card is a real surface: 1px border, soft elevation, 12px radius. Content
// that needs to sit flush to the edge (lists, tables) gets no padding — pass
// padding through `className` when the card holds prose instead.
export function Card({ children, className = '', interactive = false, as: As = 'div', ...rest }) {
  return (
    <As
      className={clsx(
        'edge-lit rounded-xl border border-surface-700/70 bg-surface-900',
        interactive &&
          'transition-[border-color,box-shadow,transform] duration-200 ease-emphasis hover:-translate-y-0.5 hover:border-blue-500/50 hover:[box-shadow:var(--shadow-raised)]',
        className
      )}
      {...rest}
    >
      {children}
    </As>
  )
}

export function CardHeader({ children, className = '' }) {
  return (
    <div className={clsx('flex min-h-[3.25rem] items-center gap-3 border-b border-surface-800 px-4 py-3', className)}>
      {children}
    </div>
  )
}

// Section title used inside cards and above lists — one consistent size and
// weight rather than six different ad-hoc <h2> treatments.
export function CardTitle({ icon: Icon, children, className = '' }) {
  return (
    <h2 className={clsx('flex items-center gap-2 text-sm font-semibold text-ink-50', className)}>
      {Icon && <Icon className="h-4 w-4 flex-none text-ink-400" strokeWidth={1.75} />}
      {children}
    </h2>
  )
}

export function CardFooter({ children, className = '' }) {
  return (
    <div className={clsx('flex items-center gap-3 border-t border-surface-800 px-4 py-3', className)}>
      {children}
    </div>
  )
}

// A filter/search strip that sits above a list. Distinct from a Card so it
// never reads as "content" — it's chrome.
export function Toolbar({ children, className = '' }) {
  return (
    <div
      className={clsx(
        'mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-surface-700/70 bg-surface-900 px-3 py-2.5 shadow-card',
        className
      )}
    >
      {children}
    </div>
  )
}

// Shared empty state. Every "nothing here" surface in the console uses this
// shape: muted glyph in a framed tile, one line of explanation, optional CTA.
export function EmptyState({ icon: Icon, title, description, action, className = '' }) {
  return (
    <div className={clsx('flex flex-col items-center justify-center px-6 py-14 text-center', className)}>
      {Icon && (
        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl border border-surface-700 bg-surface-850 text-ink-400">
          <Icon className="h-5 w-5" strokeWidth={1.5} />
        </div>
      )}
      <p className="text-sm font-semibold text-ink-100">{title}</p>
      {description && <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-ink-500">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

// Definition list used on every detail page (resource, credential, request,
// identity) so key/value blocks line up identically across the app.
export function DetailList({ items, className = '' }) {
  return (
    <dl className={clsx('divide-y divide-surface-800', className)}>
      {items.map(({ label, value }) => (
        <div key={label} className="grid grid-cols-[minmax(7rem,34%)_1fr] gap-4 px-4 py-2.5">
          <dt className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</dt>
          <dd className="min-w-0 break-words text-sm text-ink-100">{value ?? '—'}</dd>
        </div>
      ))}
    </dl>
  )
}
