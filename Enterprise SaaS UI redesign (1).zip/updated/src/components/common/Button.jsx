import { forwardRef } from 'react'
import clsx from 'clsx'
import { Spinner } from './Spinner'

// ---------------------------------------------------------------------------
// The one button in the console.
// ---------------------------------------------------------------------------
// Every action surface (page header actions, table row actions, modal
// footers, empty-state CTAs) resolves to this component or to `buttonClass()`
// so weight, height, radius, icon size, hover, active and disabled states are
// identical everywhere. Purely presentational — it forwards every prop
// (onClick, type, disabled, form, aria-*) straight through to <button>, so
// swapping a hand-rolled <button className="..."> for this changes nothing
// about behaviour.

const VARIANTS = {
  // The single solid action on a view. Slight gradient + inner top highlight
  // is what separates a "premium" primary from a flat colour block.
  primary:
    'bg-blue-600 text-white shadow-sm ring-1 ring-inset ring-blue-500/50 hover:bg-blue-500 active:bg-blue-700 disabled:bg-blue-600',
  // Default action: reads as a real control (border + surface), not a link.
  secondary:
    'border border-surface-700 bg-surface-900 text-ink-100 shadow-card hover:border-surface-600 hover:bg-surface-850 active:bg-surface-800',
  // Tertiary — lives inside toolbars and card headers.
  subtle:
    'bg-surface-800 text-ink-100 hover:bg-surface-750 active:bg-surface-700',
  ghost:
    'text-ink-400 hover:bg-surface-800 hover:text-ink-50 active:bg-surface-750',
  danger:
    'bg-red-600 text-white shadow-sm ring-1 ring-inset ring-red-500/50 hover:bg-red-500 active:bg-red-700',
  dangerGhost:
    'border border-red-300 text-red-700 hover:bg-red-50 active:bg-red-100 dark:border-red-900/60 dark:text-red-300 dark:hover:bg-red-950/40 dark:active:bg-red-950/60',
}

const SIZES = {
  xs: 'h-7 gap-1.5 rounded-md px-2.5 text-xs',
  sm: 'h-8 gap-1.5 rounded-md px-3 text-xs',
  md: 'h-9 gap-2 rounded-lg px-3.5 text-sm',
  lg: 'h-10 gap-2 rounded-lg px-4 text-sm',
}

const ICON_SIZES = {
  xs: 'h-8 w-8 rounded-md',
  sm: 'h-8 w-8 rounded-md',
  md: 'h-9 w-9 rounded-lg',
  lg: 'h-10 w-10 rounded-lg',
}

const BASE =
  'inline-flex flex-none select-none items-center justify-center whitespace-nowrap font-medium ' +
  'transition-[background-color,border-color,color,box-shadow,transform] duration-150 ' +
  'active:translate-y-px disabled:pointer-events-none disabled:opacity-45'

export function buttonClass({ variant = 'secondary', size = 'md', block = false, iconOnly = false } = {}) {
  return clsx(
    BASE,
    iconOnly ? ICON_SIZES[size] || ICON_SIZES.md : SIZES[size] || SIZES.md,
    VARIANTS[variant] || VARIANTS.secondary,
    block && 'w-full'
  )
}

export const Button = forwardRef(function Button(
  {
    variant = 'secondary',
    size = 'md',
    block = false,
    icon: Icon,
    iconRight: IconRight,
    loading = false,
    disabled,
    className,
    children,
    ...rest
  },
  ref
) {
  const iconOnly = !children
  const glyph = size === 'lg' || size === 'md' ? 'h-4 w-4' : 'h-3.5 w-3.5'
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={clsx(buttonClass({ variant, size, block, iconOnly }), className)}
      {...rest}
    >
      {loading ? (
        <Spinner size={glyph} className={variant === 'primary' || variant === 'danger' ? 'text-white' : undefined} />
      ) : (
        Icon && <Icon className={clsx(glyph, 'flex-none')} strokeWidth={2} />
      )}
      {children}
      {IconRight && !loading && <IconRight className={clsx(glyph, 'flex-none')} strokeWidth={2} />}
    </button>
  )
})

// Icon-only control for toolbars/table rows. Always give it an aria-label.
export const IconButton = forwardRef(function IconButton(
  { icon: Icon, variant = 'ghost', size = 'md', className, ...rest },
  ref
) {
  return (
    <button ref={ref} className={clsx(buttonClass({ variant, size, iconOnly: true }), className)} {...rest}>
      <Icon className={size === 'lg' || size === 'md' ? 'h-4 w-4' : 'h-3.5 w-3.5'} strokeWidth={2} />
    </button>
  )
})
