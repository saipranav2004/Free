import clsx from 'clsx'

// A tiny wrapper, but the point is that every status badge in the app goes
// through this one component with the same ring/padding/weight — so a
// design tweak is a one-file change, not a grep-and-replace across 20 files.
//
// Enterprise consoles read badges as *data*, not decoration: uppercase,
// tight tracking, tabular, and a hairline ring rather than a filled pill.
export function Badge({ children, className, dot = false }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-2 py-0.5 text-2xs font-semibold uppercase tracking-[0.04em] ring-1 ring-inset',
        className || 'bg-ink-500/10 text-ink-400 ring-ink-500/25'
      )}
    >
      {dot && <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-current opacity-80" />}
      {children}
    </span>
  )
}
