import { useEffect } from 'react'
import clsx from 'clsx'
import { X } from 'lucide-react'
import { IconButton } from './Button'

// ---------------------------------------------------------------------------
// Side drawer.
// ---------------------------------------------------------------------------
// The "peek" half of the enterprise list/detail pattern: inspect a row
// without losing your place in a filtered, paged, partially-selected table.
// Deep work still happens on the full detail page — the drawer's footer is
// where "Open full page" lives.
//
// It does not own any data. Whatever the caller renders inside is what the
// user sees, so a drawer showing a resource and the resource's own page can
// never drift apart in what they claim.

export function Drawer({ open, onClose, title, subtitle, icon, footer, width = 'md', children }) {
  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => e.key === 'Escape' && onClose?.()
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-40 flex justify-end" role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : 'Details'}>
      <div
        className="animate-overlay-in absolute inset-0 bg-slate-950/45 backdrop-blur-[2px] dark:bg-black/65"
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        className={clsx(
          'animate-panel-in relative flex h-full w-full flex-col border-l border-surface-700 bg-surface-900 shadow-overlay',
          width === 'lg' ? 'sm:max-w-2xl' : 'sm:max-w-lg'
        )}
      >
        <header className="flex flex-none items-start gap-3 border-b border-surface-800 px-5 py-4">
          {icon && (
            <span className="mt-0.5 flex h-9 w-9 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850">
              {icon}
            </span>
          )}
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-sm font-semibold text-ink-50">{title}</h2>
            {subtitle && <p className="mt-0.5 truncate font-mono text-xs text-ink-500">{subtitle}</p>}
          </div>
          <IconButton icon={X} onClick={onClose} aria-label="Close" title="Close" />
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>

        {footer && (
          <footer className="flex flex-none flex-wrap items-center gap-2 border-t border-surface-800 bg-surface-850/50 px-5 py-3">
            {footer}
          </footer>
        )}
      </aside>
    </div>
  )
}
