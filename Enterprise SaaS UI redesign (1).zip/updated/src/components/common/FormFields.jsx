import clsx from 'clsx'

// Thin, consistent wrappers around a labeled input/select/textarea plus its
// react-hook-form error message. Not a full form-library abstraction —
// deliberately dumb, so it's obvious what each field does.
//
// The visual contract: label above (small, medium weight, ink-300), control
// at a fixed 38px height with a 1px border that turns accent on focus plus a
// 3px focus halo, hint below in muted text, error replacing the hint in red.

export function Field({ label, error, hint, children, required, htmlFor }) {
  return (
    <div className="min-w-0">
      {label && (
        <label htmlFor={htmlFor} className="mb-1.5 flex items-center gap-1 text-xs font-medium text-ink-300">
          {label}
          {required && <span className="text-red-600 dark:text-red-400" aria-hidden="true">*</span>}
        </label>
      )}
      {children}
      {hint && !error && <p className="mt-1.5 text-xs leading-relaxed text-ink-500">{hint}</p>}
      {error && (
        <p className="mt-1.5 text-xs font-medium text-red-600 dark:text-red-400" role="alert">
          {error}
        </p>
      )}
    </div>
  )
}

export const inputClass = (hasError) =>
  clsx(
    'w-full rounded-lg border bg-surface-800 px-3 py-2 text-sm text-ink-50 shadow-sm',
    'placeholder:text-ink-500 focus:outline-none focus-visible:outline-none',
    'disabled:cursor-not-allowed disabled:opacity-50',
    'transition-[border-color,box-shadow] duration-150',
    hasError
      ? 'border-red-500/70 focus:border-red-500 focus:ring-[3px] focus:ring-red-500/20'
      : 'border-surface-700 hover:border-surface-600 focus:border-blue-500 focus:ring-[3px] focus:ring-blue-500/20'
  )

// Same visual contract for a native <select>. The OS caret is kept (native
// selects stay accessible and keyboard-correct); only the frame, height and
// focus treatment are aligned with the text inputs.
export const selectClass = (hasError) => clsx(inputClass(hasError), 'cursor-pointer pr-8')

// Grouping wrapper for a set of related fields inside a modal or settings
// page — gives forms real structure instead of one flat stack of inputs.
export function FieldSet({ title, description, children, className = '' }) {
  return (
    <fieldset className={className}>
      {title && (
        <legend className="mb-1 text-xs font-semibold uppercase tracking-[0.08em] text-ink-500">{title}</legend>
      )}
      {description && <p className="mb-3 text-xs leading-relaxed text-ink-500">{description}</p>}
      <div className="space-y-4">{children}</div>
    </fieldset>
  )
}
