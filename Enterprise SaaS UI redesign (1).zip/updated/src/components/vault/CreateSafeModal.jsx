import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createSafe } from '../../api/vault'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  description: z.string().optional(),
  retention_days: z.coerce.number().int().min(1).max(3650).optional(),
})

export function CreateSafeModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema), defaultValues: { retention_days: 365 } })

  const mutation = useMutation({
    mutationFn: createSafe,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vault', 'safes'] })
      toast.success('Safe created')
      reset()
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  return (
    <div className="animate-overlay-in fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/55 p-4 backdrop-blur-[3px] dark:bg-black/70">
      <div className="animate-panel-in w-full max-w-md rounded-xl border border-surface-700 bg-surface-900 p-6 shadow-overlay">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Create a safe</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>
        <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate className="space-y-4">
          <Field label="Name" error={errors.name?.message} required>
            <input className={inputClass(!!errors.name)} {...register('name')} />
          </Field>
          <Field label="Description" hint="Optional">
            <textarea rows={2} className={inputClass(false)} {...register('description')} />
          </Field>
          <Field
            label="Retention (days)"
            error={errors.retention_days?.message}
            hint="How long deleted credential versions are kept before permanent purge."
          >
            <input inputMode="numeric" className={inputClass(!!errors.retention_days)} {...register('retention_days')} />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="h-9 rounded-lg px-3 text-sm font-medium text-ink-300 transition-colors hover:bg-surface-800 hover:text-ink-50">
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 h-9 rounded-lg bg-blue-600 px-4 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
