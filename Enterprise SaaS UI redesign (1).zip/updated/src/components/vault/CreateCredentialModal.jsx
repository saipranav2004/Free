import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createCredential, listCredentialTypes } from '../../api/vault'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  account_name: z.string().trim().min(1, 'Required'),
  credential_type: z.string().min(1, 'Select a type'),
  secret_plaintext: z.string().trim().min(1, 'Required'),
  description: z.string().optional(),
  rotation_interval_days: z.coerce
    .number()
    .int()
    .min(0, 'Must be 0 or more')
    .optional(),
})

export function CreateCredentialModal({ open, onClose, safeId, folderId }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema), defaultValues: { rotation_interval_days: 0 } })

  // Fetched rather than hardcoded — the vault's own set of supported
  // credential types (with human-readable descriptions) comes straight from
  // vault_service.go's ListCredentialTypes so this list can't drift from
  // what the backend will actually accept.
  const typesQuery = useQuery({
    queryKey: ['vault', 'credential-types'],
    queryFn: ({ signal }) => listCredentialTypes(signal),
    enabled: open,
    staleTime: Infinity,
  })

  const mutation = useMutation({
    mutationFn: (values) =>
      createCredential(safeId, { ...values, folder_id: folderId || undefined }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vault', 'safes', safeId, 'credentials'] })
      toast.success('Credential encrypted and stored')
      reset()
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  return (
    <div className="animate-overlay-in fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/55 p-4 backdrop-blur-[3px] dark:bg-black/70">
      <div className="animate-panel-in my-auto max-h-[88vh] w-full max-w-lg overflow-y-auto rounded-xl border border-surface-700 bg-surface-900 p-6 shadow-overlay">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Store a credential</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>
        <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate className="space-y-4">
          <Field label="Name" error={errors.name?.message} required>
            <input className={inputClass(!!errors.name)} {...register('name')} />
          </Field>
          <Field label="Account name" error={errors.account_name?.message} required>
            <input className={inputClass(!!errors.account_name)} {...register('account_name')} />
          </Field>
          <Field label="Type" error={errors.credential_type?.message} required>
            <select className={inputClass(!!errors.credential_type)} {...register('credential_type')} disabled={typesQuery.isLoading}>
              <option value="">{typesQuery.isLoading ? 'Loading…' : 'Select…'}</option>
              {(typesQuery.data || []).map((t) => (
                <option key={t.type} value={t.type} title={t.description}>
                  {t.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Secret" error={errors.secret_plaintext?.message} hint="Encrypted at rest with envelope encryption before storage." required>
            <textarea rows={3} className={inputClass(!!errors.secret_plaintext) + ' font-mono'} {...register('secret_plaintext')} />
          </Field>
          <Field label="Description" hint="Optional">
            <input className={inputClass(false)} {...register('description')} />
          </Field>
          <Field
            label="Rotation interval (days)"
            error={errors.rotation_interval_days?.message}
            hint="0 = no automatic rotation schedule."
          >
            <input inputMode="numeric" className={inputClass(!!errors.rotation_interval_days)} {...register('rotation_interval_days')} />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="h-9 rounded-lg px-3 text-sm font-medium text-ink-300 transition-colors hover:bg-surface-800 hover:text-ink-50">
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 h-9 rounded-lg bg-blue-600 px-4 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Store
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
