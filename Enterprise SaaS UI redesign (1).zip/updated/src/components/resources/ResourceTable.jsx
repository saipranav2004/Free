import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'
import { Checkbox } from '../common/Checkbox'
import { SortHeader } from '../common/TableControls'
import { ResourceTypeIcon } from './ResourceTypeIcon'
import { ResourceStatusBadges, resourceTypeLabel } from './ResourceCard'

// The full column set. `required: true` marks the ones the column chooser
// won't let you hide — a table with no name column is not a shorter table,
// it's an unusable one.
export const RESOURCE_COLUMNS = [
  { key: 'name', label: 'Resource', required: true },
  { key: 'resource_type', label: 'Type' },
  { key: 'host', label: 'Host' },
  { key: 'port', label: 'Port', align: 'right' },
  { key: 'group', label: 'Group' },
  { key: 'database_name', label: 'Database' },
  { key: 'access', label: 'Access' },
  { key: 'credential', label: 'Credential' },
  { key: 'status', label: 'Status' },
]

export function ResourceTable({
  rows,
  sort,
  onSort,
  density,
  visibleColumns,
  isSelected,
  onToggleRow,
  onToggleAll,
  allOnPageSelected,
  someOnPageSelected,
  onPeek,
  focusedId,
}) {
  const show = (key) => !visibleColumns || visibleColumns.includes(key)
  const pad = density === 'compact' ? 'py-1.5' : 'py-3'

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[54rem] border-separate border-spacing-0 text-sm">
        <thead>
          <tr>
            {/* Sticky + frozen: the header stays put while the body scrolls,
                and the select/name pair stays put while columns scroll
                sideways — so you never lose track of which row is which. */}
            <th
              scope="col"
              className="sticky left-0 top-0 z-20 w-10 border-b border-surface-800 bg-surface-850 px-4 py-2.5"
            >
              <Checkbox
                checked={allOnPageSelected}
                indeterminate={someOnPageSelected}
                onChange={onToggleAll}
                srLabel="Select all rows on this page"
              />
            </th>
            {show('name') && (
              <SortHeader
                label="Resource"
                columnKey="name"
                sort={sort}
                onSort={onSort}
                className="sticky left-10 z-20 min-w-[14rem]"
              />
            )}
            {show('resource_type') && <SortHeader label="Type" columnKey="resource_type" sort={sort} onSort={onSort} />}
            {show('host') && <SortHeader label="Host" columnKey="host" sort={sort} onSort={onSort} />}
            {show('port') && <SortHeader label="Port" columnKey="port" sort={sort} onSort={onSort} align="right" />}
            {show('group') && <SortHeader label="Group" columnKey="group" sort={sort} onSort={onSort} />}
            {show('database_name') && <SortHeader label="Database" columnKey="database_name" sort={sort} onSort={onSort} />}
            {show('access') && <SortHeader label="Access" columnKey="requires_jit" sort={sort} onSort={onSort} />}
            {show('credential') && <SortHeader label="Credential" columnKey="vault_entry_id" sort={sort} onSort={onSort} />}
            {show('status') && <SortHeader label="Status" columnKey="is_active" sort={sort} onSort={onSort} />}
            <SortHeader label="Open" columnKey="_open" srOnly className="w-12" />
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const selected = isSelected(r)
            return (
              <tr
                key={r.id}
                data-row-id={r.id}
                className={clsx(
                  'group transition-colors',
                  selected ? 'bg-blue-50/70 dark:bg-blue-500/[0.07]' : 'hover:bg-surface-850',
                  focusedId === r.id && 'ring-1 ring-inset ring-blue-500/40'
                )}
              >
                <td className={clsx('sticky left-0 z-10 border-b border-surface-800 bg-inherit px-4', pad)}>
                  <Checkbox checked={selected} onChange={() => onToggleRow(r)} srLabel={`Select ${r.name}`} />
                </td>
                {show('name') && (
                  <td className={clsx('sticky left-10 z-10 border-b border-surface-800 bg-inherit px-4', pad)}>
                    <div className="flex min-w-0 items-center gap-2.5">
                      <ResourceTypeIcon type={r.resource_type} className="h-4 w-4 flex-none" />
                      <button
                        type="button"
                        onClick={() => onPeek(r)}
                        className="min-w-0 truncate text-left font-medium text-ink-50 outline-none transition-colors hover:text-blue-600 dark:hover:text-blue-300"
                        title={r.name}
                      >
                        {r.name}
                      </button>
                    </div>
                  </td>
                )}
                {show('resource_type') && (
                  <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-ink-200', pad)}>
                    {resourceTypeLabel(r.resource_type)}
                  </td>
                )}
                {show('host') && (
                  <td className={clsx('border-b border-surface-800 px-4 font-mono text-xs text-ink-300', pad)}>
                    {r.host}
                  </td>
                )}
                {show('port') && (
                  <td className={clsx('border-b border-surface-800 px-4 text-right font-mono text-xs tabular-nums text-ink-300', pad)}>
                    {r.port}
                  </td>
                )}
                {show('group') && (
                  <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-ink-400', pad)}>
                    {r.group || '—'}
                  </td>
                )}
                {show('database_name') && (
                  <td className={clsx('border-b border-surface-800 px-4 text-ink-400', pad)}>
                    {r.database_name || '—'}
                  </td>
                )}
                {show('access') && (
                  <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4', pad)}>
                    <ResourceStatusBadges resource={{ requires_jit: r.requires_jit, is_active: true }} size="sm" />
                  </td>
                )}
                {show('credential') && (
                  <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-xs', pad)}>
                    {r.vault_entry_id ? (
                      <span className="text-emerald-700 dark:text-emerald-400">Attached</span>
                    ) : (
                      <span className="text-ink-500">None</span>
                    )}
                  </td>
                )}
                {show('status') && (
                  <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-xs', pad)}>
                    {r.is_active ? (
                      <span className="text-ink-200">Active</span>
                    ) : (
                      <span className="text-ink-500">Inactive</span>
                    )}
                  </td>
                )}
                <td className={clsx('border-b border-surface-800 px-2', pad)}>
                  <Link
                    to={`/resources/${r.id}`}
                    aria-label={`Open ${r.name}`}
                    className="flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-colors hover:bg-surface-800 hover:text-ink-100"
                  >
                    <ChevronRight className="h-4 w-4" strokeWidth={2} />
                  </Link>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
