import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { AlertTriangle, ScrollText, Radio, KeyRound, ShieldCheck, ShieldOff, FileKey2 } from 'lucide-react'
import { auditByResource } from '../../api/audit'
import { listMySessions } from '../../api/sessions'
import { Card, CardHeader, CardTitle, EmptyState, DetailList, ListRow, StatusDot } from '../common/Layout'
import { Badge } from '../common/Badge'
import { SkeletonRows } from '../common/Spinner'
import { formatDateTime, formatDuration } from '../../lib/format'
import { CONNECT_MODES } from '../../config/constants'
import { resourceTypeLabel, CredentialState } from './ResourceCard'

const CONNECT_MODE_LABEL = Object.fromEntries(CONNECT_MODES.map((m) => [m.value, m.label]))

// A tab whose data source doesn't exist for this shape of object gets an
// honest notice, not an empty list that implies "nothing happened here".
function Unavailable({ title, description }) {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-amber-300/60 bg-amber-50/70 px-4 py-3.5 dark:border-amber-900/40 dark:bg-amber-950/20">
      <AlertTriangle className="mt-0.5 h-4 w-4 flex-none text-amber-600 dark:text-amber-400" strokeWidth={2} />
      <div>
        <p className="text-sm font-semibold text-amber-900 dark:text-amber-200">{title}</p>
        <p className="mt-1 text-sm leading-relaxed text-amber-800/90 dark:text-amber-300/90">{description}</p>
      </div>
    </div>
  )
}

export function OverviewTab({ resource }) {
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Connection</CardTitle>
        </CardHeader>
        <DetailList
          items={[
            { label: 'Type', value: resourceTypeLabel(resource.resource_type) },
            { label: 'Host', value: <span className="font-mono text-xs">{resource.host}</span> },
            { label: 'Port', value: <span className="font-mono text-xs tabular-nums">{resource.port}</span> },
            { label: 'Database', value: resource.database_name || '—' },
            { label: 'Connect mode', value: CONNECT_MODE_LABEL[resource.connect_mode] || resource.connect_mode || '—' },
            {
              label: 'Console URL',
              value: resource.console_url ? (
                <a
                  href={resource.console_url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="break-all text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  {resource.console_url}
                </a>
              ) : (
                '—'
              ),
            },
          ]}
        />
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Registration</CardTitle>
        </CardHeader>
        <DetailList
          items={[
            { label: 'Resource ID', value: <span className="break-all font-mono text-xs">{resource.id}</span> },
            { label: 'Description', value: resource.description || '—' },
            { label: 'Registered', value: resource.created_at ? formatDateTime(resource.created_at) : '—' },
            { label: 'Last updated', value: resource.updated_at ? formatDateTime(resource.updated_at) : '—' },
            { label: 'Credential', value: <CredentialState resource={resource} /> },
          ]}
        />
      </Card>

      {resource.extra_config && Object.keys(resource.extra_config).length > 0 && (
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Protocol configuration</CardTitle>
          </CardHeader>
          <pre className="overflow-x-auto px-4 py-3.5 font-mono text-xs leading-relaxed text-ink-300">
            {JSON.stringify(resource.extra_config, null, 2)}
          </pre>
        </Card>
      )}
    </div>
  )
}

export function PoliciesTab({ resource }) {
  const rules = [
    {
      key: 'jit',
      icon: resource.requires_jit ? KeyRound : ShieldCheck,
      tone: resource.requires_jit ? 'amber' : 'emerald',
      title: resource.requires_jit ? 'Just-in-time elevation required' : 'Standing access permitted',
      body: resource.requires_jit
        ? 'No standing privilege. A user must hold an approved, time-boxed JIT grant before this resource will broker a session.'
        : 'Any user whose role or attached policy permits this resource may connect without raising a request first.',
    },
    {
      key: 'record',
      icon: resource.always_record ? Radio : ScrollText,
      tone: resource.always_record ? 'purple' : 'default',
      title: resource.always_record ? 'Recording is mandatory' : 'Recording follows session policy',
      body: resource.always_record
        ? 'Every session on this resource is recorded. Recording cannot be waived per session.'
        : 'Sessions are recorded when the requesting policy or the session request asks for it.',
    },
    {
      key: 'state',
      icon: resource.is_active ? ShieldCheck : ShieldOff,
      tone: resource.is_active ? 'emerald' : 'red',
      title: resource.is_active ? 'Resource is active' : 'Resource is disabled',
      body: resource.is_active
        ? 'The resource is registered and available for brokered access.'
        : 'The registration exists but is disabled — connection attempts are refused.',
    },
  ]

  const TONE = {
    default: 'border-surface-700 bg-surface-850 text-ink-400',
    emerald: 'border-emerald-600/20 bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300',
    amber: 'border-amber-600/20 bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-300',
    purple: 'border-purple-600/20 bg-purple-50 text-purple-600 dark:bg-purple-500/10 dark:text-purple-300',
    red: 'border-red-600/20 bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-300',
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle icon={FileKey2}>Access rules in force</CardTitle>
        </CardHeader>
        <ul className="divide-y divide-surface-800">
          {rules.map((r) => (
            <li key={r.key} className="flex gap-3.5 px-4 py-4">
              <span className={`flex h-9 w-9 flex-none items-center justify-center rounded-lg border ${TONE[r.tone]}`}>
                <r.icon className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-ink-50">{r.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-ink-400">{r.body}</p>
              </div>
            </li>
          ))}
        </ul>
      </Card>

      <p className="px-1 text-xs leading-relaxed text-ink-500">
        These are the access rules stored on the resource record itself. Role- and policy-based grants that also govern
        this resource are managed in{' '}
        <Link to="/admin/policies" className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400">
          Admin Center → Policies
        </Link>
        .
      </p>
    </div>
  )
}

export function SessionsTab({ resource }) {
  // Self-service endpoint: it returns the caller's OWN sessions only, so the
  // heading says so. Filtering happens here because /sessions/mine takes no
  // resource parameter — claiming otherwise would mean inventing a request.
  const query = useQuery({
    queryKey: ['sessions', 'mine', 'all-for-resource'],
    queryFn: ({ signal }) => listMySessions({ page: 1, pageSize: 100, signal }),
  })

  const sessions = (query.data?.sessions || []).filter(
    (s) => s.resource_id === resource.id || s.resource_name === resource.name
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle icon={Radio}>Your sessions on this resource</CardTitle>
        <span className="ml-auto text-xs text-ink-500">Self-service view — your own sessions only</span>
      </CardHeader>

      {query.isLoading ? (
        <div className="p-4">
          <SkeletonRows rows={3} />
        </div>
      ) : sessions.length === 0 ? (
        <EmptyState
          icon={Radio}
          title="No sessions yet"
          description="Sessions you open against this resource will be listed here with their duration and outcome."
          className="py-12"
        />
      ) : (
        <ul className="divide-y divide-surface-800">
          {sessions.map((s) => (
            <li key={s.id}>
              <ListRow
                title={
                  <span className="flex items-center gap-2">
                    {s.status === 'ACTIVE' && <StatusDot tone="emerald" live />}
                    <span className="truncate">{s.protocol || 'Session'}</span>
                  </span>
                }
                subtitle={`Started ${formatDateTime(s.started_at)}`}
                trailing={
                  <>
                    <span className="text-xs tabular-nums text-ink-400">
                      {s.status === 'ACTIVE'
                        ? formatDuration((Date.now() - new Date(s.started_at).getTime()) / 1000)
                        : formatDuration(s.duration_seconds)}
                    </span>
                    <Badge
                      className={
                        s.status === 'ACTIVE'
                          ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/12 dark:text-emerald-300'
                          : 'bg-ink-500/10 text-ink-400 ring-ink-500/25'
                      }
                    >
                      {s.status}
                    </Badge>
                  </>
                }
              />
            </li>
          ))}
        </ul>
      )}
    </Card>
  )
}

export function AuditTab({ resource }) {
  // GET /pam/audit/resource/*resource. The wildcard's exact shape isn't
  // documented for resource records, so this asks once, doesn't retry, and
  // says plainly when the lookup isn't available rather than rendering an
  // empty list that would read as "nothing ever happened here".
  const query = useQuery({
    queryKey: ['audit', 'resource', resource.id],
    queryFn: ({ signal }) => auditByResource(resource.id, 50, signal),
    retry: false,
  })

  const events = Array.isArray(query.data) ? query.data : query.data?.items || []

  return (
    <div className="space-y-4">
      {query.isError && (
        <Unavailable
          title="Per-resource audit lookup unavailable"
          description="This backend's audit-by-resource route didn't accept this resource's identifier. The full, filterable trail for this system is available on the Audit page."
        />
      )}

      <Card>
        <CardHeader>
          <CardTitle icon={ScrollText}>Recent activity</CardTitle>
          <Link
            to="/audit"
            className="ml-auto text-xs font-medium text-blue-600 transition-colors hover:text-blue-500 dark:text-blue-400"
          >
            Open full audit trail →
          </Link>
        </CardHeader>

        {query.isLoading ? (
          <div className="p-4">
            <SkeletonRows rows={4} />
          </div>
        ) : events.length === 0 ? (
          <EmptyState
            icon={ScrollText}
            title={query.isError ? 'Nothing to show here' : 'No recorded events'}
            description={
              query.isError
                ? 'Use the Audit page to search the tamper-evident trail across every resource.'
                : 'Access decisions, session starts and credential operations for this resource will appear here.'
            }
            className="py-12"
          />
        ) : (
          <ul className="divide-y divide-surface-800">
            {events.slice(0, 25).map((e, i) => (
              <li key={e.id || i} className="flex items-start justify-between gap-4 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-ink-100">{e.action || e.event_type || 'Event'}</p>
                  <p className="mt-0.5 truncate text-xs text-ink-500">
                    {e.username || e.actor_username || e.actor_id || '—'}
                    {e.category ? ` · ${e.category}` : ''}
                  </p>
                </div>
                <div className="flex flex-none items-center gap-2.5">
                  {e.outcome && (
                    <Badge
                      className={
                        String(e.outcome).toUpperCase().includes('DENIED') || String(e.outcome).toUpperCase().includes('FAIL')
                          ? 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/12 dark:text-red-300'
                          : 'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/12 dark:text-emerald-300'
                      }
                    >
                      {e.outcome}
                    </Badge>
                  )}
                  <span className="whitespace-nowrap text-xs tabular-nums text-ink-500">
                    {formatDateTime(e.occurred_at || e.created_at || e.timestamp)}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}
