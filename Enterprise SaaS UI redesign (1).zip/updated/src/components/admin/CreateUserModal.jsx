import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createUser, assignRole } from '../../api/identity'
import { SYSTEM_ROLES } from '../../config/constants'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'
import { downloadUserCredentialsXlsx } from '../../lib/exportUserCredentials'

// Field names for the create-user payload aren't pinned down by any doc
// available here — username/email/full_name/password is the reasonable,
// commonly-named shape assumed for the POST /admin/identity/users body.
const schema = z.object({
  username: z.string().trim().min(1, 'Required').max(255),
  email: z.string().trim().min(1, 'Required').email('Must be a valid email'),
  full_name: z.string().optional(),
  password: z.string().min(10, 'Must be at least 10 characters'),
  role: z.string().optional(),
})

const DEFAULT_ROLE = 'user'

export function CreateUserModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { role: DEFAULT_ROLE },
  })

  const mutation = useMutation({
    mutationFn: async ({ role, ...payload }) => {
      const user = await createUser(payload)
      if (role && role !== DEFAULT_ROLE) {
        await assignRole(user.user_id, role)
      }
      return user
    },
    onSuccess: (_user, variables) => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] })
      toast.success('User created')
      // The backend never returns the password again after this point, so
      // the credentials export has to happen now, from what was just
      // submitted (`variables`), not from the created-user response.
      downloadUserCredentialsXlsx({
        username: variables.username,
        email: variables.email,
        password: variables.password,
        role: variables.role || DEFAULT_ROLE,
      }).catch(() => toast.error('User was created, but the credentials file failed to download.'))
      reset({ role: DEFAULT_ROLE })
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  return (
    <div className="animate-overlay-in fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/55 p-4 backdrop-blur-[3px] dark:bg-black/70">
      <div className="animate-panel-in my-auto max-h-[88vh] w-full max-w-lg overflow-y-auto rounded-xl border border-surface-700 bg-surface-900 p-6 shadow-overlay">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Create user</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit((values) => mutation.mutate(values))}
          noValidate
          className="space-y-4"
        >
          <Field label="Username" error={errors.username?.message} required>
            <input className={inputClass(!!errors.username)} {...register('username')} />
          </Field>

          <Field label="Email" error={errors.email?.message} required>
            <input className={inputClass(!!errors.email)} type="email" {...register('email')} />
          </Field>

          <Field label="Full name" hint="Optional">
            <input className={inputClass(false)} {...register('full_name')} />
          </Field>

          <Field
            label="Password"
            error={errors.password?.message}
            hint="At least 10 characters, matching this app's password policy."
            required
          >
            <input className={inputClass(!!errors.password)} type="password" {...register('password')} />
          </Field>

          <Field label="Role" hint="Assigned via RBAC after the account is created.">
            <select className={inputClass(false)} {...register('role')}>
              {SYSTEM_ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="h-9 rounded-lg px-3 text-sm font-medium text-ink-300 transition-colors hover:bg-surface-800 hover:text-ink-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 h-9 rounded-lg bg-blue-600 px-4 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
