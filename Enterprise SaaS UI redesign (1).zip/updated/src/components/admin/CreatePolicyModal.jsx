import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createPolicy } from '../../api/rbac'
import { listResources } from '../../api/resources'
import { POLICY_EFFECTS, COMMON_ACTIONS } from '../../config/constants'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'

// A policy's `resources` array is matched against strings the backend
// builds as `pam:resource/<id>` (see cmd/pam-api/main.go's RequirePermission
// wiring and opa/engine.go's PolicyDoc doc comment) — there's no way for an
// admin to discover that exact format, or the UUID of a resource they
// created, without reading backend source. This turns "Postgres prod db" in
// the dropdown into the correct `pam:resource/<uuid>` string automatically.
const ALL_RESOURCES_PATTERN = '*'
function resourcePattern(resourceId) {
  return `pam:resource/${resourceId}`
}

// Splits a comma-separated free-text field into a trimmed, non-empty string
// array — the shape the backend policy payload expects for actions/resources.
function toStringArray(value) {
  return (value || '')
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean)
}

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  description: z.string().optional(),
  effect: z.string().min(1, 'Select an effect'),
  actions: z.string().trim().min(1, 'At least one action is required'),
  resources: z.string().trim().min(1, 'At least one resource pattern is required'),
})

export function CreatePolicyModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    control,
    watch,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { effect: 'allow', actions: '', resources: '' },
  })

  const actionsValue = watch('actions')
  const resourcesValue = watch('resources')

  // Resources are self-service-listable (GET /api/v1/pam/resources) for any
  // authenticated user, including admins — reuse that instead of adding a
  // new admin-only endpoint just for this dropdown.
  const resourcesQuery = useQuery({
    queryKey: ['resources', 'for-policy-picker'],
    queryFn: ({ signal }) => listResources({ signal }),
    enabled: open,
  })

  const mutation = useMutation({
    mutationFn: (values) =>
      createPolicy({
        name: values.name,
        description: values.description,
        effect: values.effect,
        actions: toStringArray(values.actions),
        resources: toStringArray(values.resources),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'policies'] })
      toast.success('Policy created')
      reset({ effect: 'allow', actions: '', resources: '' })
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  const addAction = (action) => {
    const current = toStringArray(actionsValue)
    if (current.includes(action)) return
    setValue('actions', [...current, action].join(', '), { shouldValidate: true })
  }

  const addResourcePattern = (pattern) => {
    const current = toStringArray(resourcesValue)
    if (current.includes(pattern)) return
    setValue('resources', [...current, pattern].join(', '), { shouldValidate: true })
  }

  const selectedResourcePatterns = toStringArray(resourcesValue)
  const resources = resourcesQuery.data?.resources || []

  return (
    <div className="animate-overlay-in fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/55 p-4 backdrop-blur-[3px] dark:bg-black/70">
      <div className="animate-panel-in my-auto max-h-[88vh] w-full max-w-lg overflow-y-auto rounded-xl border border-surface-700 bg-surface-900 p-6 shadow-overlay">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Create policy</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit((values) => mutation.mutate(values))}
          noValidate
          className="space-y-4"
        >
          <Field label="Name" error={errors.name?.message} required>
            <input className={inputClass(!!errors.name)} {...register('name')} />
          </Field>

          <Field label="Description" hint="Optional">
            <textarea rows={2} className={inputClass(false)} {...register('description')} />
          </Field>

          <Field label="Effect" error={errors.effect?.message} required>
            <Controller
              name="effect"
              control={control}
              render={({ field }) => (
                <select className={inputClass(!!errors.effect)} {...field}>
                  {POLICY_EFFECTS.map((e) => (
                    <option key={e.value} value={e.value}>
                      {e.label}
                    </option>
                  ))}
                </select>
              )}
            />
          </Field>

          <Field
            label="Actions"
            error={errors.actions?.message}
            hint="Comma-separated action strings — not an enforced client-side vocabulary, the server validates these."
            required
          >
            <textarea
              rows={2}
              className={inputClass(!!errors.actions) + ' font-mono'}
              placeholder="pam:resource:List, pam:vault:Reveal"
              {...register('actions')}
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {COMMON_ACTIONS.map((a) => (
                <button
                  key={a}
                  type="button"
                  onClick={() => addAction(a)}
                  className="rounded-full bg-surface-800 px-2 py-0.5 text-xs text-ink-300 hover:bg-surface-700"
                >
                  {a}
                </button>
              ))}
            </div>
          </Field>

          <Field
            label="Resources"
            error={errors.resources?.message}
            hint="Pick from resources you've created, or edit the raw patterns directly below."
            required
          >
            <div className="mb-2 flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => addResourcePattern(ALL_RESOURCES_PATTERN)}
                className={
                  'rounded-full px-2 py-0.5 text-xs ' +
                  (selectedResourcePatterns.includes(ALL_RESOURCES_PATTERN)
                    ? 'bg-blue-600 text-white'
                    : 'bg-surface-800 text-ink-300 hover:bg-surface-700')
                }
              >
                All resources (*)
              </button>
              {resourcesQuery.isLoading && (
                <span className="px-2 py-0.5 text-xs text-ink-500">Loading your resources…</span>
              )}
              {resourcesQuery.isError && (
                <span className="px-2 py-0.5 text-xs text-red-500">Couldn't load resources.</span>
              )}
              {!resourcesQuery.isLoading && resources.length === 0 && (
                <span className="px-2 py-0.5 text-xs text-ink-500">
                  No resources created yet — register one under Resources first.
                </span>
              )}
              {resources.map((r) => {
                const pattern = resourcePattern(r.id)
                const active = selectedResourcePatterns.includes(pattern)
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => addResourcePattern(pattern)}
                    title={pattern}
                    className={
                      'rounded-full px-2 py-0.5 text-xs ' +
                      (active ? 'bg-blue-600 text-white' : 'bg-surface-800 text-ink-300 hover:bg-surface-700')
                    }
                  >
                    {r.name} <span className="opacity-70">({r.resource_type})</span>
                  </button>
                )
              })}
            </div>
            <textarea
              rows={2}
              className={inputClass(!!errors.resources) + ' font-mono'}
              placeholder="*"
              {...register('resources')}
            />
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="h-9 rounded-lg px-3 text-sm font-medium text-ink-300 transition-colors hover:bg-surface-800 hover:text-ink-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 h-9 rounded-lg bg-blue-600 px-4 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
