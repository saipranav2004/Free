import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { AlertCircle, ArrowLeft, Smartphone } from 'lucide-react'
import { verifyMfa } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { apiErrorMessage } from '../../lib/apiError'
import { Button } from '../../components/common/Button'
import { ThemeToggle } from '../../components/common/ThemeToggle'
import logoWordmark from '../../assets/logo-wordmark.png'
import logoWordmarkDark from '../../assets/logo-wordmark-dark.png'

// NOTE ON THE MISSING COUNTDOWN: the previous PAM frontend (built against an
// older backend) showed a live countdown for the MFA challenge. Verified
// against THIS backend's actual code (auth_service.go's
// verifyChallengeToken): the challenge token here has no expiry check at
// all — it's parsed and accepted regardless of age. Rather than show a
// countdown that lies about enforcement that doesn't exist, this screen
// just doesn't claim one. Worth fixing on the backend at some point; not
// something the frontend should paper over with fake UI.
export default function MfaVerifyPage() {
  const navigate = useNavigate()
  const challenge = useAuthStore((s) => s.mfaChallenge)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
  const setSession = useAuthStore((s) => s.setSession)
  const clearMfaChallenge = useAuthStore((s) => s.clearMfaChallenge)
  const [code, setCode] = useState('')
  const [error, setError] = useState(null)
  const inputRef = useRef(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  // Guard against reaching this screen directly (deep link, back button
  // after the flow already completed, a stale bookmark) with no challenge
  // in memory — without this, submitting would 400 with a confusing
  // "malformed challenge token" instead of just sending the user back to
  // start a fresh login.
  // setSession() (on a correct code) clears mfaChallenge in the very same
  // update that sets the access token, so this guard must also check
  // isAuthenticated — otherwise it fires on the legitimate success path too
  // (challenge just went null) and its navigate('/login') races the success
  // handler's navigate('/'), with whichever runs second winning. That was
  // bouncing a correct code straight back to the login page.
  useEffect(() => {
    if (!challenge?.challengeToken && !isAuthenticated) {
      navigate('/login', { replace: true })
    }
  }, [challenge, isAuthenticated, navigate])

  const mutation = useMutation({
    mutationFn: (code) => verifyMfa(challenge.challengeToken, code),
    onSuccess: (result) => {
      resetSessionExpiredGuard()
      clearMfaChallenge()
      setSession({
        accessToken: result.access_token,
        expiresAt: result.expires_at,
        user: null,
      })
      navigate('/', { replace: true })
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      // Clear the code on failure so the user re-types rather than
      // resubmitting the same rejected code by accident — but keep focus in
      // the field so they don't have to click back into it.
      setCode('')
      inputRef.current?.focus()
    },
  })

  const submit = (e) => {
    e?.preventDefault()
    if (code.trim().length === 0 || mutation.isPending) return
    setError(null)
    mutation.mutate(code.trim())
  }

  if (!challenge?.challengeToken) return null

  return (
    <div className="flex min-h-screen flex-col bg-surface-950 px-4 py-8 sm:px-8">
      <div className="flex items-center justify-between">
        <div>
          <img src={logoWordmark} alt="Deep Algorithms" className="h-6 w-auto object-contain object-left dark:hidden" />
          <img src={logoWordmarkDark} alt="" aria-hidden="true" className="hidden h-6 w-auto object-contain object-left dark:block" />
        </div>
        <ThemeToggle compact />
      </div>

      <div className="flex flex-1 items-center justify-center">
        <div className="w-full max-w-[23rem]">
          <div className="mb-8 text-center">
            <span className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm ring-1 ring-inset ring-white/15">
              <Smartphone className="h-5 w-5" strokeWidth={1.75} />
            </span>
            <h1 className="text-xl font-semibold tracking-tight text-ink-50">Two-factor verification</h1>
            <p className="mt-1.5 text-sm leading-relaxed text-ink-400">
              Enter the 6-digit code from your authenticator app to finish signing in.
            </p>
          </div>

          <form
            onSubmit={submit}
            className="space-y-5 rounded-xl border border-surface-700/70 bg-surface-900 p-6 shadow-card"
          >
            {error && (
              <div
                role="alert"
                className="flex items-start gap-2.5 rounded-lg border border-red-300/70 bg-red-50 px-3 py-2.5 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
              >
                <AlertCircle className="mt-0.5 h-4 w-4 flex-none" strokeWidth={2} />
                <span className="leading-relaxed">{error}</span>
              </div>
            )}

            <div>
              <label htmlFor="mfa-code" className="mb-1.5 block text-xs font-medium text-ink-300">
                Verification code
              </label>
              <input
                id="mfa-code"
                ref={inputRef}
                inputMode="numeric"
                autoComplete="one-time-code"
                pattern="[0-9]*"
                maxLength={8}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ''))}
                className="w-full rounded-lg border border-surface-700 bg-surface-800 px-3 py-3 text-center font-mono text-2xl tabular-nums tracking-[0.45em] text-ink-50 shadow-sm transition-[border-color,box-shadow] duration-150 placeholder:text-ink-600 hover:border-surface-600 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
                placeholder="000000"
              />
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              block
              loading={mutation.isPending}
              disabled={code.length === 0}
            >
              Verify and continue
            </Button>
          </form>

          <div className="mt-6 flex justify-center">
            <Button
              variant="ghost"
              size="sm"
              icon={ArrowLeft}
              onClick={() => {
                clearMfaChallenge()
                navigate('/login', { replace: true })
              }}
            >
              Back to sign in
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
