import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useNavigate, useLocation } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { AlertCircle, ArrowRight, Fingerprint, KeyRound, ScrollText, ShieldCheck } from 'lucide-react'
import { login } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { Field, inputClass } from '../../components/common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Button } from '../../components/common/Button'
import { ThemeToggle } from '../../components/common/ThemeToggle'
import logoWordmark from '../../assets/logo-wordmark.png'
import logoWordmarkDark from '../../assets/logo-wordmark-dark.png'

const schema = z.object({
  identifier: z.string().trim().min(1, 'Required'),
  password: z.string().min(1, 'Required'),
})

// Assurances shown on the brand panel. Static copy — no data, no fetching.
const PILLARS = [
  { icon: KeyRound, title: 'Just-in-time access', body: 'Time-boxed, approved elevation instead of standing privilege.' },
  { icon: Fingerprint, title: 'Brokered credentials', body: 'Secrets stay in the vault; sessions are brokered, never shared.' },
  { icon: ScrollText, title: 'Tamper-evident audit', body: 'Every privileged action written to a verifiable hash chain.' },
]

export default function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const setSession = useAuthStore((s) => s.setSession)
  const setMfaChallenge = useAuthStore((s) => s.setMfaChallenge)
  const [formError, setFormError] = useState(null)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })

  const mutation = useMutation({
    mutationFn: ({ identifier, password }) => login(identifier, password),
    onSuccess: (result) => {
      setFormError(null)
      // LoginResult's fields are `omitempty` on the Go side — the only
      // reliable way to tell "full session" from "MFA challenge" apart is
      // whether access_token actually came back, not the HTTP status (both
      // paths return 200 — see auth_handler.go's Login: ErrMFARequired is
      // deliberately treated as a *success* response, not an error one).
      if (result?.access_token) {
        resetSessionExpiredGuard()
        setSession({
          accessToken: result.access_token,
          expiresAt: result.expires_at,
          user: null, // populated by the dashboard's `me()` fetch
        })
        const from = location.state?.from?.pathname || '/'
        navigate(from, { replace: true })
        return
      }
      if (result?.challenge_token) {
        setMfaChallenge({ challengeToken: result.challenge_token })
        navigate('/mfa-verify', { replace: true })
        return
      }
      // Defensive: neither shape came back. Don't silently do nothing —
      // that's the kind of bug where the user clicks Login, sees no error
      // and no navigation, and assumes the app is frozen.
      setFormError('Unexpected response from the server. Please try again.')
    },
    onError: (err) => setFormError(apiErrorMessage(err)),
  })

  const onSubmit = (values) => {
    setFormError(null)
    mutation.mutate(values)
  }

  return (
    <div className="flex min-h-screen bg-surface-950">
      {/* Brand panel — desktop only. Sets the trust tone before the user
          types a credential; carries no interactive surface of its own. */}
      <aside className="relative hidden w-[46%] max-w-2xl flex-col justify-between overflow-hidden bg-surface-900 px-12 py-12 lg:flex">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-[0.55] dark:opacity-40"
          style={{
            backgroundImage:
              'linear-gradient(to right, rgb(148 163 184 / 0.14) 1px, transparent 1px), linear-gradient(to bottom, rgb(148 163 184 / 0.14) 1px, transparent 1px)',
            backgroundSize: '44px 44px',
            maskImage: 'radial-gradient(ellipse at 30% 20%, black 10%, transparent 72%)',
            WebkitMaskImage: 'radial-gradient(ellipse at 30% 20%, black 10%, transparent 72%)',
          }}
        />
        <div className="relative">
          <img src={logoWordmark} alt="Deep Algorithms" className="h-8 w-auto object-contain object-left dark:hidden" />
          <img src={logoWordmarkDark} alt="" aria-hidden="true" className="hidden h-8 w-auto object-contain object-left dark:block" />
        </div>

        <div className="relative max-w-md">
          <p className="text-2xs font-semibold uppercase tracking-[0.14em] text-blue-600 dark:text-blue-400">
            Privileged Access Management
          </p>
          <h2 className="mt-3 text-[1.75rem] font-semibold leading-tight tracking-tight text-ink-50">
            Control, broker and prove every privileged action.
          </h2>
          <ul className="mt-9 space-y-6">
            {PILLARS.map((p) => (
              <li key={p.title} className="flex gap-4">
                <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-blue-50 text-blue-600 ring-1 ring-inset ring-blue-600/15 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-500/25">
                  <p.icon className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
                </span>
                <div>
                  <p className="text-sm font-semibold text-ink-100">{p.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-ink-400">{p.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs text-ink-500">
          Authorized use only. All access attempts are logged and monitored.
        </p>
      </aside>

      {/* Credential panel */}
      <div className="flex flex-1 flex-col px-4 py-8 sm:px-8">
        <div className="flex items-center justify-between">
          <div className="lg:hidden">
            <img src={logoWordmark} alt="Deep Algorithms" className="h-6 w-auto object-contain object-left dark:hidden" />
            <img src={logoWordmarkDark} alt="" aria-hidden="true" className="hidden h-6 w-auto object-contain object-left dark:block" />
          </div>
          <div className="ml-auto">
            <ThemeToggle compact />
          </div>
        </div>

        <div className="flex flex-1 items-center justify-center">
          <div className="w-full max-w-[23rem]">
            <div className="mb-8">
              <span className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm ring-1 ring-inset ring-white/15">
                <ShieldCheck className="h-5 w-5" strokeWidth={1.75} />
              </span>
              <h1 className="text-xl font-semibold tracking-tight text-ink-50">Sign in to PAM Console</h1>
              <p className="mt-1.5 text-sm text-ink-400">Use your corporate directory credentials.</p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
              {formError && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 rounded-lg border border-red-300/70 bg-red-50 px-3 py-2.5 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 flex-none" strokeWidth={2} />
                  <span className="leading-relaxed">{formError}</span>
                </div>
              )}

              <Field label="Username or email" error={errors.identifier?.message} required htmlFor="identifier">
                <input
                  id="identifier"
                  autoFocus
                  autoComplete="username"
                  placeholder="you@company.com"
                  className={inputClass(!!errors.identifier)}
                  {...register('identifier')}
                />
              </Field>

              <Field label="Password" error={errors.password?.message} required htmlFor="password">
                <input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  placeholder="••••••••••••"
                  className={inputClass(!!errors.password)}
                  {...register('password')}
                />
              </Field>

              <Button type="submit" variant="primary" size="lg" block loading={mutation.isPending} iconRight={ArrowRight}>
                Sign in
              </Button>
            </form>

            <p className="mt-8 text-center text-xs leading-relaxed text-ink-500">
              Protected by multi-factor authentication. Sessions are time-limited and fully audited.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
