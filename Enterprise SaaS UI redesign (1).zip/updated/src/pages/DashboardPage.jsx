import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  Boxes, Vault, Radio, KeyRound, ScrollText, ShieldAlert, ArrowRight,
  Users, ClipboardList, Lock, Activity, ChevronRight, Inbox, ShieldCheck,
} from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { getStats } from '../api/admin'
import { listMyGrants, listMyJitRequests } from '../api/jit'
import { listMySessions } from '../api/sessions'
import { PageHeader, Card, Section, EmptyState } from '../components/common/Layout'
import { StatCard } from '../components/common/StatCard'
import { Badge } from '../components/common/Badge'
import { formatDateTime } from '../lib/format'
import { JIT_STATUS_BADGE, JIT_STATUS_LABELS } from '../config/constants'

// GET /admin/stats (AdminHandler.Stats, admin_handler.go) returns exactly
// five fields — pending_approvals, active_sessions, active_grants,
// active_breakglass_grants, active_resources, plus generated_at — verified
// against the actual handler source, not guessed. An earlier version of
// this file guessed at several OTHER field names (total_users,
// pending_jit_requests, total_resources, audit_events_24h,
// total_credentials) that the backend has never returned, so those tiles
// always rendered "—" regardless of real data. Two of those (pending JIT
// count, resource count) mapped onto real fields under a different name
// and are fixed below. The other three (user count, 24h audit volume,
// vault credential count) have no backing query anywhere in the backend
// at all — Stats() has no access to IdentityService/VaultService/audit
// counts to compute them — so rather than ship tiles that can never show
// real data, they've been removed. Re-add them once AdminHandler.Stats is
// extended to actually compute those three counts.
function pick(obj, ...keys) {
  if (!obj) return undefined
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null) return obj[k]
  }
  return undefined
}

const QUICK_LINKS = [
  { to: '/resources', label: 'Resources', icon: Boxes, description: 'Browse systems you can connect to' },
  { to: '/vault', label: 'Vault', icon: Vault, description: 'Safes, folders & credentials' },
  { to: '/sessions', label: 'Sessions', icon: Radio, description: 'Your connection history' },
  { to: '/jit', label: 'JIT Access', icon: KeyRound, description: 'Request or view time-boxed access' },
  { to: '/audit', label: 'Audit', icon: ScrollText, description: 'Search your activity trail' },
]

// Navigation plate — a drawn object with a framed glyph, a title, a
// supporting line and a directional affordance. The hairline top highlight
// and the hover lift are what separate this from a flat link box.
function NavPlate({ to, label, description, icon: Icon }) {
  return (
    <Link to={to} className="group block h-full rounded-xl outline-none">
      <Card interactive className="flex h-full items-center gap-3.5 p-4">
        <span className="flex h-10 w-10 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-ink-400 transition-colors duration-200 group-hover:border-blue-500/40 group-hover:bg-blue-50 group-hover:text-blue-600 dark:group-hover:bg-blue-500/10 dark:group-hover:text-blue-300">
          <Icon className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-semibold text-ink-100">{label}</span>
          {description && <span className="mt-0.5 block truncate text-xs text-ink-500">{description}</span>}
        </span>
        <ArrowRight
          className="h-4 w-4 flex-none text-ink-600 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-blue-600 dark:group-hover:text-blue-300"
          strokeWidth={1.5}
        />
      </Card>
    </Link>
  )
}

// A link that reads as a section action rather than a button.
function SectionLink({ to, children }) {
  return (
    <Link
      to={to}
      className="group inline-flex items-center gap-1 text-xs font-semibold text-blue-600 transition-colors hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
    >
      {children}
      <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" strokeWidth={2} />
    </Link>
  )
}

function AdminDashboard() {
  const statsQuery = useQuery({ queryKey: ['admin', 'stats'], queryFn: ({ signal }) => getStats(signal) })
  const s = statsQuery.data

  return (
    <div>
      <PageHeader
        eyebrow="Control plane"
        title="Admin overview"
        description="Organization-wide posture across identity, privileged access, and audit."
        meta={
          <span className="inline-flex items-center gap-2 rounded-md border border-surface-700 bg-surface-900 px-2.5 py-1 text-2xs font-medium uppercase tracking-[0.08em] text-ink-400">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" strokeWidth={1.75} />
            All privileged activity brokered &amp; recorded
          </span>
        }
      />

      <Section label="Posture">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          <StatCard
            label="Active sessions"
            icon={Activity}
            tone="emerald"
            live
            loading={statsQuery.isLoading}
            value={pick(s, 'active_sessions') ?? '—'}
            hint="Live brokered connections"
          />
          <StatCard
            label="Pending JIT requests"
            icon={KeyRound}
            tone="amber"
            loading={statsQuery.isLoading}
            value={pick(s, 'pending_approvals') ?? '—'}
            hint="Awaiting an approval decision"
          />
          <StatCard
            label="Active grants"
            icon={Lock}
            tone="emerald"
            loading={statsQuery.isLoading}
            value={pick(s, 'active_grants') ?? '—'}
            hint="Elevation currently in force"
          />
          <StatCard
            label="Resources"
            icon={Boxes}
            loading={statsQuery.isLoading}
            value={pick(s, 'active_resources') ?? '—'}
            hint="Registered and reachable"
          />
          <StatCard
            label="Break-glass active"
            icon={ShieldAlert}
            tone="red"
            loading={statsQuery.isLoading}
            value={pick(s, 'active_breakglass_grants') ?? '—'}
            hint="Emergency access in use"
          />
        </div>
      </Section>

      <Section label="Administration">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            { to: '/admin/identity', label: 'Identity', icon: Users, description: 'Accounts, roles & policies' },
            { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound, description: 'Decide pending requests' },
            { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList, description: 'Search and verify the trail' },
            { to: '/admin/vault-ops', label: 'Vault Operations', icon: Vault, description: 'Backup and restore' },
          ].map((l) => (
            <NavPlate key={l.to} {...l} />
          ))}
        </div>
      </Section>
    </div>
  )
}

function UserDashboard({ user }) {
  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMyGrants({ activeOnly: true, pageSize: 5, signal }),
  })
  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', 'mine', { status: 'PENDING', dashboard: true }],
    queryFn: ({ signal }) => listMyJitRequests({ status: 'PENDING', pageSize: 5, signal }),
  })
  const sessionsQuery = useQuery({
    queryKey: ['sessions', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMySessions({ activeOnly: true, pageSize: 5, signal }),
  })

  const pendingRequests = requestsQuery.data?.requests ?? []

  return (
    <div>
      <PageHeader
        eyebrow="Overview"
        title={`Welcome${user?.username ? `, ${user.username}` : ''}`}
        description="Your access at a glance — elevation in force, requests in flight, and live sessions."
      />

      <Section label="Your access">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <StatCard
            label="Active grants"
            icon={Lock}
            tone="emerald"
            loading={grantsQuery.isLoading}
            value={grantsQuery.data?.pagination?.total ?? grantsQuery.data?.grants?.length ?? 0}
            hint="Elevation available to you right now"
          />
          <StatCard
            label="Pending requests"
            icon={KeyRound}
            tone="amber"
            loading={requestsQuery.isLoading}
            value={requestsQuery.data?.pagination?.total ?? requestsQuery.data?.requests?.length ?? 0}
            hint="Waiting on an approver"
          />
          <StatCard
            label="Active sessions"
            icon={Activity}
            live
            loading={sessionsQuery.isLoading}
            value={sessionsQuery.data?.pagination?.total ?? sessionsQuery.data?.sessions?.length ?? 0}
            hint="Connections open in your name"
          />
        </div>
      </Section>

      {!requestsQuery.isLoading && (
        <Section label="Requests in flight" action={<SectionLink to="/jit">View all</SectionLink>}>
          <Card>
            {pendingRequests.length === 0 ? (
              <EmptyState
                icon={Inbox}
                title="No requests awaiting approval"
                description="Requests you submit for time-boxed access appear here until an approver decides."
                className="py-12"
              />
            ) : (
              <ul className="divide-y divide-surface-800">
                {pendingRequests.map((r) => (
                  <li key={r.id}>
                    <Link
                      to={`/jit/requests/${r.id}`}
                      className="group flex items-center justify-between gap-4 px-4 py-3.5 transition-colors hover:bg-surface-850"
                    >
                      <div className="flex min-w-0 items-center gap-3.5">
                        <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-ink-400 transition-colors group-hover:border-surface-600">
                          <KeyRound className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
                        </span>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-ink-100">
                            {r.resource_name || r.resource_id}
                          </p>
                          <p className="mt-0.5 text-xs text-ink-500">Requested {formatDateTime(r.created_at)}</p>
                        </div>
                      </div>
                      <div className="flex flex-none items-center gap-2.5">
                        <Badge className={JIT_STATUS_BADGE[r.status] || 'bg-ink-500/10 text-ink-400 ring-ink-500/25'}>
                          {JIT_STATUS_LABELS[r.status] || r.status}
                        </Badge>
                        <ChevronRight
                          className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                          strokeWidth={1.5}
                        />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </Section>
      )}

      <Section label="Go to">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {QUICK_LINKS.map((l) => (
            <NavPlate key={l.to} {...l} />
          ))}
        </div>
      </Section>
    </div>
  )
}

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  return isAdmin ? <AdminDashboard /> : <UserDashboard user={user} />
}
