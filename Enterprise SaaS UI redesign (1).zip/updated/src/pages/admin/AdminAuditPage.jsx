import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ScrollText, Video, ShieldCheck, ShieldAlert, FileSearch, Download } from 'lucide-react'
import { listAudit, listRecordings, verifyAudit } from '../../api/admin'
import { generateComplianceReport } from '../../api/audit'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { TabBar } from '../../components/common/TabBar'
import { Spinner } from '../../components/common/Spinner'
import { inputClass } from '../../components/common/FormFields'
import { AuditEventDetailModal } from '../../components/audit/AuditEventDetailModal'
import {
  formatDateTime,
  formatDuration,
  dateInputToRFC3339,
  todayDateInputValue,
  daysAgoDateInputValue,
} from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  AUDIT_CATEGORIES, AUDIT_OUTCOMES, AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE,
  RECORDING_STATUS_BADGE, DEFAULT_PAGE_SIZE,
} from '../../config/constants'

const TABS = [
  { key: 'events', label: 'Events', icon: ScrollText },
  { key: 'recordings', label: 'Recordings', icon: Video },
  { key: 'chain', label: 'Chain Verification', icon: ShieldCheck },
]

const selectClass =
  'rounded-md border border-surface-700 bg-surface-800 px-2.5 py-1.5 text-sm text-ink-100 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20'

// Same defensive lookups as the self-service AuditPage — the exact field
// names for actor/target on an org-wide event aren't pinned down anywhere
// we've been given.
function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}
function actorLabel(item) {
  return (
    item?.actor_username ||
    item?.username ||
    item?.actor?.username ||
    item?.user_email ||
    item?.actor_id ||
    item?.user_id ||
    '—'
  )
}
function targetLabel(item) {
  return item?.resource_name || item?.resource || item?.target || item?.resource_id || '—'
}

function EventsTab() {
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [page, setPage] = useState(1)
  const [reportOpen, setReportOpen] = useState(false)
  const [reportFormat, setReportFormat] = useState('pdf')
  const [reportFrom, setReportFrom] = useState(() => daysAgoDateInputValue(30))
  const [reportTo, setReportTo] = useState(() => todayDateInputValue())
  const [selectedEvent, setSelectedEvent] = useState(null)

  const changeCategory = (next) => {
    setCategory(next)
    setPage(1)
  }
  const changeOutcome = (next) => {
    setOutcome(next)
    setPage(1)
  }

  const eventsQuery = useQuery({
    queryKey: ['admin', 'audit', 'events', { page, category, outcome }],
    queryFn: ({ signal }) =>
      listAudit(
        { page, page_size: DEFAULT_PAGE_SIZE, category: category || undefined, outcome: outcome || undefined },
        signal
      ),
    placeholderData: (prev) => prev,
  })

  // Reuses the same backend route the self-service Audit page uses
  // (there's only one /audit/report endpoint — see api/audit.js) but this
  // is the more natural home for it: an admin doing compliance work looks
  // under "Audit & Compliance", not their own personal audit trail.
  const reportMutation = useMutation({
    mutationFn: () => {
      const fromTime = dateInputToRFC3339(reportFrom, false)
      const toTime = dateInputToRFC3339(reportTo, true)
      if (!fromTime || !toTime) throw new Error('Pick a start and end date for the report range.')
      if (new Date(fromTime) > new Date(toTime)) throw new Error('The start date must be before the end date.')
      return generateComplianceReport({
        category: category || undefined,
        outcome: outcome || undefined,
        fromTime,
        toTime,
        format: reportFormat,
      })
    },
    onSuccess: (result) => {
      toast.success(result?.filename ? `Report downloaded: ${result.filename}` : 'Report downloaded')
    },
    onError: (err) => toast.error(err?.response ? apiErrorMessage(err) : err.message || apiErrorMessage(err)),
  })

  const pagination = eventsQuery.data?.pagination

  return (
    <>
      <Card className="mb-4">
        <CardHeader className="flex flex-wrap items-center gap-3">
          <select value={category} onChange={(e) => changeCategory(e.target.value)} className={selectClass}>
            <option value="">All categories</option>
            {AUDIT_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select value={outcome} onChange={(e) => changeOutcome(e.target.value)} className={selectClass}>
            <option value="">All outcomes</option>
            {AUDIT_OUTCOMES.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
          <button
            onClick={() => setReportOpen((v) => !v)}
            className="ml-auto flex items-center gap-1.5 h-9 rounded-lg bg-blue-600 px-3.5 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700"
          >
            <FileSearch className="h-4 w-4" /> Generate report
          </button>
        </CardHeader>

        {reportOpen && (
          <div className="flex flex-wrap items-end gap-3 border-b border-surface-800 px-4 py-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-ink-300">From</label>
              <input
                type="date"
                value={reportFrom}
                max={reportTo}
                onChange={(e) => setReportFrom(e.target.value)}
                className={inputClass(false)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-ink-300">To</label>
              <input
                type="date"
                value={reportTo}
                min={reportFrom}
                max={todayDateInputValue()}
                onChange={(e) => setReportTo(e.target.value)}
                className={inputClass(false)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium text-ink-300">Format</span>
              <div className="flex items-center gap-3 py-1.5">
                <label className="flex items-center gap-1.5 text-sm text-ink-200">
                  <input
                    type="radio"
                    name="admin-report-format"
                    checked={reportFormat === 'pdf'}
                    onChange={() => setReportFormat('pdf')}
                  />
                  PDF
                </label>
                <label className="flex items-center gap-1.5 text-sm text-ink-200">
                  <input
                    type="radio"
                    name="admin-report-format"
                    checked={reportFormat === 'csv'}
                    onChange={() => setReportFormat('csv')}
                  />
                  CSV
                </label>
              </div>
            </div>
            <button
              onClick={() => reportMutation.mutate()}
              disabled={reportMutation.isPending}
              className="flex items-center gap-1.5 rounded-lg bg-surface-800 transition-colors px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
            >
              {reportMutation.isPending ? <Spinner size="h-3.5 w-3.5" /> : <Download className="h-3.5 w-3.5" />}
              Download
            </button>
            <span className="text-xs text-ink-500">Org-wide — also scoped to the filters above.</span>
          </div>
        )}

        <QueryState
          query={eventsQuery}
          empty={(d) => !d?.events || d.events.length === 0}
          emptyMessage="No audit events found."
        >
          {(data) => (
            <>
              <ul className="divide-y divide-surface-800">
                {data.events.map((item, idx) => (
                  <li key={item?.id ?? idx}>
                    <button
                      type="button"
                      onClick={() => setSelectedEvent(item)}
                      className="flex w-full flex-col gap-2 px-4 py-3.5 text-left transition-colors hover:bg-surface-850 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink-100">
                          <span className="text-ink-400">{item?.category || 'OTHER'}</span>
                          <span>{item?.action || '—'}</span>
                          {item?.outcome && (
                            <Badge className={AUDIT_OUTCOME_BADGE[item.outcome] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                              {item.outcome}
                            </Badge>
                          )}
                          {item?.severity && (
                            <Badge className={AUDIT_SEVERITY_BADGE[item.severity] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                              {item.severity}
                            </Badge>
                          )}
                        </p>
                        <p className="mt-1 truncate text-xs text-ink-500">
                          {formatDateTime(itemTimestamp(item))} · actor: {actorLabel(item)} · target: {targetLabel(item)}
                        </p>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <AuditEventDetailModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />
    </>
  )
}

function RecordingsTab() {
  const [page, setPage] = useState(1)

  const recordingsQuery = useQuery({
    queryKey: ['admin', 'recordings', { page }],
    queryFn: ({ signal }) => listRecordings({ page, page_size: DEFAULT_PAGE_SIZE }, signal),
  })

  const pagination = recordingsQuery.data?.pagination

  return (
    <Card>
      <QueryState
        query={recordingsQuery}
        empty={(d) => !d?.recordings || d.recordings.length === 0}
        emptyMessage="No session recordings found."
      >
        {(data) => (
          <>
            <ul className="divide-y divide-surface-800">
              {data.recordings.map((rec, idx) => (
                <li key={rec?.id ?? idx} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink-100">
                      {rec?.resource_name || rec?.resource_id || '—'}
                      {rec?.session_id ? (
                        <span className="ml-2 text-xs font-normal text-ink-500">session {rec.session_id}</span>
                      ) : null}
                    </p>
                    <p className="mt-0.5 truncate text-xs text-ink-500">
                      Started {formatDateTime(rec?.started_at || rec?.created_at)}
                      {rec?.duration_seconds != null ? ` · ${formatDuration(rec.duration_seconds)}` : ''}
                    </p>
                  </div>
                  <Badge className={RECORDING_STATUS_BADGE[rec?.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                    {rec?.status || 'UNKNOWN'}
                  </Badge>
                </li>
              ))}
            </ul>
            {pagination && (
              <Pagination
                page={pagination.page}
                pageSize={pagination.page_size}
                total={pagination.total}
                totalPages={pagination.total_pages}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </QueryState>
    </Card>
  )
}

// Local to this file only (deliberately not shared with AdminOverviewPage's
// own version) — same defensive field-name probing, since the exact shape
// of verifyAudit()'s payload isn't pinned down anywhere we have access to.
function ChainVerificationBanner({ result }) {
  if (!result) return null
  const knownField =
    'valid' in result ? 'valid'
    : 'chain_valid' in result ? 'chain_valid'
    : 'intact' in result ? 'intact'
    : 'success' in result ? 'success'
    : null
  const isValid = knownField ? Boolean(result[knownField]) : null

  return (
    <div
      className={
        'flex items-start gap-3 rounded-lg border p-4 ' +
        (isValid === false
          ? 'border-red-400 dark:border-red-600/60 bg-red-50 dark:bg-red-950/40'
          : isValid === true
            ? 'border-emerald-300 dark:border-emerald-600/40 bg-emerald-50 dark:bg-emerald-950/20'
            : 'border-surface-800 bg-surface-900')
      }
    >
      {isValid === false && <ShieldAlert className="mt-0.5 h-5 w-5 flex-none text-red-600 dark:text-red-400" />}
      {isValid === true && <ShieldCheck className="mt-0.5 h-5 w-5 flex-none text-emerald-600 dark:text-emerald-400" />}
      <div className="min-w-0">
        {isValid === true && (
          <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">Audit chain intact — no tampering detected.</p>
        )}
        {isValid === false && (
          <p className="text-sm font-semibold text-red-700 dark:text-red-300">
            Audit chain broken — possible tampering detected. Notify a security administrator.
          </p>
        )}
        {isValid === null && (
          <>
            <p className="mb-1 text-sm font-medium text-ink-100">Verification result</p>
            <pre className="max-w-full overflow-x-auto text-xs text-ink-400">{JSON.stringify(result, null, 2)}</pre>
          </>
        )}
      </div>
    </div>
  )
}

function ChainVerificationTab() {
  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <Card>
      <CardHeader className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-medium text-ink-100">Audit chain integrity (org-wide)</h2>
        <button
          onClick={() => verifyMutation.mutate()}
          disabled={verifyMutation.isPending}
          className="flex items-center gap-1.5 h-9 rounded-lg bg-blue-600 px-3.5 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700 disabled:opacity-60"
        >
          {verifyMutation.isPending ? <Spinner size="h-3.5 w-3.5" className="text-white" /> : <ShieldCheck className="h-4 w-4" />}
          Run verification
        </button>
      </CardHeader>
      <div className="p-4">
        {verifyMutation.isPending ? (
          <div className="flex items-center gap-2 text-sm text-ink-400">
            <Spinner size="h-4 w-4" /> Verifying…
          </div>
        ) : verifyMutation.isSuccess ? (
          <ChainVerificationBanner result={verifyMutation.data} />
        ) : (
          <p className="text-xs text-ink-500">
            Checks that org-wide audit entries form an unbroken, tamper-evident chain. Not run automatically —
            trigger it explicitly.
          </p>
        )}
      </div>
    </Card>
  )
}

export default function AdminAuditPage() {
  const [tab, setTab] = useState('events')

  return (
    <div>
      <PageHeader
        title="Audit & Compliance"
        description="Org-wide audit trail, session recordings, and tamper-evident chain verification."
      />

      <div className="mb-4">
        <TabBar tabs={TABS} active={tab} onChange={setTab} />
      </div>

      {tab === 'events' && <EventsTab />}
      {tab === 'recordings' && <RecordingsTab />}
      {tab === 'chain' && <ChainVerificationTab />}
    </div>
  )
}
