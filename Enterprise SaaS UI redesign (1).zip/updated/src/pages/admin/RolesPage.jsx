import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Plus, ChevronDown, ChevronRight, Trash2, Lock, ShieldCheck, Link2 } from 'lucide-react'
import {
  listRoles,
  getRole,
  attachPolicyToRole,
  detachPolicyFromRole,
  deleteRole,
  listPolicies,
} from '../../api/rbac'
import { PageHeader, Card, CardHeader, CardTitle } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { selectClass } from '../../components/common/FormFields'
import { Button } from '../../components/common/Button'
import { CreateRoleModal } from '../../components/admin/CreateRoleModal'
import { apiErrorMessage } from '../../lib/apiError'

function RoleRow({ role, isExpanded, onToggle, onDelete }) {
  const queryClient = useQueryClient()
  const [newPolicyId, setNewPolicyId] = useState('')

  const roleQuery = useQuery({
    queryKey: ['admin', 'roles', role.id],
    queryFn: ({ signal }) => getRole(role.id, signal),
    enabled: isExpanded,
  })

  const policiesQuery = useQuery({
    queryKey: ['admin', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
    enabled: isExpanded,
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'roles', role.id] })

  const attachMutation = useMutation({
    mutationFn: (policyId) => attachPolicyToRole(role.id, policyId),
    onSuccess: () => {
      toast.success('Policy attached')
      invalidate()
      setNewPolicyId('')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const detachMutation = useMutation({
    mutationFn: (policyId) => detachPolicyFromRole(role.id, policyId),
    onSuccess: () => {
      toast.success('Policy detached')
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <li>
      <div
        className={
          'group flex items-center justify-between gap-4 px-4 py-3.5 transition-colors ' +
          (isExpanded ? 'bg-surface-850' : 'hover:bg-surface-850')
        }
      >
        <button
          onClick={onToggle}
          aria-expanded={isExpanded}
          className="flex min-w-0 flex-1 items-center gap-3.5 text-left outline-none"
        >
          <span
            className={
              'flex h-9 w-9 flex-none items-center justify-center rounded-lg border transition-colors ' +
              (isExpanded
                ? 'border-blue-500/35 bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-300'
                : 'border-surface-700 bg-surface-850 text-ink-400 group-hover:border-surface-600')
            }
          >
            <Lock className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
          </span>
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold text-ink-100">{role.name}</span>
            <span className="mt-0.5 block truncate text-xs text-ink-500">
              {role.description || 'No description'}
            </span>
          </span>
        </button>
        <div className="flex flex-none items-center gap-1.5">
          <button
            onClick={(e) => {
              e.stopPropagation()
              onDelete(role)
            }}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-500 transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/30 dark:hover:text-red-300"
            aria-label={`Delete ${role.name}`}
          >
            <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
          </button>
          <button
            onClick={onToggle}
            aria-label={isExpanded ? `Collapse ${role.name}` : `Expand ${role.name}`}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-500 transition-colors hover:bg-surface-800 hover:text-ink-100"
          >
            {isExpanded ? (
              <ChevronDown className="h-4 w-4" strokeWidth={1.75} />
            ) : (
              <ChevronRight className="h-4 w-4" strokeWidth={1.75} />
            )}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="border-t border-surface-800 bg-surface-1000/60 px-4 py-4">
          <QueryState query={roleQuery} loadingLabel="Loading policies…">
            {(data) => {
              const policies = data.policies || []
              const attachedIds = new Set(policies.map((p) => p.id))
              const available = (policiesQuery.data || []).filter((p) => !attachedIds.has(p.id))

              return (
                <div className="space-y-4">
                  <div>
                    <p className="mb-2 text-2xs font-semibold uppercase tracking-[0.1em] text-ink-500">
                      Attached policies
                    </p>
                    {policies.length === 0 ? (
                      <p className="rounded-lg border border-dashed border-surface-700 px-3 py-3 text-xs text-ink-500">
                        No policies attached — this role grants nothing on its own.
                      </p>
                    ) : (
                      <ul className="flex flex-wrap gap-2">
                        {policies.map((p) => (
                          <li
                            key={p.id}
                            className="inline-flex items-center gap-2 rounded-lg border border-surface-700 bg-surface-900 py-1 pl-2.5 pr-1 shadow-card"
                          >
                            <ShieldCheck className="h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.5} />
                            <span className="text-xs font-medium text-ink-100">{p.name}</span>
                            <button
                              onClick={() => detachMutation.mutate(p.id)}
                              disabled={detachMutation.isPending}
                              aria-label={`Detach ${p.name}`}
                              className="rounded px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.05em] text-ink-500 transition-colors hover:bg-red-50 hover:text-red-600 disabled:opacity-40 dark:hover:bg-red-950/30 dark:hover:text-red-300"
                            >
                              Detach
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                  {available.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 border-t border-surface-800 pt-4">
                      <select
                        className={selectClass(false) + ' h-8 w-auto min-w-[12rem] py-0 text-xs'}
                        value={newPolicyId}
                        onChange={(e) => setNewPolicyId(e.target.value)}
                        aria-label="Policy to attach"
                      >
                        <option value="">Attach a policy…</option>
                        {available.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name}
                          </option>
                        ))}
                      </select>
                      <Button
                        size="sm"
                        variant="primary"
                        icon={Link2}
                        onClick={() => newPolicyId && attachMutation.mutate(newPolicyId)}
                        disabled={!newPolicyId}
                        loading={attachMutation.isPending}
                      >
                        Attach
                      </Button>
                    </div>
                  )}
                </div>
              )
            }}
          </QueryState>
        </div>
      )}
    </li>
  )
}

export default function RolesPage() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [expandedId, setExpandedId] = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)

  const rolesQuery = useQuery({
    queryKey: ['admin', 'roles'],
    queryFn: ({ signal }) => listRoles(signal),
  })

  const deleteMutation = useMutation({
    mutationFn: (roleId) => deleteRole(roleId),
    onSuccess: () => {
      toast.success('Role deleted')
      queryClient.invalidateQueries({ queryKey: ['admin', 'roles'] })
      setDeleteTarget(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDeleteTarget(null)
    },
  })

  return (
    <div>
      <PageHeader
        eyebrow="Admin Center"
        title="Roles"
        description="RBAC roles bundle policies into a single assignable unit. Expand a role to see and change what it grants."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create role
          </Button>
        }
      />

      <QueryState
        query={rolesQuery}
        empty={(roles) => !roles || roles.length === 0}
        emptyTitle="No roles defined"
        emptyMessage="Create a role to bundle policies and assign them to accounts."
        emptyAction={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create role
          </Button>
        }
      >
        {(roles) => (
          <Card>
            <CardHeader>
              <CardTitle icon={Lock}>All roles</CardTitle>
              <span className="ml-auto rounded bg-surface-800 px-1.5 py-0.5 text-2xs font-semibold tabular-nums text-ink-400 ring-1 ring-inset ring-surface-700">
                {roles.length}
              </span>
            </CardHeader>
            <ul className="divide-y divide-surface-800">
              {roles.map((role) => (
                <RoleRow
                  key={role.id}
                  role={role}
                  isExpanded={expandedId === role.id}
                  onToggle={() => setExpandedId(expandedId === role.id ? null : role.id)}
                  onDelete={setDeleteTarget}
                />
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreateRoleModal open={createOpen} onClose={() => setCreateOpen(false)} />

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete "${deleteTarget?.name}"?`}
        description="This removes the role. Users who had it assigned lose the policies it granted."
        confirmLabel="Delete"
        destructive
        isLoading={deleteMutation.isPending}
        onConfirm={() => deleteMutation.mutate(deleteTarget.id)}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  )
}
