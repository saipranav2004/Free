import { useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  Plus, ChevronRight, UserPlus, Users, UserCheck, UserX, ShieldAlert, SearchX,
  Download, Lock, Ban, Trash2, ShieldCheck,
} from 'lucide-react'
import clsx from 'clsx'
import { toast } from 'sonner'
import { listUsers } from '../../api/identity'
import { PageHeader, Card, EmptyState } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { KpiStrip } from '../../components/common/KpiStrip'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { Checkbox } from '../../components/common/Checkbox'
import { Pagination } from '../../components/common/Pagination'
import { BulkActionBar } from '../../components/common/BulkActionBar'
import {
  SearchField, SortHeader, ColumnChooser, DensityToggle, ExportMenu, RefreshControl, ActiveFilters,
} from '../../components/common/TableControls'
import { CreateUserModal } from '../../components/admin/CreateUserModal'
import { useTableState } from '../../hooks/useTableState'
import { exportRowsToCsv, exportRowsToJson } from '../../lib/exportRows'
import { formatDateTime } from '../../lib/format'
import { USER_STATUS_BADGE, SEARCH_DEBOUNCE_MS } from '../../config/constants'

// ---------------------------------------------------------------------------
// Identity — accounts table.
// ---------------------------------------------------------------------------
// The list becomes a real table: sortable columns, a column chooser, density,
// pagination, row selection and export. The API call is unchanged —
// listUsers(search) — and search stays SERVER-side and debounced, because that
// parameter genuinely exists. Everything the endpoint doesn't support (status
// facet, sort, paging) is applied client-side over the returned collection.
//
// No bulk mutation is wired up: /admin/identity exposes no batch route, so the
// destructive actions render disabled with the reason rather than fanning out
// N requests behind one innocuous-looking click.

const COLUMNS = [
  { key: 'username', label: 'User', required: true },
  { key: 'email', label: 'Email' },
  { key: 'full_name', label: 'Full name' },
  { key: 'roles', label: 'Roles' },
  { key: 'status', label: 'Status' },
  { key: 'created_at', label: 'Created' },
  { key: 'last_login_at', label: 'Last sign-in' },
]

const CSV_COLUMNS = [
  { key: 'username', label: 'Username' },
  { key: 'email', label: 'Email' },
  { key: 'full_name', label: 'Full name' },
  { key: 'status', label: 'Status' },
  { key: 'roles', label: 'Roles', value: (u) => (Array.isArray(u.roles) ? u.roles.join(' | ') : u.roles || '') },
  { key: 'created_at', label: 'Created' },
  { key: 'last_login_at', label: 'Last sign-in' },
  { key: 'user_id', label: 'User ID' },
]

const NO_BULK_ENDPOINT = 'Requires a backend batch endpoint — not available yet'

function initialsOf(name) {
  if (!name) return '—'
  const parts = String(name).replace(/[._-]+/g, ' ').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '—'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

function rolesOf(user) {
  if (Array.isArray(user.roles)) return user.roles
  if (typeof user.roles === 'string' && user.roles) return user.roles.split(',').map((r) => r.trim())
  return []
}

export default function IdentityListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [focusedId, setFocusedId] = useState(null)

  // Server-side search, debounced: the input responds immediately, the query
  // key only changes once typing settles.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })

  const users = usersQuery.data?.users || []

  const table = useTableState({
    rows: users,
    storageKey: 'identity',
    rowId: (u) => u.user_id,
    initialSort: { key: 'username', dir: 'asc' },
    initialPageSize: 25,
    initialFilters: { status: 'all' },
    filterFn: (u, f) => f.status === 'all' || (u.status || 'UNKNOWN') === f.status,
    sortAccessor: (u, key) => (key === 'roles' ? rolesOf(u).join(', ') : u[key]),
  })

  const statuses = useMemo(() => [...new Set(users.map((u) => u.status || 'UNKNOWN'))].sort(), [users])

  const counts = useMemo(
    () => ({
      total: users.length,
      active: users.filter((u) => u.status === 'ACTIVE').length,
      disabled: users.filter((u) => u.status === 'DISABLED' || u.status === 'INACTIVE').length,
      locked: users.filter((u) => u.status === 'LOCKED').length,
      privileged: users.filter((u) => rolesOf(u).some((r) => /admin|root/i.test(r))).length,
    }),
    [users]
  )

  useEffect(() => {
    const onKey = (e) => {
      const el = document.activeElement
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)) return
      if (e.metaKey || e.ctrlKey || e.altKey) return
      const rows = table.pageRows
      if (rows.length === 0) return
      const idx = rows.findIndex((r) => r.user_id === focusedId)
      if (e.key === 'j' || e.key === 'ArrowDown') {
        e.preventDefault()
        setFocusedId(rows[Math.min(idx + 1, rows.length - 1)]?.user_id ?? rows[0].user_id)
      } else if (e.key === 'k' || e.key === 'ArrowUp') {
        e.preventDefault()
        setFocusedId(rows[Math.max(idx - 1, 0)]?.user_id ?? rows[0].user_id)
      } else if (e.key === 'x' && idx >= 0) {
        e.preventDefault()
        table.toggleRow(rows[idx])
      } else if (e.key === 'Escape') {
        setFocusedId(null)
        table.clearSelection()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [focusedId, table])

  const show = (key) => !table.visibleColumns || table.visibleColumns.includes(key)
  const pad = table.density === 'compact' ? 'py-1.5' : 'py-3'

  const chips = []
  if (search) chips.push({ key: 'q', label: 'Search', value: search, onClear: () => setSearchInput('') })
  if (table.filters.status !== 'all') {
    chips.push({ key: 'status', label: 'Status', value: table.filters.status, onClear: () => table.setFilter('status', 'all') })
  }

  const bulkActions = [
    {
      key: 'export',
      label: 'Export',
      icon: Download,
      onClick: () => {
        exportRowsToCsv(table.selectedRows, CSV_COLUMNS, 'identity-selection')
        toast.success(`Exported ${table.selectedCount} accounts`)
      },
    },
    { key: 'disable', label: 'Disable', icon: Ban, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'unlock', label: 'Unlock', icon: Lock, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'delete', label: 'Delete', icon: Trash2, variant: 'dangerGhost', disabled: true, disabledReason: NO_BULK_ENDPOINT },
  ]

  return (
    <div className="pb-24">
      <PageHeader
        eyebrow="Admin Center"
        title="Identity"
        description="User accounts in this PAM install — create, disable, lock, or delete, and manage RBAC role and policy assignment."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create user
          </Button>
        }
      />

      <KpiStrip
        className="mb-5"
        loading={usersQuery.isLoading}
        items={[
          { key: 'total', label: 'Total accounts', value: counts.total, icon: Users, description: 'Provisioned in this install' },
          { key: 'active', label: 'Active', value: counts.active, icon: UserCheck, tone: 'emerald', description: 'Able to authenticate' },
          {
            key: 'locked',
            label: 'Locked',
            value: counts.locked,
            icon: ShieldAlert,
            tone: counts.locked > 0 ? 'amber' : 'default',
            description: 'Locked out after failed attempts',
          },
          { key: 'disabled', label: 'Disabled', value: counts.disabled, icon: UserX, description: 'Retained but denied access' },
          {
            key: 'privileged',
            label: 'Privileged',
            value: counts.privileged,
            icon: ShieldCheck,
            tone: 'red',
            description: 'Hold an admin or root role',
          },
        ]}
      />

      <div className="mb-4 space-y-3 rounded-xl border border-surface-700/70 bg-surface-900 px-3 py-3 shadow-card">
        <div className="flex flex-wrap items-center gap-2">
          <SearchField
            value={searchInput}
            onChange={setSearchInput}
            placeholder="Search username or email…"
            className="min-w-[15rem] sm:max-w-sm"
          />

          <label className="flex items-center gap-2">
            <span className="whitespace-nowrap text-xs font-medium text-ink-400">Status</span>
            <select
              value={table.filters.status}
              onChange={(e) => table.setFilter('status', e.target.value)}
              className="h-9 cursor-pointer rounded-lg border border-surface-700 bg-surface-900 pl-2.5 pr-7 text-xs font-medium text-ink-100 shadow-sm transition-colors hover:border-surface-600 focus:border-blue-500 focus:outline-none"
            >
              <option value="all">Any</option>
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </label>

          <span className="ml-auto flex flex-wrap items-center gap-2">
            <ColumnChooser columns={COLUMNS} visible={table.visibleColumns} onChange={table.setVisibleColumns} />
            <DensityToggle value={table.density} onChange={table.setDensity} />
            <ExportMenu
              count={table.total}
              disabled={table.total === 0}
              onExportCsv={() => exportRowsToCsv(table.filteredRows, CSV_COLUMNS, 'identity')}
              onExportJson={() => exportRowsToJson(table.filteredRows, CSV_COLUMNS, 'identity')}
            />
            <RefreshControl
              onRefresh={() => usersQuery.refetch()}
              isFetching={usersQuery.isFetching}
              updatedAt={usersQuery.dataUpdatedAt}
            />
          </span>
        </div>

        {chips.length > 0 && (
          <div className="border-t border-surface-800 pt-3">
            <ActiveFilters
              chips={chips}
              onClearAll={() => {
                setSearchInput('')
                table.resetFilters()
              }}
            />
          </div>
        )}
      </div>

      <QueryState
        query={usersQuery}
        empty={(data) => !data?.users || data.users.length === 0}
        emptyTitle={search ? 'No matching accounts' : 'No user accounts yet'}
        emptyMessage={
          search
            ? 'No account matches that username or email. Try a broader term.'
            : 'Create the first account to start assigning roles and policies.'
        }
        emptyAction={
          !search && (
            <Button variant="primary" icon={UserPlus} onClick={() => setCreateOpen(true)}>
              Create user
            </Button>
          )
        }
      >
        {() =>
          table.total === 0 ? (
            <Card>
              <EmptyState
                icon={SearchX}
                title="No accounts match this filter"
                description="Every returned account was filtered out by the current status selection."
                action={
                  <Button variant="secondary" onClick={() => table.resetFilters()}>
                    Clear filters
                  </Button>
                }
              />
            </Card>
          ) : (
            <Card className="overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[52rem] border-separate border-spacing-0 text-sm">
                  <thead>
                    <tr>
                      <th scope="col" className="sticky left-0 top-0 z-20 w-10 border-b border-surface-800 bg-surface-850 px-4 py-2.5">
                        <Checkbox
                          checked={table.allOnPageSelected}
                          indeterminate={table.someOnPageSelected}
                          onChange={table.toggleAllOnPage}
                          srLabel="Select all accounts on this page"
                        />
                      </th>
                      {show('username') && (
                        <SortHeader label="User" columnKey="username" sort={table.sort} onSort={table.toggleSort} className="sticky left-10 z-20 min-w-[13rem]" />
                      )}
                      {show('email') && <SortHeader label="Email" columnKey="email" sort={table.sort} onSort={table.toggleSort} />}
                      {show('full_name') && <SortHeader label="Full name" columnKey="full_name" sort={table.sort} onSort={table.toggleSort} />}
                      {show('roles') && <SortHeader label="Roles" columnKey="roles" sort={table.sort} onSort={table.toggleSort} />}
                      {show('status') && <SortHeader label="Status" columnKey="status" sort={table.sort} onSort={table.toggleSort} />}
                      {show('created_at') && <SortHeader label="Created" columnKey="created_at" sort={table.sort} onSort={table.toggleSort} />}
                      {show('last_login_at') && <SortHeader label="Last sign-in" columnKey="last_login_at" sort={table.sort} onSort={table.toggleSort} />}
                      <SortHeader label="Open" columnKey="_open" srOnly className="w-12" />
                    </tr>
                  </thead>
                  <tbody>
                    {table.pageRows.map((u) => {
                      const selected = table.isSelected(u)
                      const roles = rolesOf(u)
                      return (
                        <tr
                          key={u.user_id}
                          className={clsx(
                            'group transition-colors',
                            selected ? 'bg-blue-50/70 dark:bg-blue-500/[0.07]' : 'hover:bg-surface-850',
                            focusedId === u.user_id && 'ring-1 ring-inset ring-blue-500/40'
                          )}
                        >
                          <td className={clsx('sticky left-0 z-10 border-b border-surface-800 bg-inherit px-4', pad)}>
                            <Checkbox checked={selected} onChange={() => table.toggleRow(u)} srLabel={`Select ${u.username}`} />
                          </td>
                          {show('username') && (
                            <td className={clsx('sticky left-10 z-10 border-b border-surface-800 bg-inherit px-4', pad)}>
                              <div className="flex min-w-0 items-center gap-3">
                                <span
                                  aria-hidden="true"
                                  className="flex h-8 w-8 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-2xs font-semibold uppercase text-ink-400"
                                >
                                  {initialsOf(u.username)}
                                </span>
                                <Link
                                  to={`/admin/identity/${u.user_id}`}
                                  className="min-w-0 truncate font-medium text-ink-50 transition-colors hover:text-blue-600 dark:hover:text-blue-300"
                                >
                                  {u.username}
                                </Link>
                              </div>
                            </td>
                          )}
                          {show('email') && (
                            <td className={clsx('border-b border-surface-800 px-4 text-ink-300', pad)}>{u.email || '—'}</td>
                          )}
                          {show('full_name') && (
                            <td className={clsx('border-b border-surface-800 px-4 text-ink-400', pad)}>{u.full_name || '—'}</td>
                          )}
                          {show('roles') && (
                            <td className={clsx('border-b border-surface-800 px-4', pad)}>
                              {roles.length === 0 ? (
                                <span className="text-xs text-ink-500">None</span>
                              ) : (
                                <span className="flex flex-wrap gap-1">
                                  {roles.slice(0, 2).map((r) => (
                                    <Badge key={r} className="bg-surface-800 text-ink-300 ring-surface-700">
                                      {r}
                                    </Badge>
                                  ))}
                                  {roles.length > 2 && (
                                    <span className="text-2xs font-medium text-ink-500">+{roles.length - 2}</span>
                                  )}
                                </span>
                              )}
                            </td>
                          )}
                          {show('status') && (
                            <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4', pad)}>
                              <Badge className={USER_STATUS_BADGE[u.status] || undefined}>{u.status || 'UNKNOWN'}</Badge>
                            </td>
                          )}
                          {show('created_at') && (
                            <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-xs tabular-nums text-ink-400', pad)}>
                              {u.created_at ? formatDateTime(u.created_at) : '—'}
                            </td>
                          )}
                          {show('last_login_at') && (
                            <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-xs tabular-nums text-ink-400', pad)}>
                              {u.last_login_at ? formatDateTime(u.last_login_at) : 'Never'}
                            </td>
                          )}
                          <td className={clsx('border-b border-surface-800 px-2', pad)}>
                            <Link
                              to={`/admin/identity/${u.user_id}`}
                              aria-label={`Open ${u.username}`}
                              className="flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-colors hover:bg-surface-800 hover:text-ink-100"
                            >
                              <ChevronRight className="h-4 w-4" strokeWidth={2} />
                            </Link>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              <Pagination
                page={table.page}
                pageSize={table.pageSize}
                total={table.total}
                totalPages={table.totalPages}
                onPageChange={table.setPage}
                onPageSizeChange={table.setPageSize}
                label="accounts"
              />
            </Card>
          )
        }
      </QueryState>

      <BulkActionBar
        count={table.selectedCount}
        total={table.total}
        noun="account"
        actions={bulkActions}
        allMatchingSelected={table.allMatchingSelected}
        onSelectAllMatching={table.selectAllMatching}
        onClear={table.clearSelection}
      />

      <CreateUserModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
