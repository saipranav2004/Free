import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight, Search, UserPlus } from 'lucide-react'
import { listUsers } from '../../api/identity'
import { PageHeader, Card, Toolbar } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { CreateUserModal } from '../../components/admin/CreateUserModal'
import { USER_STATUS_BADGE, SEARCH_DEBOUNCE_MS } from '../../config/constants'

function initialsOf(name) {
  if (!name) return '—'
  const parts = String(name).replace(/[._-]+/g, ' ').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '—'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export default function IdentityListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')

  // Debounce the free-text search so it doesn't fire a request per keystroke —
  // the input updates immediately for responsiveness, the query key only
  // picks up `search` after SEARCH_DEBOUNCE_MS of no further typing.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })

  return (
    <div>
      <PageHeader
        eyebrow="Admin Center"
        title="Identity"
        description="User accounts in this PAM install — create, disable, lock, or delete, and manage RBAC role and policy assignment."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create user
          </Button>
        }
      />

      <Toolbar>
        <div className="relative min-w-0 flex-1 sm:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500" strokeWidth={1.75} />
          <input
            className="h-9 w-full rounded-lg border border-surface-700 bg-surface-800 pl-9 pr-3 text-sm text-ink-50 shadow-sm transition-[border-color,box-shadow] duration-150 placeholder:text-ink-500 hover:border-surface-600 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
            placeholder="Search username or email…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            aria-label="Search users"
          />
        </div>
      </Toolbar>

      <QueryState
        query={usersQuery}
        empty={(data) => !data?.users || data.users.length === 0}
        emptyTitle={search ? 'No matching accounts' : 'No user accounts yet'}
        emptyMessage={
          search
            ? 'No account matches that username or email. Try a broader term.'
            : 'Create the first account to start assigning roles and policies.'
        }
        emptyAction={
          !search && (
            <Button variant="primary" icon={UserPlus} onClick={() => setCreateOpen(true)}>
              Create user
            </Button>
          )
        }
      >
        {(data) => (
          <Card>
            <ul className="divide-y divide-surface-800">
              {data.users.map((u) => (
                <li key={u.user_id}>
                  <Link
                    to={`/admin/identity/${u.user_id}`}
                    className="group flex items-center justify-between gap-4 px-4 py-3.5 transition-colors hover:bg-surface-850"
                  >
                    <div className="flex min-w-0 items-center gap-3.5">
                      <span
                        aria-hidden="true"
                        className="flex h-9 w-9 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-xs font-semibold uppercase text-ink-400"
                      >
                        {initialsOf(u.username)}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-ink-100">{u.username}</p>
                        <p className="mt-0.5 truncate text-xs text-ink-500">
                          {u.email}
                          {u.full_name ? ` · ${u.full_name}` : ''}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-none items-center gap-2.5">
                      <Badge className={USER_STATUS_BADGE[u.status] || undefined}>{u.status || 'UNKNOWN'}</Badge>
                      <ChevronRight
                        className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                        strokeWidth={1.75}
                      />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreateUserModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
