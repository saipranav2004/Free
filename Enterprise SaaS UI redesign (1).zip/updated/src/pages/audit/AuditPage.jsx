import { useEffect, useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  ChevronLeft, ChevronRight, ShieldCheck, ShieldAlert, Download, FileSearch, Search, Link2,
  ScrollText, XCircle,
} from 'lucide-react'
import { searchAudit, generateComplianceReport } from '../../api/audit'
import { verifyAudit } from '../../api/admin'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, CardHeader, CardTitle, Toolbar } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { KpiStrip } from '../../components/common/KpiStrip'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { SegmentedControl } from '../../components/common/SegmentedControl'
import { inputClass, selectClass } from '../../components/common/FormFields'
import { AuditEventDetailModal } from '../../components/audit/AuditEventDetailModal'
import {
  formatDateTime,
  dateInputToRFC3339,
  todayDateInputValue,
  daysAgoDateInputValue,
} from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  AUDIT_CATEGORIES,
  AUDIT_OUTCOMES,
  AUDIT_OUTCOME_BADGE,
  AUDIT_SEVERITY_BADGE,
  SEARCH_DEBOUNCE_MS,
} from '../../config/constants'

const PAGE_LIMIT = 20

// Defensive readers — the exact field names an audit item carries for
// "when did this happen" / "who did it" / "what did it touch" aren't pinned
// down anywhere we've been given, so try the plausible candidates and fall
// back to a placeholder rather than crashing on `undefined.foo`.
function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}
function actorLabel(item) {
  return (
    item?.actor_username ||
    item?.username ||
    item?.actor?.username ||
    item?.user_email ||
    item?.actor_id ||
    item?.user_id ||
    '—'
  )
}
function targetLabel(item) {
  return (
    item?.resource_name ||
    item?.resource ||
    item?.target ||
    item?.resource_id ||
    '—'
  )
}

// One audit entry. The action string is the identity of the row and gets
// monospace treatment; the category is a quiet prefix chip; actor and target
// are labelled metadata rather than a run-on sentence.
function AuditRow({ item, onSelect }) {
  const ts = itemTimestamp(item)
  return (
    <li>
      <button
        type="button"
        onClick={() => onSelect(item)}
        className="group flex w-full flex-col gap-2 px-4 py-3.5 text-left transition-colors hover:bg-surface-850 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded border border-surface-700 bg-surface-850 px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.06em] text-ink-500">
              {item?.category || 'OTHER'}
            </span>
            <span className="truncate font-mono text-xs font-medium text-ink-100">{item?.action || '—'}</span>
            {item?.outcome && (
              <Badge className={AUDIT_OUTCOME_BADGE[item.outcome] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                {item.outcome}
              </Badge>
            )}
            {item?.severity && (
              <Badge className={AUDIT_SEVERITY_BADGE[item.severity] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                {item.severity}
              </Badge>
            )}
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-500">
            <span className="tabular-nums">{formatDateTime(ts)}</span>
            <span className="truncate">
              <span className="text-ink-600">actor</span> {actorLabel(item)}
            </span>
            <span className="truncate">
              <span className="text-ink-600">target</span> {targetLabel(item)}
            </span>
          </div>
        </div>
        <ChevronRight
          className="hidden h-4 w-4 flex-none text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5 sm:block"
          strokeWidth={1.5}
        />
      </button>
    </li>
  )
}

export default function AuditPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [offset, setOffset] = useState(0)
  const [reportOpen, setReportOpen] = useState(false)
  const [reportFormat, setReportFormat] = useState('pdf')
  // Default to the last 30 days — the backend requires a from/to range on
  // every report request (see api/audit.js's generateComplianceReport doc
  // comment), so this needs a real default rather than forcing the user to
  // pick dates just to generate a report at all.
  const [reportFrom, setReportFrom] = useState(() => daysAgoDateInputValue(30))
  const [reportTo, setReportTo] = useState(() => todayDateInputValue())
  const [selectedEvent, setSelectedEvent] = useState(null)

  // Debounce the free-text search so it doesn't fire a request per keystroke —
  // the input updates immediately for responsiveness, the query key only
  // picks up `search` after SEARCH_DEBOUNCE_MS of no further typing.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  // Any filter change invalidates the current offset — otherwise "offset 60"
  // can persist into a filtered result set with only 10 total items.
  useEffect(() => {
    setOffset(0)
  }, [search, category, outcome])

  // AuditHandler.Search (audit_handler.go) exposes two very different
  // params: `action` is an EXACT match against the stored action string
  // ("pam:resource:Connect", "pam:vault:Reveal", ...), while `q` runs a
  // full-text search (Postgres tsvector + plainto_tsquery, see
  // audit_query_service.go) across the row's searchable fields. This search
  // box was wired to `action`, so typing anything other than one exact,
  // correctly-formatted action string returned zero rows regardless of
  // what was typed — which is why "search doesn't work" even though the
  // backend search endpoint itself was fine. Free text belongs on `q`.
  const filters = {
    q: search || undefined,
    category: category || undefined,
    outcome: outcome || undefined,
  }

  const auditQuery = useQuery({
    queryKey: ['audit', 'search', { search, category, outcome, offset }],
    queryFn: ({ signal }) => searchAudit({ ...filters, limit: PAGE_LIMIT, offset }, signal),
    placeholderData: (prev) => prev,
  })

  // Chain verification is inherently org-wide (it walks the whole hash
  // chain, not a per-account slice), and the backend only ever exposes it
  // under the admin-gated /admin/audit/verify route — there is no
  // self-service equivalent (see api/audit.js's comment where the old,
  // always-404ing self-service call used to live). Reusing api/admin.js's
  // verifyAudit() here rather than duplicating the request.
  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const reportMutation = useMutation({
    mutationFn: () => {
      const fromTime = dateInputToRFC3339(reportFrom, false)
      const toTime = dateInputToRFC3339(reportTo, true)
      if (!fromTime || !toTime) {
        throw new Error('Pick a start and end date for the report range.')
      }
      if (new Date(fromTime) > new Date(toTime)) {
        throw new Error('The start date must be before the end date.')
      }
      return generateComplianceReport({ ...filters, fromTime, toTime, format: reportFormat })
    },
    onSuccess: (result) => {
      toast.success(result?.filename ? `Report downloaded: ${result.filename}` : 'Report downloaded')
    },
    onError: (err) => {
      // Client-side validation above throws a plain Error, not an axios
      // error — apiErrorMessage would just fall through to a generic
      // "Something went wrong" for that shape, so show err.message directly
      // when there's no HTTP response to normalize.
      toast.error(err?.response ? apiErrorMessage(err) : err.message || apiErrorMessage(err))
    },
  })

  const total = auditQuery.data?.total ?? 0
  const limit = auditQuery.data?.limit ?? PAGE_LIMIT
  const items = auditQuery.data?.items
  const canPrev = offset > 0
  const canNext = offset + limit < total
  const rangeStart = total === 0 ? 0 : offset + 1
  const rangeEnd = Math.min(offset + limit, total)

  const verifyResult = verifyMutation.data
  // The field naming inside the verification payload isn't pinned down
  // anywhere we have access to — probe the plausible boolean fields and
  // otherwise fall back to showing the raw JSON rather than silently
  // dropping the signal.
  const verifyKnownField =
    verifyResult && (
      'valid' in verifyResult ? 'valid'
      : 'chain_valid' in verifyResult ? 'chain_valid'
      : 'success' in verifyResult ? 'success'
      : null
    )
  const verifyIsValid = verifyKnownField ? Boolean(verifyResult[verifyKnownField]) : null

  const filterSelect = selectClass(false) + ' h-9 w-auto min-w-[9.5rem] py-0 text-xs'

  // `total` is the server's count for the whole filtered query; the outcome
  // split can only be computed from the page in hand, so it's labelled that
  // way rather than implying it covers all results.
  const pageItems = items || []
  const deniedOnPage = pageItems.filter((e) => {
    const o = String(e.outcome || '').toUpperCase()
    return o.includes('DENIED') || o.includes('FAIL')
  }).length

  return (
    <div>
      <PageHeader
        eyebrow="Compliance"
        title="Audit"
        description="Your own audit trail — actions performed by, or affecting, your account. Every entry is written to a tamper-evident hash chain."
      />

      <KpiStrip
        className="mb-5"
        loading={auditQuery.isLoading}
        items={[
          {
            key: 'total',
            label: 'Events matched',
            value: total,
            icon: ScrollText,
            description: 'Across the current filters',
          },
          {
            key: 'page',
            label: 'Shown here',
            value: pageItems.length,
            icon: FileSearch,
            description: total ? `Range ${rangeStart}–${rangeEnd}` : 'Nothing on this page',
          },
          {
            key: 'denied',
            label: 'Denied or failed',
            value: deniedOnPage,
            icon: XCircle,
            tone: deniedOnPage > 0 ? 'red' : 'default',
            description: 'On this page',
          },
          {
            key: 'chain',
            label: 'Chain integrity',
            value: verifyMutation.isSuccess ? (verifyIsValid === true ? 'Intact' : verifyIsValid === false ? 'Broken' : 'Unclear') : 'Not checked',
            icon: verifyIsValid === false ? ShieldAlert : ShieldCheck,
            tone: verifyIsValid === false ? 'red' : verifyIsValid === true ? 'emerald' : 'default',
            description: isAdmin ? 'Verify below' : 'Administrator-run check',
          },
        ]}
      />

      {/* Chain integrity — admin-only. A verification result is a security
          finding, so it gets its own plate above the log rather than a toast. */}
      {isAdmin && (
        <Card className="mb-5 overflow-hidden">
          <CardHeader className="justify-between">
            <CardTitle icon={Link2}>Chain integrity — organization-wide</CardTitle>
            <Button
              size="sm"
              variant="secondary"
              icon={ShieldCheck}
              loading={verifyMutation.isPending}
              onClick={() => verifyMutation.mutate()}
            >
              Verify chain
            </Button>
          </CardHeader>

          {verifyMutation.isSuccess ? (
            <div
              className={
                'flex items-start gap-3 px-4 py-3.5 ' +
                (verifyIsValid === false
                  ? 'bg-red-50 dark:bg-red-950/30'
                  : verifyIsValid === true
                    ? 'bg-emerald-50 dark:bg-emerald-950/20'
                    : '')
              }
            >
              {verifyIsValid === false && (
                <ShieldAlert className="mt-0.5 h-5 w-5 flex-none text-red-600 dark:text-red-400" strokeWidth={1.75} />
              )}
              {verifyIsValid === true && (
                <ShieldCheck className="mt-0.5 h-5 w-5 flex-none text-emerald-600 dark:text-emerald-400" strokeWidth={1.75} />
              )}
              <div className="min-w-0">
                {verifyIsValid === true && (
                  <p className="text-sm font-semibold text-emerald-800 dark:text-emerald-300">
                    Audit chain intact — no tampering detected.
                  </p>
                )}
                {verifyIsValid === false && (
                  <p className="text-sm font-semibold text-red-800 dark:text-red-300">
                    Audit chain broken — possible tampering detected. Notify a security administrator.
                  </p>
                )}
                {verifyIsValid === null && (
                  <>
                    <p className="mb-1 text-sm font-semibold text-ink-100">Verification result</p>
                    <pre className="max-w-full overflow-x-auto rounded-lg border border-surface-700 bg-surface-850 p-2.5 font-mono text-xs text-ink-400">
                      {JSON.stringify(verifyResult, null, 2)}
                    </pre>
                  </>
                )}
              </div>
            </div>
          ) : (
            <p className="px-4 py-3 text-xs leading-relaxed text-ink-500">
              Checks that every recorded audit entry in this PAM install forms an unbroken, tamper-evident
              chain. This is not run automatically — trigger it explicitly.
            </p>
          )}
        </Card>
      )}

      <Toolbar>
        <div className="relative min-w-0 flex-1 sm:max-w-xs">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500"
            strokeWidth={1.5}
          />
          <input
            className={inputClass(false) + ' h-9 py-0 pl-9 text-sm'}
            placeholder="Search the trail…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            aria-label="Search audit entries"
          />
        </div>
        <select
          className={filterSelect}
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          aria-label="Filter by category"
        >
          <option value="">All categories</option>
          {AUDIT_CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <select
          className={filterSelect}
          value={outcome}
          onChange={(e) => setOutcome(e.target.value)}
          aria-label="Filter by outcome"
        >
          <option value="">All outcomes</option>
          {AUDIT_OUTCOMES.map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
        <span className="ml-auto" />
        <Button
          size="sm"
          variant={reportOpen ? 'subtle' : 'secondary'}
          icon={FileSearch}
          onClick={() => setReportOpen((v) => !v)}
          aria-expanded={reportOpen}
        >
          Generate report
        </Button>
      </Toolbar>

      {/* Report builder — a disclosed panel rather than a modal, because it
          inherits the filters visible directly above it. */}
      {reportOpen && (
        <Card className="mb-5 overflow-hidden">
          <CardHeader>
            <CardTitle icon={Download}>Compliance report</CardTitle>
          </CardHeader>
          <div className="flex flex-wrap items-end gap-4 px-4 py-4">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="report-from" className="text-xs font-medium text-ink-300">
                From
              </label>
              <input
                id="report-from"
                type="date"
                value={reportFrom}
                max={reportTo}
                onChange={(e) => setReportFrom(e.target.value)}
                className={inputClass(false) + ' h-9 w-auto py-0 text-sm'}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label htmlFor="report-to" className="text-xs font-medium text-ink-300">
                To
              </label>
              <input
                id="report-to"
                type="date"
                value={reportTo}
                min={reportFrom}
                max={todayDateInputValue()}
                onChange={(e) => setReportTo(e.target.value)}
                className={inputClass(false) + ' h-9 w-auto py-0 text-sm'}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-ink-300">Format</span>
              <SegmentedControl
                options={[
                  { key: 'pdf', label: 'PDF' },
                  { key: 'csv', label: 'CSV' },
                ]}
                value={reportFormat}
                onChange={setReportFormat}
                ariaLabel="Report format"
              />
            </div>
            <Button
              variant="primary"
              icon={Download}
              loading={reportMutation.isPending}
              onClick={() => reportMutation.mutate()}
            >
              Download
            </Button>
          </div>
          <p className="border-t border-surface-800 bg-surface-850/50 px-4 py-2.5 text-xs text-ink-500">
            The report is also scoped to the search, category and outcome filters set above.
          </p>
        </Card>
      )}

      <Card>
        <QueryState
          query={auditQuery}
          empty={(d) => !d?.items || d.items.length === 0}
          emptyTitle="No audit entries"
          emptyMessage="Nothing matches these filters. Widen the search, or clear the category and outcome."
          skeletonRows={8}
        >
          {() => (
            <>
              <ul className="divide-y divide-surface-800">
                {items.map((item, idx) => (
                  <AuditRow key={item?.id ?? item?.sequence ?? idx} item={item} onSelect={setSelectedEvent} />
                ))}
              </ul>
              {/* Offset/limit pagination — this endpoint returns
                  {items,total,limit,offset}, not the {page,total_pages}
                  shape the shared Pagination component expects, so the
                  control is local by necessity. Styling matches it. */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-surface-800 bg-surface-850/50 px-4 py-2.5 text-xs text-ink-400">
                <span className="tabular-nums">
                  Showing <span className="font-semibold text-ink-100">{rangeStart}</span>–
                  <span className="font-semibold text-ink-100">{rangeEnd}</span> of{' '}
                  <span className="font-semibold text-ink-100">{total}</span>
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="xs"
                    variant="secondary"
                    icon={ChevronLeft}
                    disabled={!canPrev}
                    onClick={() => canPrev && setOffset((o) => Math.max(0, o - limit))}
                    aria-label="Previous page"
                  >
                    Prev
                  </Button>
                  <Button
                    size="xs"
                    variant="secondary"
                    iconRight={ChevronRight}
                    disabled={!canNext}
                    onClick={() => canNext && setOffset((o) => o + limit)}
                    aria-label="Next page"
                  >
                    Next
                  </Button>
                </div>
              </div>
            </>
          )}
        </QueryState>
      </Card>

      <AuditEventDetailModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />
    </div>
  )
}
