import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight, Boxes, ServerOff } from 'lucide-react'
import { listResourceGroups } from '../../api/resources'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, EmptyState } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { ResourceTypeIcon } from '../../components/resources/ResourceTypeIcon'
import { CreateResourceModal } from '../../components/resources/CreateResourceModal'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'

export default function ResourcesPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const groupsQuery = useQuery({
    queryKey: ['resources', 'groups'],
    queryFn: ({ signal }) => listResourceGroups(signal),
  })

  return (
    <div>
      <PageHeader
        eyebrow="Access"
        title="Resources"
        description="Systems PAM can manage or broker access to, grouped by platform."
        actions={
          isAdmin && (
            <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
              Register resource
            </Button>
          )
        }
      />

      <QueryState
        query={groupsQuery}
        empty={(groups) => !groups || groups.length === 0}
        emptyTitle="No resources registered"
        emptyMessage="Once a system is registered, it appears here with its connection details and access requirements."
      >
        {(groups) => (
          <div className="space-y-8">
            {groups.map((group) => (
              <section key={group.name}>
                {/* Group header — a typographic rule, not a coloured banner:
                    the group label is chrome, the resources are the content. */}
                <div className="mb-3 flex items-center gap-3">
                  <span className="flex h-7 w-7 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-ink-400">
                    <Boxes className="h-3.5 w-3.5" strokeWidth={1.75} />
                  </span>
                  <h2 className="text-xs font-semibold uppercase tracking-[0.09em] text-ink-300">{group.name}</h2>
                  <span className="rounded bg-surface-800 px-1.5 py-0.5 text-2xs font-semibold tabular-nums text-ink-400 ring-1 ring-inset ring-surface-700">
                    {group.resources?.length || 0}
                  </span>
                  <span className="h-px flex-1 bg-surface-800" aria-hidden="true" />
                </div>

                <Card>
                  {(group.resources || []).length === 0 ? (
                    <EmptyState
                      icon={ServerOff}
                      title="No systems in this group"
                      description="Register a resource to make it available for brokered access."
                      className="py-10"
                    />
                  ) : (
                    <ul className="divide-y divide-surface-800">
                      {(group.resources || []).map((r) => (
                        <li key={r.id}>
                          <Link
                            to={`/resources/${r.id}`}
                            className="group flex items-center justify-between gap-4 px-4 py-3.5 transition-colors hover:bg-surface-850"
                          >
                            <div className="flex min-w-0 items-center gap-3.5">
                              <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 transition-colors group-hover:border-surface-600">
                                <ResourceTypeIcon type={r.resource_type} className="h-[1.05rem] w-[1.05rem]" />
                              </span>
                              <div className="min-w-0">
                                <p className="truncate text-sm font-semibold text-ink-100">{r.name}</p>
                                <p className="mt-0.5 truncate font-mono text-xs text-ink-500">
                                  {r.host}:{r.port}
                                  {r.database_name ? ` · ${r.database_name}` : ''}
                                </p>
                              </div>
                            </div>
                            <div className="flex flex-none items-center gap-2">
                              {r.requires_jit && (
                                <Badge className="bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30">
                                  JIT-gated
                                </Badge>
                              )}
                              {!r.is_active && (
                                <Badge className="bg-ink-500/10 text-ink-400 ring-ink-500/25">Inactive</Badge>
                              )}
                              <ChevronRight
                                className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                                strokeWidth={1.75}
                              />
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </Card>
              </section>
            ))}
          </div>
        )}
      </QueryState>

      {isAdmin && <CreateResourceModal open={createOpen} onClose={() => setCreateOpen(false)} />}
    </div>
  )
}
