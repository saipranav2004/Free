import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { toast } from 'sonner'
import { Plus, ShieldAlert, ArrowRight, Info, KeyRound, Lock, ChevronRight } from 'lucide-react'
import { listMyJitRequests, listMyGrants, cancelJitRequest } from '../../api/jit'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, Toolbar, ListRow } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { SegmentedControl } from '../../components/common/SegmentedControl'
import { selectClass } from '../../components/common/FormFields'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { CreateJitRequestModal } from '../../components/jit/CreateJitRequestModal'
import { formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  JIT_STATUS,
  JIT_STATUS_LABELS,
  JIT_STATUS_BADGE,
  GRANT_STATUS,
  GRANT_STATUS_BADGE,
  DEFAULT_PAGE_SIZE,
} from '../../config/constants'

const TABS = [
  { key: 'requests', label: 'My Requests' },
  { key: 'grants', label: 'My Grants' },
]

// Requests in these two states are the only ones a self-service user can
// still back out of — anything already APPROVED/DENIED/CANCELLED/EXPIRED
// is a done deal (the backend's own cancel endpoint would 409 on those).
const CANCELLABLE_STATUSES = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

const filterSelectClass = selectClass(false) + ' h-8 w-auto min-w-[10rem] py-0 text-xs'

export default function JitPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [tab, setTab] = useState('requests')
  const [requestStatus, setRequestStatus] = useState('')
  const [grantStatus, setGrantStatus] = useState('')
  const [page, setPage] = useState(1)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalBreakglass, setModalBreakglass] = useState(false)
  const [cancelTarget, setCancelTarget] = useState(null)
  const queryClient = useQueryClient()

  // Reset to page 1 whenever the tab or its filter changes — otherwise a
  // stale page number from one filter/tab combination can carry over into a
  // result set that doesn't have that many pages.
  const changeTab = (next) => {
    setTab(next)
    setPage(1)
  }
  const changeRequestStatus = (next) => {
    setRequestStatus(next)
    setPage(1)
  }
  const changeGrantStatus = (next) => {
    setGrantStatus(next)
    setPage(1)
  }

  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', { page, status: requestStatus }],
    queryFn: ({ signal }) =>
      listMyJitRequests({ page, pageSize: DEFAULT_PAGE_SIZE, status: requestStatus || undefined, signal }),
    enabled: tab === 'requests',
  })

  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', { page, status: grantStatus }],
    queryFn: ({ signal }) =>
      listMyGrants({ page, pageSize: DEFAULT_PAGE_SIZE, status: grantStatus || undefined, signal }),
    enabled: tab === 'grants',
  })

  const activeQuery = tab === 'requests' ? requestsQuery : grantsQuery

  const cancelMutation = useMutation({
    mutationFn: ({ id, reason }) => cancelJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request cancelled')
      setCancelTarget(null)
      queryClient.invalidateQueries({ queryKey: ['jit'] })
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setCancelTarget(null)
    },
  })

  const openNewRequest = () => {
    setModalBreakglass(false)
    setModalOpen(true)
  }
  const openBreakglass = () => {
    setModalBreakglass(true)
    setModalOpen(true)
  }

  const requests = requestsQuery.data?.requests
  const grants = grantsQuery.data?.grants
  const pagination = activeQuery.data?.pagination

  return (
    <div>
      <PageHeader
        eyebrow="Access"
        title="Just-in-Time Access"
        description="Request time-boxed access to JIT-gated resources and track the requests and grants you personally made."
        actions={
          <>
            <Button variant="dangerGhost" icon={ShieldAlert} onClick={openBreakglass}>
              Emergency access
            </Button>
            <Button variant="primary" icon={Plus} onClick={openNewRequest}>
              New request
            </Button>
          </>
        }
      />

      {isAdmin && (
        // Scope notice — this page is deliberately personal-scope even for
        // admins, and saying so inline prevents the "where are everyone
        // else's requests?" confusion.
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-blue-300/60 bg-blue-50/70 px-4 py-3 dark:border-blue-800/40 dark:bg-blue-950/20">
          <p className="flex items-start gap-2.5 text-sm leading-relaxed text-blue-800 dark:text-blue-200">
            <Info className="mt-0.5 h-4 w-4 flex-none" strokeWidth={1.75} />
            <span>
              This page shows only the requests and grants <strong className="font-semibold">you personally</strong>{' '}
              made. To review and approve requests from across the org, use JIT Approvals.
            </span>
          </p>
          <Link
            to="/admin/jit"
            className="group inline-flex flex-none items-center gap-1 text-sm font-semibold text-blue-700 transition-colors hover:text-blue-600 dark:text-blue-300 dark:hover:text-blue-200"
          >
            JIT Approvals
            <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" strokeWidth={2} />
          </Link>
        </div>
      )}

      <Toolbar>
        <SegmentedControl options={TABS} value={tab} onChange={changeTab} ariaLabel="JIT view" />
        <span className="ml-auto" />
        {tab === 'requests' ? (
          <select
            value={requestStatus}
            onChange={(e) => changeRequestStatus(e.target.value)}
            className={filterSelectClass}
            aria-label="Filter requests by status"
          >
            <option value="">All statuses</option>
            {Object.values(JIT_STATUS).map((s) => (
              <option key={s} value={s}>
                {JIT_STATUS_LABELS[s] || s}
              </option>
            ))}
          </select>
        ) : (
          <select
            value={grantStatus}
            onChange={(e) => changeGrantStatus(e.target.value)}
            className={filterSelectClass}
            aria-label="Filter grants by status"
          >
            <option value="">All statuses</option>
            {Object.values(GRANT_STATUS).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        )}
      </Toolbar>

      <Card>
        {tab === 'requests' ? (
          <QueryState
            query={requestsQuery}
            empty={(d) => !d?.requests || d.requests.length === 0}
            emptyTitle="No JIT requests"
            emptyMessage="Request time-boxed access to a JIT-gated resource and it will appear here with its approval status."
            emptyAction={
              <Button variant="primary" icon={Plus} onClick={openNewRequest}>
                New request
              </Button>
            }
          >
            {() => (
              <>
                <ul className="divide-y divide-surface-800">
                  {requests.map((r) => (
                    <li key={r.id} className="group">
                      <ListRow
                        icon={KeyRound}
                        title={
                          <Link to={`/jit/requests/${r.id}`} className="flex items-center gap-2 outline-none">
                            <span className="truncate">{r.resource_name || r.resource_id || '—'}</span>
                            {r.type === 'BREAKGLASS' && (
                              <span className="inline-flex flex-none items-center gap-1 rounded px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.04em] text-red-700 ring-1 ring-inset ring-red-600/25 dark:text-red-300 dark:ring-red-500/30">
                                <ShieldAlert className="h-3 w-3" strokeWidth={1.75} /> break-glass
                              </span>
                            )}
                          </Link>
                        }
                        subtitle={
                          <>
                            Requested {formatDateTime(r.created_at)}
                            {r.reason ? ` · ${r.reason}` : ''}
                          </>
                        }
                        trailing={
                          <>
                            <Badge className={JIT_STATUS_BADGE[r.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                              {JIT_STATUS_LABELS[r.status] || r.status}
                            </Badge>
                            {CANCELLABLE_STATUSES.includes(r.status) && (
                              <Button
                                size="xs"
                                variant="dangerGhost"
                                onClick={() => setCancelTarget(r)}
                                disabled={cancelMutation.isPending}
                              >
                                Cancel
                              </Button>
                            )}
                            <Link
                              to={`/jit/requests/${r.id}`}
                              aria-label="Open request"
                              className="flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-all duration-200 hover:bg-surface-800 hover:text-ink-100 group-hover:translate-x-0.5"
                            >
                              <ChevronRight className="h-4 w-4" strokeWidth={1.5} />
                            </Link>
                          </>
                        }
                        className="transition-colors hover:bg-surface-850"
                      />
                    </li>
                  ))}
                </ul>
                {pagination && (
                  <Pagination
                    page={pagination.page}
                    pageSize={pagination.page_size}
                    total={pagination.total}
                    totalPages={pagination.total_pages}
                    onPageChange={setPage}
                  />
                )}
              </>
            )}
          </QueryState>
        ) : (
          <QueryState
            query={grantsQuery}
            empty={(d) => !d?.grants || d.grants.length === 0}
            emptyTitle="No grants yet"
            emptyMessage="Approved requests become grants — time-boxed elevation you can use until it expires."
          >
            {() => (
              <>
                <ul className="divide-y divide-surface-800">
                  {grants.map((g) => (
                    <li key={g.id} className="group">
                      <Link to={g.resource_id ? `/resources/${g.resource_id}` : '#'} className="block outline-none">
                        <ListRow
                          icon={Lock}
                          title={g.resource_name || g.resource_id || '—'}
                          subtitle={
                            <>
                              Granted {formatDateTime(g.created_at)}
                              {g.expires_at ? ` · Expires ${formatDateTime(g.expires_at)}` : ''}
                            </>
                          }
                          trailing={
                            <>
                              <Badge className={GRANT_STATUS_BADGE[g.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                                {g.status}
                              </Badge>
                              <ChevronRight
                                className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                                strokeWidth={1.5}
                              />
                            </>
                          }
                          className="transition-colors hover:bg-surface-850"
                        />
                      </Link>
                    </li>
                  ))}
                </ul>
                {pagination && (
                  <Pagination
                    page={pagination.page}
                    pageSize={pagination.page_size}
                    total={pagination.total}
                    totalPages={pagination.total_pages}
                    onPageChange={setPage}
                  />
                )}
              </>
            )}
          </QueryState>
        )}
      </Card>

      <CreateJitRequestModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        defaultBreakglass={modalBreakglass}
      />

      <ConfirmDialog
        open={!!cancelTarget}
        title={`Cancel request for "${cancelTarget?.resource_name || cancelTarget?.resource_id || 'this resource'}"?`}
        description="This withdraws the request. You can submit a new one later if you still need access."
        confirmLabel="Cancel request"
        destructive
        requireReason
        reasonLabel="Reason (required for the audit record)"
        isLoading={cancelMutation.isPending}
        onConfirm={(reason) => cancelMutation.mutate({ id: cancelTarget.id, reason })}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  )
}
