import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Square, ShieldAlert, Timer } from 'lucide-react'
import { listMySessions, endSession } from '../../api/sessions'
import { listSessions, killSession } from '../../api/admin'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, Toolbar, ListRow, StatusDot } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { SegmentedControl, FilterToggle } from '../../components/common/SegmentedControl'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { ResourceTypeIcon } from '../../components/resources/ResourceTypeIcon'
import { formatDateTime, formatDuration } from '../../lib/format'
import { SESSION_STATUS_BADGE, SESSIONS_POLL_MS, DEFAULT_PAGE_SIZE } from '../../config/constants'
import { apiErrorMessage } from '../../lib/apiError'

const TABS = [
  { key: 'mine', label: 'My sessions' },
  { key: 'all', label: 'All active (org-wide)' },
]

function StatusBadge({ status }) {
  return (
    <Badge className={SESSION_STATUS_BADGE[status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
      {status}
    </Badge>
  )
}

// Live duration for a still-running session — the backend's duration_seconds
// field is only populated once a session ends (see session.go's End()), so
// an ACTIVE row's own DurationSeconds is always 0. Computing it client-side
// from started_at avoids showing a permanently-stuck "0s" for live sessions.
function LiveDuration({ session }) {
  if (session.status !== 'ACTIVE') {
    return <>{formatDuration(session.duration_seconds)}</>
  }
  const elapsedSec = (Date.now() - new Date(session.started_at).getTime()) / 1000
  return <>{formatDuration(elapsedSec)}</>
}

function SessionRow({ session, onEnd, onKill, canKill, isMutating }) {
  const isActive = session.status === 'ACTIVE'
  return (
    <li className="group">
      <ListRow
        iconNode={<ResourceTypeIcon type={session.resource_type} className="h-[1.05rem] w-[1.05rem]" />}
        title={
          <span className="flex items-center gap-2">
            <span className="truncate">{session.resource_name}</span>
            {session.is_breakglass && (
              <span className="inline-flex flex-none items-center gap-1 rounded px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.04em] text-red-700 ring-1 ring-inset ring-red-600/25 dark:text-red-300 dark:ring-red-500/30">
                <ShieldAlert className="h-3 w-3" strokeWidth={1.75} /> break-glass
              </span>
            )}
          </span>
        }
        subtitle={
          <>
            {session.username ? `${session.username} · ` : ''}
            Started {formatDateTime(session.started_at)}
            {session.protocol ? ` · ${session.protocol}` : ''}
          </>
        }
        trailing={
          <>
            {/* Elapsed time reads as instrumentation: monospace, tabular,
                framed — not as another line of prose. */}
            <span className="hidden items-center gap-1.5 rounded-md border border-surface-700 bg-surface-850 px-2 py-1 font-mono text-2xs tabular-nums text-ink-300 sm:inline-flex">
              <Timer className="h-3 w-3 text-ink-500" strokeWidth={1.75} />
              <LiveDuration session={session} />
            </span>
            <span className="flex items-center gap-2">
              {isActive && <StatusDot tone="emerald" live />}
              <StatusBadge status={session.status} />
            </span>
            {isActive && (
              <span className="flex items-center gap-1.5">
                <Button size="xs" variant="secondary" onClick={() => onEnd(session.id)} disabled={isMutating}>
                  End
                </Button>
                {canKill && (
                  <Button
                    size="xs"
                    variant="dangerGhost"
                    icon={Square}
                    onClick={() => onKill(session)}
                    disabled={isMutating}
                  >
                    Kill
                  </Button>
                )}
              </span>
            )}
          </>
        }
        className="transition-colors hover:bg-surface-850"
      />
    </li>
  )
}

export default function SessionsPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [tab, setTab] = useState('mine')
  const [activeOnly, setActiveOnly] = useState(true)
  const [page, setPage] = useState(1)
  const [killTarget, setKillTarget] = useState(null)
  const queryClient = useQueryClient()

  // Reset to page 1 whenever a filter that changes the result set changes —
  // otherwise "page 3" can persist after switching filters into a set with
  // only 1 page, leaving Pagination's own bounds-check to silently clamp it
  // but the fetch itself would still have requested a now-invalid page.
  const changeTab = (next) => {
    setTab(next)
    setPage(1)
  }
  const changeActiveOnly = (next) => {
    setActiveOnly(next)
    setPage(1)
  }

  const mineQuery = useQuery({
    queryKey: ['sessions', 'mine', { page, activeOnly }],
    queryFn: ({ signal }) =>
      listMySessions({ page, pageSize: DEFAULT_PAGE_SIZE, activeOnly, signal }),
    enabled: tab === 'mine',
    // Poll only when looking at active sessions — a completed-sessions
    // history view has no reason to refetch every 15s.
    refetchInterval: tab === 'mine' && activeOnly ? SESSIONS_POLL_MS : false,
  })

  const allQuery = useQuery({
    queryKey: ['sessions', 'all', { activeOnly }],
    queryFn: ({ signal }) => listSessions({ active: activeOnly ? 'true' : undefined }, signal),
    enabled: tab === 'all' && isAdmin,
    refetchInterval: tab === 'all' && activeOnly ? SESSIONS_POLL_MS : false,
  })

  const activeQuery = tab === 'mine' ? mineQuery : allQuery

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ['sessions'] })
  }

  const endMutation = useMutation({
    mutationFn: (id) => endSession(id),
    onSuccess: () => {
      toast.success('Session ended')
      invalidateAll()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const killMutation = useMutation({
    mutationFn: ({ id, reason }) => killSession(id, reason),
    onSuccess: () => {
      toast.success('Session killed')
      setKillTarget(null)
      invalidateAll()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setKillTarget(null)
    },
  })

  const sessions = activeQuery.data?.sessions
  const pagination = tab === 'mine' ? activeQuery.data?.pagination : null
  const visibleTabs = TABS.filter((t) => t.key !== 'all' || isAdmin)

  return (
    <div>
      <PageHeader
        eyebrow="Access"
        title="Sessions"
        description="Tracked connection sessions — start/end lifecycle for audit and JIT grant expiry, not a live terminal."
        meta={
          activeOnly && (
            <span className="inline-flex items-center gap-2 rounded-md border border-surface-700 bg-surface-900 px-2.5 py-1 text-2xs font-medium uppercase tracking-[0.08em] text-ink-400">
              <StatusDot tone="emerald" live />
              Auto-refreshing
            </span>
          )
        }
      />

      <Toolbar>
        <SegmentedControl
          options={visibleTabs}
          value={tab}
          onChange={changeTab}
          ariaLabel="Session scope"
        />
        <span className="ml-auto" />
        <FilterToggle checked={activeOnly} onChange={changeActiveOnly} label="Active only" />
      </Toolbar>

      <Card>
        <QueryState
          query={activeQuery}
          empty={(d) => !d?.sessions || d.sessions.length === 0}
          emptyTitle={activeOnly ? 'No active sessions' : 'No sessions found'}
          emptyMessage={
            activeOnly
              ? 'Nothing is connected right now. Sessions appear here the moment a brokered connection opens.'
              : 'No session history matches this view.'
          }
        >
          {() => (
            <>
              <ul className="divide-y divide-surface-800">
                {sessions.map((s) => (
                  <SessionRow
                    key={s.id}
                    session={s}
                    canKill={tab === 'all'}
                    isMutating={endMutation.isPending || killMutation.isPending}
                    onEnd={(id) => endMutation.mutate(id)}
                    onKill={(session) => setKillTarget(session)}
                  />
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <ConfirmDialog
        open={!!killTarget}
        title={`Kill session on "${killTarget?.resource_name}"?`}
        description="This immediately terminates the tracked session and is recorded in the audit log."
        confirmLabel="Kill session"
        destructive
        requireReason
        reasonLabel="Reason (required for the audit record)"
        isLoading={killMutation.isPending}
        onConfirm={(reason) => killMutation.mutate({ id: killTarget.id, reason })}
        onCancel={() => setKillTarget(null)}
      />
    </div>
  )
}
