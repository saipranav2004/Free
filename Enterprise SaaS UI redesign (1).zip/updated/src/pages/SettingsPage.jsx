import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { CheckCircle2, ShieldCheck, UserRound } from 'lucide-react'
import { me } from '../api/auth'
import { PageHeader, Card, CardHeader, CardTitle } from '../components/common/Layout'
import { QueryState } from '../components/common/QueryState'
import { MfaEnrollment } from '../components/auth/MfaEnrollment'
import { Badge } from '../components/common/Badge'
import { AgentDevicesPanel } from '../components/agent/AgentDevicesPanel'
import { ROLE_BADGE } from '../config/constants'

function Row({ label, children }) {
  return (
    <div className="grid grid-cols-[minmax(6.5rem,30%)_1fr] gap-4 px-4 py-3">
      <dt className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</dt>
      <dd className="min-w-0 break-words text-sm text-ink-100">{children}</dd>
    </div>
  )
}

export default function SettingsPage() {
  const queryClient = useQueryClient()
  const [justEnrolled, setJustEnrolled] = useState(false)
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal) })

  return (
    <div>
      <PageHeader
        eyebrow="Account"
        title="Settings"
        description="Your identity, second factor, and the devices paired to this account."
      />

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle icon={UserRound}>Account</CardTitle>
          </CardHeader>
          <QueryState query={meQuery} skeletonRows={4}>
            {(data) => (
              <dl className="divide-y divide-surface-800">
                <Row label="Username">{data.username}</Row>
                <Row label="Email">{data.email}</Row>
                <Row label="MFA">
                  {data.mfa_verified ? (
                    <Badge className="bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30" dot>
                      Verified this session
                    </Badge>
                  ) : (
                    <Badge className="bg-ink-500/10 text-ink-400 ring-ink-500/25" dot>
                      Not verified this session
                    </Badge>
                  )}
                </Row>
                <Row label="Roles">
                  <div className="flex flex-wrap gap-1.5">
                    {(data.roles || []).length === 0 && <span className="text-ink-500">—</span>}
                    {(data.roles || []).map((r) => (
                      <Badge key={r} className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                        {r}
                      </Badge>
                    ))}
                  </div>
                </Row>
              </dl>
            )}
          </QueryState>
        </Card>

        {justEnrolled ? (
          <Card>
            <CardHeader>
              <CardTitle icon={ShieldCheck}>Two-factor authentication</CardTitle>
            </CardHeader>
            <div className="flex items-start gap-3 p-5">
              <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 ring-1 ring-inset ring-emerald-600/15 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
                <CheckCircle2 className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
              </span>
              <div>
                <p className="text-sm font-semibold text-ink-100">Two-factor authentication is active</p>
                <p className="mt-1 text-sm leading-relaxed text-ink-400">
                  You&apos;ll be asked for a code from your authenticator app on every new sign-in.
                </p>
              </div>
            </div>
          </Card>
        ) : (
          <MfaEnrollment
            onEnrolled={() => {
              setJustEnrolled(true)
              queryClient.invalidateQueries({ queryKey: ['me'] })
              toast.success('MFA enabled')
            }}
          />
        )}

        <AgentDevicesPanel />
      </div>
    </div>
  )
}
