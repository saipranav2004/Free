import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, Plus, FolderTree, KeyRound, ChevronRight } from 'lucide-react'
import { getSafe, listFolders, listCredentials } from '../../api/vault'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { CreateFolderModal } from '../../components/vault/CreateFolderModal'
import { CreateCredentialModal } from '../../components/vault/CreateCredentialModal'
import { formatDateTime } from '../../lib/format'

function CredentialStatusBadge({ status }) {
  const cls =
    status === 'active'
      ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30'
      : 'bg-ink-500/15 text-ink-400 ring-ink-500/30'
  return <Badge className={cls}>{status}</Badge>
}

export default function SafeDetailPage() {
  const { safeId } = useParams()
  const [folderModalOpen, setFolderModalOpen] = useState(false)
  const [credentialModalOpen, setCredentialModalOpen] = useState(false)

  const safeQuery = useQuery({
    queryKey: ['vault', 'safes', safeId],
    queryFn: ({ signal }) => getSafe(safeId, signal),
  })
  const foldersQuery = useQuery({
    queryKey: ['vault', 'safes', safeId, 'folders'],
    queryFn: ({ signal }) => listFolders(safeId, signal),
  })
  const credentialsQuery = useQuery({
    queryKey: ['vault', 'safes', safeId, 'credentials'],
    queryFn: ({ signal }) => listCredentials(safeId, signal),
  })

  return (
    <div>
      <Link to="/vault" className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 hover:text-ink-200">
        <ArrowLeft className="h-3.5 w-3.5" /> Back to safes
      </Link>

      <QueryState query={safeQuery}>
        {(safe) => (
          <PageHeader
            title={safe.name}
            description={safe.description || `Retention: ${safe.retention_days} days`}
          />
        )}
      </QueryState>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <Card>
          <CardHeader className="flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-sm font-semibold text-ink-50">
              <FolderTree className="h-4 w-4" /> Folders
            </h3>
            <button
              onClick={() => setFolderModalOpen(true)}
              className="text-ink-400 hover:text-ink-100"
              aria-label="Create folder"
              title="Create folder"
            >
              <Plus className="h-4 w-4" />
            </button>
          </CardHeader>
          <QueryState
            query={foldersQuery}
            empty={(f) => !f || f.length === 0}
            emptyMessage="No folders."
          >
            {(folders) => (
              <ul className="divide-y divide-surface-800">
                {folders.map((f) => (
                  <li key={f.id} className="px-4 py-2.5">
                    <p className="text-sm text-ink-100">{f.name}</p>
                    <p className="truncate text-xs text-ink-500" title={f.path}>
                      {f.path}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </Card>

        <Card>
          <CardHeader className="flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-sm font-semibold text-ink-50">
              <KeyRound className="h-4 w-4" /> Credentials
            </h3>
            <button
              onClick={() => setCredentialModalOpen(true)}
              className="flex items-center gap-1.5 h-7 rounded-lg bg-blue-600 px-2.5 text-xs font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700"
            >
              <Plus className="h-3.5 w-3.5" /> Store credential
            </button>
          </CardHeader>
          <QueryState
            query={credentialsQuery}
            empty={(c) => !c || c.length === 0}
            emptyMessage="No credentials stored in this safe yet."
          >
            {(credentials) => (
              <ul className="divide-y divide-surface-800">
                {credentials.map((c) => (
                  <li key={c.id}>
                    <Link
                      to={`/vault/${safeId}/credentials/${c.id}`}
                      className="flex items-center justify-between px-4 py-3.5 transition-colors hover:bg-surface-850"
                    >
                      <div>
                        <p className="text-sm font-medium text-ink-100">{c.name}</p>
                        <p className="text-xs text-ink-500">
                          {c.account_name} · {c.credential_type}
                          {c.last_rotated_at && ` · rotated ${formatDateTime(c.last_rotated_at)}`}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {c.is_breakglass && (
                          <Badge className="bg-red-500/15 text-red-700 dark:text-red-300 ring-red-500/30">Break-glass</Badge>
                        )}
                        <CredentialStatusBadge status={c.status} />
                        <ChevronRight className="h-4 w-4 text-ink-600" />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </Card>
      </div>

      <CreateFolderModal open={folderModalOpen} onClose={() => setFolderModalOpen(false)} safeId={safeId} />
      <CreateCredentialModal open={credentialModalOpen} onClose={() => setCredentialModalOpen(false)} safeId={safeId} />
    </div>
  )
}
