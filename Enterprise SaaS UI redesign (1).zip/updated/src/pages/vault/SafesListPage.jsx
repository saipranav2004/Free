import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight, Vault as VaultIcon, Clock, ShieldCheck, Star } from 'lucide-react'
import { listSafes } from '../../api/vault'
import { PageHeader, Card, ListRow } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { KpiStrip } from '../../components/common/KpiStrip'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { CreateSafeModal } from '../../components/vault/CreateSafeModal'

export default function SafesListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const safesQuery = useQuery({
    queryKey: ['vault', 'safes'],
    queryFn: ({ signal }) => listSafes(signal),
  })

  // Every figure below is read straight off the safe records this endpoint
  // returned. Credential counts are deliberately absent: listSafes doesn't
  // return them, and fetching per-safe counts would mean N requests to
  // decorate a list header.
  const safes = safesQuery.data || []
  const retentions = safes.map((s) => s.retention_days).filter((d) => typeof d === 'number')
  const longestRetention = retentions.length ? Math.max(...retentions) : null

  return (
    <div>
      <PageHeader
        eyebrow="Vault"
        title="Safes"
        description="Safes group credentials by ownership and retention policy. Secrets never leave the vault — access is brokered and recorded."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create safe
          </Button>
        }
      />

      <KpiStrip
        className="mb-5"
        columns={3}
        loading={safesQuery.isLoading}
        items={[
          {
            key: 'safes',
            label: 'Safes',
            value: safes.length,
            icon: VaultIcon,
            description: 'Credential containers in the vault',
          },
          {
            key: 'default',
            label: 'Default safe',
            value: safes.some((s) => s.is_default) ? 'Set' : 'None',
            icon: Star,
            tone: safes.some((s) => s.is_default) ? 'blue' : 'amber',
            description: safes.find((s) => s.is_default)?.name || 'No default assigned',
          },
          {
            key: 'retention',
            label: 'Longest retention',
            value: longestRetention === null ? '—' : `${longestRetention}d`,
            icon: ShieldCheck,
            description: 'Maximum configured across safes',
          },
        ]}
      />

      <QueryState
        query={safesQuery}
        empty={(safes) => !safes || safes.length === 0}
        emptyTitle="No safes yet"
        emptyMessage="Create a safe to start storing credentials under a retention policy."
        emptyAction={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create safe
          </Button>
        }
      >
        {(safes) => (
          <Card>
            <ul className="divide-y divide-surface-800">
              {safes.map((safe) => (
                <li key={safe.id} className="group">
                  <Link to={`/vault/${safe.id}`} className="block outline-none">
                    <ListRow
                      icon={VaultIcon}
                      title={safe.name}
                      subtitle={safe.description || 'No description'}
                      trailing={
                        <>
                          {safe.is_default && (
                            <Badge className="bg-blue-50 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30">
                              Default
                            </Badge>
                          )}
                          <span className="hidden items-center gap-1.5 rounded-md border border-surface-700 bg-surface-850 px-2 py-1 font-mono text-2xs tabular-nums text-ink-400 sm:inline-flex">
                            <Clock className="h-3 w-3 text-ink-500" strokeWidth={1.75} />
                            {safe.retention_days}d
                          </span>
                          <ChevronRight
                            className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                            strokeWidth={1.5}
                          />
                        </>
                      }
                      className="transition-colors hover:bg-surface-850"
                    />
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreateSafeModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
