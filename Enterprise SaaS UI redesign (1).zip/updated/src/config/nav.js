import {
  LayoutDashboard, Boxes, Vault, Radio, KeyRound, ScrollText,
  Users, Lock, FileKey2, ClipboardList, Archive, Settings as SettingsIcon,
} from 'lucide-react'

// ---------------------------------------------------------------------------
// Navigation model
// ---------------------------------------------------------------------------
// Lifted out of AppLayout so the sidebar, the topbar breadcrumb and the
// topbar's jump-to search all read the SAME list. Previously the sidebar
// owned these arrays privately, which meant anything else that wanted to
// know "what can you navigate to" had to duplicate them and drift.

// Self-service — visible to every authenticated user, regardless of role.
export const CONSOLE_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/resources', label: 'Resources', icon: Boxes },
  { to: '/vault', label: 'Vault', icon: Vault },
  { to: '/sessions', label: 'Sessions', icon: Radio },
  { to: '/jit', label: 'JIT Access', icon: KeyRound },
  { to: '/audit', label: 'Audit', icon: ScrollText },
]

// Admin Center — only rendered for accounts holding the "admin" or "root"
// role (see AdminRoute for the matching route guard).
export const ADMIN_NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/identity', label: 'Identity', icon: Users },
  { to: '/admin/roles', label: 'Roles', icon: Lock },
  { to: '/admin/policies', label: 'Policies', icon: FileKey2 },
  { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound },
  { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
  { to: '/admin/vault-ops', label: 'Vault Operations', icon: Archive },
]

// Presentational only — maps a path segment to a human label for the
// topbar breadcrumb. Reads location; never influences routing or fetching.
export const CRUMB_LABELS = {
  resources: 'Resources',
  vault: 'Vault',
  sessions: 'Sessions',
  jit: 'JIT Access',
  requests: 'Request',
  audit: 'Audit',
  settings: 'Settings',
  admin: 'Admin Center',
  identity: 'Identity',
  roles: 'Roles',
  policies: 'Policies',
  'vault-ops': 'Vault Operations',
  credentials: 'Credential',
  'mfa-verify': 'Verification',
}

// Everything the topbar's jump-to (⌘K) can navigate to. Navigation targets
// only — deliberately NOT a command palette: page-level *actions* need an
// action registry that doesn't exist yet, and a palette that lists actions
// it can't perform is worse than one that only jumps.
export function quickJumpTargets(isAdmin) {
  return [
    ...CONSOLE_NAV.map((i) => ({ to: i.to, label: i.label, icon: i.icon, group: 'Console' })),
    ...(isAdmin
      ? ADMIN_NAV.map((i) => ({ to: i.to, label: i.label, icon: i.icon, group: 'Admin Center' }))
      : []),
    { to: '/settings', label: 'Settings', icon: SettingsIcon, group: 'Account' },
  ]
}
