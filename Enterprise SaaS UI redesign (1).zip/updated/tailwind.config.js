/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Desaturated console palette — status colors (amber/red/emerald) do
        // the signaling, the base palette stays quiet so they stand out.
        //
        // THEME NOTE: every shade below is backed by a CSS custom property
        // (see src/index.css) rather than a literal hex value. `:root`
        // defines the LIGHT values, `.dark` overrides them with the
        // original dark-console values — so every existing class in the
        // app (`bg-surface-900`, `text-ink-400`, etc.) automatically
        // repaints for the active theme with zero per-component changes.
        // The `<alpha-value>` placeholder is Tailwind's own mechanism for
        // letting `bg-surface-900/50` opacity modifiers keep working against
        // an rgb()-triplet custom property.
        //
        // ink-100 / ink-300 / ink-600 and surface-750 / surface-1000 are new
        // *steps of the same ramp* (no hue change): the app already used
        // several of these class names, which previously resolved to nothing
        // and silently fell back to inherited color.
        surface: {
          1000: 'rgb(var(--surface-1000) / <alpha-value>)',
          950: 'rgb(var(--surface-950) / <alpha-value>)',
          900: 'rgb(var(--surface-900) / <alpha-value>)',
          850: 'rgb(var(--surface-850) / <alpha-value>)',
          800: 'rgb(var(--surface-800) / <alpha-value>)',
          750: 'rgb(var(--surface-750) / <alpha-value>)',
          700: 'rgb(var(--surface-700) / <alpha-value>)',
          600: 'rgb(var(--surface-600) / <alpha-value>)',
        },
        ink: {
          50: 'rgb(var(--ink-50) / <alpha-value>)',
          100: 'rgb(var(--ink-100) / <alpha-value>)',
          200: 'rgb(var(--ink-200) / <alpha-value>)',
          300: 'rgb(var(--ink-300) / <alpha-value>)',
          400: 'rgb(var(--ink-400) / <alpha-value>)',
          500: 'rgb(var(--ink-500) / <alpha-value>)',
          600: 'rgb(var(--ink-600) / <alpha-value>)',
        },
      },
      fontFamily: {
        sans: ['Inter var', 'Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem', letterSpacing: '0.02em' }],
      },
      boxShadow: {
        card: 'var(--shadow-card)',
        raised: 'var(--shadow-raised)',
        pop: 'var(--shadow-pop)',
        overlay: 'var(--shadow-overlay)',
      },
      borderRadius: {
        xl: '0.75rem',
        '2xl': '1rem',
      },
      transitionTimingFunction: {
        emphasis: 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
    },
  },
  plugins: [],
}
