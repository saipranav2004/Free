# PAM Console — enterprise UI/UX redesign

Copy this folder's contents over your project root, preserving paths. Only
changed and new files are included.

**Backend untouched.** Nothing under `src/api`, `src/lib`, `src/store`,
`src/config`, `src/hooks`, `src/main.jsx` or `src/App.jsx` was modified — every
API call, payload, query key, mutation, cache invalidation, count and state
update is byte-for-byte what it was. No new dependencies; no `npm install`
needed.

---

## The design system this establishes

Four decisions drive every screen:

1. **Surface depth is real.** The sidebar sits on `surface-1000`, content on
   `surface-950`, cards on `surface-900`, wells on `surface-800`. Navigation
   reads as chrome instead of as another content panel — the single biggest
   change to how the app feels.
2. **Cards are drawn objects, not rectangles.** Hairline border, a 1px inner
   top highlight (`.edge-lit`), and a faint modular grid (`.tex-grid`) in the
   corner of metric plates. Depth from structure, not from gradients.
3. **Every glyph is Lucide at stroke-width 1.5.** A thinner stroke is what
   separates technical enterprise iconography from generic UI icons.
4. **One primitive per job.** One button, one modal, one list row, one metric
   plate, one segmented control — so a change lands everywhere at once and no
   screen drifts.

## Screens redesigned

**Sidebar** — its own surface plane, logo wordmark + a console-identity plate
below it (**IAM Console** for admin/root, **PAM Console** otherwise, derived
from the existing `isAdmin()` selector). Grouped nav with ruled section
labels, an animated active rail, tinted active state. **Open by default**;
collapses to a 76px icon rail with the mark and a tooltip per item. State
persists under `pam_sidebar_collapsed`.

**Topbar** — collapse toggle, URL-derived breadcrumb (opaque UUID segments
render as "Detail", never raw), theme switch, and the user cluster: avatar +
username, **no chevron**, menu still opens on click.

**Dashboard** — metric plates with a tone rail, 32px tabular figure, framed
icon tile, corner grid texture and a live presence dot on the "active"
metrics. Content is banded into ruled `Section`s. Navigation plates replace
the flat link boxes.

**Sessions** — segmented control replaces the blue-pill tabs, styled filter
toggle replaces the raw checkbox, elapsed time renders as a framed monospace
instrument readout, live sessions carry a pulsing dot.

**JIT Access** — segmented control + styled status filter in a toolbar,
framed row glyphs, break-glass rendered as a ringed marker rather than loose
red text, real empty states with a CTA.

**Audit** — chain-integrity verification promoted to its own plate above the
log; search/category/outcome moved into a proper toolbar; the report builder
is a disclosed panel with a segmented format switch; entries render the
action in monospace with the category as a chip and actor/target as labelled
metadata.

**Roles** — expandable rows with a framed lock glyph, attached policies as
detachable chips, and a bordered attach control.

**Admin overview / Identity / Resources / Vault / Settings / Login / MFA /
404** — all rebuilt on the same vocabulary.

**Everywhere** — skeleton rows for loading, a framed error plate with retry,
shared empty states, and hover/active/focus states on every interactive
surface (`:focus-visible` only, so mouse clicks don't leave rings).

## New files

    src/components/common/Button.jsx            Button / IconButton + buttonClass()
    src/components/common/Modal.jsx             modal shell: esc, scroll lock, focus, motion
    src/components/common/SegmentedControl.jsx  SegmentedControl + FilterToggle
    src/assets/logo-wordmark.png                trimmed lockup, light theme
    src/assets/logo-wordmark-dark.png           same lockup, reversed for dark
    src/assets/logo-mark.png                    square mark for the collapsed rail

`das_logo_light.png` is untouched — the three assets above are derived from it.

## Changed files

    index.html                      Inter + JetBrains Mono (the config already
                                    asked for Inter; it was never loaded)
    tailwind.config.js              ramp steps, shadow-card/raised/pop/overlay,
                                    text-2xs, ease-emphasis
    src/index.css                   tokens, elevation, .edge-lit, .tex-grid,
                                    .tex-hatch, skeleton shimmer, overlay/panel/
                                    menu motion, focus ring, reduced-motion

    src/components/common/          AppLayout, Layout (+Section, ListRow,
                                    StatusDot, Toolbar), StatCard, Badge,
                                    FormFields, QueryState, Spinner, TabBar,
                                    Pagination, ConfirmDialog, CopyButton,
                                    ErrorBoundary, ThemeToggle
    src/components/admin/           CreatePolicyModal, CreateRoleModal, CreateUserModal
    src/components/agent/           AgentDevicesPanel, PairAgentPanel
    src/components/audit/           AuditEventDetailModal
    src/components/auth/            MfaEnrollment
    src/components/jit/             CreateJitRequestModal
    src/components/resources/       ConnectPanel, CreateResourceModal, ResourceTypeIcon
    src/components/vault/           BackupRestorePanel, CreateCredentialModal,
                                    CreateFolderModal, CreateSafeModal,
                                    RevealCredentialModal

    src/pages/                      DashboardPage, SettingsPage, NotFoundPage
    src/pages/auth/                 LoginPage, MfaVerifyPage
    src/pages/admin/                AdminOverviewPage, AdminAuditPage, AdminJitPage,
                                    IdentityListPage, IdentityDetailPage,
                                    PoliciesPage, RolesPage
    src/pages/audit/                AuditPage
    src/pages/jit/                  JitPage, JitRequestDetailPage
    src/pages/resources/            ResourcesPage, ResourceDetailPage
    src/pages/sessions/             SessionsPage
    src/pages/vault/                SafesListPage, SafeDetailPage, CredentialDetailPage

Deliberately NOT included (unchanged): `src/pages/vault/VaultPage.jsx`,
`src/pages/admin/AdminVaultOpsPage.jsx`, `src/components/auth/ProtectedRoute.jsx`,
`src/components/auth/AdminRoute.jsx`, and all of `src/api`, `src/lib`,
`src/store`, `src/config`, `src/hooks`.

## Palette

Unchanged. Same blue-600 accent, same surface/ink values. The config additions
are new *steps of the existing ramps* — no new hues. `ink-100`, `ink-300` and
`ink-600` were already referenced across the app but had never been defined, so
those classes silently rendered as inherited colour; they now resolve. That is
the only behavioural change in the drop.

## Verify after `npm run dev`

Dashboard counts (admin and non-admin), JIT approve/deny + the pending count
after a decision, session end/kill, audit search + offset pagination, and the
sidebar title switching between IAM and PAM Console by role.
