import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import {
  AlertCircle, ArrowLeft, ArrowRight, Check, KeyRound, LifeBuoy,
  ShieldCheck, Smartphone, Star, CheckCircle2, Clock3,
} from 'lucide-react'
import { verifyMfa } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../../components/common/Spinner'
import { OtpInput, isCompleteOtp } from '../../components/common/OtpInput'
import logoWordmark from '../../assets/logo-wordmark.png'

// ---------------------------------------------------------------------------
// Two-factor verification — step 2 of the sign-in flow
// ---------------------------------------------------------------------------
// REDESIGN RATIONALE. This screen used to be a small themed console card on a
// surface-950 field, which meant the highest-stakes moment in the product —
// the one where a privileged operator proves who they are — looked less
// considered than the sign-in screen immediately before it, and switched
// visual language mid-flow. It is now built on the SAME fixed brand surface as
// LoginPage (navy field, radial lighting, white credential card), so signing
// in reads as one continuous two-step act rather than two unrelated pages.
//
// Like LoginPage, this screen is deliberately theme-independent: the colours
// are literal brand values, not surface-*/ink-* tokens, because authentication
// is a brand surface and must render identically on every machine. The OTP
// field is the shared OtpInput in its `brand` tone for exactly that reason.
//
// WHAT IS NEW BEYOND THE SKIN:
//   · a three-step flow indicator, so the user knows where they are and that
//     one step remains;
//   · an explicit method switch — authenticator app vs. recovery code — instead
//     of a footnote telling people to type a backup code into a six-box field
//     that physically cannot hold one;
//   · the account being verified, echoed back, so a user with several accounts
//     knows which session they are completing;
//   · after two rejections, the real diagnosis (authenticator clock drift)
//     rather than the same generic error a third time.
//
// AUTH BEHAVIOUR IS UNCHANGED: same challenge guard, same verifyMfa call, same
// setSession({ viaMfaChallenge }) evidence flag, same redirect.
//
// NOTE ON THE MISSING COUNTDOWN: verified against this backend
// (auth_service.go's verifyChallengeToken) the challenge token has no expiry
// check at all — it is parsed and accepted regardless of age. A countdown here
// would be a lie about enforcement that does not exist, so there isn't one.

const NAVY = '#0A1729'
const CYAN = '#29A8E0'

const ASSURANCES = [
  { icon: ShieldCheck, label: 'SOC 2 Type II Certified' },
  { icon: Star, label: 'ISO 27001 Compliant' },
  { icon: CheckCircle2, label: '24/7 Monitoring' },
]

const STEPS = ['Credentials', 'Verification', 'Console']

const METHODS = [
  { key: 'totp', label: 'Authenticator app', icon: Smartphone },
  { key: 'recovery', label: 'Recovery code', icon: KeyRound },
]

function FlowSteps({ current = 1 }) {
  return (
    <ol className="flex items-center gap-3" aria-label="Sign-in progress">
      {STEPS.map((label, i) => {
        const done = i < current
        const active = i === current
        return (
          <li key={label} className="flex items-center gap-3">
            <span className="flex items-center gap-2">
              <span
                aria-hidden="true"
                className="flex h-5 w-5 flex-none items-center justify-center rounded-full text-[0.625rem] font-bold"
                style={{
                  backgroundColor: done ? 'rgba(16,185,129,0.18)' : active ? CYAN : 'rgba(255,255,255,0.08)',
                  color: done ? '#34d399' : active ? '#04121f' : 'rgba(226,232,240,0.55)',
                  boxShadow: active ? `0 0 0 4px rgba(41,168,224,0.16)` : 'none',
                }}
              >
                {done ? <Check className="h-3 w-3" strokeWidth={3} /> : i + 1}
              </span>
              <span
                className="text-[0.6875rem] font-semibold uppercase tracking-[0.12em]"
                style={{ color: active ? '#E2E8F0' : 'rgba(226,232,240,0.5)' }}
              >
                {label}
              </span>
            </span>
            {i < STEPS.length - 1 && (
              <span aria-hidden="true" className="h-px w-6 flex-none" style={{ backgroundColor: 'rgba(226,232,240,0.18)' }} />
            )}
          </li>
        )
      })}
    </ol>
  )
}

export default function MfaVerifyPage() {
  const navigate = useNavigate()
  const challenge = useAuthStore((s) => s.mfaChallenge)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
  const setSession = useAuthStore((s) => s.setSession)
  const clearMfaChallenge = useAuthStore((s) => s.clearMfaChallenge)

  const [method, setMethod] = useState('totp')
  const [code, setCode] = useState('')
  const [recovery, setRecovery] = useState('')
  const [error, setError] = useState(null)
  const [attempts, setAttempts] = useState(0)
  const recoveryRef = useRef(null)

  // Guard against reaching this screen with no challenge in memory (deep link,
  // back button, stale bookmark). It must also check isAuthenticated:
  // setSession() clears mfaChallenge in the same update that sets the token, so
  // without that check this fires on the success path too and its
  // navigate('/login') races the success handler's navigate('/').
  useEffect(() => {
    if (!challenge?.challengeToken && !isAuthenticated) {
      navigate('/login', { replace: true })
    }
  }, [challenge, isAuthenticated, navigate])

  const mutation = useMutation({
    mutationFn: (c) => verifyMfa(challenge.challengeToken, c),
    onSuccess: (result) => {
      resetSessionExpiredGuard()
      clearMfaChallenge()
      setSession({
        accessToken: result.access_token,
        expiresAt: result.expires_at,
        user: null,
        // Reaching here means a challenge was issued and cleared, so this
        // account demonstrably HAS MFA. viaMfaChallenge stops setSession
        // recording the opposite — without it, completing an MFA sign-in would
        // overwrite the enrolment evidence the challenge just proved.
        identifier: challenge?.identifier,
        viaMfaChallenge: true,
      })
      navigate('/', { replace: true })
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      setAttempts((n) => n + 1)
      // Clear on failure so the user re-types rather than resubmitting the
      // same rejected value — OtpInput returns focus to the first box.
      setCode('')
      setRecovery('')
    },
  })

  const value = method === 'totp' ? code : recovery.trim()
  const submittable = method === 'totp' ? isCompleteOtp(code) : recovery.trim().length >= 6

  const submit = (c) => {
    const next = c ?? value
    const ok = method === 'totp' ? isCompleteOtp(next) : String(next).trim().length >= 6
    if (!ok || mutation.isPending) return
    setError(null)
    mutation.mutate(String(next).trim())
  }

  const switchMethod = (next) => {
    if (next === method) return
    setMethod(next)
    setError(null)
    setCode('')
    setRecovery('')
    if (next === 'recovery') requestAnimationFrame(() => recoveryRef.current?.focus())
  }

  if (!challenge?.challengeToken) return null

  return (
    <div className="relative min-h-screen overflow-hidden" style={{ backgroundColor: NAVY }}>
      {/* Same lit navy plane as sign-in: two soft radial washes rather than a
          linear gradient sweep, so it reads as depth, not decoration. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(1100px 720px at 18% 8%, rgba(41,120,196,0.42), transparent 62%), radial-gradient(900px 600px at 8% 96%, rgba(12,32,58,0.9), transparent 70%)',
        }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(148,183,226,0.07) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,183,226,0.07) 1px, transparent 1px)',
          backgroundSize: '56px 56px',
          maskImage: 'radial-gradient(ellipse at 25% 15%, black 5%, transparent 65%)',
          WebkitMaskImage: 'radial-gradient(ellipse at 25% 15%, black 5%, transparent 65%)',
        }}
      />

      <div className="relative flex min-h-screen flex-col lg:flex-row">
        {/* -------------------------------------------------------------
            Assurance panel
            ------------------------------------------------------------- */}
        <section className="flex min-w-0 flex-1 flex-col justify-between gap-12 px-6 pb-10 pt-10 sm:px-10 lg:py-14 lg:pl-14 lg:pr-8 xl:pl-20">
          <div className="flex flex-col items-start gap-7">
            <div className="inline-flex w-fit items-center gap-2.5 rounded-full border border-white/[0.14] bg-white/[0.05] py-2 pl-3 pr-4 backdrop-blur-sm">
              <span className="h-1.5 w-1.5 flex-none rounded-full" style={{ backgroundColor: CYAN }} aria-hidden="true" />
              <span className="text-[0.6875rem] font-semibold uppercase tracking-[0.16em] text-slate-200">
                Step 2 of 2 · Identity Verification
              </span>
            </div>
            <FlowSteps current={1} />
          </div>

          <div className="max-w-2xl">
            <h1 className="text-[2.5rem] font-bold leading-[1.06] tracking-[-0.03em] text-white sm:text-5xl lg:text-[3.75rem]">
              One more
              <br />
              <span style={{ color: CYAN }}>proof of identity</span>
            </h1>

            <p className="mt-8 max-w-xl text-base font-medium leading-relaxed text-slate-300/90 sm:text-lg">
              Your password alone does not open a privileged session. Confirm the second factor from a device you
              control and the console will be unlocked for this session only.
            </p>

            <ul className="mt-10 flex flex-wrap items-center gap-x-9 gap-y-4">
              {ASSURANCES.map((a) => (
                <li key={a.label} className="flex items-center gap-2.5 text-sm font-medium text-slate-200 sm:text-[0.9375rem]">
                  <a.icon className="h-[1.15rem] w-[1.15rem] flex-none text-emerald-400" strokeWidth={1.75} />
                  {a.label}
                </li>
              ))}
            </ul>
          </div>

          <p className="text-xs text-slate-400/80 sm:text-sm">
            © {new Date().getFullYear()} Deep Algorithms · Fostering AI. Connecting Minds.
          </p>
        </section>

        {/* -------------------------------------------------------------
            Verification card
            ------------------------------------------------------------- */}
        {/* Same contained card as sign-in, and for the same reasons - see the
            long note in LoginPage.jsx. This screen carries more content (method
            switch, code field, two footer affordances), so the measure is one
            step wider at 26rem and the internal rhythm one step tighter, which
            keeps the whole card inside a 900px-tall laptop viewport without
            scrolling. Step 1 and step 2 of sign-in therefore present the same
            object at the same optical size, which is the point: the flow should
            not appear to change shape between them. Colours are untouched. */}
        <div className="flex w-full flex-none items-center justify-center px-5 pb-10 pt-2 lg:w-[42%] lg:max-w-[34rem] lg:px-8 lg:py-10">
          <div className="w-full max-w-[26rem] rounded-2xl bg-white px-6 py-8 shadow-[0_24px_56px_-20px_rgba(3,10,22,0.62),0_2px_8px_-3px_rgba(3,10,22,0.30)] ring-1 ring-slate-900/[0.06] sm:px-8">
            <div className="w-full">
              <img src={logoWordmark} alt="Deep Algorithms" className="mb-6 h-8 w-auto object-contain object-left" />

              <div className="flex items-start gap-3">
                <span
                  className="flex h-10 w-10 flex-none items-center justify-center rounded-xl text-white"
                  style={{ backgroundImage: 'linear-gradient(140deg, #2FA8E0 0%, #1C79C6 100%)', boxShadow: '0 10px 22px -12px rgba(28,121,198,0.9)' }}
                >
                  <ShieldCheck className="h-[1.2rem] w-[1.2rem]" strokeWidth={1.9} />
                </span>
                <div className="min-w-0">
                  <h2 className="text-[1.375rem] font-bold leading-tight tracking-[-0.02em] text-slate-900">
                    Two-factor verification
                  </h2>
                  <p className="mt-1 text-[0.8125rem] leading-relaxed text-slate-500">
                    {method === 'totp'
                      ? 'Enter the 6-digit code shown in your authenticator app.'
                      : 'Enter one unused recovery code from when you enrolled.'}
                  </p>
                </div>
              </div>

              {challenge?.identifier && (
                <div className="mt-4 flex items-center gap-2.5 rounded-[0.625rem] border border-slate-200 bg-slate-50 px-3 py-2">
                  <span className="flex h-6 w-6 flex-none items-center justify-center rounded-full bg-slate-900 text-[0.625rem] font-bold uppercase text-white">
                    {String(challenge.identifier).charAt(0)}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-[0.8125rem] text-slate-600">
                    Verifying <span className="font-semibold text-slate-900">{challenge.identifier}</span>
                  </span>
                </div>
              )}

              {/* Method switch. A recovery code is not six digits, so offering
                  it as a mode — rather than as a footnote under a six-box
                  field — is the difference between a usable fallback and a
                  dead end at the worst possible moment. */}
              <div className="mt-5 inline-flex w-full items-center gap-1 rounded-[0.625rem] border border-slate-200 bg-slate-100/70 p-1">
                {METHODS.map((m) => {
                  const selected = method === m.key
                  return (
                    <button
                      key={m.key}
                      type="button"
                      onClick={() => switchMethod(m.key)}
                      aria-pressed={selected}
                      className={[
                        'inline-flex h-9 flex-1 items-center justify-center gap-2 rounded-lg text-[0.8125rem] font-semibold transition-all duration-150',
                        selected
                          ? 'bg-white text-slate-900 shadow-[0_1px_2px_rgb(15_23_42/0.10)] ring-1 ring-slate-200'
                          : 'text-slate-500 hover:text-slate-800',
                      ].join(' ')}
                    >
                      <m.icon className="h-4 w-4 flex-none" strokeWidth={1.75} />
                      {m.label}
                    </button>
                  )
                })}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  submit()
                }}
                className="mt-5"
                noValidate
              >
                {method === 'totp' ? (
                  <OtpInput
                    value={code}
                    onChange={setCode}
                    onComplete={submit}
                    invalid={!!error}
                    disabled={mutation.isPending}
                    autoFocus
                    tone="brand"
                    ariaLabel="Six digit verification code"
                  />
                ) : (
                  <div>
                    <label htmlFor="recovery-code" className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-800">
                      <KeyRound className="h-4 w-4 flex-none text-slate-400" strokeWidth={1.75} />
                      Recovery code
                    </label>
                    <input
                      id="recovery-code"
                      ref={recoveryRef}
                      value={recovery}
                      onChange={(e) => setRecovery(e.target.value)}
                      autoComplete="one-time-code"
                      spellCheck="false"
                      autoCapitalize="off"
                      placeholder="xxxx-xxxx-xxxx"
                      aria-invalid={!!error}
                      disabled={mutation.isPending}
                      className={[
                        'h-12 w-full rounded-[0.625rem] border bg-white px-4 text-center font-mono text-base tracking-[0.12em] text-slate-900 shadow-[0_1px_2px_rgb(15_23_42/0.04)]',
                        'transition-[border-color,box-shadow] duration-150 placeholder:tracking-normal placeholder:text-slate-300',
                        'focus:outline-none focus:ring-[3px] disabled:opacity-60',
                        error
                          ? 'border-red-400 focus:border-red-500 focus:ring-red-500/15'
                          : 'border-slate-200 hover:border-slate-300 focus:border-[#29A8E0] focus:ring-[#29A8E0]/20',
                      ].join(' ')}
                    />
                    <p className="mt-2 text-xs leading-relaxed text-slate-500">
                      Each recovery code works once. Using one here does not disable your authenticator.
                    </p>
                  </div>
                )}

                {error && (
                  <div
                    role="alert"
                    className="mt-4 flex items-start gap-2.5 rounded-[0.625rem] border border-red-200 bg-red-50 px-3 py-2.5 text-[0.8125rem] text-red-700"
                  >
                    <AlertCircle className="mt-0.5 h-4 w-4 flex-none" strokeWidth={2} />
                    <span className="leading-relaxed">{error}</span>
                  </div>
                )}

                {/* Repeated rejection of a *correct-looking* code is almost
                    always device clock drift, and that is actionable advice —
                    unlike showing the same generic rejection a third time. */}
                {attempts >= 2 && method === 'totp' && (
                  <div className="mt-3 flex items-start gap-2.5 rounded-[0.625rem] border border-amber-200 bg-amber-50 px-3 py-2.5 text-[0.8125rem] text-amber-800">
                    <Clock3 className="mt-0.5 h-4 w-4 flex-none" strokeWidth={2} />
                    <span className="leading-relaxed">
                      Codes rejected repeatedly? Check that automatic time is enabled on the device running your
                      authenticator — a clock more than 30 seconds out generates codes this server will refuse.
                    </span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={!submittable || mutation.isPending}
                  className="mt-5 flex h-12 w-full items-center justify-center gap-2.5 rounded-[0.625rem] text-[0.9375rem] font-semibold text-white shadow-[0_10px_24px_-10px_rgba(30,124,200,0.75)] transition-[filter,box-shadow] duration-150 hover:brightness-[1.06] active:brightness-95 disabled:cursor-not-allowed disabled:opacity-60"
                  style={{ backgroundImage: 'linear-gradient(90deg, #2FA8E0 0%, #1C79C6 100%)' }}
                >
                  {mutation.isPending ? (
                    <>
                      <Spinner size="h-4 w-4" className="text-white" />
                      Verifying…
                    </>
                  ) : (
                    <>
                      Verify and continue
                      <ArrowRight className="h-[1.05rem] w-[1.05rem]" strokeWidth={2.25} />
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 flex flex-col gap-2.5 border-t border-slate-200 pt-4 sm:flex-row sm:items-center sm:justify-between">
                <button
                  type="button"
                  onClick={() => {
                    clearMfaChallenge()
                    navigate('/login', { replace: true })
                  }}
                  className="inline-flex items-center gap-1.5 text-[0.8125rem] font-medium text-slate-500 transition-colors hover:text-slate-800"
                >
                  <ArrowLeft className="h-[0.95rem] w-[0.95rem]" strokeWidth={2} />
                  Back to sign in
                </button>
                <span className="inline-flex items-center gap-1.5 text-[0.8125rem] text-slate-500">
                  <LifeBuoy className="h-[0.95rem] w-[0.95rem] flex-none text-slate-400" strokeWidth={1.75} />
                  Lost both? Your administrator can re-enrol you.
                </span>
              </div>

              <p className="mt-5 text-center text-xs leading-relaxed text-slate-500">
                Authorized use only. Every verification attempt is recorded in the audit log.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
