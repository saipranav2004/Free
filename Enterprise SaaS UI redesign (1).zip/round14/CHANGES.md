# Round 14

Three files. Drop them in over the same paths.

    src/pages/DashboardPage.jsx
    src/pages/auth/LoginPage.jsx
    src/pages/auth/MfaVerifyPage.jsx

---

## Task 1 — the dashboard sample filter changed nothing

### Root cause

Not a front-end bug. Both audit endpoints clamp how many rows a single request
may return, and they clamp **silently** — the response is 200 OK with no
indication it was trimmed:

| Endpoint | Parameter | Clamp | Where |
|---|---|---|---|
| `GET /api/v1/pam/admin/audit` | `page_size` | **200** | `pagingFrom` at the HTTP layer, and again in `AuditService.List` → `normalisePaging` |
| `GET /api/v1/pam/audit/search` | `limit` | **500** | `AuditQueryService.Search` |

The dashboard was asking for the whole sample in one call
(`page_size: 5000` / `limit: 5000`). The admin view therefore received exactly
200 rows for every option, and the self-service view exactly 500 for the two
largest. Same rows in, same charts out — activity volume, outcomes, most
frequent actions, by category, most active accounts and the denied list were all
recomputed from an identical array, so nothing on screen moved.

### Fix

The sample is now **assembled from consecutive pages** at each endpoint's own
maximum:

* `fetchAuditSample` — walks `page=1,2,3…` at `page_size=200` (admin).
* `fetchSelfAuditSample` — walks `offset` at `limit=500` (self-service).

Both stop at the first of: enough rows for the chosen option, a short page
(history exhausted), `pagination.total_pages` / `total` reached, or a hard
ceiling of 30 requests.

Details that matter:

* **Abort signal is threaded through every request**, so switching the control
  mid-walk cancels the remainder instead of leaving requests in flight.
* **Rows are de-duplicated by `id`.** The log is ordered newest-first, so an
  entry written between page 1 and page 2 shifts the window and would otherwise
  be counted twice — quietly inflating every chart.
* **Offset is tracked from rows received, not rows kept**, so a de-duplicated
  row can't make the next request re-read a window already seen.
* The helpers return the **same shapes** the single calls returned
  (`{ events, pagination }` and `{ items, total }`), so nothing downstream
  changed — no chart, metric or footer code was touched.
* No API contract change. Same endpoints, same parameter names, same envelopes.

The "All available audits" scope text was corrected: it no longer claims to be
one request.

### Cost, stated plainly

"All available" is up to 25 sequential requests on the admin view. The existing
spinner beside the control covers the wait and `placeholderData` keeps the
previous charts on screen while it runs. If that is too slow in your
environment, lower that option's `value` in `EVENT_LIMITS` — it is one number.

---

## Task 2 — login and MFA credential cards

### What was wrong

The card was a white plane bolted to the right edge and stretched to the full
viewport height (`items-stretch`, `lg:w-[46%] lg:max-w-[42rem]`,
`rounded-3xl`), with a 26rem column of content floating in the middle of it.
Three consequences, all visible in your screenshot:

1. most of the white is empty — the form occupies roughly the middle third;
2. the form has no perceptible edge, because the "card" is the size of the
   viewport;
3. the brand field the card is supposed to sit *on* is hidden behind it.

### What premium enterprise sign-in screens actually do

Okta, Azure AD / Entra, CyberArk Identity, Auth0 and Duo all resolve this the
same way: **one modest card, sized to its own content, optically centred,
floating clear of the brand field on all four sides.** The card gets a real
boundary, the field stays visible as context, and the eye lands on the form
because it is the only object with an edge — not because it is the largest area
of white.

### What changed

| | Before | After |
|---|---|---|
| Column | `items-stretch`, 46% / 42rem | `items-center justify-center`, 40% / 33rem (42% / 34rem on MFA) |
| Card | full viewport height, `rounded-3xl`, `px-14` | content height, `rounded-2xl`, `px-8 py-8` |
| Measure | 26rem inside a much wider slab | 25rem (login) / 26rem (MFA) — the card *is* the measure |
| Elevation | one 80px soft shadow | two-layer shadow + `ring-1 ring-slate-900/6` hairline |
| Inputs | 52px | 48px — the enterprise standard, still above the 44px hit target |
| Rhythm | 20–32px gaps | 12–24px, one consistent step tighter |

Login lands at roughly 400×500px, MFA at 416×640px, so **step 1 and step 2 of
sign-in now present the same object at the same optical size** — the flow no
longer appears to change shape between them. MFA fits a 900px-tall laptop
viewport without scrolling.

### Not changed

* **No colour was altered.** `#0A1729`, `#29A8E0`, `#1E7CC8`, the
  `#2FA8E0 → #1C79C6` button gradient, the radial washes, the grid overlay and
  every slate / red / amber / emerald state class are byte-identical. This was
  verified programmatically before the files were written.
* No auth behaviour. Same schema, same `react-hook-form` wiring, same
  mutations, same MFA-challenge branch, same `viaMfaChallenge` evidence flag,
  same redirects.
* No copy, no fields, no structure. Only container sizing, radii, spacing and
  type scale.
