import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { UsersRound, Plus, ChevronRight, Users } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, StatusBadge, EmptyState, Toolbar, SearchInput, IconButton, FormErrorSummary,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { extractList } from '../../utils/format.js';

/**
 * GroupsPage — RBAC group inventory.
 * Same list-page anatomy as Roles and Users so the product feels like one tool.
 */
export default function GroupsPage() {
  const { accountId } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const groups = useResource(() => identityApi.listGroups(accountId), [accountId]);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({ group_name: '', description: '' });

  const data = extractList(groups.data, 'groups');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (g) => g.group_name?.toLowerCase().includes(q) || g.description?.toLowerCase().includes(q)
    );
  }, [data, search]);

  const validate = () => {
    const next = {};
    const name = form.group_name.trim();
    if (!name) next.group_name = 'Group name is required.';
    else if (data.some((g) => g.group_name?.toLowerCase() === name.toLowerCase())) {
      next.group_name = 'A group with this name already exists.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const create = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      await identityApi.createGroup(accountId, form);
      toast.success('Group created.');
      setOpen(false);
      setForm({ group_name: '', description: '' });
      groups.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create group.');
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    {
      id: 'group_name',
      header: 'Group',
      primary: true,
      sortable: true,
      render: (g) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
            <UsersRound className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium text-ink-900">{g.group_name}</p>
            <p className="truncate text-xs text-slate-500">{g.description || 'No description'}</p>
          </div>
        </div>
      ),
    },
    {
      id: 'member_count',
      header: 'Members',
      sortable: true,
      render: (g) => (
        <span className="inline-flex items-center gap-1.5 text-[13px] text-ink-800 tabular">
          <Users className="h-3.5 w-3.5 text-slate-400" />
          {g.member_count ?? 0}
        </span>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      sortable: true,
      render: (g) => <StatusBadge status={g.status} />,
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (g) => (
        <IconButton
          icon={ChevronRight}
          title="Open group"
          tone="brand"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/rbac/groups/${g.group_id}`);
          }}
        />
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Groups"
        description="Organise users and attach roles at scale (RBAC)."
        icon={<UsersRound className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Access control' }, { label: 'Groups' }]}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New group
          </Button>
        }
      />

      <div className="space-y-4">
        <Toolbar
          right={
            <span className="text-2xs text-slate-500 tabular">
              {filtered.length} of {data.length} group{data.length === 1 ? '' : 's'}
            </span>
          }
        >
          <SearchInput value={search} onChange={setSearch} placeholder="Search groups…" />
        </Toolbar>

        {groups.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={groups.loading}
            onRowClick={(g) => navigate(`/rbac/groups/${g.group_id}`)}
            columnsStorageKey="iam-groups-columns"
            empty={{
              icon: UsersRound,
              title: `No groups match “${search}”`,
              description: 'Adjust the search to see more results.',
              action: (
                <Button variant="secondary" onClick={() => setSearch('')}>
                  Clear search
                </Button>
              ),
            }}
          />
        ) : (
          <EmptyState
            icon={UsersRound}
            title="No groups yet"
            description="Create a group to grant access to many users at once."
            action={<Button onClick={() => setOpen(true)}>New group</Button>}
          />
        )}
      </div>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Create group"
        description="Groups collect users so roles can be attached once instead of per person."
        icon={UsersRound}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={create} loading={saving}>
              Create group
            </Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          <FormErrorSummary errors={errors} />
          <Input
            label="Group name"
            value={form.group_name}
            error={errors.group_name}
            onChange={(e) => {
              setForm((f) => ({ ...f, group_name: e.target.value }));
              setErrors((x) => ({ ...x, group_name: undefined }));
            }}
            required
            placeholder="platform-engineering"
          />
          <Input
            label="Description"
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            placeholder="Who belongs in this group"
          />
        </form>
      </Modal>
    </div>
  );
}
