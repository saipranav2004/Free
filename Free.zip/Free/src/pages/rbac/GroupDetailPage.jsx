import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, UserPlus, FileLock2, Users, ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, SearchableCombobox } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

/**
 * GroupDetailPage — View and manage a single group.
 *
 * Shows members and attached policies with full CRUD capabilities.
 * The attach/detach policy functionality matches RoleDetailPage exactly:
 *   - SearchableCombobox for selecting policies
 *   - Attach via rbacApi.attachPolicyToRole (backend group-policy association)
 *   - Detach via rbacApi.detachPolicyFromRoleById
 *   - List refreshes after every action
 */
export default function GroupDetailPage() {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { accountId } = useAuth();

  const group = useResource(
    () => accountId ? identityApi.getGroup(accountId, groupId) : Promise.resolve(null),
    [groupId, accountId]
  );

  // All policies list (for the attach dropdown)
  const policies = useResource(() => pbacApi.listPolicies(), []);

  // Modal states
  const [memberOpen, setMemberOpen] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [disableOpen, setDisableOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // Form states
  const [userId, setUserId] = useState('');
  const [policyId, setPolicyId] = useState('');
  const [form, setForm] = useState({ group_name: '', description: '' });

  // Fetch users for the Add Member combobox
  const usersResource = useResource(
    () => memberOpen ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null,
    [memberOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];
  const userOptions = usersList.map((u) => ({
    id: u.user_id,
    label: u.username || u.email || u.user_id,
    description: u.email,
    badge: u.status,
  }));

  // Policies data for combobox
  const policiesList = Array.isArray(policies.data) ? policies.data : [];
  const policyOptions = policiesList.map((p) => ({
    id: p.policy_id,
    label: p.policy_name,
    description: p.description,
    badge: p.is_system_policy ? 'SYSTEM' : undefined,
  }));

  // Group data extraction
  const data = group.data || {};

  // Extract members from multiple possible field names
  const members = Array.isArray(data.members)
    ? data.members
    : Array.isArray(data.users)
      ? data.users
      : Array.isArray(data.memberships)
        ? data.memberships
        : [];

  // Extract attached policies from multiple possible field names
  const attachedPolicies = Array.isArray(data.policies)
    ? data.policies
    : Array.isArray(data.attached_policies)
      ? data.attached_policies
      : [];

  // Helper to reload all data after mutations
  const reloadAll = () => {
    group.reload();
  };

  const openEdit = () => {
    setForm({ group_name: data.group_name || '', description: data.description || '' });
    setEditOpen(true);
  };

  const addMember = async (e) => {
    e.preventDefault();
    if (!userId) { toast.error('Please select a user.'); return; }
    setBusy(true);
    try {
      await identityApi.addGroupMember(accountId, groupId, userId);
      toast.success('Member added.');
      setMemberOpen(false);
      setUserId('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not add member.');
    } finally {
      setBusy(false);
    }
  };

  const removeMember = async (uid) => {
    try {
      await identityApi.removeGroupMember(accountId, groupId, uid);
      toast.success('Member removed.');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not remove member.');
    }
  };

  // ── Attach Policy (matches RoleDetailPage pattern exactly) ──
  const attachPolicy = async (e) => {
    e.preventDefault();
    if (!policyId) { toast.error('Please select a policy.'); return; }
    setBusy(true);
    try {
      // Use the same RBAC endpoint as RoleDetailPage
      // POST /api/v1/authz/roles/policies/attach with { role_id, policy_id }
      // For groups, we associate the policy via the role mechanism
      await rbacApi.attachPolicyToRole(groupId, policyId);
      toast.success('Policy attached.');
      setPolicyOpen(false);
      setPolicyId('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach policy.');
    } finally {
      setBusy(false);
    }
  };

  // ── Detach Policy (matches RoleDetailPage pattern exactly) ──
  const detachPolicy = async (policyId) => {
    try {
      // Use the same RBAC endpoint as RoleDetailPage
      // DELETE /api/v1/authz/roles/<role_id>/policies/<policy_id>
      await rbacApi.detachPolicyFromRoleById(groupId, policyId);
      toast.success('Policy detached.');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not detach policy.');
    }
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await identityApi.updateGroup(accountId, groupId, form);
      toast.success('Group updated.');
      setEditOpen(false);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not update group.');
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await identityApi.deleteGroup(accountId, groupId);
      toast.success('Group deleted.');
      navigate('/rbac/groups');
    } catch (err) {
      toast.error(err.userMessage || 'Could not delete group.');
    } finally {
      setBusy(false);
      setDisableOpen(false);
    }
  };

  if (group.loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => navigate('/rbac/groups')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Groups
      </button>

      <PageHeader
        title={data.group_name}
        description={data.description}
        icon={<Users className="h-5 w-5" />}
        actions={
          <>
            <Button variant="secondary" onClick={openEdit}>Edit</Button>
            <Button variant="danger" onClick={() => setDisableOpen(true)}>
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
          </>
        }
      />

      {/* Enterprise: summary stats row */}
      <div className="mb-6 grid grid-cols-2 gap-4">
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-brand-50 p-2 text-brand-600">
            <Users className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Members</p>
            <p className="text-lg font-semibold text-ink-900">{members.length}</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
            <FileLock2 className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Attached Policies</p>
            <p className="text-lg font-semibold text-ink-900">{attachedPolicies.length}</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Members Card */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <Users className="h-4 w-4 text-brand-600" /> Members
            </h3>
            <Button size="sm" onClick={() => setMemberOpen(true)}>
              <UserPlus className="h-4 w-4" /> Add
            </Button>
          </div>
          {group.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : members.length ? (
            <ul className="divide-y divide-line-soft">
              {members.map((m) => (
                <li key={m.user_id || m.id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-2xs font-semibold text-brand-700">
                      {m.username?.charAt(0)?.toUpperCase() || '?'}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{m.username}</p>
                      {m.email && <p className="text-xs text-slate-400">{m.email}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeMember(m.user_id || m.id)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <Users className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No members</p>
              <p className="mt-1 text-xs text-slate-500">Add users to this group.</p>
              <Button size="sm" className="mt-3" onClick={() => setMemberOpen(true)}>
                <UserPlus className="h-4 w-4" /> Add member
              </Button>
            </div>
          )}
        </Card>

        {/* Attached Policies Card (matches RoleDetailPage pattern exactly) */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <FileLock2 className="h-4 w-4 text-emerald-600" /> Attached policies
            </h3>
            <Button size="sm" onClick={() => setPolicyOpen(true)}>
              <Plus className="h-4 w-4" /> Attach
            </Button>
          </div>
          {group.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : attachedPolicies.length ? (
            <ul className="divide-y divide-line-soft">
              {attachedPolicies.map((p) => (
                <li key={p.policy_id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-2xs font-semibold text-slate-600">
                      <FileLock2 className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{p.policy_name}</p>
                      {p.description && <p className="text-xs text-slate-400">{p.description}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => detachPolicy(p.policy_id)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <FileLock2 className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No policies attached</p>
              <p className="mt-1 text-xs text-slate-500">Attach policies to define what this group can access.</p>
              <Button size="sm" className="mt-3" onClick={() => setPolicyOpen(true)}>
                <Plus className="h-4 w-4" /> Attach policy
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          MODALS (matching RoleDetailPage pattern exactly)
          ═══════════════════════════════════════════════════════════════════════ */}

      {/* ── Add Member Modal ── */}
      <Modal
        open={memberOpen}
        onClose={() => { setMemberOpen(false); setUserId(''); }}
        title="Add member"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setMemberOpen(false); setUserId(''); }}>Cancel</Button>
            <Button onClick={addMember} loading={busy}>Add</Button>
          </>
        }
      >
        <form onSubmit={addMember} className="space-y-4">
          <SearchableCombobox
            label="User"
            required
            options={userOptions}
            value={userId}
            onChange={setUserId}
            loading={usersResource.loading}
            placeholder="Search users by name or email…"
            hint="Type to filter the tenant directory — the list narrows as you type."
            emptyMessage="No users match that name or email."
          />
        </form>
      </Modal>

      {/* ── Attach Policy Modal (matches RoleDetailPage exactly) ── */}
      <Modal
        open={policyOpen}
        onClose={() => { setPolicyOpen(false); setPolicyId(''); }}
        title="Attach policy"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setPolicyOpen(false); setPolicyId(''); }}>Cancel</Button>
            <Button onClick={attachPolicy} loading={busy}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attachPolicy} className="space-y-4">
          <SearchableCombobox
            label="Policy"
            required
            options={policyOptions}
            value={policyId}
            onChange={setPolicyId}
            loading={policies.loading}
            placeholder="Search policies by name or description…"
            hint="Attaching a policy grants its permissions to every member of this group."
            emptyMessage="No policies match that search."
          />
        </form>
      </Modal>

      {/* ── Edit Group Modal ── */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit group"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={saveEdit} loading={busy}>Save</Button>
          </>
        }
      >
        <form onSubmit={saveEdit} className="space-y-4">
          <Input label="Group name" value={form.group_name} onChange={(e) => setForm((f) => ({ ...f, group_name: e.target.value }))} required />
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
        </form>
      </Modal>

      <ConfirmDialog
        open={disableOpen}
        onClose={() => setDisableOpen(false)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Delete group"
        message="This will permanently delete the group and remove all member and policy associations."
      />
    </div>
  );
}
