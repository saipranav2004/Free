import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The Flask IAM backend listens on :5000. During development we proxy the
// API + JWKS paths so cookies/CSP/origin are never an issue. For production
// builds set VITE_API_BASE_URL to your gateway and remove the proxy.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:5000', changeOrigin: true },
      '/well-known': { target: 'http://localhost:5000', changeOrigin: true },

      // ═════════════════════════════════════════════════════════════════════
      // AdapID (IDP) — SEPARATE service on its own host.
      // ═════════════════════════════════════════════════════════════════════
      // BUG FIX — `{"data":null,"error":"Missing token","success":false}` on a
      // hard reload of an IDP page.
      //
      // This proxy used to be mounted on '/idp', which is ALSO the SPA's own
      // route namespace (/idp/overview, /idp/tenants). The two cannot share a
      // prefix:
      //
      //   · SPA navigation  → no document request, React Router renders the
      //                       page, XHRs to /idp/api/* are proxied. Works.
      //   · F5 / hard reload → the browser asks the dev server for the DOCUMENT
      //                       at /idp/overview. The proxy matched first and
      //                       forwarded it to AdapID, which answered its own
      //                       JSON error ("Missing token") instead of index.html
      //                       — the raw payload seen in the browser.
      //
      // The API prefix is therefore moved to '/idp-api', which no client route
      // can ever collide with. `rewrite` still strips it, because the client
      // requests /idp-api/api/tenants and the service exposes /api/tenants.
      // Mirrored in nginx.conf for production (location /idp-api/).
      '/idp-api': {
        target: 'https://idp.cf.adapid.link/idp',
        changeOrigin: true,
        // The target is HTTPS with a real certificate; keep verification on.
        secure: true,
        rewrite: (path) => path.replace(/^\/idp-api/, ''),
      },
    },
  },
  // NOTE: `build` previously sat INSIDE `server`, where Vite ignores it.
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
