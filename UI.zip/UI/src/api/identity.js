import { http } from '../lib/http'

// Identity Management — the Admin Center's user lifecycle screens
// (/api/v1/pam/admin/identity/*). Admin/root only. Brand new surface: PAM
// now owns user accounts end to end (no external IAM service), so this is
// full user CRUD + lifecycle + RBAC role assignment + PBAC direct policy
// attachment — see identity_handler.go.

export async function listUsers(q, signal) {
  const { data } = await http.get('/api/v1/pam/admin/identity/users', {
    params: q ? { q } : undefined,
    signal,
  })
  return data.data // { users, count }
}

export async function getUser(id, signal) {
  const { data } = await http.get(`/api/v1/pam/admin/identity/users/${id}`, { signal })
  return data.data // { user, access: { roles, policies } }
}

export async function createUser(payload) {
  const { data } = await http.post('/api/v1/pam/admin/identity/users', payload)
  return data.data.user
}

export async function updateUser(id, payload) {
  const { data } = await http.patch(`/api/v1/pam/admin/identity/users/${id}`, payload)
  return data.data.user
}

export async function setUserStatus(id, status) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${id}/status`, { status })
  return data.data
}

export async function deleteUser(id) {
  const { data } = await http.delete(`/api/v1/pam/admin/identity/users/${id}`)
  return data.data
}

export async function resetUserPassword(id, newPassword) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${id}/reset-password`, {
    new_password: newPassword,
  })
  return data.data
}

export async function assignRole(userId, roleName) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${userId}/roles`, {
    role_name: roleName,
  })
  return data.data
}

export async function removeRole(userId, roleName) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${userId}/roles/${encodeURIComponent(roleName)}`
  )
  return data.data
}

export async function attachPolicy(userId, policyId) {
  const { data } = await http.post(`/api/v1/pam/admin/identity/users/${userId}/policies`, {
    policy_id: policyId,
  })
  return data.data
}

export async function detachPolicy(userId, policyId) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${userId}/policies/${policyId}`
  )
  return data.data
}
