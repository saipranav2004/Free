import { http } from '../lib/http'

// Admin Center reads + attributable actions (/api/v1/pam/admin/*) — gated
// server-side by middleware.RequireAdmin (the caller's own JWT "roles"
// claim must include "admin" or "root"). This used to go through a separate
// `adminHttp` client authenticated with a shared X-IAM-Service-Token; that
// entire model is gone. Every call below uses the SAME `http` client and
// the SAME Bearer token as every other authenticated request in the app —
// there is no separate identity to attach, because the acting admin IS the
// logged-in user (see middleware/admin.go's AdminIdentityFromContext).

export async function listJitRequests(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/jit-requests', { params, signal })
  return data.data // { requests, pagination }
}

export async function getJitRequest(id, signal) {
  const { data } = await http.get(`/api/v1/pam/admin/jit-requests/${id}`, { signal })
  return data.data // { request, grant?, audit_trail? }
}

export async function listGrants(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/grants', { params, signal })
  return data.data // { grants, pagination }
}

export async function listSessions(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/sessions', { params, signal })
  return data.data // { sessions, pagination }
}

export async function listRecordings(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/recordings', { params, signal })
  return data.data // { recordings, pagination }
}

export async function listAudit(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/audit', { params, signal })
  return data.data // { events, pagination }
}

// This is the ONLY chain-verification route the backend exposes — there is
// no self-service equivalent under /api/v1/pam/audit/* (confirmed against
// cmd/pam-api/main.go). AuditPage reuses this same function for its
// admin-gated "Chain integrity" card rather than calling a nonexistent
// self-service path. Always wraps its result in the normal envelope
// (verified against admin_handler.go — response.Success is called
// unconditionally, whether res.Valid is true or false), so no bare-response
// special case is needed here.
export async function verifyAudit(orgId, signal) {
  const { data } = await http.get('/api/v1/pam/admin/audit/verify', {
    params: orgId ? { org_id: orgId } : undefined,
    signal,
  })
  return data.data.verification
}

export async function listBreakglass(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/breakglass', { params, signal })
  return data.data // { requests, pagination, grants }
}

export async function getBreakglassReport(grantId, signal) {
  const { data } = await http.get(`/api/v1/pam/admin/breakglass/${grantId}/report`, { signal })
  return data.data.report
}

export async function getStats(signal) {
  const { data } = await http.get('/api/v1/pam/admin/stats', { signal })
  return data.data
}

// ---------------------------------------------------------------------------
// Actions (attributable writes — automatically attributed to the logged-in
// admin/root, no header to forge and no separate identity to propagate)
// ---------------------------------------------------------------------------

// Requires an MFA-verified admin token (backend: RequireMFA on this route).
// Also enforces separation-of-duty (an approver cannot approve their own
// request) — surfaced via apiErrorMessage's normalized message, not a
// special code, so just show it as-is.
export async function approveJitRequest(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/jit-requests/${id}/approve`, { reason })
  return data.data // { request, grant, expires_at }
}

export async function denyJitRequest(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/jit-requests/${id}/deny`, { reason })
  return data.data
}

export async function revokeGrant(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/grants/${id}/revoke`, { reason })
  return data.data // { grant, sessions_killed }
}

export async function killSession(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/sessions/${id}/kill`, { reason })
  return data.data
}
