/**
 * Topbar — Full-width enterprise header spanning the entire viewport.
 *
 * Enterprise research findings (Azure AD / Okta / CyberArk / AWS Console / SailPoint):
 *  - The "L Layout" pattern: topbar spans full width, sidebar sits BELOW it
 *  - Logo anchored far-left as persistent "Home" anchor (every platform does this)
 *  - Logo should be BIG and CLEAN without any box/container wrapper
 *  - Navigation tabs (IAM | IDP | PAM) placed on the RIGHT side
 *    (before profile area, creating balanced enterprise layout)
 *  - Theme toggle (sun/moon) on the right side for quick access
 *  - Clock, notifications, user profile on the far right
 *  - Bar height: 64px (premium enterprise standard for spacious navigation)
 *  - Full-width bar with left-right padding for visual breathing room
 *  - IDP has a dropdown for sub-pages (Okta megamenu-lite pattern)
 *
 * Layout structure (matching Deep Algorithms reference):
 *  ┌──────────────────────────────────────────────────────────────────┐
 *  │ [Logo]              IAM    IDP ▾    PAM    🔔 10:42  🌙  [Avatar]│
 *  ├──────────────────────────────────────────────────────────────────┤
 *  │ [Sidebar] │  Main Content Area                                  │
 *  │           │                                                     │
 *  └──────────────────────────────────────────────────────────────────┘
 *
 * Logo: Big, clean, no box wrapper — raw image for premium enterprise feel
 * Tabs: RIGHT side — positioned before user profile for balanced layout
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Menu, Bell, LogOut, User as UserIcon, ShieldAlert, Clock,
  Smartphone, MonitorSmartphone, Shield, ChevronDown, ChevronRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { initials, classNames } from '../../utils/format.js';
import { isAdmin } from '../../utils/permissions.js';
import { Logo } from '../common/Logo.jsx';

// ─── Navigation Tabs ───
// Enterprise pattern: Main product tabs are big, bold, and visually dominant.
// They sit on the RIGHT side of the header, before the profile area.
const TABS = [
  {
    id: 'iam',
    label: 'IAM',
    description: 'Identity & Access Management',
    to: '/',
  },
  {
    id: 'idp',
    label: 'IDP',
    description: 'Identity Provider Federation',
    children: [
      { label: 'Overview', to: '/idp/overview', description: 'All adopted tenants' },
      { label: 'Tenants', to: '/idp/tenants', description: 'Adopt a new tenant' },
    ],
  },
  {
    id: 'pam',
    label: 'PAM',
    description: 'Privileged Access Management',
    to: '/pam',
  },
];

function getActiveTab(pathname) {
  if (pathname.startsWith('/idp')) return 'idp';
  if (pathname.startsWith('/pam') || pathname === '/audit-logs') return 'pam';
  return 'iam';
}

export function Topbar({ onMenu }) {
  const { user, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  // Profile dropdown state
  const [menuOpen, setMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const menuRef = useRef(null);
  const triggerRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(-1);

  // IDP dropdown state
  const [idpOpen, setIdpOpen] = useState(false);
  const idpDropdownRef = useRef(null);

  const activeTab = getActiveTab(location.pathname);

  // Enterprise: live clock in topbar for security dashboards
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60_000);
    return () => clearInterval(timer);
  }, []);

  // Close profile dropdown on outside click
  useEffect(() => {
    if (!menuOpen) return;
    const handleClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [menuOpen]);

  // Close IDP dropdown on outside click
  useEffect(() => {
    if (!idpOpen) return;
    const handler = (e) => {
      if (idpDropdownRef.current && !idpDropdownRef.current.contains(e.target)) {
        setIdpOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [idpOpen]);

  // Close IDP dropdown on route change
  useEffect(() => {
    setIdpOpen(false);
  }, [location.pathname]);

  // Keyboard navigation for profile dropdown
  const menuItems = [
    { type: 'item', icon: UserIcon, label: 'My Profile', path: '/profile' },
    { type: 'divider' },
    { type: 'header', label: 'Security' },
    { type: 'item', icon: Smartphone, label: 'MFA', path: '/security/mfa' },
    { type: 'item', icon: MonitorSmartphone, label: 'Sessions', path: '/security/sessions' },
    { type: 'divider' },
    { type: 'item', icon: LogOut, label: 'Sign out', action: () => handleLogout(false) },
    { type: 'item', icon: LogOut, label: 'Sign out everywhere', action: () => handleLogout(true), danger: true },
  ];

  const navigableItems = menuItems.filter(i => i.type === 'item');

  const handleKeyDown = useCallback((e) => {
    if (!menuOpen) return;
    switch (e.key) {
      case 'Escape':
        e.preventDefault();
        setMenuOpen(false);
        triggerRef.current?.focus();
        break;
      case 'ArrowDown':
        e.preventDefault();
        setActiveIndex(prev => Math.min(prev + 1, navigableItems.length - 1));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setActiveIndex(prev => Math.max(prev - 1, 0));
        break;
      case 'Enter':
      case ' ':
        if (activeIndex >= 0 && navigableItems[activeIndex]) {
          e.preventDefault();
          const item = navigableItems[activeIndex];
          setMenuOpen(false);
          if (item.action) item.action();
          else if (item.path) navigate(item.path);
        }
        break;
    }
  }, [menuOpen, activeIndex, navigableItems, navigate]);

  useEffect(() => {
    if (menuOpen) setActiveIndex(-1);
  }, [menuOpen]);

  const handleLogout = async (allSessions = false) => {
    await logout(allSessions);
    toast.success('Signed out.');
    navigate('/login', { replace: true });
  };

  const navigateAndClose = (path) => {
    setMenuOpen(false);
    navigate(path);
  };

  return (
    <header
      className="sticky top-0 z-30 flex h-16 w-full items-center border-b border-slate-200 bg-white pl-0 pr-4 lg:pr-6"
      role="banner"
    >
      {/* ── Left: Mobile menu button ── */}
      <button
        onClick={onMenu}
        className="mr-2 rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden"
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* ── Left: Logo — EXTREME LEFT CORNER, BIG, CLEAN, NO BOX WRAPPER ── */}
      {/* Enterprise pattern: Logo sits flush against the extreme left edge
          of the viewport. Zero left padding creates the "anchor" position
          seen in Azure AD, Okta, CyberArk, and AWS Console. */}
      <button
        onClick={() => navigate('/')}
        className="flex shrink-0 items-center pl-0 transition hover:opacity-80"
        title="Go to Dashboard"
      >
        <Logo size="xl" variant="topbar" />
        {/* "IAM Control" text REMOVED per requirements — logo stands alone on the left */}
      </button>

      {/* ── Spacer: pushes everything else to the right ── */}
      <div className="flex-1" />

      {/* ── Right: Navigation Tabs (IAM | IDP | PAM) ── */}
      {/* Enterprise pattern: Tabs are 16-17px, bold weight, generous padding.
          Active state uses a strong brand-colored underline + subtle bg tint.
          RIGHT side placement: positioned before profile for balanced layout. */}
      <nav className="flex items-center gap-1" role="tablist" aria-label="Main navigation">
        {TABS.map((tab) => {
          const isActive = tab.id === activeTab;

          // Tabs with children (IDP dropdown)
          if (tab.children) {
            return (
              <div key={tab.id} className="relative" ref={idpDropdownRef}>
                <button
                  role="tab"
                  aria-selected={isActive}
                  aria-expanded={idpOpen}
                  onClick={() => setIdpOpen((o) => !o)}
                  className={classNames(
                    'relative flex items-center gap-1.5 rounded-lg px-4 py-2 text-[16px] font-bold transition-all duration-150',
                    isActive
                      ? 'text-brand-700 bg-brand-50'
                      : 'text-slate-500 hover:text-ink-800 hover:bg-slate-100'
                  )}
                  title={tab.description}
                >
                  {tab.label}
                  <ChevronDown
                    className={classNames(
                      'h-4 w-4 transition-transform duration-200',
                      idpOpen && 'rotate-180'
                    )}
                  />
                  {/* Active indicator: thick brand-colored underline */}
                  {isActive && (
                    <span className="absolute -bottom-[1px] left-3 right-3 h-[3px] rounded-full bg-brand-600" />
                  )}
                </button>

                {idpOpen && (
                  <div className="absolute left-0 z-50 mt-2 w-56 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl shadow-slate-200/50">
                    <div className="p-1.5">
                      {tab.children.map((child) => {
                        const childActive = location.pathname === child.to;
                        return (
                          <button
                            key={child.to}
                            onClick={() => {
                              navigate(child.to);
                              setIdpOpen(false);
                            }}
                            className={classNames(
                              'flex w-full items-center gap-3 rounded-lg px-3.5 py-2.5 text-left transition-all duration-100',
                              childActive
                                ? 'bg-brand-50 text-brand-700'
                                : 'text-ink-600 hover:bg-slate-50 hover:text-ink-800'
                            )}
                          >
                            <div className="min-w-0 flex-1">
                              <span className="block text-[14px] font-semibold">{child.label}</span>
                              <span className="block text-[12px] text-slate-400">{child.description}</span>
                            </div>
                            <ChevronRight className="h-4 w-4 shrink-0 text-slate-300" />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          }

          // Simple tabs (IAM, PAM)
          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={isActive}
              onClick={() => navigate(tab.to)}
              className={classNames(
                'relative rounded-lg px-4 py-2 text-[16px] font-bold transition-all duration-150',
                isActive
                  ? 'text-brand-700 bg-brand-50'
                  : 'text-slate-500 hover:text-ink-800 hover:bg-slate-100'
              )}
              title={tab.description}
            >
              {tab.label}
              {/* Active indicator: thick brand-colored underline */}
              {isActive && (
                <span className="absolute -bottom-[1px] left-3 right-3 h-[3px] rounded-full bg-brand-600" />
              )}
            </button>
          );
        })}
      </nav>

      {/* ── Divider between tabs and right actions ── */}
      <div className="hidden h-6 w-px mx-3 bg-slate-200 sm:block" />

      {/* ── Right: Global actions + profile ── */}
      <div className="flex items-center gap-2">
        {/* Live clock */}
        <span className="hidden items-center gap-1.5 text-[13px] text-slate-400 sm:inline-flex">
          <Clock className="h-4 w-4" />
          {currentTime.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
        </span>

        {/* MFA warning */}
        {!user?.mfa_enabled && (
          <span className="hidden items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-semibold text-amber-700 ring-1 ring-inset ring-amber-600/20 sm:inline-flex">
            <ShieldAlert className="h-3 w-3" /> MFA off
          </span>
        )}

        {/* Notifications */}
        <button
          className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 transition-colors"
          aria-label="Notifications"
        >
          <Bell className="h-4.5 w-4.5" />
        </button>

        {/* Divider */}
        <div className="hidden h-6 w-px bg-slate-200 sm:block" />

        {/* ── User profile dropdown ── */}
        {/* Enterprise pattern: No visible dropdown arrow — avatar + name IS the affordance.
            Azure AD, Okta, and CyberArk all use this clean approach where the profile
            area itself signals interactivity through hover states and visual grouping. */}
        <div className="relative" ref={menuRef}>
          <button
            ref={triggerRef}
            onClick={() => setMenuOpen((o) => !o)}
            className={classNames(
              'group flex items-center gap-2.5 rounded-lg p-1.5 pr-2 transition-all duration-200',
              menuOpen
                ? 'bg-slate-100 ring-1 ring-slate-200'
                : 'hover:bg-slate-50 hover:ring-1 hover:ring-slate-100'
            )}
            aria-haspopup="true"
            aria-expanded={menuOpen}
            onKeyDown={handleKeyDown}
          >
            {/* Avatar with hover ring effect */}
            <span className={classNames(
              'flex h-8 w-8 items-center justify-center rounded-full text-[12px] font-bold text-white transition-all duration-200',
              menuOpen
                ? 'bg-brand-700 shadow-md shadow-brand-600/30 ring-2 ring-brand-200'
                : 'bg-brand-600 shadow-sm shadow-brand-600/20 group-hover:shadow-md group-hover:shadow-brand-600/25 group-hover:ring-2 group-hover:ring-brand-100'
            )}>
              {initials(user?.username || user?.email || 'U')}
            </span>
            <span className="hidden text-left sm:block">
              <span className="block text-[14px] font-semibold text-ink-900 leading-tight">
                {user?.username || user?.email}
              </span>
              <span className="block text-[12px] text-slate-400 leading-tight">
                {isAdmin(user) ? 'Administrator' : (user?.account_type || 'user')}
              </span>
            </span>
          </button>

          {menuOpen && (
            <div
              className="absolute right-0 z-50 mt-2 w-72 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl shadow-slate-200/50"
              onKeyDown={handleKeyDown}
            >
              {/* User identity header */}
              <div className="border-b border-slate-100 px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-600 text-sm font-bold text-white shadow-sm shadow-brand-600/20">
                    {initials(user?.username || user?.email || 'U')}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-ink-900 truncate">
                      {user?.username || user?.email}
                    </p>
                    <p className="text-xs text-slate-400 truncate">
                      {user?.email}
                    </p>
                  </div>
                  {isAdmin(user) && (
                    <span className="flex items-center gap-1 rounded-full bg-brand-50 px-2 py-0.5 text-[10px] font-semibold text-brand-700 ring-1 ring-inset ring-brand-600/20">
                      <Shield className="h-2.5 w-2.5" />
                      Admin
                    </span>
                  )}
                </div>
              </div>

              {/* Account section */}
              <div className="py-1.5">
                <DropdownItem
                  icon={UserIcon}
                  label="My Profile"
                  onClick={() => navigateAndClose('/profile')}
                  index={0}
                  activeIndex={activeIndex}
                />
              </div>

              <div className="border-t border-slate-100" />

              {/* Security section */}
              <div className="py-1.5">
                <p className="px-4 pt-2 pb-1 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400/80">
                  Security
                </p>
                <DropdownItem
                  icon={Smartphone}
                  label="MFA"
                  onClick={() => navigateAndClose('/security/mfa')}
                  index={1}
                  activeIndex={activeIndex}
                />
                <DropdownItem
                  icon={MonitorSmartphone}
                  label="Sessions"
                  onClick={() => navigateAndClose('/security/sessions')}
                  index={2}
                  activeIndex={activeIndex}
                />
              </div>

              <div className="border-t border-slate-100" />

              {/* Danger actions */}
              <div className="py-1.5">
                <DropdownItem
                  icon={LogOut}
                  label="Sign out"
                  onClick={() => {
                    setMenuOpen(false);
                    handleLogout(false);
                  }}
                  index={3}
                  activeIndex={activeIndex}
                />
                <DropdownItem
                  icon={LogOut}
                  label="Sign out everywhere"
                  onClick={() => {
                    setMenuOpen(false);
                    handleLogout(true);
                  }}
                  danger
                  index={4}
                  activeIndex={activeIndex}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function DropdownItem({ icon: Icon, label, onClick, danger = false, index, activeIndex }) {
  const isActive = index === activeIndex;
  return (
    <button
      type="button"
      onClick={onClick}
      className={classNames(
        'flex w-full items-center gap-2.5 px-4 py-2 text-[13px] font-medium transition-all duration-100',
        danger
          ? isActive
            ? 'bg-rose-50 text-rose-700'
            : 'text-rose-600 hover:bg-rose-50'
          : isActive
            ? 'bg-slate-100 text-ink-800'
            : 'text-ink-600 hover:bg-slate-50 hover:text-ink-800'
      )}
      role="menuitem"
    >
      <Icon className="h-4 w-4 shrink-0" />
      <span>{label}</span>
    </button>
  );
}
