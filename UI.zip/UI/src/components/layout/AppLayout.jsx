import { useState, useCallback, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar.jsx';
import { Topbar } from './Topbar.jsx';
import { classNames } from '../../utils/format.js';

/**
 * Enterprise layout shell — "L Layout" pattern.
 *
 * Research findings (Azure AD / Okta / CyberArk / AWS Console / Google Cloud):
 *  - Topbar spans FULL viewport width (not just the content area)
 *  - Sidebar starts BELOW the topbar (not from viewport top)
 *  - This creates a clean "L" shape: top bar across top, sidebar down left
 *  - Main content fills the remaining space to the right of the sidebar
 *
 * Layout structure:
 *  ┌──────────────────────────────────────────────────────────────────┐
 *  │ Topbar (full width, 64px)                                        │
 *  ├──────────┬───────────────────────────────────────────────────────┤
 *  │ Sidebar  │  Main Content Area                                    │
 *  │ (240px   │  (flex-1, scrollable)                                 │
 *  │  or 64px)│                                                       │
 *  │          │                                                       │
 *  └──────────┴───────────────────────────────────────────────────────┘
 *
 * The topbar sits at the very top of the viewport (sticky z-30).
 * The sidebar is positioned below it (top-16, which is 64px = h-16).
 * Main content has left padding matching sidebar width for alignment.
 */
export function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Enterprise: persist collapsed preference across sessions.
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    try {
      return localStorage.getItem('iam-sidebar-collapsed') === 'true';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('iam-sidebar-collapsed', String(sidebarCollapsed));
    } catch { /* storage unavailable — ignore */ }
  }, [sidebarCollapsed]);

  const toggleCollapse = useCallback(() => setSidebarCollapsed((c) => !c), []);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* ── Topbar: full viewport width, sits at very top ── */}
      <Topbar onMenu={() => setSidebarOpen(true)} />

      {/* ── Content area: sidebar + main content ── */}
      <div className="flex">
        {/* Sidebar: positioned below topbar (top-14) */}
        <Sidebar
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          collapsed={sidebarCollapsed}
          onToggleCollapse={toggleCollapse}
        />

        {/* Main content: must offset left margin to account for the fixed sidebar.
            Fixed elements don't push siblings, so without this the content
            renders behind the sidebar. lg:ml-64 = expanded sidebar (256px),
            lg:ml-16 = collapsed sidebar (64px). */}
        <main
          className={classNames(
            'flex-1 min-w-0 mx-auto max-w-7xl px-4 py-6 lg:px-8',
            sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'
          )}
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
}
