import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  // UserCog,       // ← Delegations icon (section temporarily commented out)
  // UsersRound,    // ← Groups (RBAC) icon (section temporarily commented out)
  ShieldCheck,
  FileLock2,
  Boxes,
  PanelLeftClose,
  PanelLeftOpen,
  ScrollText,
  ShieldAlert,
  Network,
  X,
} from 'lucide-react';
import { classNames } from '../../utils/format.js';
// M365 service registry — unused while the M365 section is disabled.
// import { M365_SERVICES } from '../../pages/integrations/m365/registry.js';
import { Logo } from '../common/Logo.jsx';

/**
 * Sidebar — the persistent working navigation.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO PRODUCTS, TWO SIDEBARS
 * ═══════════════════════════════════════════════════════════════════════════
 * IAM and PAM are different jobs, so they no longer share one tree:
 *
 *   IAM  (default)        Overview → Dashboard
 *                         Identity → Users · Resources
 *                         Access Control → Roles (RBAC) · Policies (PBAC)
 *
 *   PAM  (/pam/*)         Privileged Access → Audit Logs · Alerts
 *                         (each is a page of its own, no tabs)
 *
 *   IDP  (/idp/*)         stays a Topbar dropdown; its contextual section is
 *                         appended so the rail never highlights nothing.
 *
 * Enterprise console conventions applied:
 *  · Sections are labelled by domain so the rail matches the product's IA
 *  · Active item: tinted row + 3px leading accent — survives collapse to the rail
 *  · Collapsible 56px rail with hover tooltips for screen-constrained work
 *  · On mobile it is a real drawer: header, close affordance, scrim
 */

const IAM_NAV = [
  {
    section: 'Overview',
    items: [{ to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true }],
  },
  {
    section: 'Identity',
    items: [
      { to: '/identity/users', label: 'Users', icon: Users },
      // ── Delegations — TEMPORARILY COMMENTED OUT ──────────────────────────
      // The Delegations page is withheld for now. The page file
      // (pages/identity/DelegationsPage.jsx) and its route are intact but
      // commented out in routes/AppRoutes.jsx. Restore by uncommenting this
      // item, the matching route, and the `UserCog` import above.
      // { to: '/identity/delegations', label: 'Delegations', icon: UserCog },
      { to: '/identity/resources', label: 'Resources', icon: Boxes },
    ],
  },
  {
    section: 'Access Control',
    items: [
      // ── Groups (RBAC) — TEMPORARILY COMMENTED OUT ───────────────────────
      // GroupsPage / GroupDetailPage are withheld for now; both page files and
      // their routes are preserved (commented out in routes/AppRoutes.jsx).
      // Restore by uncommenting this item, the matching routes, and the
      // `UsersRound` import above.
      // { to: '/rbac/groups', label: 'Groups (RBAC)', icon: UsersRound },
      { to: '/rbac/roles', label: 'Roles (RBAC)', icon: ShieldCheck },
      { to: '/pbac/policies', label: 'Policies (PBAC)', icon: FileLock2 },
    ],
  },
  // ── Microsoft 365 + Oracle — TEMPORARILY DISABLED ────────────────────────
  // Both navigation sections are commented out alongside their routes.
  // Restore by uncommenting these blocks and the imports above.
  // {
  //   section: 'Microsoft 365',
  //   items: [
  //     { to: '/integrations/m365', label: 'M365 Overview', icon: Cloud, end: true },
  //     ...M365_SERVICES.map((s) => ({
  //       to: `/integrations/m365/${s.id}`,
  //       label: s.name,
  //       icon: s.icon,
  //     })),
  //   ],
  // },
  // {
  //   section: 'Oracle',
  //   items: [{ to: '/integrations/oracle', label: 'Oracle DB', icon: Database }],
  // },
];

/** PAM sidebar — the audit trail and the denial alerts, as separate pages. */
const PAM_NAV = [
  {
    section: 'Privileged Access',
    items: [
      { to: '/pam/audit-logs', label: 'Audit Logs', icon: ScrollText },
      { to: '/pam/alerts', label: 'Alerts', icon: ShieldAlert },
    ],
  },
];

const IDP_SECTION = {
  section: 'Identity Provider',
  items: [
    { to: '/idp/overview', label: 'Federation Overview', icon: Network },
    { to: '/idp/tenants', label: 'Tenants', icon: Boxes },
  ],
};

function NavItem({ item, collapsed, onNavigate }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.to}
      end={item.end}
      onClick={onNavigate}
      className={({ isActive }) =>
        classNames(
          'group/nav relative flex items-center rounded-lg text-[13px] font-medium transition-colors duration-100',
          collapsed ? 'justify-center px-1.5 py-2' : 'gap-2.5 px-3 py-2',
          isActive
            ? 'bg-brand-50 text-brand-800'
            : 'text-slate-600 hover:bg-slate-100/80 hover:text-ink-900'
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive && (
            <span className="absolute inset-y-1.5 left-0 w-[3px] rounded-r-full bg-brand-600" />
          )}
          {Icon && (
            <Icon
              className={classNames(
                'h-4 w-4 shrink-0',
                isActive ? 'text-brand-700' : 'text-slate-400 group-hover/nav:text-slate-600'
              )}
            />
          )}
          {!collapsed && <span className="truncate">{item.label}</span>}
          {collapsed && (
            <span className="pointer-events-none absolute left-full z-50 ml-2 hidden whitespace-nowrap rounded-lg bg-ink-900 px-2.5 py-1.5 text-2xs font-medium text-white shadow-popover group-hover/nav:block">
              {item.label}
            </span>
          )}
        </>
      )}
    </NavLink>
  );
}

export function Sidebar({ open, onClose, collapsed, onToggleCollapse }) {
  const { pathname } = useLocation();

  /* Which product is the operator in? PAM gets its own dedicated rail; IDP
     appends its federation section above the IAM tree (the IDP entry point
     itself remains the Topbar dropdown). */
  const inPam = pathname.startsWith('/pam') || pathname === '/audit-logs';
  const inIdp = pathname.startsWith('/idp');

  const groups = inPam ? PAM_NAV : inIdp ? [IDP_SECTION, ...IAM_NAV] : IAM_NAV;

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-40 bg-ink-900/40 backdrop-blur-[2px] animate-fade-in lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        aria-label={inPam ? 'Privileged access navigation' : 'Main navigation'}
        className={classNames(
          'fixed left-0 z-40 flex flex-col border-r border-line bg-white transition-[width,transform] duration-200 ease-out',
          'top-0 bottom-0 w-[17rem] lg:top-14',
          collapsed ? 'lg:w-14' : 'lg:w-64',
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Drawer header — mobile only (desktop keeps the logo in the topbar) */}
        <div className="flex h-14 shrink-0 items-center justify-between border-b border-line px-4 lg:hidden">
          <Logo variant="appbar" />
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
            aria-label="Close navigation"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>

        <nav className={classNames(
          "flex-1 overflow-y-auto overflow-x-hidden py-4",
          collapsed ? "px-1 space-y-1" : "px-2.5 space-y-5"
        )}>
          {groups.map((group, gi) => (
            <div key={group.section}>
              {!collapsed ? (
                <p className="px-3 pb-1.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                  {group.section}
                </p>
              ) : (
                gi > 0 && <div className="mx-2 mb-2 border-t border-line-soft" />
              )}
              <div className="space-y-0.5">
                {group.items.map((item) => (
                  <NavItem key={item.to} item={item} collapsed={collapsed} onNavigate={onClose} />
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div
          className={classNames(
            'flex shrink-0 items-center border-t border-line px-2.5 py-2.5',
            collapsed ? 'justify-center' : 'justify-between'
          )}
        >
          {!collapsed && (
            <span className="pl-1 text-3xs font-semibold uppercase tracking-[0.12em] text-slate-400">
              {inPam ? 'PAM Console' : 'IAM Control Center'}
            </span>
          )}
          <button
            type="button"
            onClick={onToggleCollapse}
            className="hidden h-7 w-7 shrink-0 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700 lg:flex"
            aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}
            title={collapsed ? 'Expand navigation' : 'Collapse navigation'}
          >
            {collapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </button>
        </div>
      </aside>
    </>
  );
}
