import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  UserCog,
  Rocket,
  UsersRound,
  ShieldCheck,
  FileLock2,
  Boxes,
  Cloud,
  Database,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { classNames } from '../../utils/format.js';
import { M365_SERVICES } from '../../pages/integrations/m365/registry.js';

const NAV = [
  { section: 'Overview', items: [{ to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true }] },
  {
    section: 'Identity',
    items: [
      { to: '/identity/users', label: 'Users', icon: Users },
      { to: '/identity/delegations', label: 'Delegations', icon: UserCog },
      { to: '/identity/resources', label: 'Resources', icon: Boxes },
      // Admin Bootstrap — hidden from sidebar navigation per requirements.
      // The page still exists at /identity/bootstrap for direct URL access.
      // { to: '/identity/bootstrap', label: 'Admin Bootstrap', icon: Rocket },
    ],
  },
  {
    section: 'Access Control',
    items: [
      { to: '/rbac/groups', label: 'Groups (RBAC)', icon: UsersRound },
      { to: '/rbac/roles', label: 'Roles (RBAC)', icon: ShieldCheck },
      { to: '/pbac/policies', label: 'Policies (PBAC)', icon: FileLock2 },
    ],
  },
  {
    section: 'Microsoft 365',
    items: [
      { to: '/integrations/m365', label: 'M365 Overview', icon: Cloud, end: true },
      ...M365_SERVICES.map((s) => ({
        to: `/integrations/m365/${s.id}`,
        label: s.name,
        icon: s.icon,
      })),
    ],
  },
  {
    section: 'Oracle',
    items: [
      { to: '/integrations/oracle', label: 'Oracle DB', icon: Database },
    ],
  },
  // PIM/PAM section removed — moved to top Navbar as PAM tab per enterprise UX conventions.
];

/**
 * Premium enterprise sidebar — sits BELOW the topbar (L-layout pattern).
 *
 * Enterprise research findings (Azure AD / Okta / CyberArk / AWS Console):
 *  - Sidebar starts below the topbar, NOT from viewport top
 *  - Full-height sidebar (minus topbar height) for maximum navigation space
 *  - Left accent bar on active items (3px brand-colored bar + subtle bg)
 *  - Subtle shadow depth for visual hierarchy
 *  - Refined section headers with proper typography
 *  - Smooth hover transitions with micro-interactions
 *  - No logo in sidebar header — logo is in the topbar (every enterprise platform)
 *  - Collapsible to icon-only rail (48-64px) for screen real estate
 *  - Dark mode support for professional appearance
 *
 * Layout:
 *  ┌──────────────────────────────────────────────────────────┐
 *  │ Topbar (full width, 64px, contains logo + tabs + profile)│
 *  ├──────────┬───────────────────────────────────────────────┤
 *  │ Sidebar  │  Main Content                                 │
 *  │ (240px)  │                                               │
 *  │          │                                               │
 *  └──────────┴───────────────────────────────────────────────┘
 */
export function Sidebar({ open, onClose, collapsed, onToggleCollapse }) {
  return (
    <>
      {/* Mobile backdrop overlay */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-ink-900/40 backdrop-blur-sm transition-opacity lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={classNames(
          'fixed left-0 z-40 flex flex-col border-r transition-all duration-200 ease-in-out',
          'shadow-[2px_0_8px_rgba(0,0,0,0.04)] border-slate-200 bg-white',
          // Start below topbar (64px / h-16) — this is the key L-layout fix
          'top-16',
          // Full height minus topbar
          'bottom-0',
          collapsed ? 'w-16' : 'w-64',
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Compact header with collapse toggle — no logo (logo is in topbar) */}
        <div className="flex items-center justify-end border-b border-slate-100 px-2 py-2">
          {/* Enterprise: collapse/expand toggle — hidden on mobile, visible on lg+ */}
          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-all duration-150"
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? (
              <PanelLeftOpen className="h-4 w-4" />
            ) : (
              <PanelLeftClose className="h-4 w-4" />
            )}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-5 overflow-y-auto overflow-x-hidden px-2 py-3">
          {NAV.map((group) => (
            <div key={group.section}>
              {/* Premium: refined section headers with better typography */}
              {!collapsed && (
                <p className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400/80">
                  {group.section}
                </p>
              )}
              <div className={classNames('space-y-0.5', collapsed && 'mt-1')}>
                {group.items.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    onClick={onClose}
                    title={collapsed ? item.label : undefined}
                    className={({ isActive }) =>
                      classNames(
                        'group/nav relative flex items-center rounded-lg transition-all duration-150',
                        collapsed
                          ? 'justify-center px-2 py-2.5'
                          : 'gap-2.5 px-3 py-2',
                        'text-[13px] font-medium',
                        isActive
                          ? 'bg-brand-50/80 text-brand-700 before:absolute before:left-0 before:top-1.5 before:bottom-1.5 before:w-[3px] before:rounded-full before:bg-brand-600'
                          : 'text-slate-500 hover:bg-slate-50 hover:text-ink-800'
                      )
                    }
                  >
                    <item.icon className="h-[18px] w-[18px] shrink-0 transition-colors duration-150" />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                    {/* Tooltip for collapsed state */}
                    {collapsed && (
                      <span className="pointer-events-none absolute left-full z-50 ml-2 hidden whitespace-nowrap rounded-lg bg-ink-900 px-2.5 py-1.5 text-xs font-medium text-white shadow-lg group-hover/nav:inline-flex">
                        {item.label}
                      </span>
                    )}
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>

        {/* Premium: footer branding with refined styling */}
        <div className="border-t border-slate-100/80 px-3 py-3">
          {!collapsed ? (
            <div className="text-center">
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-300/90">
                IAM Control Center
              </p>
            </div>
          ) : (
            <p className="text-center text-[8px] font-bold uppercase tracking-widest text-slate-300/90">
              IAM
            </p>
          )}
        </div>
      </aside>
    </>
  );
}
