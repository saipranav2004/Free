/**
 * @deprecated — This component is NOT currently rendered anywhere.
 * The navigation tabs are implemented inline in Topbar.jsx instead.
 * This file is kept for reference only and uses `fixed` positioning
 * that would conflict with the Topbar's `sticky` positioning.
 *
 * TopNavTabs — Enterprise top-level navigation tabs (IAM | IDP | PAM).
 *
 * Pattern: Azure AD / Okta / CyberArk use top-level product tabs to separate
 * IAM (identity & access), IDP (identity provider federation), and PAM
 * (privileged access management) into distinct navigation contexts.
 *
 * Each tab switches the entire sidebar context below it. The active tab is
 * highlighted with a bottom accent bar. IDP has a dropdown for sub-pages.
 */
import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';
import { classNames } from '../../utils/format.js';

const TABS = [
  {
    id: 'iam',
    label: 'IAM',
    description: 'Identity & Access Management',
    to: '/',
  },
  {
    id: 'idp',
    label: 'IDP',
    description: 'Identity Provider Federation',
    children: [
      { label: 'Overview', to: '/idp/overview', description: 'All added tenants' },
      { label: 'Tenants', to: '/idp/tenants', description: 'Add a new tenant' },
    ],
  },
  {
    id: 'pam',
    label: 'PAM',
    description: 'Privileged Access Management',
    to: '/pam',
  },
];

/**
 * Determine which top tab is active based on the current route.
 * IDP routes match the IDP tab; /audit-logs matches PAM; everything else = IAM.
 */
function getActiveTab(pathname) {
  if (pathname.startsWith('/idp')) return 'idp';
  if (pathname.startsWith('/pam') || pathname === '/audit-logs') return 'pam';
  return 'iam';
}

export function TopNavTabs() {
  const navigate = useNavigate();
  const location = useLocation();
  const [idpOpen, setIdpOpen] = useState(false);
  const dropdownRef = useRef(null);
  const activeTab = getActiveTab(location.pathname);

  // Close dropdown on outside click
  useEffect(() => {
    if (!idpOpen) return;
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIdpOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [idpOpen]);

  // Close dropdown on route change
  useEffect(() => {
    setIdpOpen(false);
  }, [location.pathname]);

  return (
    <nav className="fixed inset-x-0 top-0 z-50 flex h-12 items-center gap-1 border-b border-slate-200 bg-white/90 px-4 backdrop-blur-sm lg:px-6">
      {/* Brand logo area — small separator */}
      <div className="mr-3 hidden items-center border-r border-slate-200 pr-3 lg:flex">
        <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
          Control Center
        </span>
      </div>

      {TABS.map((tab) => {
        const isActive = tab.id === activeTab;

        // Tabs with children (dropdown)
        if (tab.children) {
          return (
            <div key={tab.id} className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIdpOpen((o) => !o)}
                className={classNames(
                  'relative flex items-center gap-1.5 px-3 py-2.5 text-[13px] font-semibold transition-all duration-150',
                  isActive
                    ? 'text-brand-700'
                    : 'text-slate-500 hover:text-ink-700 hover:bg-slate-50 rounded-lg'
                )}
                title={tab.description}
              >
                {tab.label}
                <ChevronDown
                  className={classNames(
                    'h-3.5 w-3.5 transition-transform duration-200',
                    idpOpen && 'rotate-180'
                  )}
                />
                {/* Active indicator: bottom accent bar */}
                {isActive && (
                  <span className="absolute bottom-0 left-3 right-3 h-[2px] rounded-full bg-brand-600" />
                )}
              </button>

              {idpOpen && (
                <div className="absolute left-0 z-50 mt-1 w-56 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl shadow-slate-200/50">
                  <div className="p-1.5">
                    {tab.children.map((child) => {
                      const childActive = location.pathname === child.to;
                      return (
                        <button
                          key={child.to}
                          onClick={() => {
                            navigate(child.to);
                            setIdpOpen(false);
                          }}
                          className={classNames(
                            'flex w-full flex-col rounded-lg px-3 py-2 text-left transition-all duration-100',
                            childActive
                              ? 'bg-brand-50 text-brand-700'
                              : 'text-ink-600 hover:bg-slate-50 hover:text-ink-800'
                          )}
                        >
                          <span className="text-[13px] font-medium">{child.label}</span>
                          <span className="text-[11px] text-slate-400">{child.description}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        }

        // Simple tabs (no children)
        return (
          <button
            key={tab.id}
            onClick={() => navigate(tab.to)}
            className={classNames(
              'relative px-3 py-2.5 text-[13px] font-semibold transition-all duration-150 rounded-lg',
              isActive
                ? 'text-brand-700'
                : 'text-slate-500 hover:text-ink-700 hover:bg-slate-50'
            )}
            title={tab.description}
          >
            {tab.label}
            {/* Active indicator: bottom accent bar */}
            {isActive && (
              <span className="absolute bottom-0 left-3 right-3 h-[2px] rounded-full bg-brand-600" />
            )}
          </button>
        );
      })}
    </nav>
  );
}
