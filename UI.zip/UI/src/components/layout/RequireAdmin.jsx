import { useAuth } from '../../context/AuthContext.jsx';
import { isAdminAccountType } from '../../utils/permissions.js';
import { Spinner, Button, Card } from '../ui/primitives.jsx';
import { ShieldAlert, ArrowLeft, Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

/**
 * RequireAdmin — administrator-only route gate.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * ACCESS MODEL
 * ═══════════════════════════════════════════════════════════════════════════
 * Identity-provider federation decides how an entire tenant authenticates, so
 * it is an administrator surface. The decision is taken from ONE input — the
 * `account_type` field of the Get-User-Details response:
 *
 *     GET /api/v1/identity/accounts/<account_id>/users/<user_id>
 *     → { data: { account_type: "admin", … } }
 *
 * `account_type === 'admin'` → full access. Anything else → the Access
 * Restricted panel below. The navigation entries are deliberately NOT hidden:
 * the menu item and the pages remain discoverable, and a non-admin who opens
 * one is told plainly why they cannot proceed.
 *
 * Server-side authorisation remains the real authority; this only controls what
 * the UI renders, and it never exposes internal detail.
 * ═══════════════════════════════════════════════════════════════════════════
 */
export function RequireAdmin({ children, area = 'This area' }) {
  const { accountType, accountTypeLoading, bootstrapping, user } = useAuth();
  const navigate = useNavigate();

  /* The account type is still being read; deciding now would flash a false
     denial at a genuine administrator on every hard refresh. */
  if (bootstrapping || !user || (accountTypeLoading && !accountType)) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-7 w-7" />
      </div>
    );
  }

  if (!isAdminAccountType(accountType)) {
    return (
      <div className="mx-auto max-w-xl py-10">
        <Card className="px-6 py-8 text-center sm:px-10 sm:py-10">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
            <ShieldAlert className="h-6 w-6" />
          </span>
          <h1 className="mt-5 text-[17px] font-semibold text-ink-900">Access Restricted</h1>
          <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-slate-500">
            {area} is available to tenant administrators only. Your account does not have
            administrator privileges for this tenant, so identity-provider federation cannot be
            viewed or changed here.
          </p>
          <p className="mx-auto mt-4 flex max-w-md items-center justify-center gap-2 rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2 text-2xs text-slate-500">
            <Lock className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            Ask a tenant administrator to grant access if you need this area.
          </p>
          <div className="mt-6 flex justify-center">
            <Button variant="secondary" onClick={() => navigate('/')}>
              <ArrowLeft className="h-4 w-4" />
              Back to dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return children;
}
