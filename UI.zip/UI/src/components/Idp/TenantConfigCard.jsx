/**
 * TenantConfigCard — one adopted IDP tenant, with everything an admin can do
 * to it: SAML endpoint values, Microsoft Graph credentials + directory sync,
 * the federation switch, and the MFA policy.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS IS SHARED
 * ═══════════════════════════════════════════════════════════════════════════
 * The AdapID app deliberately rendered one card from `static/tenant_cards.js`
 * on BOTH surfaces — the Overview page (every tenant) and step 4 of the adopt
 * wizard (the tenant just adopted). This is the React port of that module, so
 * the two pages cannot drift apart: fix the sync report here and both surfaces
 * get it.
 *
 * Platform differences, straight from the source:
 *  · Entra   → Graph credentials, directory sync, federation switch.
 *              The switch stays DISABLED until the first successful sync — the
 *              service cannot federate a domain it has never read.
 *  · Google  → no Graph, no federation; the SP consumes published metadata,
 *              so the metadata URL is surfaced for Google and not for Entra.
 *  · Deprecated tenants expose no mutating controls at all.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Cloud, ChevronDown, ChevronUp, ExternalLink, Copy, RefreshCw, Link2,
  ShieldCheck, KeyRound, AlertTriangle,
} from 'lucide-react';
import {
  samlEndpoints, getFederationStatus, toggleFederation, saveGraphCredentials,
  testGraphConnection, syncDirectory, getSyncStatus, saveMfaConfig,
} from '../../lib/api/idp.js';
import { useToast } from '../../context/ToastContext.jsx';
import { Card, Button, Input, Select, Badge, IconButton } from '../ui/primitives.jsx';
import { classNames } from '../../utils/format.js';

/* ── Microsoft Entra — TEMPORARILY DISABLED ────────────────────────────────
   Graph credentials, directory sync and the federation switch are switched off
   behind this flag rather than deleted. An already-adopted Entra tenant still
   shows its identity and SAML endpoints (read-only facts an operator may need);
   only the mutating Entra controls are withheld. Flip to `true` to restore. */
const ENTRA_ENABLED = false;

const isGoogle = (t) => String(t?.platform || '').toLowerCase() === 'google';
const isDeprecated = (t) => !!t?.deprecated || t?.consent_state === 'deprecated';

const PLATFORM_LABEL = {
  entra: 'Microsoft Entra',
  entraid: 'Microsoft Entra',
  google: 'Google Workspace',
};

/** consent_state → badge tone, so state reads the same on both surfaces. */
function stateTone(tenant) {
  if (isDeprecated(tenant)) return 'red';
  if (tenant?.consent_state === 'adopted') return 'green';
  return 'amber';
}

function EndpointRow({ label, value, external = false }) {
  const toast = useToast();
  if (!value) return null;
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(`${label} copied.`);
    } catch {
      toast.error('Clipboard is unavailable in this browser.');
    }
  };
  return (
    <div className="flex items-start gap-2 py-1">
      <span className="w-[124px] shrink-0 text-2xs font-medium uppercase tracking-[0.06em] text-slate-400">
        {label}
      </span>
      <code className="min-w-0 flex-1 break-all font-mono text-xs text-brand-700">{value}</code>
      <span className="flex shrink-0 items-center gap-0.5">
        <IconButton icon={Copy} title={`Copy ${label}`} size="xs" onClick={copy} />
        {external && (
          <a
            href={value}
            target="_blank"
            rel="noreferrer noopener"
            title="Open in a new tab"
            className="inline-flex h-6 w-6 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
          >
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}
      </span>
    </div>
  );
}

function DetailRow({ label, value }) {
  return (
    <div className="flex items-start gap-2 py-1">
      <span className="w-[124px] shrink-0 text-2xs font-medium uppercase tracking-[0.06em] text-slate-400">
        {label}
      </span>
      <code className="min-w-0 flex-1 break-all font-mono text-xs text-ink-800">{value || '—'}</code>
    </div>
  );
}

/** Sync job report — the five numbers the job returns, laid out as a KPI row. */
function SyncReport({ job }) {
  if (!job) return null;
  const cells = [
    ['Pulled', job.pulled],
    ['Stored', job.local_upserts],
    ['Backfilled', job.backfilled],
    ['Conflicts', job.conflicts_count],
    ['Errors', job.errors_count],
  ];
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
      {cells.map(([label, value]) => (
        <div key={label} className="rounded-lg border border-line-soft bg-slate-50/70 px-2.5 py-2">
          <p className="text-3xs font-semibold uppercase tracking-[0.08em] text-slate-400">{label}</p>
          <p
            className={classNames(
              'mt-0.5 text-[15px] font-semibold tabular',
              label === 'Errors' && Number(value) > 0 ? 'text-rose-600' : 'text-ink-900'
            )}
          >
            {value ?? 0}
          </p>
        </div>
      ))}
    </div>
  );
}

export function TenantConfigCard({
  tenant,
  mfaMethods,
  defaultExpanded = false,
  showDetails = false,
  onChanged,
}) {
  const toast = useToast();
  const t = tenant || {};
  const google = isGoogle(t);
  const deprecated = isDeprecated(t);
  const [expanded, setExpanded] = useState(defaultExpanded);

  // Federation
  const [fedStatus, setFedStatus] = useState(null);
  const [fedBusy, setFedBusy] = useState(false);

  // Graph credentials
  const [clientId, setClientId] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [graphBusy, setGraphBusy] = useState(null); // 'test' | 'save' | null
  const [graphMsg, setGraphMsg] = useState(null); // { tone, text }

  // Directory sync
  const [syncMsg, setSyncMsg] = useState(null);
  const [syncJob, setSyncJob] = useState(null);
  const [syncing, setSyncing] = useState(false);
  const pollRef = useRef(null);

  // MFA policy
  const [mfaPrimary, setMfaPrimary] = useState(t.mfa_method || 'behaviour');
  const [stepupMode, setStepupMode] = useState(t.stepup_mode || 'external');
  const [stepupMethod, setStepupMethod] = useState(t.stepup_method || 'dummy_approve');
  const [mfaBusy, setMfaBusy] = useState(false);
  const [mfaMsg, setMfaMsg] = useState(null);

  // Keep the policy selects in step when the tenant is re-read from the server.
  useEffect(() => {
    setMfaPrimary(t.mfa_method || 'behaviour');
    setStepupMode(t.stepup_mode || 'external');
    setStepupMethod(t.stepup_method || 'dummy_approve');
  }, [t.tenant_id, t.mfa_method, t.stepup_mode, t.stepup_method]);

  // Never leave a poll running behind an unmounted card.
  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  const refreshFederation = useCallback(async () => {
    if (!ENTRA_ENABLED || google || deprecated) return;
    try {
      setFedStatus(await getFederationStatus(t.tenant_id));
    } catch {
      /* federation status is advisory — a failure must not break the card */
    }
  }, [google, deprecated, t.tenant_id]);

  // Federation status is only meaningful for an expanded Entra tenant.
  useEffect(() => {
    if (!expanded) return;
    refreshFederation();
  }, [expanded, refreshFederation]);

  const endpoints = samlEndpoints(t.platform, t.tenant_id);
  const federated = fedStatus?.status?.authentication_type === 'Federated';
  const canFederate = !!fedStatus?.has_synced;

  const handleFederationToggle = async () => {
    const turningOn = !federated;
    const question = turningOn
      ? 'Turn federation ON? This converts the domain to Federated in Entra.'
      : 'Turn federation OFF? This reverts the domain to Managed.';
    if (!window.confirm(question)) return;

    setFedBusy(true);
    try {
      const d = await toggleFederation(t.tenant_id, turningOn);
      if (d?.ok === false) throw new Error(d.error || 'Federation change failed.');
      toast.success(turningOn ? 'Domain federated.' : 'Domain reverted to Managed.');
      // Read the real state back rather than assuming the optimistic one.
      await refreshFederation();
      onChanged?.();
    } catch (err) {
      toast.error(err.userMessage || 'Could not change federation.');
    } finally {
      setFedBusy(false);
    }
  };

  const handleGraphTest = async () => {
    if (!clientId.trim() || !clientSecret.trim()) {
      setGraphMsg({ tone: 'err', text: 'Enter both the client ID and secret to test.' });
      return;
    }
    setGraphBusy('test');
    setGraphMsg({ tone: 'info', text: 'Contacting Microsoft Graph…' });
    try {
      const d = await testGraphConnection(t.tenant_id, clientId.trim(), clientSecret.trim());
      if (d?.ok) {
        setGraphMsg({ tone: 'ok', text: `Connected — read ${d.sample_count ?? 0} user(s).` });
      } else {
        setGraphMsg({
          tone: 'err',
          text: `Failed at ${d?.stage || 'request'}: ${d?.detail || d?.error || 'unknown error'}`,
        });
      }
    } catch (err) {
      setGraphMsg({ tone: 'err', text: err.userMessage || 'Connection test failed.' });
    } finally {
      setGraphBusy(null);
    }
  };

  const handleGraphSave = async () => {
    if (!clientId.trim() || !clientSecret.trim()) {
      setGraphMsg({ tone: 'err', text: 'Enter both the client ID and secret to save.' });
      return;
    }
    setGraphBusy('save');
    try {
      await saveGraphCredentials(t.tenant_id, clientId.trim(), clientSecret.trim());
      // The secret is write-only from here on — clear it from the DOM.
      setClientSecret('');
      setGraphMsg({ tone: 'ok', text: 'Credentials saved (encrypted at rest).' });
      toast.success('Graph credentials saved.');
    } catch (err) {
      setGraphMsg({ tone: 'err', text: err.userMessage || 'Could not save credentials.' });
    } finally {
      setGraphBusy(null);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    setSyncJob(null);
    setSyncMsg({ tone: 'info', text: 'Starting directory sync…' });
    try {
      const d = await syncDirectory(t.tenant_id);
      const jobId = d?.job_id;
      if (!jobId) throw new Error(d?.error || 'Could not start the sync.');

      if (pollRef.current) clearInterval(pollRef.current);
      pollRef.current = setInterval(async () => {
        try {
          const jd = await getSyncStatus(t.tenant_id, jobId);
          const job = jd?.job;
          if (!job) return;
          setSyncJob(job);
          const label = {
            queued: 'Queued…',
            running: 'Syncing directory…',
            succeeded: 'Sync complete.',
            failed: 'Sync failed.',
          }[job.status] || job.status;
          const tone = job.status === 'succeeded' ? 'ok' : job.status === 'failed' ? 'err' : 'info';
          setSyncMsg({ tone, text: label });

          if (job.status === 'succeeded' || job.status === 'failed') {
            clearInterval(pollRef.current);
            pollRef.current = null;
            setSyncing(false);
            // A successful sync is what unlocks the federation switch.
            if (job.status === 'succeeded') {
              await refreshFederation();
              onChanged?.();
            }
          }
        } catch {
          /* transient poll failure — the next tick retries */
        }
      }, 2000);
    } catch (err) {
      // 409 is the service's "a sync is already running" answer.
      const conflict = err?.response?.status === 409;
      setSyncMsg({
        tone: 'err',
        text: conflict
          ? 'A sync is already running for this tenant.'
          : err.userMessage || 'Could not start the sync.',
      });
      setSyncing(false);
    }
  };

  const handleMfaSave = async () => {
    setMfaBusy(true);
    setMfaMsg(null);
    try {
      const r = await saveMfaConfig(t.tenant_id, {
        mfa_method: mfaPrimary,
        stepup_mode: stepupMode,
        stepup_method: stepupMethod,
      });
      if (r?.saved) {
        setMfaMsg({
          tone: 'ok',
          text:
            `Saved — primary ${r.mfa_method}, step-up ${r.stepup_mode}` +
            (r.stepup_mode === 'idp' ? ` (${r.stepup_method})` : '') + '.',
        });
        toast.success('MFA policy saved.');
        onChanged?.();
      } else {
        setMfaMsg({ tone: 'err', text: `Failed: ${r?.error || 'unknown error'}` });
      }
    } catch (err) {
      setMfaMsg({ tone: 'err', text: err.userMessage || 'Could not save the MFA policy.' });
    } finally {
      setMfaBusy(false);
    }
  };

  const methods = mfaMethods || { primary: [], stepup: [], modes: ['external', 'idp'] };
  const platformLabel = PLATFORM_LABEL[String(t.platform || '').toLowerCase()] || t.platform || '—';

  const msgClass = (tone) =>
    classNames(
      'text-xs leading-snug',
      tone === 'ok' ? 'text-emerald-700' : tone === 'err' ? 'text-rose-600' : 'text-slate-500'
    );

  return (
    <Card className="overflow-hidden">
      {/* ── Header: identity + state, click to expand ── */}
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
        className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left transition-colors hover:bg-slate-50 focus-visible:outline-none"
      >
        <div className="flex min-w-0 items-center gap-3">
          <span
            className={classNames(
              'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
              google ? 'bg-emerald-50 text-emerald-600' : 'bg-brand-50 text-brand-700'
            )}
          >
            <Cloud className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-ink-900">
              {t.display_name || t.tenant_id}
            </p>
            <p className="truncate text-xs text-slate-500">
              {t.verified_domain || '(no domain)'} · {platformLabel}
              {!showDetails && (
                <>
                  {' · schema '}
                  <code className="font-mono text-[11px]">{t.schema_name || '—'}</code>
                </>
              )}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2.5">
          {ENTRA_ENABLED && !google && !deprecated && fedStatus && (
            <Badge tone={federated ? 'brand' : 'slate'} dot>
              {federated ? 'Federated' : 'Managed'}
            </Badge>
          )}
          {/* Display label only — the stored `consent_state` value is untouched;
              'adopted' simply reads as "added" in the UI. */}
          <Badge tone={stateTone(t)}>
            {deprecated ? 'deprecated' : t.consent_state === 'adopted' ? 'added' : t.consent_state || 'unknown'}
          </Badge>
          {expanded ? (
            <ChevronUp className="h-4 w-4 text-slate-400" />
          ) : (
            <ChevronDown className="h-4 w-4 text-slate-400" />
          )}
        </div>
      </button>

      {expanded && (
        <div className="space-y-5 border-t border-line-soft px-5 py-4">
          {deprecated && (
            <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-600" />
              <p className="text-xs leading-snug text-rose-700">
                This tenant is deprecated. Its endpoints remain published for reference, but
                credentials, sync, federation and policy changes are disabled.
              </p>
            </div>
          )}

          {showDetails && (
            <section>
              <h4 className="text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                Tenant record
              </h4>
              <div className="mt-1 rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2">
                <DetailRow label="Domain" value={t.verified_domain} />
                <DetailRow label="Display name" value={t.display_name} />
                <DetailRow label="Tenant ID" value={t.tenant_id} />
                <DetailRow label="Schema" value={t.schema_name} />
                {t.platform_id && <DetailRow label="Platform ID" value={t.platform_id} />}
              </div>
            </section>
          )}

          {/* ── SAML endpoints ── */}
          <section>
            <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <Link2 className="h-3.5 w-3.5" /> SAML endpoints
            </h4>
            <div className="mt-1 rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2">
              <EndpointRow label="IdP Entity ID" value={endpoints.entityId} />
              <EndpointRow label="SSO URL" value={endpoints.sso} />
              {google && (
                <>
                  <EndpointRow label="Sign-out URL" value={endpoints.slo} />
                  <EndpointRow label="Change password" value={endpoints.changePassword} />
                  {/* Metadata is what a Google SP consumes; Entra is configured
                      through the federation switch instead. */}
                  <EndpointRow label="Metadata" value={endpoints.metadata} external />
                </>
              )}
            </div>
          </section>

          {/* ── Microsoft Graph + sync + federation (Entra only) ── */}
          {ENTRA_ENABLED && !google && !deprecated && (
            <section className="space-y-3">
              <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                <KeyRound className="h-3.5 w-3.5" /> Microsoft Graph
              </h4>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Input
                  label="Client ID"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  placeholder="Application (client) ID"
                  autoComplete="off"
                />
                <Input
                  label="Client secret"
                  type="password"
                  value={clientSecret}
                  onChange={(e) => setClientSecret(e.target.value)}
                  placeholder="Client secret"
                  hint="Stored encrypted; never returned by the API."
                  autoComplete="new-password"
                />
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleGraphTest}
                  loading={graphBusy === 'test'}
                  disabled={graphBusy === 'save'}
                >
                  Test connection
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleGraphSave}
                  loading={graphBusy === 'save'}
                  disabled={graphBusy === 'test'}
                >
                  Save credentials
                </Button>
                <Button variant="ghost" size="sm" onClick={handleSync} loading={syncing}>
                  <RefreshCw className="h-3.5 w-3.5" /> Sync directory
                </Button>
              </div>
              {graphMsg && <p className={msgClass(graphMsg.tone)}>{graphMsg.text}</p>}
              {syncMsg && <p className={msgClass(syncMsg.tone)}>{syncMsg.text}</p>}
              {syncJob && <SyncReport job={syncJob} />}

              {/* Federation switch — always visible, and explicit about why it
                  is locked before the first successful sync. */}
              <div className="flex flex-wrap items-center gap-3 border-t border-line-soft pt-3">
                <span className="text-2xs font-semibold uppercase tracking-[0.06em] text-slate-400">
                  Federation
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={federated}
                  aria-label="Federate this domain"
                  onClick={handleFederationToggle}
                  disabled={fedBusy || !canFederate}
                  className={classNames(
                    'relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors duration-150 focus-visible:outline-none',
                    federated ? 'bg-brand-600' : 'bg-slate-300',
                    (fedBusy || !canFederate) && 'cursor-not-allowed opacity-50'
                  )}
                >
                  <span
                    className={classNames(
                      'inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform duration-150',
                      federated ? 'translate-x-4' : 'translate-x-0.5'
                    )}
                  />
                </button>
                <span className="text-xs text-slate-500">
                  {!fedStatus
                    ? 'Checking federation status…'
                    : !canFederate
                      ? 'Available after the first successful directory sync.'
                      : federated
                        ? 'Domain is Federated — sign-in is handled by this IdP.'
                        : 'Domain is Managed — sign-in is handled by Entra.'}
                </span>
              </div>
            </section>
          )}

          {/* ── MFA policy ── */}
          <section className="space-y-3 border-t border-line-soft pt-4">
            <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <ShieldCheck className="h-3.5 w-3.5" /> MFA policy
            </h4>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <Select
                label="Primary method"
                value={mfaPrimary}
                disabled={deprecated}
                onChange={(e) => setMfaPrimary(e.target.value)}
              >
                {methods.primary.length ? (
                  methods.primary.map((m) => (
                    <option key={m.name} value={m.name}>{m.label}</option>
                  ))
                ) : (
                  <option value={mfaPrimary}>{mfaPrimary}</option>
                )}
              </Select>
              <Select
                label="Step-up mode"
                value={stepupMode}
                disabled={deprecated}
                onChange={(e) => setStepupMode(e.target.value)}
              >
                {(methods.modes || ['external', 'idp']).map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </Select>
              <Select
                label="Step-up method"
                value={stepupMethod}
                /* Only the `idp` mode performs step-up in this product; in
                   `external` mode the choice has no effect. */
                disabled={deprecated || stepupMode !== 'idp'}
                hint={stepupMode === 'idp' ? undefined : 'Applies to the idp mode only.'}
                onChange={(e) => setStepupMethod(e.target.value)}
              >
                {methods.stepup.length ? (
                  methods.stepup.map((m) => (
                    <option key={m.name} value={m.name}>{m.label}</option>
                  ))
                ) : (
                  <option value={stepupMethod}>{stepupMethod}</option>
                )}
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" onClick={handleMfaSave} loading={mfaBusy} disabled={deprecated}>
                Save MFA policy
              </Button>
              {mfaMsg && <p className={msgClass(mfaMsg.tone)}>{mfaMsg.text}</p>}
            </div>
          </section>
        </div>
      )}
    </Card>
  );
}

export default TenantConfigCard;
