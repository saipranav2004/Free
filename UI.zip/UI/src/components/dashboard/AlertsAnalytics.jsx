/**
 * AlertsAnalytics — Enterprise alerts analytics section for PAM Alerts tab.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * DESIGN DECISIONS (Research: CyberArk, Splunk, CrowdStrike, Sentinel)
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * 1. SEVERITY DISTRIBUTION — Visual breakdown of denial severity levels
 *    using horizontal stacked bars (BeyondTrust pattern).
 *
 * 2. ENHANCED DATA MAPPING — Fixed 'Unknown action' issues by properly
 *    mapping nested audit_event objects and handling missing fields.
 *
 * 3. USER RISK PATTERNS — Top denied users with risk indicators
 *    (Delinea Privileged Behavior Analytics pattern).
 *
 * 4. RESOURCE HOTSPOTS — Visual indication of most targeted resources
 *    with severity-weighted progress bars.
 *
 * 5. TREND VISUALIZATION — Enhanced trend display with visual bars
 *    instead of plain numbers (CyberArk Trends and Insights pattern).
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * CONSTRAINTS
 * ═══════════════════════════════════════════════════════════════════════════════
 * - Frontend only. Backend folder is strictly for studying APIs.
 * - No git commands.
 * - Existing color palette preserved.
 * - Production-grade, maintainable code.
 */
import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import {
  ShieldAlert,
  Users,
  Activity,
  Clock,
  AlertTriangle,
  Pause,
  Play,
  RefreshCw,
  CheckCircle2,
  XCircle,
  TrendingUp,
  BarChart3,
  Target,
  UserX,
} from 'lucide-react';
import { useResource } from '../../hooks/useResource.js';
import { alertsApi } from '../../lib/api/alerts.js';
import { Card, Badge, Button, Spinner } from '../ui/primitives.jsx';
import { Modal } from '../ui/Modal.jsx';
import { formatDateTime, shortId, classNames } from '../../utils/format.js';

// ─── Color palette ────────────────────────────────────────────────────────────
const BRAND_COLOR = '#1f47f5';
const AMBER_COLOR = '#d97706';
const SLATE_COLOR = '#64748b';
const ROSE_COLOR = '#e11d48';

// ─── Enhanced data extraction with fallbacks ──────────────────────────────────
// Fixed: Properly extracts data from nested audit_event objects
// Fixed: Handles missing fields gracefully without showing "Unknown"
function extractEventData(item) {
  const event = item?.audit_event || item || {};
  const userProfile = item?.user_profile || {};

  return {
    auditId: event?.audit_id || event?.id || item?.audit_id || item?.id,
    action: event?.action || event?.event_type || item?.action || item?.event_type,
    username: userProfile?.username || event?.username || item?.username || event?.user_id || 'System',
    email: userProfile?.email || event?.email || item?.email,
    resourceName: event?.resource_name || event?.resource || item?.resource_name || item?.resource,
    decision: String(event?.decision || event?.status || item?.decision || '').toUpperCase(),
    ipAddress: event?.ip_address || item?.ip_address,
    createdAt: event?.created_at || item?.created_at,
    details: event?.details || item?.details,
    logType: event?.log_type || item?.log_type,
    userAgent: event?.user_agent || item?.user_agent,
    // For display: format action name nicely
    actionDisplay: formatActionName(event?.action || event?.event_type || item?.action || item?.event_type),
  };
}

// ─── Format action names for better readability ───────────────────────────────
function formatActionName(action) {
  if (!action) return 'Authorization Event';

  // Common action mappings
  const actionMap = {
    'role:assign': 'Role Assignment',
    'role:remove': 'Role Removal',
    'policy:read': 'Policy Read',
    'resource:read': 'Resource Read',
    'resource:create': 'Resource Create',
    'user:login': 'User Login',
    'user:logout': 'User Logout',
    'mfa:verify': 'MFA Verification',
    'session:create': 'Session Create',
    'session:revoke': 'Session Revoke',
  };

  return actionMap[action] || action.split(':').map(word =>
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
}

// ─── Horizontal progress bar for "Top N" analytics ───────────────────────────
function ProgressBar({ label, value, maxValue, color = BRAND_COLOR, suffix = '' }) {
  const percentage = maxValue > 0 ? Math.round((value / maxValue) * 100) : 0;

  return (
    <div className="group">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-medium text-slate-700 truncate max-w-[180px]" title={label}>
          {label}
        </span>
        <span className="text-xs font-semibold text-ink-900">
          {value?.toLocaleString?.() ?? value ?? 0}{suffix}
        </span>
      </div>
      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500 ease-out"
          style={{
            width: `${Math.max(percentage, 2)}%`,
            backgroundColor: color,
          }}
        />
      </div>
    </div>
  );
}

// ─── Severity Distribution Bar ────────────────────────────────────────────────
// Enterprise pattern: Stacked horizontal bar showing denial severity breakdown
function SeverityDistributionBar({ stats }) {
  const total = stats?.total_deny || 0;

  // Calculate severity distribution from available data
  const severities = useMemo(() => {
    // Group by action type as proxy for severity
    const actionGroups = stats?.deny_by_action || [];
    const highSeverity = actionGroups.filter(a =>
      a.action?.includes('role:') || a.action?.includes('admin')
    ).reduce((sum, a) => sum + (a.count || 0), 0);

    const mediumSeverity = actionGroups.filter(a =>
      a.action?.includes('policy:') || a.action?.includes('resource:')
    ).reduce((sum, a) => sum + (a.count || 0), 0);

    const lowSeverity = total - highSeverity - mediumSeverity;

    return [
      { label: 'High', count: Math.max(0, highSeverity), color: 'bg-rose-500' },
      { label: 'Medium', count: Math.max(0, mediumSeverity), color: 'bg-amber-500' },
      { label: 'Low', count: Math.max(0, lowSeverity), color: 'bg-slate-400' },
    ].filter(s => s.count > 0);
  }, [stats, total]);

  if (total === 0) return null;

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <BarChart3 className="h-4 w-4 text-brand-500" />
        <p className="text-sm font-semibold text-ink-900">Severity Distribution</p>
      </div>

      {/* Stacked bar */}
      <div className="flex h-4 rounded-full overflow-hidden mb-3">
        {severities.map((sev) => (
          <div
            key={sev.label}
            className={classNames('transition-all duration-500', sev.color)}
            style={{ width: `${(sev.count / total) * 100}%` }}
            title={`${sev.label}: ${sev.count} denials`}
          />
        ))}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4">
        {severities.map((sev) => (
          <div key={sev.label} className="flex items-center gap-2">
            <div className={classNames('w-3 h-3 rounded-full', sev.color)} />
            <span className="text-xs text-slate-600">
              {sev.label} ({sev.count})
            </span>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── DenialField — compact key/value display for denial detail modal ──────────
function DenialField({ label, value, mono }) {
  return (
    <div>
      <p className="text-xs font-medium text-slate-500 mb-0.5">{label}</p>
      <p className={classNames('text-ink-900', mono && 'break-all font-mono text-xs')}>
        {value || '—'}
      </p>
    </div>
  );
}

// ─── AlertStatCard — compact stat card for alert metrics ──────────────────────
function AlertStatCard({ label, value, icon: Icon, tone = 'brand', hint, loading }) {
  const tones = {
    brand: 'bg-brand-50 text-brand-600',
    red: 'bg-rose-50 text-rose-600',
    amber: 'bg-amber-50 text-amber-600',
    green: 'bg-emerald-50 text-emerald-600',
    slate: 'bg-slate-100 text-slate-600',
  };

  return (
    <div className="flex items-center gap-3">
      <div className={classNames('rounded-lg p-2', tones[tone])}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-xs text-slate-500">{label}</p>
        {loading ? (
          <div className="mt-1 h-5 w-12 animate-pulse rounded bg-slate-100" />
        ) : (
          <p className="text-lg font-semibold text-ink-900">
            {value?.toLocaleString?.() ?? value ?? '—'}
          </p>
        )}
      </div>
      {hint && (
        <span className="shrink-0 text-[11px] font-medium text-slate-400">{hint}</span>
      )}
    </div>
  );
}

// ─── Trend Visualization Card ─────────────────────────────────────────────────
// Enhanced trend display with visual bars (CyberArk Trends pattern)
function TrendVisualization({ trend }) {
  if (!trend) return null;

  const maxValue = Math.max(trend.last_24h || 0, trend.last_7d || 0, trend.last_30d || 0, 1);

  const periods = [
    { label: 'Last 24 Hours', value: trend.last_24h || 0, color: 'bg-rose-500' },
    { label: 'Last 7 Days', value: trend.last_7d || 0, color: 'bg-amber-500' },
    { label: 'Last 30 Days', value: trend.last_30d || 0, color: 'bg-slate-400' },
  ];

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-4 w-4 text-rose-500" />
        <p className="text-sm font-semibold text-ink-900">Denial Trend</p>
      </div>

      <div className="space-y-4">
        {periods.map((period) => (
          <div key={period.label}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-slate-600">{period.label}</span>
              <span className="text-sm font-bold text-ink-900">{period.value.toLocaleString()}</span>
            </div>
            <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
              <div
                className={classNames('h-full rounded-full transition-all duration-700', period.color)}
                style={{ width: `${(period.value / maxValue) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── User Risk Patterns Card ──────────────────────────────────────────────────
// Enterprise pattern: Top denied users with risk indicators
function UserRiskPatterns({ denyByUser, maxValue }) {
  if (!denyByUser?.length) return null;

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <UserX className="h-4 w-4 text-amber-500" />
        <p className="text-sm font-semibold text-ink-900">Top Denied Users</p>
      </div>
      <div className="space-y-3">
        {denyByUser.slice(0, 6).map((item, i) => {
          const username = item.username || item.user_id || 'Unknown';
          const count = item.count || 0;
          const percentage = maxValue > 0 ? (count / maxValue) * 100 : 0;

          return (
            <div key={username + i} className="group">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-100 text-xs font-semibold text-amber-700">
                    {username.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-xs font-medium text-slate-700 truncate max-w-[150px]" title={username}>
                    {username}
                  </span>
                </div>
                <span className="text-xs font-bold text-ink-900">{count}</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full bg-amber-500 transition-all duration-500"
                  style={{ width: `${Math.max(percentage, 2)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── Resource Hotspot Card ────────────────────────────────────────────────────
// Enterprise pattern: Most targeted resources visualization
function ResourceHotspots({ denyByResource, maxValue }) {
  if (!denyByResource?.length) return null;

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <Target className="h-4 w-4 text-slate-500" />
        <p className="text-sm font-semibold text-ink-900">Targeted Resources</p>
      </div>
      <div className="space-y-3">
        {denyByResource.slice(0, 6).map((item, i) => {
          const resource = item.resource || 'Unknown';
          const count = item.count || 0;
          const percentage = maxValue > 0 ? (count / maxValue) * 100 : 0;

          return (
            <div key={resource + i} className="group">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-slate-700 truncate max-w-[180px]" title={resource}>
                  {resource}
                </span>
                <span className="text-xs font-bold text-ink-900">{count}</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full bg-slate-500 transition-all duration-500"
                  style={{ width: `${Math.max(percentage, 2)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── AlertsAnalytics — the main alerts analytics section ──────────────────────
export function AlertsAnalytics() {
  // ── Auto-refresh state ──
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const autoRefreshRef = useRef(null);
  const alertsRef = useRef(null);

  // ── Denial detail modal state ──
  const [selectedDenial, setSelectedDenial] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailData, setDetailData] = useState(null);

  // ── Fetch alerts with stats ──
  const fetcher = useCallback(
    () => alertsApi.list({ page: 1, page_size: 50 }),
    []
  );

  const alerts = useResource(fetcher, []);

  // Keep ref in sync for auto-refresh (avoids stale closures)
  alertsRef.current = alerts;

  // ── Auto-refresh effect (60-second interval for dashboard) ──
  useEffect(() => {
    if (!autoRefresh) return;
    autoRefreshRef.current = setInterval(() => {
      alertsRef.current?.reload?.();
      setLastUpdated(new Date());
    }, 60_000);
    return () => {
      if (autoRefreshRef.current) clearInterval(autoRefreshRef.current);
    };
  }, [autoRefresh]);

  // ── Tolerate multiple API response shapes and extract data properly ──
  const raw = alerts?.data;
  const items = Array.isArray(raw)
    ? raw
    : raw?.items || raw?.logs || raw?.data || [];

  // Extract and normalize event data using enhanced extraction
  const normalizedItems = useMemo(() =>
    items.map(extractEventData).filter(item => item.auditId),
    [items]
  );

  const stats = raw?.stats || {
    total_deny: 0,
    unique_users: 0,
    unique_actions: 0,
    unique_resources: 0,
    deny_by_action: [],
    deny_by_resource: [],
    deny_by_reason: [],
    deny_by_user: [],
    trend: { last_24h: 0, last_7d: 0, last_30d: 0 },
  };

  // ── Transform data for horizontal progress bars ──
  const actionData = (stats.deny_by_action || []).map((item) => ({
    name: formatActionName(item.action || 'Unknown'),
    value: item.count || 0,
  }));

  const userData = (stats.deny_by_user || []).map((item) => ({
    name: item.username || item.user_id || 'Unknown',
    value: item.count || 0,
  }));

  const resourceData = (stats.deny_by_resource || []).map((item) => ({
    name: item.resource || 'Unknown',
    value: item.count || 0,
  }));

  // ── Max values for progress bar scaling ──
  const maxAction = Math.max(...actionData.map(d => d.value), 1);
  const maxUser = Math.max(...userData.map(d => d.value), 1);
  const maxResource = Math.max(...resourceData.map(d => d.value), 1);

  // ── Recent alerts (first 5 items) ──
  const recentAlerts = normalizedItems.slice(0, 5);

  // ── Handle denial click — fetch detail and open modal ──
  const handleDenialClick = useCallback(async (item) => {
    setSelectedDenial(item);
    if (item.auditId) {
      setDetailLoading(true);
      try {
        const res = await alertsApi.detail(item.auditId);
        setDetailData(res);
      } catch {
        setDetailData(null);
      } finally {
        setDetailLoading(false);
      }
    }
  }, []);

  const loading = alerts.loading;

  return (
    <>
      {/* ── Denial detail modal ── */}
      <Modal
        open={!!selectedDenial}
        onClose={() => { setSelectedDenial(null); setDetailData(null); }}
        size="lg"
        title={
          selectedDenial ? (
            <span className="flex items-center gap-2">
              <Badge tone="red">DENIED</Badge>
              <span className="font-mono text-sm">
                {selectedDenial.actionDisplay}
              </span>
            </span>
          ) : 'Denial detail'
        }
        description={selectedDenial ? formatDateTime(selectedDenial.createdAt) : undefined}
      >
        {selectedDenial && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <DenialField
                label="User"
                value={selectedDenial.username}
              />
              <DenialField
                label="Email"
                value={selectedDenial.email}
              />
              <DenialField label="User ID" value={shortId(selectedDenial.auditId)} mono />
              <DenialField
                label="Action"
                value={selectedDenial.actionDisplay}
                mono
              />
              <DenialField
                label="Resource"
                value={selectedDenial.resourceName}
              />
              <DenialField label="IP Address" value={selectedDenial.ipAddress} mono />
            </div>
            {selectedDenial.decision && (
              <div>
                <p className="text-xs font-medium text-slate-500 mb-1">Decision</p>
                <Badge tone="red">
                  <span className="flex items-center gap-1">
                    <XCircle className="h-3 w-3" />
                    {selectedDenial.decision}
                  </span>
                </Badge>
              </div>
            )}
            {detailLoading ? (
              <div className="flex items-center justify-center py-6">
                <Spinner className="h-5 w-5" />
              </div>
            ) : detailData?.policy_attachments?.length > 0 ? (
              <div>
                <p className="text-xs font-medium text-slate-500 mb-2">Matched Policies</p>
                <div className="space-y-1.5">
                  {detailData.policy_attachments.map((pol, i) => (
                    <div
                      key={pol.policy_id || i}
                      className="flex items-center gap-2 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2"
                    >
                      <ShieldAlert className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                      <span className="text-xs font-medium text-amber-900 truncate">
                        {pol.policy_name || pol.name || `Policy ${shortId(pol.policy_id)}`}
                      </span>
                      {pol.effect && <Badge tone="amber">{pol.effect}</Badge>}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
            <div>
              <p className="text-xs font-medium text-slate-500 mb-1">Details</p>
              <pre className="max-h-60 overflow-auto rounded-lg bg-slate-900 p-3 text-xs leading-relaxed text-slate-100">
                {(() => {
                  try {
                    const d = selectedDenial.details;
                    const parsed = typeof d === 'string' ? JSON.parse(d) : d;
                    return parsed
                      ? JSON.stringify(parsed, null, 2)
                      : 'No additional details captured.';
                  } catch {
                    return String(selectedDenial.details || 'No additional details captured.');
                  }
                })()}
              </pre>
            </div>
            <p className="text-[11px] text-slate-300">Press Esc to close</p>
          </div>
        )}
      </Modal>

      <div className="space-y-6">
        {/* ── Section header with controls ── */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600">
              <ShieldAlert className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-ink-900">Alerts</h2>
              <p className="text-sm text-slate-500">
                Security alerts and denial analytics
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {lastUpdated && (
              <span className="flex items-center gap-1 text-xs text-slate-400">
                <Clock className="h-3 w-3" />
                {lastUpdated.toLocaleTimeString()}
              </span>
            )}
            <Button
              variant={autoRefresh ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setAutoRefresh((v) => !v)}
            >
              {autoRefresh ? (
                <Pause className="h-3.5 w-3.5" />
              ) : (
                <Play className="h-3.5 w-3.5" />
              )}
              {autoRefresh ? 'Live' : 'Auto-refresh'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                alerts?.reload?.();
                setLastUpdated(new Date());
              }}
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Spinner className="h-6 w-6" />
          </div>
        ) : alerts?.error ? (
          <Card className="flex items-center gap-3 border-amber-200 bg-amber-50 p-4">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <p className="text-sm text-amber-800">
              Could not load alerts data.{' '}
              <button
                onClick={() => alerts?.reload?.()}
                className="font-medium underline hover:text-amber-900"
              >
                Retry
              </button>
            </p>
          </Card>
        ) : (
          <>
            {/* ── Stat cards row ── */}
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              <Card className="p-4">
                <AlertStatCard
                  label="Total Denials"
                  value={stats.total_deny}
                  icon={XCircle}
                  tone="red"
                  loading={loading}
                />
              </Card>
              <Card className="p-4">
                <AlertStatCard
                  label="Unique Users"
                  value={stats.unique_users}
                  icon={Users}
                  tone="amber"
                  loading={loading}
                />
              </Card>
              <Card className="p-4">
                <AlertStatCard
                  label="Last 24 Hours"
                  value={stats.trend?.last_24h}
                  icon={Activity}
                  tone="brand"
                  hint="denials"
                  loading={loading}
                />
              </Card>
              <Card className="p-4">
                <AlertStatCard
                  label="Affected Resources"
                  value={stats.unique_resources}
                  icon={ShieldAlert}
                  tone="slate"
                  loading={loading}
                />
              </Card>
            </div>

            {/* ── Trend Visualization ── */}
            <TrendVisualization trend={stats.trend} />

            {/* ── Severity Distribution ── */}
            <SeverityDistributionBar stats={stats} />

            {/* ── Analytics Grid: User Risk + Resource Hotspots + Top Actions ── */}
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
              {/* User Risk Patterns */}
              <UserRiskPatterns
                denyByUser={stats.deny_by_user}
                maxValue={maxUser}
              />

              {/* Resource Hotspots */}
              <ResourceHotspots
                denyByResource={stats.deny_by_resource}
                maxValue={maxResource}
              />

              {/* Top Denied Actions */}
              {actionData.length > 0 && (
                <Card className="p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <BarChart3 className="h-4 w-4 text-brand-500" />
                    <p className="text-sm font-semibold text-ink-900">Top Denied Actions</p>
                  </div>
                  <div className="space-y-3">
                    {actionData.slice(0, 6).map((item) => (
                      <ProgressBar
                        key={item.name}
                        label={item.name}
                        value={item.value}
                        maxValue={maxAction}
                        color={BRAND_COLOR}
                      />
                    ))}
                  </div>
                </Card>
              )}
            </div>

            {/* ── Recent Denials — clickable with detail modal ── */}
            {recentAlerts.length > 0 && (
              <Card>
                <div className="flex items-center border-b border-line-soft px-5 py-3">
                  <h3 className="text-sm font-semibold text-ink-900">Recent Denials</h3>
                </div>
                <div className="divide-y divide-line-soft">
                  {recentAlerts.map((item, i) => (
                    <button
                      key={item.auditId || i}
                      onClick={() => handleDenialClick(item)}
                      className="flex w-full items-center gap-3 px-5 py-3 text-left transition hover:bg-slate-50 cursor-pointer"
                    >
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-rose-50">
                        <XCircle className="h-4 w-4 text-rose-500" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-ink-900">
                          {item.actionDisplay}
                        </p>
                        <p className="truncate text-xs text-slate-500">
                          {item.username} → {item.resourceName || 'resource'}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <Badge tone="red">DENIED</Badge>
                        <p className="mt-1 text-[11px] text-slate-400">
                          {formatDateTime(item.createdAt)}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </Card>
            )}

            {/* ── Empty state when no alerts ── */}
            {stats.total_deny === 0 && recentAlerts.length === 0 && (
              <Card className="flex flex-col items-center justify-center py-12">
                <div className="rounded-full bg-emerald-50 p-3">
                  <CheckCircle2 className="h-6 w-6 text-emerald-500" />
                </div>
                <p className="mt-3 text-sm font-semibold text-ink-900">No denial alerts</p>
                <p className="mt-1 text-sm text-slate-500">
                  Authorization is operating normally. Denials will appear here when detected.
                </p>
              </Card>
            )}
          </>
        )}
      </div>
    </>
  );
}
