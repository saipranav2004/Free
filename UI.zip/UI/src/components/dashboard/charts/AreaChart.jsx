import { useMemo } from 'react';
import { ResponsiveContainer, AreaChart as RechartsArea, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

let _gradientCounter = 0;

/**
 * Enterprise-styled area chart for dashboard analytics.
 *
 * Uses Recharts under the hood but provides a simplified API matching
 * the project's design language (brand-600 primary, smooth gradients).
 *
 * Props:
 *   data      – Array of objects, one per X point
 *   dataKey   – The Y-axis value key in each data object
 *   xKey      – The X-axis label key (default: 'name')
 *   color     – Stroke / fill color (default: brand-600 #1f47f5)
 *   height    – Chart height in px (default: 220)
 *   title     – Optional chart title
 *   tooltip   – Custom tooltip renderer (receives { active, payload, label })
 */
export function DashboardAreaChart({
  data = [],
  dataKey = 'value',
  xKey = 'name',
  color = '#1f47f5',
  height = 220,
  title,
  tooltip: CustomTooltip,
}) {
  // Stable unique ID for gradient — one per component instance
  const gradientId = useMemo(() => `area-grad-${++_gradientCounter}`, []);

  if (!data.length) {
    return (
      <div className="flex items-center justify-center text-sm text-slate-400" style={{ height }}>
        No data available
      </div>
    );
  }

  return (
    <div>
      {title && (
        <p className="mb-3 text-sm font-semibold text-ink-900">{title}</p>
      )}
      <ResponsiveContainer width="100%" height={height}>
        <RechartsArea data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.15} />
              <stop offset="95%" stopColor={color} stopOpacity={0.01} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis
            dataKey={xKey}
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            axisLine={false}
            tickLine={false}
            allowDecimals={false}
          />
          <Tooltip content={CustomTooltip || <DefaultTooltip />} />
          <Area
            type="monotone"
            dataKey={dataKey}
            stroke={color}
            strokeWidth={2}
            fill={`url(#${gradientId})`}
            dot={{ r: 3, fill: color, strokeWidth: 0 }}
            activeDot={{ r: 5, fill: color, stroke: '#fff', strokeWidth: 2 }}
          />
        </RechartsArea>
      </ResponsiveContainer>
    </div>
  );
}

/** Default tooltip matching the project's design language */
function DefaultTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-lg">
      <p className="text-xs font-medium text-slate-500">{label}</p>
      {payload.map((entry, i) => (
        <p key={i} className="mt-0.5 text-sm font-semibold text-ink-900">
          {entry.value?.toLocaleString?.() ?? entry.value}
        </p>
      ))}
    </div>
  );
}
