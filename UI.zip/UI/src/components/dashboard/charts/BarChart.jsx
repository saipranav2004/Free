import { ResponsiveContainer, BarChart as RechartsBar, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell } from 'recharts';

/**
 * Enterprise-styled horizontal bar chart for dashboard analytics.
 *
 * Designed for "Top-N" lists (top denied actions, top users, top resources).
 * Uses horizontal bars for long labels and clean readability.
 *
 * Props:
 *   data       – Array of { name, value } objects
 *   color      – Bar fill color (default: brand-600)
 *   height     – Chart height in px (default: 200)
 *   maxBars    – Maximum bars to display (default: 6)
 *   title      – Optional chart title
 *   formatter  – Optional value formatter function
 */
export function DashboardBarChart({
  data = [],
  color = '#1f47f5',
  height = 200,
  maxBars = 6,
  title,
  formatter,
}) {
  const displayData = data.slice(0, maxBars);

  if (!displayData.length) {
    return (
      <div className="flex items-center justify-center text-sm text-slate-400" style={{ height }}>
        No data available
      </div>
    );
  }

  // Dynamic bar height based on data count
  const barSize = Math.min(24, Math.max(12, (height - 40) / displayData.length));

  return (
    <div>
      {title && (
        <p className="mb-3 text-sm font-semibold text-ink-900">{title}</p>
      )}
      <ResponsiveContainer width="100%" height={height}>
        <RechartsBar
          data={displayData}
          layout="vertical"
          margin={{ top: 0, right: 20, left: 0, bottom: 0 }}
          barCategoryGap="20%"
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
          <XAxis
            type="number"
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            axisLine={false}
            tickLine={false}
            allowDecimals={false}
          />
          <YAxis
            type="category"
            dataKey="name"
            tick={{ fontSize: 11, fill: '#475569' }}
            axisLine={false}
            tickLine={false}
            width={120}
            tickFormatter={(val) => val?.length > 18 ? `${val.slice(0, 18)}…` : val}
          />
          <Tooltip content={<BarTooltip formatter={formatter} />} />
          <Bar
            dataKey="value"
            radius={[0, 4, 4, 0]}
            barSize={barSize}
          >
            {displayData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={color}
                fillOpacity={0.85 + (index === 0 ? 0.15 : 0) - (index * 0.05)}
              />
            ))}
          </Bar>
        </RechartsBar>
      </ResponsiveContainer>
    </div>
  );
}

/** Tooltip for bar chart entries */
function BarTooltip({ active, payload, formatter }) {
  if (!active || !payload?.length) return null;
  const entry = payload[0];
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-lg">
      <p className="max-w-[200px] truncate text-xs font-medium text-slate-500">
        {entry.payload?.name}
      </p>
      <p className="mt-0.5 text-sm font-semibold text-ink-900">
        {formatter ? formatter(entry.value) : entry.value?.toLocaleString?.() ?? entry.value}
      </p>
    </div>
  );
}


