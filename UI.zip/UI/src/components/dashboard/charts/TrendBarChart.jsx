import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';

/**
 * Enterprise-styled vertical bar chart for denial trend visualization.
 *
 * Displays denial counts across three time windows: 24 hours, 7 days, and 30 days.
 * Each bar uses a distinct color shade from red/rose palette for visual hierarchy.
 *
 * Props:
 *   data   – Array of { name, value } objects (typically 3 items for time windows)
 *   height – Chart height in px (default: 200)
 */

// Color palette — each time window gets a distinct shade for visual hierarchy
const TREND_COLORS = ['#e11d48', '#f43f5e', '#fb7185'];

/** Custom tooltip for the trend bar chart */
function TrendTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-lg">
      <p className="text-xs font-medium text-slate-500">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink-900">
        {payload[0].value?.toLocaleString()} denial{payload[0].value !== 1 ? 's' : ''}
      </p>
    </div>
  );
}

export function TrendBarChart({ data = [], height = 200 }) {
  if (!data.length || data.every((d) => d.value === 0)) {
    return (
      <div className="flex flex-col items-center justify-center text-center" style={{ height }}>
        <p className="text-sm text-slate-500">No denials recorded</p>
        <p className="mt-1 text-xs text-slate-400">Authorization is operating normally</p>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 11, fill: '#94a3b8' }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fontSize: 11, fill: '#94a3b8' }}
          axisLine={false}
          tickLine={false}
          allowDecimals={false}
        />
        <Tooltip content={<TrendTooltip />} />
        <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={40}>
          {data.map((entry, index) => (
            <Cell key={`trend-${index}`} fill={TREND_COLORS[index] || '#e11d48'} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
