import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'
import { SortHeader } from '../common/TableControls'
import { StatusIndicator } from '../common/Badge'
import { stickyCell, stickyHeader, cell, COL, TruncCell } from '../common/tableStyles'
import { ResourceTypeIcon } from './ResourceTypeIcon'
import { resourceTypeLabel } from './ResourceCard'

// ---------------------------------------------------------------------------
// Resources table
// ---------------------------------------------------------------------------
// NARROWED TO WHAT A CATALOGUE IS FOR. Host, Port, Group and Database are
// gone from the grid, and so is the selection column.
//
// Why those four: they are CONNECTION PARAMETERS, not identity. Nobody scans
// a catalogue looking for "port 6379" — they scan for a system by name, then
// open it. Carrying four wide, low-signal columns forced a 64rem minimum
// width, which is what made the table scroll sideways on a normal laptop and
// pushed Status (the column people DO scan) off screen. Every one of the four
// is still on the resource's own detail page, one click away, and still
// searchable from the box above. This is the same call CyberArk's account
// list and AWS's Systems Manager inventory make: identity + state in the
// grid, connection detail on the object.
//
// Why selection is gone: this backend exposes no batch endpoints. Checkboxes
// that can only ever lead to a disabled action bar are a promise the platform
// cannot keep, and they cost a permanent frozen column on every row.
//
// What is left fits without horizontal scroll, which is the actual win.
//
// The status columns are dot-plus-text indicators, not filled pills. Access,
// Credential and Status are populated on EVERY row, so as chips they produced
// ~45 saturated blocks per screen. Filled badges stay reserved for exceptions.

export const RESOURCE_COLUMNS = [
  { key: 'name', label: 'Resource', required: true },
  { key: 'resource_type', label: 'Type' },
  { key: 'access', label: 'Access' },
  { key: 'credential', label: 'Credential' },
  { key: 'status', label: 'Status' },
]

export function ResourceTable({ rows, sort, onSort, density, visibleColumns, onPeek, focusedId }) {
  const show = (key) => !visibleColumns || visibleColumns.includes(key)
  const pad = density === 'compact' ? 'py-2' : 'py-3'

  return (
    <div className="relative overflow-x-auto overscroll-x-contain">
      <table className="w-full min-w-[40rem] table-fixed border-separate border-spacing-0 text-sm">
        <colgroup>
          {show('name') && <col className={COL.name} />}
          {show('resource_type') && <col className={COL.medium} />}
          {show('access') && <col className={COL.status} />}
          {show('credential') && <col className={COL.status} />}
          {show('status') && <col className={COL.status} />}
          <col className={COL.actions} />
        </colgroup>

        <thead>
          <tr>
            {show('name') && (
              <SortHeader
                label="Resource"
                columnKey="name"
                sort={sort}
                onSort={onSort}
                className={clsx(stickyHeader({ left: 'left-0', edge: true }), 'z-30')}
              />
            )}
            {show('resource_type') && <SortHeader label="Type" columnKey="resource_type" sort={sort} onSort={onSort} />}
            {show('access') && <SortHeader label="Access" columnKey="requires_jit" sort={sort} onSort={onSort} />}
            {show('credential') && <SortHeader label="Credential" columnKey="vault_entry_id" sort={sort} onSort={onSort} />}
            {show('status') && <SortHeader label="Status" columnKey="is_active" sort={sort} onSort={onSort} />}
            <SortHeader label="Open" columnKey="_open" srOnly />
          </tr>
        </thead>

        <tbody>
          {rows.map((r) => (
            <tr
              key={r.id}
              data-row-id={r.id}
              className={clsx('group', focusedId === r.id && 'outline outline-1 -outline-offset-1 outline-blue-500/40')}
            >
              {show('name') && (
                <td className={clsx(stickyCell({ left: 'left-0', edge: true }), 'px-4', pad)}>
                  <div className="flex min-w-0 items-center gap-2.5">
                    <ResourceTypeIcon type={r.resource_type} className="h-4 w-4 flex-none" />
                    <span className="min-w-0 flex-1">
                      <button
                        type="button"
                        onClick={() => onPeek(r)}
                        title={r.name}
                        className="block max-w-full truncate text-left font-medium text-ink-50 outline-none transition-colors hover:text-blue-600 dark:hover:text-blue-300"
                      >
                        {r.name}
                      </button>
                      {/* Host moved off the grid as a column, but it is the
                          one connection fact that disambiguates two
                          similarly-named systems — so it rides under the name
                          as secondary text instead of taking 14rem of width. */}
                      {r.host && (
                        <span className="mt-0.5 block truncate font-mono text-2xs text-ink-500" title={r.host}>
                          {r.host}
                        </span>
                      )}
                    </span>
                  </div>
                </td>
              )}

              {show('resource_type') && (
                <td className={clsx(cell({}), 'px-4', pad)}>
                  <TruncCell value={resourceTypeLabel(r.resource_type)} />
                </td>
              )}

              {/* Access is the one column where the two values mean genuinely
                  different things operationally, so JIT gets the warmer dot —
                  but neither is a filled chip. */}
              {show('access') && (
                <td className={clsx(cell({}), 'px-4', pad)}>
                  {r.requires_jit ? (
                    <StatusIndicator tone="amber" title="Requires an approved just-in-time request">
                      JIT required
                    </StatusIndicator>
                  ) : (
                    <StatusIndicator tone="blue" title="Available without a request">
                      Standing
                    </StatusIndicator>
                  )}
                </td>
              )}

              {show('credential') && (
                <td className={clsx(cell({}), 'px-4', pad)}>
                  {r.vault_entry_id ? (
                    <StatusIndicator tone="emerald">Attached</StatusIndicator>
                  ) : (
                    <StatusIndicator tone="neutral">None</StatusIndicator>
                  )}
                </td>
              )}

              {show('status') && (
                <td className={clsx(cell({}), 'px-4', pad)}>
                  {r.is_active ? (
                    <StatusIndicator tone="emerald">Active</StatusIndicator>
                  ) : (
                    <StatusIndicator tone="neutral">Inactive</StatusIndicator>
                  )}
                </td>
              )}

              <td className={clsx(cell({}), 'px-2', pad)}>
                <Link
                  to={`/resources/${r.id}`}
                  aria-label={`Open ${r.name}`}
                  className="ml-auto flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-colors hover:bg-surface-800 hover:text-ink-100"
                >
                  <ChevronRight className="h-4 w-4" strokeWidth={2} />
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
