/**
 * PamFilters — Smart filter bar for the PAM unified operations center.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * DESIGN DECISIONS (Research: Splunk, Chronicle, Sentinel)
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * 1. RESPONSIVE FILTER BAR — Collapsible sections on mobile with touch-friendly
 *    controls (min 44x44px tap targets).
 *
 * 2. QUICK FILTER CHIPS — Severity quick filters reduce cognitive load vs
 *    dropdown-heavy UIs (Enterprise security tool pattern).
 *
 * 3. ACTIVE FILTER CHIPS — Clear visual feedback with easy dismiss buttons.
 *
 * 4. PROGRESSIVE DISCLOSURE — Advanced filters hidden behind expandable section
 *    on mobile, always visible on desktop.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * CONSTRAINTS
 * ═══════════════════════════════════════════════════════════════════════════════
 * - Frontend only. Backend folder is strictly for studying APIs.
 * - No git commands.
 * - Existing color palette preserved.
 * - Production-grade, maintainable code.
 */
import { useState, useCallback } from 'react';
import {
  Filter,
  X,
  Search,
  RotateCcw,
  XCircle,
  CheckCircle2,
  ChevronDown,
  SlidersHorizontal,
} from 'lucide-react';
import { Button, Input, Select } from '../ui/primitives.jsx';
import { classNames } from '../../utils/format.js';

// ─── Filter chips ─────────────────────────────────────────────────────────────

function FilterChip({ label, value, onClear }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-2.5 py-1 text-xs font-medium text-brand-700 ring-1 ring-inset ring-brand-600/20">
      <span className="text-brand-500">{label}:</span>
      <span className="font-semibold">{value}</span>
      <button
        onClick={onClear}
        className="ml-0.5 rounded-full p-0.5 hover:bg-brand-100 transition-colors"
        aria-label={`Clear ${label} filter`}
      >
        <X className="h-3 w-3" />
      </button>
    </span>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

/**
 * PamFilters
 *
 * Props:
 *  - filters: Current filter state object
 *  - onFilterChange: Callback (key, value) when a filter changes
 *  - onSearch: Callback to apply text search
 *  - onReset: Callback to reset all filters
 *  - counts: Optional object with counts for each severity/type
 */
export function PamFilters({ filters, onFilterChange, onSearch, onReset, counts = {} }) {
  const [searchInput, setSearchInput] = useState(filters.search || '');
  const [advancedOpen, setAdvancedOpen] = useState(false);

  const handleSearchSubmit = useCallback(() => {
    onSearch?.(searchInput);
  }, [searchInput, onSearch]);

  const handleSearchKeyDown = useCallback((e) => {
    if (e.key === 'Enter') handleSearchSubmit();
  }, [handleSearchSubmit]);

  // ── Build active filter chips ──
  const activeFilters = [];
  if (filters.severity && filters.severity !== 'all') {
    activeFilters.push({ key: 'severity', label: 'Status', value: filters.severity.toUpperCase() });
  }
  if (filters.type && filters.type !== 'all') {
    activeFilters.push({ key: 'type', label: 'Type', value: filters.type.toUpperCase() });
  }
  if (filters.from) {
    activeFilters.push({ key: 'from', label: 'From', value: filters.from });
  }
  if (filters.to) {
    activeFilters.push({ key: 'to', label: 'To', value: filters.to });
  }
  if (filters.search) {
    activeFilters.push({ key: 'search', label: 'Search', value: filters.search });
  }

  const clearFilter = useCallback((key) => {
    const defaultVal = key === 'type' || key === 'severity' ? 'all' : '';
    onFilterChange?.(key, defaultVal);
    if (key === 'search') setSearchInput('');
  }, [onFilterChange]);

  return (
    <div className="space-y-3">
      {/* ── Main filter bar ── */}
      <div className="space-y-3 lg:space-y-0">
        {/* Quick filters - always visible */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Severity quick filters */}
          <div className="flex items-center gap-1">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mr-1 hidden sm:inline">
              Status
            </span>
            {[
              { value: 'all', label: 'All', icon: null },
              { value: 'denied', label: 'Denied', icon: XCircle, tone: 'rose' },
              { value: 'success', label: 'Success', icon: CheckCircle2, tone: 'emerald' },
            ].map((opt) => {
              const isActive = (filters.severity || 'all') === opt.value;
              const Icon = opt.icon;
              return (
                <button
                  key={opt.value}
                  onClick={() => onFilterChange?.('severity', opt.value)}
                  className={classNames(
                    'inline-flex items-center gap-1 sm:gap-1.5 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-medium transition-all duration-100',
                    isActive
                      ? opt.value === 'denied'
                        ? 'bg-rose-100 text-rose-700 ring-1 ring-inset ring-rose-300'
                        : opt.value === 'success'
                        ? 'bg-emerald-100 text-emerald-700 ring-1 ring-inset ring-emerald-300'
                        : 'bg-brand-100 text-brand-700 ring-1 ring-inset ring-brand-300'
                      : 'bg-white text-slate-600 ring-1 ring-inset ring-slate-200 hover:bg-slate-50'
                  )}
                >
                  {Icon && <Icon className="h-3 w-3 sm:h-3.5 sm:w-3.5" />}
                  {opt.label}
                  {opt.value !== 'all' && counts[opt.value] != null && (
                    <span className={classNames(
                      'rounded-full px-1.5 py-0.5 text-[10px] sm:text-[11px] font-bold',
                      isActive ? 'bg-white/60' : 'bg-slate-100'
                    )}>
                      {counts[opt.value]}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Search - always visible */}
          <div className="flex-1 min-w-0 sm:w-56 sm:flex-none">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search…"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyDown={handleSearchKeyDown}
                className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
              />
            </div>
          </div>

          {/* Apply button - always visible */}
          <Button variant="primary" size="sm" onClick={handleSearchSubmit}>
            <Filter className="h-3.5 w-3.5" /> Apply
          </Button>

          {/* Advanced filters toggle - mobile only */}
          <button
            onClick={() => setAdvancedOpen(!advancedOpen)}
            className="lg:hidden inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 ring-1 ring-inset ring-slate-200 hover:bg-slate-50"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
            <ChevronDown className={classNames(
              'h-3.5 w-3.5 transition-transform',
              advancedOpen && 'rotate-180'
            )} />
          </button>
        </div>

        {/* Advanced filters - collapsible on mobile, always visible on desktop */}
        <div className={classNames(
          'lg:flex lg:items-end lg:gap-3',
          advancedOpen ? 'block' : 'hidden lg:block'
        )}>
          {/* Type filter */}
          <div className="w-full lg:w-32">
            <Select
              label="Log type"
              value={filters.type || 'all'}
              onChange={(e) => onFilterChange?.('type', e.target.value)}
            >
              <option value="all">All types</option>
              <option value="authn">AuthN</option>
              <option value="authz">AuthZ</option>
            </Select>
          </div>

          {/* Date range */}
          <div className="w-full lg:w-36">
            <Input
              label="From"
              type="date"
              value={filters.from || ''}
              onChange={(e) => onFilterChange?.('from', e.target.value)}
            />
          </div>
          <div className="w-full lg:w-36">
            <Input
              label="To"
              type="date"
              value={filters.to || ''}
              onChange={(e) => onFilterChange?.('to', e.target.value)}
            />
          </div>

          {/* Reset button */}
          <div className="flex items-end gap-1.5 mt-3 lg:mt-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { onReset?.(); setSearchInput(''); }}
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </Button>
          </div>
        </div>
      </div>

      {/* ── Active filter chips ── */}
      {activeFilters.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-medium text-slate-400">Active:</span>
          {activeFilters.map((f) => (
            <FilterChip
              key={f.key}
              label={f.label}
              value={f.value}
              onClear={() => clearFilter(f.key)}
            />
          ))}
          <button
            onClick={() => { onReset?.(); setSearchInput(''); }}
            className="text-[11px] font-medium text-slate-400 hover:text-slate-600 transition-colors"
          >
            Clear all
          </button>
        </div>
      )}
    </div>
  );
}
