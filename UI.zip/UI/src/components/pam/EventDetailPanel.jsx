/**
 * EventDetailPanel — Right-side detail panel for the PAM unified split-view.
 *
 * Research finding (CyberArk, Splunk, Sentinel):
 *  - Master-Detail split layout is the SIEM gold standard
 *  - Detail panels show: WHO, WHAT, WHEN, WHERE, HOW, and WHY
 *  - Structured key/value fields for quick scanning
 *  - Raw JSON for deep forensic investigation
 *  - Related entity links (user profile, resource, policy) for context
 *
 * This component renders inside the right pane of PamPage's split-view.
 * When no event is selected, it shows an empty state prompting the user
 * to select an event from the activity feed.
 */
import { useState, useCallback } from 'react';
import {
  X,
  User,
  Shield,
  FileText,
  Copy,
  Check,
  CheckCircle2,
  XCircle,
  Info,
} from 'lucide-react';
import { Badge, Button, Spinner } from '../ui/primitives.jsx';
import { useResource } from '../../hooks/useResource.js';
import { alertsApi } from '../../lib/api/alerts.js';
import { formatDateTime, shortId, classNames } from '../../utils/format.js';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Format a decision/status value into a visual badge */
function DecisionBadge({ decision }) {
  if (!decision) return <span className="text-xs text-slate-400">—</span>;
  const d = String(decision).toUpperCase();
  const allow = d === 'ALLOW' || d === 'SUCCESS';
  return (
    <Badge tone={allow ? 'green' : 'red'}>
      <span className="flex items-center gap-1">
        {allow ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
        {decision}
      </span>
    </Badge>
  );
}

/** Compact key/value field for the detail panel */
function Field({ label, value, mono, copyable }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(() => {
    if (!value || value === '—') return;
    navigator.clipboard.writeText(String(value));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }, [value]);

  return (
    <div className="group">
      <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">{label}</p>
      <div className="flex items-start gap-1.5">
        <p className={classNames(
          'text-sm text-ink-900 flex-1 min-w-0',
          mono && 'break-all font-mono text-xs bg-slate-50 rounded px-1.5 py-0.5'
        )}>
          {value || '—'}
        </p>
        {copyable && value && value !== '—' && (
          <button
            onClick={handleCopy}
            className="shrink-0 rounded p-0.5 text-slate-300 opacity-0 group-hover:opacity-100 hover:text-slate-600 transition-opacity"
            title="Copy to clipboard"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyDetailState() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center px-8">
      <div className="rounded-2xl bg-slate-100 p-4 mb-4">
        <Info className="h-8 w-8 text-slate-300" />
      </div>
      <p className="text-sm font-semibold text-slate-600">No event selected</p>
      <p className="mt-1.5 text-xs text-slate-400 max-w-[220px]">
        Click any event in the activity feed to view its full details here.
      </p>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

/**
 * EventDetailPanel
 *
 * Props:
 *  - event: The selected audit/alert event object (from ActivityFeed)
 *  - onClose: Callback to deselect the event
 *  - onNavigateToUser: Optional callback to navigate to a user's detail page
 *  - onNavigateToResource: Optional callback to navigate to a resource's detail page
 */
export function EventDetailPanel({ event, onClose, onNavigateToUser, onNavigateToResource }) {
  // ── Fetch full alert detail if the event is a DENY alert ──
  // The alert detail endpoint returns richer data: user_profile, policy_attachments, etc.
  const isDeny = String(event?.decision || '').toUpperCase() === 'DENY' ||
                 String(event?.status || '').toUpperCase() === 'FAILURE';

  const alertId = event?.audit_id || event?.id;
  const shouldFetch = isDeny && !!alertId;
  const detailFetcher = useCallback(
    () => alertsApi.detail(alertId),
    [alertId]
  );
  const detailRes = useResource(shouldFetch ? detailFetcher : null);
  const detail = detailRes?.data;

  // ── Merge event data with detail data ──
  const auditEvent = detail?.audit_event || event;
  const userProfile = detail?.user_profile || {};
  const policies = detail?.policy_attachments || [];

  // ── Parse details JSON ──
  let detailsJson = null;
  if (auditEvent?.details) {
    try {
      const parsed = typeof auditEvent.details === 'string'
        ? JSON.parse(auditEvent.details)
        : auditEvent.details;
      detailsJson = JSON.stringify(parsed, null, 2);
    } catch {
      detailsJson = String(auditEvent.details);
    }
  }

  // ── Event type styling ──
  const decision = String(auditEvent?.decision || auditEvent?.status || '').toUpperCase();
  const isAllow = decision === 'ALLOW' || decision === 'SUCCESS';
  const isDenyEvent = decision === 'DENY' || decision === 'FAILURE';

  return (
    <div className="flex flex-col h-full">
      {/* ── Panel header ── */}
      <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 bg-slate-50/80">
        <div className="flex items-center gap-2 min-w-0">
          <div className={classNames(
            'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg',
            isDenyEvent ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'
          )}>
            {isDenyEvent ? <XCircle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink-900 truncate">
              {auditEvent?.action || auditEvent?.event_type || 'Event Detail'}
            </p>
            <p className="text-[11px] text-slate-400">
              {formatDateTime(auditEvent?.created_at)}
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-200 hover:text-ink-700 transition-colors"
          aria-label="Close detail panel"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* ── Panel body ── */}
      {!event ? (
        <EmptyDetailState />
      ) : detailRes?.loading ? (
        <div className="flex items-center justify-center py-16">
          <Spinner className="h-5 w-5" />
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
          {/* ── Status & Decision badges ── */}
          <div className="flex flex-wrap items-center gap-2">
            <DecisionBadge decision={auditEvent?.decision || auditEvent?.status} />
            {auditEvent?.log_type && (
              <Badge tone={auditEvent.log_type === 'authn' ? 'sky' : 'brand'}>
                {(auditEvent.log_type).toUpperCase()}
              </Badge>
            )}
          </div>

          {/* ── Core fields grid ── */}
          <div className="grid grid-cols-2 gap-4">
            <Field label="User" value={userProfile.username || auditEvent?.username} />
            <Field label="Email" value={userProfile.email || auditEvent?.email} />
            <Field label="User ID" value={shortId(auditEvent?.user_id)} mono copyable />
            <Field label="Action" value={auditEvent?.action || auditEvent?.event_type} mono />
            <Field label="Resource" value={auditEvent?.resource_name || auditEvent?.resource} />
            <Field label="IP Address" value={auditEvent?.ip_address} mono copyable />
          </div>

          {/* ── User agent ── */}
          {auditEvent?.user_agent && (
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">User Agent</p>
              <p className="text-xs text-slate-600 break-all bg-slate-50 rounded-lg p-2 font-mono leading-relaxed">
                {auditEvent.user_agent}
              </p>
            </div>
          )}

          {/* ── Policy attachments (for DENY events) ── */}
          {policies.length > 0 && (
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-2">
                Matched Policies ({policies.length})
              </p>
              <div className="space-y-1.5">
                {policies.map((pol, i) => (
                  <div
                    key={pol.policy_id || i}
                    className="flex items-center gap-2 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2"
                  >
                    <Shield className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-amber-900 truncate">
                        {pol.policy_name || pol.name || `Policy ${shortId(pol.policy_id)}`}
                      </p>
                      {pol.effect && (
                        <p className="text-[11px] text-amber-600">
                          Effect: {pol.effect}
                        </p>
                      )}
                    </div>
                    {pol.policy_id && (
                      <Badge tone="amber">{pol.effect || 'DENY'}</Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Decision details ── */}
          {auditEvent?.decision && (
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">Decision</p>
              <DecisionBadge decision={auditEvent.decision} />
            </div>
          )}

          {/* ── Raw details JSON ── */}
          {detailsJson && (
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">
                Raw Event Data
              </p>
              <pre className="max-h-64 overflow-auto rounded-xl bg-slate-900 p-3 text-[11px] leading-relaxed text-slate-200 font-mono">
                {detailsJson}
              </pre>
            </div>
          )}

          {/* ── Quick actions ── */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
            {onNavigateToUser && (auditEvent?.user_id || auditEvent?.username) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateToUser(auditEvent.user_id || auditEvent.username)}
              >
                <User className="h-3.5 w-3.5" /> View User
              </Button>
            )}
            {onNavigateToResource && (auditEvent?.resource_name || auditEvent?.resource) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateToResource(auditEvent.resource_name || auditEvent.resource)}
              >
                <FileText className="h-3.5 w-3.5" /> View Resource
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
