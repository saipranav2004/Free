/**
 * ActivityFeed — Unified chronological activity feed for the PAM operations center.
 *
 * Research findings:
 *  - Okta PA uses a continuous activity feed (time-series) as the primary pattern
 *  - SIEM tools (Splunk, Sentinel) use severity-based visual grouping
 *  - Master-detail split requires a scannable, high-density list
 *  - Color-coded left borders provide instant severity recognition
 *
 * This component merges BOTH audit logs AND denial alerts into a single
 * chronological stream, with visual severity indicators:
 *  - Red left border + icon = DENIED/FAILURE
 *  - Green left border + icon = ALLOW/SUCCESS
 *  - Brand left border + icon = AuthZ events
 *  - Slate left border + icon = AuthN events
 *
 * Each row is clickable and sets the selected event in the parent PamPage,
 * which then displays full details in the EventDetailPanel.
 */
import { useCallback, useRef, useEffect } from 'react';
import {
  XCircle,
  CheckCircle2,
  ScrollText,
  AlertTriangle,
  Shield,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Badge, Spinner, Button } from '../ui/primitives.jsx';
import { formatDateTime, classNames } from '../../utils/format.js';

// ─── Severity mapping ─────────────────────────────────────────────────────────
// Maps event properties to visual severity treatment.
// Enterprise pattern: Color-coded left borders + icons for instant recognition.

function getEventSeverity(event) {
  const decision = String(event?.decision || '').toUpperCase();
  const status = String(event?.status || '').toUpperCase();
  const logType = String(event?.log_type || '').toLowerCase();

  if (decision === 'DENY' || status === 'FAILURE') {
    return {
      tone: 'danger',
      borderColor: 'border-l-rose-500',
      bgColor: 'hover:bg-rose-50/30',
      iconBg: 'bg-rose-50 text-rose-500',
      Icon: XCircle,
      badge: <Badge tone="red">DENIED</Badge>,
    };
  }

  if (decision === 'ALLOW' || status === 'SUCCESS') {
    return {
      tone: 'success',
      borderColor: 'border-l-emerald-500',
      bgColor: 'hover:bg-emerald-50/30',
      iconBg: 'bg-emerald-50 text-emerald-500',
      Icon: CheckCircle2,
      badge: <Badge tone="green">SUCCESS</Badge>,
    };
  }

  if (logType === 'authz') {
    return {
      tone: 'authz',
      borderColor: 'border-l-brand-500',
      bgColor: 'hover:bg-brand-50/30',
      iconBg: 'bg-brand-50 text-brand-500',
      Icon: Shield,
      badge: <Badge tone="brand">AUTHZ</Badge>,
    };
  }

  return {
    tone: 'authn',
    borderColor: 'border-l-slate-400',
    bgColor: 'hover:bg-slate-50',
    iconBg: 'bg-slate-100 text-slate-500',
    Icon: ScrollText,
    badge: <Badge tone="slate">AUTHN</Badge>,
  };
}

// ─── Activity row ─────────────────────────────────────────────────────────────

function ActivityRow({ event, isSelected, onSelect, index }) {
  const sev = getEventSeverity(event);
  const SevIcon = sev.Icon;

  return (
    <button
      onClick={() => onSelect(event)}
      className={classNames(
        'w-full text-left flex items-center gap-3 px-4 py-3 border-l-4 transition-all duration-100',
        sev.borderColor,
        isSelected
          ? 'bg-brand-50 ring-1 ring-inset ring-brand-200'
          : sev.bgColor,
        'focus:outline-none focus:ring-2 focus:ring-brand-300 focus:ring-inset'
      )}
    >
      {/* Severity icon */}
      <div className={classNames(
        'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg',
        sev.iconBg
      )}>
        <SevIcon className="h-4 w-4" />
      </div>

      {/* Event content */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 mb-0.5">
          <p className="text-sm font-medium text-ink-900 truncate">
            {event?.action || event?.event_type || 'Unknown action'}
          </p>
          {sev.badge}
        </div>
        <p className="text-xs text-slate-500 truncate">
          <span className="font-medium text-slate-600">
            {event?.username || event?.user_id || 'Unknown user'}
          </span>
          {' → '}
          <span className="text-slate-500">
            {event?.resource_name || event?.resource || event?.target_id || 'resource'}
          </span>
        </p>
      </div>

      {/* Timestamp */}
      <div className="shrink-0 text-right">
        <p className="text-[11px] text-slate-400 whitespace-nowrap">
          {formatDateTime(event?.created_at)}
        </p>
      </div>
    </button>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

/**
 * ActivityFeed
 *
 * Props:
 *  - events: Array of merged audit + alert events, sorted by created_at desc
 *  - selectedEvent: Currently selected event (for highlight)
 *  - onSelectEvent: Callback when an event is clicked
 *  - loading: Whether data is currently loading
 *  - error: Error message if data failed to load
 *  - pagination: { page, page_size, total, total_pages }
 *  - onPageChange: Callback when page changes
 *  - onRetry: Callback to retry on error
 *  - emptyMessage: Message when no events exist
 */
export function ActivityFeed({
  events = [],
  selectedEvent,
  onSelectEvent,
  loading = false,
  error = null,
  pagination,
  onPageChange,
  onRetry,
  emptyMessage = 'No events found',
}) {
  const listRef = useRef(null);

  // ── Scroll to top when events change (new page) ──
  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = 0;
    }
  }, [events]);

  // ── Loading state ──
  if (loading && events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <Spinner className="h-6 w-6" />
        <p className="mt-3 text-xs text-slate-400">Loading activity feed…</p>
      </div>
    );
  }

  // ── Error state (only show full error screen when no data exists) ──
  if (error && events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-6">
        <AlertTriangle className="h-8 w-8 text-amber-500 mb-3" />
        <p className="text-sm font-medium text-slate-700">Failed to load activity</p>
        <p className="mt-1 text-xs text-slate-500 text-center max-w-[240px]">
          {typeof error === 'string' ? error : 'An unexpected error occurred'}
        </p>
        {onRetry && (
          <Button variant="outline" size="sm" className="mt-3" onClick={onRetry}>
            Retry
          </Button>
        )}
      </div>
    );
  }

  // ── Empty state ──
  if (!loading && events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-6">
        <div className="rounded-2xl bg-slate-100 p-4 mb-3">
          <CheckCircle2 className="h-8 w-8 text-emerald-400" />
        </div>
        <p className="text-sm font-semibold text-ink-900">All clear</p>
        <p className="mt-1 text-xs text-slate-400 text-center max-w-[240px]">
          {emptyMessage}
        </p>
      </div>
    );
  }

  // ── Pagination info ──
  const totalPages = pagination?.total_pages || 1;
  const currentPage = pagination?.page || 1;
  const totalItems = pagination?.total || events.length;

  return (
    <div className="flex flex-col h-full">
      {/* ── Feed header with count ── */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-200 bg-slate-50/60">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
            Activity Feed
          </span>
          <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-bold text-slate-600">
            {totalItems}
          </span>
        </div>
        {loading && (
          <div className="flex items-center gap-1.5">
            <div className="h-1.5 w-1.5 rounded-full bg-brand-500 animate-pulse" />
            <span className="text-[10px] text-slate-400">Refreshing</span>
          </div>
        )}
      </div>

      {/* ── Event list ── */}
      <div ref={listRef} className="flex-1 overflow-y-auto divide-y divide-slate-100/80">
        {events.map((event, i) => {
          const eventId = event?.audit_id || event?.id || i;
          const isSelected = selectedEvent?.audit_id === eventId || selectedEvent?.id === eventId;
          return (
            <ActivityRow
              key={eventId}
              event={event}
              isSelected={isSelected}
              onSelect={onSelectEvent}
              index={i}
            />
          );
        })}
      </div>

      {/* ── Pagination ── */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-2 border-t border-slate-200 bg-slate-50/60">
          <span className="text-[11px] text-slate-400">
            Page {currentPage} of {totalPages}
          </span>
          <div className="flex gap-1">
            <button
              disabled={currentPage <= 1}
              onClick={() => onPageChange?.(currentPage - 1)}
              className="inline-flex items-center gap-0.5 rounded border border-slate-300 px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="h-3 w-3" /> Prev
            </button>
            <button
              disabled={currentPage >= totalPages}
              onClick={() => onPageChange?.(currentPage + 1)}
              className="inline-flex items-center gap-0.5 rounded border border-slate-300 px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Next <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
