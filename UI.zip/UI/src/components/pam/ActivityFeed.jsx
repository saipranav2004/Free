/**
 * ActivityFeed — chronological event stream for the PAM master/detail views.
 *
 * Design decisions:
 *  · A 2px leading rail encodes the decision (denied / allowed / authz / authn)
 *    so severity is legible in peripheral vision while scanning fast.
 *  · Rows are one line of identity + one line of context: action, principal,
 *    resource, time. No wrapping, no truncation of the action verb.
 *  · The selected row is tinted and marked, because the detail pane on the
 *    right is only meaningful if you can see which row it belongs to.
 *  · Header is sticky within the pane and carries the count; pagination pins
 *    to the bottom so the list length never moves the controls.
 *  · Pagination is the console's shared control (numbered pages + a page-size
 *    selector), not a bespoke prev/next pair: an investigator needs to jump to
 *    a page and to widen the window, which two arrows cannot do.
 */
import { useEffect, useRef } from 'react';
import {
  XCircle, CheckCircle2, ScrollText, AlertTriangle, Shield, ChevronRight,
} from 'lucide-react';
import { Badge, Spinner, Button } from '../ui/primitives.jsx';
import { Pagination } from '../common/Pagination.jsx';
import { formatDateTime, classNames } from '../../utils/format.js';

function getEventSeverity(event) {
  const decision = String(event?.decision || '').toUpperCase();
  const status = String(event?.status || '').toUpperCase();
  const logType = String(event?.log_type || '').toLowerCase();

  if (decision === 'DENY' || status === 'FAILURE') {
    return {
      rail: 'bg-rose-500',
      hover: 'hover:bg-rose-50/40',
      iconWrap: 'bg-rose-50 text-rose-600',
      Icon: XCircle,
      label: 'Denied',
      tone: 'red',
    };
  }
  if (decision === 'ALLOW' || status === 'SUCCESS') {
    return {
      rail: 'bg-emerald-500',
      hover: 'hover:bg-emerald-50/40',
      iconWrap: 'bg-emerald-50 text-emerald-600',
      Icon: CheckCircle2,
      label: 'Allowed',
      tone: 'green',
    };
  }
  if (logType === 'authz') {
    return {
      rail: 'bg-brand-500',
      hover: 'hover:bg-brand-50/40',
      iconWrap: 'bg-brand-50 text-brand-600',
      Icon: Shield,
      label: 'AuthZ',
      tone: 'brand',
    };
  }
  return {
    rail: 'bg-slate-300',
    hover: 'hover:bg-slate-50',
    iconWrap: 'bg-slate-100 text-slate-500',
    Icon: ScrollText,
    label: 'AuthN',
    tone: 'slate',
  };
}

function ActivityRow({ event, isSelected, onSelect }) {
  const sev = getEventSeverity(event);
  const SevIcon = sev.Icon;

  return (
    <button
      type="button"
      onClick={() => onSelect?.(event)}
      aria-current={isSelected || undefined}
      className={classNames(
        'relative flex w-full items-center gap-3 py-2.5 pl-4 pr-3 text-left transition-colors',
        isSelected ? 'bg-brand-50/70' : sev.hover
      )}
    >
      <span className={classNames('absolute inset-y-0 left-0 w-[2px]', sev.rail)} />
      <span
        className={classNames(
          'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg',
          sev.iconWrap
        )}
      >
        <SevIcon className="h-3.5 w-3.5" />
      </span>

      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="truncate font-mono text-xs font-medium text-ink-900">
            {event?.action || event?.event_type || 'unknown.action'}
          </span>
          <Badge tone={sev.tone}>{sev.label}</Badge>
        </span>
        <span className="mt-0.5 block truncate text-2xs text-slate-500">
          <span className="font-medium text-slate-600">
            {event?.username || event?.user_id || 'unknown principal'}
          </span>
          <span className="mx-1 text-slate-300">→</span>
          {event?.resource_name || event?.resource || event?.target_id || 'resource'}
        </span>
      </span>

      <span className="shrink-0 whitespace-nowrap text-2xs text-slate-400">
        {formatDateTime(event?.created_at)}
      </span>
      {isSelected && <ChevronRight className="h-4 w-4 shrink-0 text-brand-500" />}
    </button>
  );
}

export function ActivityFeed({
  events = [],
  selectedEvent,
  onSelectEvent,
  loading = false,
  error = null,
  pagination,
  onPageChange,
  // Page size is part of paging on an audit surface: 10 rows to read carefully,
  // 100 to scan a burst. Omit the handler to hide the selector.
  onPerPageChange,
  perPageOptions = [10, 20, 50, 100],
  onRetry,
  // An authorisation failure needs its own heading (and no Retry button, since
  // retrying an identical refused request cannot succeed).
  errorTitle = 'Could not load events',
  canRetry = true,
  emptyMessage = 'No events found',
  title = 'Activity feed',
}) {
  const listRef = useRef(null);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = 0;
  }, [events]);

  if (loading && events.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center py-16">
        <Spinner className="h-5 w-5" />
        <p className="mt-3 text-2xs text-slate-500">Loading events…</p>
      </div>
    );
  }

  if (error && events.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-16 text-center">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
        </span>
        <p className="mt-3 text-[13px] font-semibold text-ink-900">{errorTitle}</p>
        <p className="mt-1 max-w-[320px] text-xs leading-relaxed text-slate-500">
          {typeof error === 'string' ? error : 'An unexpected error occurred.'}
        </p>
        {onRetry && canRetry && (
          <Button variant="secondary" size="sm" className="mt-4" onClick={onRetry}>
            Retry
          </Button>
        )}
      </div>
    );
  }

  if (!loading && events.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-16 text-center">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50">
          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
        </span>
        <p className="mt-3 text-[13px] font-semibold text-ink-900">All clear</p>
        <p className="mt-1 max-w-[260px] text-xs text-slate-500">{emptyMessage}</p>
      </div>
    );
  }

  const currentPage = pagination?.page || 1;
  const perPage = pagination?.page_size || pagination?.per_page || events.length || 20;
  const totalItems = pagination?.total ?? events.length;
  const showPagination = totalItems > perPage || !!onPerPageChange;

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-line bg-slate-50/70 px-4 py-2">
        <div className="flex items-center gap-2">
          <span className="text-3xs font-semibold uppercase tracking-[0.1em] text-slate-500">
            {title}
          </span>
          <span className="rounded-md bg-white px-1.5 py-0.5 text-3xs font-bold text-slate-600 ring-1 ring-inset ring-line tabular">
            {totalItems.toLocaleString()}
          </span>
        </div>
        {loading && (
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-brand-500" />
            <span className="text-3xs text-slate-500">Refreshing</span>
          </span>
        )}
      </div>

      <div ref={listRef} className="max-h-[560px] flex-1 divide-y divide-line-soft overflow-y-auto">
        {events.map((event, i) => {
          const eventId = event?.audit_id || event?.id || i;
          const selectedId = selectedEvent?.audit_id || selectedEvent?.id;
          return (
            <ActivityRow
              key={eventId}
              event={event}
              isSelected={selectedId != null && selectedId === eventId}
              onSelect={onSelectEvent}
            />
          );
        })}
      </div>

      {showPagination && (
        <div className="border-t border-line bg-slate-50/70 px-4 py-2">
          <Pagination
            page={currentPage}
            perPage={perPage}
            total={totalItems}
            onPageChange={onPageChange}
            onPerPageChange={onPerPageChange}
            perPageOptions={perPageOptions}
            className="pt-0"
          />
        </div>
      )}
    </div>
  );
}
