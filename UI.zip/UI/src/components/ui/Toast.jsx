import { CheckCircle2, XCircle, Info, AlertTriangle, X } from 'lucide-react';
import { classNames } from '../../utils/format.js';

const ICONS = {
  success: CheckCircle2,
  error: XCircle,
  info: Info,
  warning: AlertTriangle,
};

const TONES = {
  success: 'border-l-emerald-500',
  error: 'border-l-rose-500',
  info: 'border-l-brand-500',
  warning: 'border-l-amber-500',
};

const ICON_TONES = {
  success: 'text-emerald-500',
  error: 'text-rose-500',
  info: 'text-brand-500',
  warning: 'text-amber-500',
};

export function ToastViewport({ toasts, onDismiss }) {
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-full max-w-sm flex-col gap-2">
      {toasts.map((t) => {
        const Icon = ICONS[t.type] || Info;
        return (
          <div
            key={t.id}
            className={classNames(
              'pointer-events-auto flex items-start gap-3 rounded-lg border-l-4 bg-white px-4 py-3 shadow-lg',
              TONES[t.type] || TONES.info
            )}
            role="status"
          >
            <Icon className={classNames('mt-0.5 h-5 w-5 shrink-0', ICON_TONES[t.type])} />
            <div className="flex-1 text-sm text-ink-800">{t.message}</div>
            <button
              onClick={() => onDismiss(t.id)}
              className="text-slate-400 hover:text-ink-700"
              aria-label="Dismiss"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
