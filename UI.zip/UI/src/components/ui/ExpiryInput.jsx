/**
 * ExpiryInput — the console's only expiry / expiration date control.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY A DEDICATED COMPONENT
 * ═══════════════════════════════════════════════════════════════════════════
 * An expiry in the past is never a valid grant: it either silently revokes
 * access the moment it is saved, or the backend rejects it and the operator has
 * to guess why. Every expiry field was a bare `<Input type="datetime-local">`
 * with no lower bound, so yesterday was selectable everywhere.
 *
 * This component owns that rule in one place:
 *  · `min` is pinned to now (or today for a date-only field), so the native
 *    calendar renders every earlier day greyed out and unclickable — the OS
 *    picker does the "blacked out" treatment for us, which is what operators
 *    already recognise from Entra and Okta.
 *  · Typed input is validated too (a keyboard can defeat any `min`), with
 *    inline copy rather than a silent correction.
 *  · `toIsoExpiry()` performs the local → ISO-8601 conversion the API expects,
 *    so formatting stays identical to what the pages did before.
 *
 * It is a thin wrapper over the existing `Input` primitive, so label, hint and
 * error styling are unchanged.
 */
import { forwardRef, useMemo } from 'react';
import { Input } from './primitives.jsx';

/** Local `YYYY-MM-DDTHH:mm` for a Date (never UTC — the control is local). */
function toLocalDateTimeValue(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return (
    `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
    `T${pad(date.getHours())}:${pad(date.getMinutes())}`
  );
}

/** Local `YYYY-MM-DD` for a Date. */
function toLocalDateValue(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** Earliest selectable value: this minute for datetime, today for date. */
export function minExpiryValue(mode = 'datetime') {
  const now = new Date();
  return mode === 'date' ? toLocalDateValue(now) : toLocalDateTimeValue(now);
}

/** True when a control value is earlier than now — i.e. already expired. */
export function isPastExpiry(value, mode = 'datetime') {
  if (!value) return false;
  const picked = new Date(value);
  if (Number.isNaN(picked.getTime())) return false;
  if (mode === 'date') {
    // A date-only expiry means "end of that day", so today is still valid.
    const endOfDay = new Date(picked);
    endOfDay.setHours(23, 59, 59, 999);
    return endOfDay.getTime() < Date.now();
  }
  return picked.getTime() < Date.now();
}

/**
 * Control value → the ISO-8601 string the API expects, or null when empty.
 * Same conversion the pages performed inline; centralised so it cannot drift.
 */
export function toIsoExpiry(value) {
  if (!value) return null;
  const picked = new Date(value);
  if (Number.isNaN(picked.getTime())) return null;
  return picked.toISOString();
}

/** ISO-8601 from the API → a value this control can display. */
export function fromIsoExpiry(iso, mode = 'datetime') {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return mode === 'date' ? toLocalDateValue(date) : toLocalDateTimeValue(date);
}

export const PAST_EXPIRY_MESSAGE = 'Choose today or a later date — an expiry in the past grants no access.';

export const ExpiryInput = forwardRef(function ExpiryInput(
  {
    label = 'Expires at',
    mode = 'datetime',
    value,
    error,
    hint,
    /** Pass false to allow a blank value with no "required" affordance. */
    required = false,
    ...props
  },
  ref
) {
  // Recomputed per render so a long-lived form cannot drift behind the clock.
  const min = useMemo(() => minExpiryValue(mode), [mode]);
  const past = isPastExpiry(value, mode);

  return (
    <Input
      ref={ref}
      label={label}
      type={mode === 'date' ? 'date' : 'datetime-local'}
      value={value || ''}
      /* The native picker disables everything before `min`; the explicit error
         covers a value typed straight into the field. */
      min={min}
      required={required}
      error={error || (past ? PAST_EXPIRY_MESSAGE : undefined)}
      hint={error || past ? undefined : hint}
      {...props}
    />
  );
});

export default ExpiryInput;
