import { forwardRef, useState, useRef, useEffect, useCallback } from 'react';
import { Loader2, Search, ChevronDown, Check, X } from 'lucide-react';
import { classNames } from '../../utils/format.js';

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled,
  className,
  type = 'button',
  ...props
}) {
  const variants = {
    primary:
      'bg-brand-600 text-white hover:bg-brand-700 focus:ring-brand-300',
    secondary:
      'bg-white text-ink-700 ring-1 ring-inset ring-slate-300 hover:bg-slate-50 focus:ring-brand-300',
    danger: 'bg-rose-600 text-white hover:bg-rose-700 focus:ring-rose-300',
    ghost: 'bg-transparent text-ink-600 hover:bg-slate-100 focus:ring-slate-300',
    outline:
      'bg-white text-brand-700 ring-1 ring-inset ring-brand-300 hover:bg-brand-50 focus:ring-brand-300',
  };
  const sizes = {
    sm: 'px-2.5 py-1.5 text-xs',
    md: 'px-3.5 py-2 text-sm',
    lg: 'px-5 py-2.5 text-sm',
  };
  return (
    <button
      type={type}
      disabled={disabled || loading}
      className={classNames(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium transition focus:outline-none focus:ring-2 disabled:cursor-not-allowed disabled:opacity-60',
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
}

export function Card({ className, children, ...props }) {
  return (
    <div className={classNames('card', className)} {...props}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, action }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4">
      <div>
        <h3 className="text-sm font-semibold text-ink-900">{title}</h3>
        {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export const Input = forwardRef(function Input(
  { label, error, hint, className, id, ...props },
  ref
) {
  const inputId = id || props.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="label-base">
          {label}
        </label>
      )}
      <input
        id={inputId}
        ref={ref}
        className={classNames('input-base', error && 'border-rose-400 focus:ring-rose-200', className)}
        {...props}
      />
      {hint && !error && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
      {error && <p className="mt-1 text-xs text-rose-600">{error}</p>}
    </div>
  );
});

export const Textarea = forwardRef(function Textarea(
  { label, error, className, id, rows = 4, ...props },
  ref
) {
  const inputId = id || props.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="label-base">
          {label}
        </label>
      )}
      <textarea
        id={inputId}
        ref={ref}
        rows={rows}
        className={classNames('input-base', error && 'border-rose-400 focus:ring-rose-200', className)}
        {...props}
      />
      {error && <p className="mt-1 text-xs text-rose-600">{error}</p>}
    </div>
  );
});

export const Select = forwardRef(function Select(
  { label, error, className, id, children, ...props },
  ref
) {
  const inputId = id || props.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="label-base">
          {label}
        </label>
      )}
      <select
        id={inputId}
        ref={ref}
        className={classNames('input-base', error && 'border-rose-400', className)}
        {...props}
      >
        {children}
      </select>
      {error && <p className="mt-1 text-xs text-rose-600">{error}</p>}
    </div>
  );
});

export function Badge({ children, tone = 'slate', className }) {
  const tones = {
    slate: 'bg-slate-100 text-slate-700 ring-slate-500/20',
    brand: 'bg-brand-50 text-brand-700 ring-brand-600/20',
    green: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
    amber: 'bg-amber-50 text-amber-700 ring-amber-600/20',
    red: 'bg-rose-50 text-rose-700 ring-rose-600/20',
    sky: 'bg-sky-50 text-sky-700 ring-sky-600/20',
  };
  return (
    <span
      className={classNames(
        'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset',
        tones[tone] || tones.slate,
        className
      )}
    >
      {children}
    </span>
  );
}

export function Spinner({ className }) {
  return <Loader2 className={classNames('h-5 w-5 animate-spin text-brand-500', className)} />;
}

export function StatusBadge({ status }) {
  const styleMap = {
    ACTIVE: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
    ENABLED: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
    LOCKED: 'bg-amber-50 text-amber-700 ring-amber-600/20',
    PENDING_VERIFICATION: 'bg-sky-50 text-sky-700 ring-sky-600/20',
    DISABLED: 'bg-slate-100 text-slate-600 ring-slate-500/20',
    OFFBOARDED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
    DELETED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
    SUSPENDED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
    EXPIRED: 'bg-amber-50 text-amber-700 ring-amber-600/20',
    REVOKED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
    ROTATED: 'bg-slate-100 text-slate-600 ring-slate-500/20',
  };
  return (
    <span
      className={classNames(
        'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset',
        styleMap[status] || 'bg-slate-100 text-slate-600 ring-slate-500/20'
      )}
    >
      {status}
    </span>
  );
}

export function StatCard({ label, value, hint, icon: Icon, tone = 'brand' }) {
  const tones = {
    brand: 'bg-brand-50 text-brand-600',
    green: 'bg-emerald-50 text-emerald-600',
    amber: 'bg-amber-50 text-amber-600',
    red: 'bg-rose-50 text-rose-600',
    slate: 'bg-slate-100 text-slate-600',
  };
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-500">{label}</p>
          <p className="mt-1 text-2xl font-semibold text-ink-900">{value}</p>
          {hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
        </div>
        {Icon && (
          <div className={classNames('rounded-lg p-2.5', tones[tone])}>
            <Icon className="h-5 w-5" />
          </div>
        )}
      </div>
    </Card>
  );
}

export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
      {Icon && (
        <div className="mb-4 rounded-full bg-slate-100 p-4 text-slate-400">
          <Icon className="h-8 w-8" />
        </div>
      )}
      <p className="text-sm font-semibold text-ink-900">{title}</p>
      {description && (
        <p className="mt-1.5 max-w-xs text-sm text-slate-500">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Tabs({ tabs, active, onChange }) {
  return (
    <div className="flex gap-1 border-b border-slate-200">
      {tabs.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={classNames(
            'relative -mb-px border-b-2 px-3 py-2 text-sm font-medium transition',
            active === t.id
              ? 'border-brand-600 text-brand-700'
              : 'border-transparent text-slate-500 hover:text-ink-700'
          )}
        >
          {t.label}
          {t.count != null && (
            <span className="ml-2 rounded-full bg-slate-100 px-1.5 py-0.5 text-xs text-slate-600">
              {t.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

export function Switch({ checked, onChange, label }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={classNames(
        'relative inline-flex h-5 w-9 items-center rounded-full transition',
        checked ? 'bg-brand-600' : 'bg-slate-300'
      )}
    >
      <span
        className={classNames(
          'inline-block h-4 w-4 transform rounded-full bg-white shadow transition',
          checked ? 'translate-x-4' : 'translate-x-0.5'
        )}
      />
      {label && <span className="sr-only">{label}</span>}
    </button>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SearchableCombobox — Enterprise-grade searchable/filterable dropdown
// ═══════════════════════════════════════════════════════════════════════════════
// Supports both single-select and multi-select modes.
// Pattern inspired by Azure AD, Okta, and Google Admin comboboxes.
//
// Props:
//  - options: Array<{ id: string, label: string, description?: string, icon?: ReactNode, badge?: string }>
//  - value: string (single) or string[] (multi)
//  - onChange: (value) => void
//  - label?: string
//  - placeholder?: string
//  - searchPlaceholder?: string
//  - loading?: boolean
//  - error?: string
//  - hint?: string
//  - multi?: boolean
//  - disabled?: boolean
//  - className?: string
//  - emptyMessage?: string
// ═══════════════════════════════════════════════════════════════════════════════
export function SearchableCombobox({
  options = [],
  value,
  onChange,
  label,
  placeholder = 'Select…',
  searchPlaceholder = 'Search…',
  loading = false,
  error,
  hint,
  multi = false,
  disabled = false,
  className,
  emptyMessage = 'No options match your search.',
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [highlightIdx, setHighlightIdx] = useState(-1);
  const containerRef = useRef(null);
  const searchInputRef = useRef(null);
  const listRef = useRef(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handleClick = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
        setSearch('');
        setHighlightIdx(-1);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [open]);

  // Auto-focus search input when dropdown opens
  useEffect(() => {
    if (open && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [open]);

  // Filter options based on search query
  const filtered = options.filter((opt) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      opt.label?.toLowerCase().includes(q) ||
      opt.description?.toLowerCase().includes(q) ||
      opt.id?.toLowerCase().includes(q)
    );
  });

  // Reset highlight when filter changes
  useEffect(() => {
    setHighlightIdx(-1);
  }, [search]);

  // Scroll highlighted item into view
  useEffect(() => {
    if (highlightIdx >= 0 && listRef.current) {
      const items = listRef.current.querySelectorAll('[data-combo-item]');
      if (items[highlightIdx]) {
        items[highlightIdx].scrollIntoView({ block: 'nearest' });
      }
    }
  }, [highlightIdx]);

  // Single-select: find the selected option
  const selectedSingle = !multi ? options.find((o) => o.id === value) : null;

  // Multi-select: find selected options
  const selectedIds = multi ? (Array.isArray(value) ? value : []) : [];
  const selectedMulti = multi ? options.filter((o) => selectedIds.includes(o.id)) : [];

  const toggleOption = useCallback((id) => {
    if (multi) {
      const current = Array.isArray(value) ? [...value] : [];
      const idx = current.indexOf(id);
      if (idx >= 0) {
        current.splice(idx, 1);
      } else {
        current.push(id);
      }
      onChange(current);
    } else {
      onChange(id);
      setOpen(false);
      setSearch('');
      setHighlightIdx(-1);
    }
  }, [multi, value, onChange]);

  const removeMultiItem = useCallback((id) => {
    if (!multi) return;
    const current = Array.isArray(value) ? value.filter((v) => v !== id) : [];
    onChange(current);
  }, [multi, value, onChange]);

  // Clear single-select value
  const clearSingle = useCallback((e) => {
    e.stopPropagation();
    onChange('');
    setSearch('');
    setHighlightIdx(-1);
  }, [onChange]);

  const isSelected = (id) => multi ? selectedIds.includes(id) : value === id;

  // ── Keyboard navigation (defined after toggleOption to avoid hoisting issues) ──
  const handleKeyDown = useCallback((e) => {
    if (!open) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        setOpen(true);
      }
      return;
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setHighlightIdx((prev) => (prev < filtered.length - 1 ? prev + 1 : 0));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setHighlightIdx((prev) => (prev > 0 ? prev - 1 : filtered.length - 1));
        break;
      case 'Enter':
        e.preventDefault();
        if (highlightIdx >= 0 && highlightIdx < filtered.length) {
          toggleOption(filtered[highlightIdx].id);
        }
        break;
      case 'Escape':
        e.preventDefault();
        setOpen(false);
        setSearch('');
        setHighlightIdx(-1);
        break;
      case 'Tab':
        setOpen(false);
        setSearch('');
        setHighlightIdx(-1);
        break;
      default:
        break;
    }
  }, [open, filtered, highlightIdx, toggleOption]);

  // ── Render option icon/avatar ──
  const renderOptionIcon = (opt) => {
    if (opt.icon) return opt.icon;
    return (
      <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
        {opt.label?.charAt(0)?.toUpperCase() || '?'}
      </span>
    );
  };

  return (
    <div className={classNames('w-full', className)} ref={containerRef}>
      {label && (
        <label className="label-base">
          {label}
        </label>
      )}

      {/* ── Multi-select: show selected tags above trigger ── */}
      {multi && selectedMulti.length > 0 && (
        <div className="mb-1.5 flex flex-wrap gap-1.5">
          {selectedMulti.map((opt) => (
            <span
              key={opt.id}
              className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700 ring-1 ring-inset ring-brand-600/20"
            >
              {opt.label}
              <button
                type="button"
                onClick={() => removeMultiItem(opt.id)}
                className="rounded-full p-0.5 hover:bg-brand-100 transition"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* ── Trigger button ── */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={handleKeyDown}
        className={classNames(
          'flex w-full items-center justify-between gap-2 rounded-lg border bg-white px-3 py-2.5 text-left text-sm transition',
          'hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-300',
          open ? 'border-brand-400 ring-2 ring-brand-300' : 'border-slate-200',
          error && 'border-rose-400 focus:ring-rose-200',
          disabled && 'opacity-60 cursor-not-allowed'
        )}
      >
        {multi ? (
          selectedMulti.length > 0 ? (
            <span className="text-sm text-ink-900">
              {selectedMulti.length} selected
            </span>
          ) : (
            <span className="text-sm text-slate-400">{placeholder}</span>
          )
        ) : selectedSingle ? (
          <span className="flex items-center gap-2 min-w-0 flex-1">
            {renderOptionIcon(selectedSingle)}
            <div className="min-w-0 flex-1">
              <span className="text-sm font-medium text-ink-900">{selectedSingle.label}</span>
              {selectedSingle.description && (
                <span className="ml-1.5 text-sm text-slate-400">· {selectedSingle.description}</span>
              )}
            </div>
          </span>
        ) : (
          <span className="text-sm text-slate-400">{placeholder}</span>
        )}
        <div className="flex items-center gap-1 shrink-0">
          {/* Clear button for single-select */}
          {!multi && selectedSingle && !disabled && (
            <button
              type="button"
              onClick={clearSingle}
              className="rounded-full p-0.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
              aria-label="Clear selection"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
          <ChevronDown className={classNames(
            'h-4 w-4 shrink-0 text-slate-400 transition-transform',
            open && 'rotate-180'
          )} />
        </div>
      </button>

      {hint && !error && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
      {error && <p className="mt-1 text-xs text-rose-600">{error}</p>}

      {/* ── Dropdown panel ── */}
      {open && (
        <div className="relative z-50 mt-1 w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
          {/* Search input */}
          <div className="border-b border-slate-100 p-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                ref={searchInputRef}
                type="text"
                placeholder={searchPlaceholder}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-8 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-300"
              />
            </div>
          </div>

          {/* Options list */}
          <div ref={listRef} className="max-h-60 overflow-y-auto p-1">
            {loading ? (
              <div className="flex items-center justify-center gap-2 py-6">
                <Spinner className="h-4 w-4" />
                <span className="text-sm text-slate-500">Loading…</span>
              </div>
            ) : filtered.length === 0 ? (
              <p className="px-3 py-4 text-center text-sm text-slate-400">{emptyMessage}</p>
            ) : (
              filtered.map((opt, idx) => {
                const active = isSelected(opt.id);
                const highlighted = idx === highlightIdx;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    data-combo-item
                    onClick={() => toggleOption(opt.id)}
                    className={classNames(
                      'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition',
                      active ? 'bg-brand-50' : highlighted ? 'bg-slate-100' : 'hover:bg-slate-50'
                    )}
                  >
                    {renderOptionIcon(opt)}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-medium text-ink-900">{opt.label}</span>
                        {opt.badge && (
                          <span className="inline-flex items-center rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-600 ring-1 ring-inset ring-slate-500/20">
                            {opt.badge}
                          </span>
                        )}
                      </div>
                      {opt.description && (
                        <p className="truncate text-xs text-slate-400">{opt.description}</p>
                      )}
                    </div>
                    {active && <Check className="h-4 w-4 shrink-0 text-brand-600" />}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
