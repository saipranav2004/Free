import { Spinner, EmptyState } from './primitives.jsx';
import { classNames } from '../../utils/format.js';

/**
 * Enterprise-grade data table with density control, row count,
 * and consistent alignment.
 *
 * columns: [{ id, header, render?(row), className?, align? }]
 * density: 'compact' | 'normal' — controls row padding
 */
export function DataTable({
  columns,
  data = [],
  loading = false,
  rowKey,
  onRowClick,
  density = 'normal',
  empty = { title: 'No records found' },
  getRowId = (row, i) => row?.id || row?.user_id || row?.role_id || row?.group_id || row?.policy_id || row?.key_id || row?.delegation_id || i,
}) {
  // Enterprise: consistent cell padding based on density setting
  const cellPadding = density === 'compact' ? 'px-4 py-2' : 'px-4 py-3';

  if (loading) {
    return (
      <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white py-16">
        <Spinner className="h-6 w-6" />
      </div>
    );
  }

  if (!data.length) {
    return (
      <EmptyState
        title={empty.title}
        description={empty.description}
        icon={empty.icon}
        action={empty.action}
      />
    );
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
      {/* Enterprise: show row count above table for scannability */}
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2">
        <span className="text-xs text-slate-400">
          {data.length} record{data.length !== 1 ? 's' : ''}
        </span>
      </div>
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-50">
          <tr>
            {columns.map((col) => (
              <th
                key={col.id}
                className={classNames(
                  cellPadding,
                  'text-left text-xs font-semibold uppercase tracking-wide text-slate-500',
                  col.align === 'right' && 'text-right',
                  col.align === 'center' && 'text-center',
                  col.className
                )}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {data.map((row, i) => {
            const id = getRowId(row, i);
            return (
              <tr
                key={id}
                onClick={() => onRowClick?.(row)}
                className={
                  onRowClick
                    ? 'cursor-pointer transition hover:bg-slate-50'
                    : 'transition hover:bg-slate-50'
                }
              >
                {columns.map((col) => (
                  <td
                    key={col.id}
                    className={classNames(
                      cellPadding,
                      'text-ink-800',
                      col.align === 'right' && 'text-right',
                      col.align === 'center' && 'text-center',
                      col.className
                    )}
                  >
                    {col.render ? col.render(row, i) : row[col.id]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
