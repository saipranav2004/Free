/**
 * DataTable — the console's tabular surface.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * DESIGN DECISIONS (enterprise table research)
 * ═══════════════════════════════════════════════════════════════════════════
 *  · Sticky header — context is never lost while scrolling long result sets.
 *  · Density as a named, persisted user setting (compact / comfortable).
 *  · Column chooser + persisted preferences: power users live in one or two
 *    tables all day and want them shaped to their job, not to ours.
 *  · Bulk selection with a contextual action bar: identity work is repetitive
 *    (disable ten leavers, export a cohort) and one-row-at-a-time is the single
 *    biggest time sink in an admin console.
 *  · Quiet borders, light hover, right-aligned row actions.
 *  · Below `md` the table becomes a stacked record list, not a scrolling grid.
 *
 * API (backwards compatible):
 *   columns: [{ id, header, render?(row, i), className?, align?, sortable?,
 *               sortValue?(row), hideOnMobile?, primary?, hideable? }]
 *   data, loading, density, empty, getRowId, onRowClick, title, subtitle,
 *   toolbar, densityToggle, densityStorageKey, maxHeight, footer, showCount
 * New, all optional:
 *   selectable, selectedIds, onSelectionChange, bulkActions, columnsStorageKey
 * ═══════════════════════════════════════════════════════════════════════════
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronsUpDown, List, AlignJustify, Columns3, X, Check } from 'lucide-react';
import { Spinner, EmptyState, SegmentedControl, Checkbox } from './primitives.jsx';
import { classNames } from '../../utils/format.js';

const DEFAULT_ROW_ID = (row, i) =>
  row?.id ??
  row?.user_id ??
  row?.role_id ??
  row?.group_id ??
  row?.policy_id ??
  row?.key_id ??
  row?.delegation_id ??
  row?.resource_id ??
  row?.audit_id ??
  i;

function readStored(key, fallback) {
  if (!key) return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeStored(key, value) {
  if (!key) return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — preference stays session-local */
  }
}

export function DataTable({
  columns = [],
  data = [],
  loading = false,
  rowKey,
  onRowClick,
  density = 'compact',
  empty = { title: 'No records found' },
  getRowId = DEFAULT_ROW_ID,
  title,
  subtitle,
  toolbar,
  densityToggle = true,
  densityStorageKey = 'iam-table-density',
  columnsStorageKey,
  maxHeight,
  footer,
  showCount = true,
  stickyHeader = true,
  selectable = false,
  selectedIds = [],
  onSelectionChange,
  bulkActions,
  className,
}) {
  const [localDensity, setLocalDensity] = useState(() => {
    const stored = readStored(densityStorageKey, null);
    return stored === 'compact' || stored === 'normal' ? stored : density;
  });
  const [hiddenColumns, setHiddenColumns] = useState(() => readStored(columnsStorageKey, []) || []);
  const [columnMenuOpen, setColumnMenuOpen] = useState(false);
  const columnMenuTriggerRef = useRef(null);
  const [sort, setSort] = useState({ id: null, dir: 'asc' });
  const columnMenuRef = useRef(null);

  useEffect(() => writeStored(densityStorageKey, localDensity), [localDensity, densityStorageKey]);
  useEffect(() => writeStored(columnsStorageKey, hiddenColumns), [hiddenColumns, columnsStorageKey]);

  useEffect(() => {
    if (!columnMenuOpen) return undefined;
    const onDown = (e) => {
      if (columnMenuRef.current && !columnMenuRef.current.contains(e.target)) setColumnMenuOpen(false);
    };
    // Escape closes and returns focus to the trigger, like every other popover.
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      e.stopPropagation();
      setColumnMenuOpen(false);
      columnMenuTriggerRef.current?.focus();
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [columnMenuOpen]);

  const cellPad = localDensity === 'compact' ? 'px-4 py-1.5' : 'px-4 py-2.5';
  const headPad = localDensity === 'compact' ? 'py-2' : 'py-2.5';

  const visibleColumns = useMemo(
    () => columns.filter((c) => !hiddenColumns.includes(c.id)),
    [columns, hiddenColumns]
  );

  /* Columns offered in the chooser. An unlabelled header (the actions column,
     or a spacer) cannot be listed meaningfully, so it is never hideable — that
     is what produced blank rows in the menu. */
  const hideableColumns = columns.filter(
    (c) =>
      c.hideable !== false &&
      c.id !== 'actions' &&
      !c.primary &&
      typeof c.header === 'string' &&
      c.header.trim() !== ''
  );

  const toggleColumn = (id) =>
    setHiddenColumns((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );

  const sortedData = useMemo(() => {
    if (!sort.id) return data;
    const col = columns.find((c) => c.id === sort.id);
    if (!col) return data;
    const valueOf =
      col.sortValue ||
      ((row) => {
        const v = row?.[col.id];
        return typeof v === 'string' ? v.toLowerCase() : v;
      });
    const copy = [...data];
    copy.sort((a, b) => {
      const va = valueOf(a);
      const vb = valueOf(b);
      if (va == null && vb == null) return 0;
      if (va == null) return 1;
      if (vb == null) return -1;
      if (va === vb) return 0;
      const res = va > vb ? 1 : -1;
      return sort.dir === 'asc' ? res : -res;
    });
    return copy;
  }, [data, sort, columns]);

  const toggleSort = (col) => {
    if (!col.sortable) return;
    setSort((prev) =>
      prev.id === col.id
        ? { id: col.id, dir: prev.dir === 'asc' ? 'desc' : 'asc' }
        : { id: col.id, dir: 'asc' }
    );
  };

  /* ── Selection ── */
  const allIds = useMemo(
    () => sortedData.map((row, i) => (rowKey ? rowKey(row, i) : getRowId(row, i))),
    [sortedData, rowKey, getRowId]
  );
  const selectedSet = useMemo(() => new Set(selectedIds), [selectedIds]);
  const selectedOnPage = allIds.filter((id) => selectedSet.has(id));
  const allSelected = allIds.length > 0 && selectedOnPage.length === allIds.length;
  const someSelected = selectedOnPage.length > 0 && !allSelected;

  const toggleAll = () => onSelectionChange?.(allSelected ? [] : allIds);
  const toggleOne = (id) =>
    onSelectionChange?.(
      selectedSet.has(id) ? selectedIds.filter((x) => x !== id) : [...selectedIds, id]
    );

  /* The column chooser used to require `columnsStorageKey`, so most tables in
     the console rendered no Columns control at all. It is available wherever
     there are hideable columns now; the key only decides whether the choice is
     remembered between visits. */
  const showColumnChooser = hideableColumns.length > 0;
  const hasChrome = title || toolbar || showCount || densityToggle || showColumnChooser;

  if (loading) {
    return (
      <div className="card flex items-center justify-center py-20">
        <Spinner className="h-5 w-5" />
      </div>
    );
  }

  if (!data.length) {
    return (
      <EmptyState
        title={empty.title}
        description={empty.description}
        icon={empty.icon}
        action={empty.action}
      />
    );
  }

  const mobileColumns = visibleColumns.filter((c) => c.id !== 'actions' && !c.primary);
  const primaryColumn = visibleColumns.find((c) => c.primary) || visibleColumns[0];
  const actionColumn = visibleColumns.find((c) => c.id === 'actions');

  return (
    /* `overflow-hidden` on the card was clipping the header popovers, which is
       why the Columns menu appeared to do nothing — it was rendering inside a
       clipped box. The card no longer clips; the scrolling regions below own
       their own overflow and rounded corners instead. */
    <div className={classNames('card overflow-visible', className)}>
      {hasChrome && (
        <div className="relative z-20 flex flex-col gap-2 border-b border-line-soft px-4 py-2.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex min-w-0 items-center gap-3">
            {title ? (
              <div className="min-w-0">
                <h3 className="truncate text-[13.5px] font-semibold text-ink-900">{title}</h3>
                {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
              </div>
            ) : (
              showCount && (
                <span className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-500">
                  {data.length.toLocaleString()} record{data.length !== 1 ? 's' : ''}
                </span>
              )
            )}
            {title && showCount && (
              <span className="rounded-md bg-slate-100 px-1.5 py-0.5 text-2xs font-semibold text-slate-600 tabular">
                {data.length.toLocaleString()}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {toolbar}
            {showColumnChooser && (
              <div className="relative hidden md:block" ref={columnMenuRef}>
                <button
                  ref={columnMenuTriggerRef}
                  type="button"
                  onClick={() => setColumnMenuOpen((o) => !o)}
                  title="Choose columns"
                  aria-expanded={columnMenuOpen}
                  className={classNames(
                    'inline-flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-2xs font-medium transition-colors',
                    columnMenuOpen
                      ? 'border-brand-300 bg-brand-50 text-brand-800'
                      : 'border-line bg-white text-slate-600 hover:bg-slate-50'
                  )}
                >
                  <Columns3 className="h-3.5 w-3.5" />
                  Columns
                  {hiddenColumns.length > 0 && (
                    <span className="rounded bg-slate-100 px-1 text-3xs font-semibold text-slate-600">
                      {visibleColumns.length}/{columns.length}
                    </span>
                  )}
                </button>
                {columnMenuOpen && (
                  <div
                    role="group"
                    aria-label="Visible columns"
                    className="absolute right-0 z-50 mt-1.5 max-h-[320px] w-56 overflow-y-auto rounded-xl border border-line bg-white p-1.5 shadow-popover animate-pop-in"
                  >
                    <p className="px-2 pb-1 pt-1.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                      Visible columns
                    </p>
                    {hideableColumns.map((col) => {
                      const visible = !hiddenColumns.includes(col.id);
                      return (
                        <button
                          key={col.id}
                          type="button"
                          role="menuitemcheckbox"
                          aria-checked={visible}
                          onClick={() => toggleColumn(col.id)}
                          className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-slate-50"
                        >
                          {/* Presentational box — a real Checkbox here would nest a button in a button. */}
                          <span
                            aria-hidden="true"
                            className={classNames(
                              'flex h-4 w-4 shrink-0 items-center justify-center rounded border',
                              visible ? 'border-brand-600 bg-brand-600 text-white' : 'border-slate-300 bg-white'
                            )}
                          >
                            {visible && <Check className="h-3 w-3" strokeWidth={3} />}
                          </span>
                          <span className="truncate text-[13px] text-ink-800">{col.header}</span>
                        </button>
                      );
                    })}
                    {hiddenColumns.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setHiddenColumns([])}
                        className="mt-1 w-full rounded-lg border-t border-line-soft px-2 py-1.5 text-left text-2xs font-medium text-brand-700 transition-colors hover:bg-slate-50"
                      >
                        Show all columns
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
            {densityToggle && (
              <div className="hidden md:block">
                <SegmentedControl
                  size="sm"
                  ariaLabel="Row density"
                  value={localDensity}
                  onChange={setLocalDensity}
                  options={[
                    { value: 'normal', label: '', icon: List, title: 'Comfortable rows' },
                    { value: 'compact', label: '', icon: AlignJustify, title: 'Compact rows' },
                  ]}
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Contextual bulk bar — only exists while a selection does. */}
      {selectable && selectedIds.length > 0 && (
        <div className="flex flex-col gap-2 border-b border-brand-200 bg-brand-50/70 px-4 py-2 sm:flex-row sm:items-center sm:justify-between">
          <span className="text-[12.5px] font-medium text-brand-900">
            {selectedIds.length.toLocaleString()} selected
          </span>
          <div className="flex flex-wrap items-center gap-1.5">
            {bulkActions}
            <button
              type="button"
              onClick={() => onSelectionChange?.([])}
              className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-2xs font-medium text-slate-600 transition-colors hover:bg-white"
            >
              <X className="h-3 w-3" /> Clear
            </button>
          </div>
        </div>
      )}

      {/* ── Desktop / tablet: real table ── */}
      <div className="hidden overflow-auto rounded-b-xl md:block" style={maxHeight ? { maxHeight } : undefined}>
        <table className="min-w-full border-separate border-spacing-0 text-[13px]">
          <thead>
            <tr>
              {selectable && (
                <th
                  className={classNames(
                    'w-10 border-b border-line bg-slate-50/95 pl-4 pr-2',
                    stickyHeader && 'sticky top-0 z-10 backdrop-blur',
                    headPad
                  )}
                >
                  <Checkbox
                    checked={allSelected}
                    indeterminate={someSelected}
                    onChange={toggleAll}
                    label="Select all rows"
                  />
                </th>
              )}
              {visibleColumns.map((col) => {
                const isSorted = sort.id === col.id;
                const SortIcon = !col.sortable
                  ? null
                  : isSorted
                    ? sort.dir === 'asc'
                      ? ArrowUp
                      : ArrowDown
                    : ChevronsUpDown;
                return (
                  <th
                    key={col.id}
                    scope="col"
                    aria-sort={isSorted ? (sort.dir === 'asc' ? 'ascending' : 'descending') : undefined}
                    className={classNames(
                      'whitespace-nowrap border-b border-line bg-slate-50/95 px-4 text-left text-2xs font-semibold uppercase tracking-[0.07em] text-slate-500',
                      stickyHeader && 'sticky top-0 z-10 backdrop-blur',
                      headPad,
                      col.align === 'right' && 'text-right',
                      col.align === 'center' && 'text-center',
                      col.className
                    )}
                  >
                    {col.sortable ? (
                      <button
                        type="button"
                        onClick={() => toggleSort(col)}
                        className={classNames(
                          'inline-flex items-center gap-1.5 rounded transition-colors hover:text-ink-800',
                          isSorted && 'text-ink-800'
                        )}
                      >
                        {col.header}
                        {SortIcon && (
                          <SortIcon
                            className={classNames('h-3 w-3', isSorted ? 'text-brand-600' : 'text-slate-400')}
                          />
                        )}
                      </button>
                    ) : (
                      col.header
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {sortedData.map((row, i) => {
              const id = rowKey ? rowKey(row, i) : getRowId(row, i);
              const isSelected = selectedSet.has(id);
              return (
                <tr
                  key={id}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={classNames(
                    'group/row transition-colors',
                    onRowClick && 'cursor-pointer',
                    isSelected ? 'bg-brand-50/50' : 'hover:bg-slate-50/80'
                  )}
                >
                  {selectable && (
                    <td
                      className={classNames('border-b border-line-soft pl-4 pr-2 align-middle', cellPad)}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Checkbox checked={isSelected} onChange={() => toggleOne(id)} label="Select row" />
                    </td>
                  )}
                  {visibleColumns.map((col) => (
                    <td
                      key={col.id}
                      className={classNames(
                        cellPad,
                        'border-b border-line-soft align-middle text-ink-800',
                        col.align === 'right' && 'text-right',
                        col.align === 'center' && 'text-center',
                        col.className
                      )}
                    >
                      {col.render ? col.render(row, i) : row[col.id] ?? '—'}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* ── Mobile: stacked record list ── */}
      <ul className="divide-y divide-line-soft overflow-hidden rounded-b-xl md:hidden">
        {sortedData.map((row, i) => {
          const id = rowKey ? rowKey(row, i) : getRowId(row, i);
          const isSelected = selectedSet.has(id);
          return (
            <li key={id} className={classNames('px-4 py-3', isSelected && 'bg-brand-50/50')}>
              <div className="flex items-start gap-3">
                {selectable && (
                  <span className="pt-0.5">
                    <Checkbox checked={isSelected} onChange={() => toggleOne(id)} label="Select row" />
                  </span>
                )}
                <div
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={classNames('min-w-0 flex-1', onRowClick && 'cursor-pointer')}
                >
                  <div className="text-[13px] font-medium text-ink-900">
                    {primaryColumn?.render ? primaryColumn.render(row, i) : row?.[primaryColumn?.id] ?? '—'}
                  </div>
                  <dl className="mt-2.5 grid grid-cols-2 gap-x-4 gap-y-2">
                    {mobileColumns
                      .filter((c) => !c.hideOnMobile)
                      .map((col) => (
                        <div key={col.id} className="min-w-0">
                          <dt className="text-3xs font-medium uppercase tracking-[0.07em] text-slate-400">
                            {typeof col.header === 'string' ? col.header : col.id}
                          </dt>
                          <dd className="mt-0.5 truncate text-xs text-ink-800">
                            {col.render ? col.render(row, i) : row[col.id] ?? '—'}
                          </dd>
                        </div>
                      ))}
                  </dl>
                </div>
              </div>
              {actionColumn && (
                <div className="mt-3 flex justify-end border-t border-line-soft pt-2.5">
                  {actionColumn.render?.(row, i)}
                </div>
              )}
            </li>
          );
        })}
      </ul>

      {footer && <div className="rounded-b-xl border-t border-line-soft px-4 py-2.5">{footer}</div>}
    </div>
  );
}
