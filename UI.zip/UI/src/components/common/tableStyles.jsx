import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Table styling primitives
// ---------------------------------------------------------------------------
// FIXES THE FROZEN-COLUMN BUG. The tables used `bg-inherit` on their sticky
// cells and set the row colour on the `<tr>`. That does not work: a `<tr>`'s
// own background is `transparent` by default, and `hover:` classes on the row
// don't change what a child inherits at rest — so the frozen cells were
// effectively see-through and every column scrolled *underneath* them,
// producing the smeared, overlapping first column.
//
// A frozen cell must paint its own opaque background for every row state it
// can be in. That is what `stickyCell` does, and because the state lives in
// one place, selected/hover/plain can never disagree between the checkbox
// column and the name column next to it.
//
// It also adds the edge treatment every serious data grid has: a hairline
// plus a soft shadow on the right of the last frozen column, so the boundary
// between "frozen" and "scrolling" is visible rather than implied. Without
// it, a user scrolling right cannot tell why some columns stopped moving.

const ROW_BG = {
  // Explicit backgrounds, not bg-inherit. surface-900 is the card plane.
  plain: 'bg-surface-900 group-hover:bg-surface-850',
  selected: 'bg-blue-50 group-hover:bg-blue-100/70 dark:bg-[#16233a] dark:group-hover:bg-[#1a2942]',
}

/**
 * Classes for a frozen (horizontally sticky) body cell.
 * @param {object} o
 * @param {string} o.left       Tailwind left offset class, e.g. 'left-0'
 * @param {boolean} o.selected  Row is selected
 * @param {boolean} o.edge      This is the LAST frozen column (gets the divider)
 */
export function stickyCell({ left = 'left-0', selected = false, edge = false } = {}) {
  return clsx(
    'sticky z-10 border-b border-surface-800 transition-colors',
    left,
    selected ? ROW_BG.selected : ROW_BG.plain,
    edge && 'after:pointer-events-none after:absolute after:inset-y-0 after:right-0 after:w-px after:bg-surface-700 after:content-[""]',
    edge && 'shadow-[6px_0_8px_-6px_rgba(15,23,42,0.16)] dark:shadow-[6px_0_10px_-6px_rgba(0,0,0,0.55)]'
  )
}

/** Matching classes for the frozen cells in the header row. */
export function stickyHeader({ left = 'left-0', edge = false } = {}) {
  return clsx(
    'sticky top-0 z-30 border-b border-surface-800 bg-surface-850',
    left,
    edge && 'after:pointer-events-none after:absolute after:inset-y-0 after:right-0 after:w-px after:bg-surface-700 after:content-[""]',
    edge && 'shadow-[6px_0_8px_-6px_rgba(15,23,42,0.16)] dark:shadow-[6px_0_10px_-6px_rgba(0,0,0,0.55)]'
  )
}

/** Ordinary (non-frozen) body cell. */
export function cell({ selected = false, className } = {}) {
  return clsx('border-b border-surface-800 transition-colors', selected ? ROW_BG.selected : ROW_BG.plain, className)
}

// ---------------------------------------------------------------------------
// Column sizing
// ---------------------------------------------------------------------------
// The other half of the complaint: "columns with big data have the same size
// as everything else". An auto-layout table gives every column a share of the
// width based on its *content*, so a 36-character hostname and a 3-character
// port fight for the same space and both end up wrong.
//
// The fix is the one every enterprise grid uses: declare an intended width
// per column, let the browser lay the table out with `table-fixed`, and
// truncate overflow with the full value on `title`. Data-shaped columns
// (host, port, counts, timestamps) get exactly what they need; the name
// column gets the remainder.
export const COL = {
  select: 'w-12',
  name: 'w-[18rem] min-w-[18rem]',
  wide: 'w-[16rem]',
  medium: 'w-[11rem]',
  short: 'w-[8.5rem]',
  status: 'w-[9rem]',
  count: 'w-[6.5rem]',
  timestamp: 'w-[11.5rem]',
  actions: 'w-[5.5rem]',
}

// Truncating cell content: one class set, so no table forgets the title
// attribute that makes truncation acceptable.
export function TruncCell({ value, className, mono = false, muted = false }) {
  const text = value === null || value === undefined || value === '' ? '—' : String(value)
  return (
    <span
      title={text !== '—' ? text : undefined}
      className={clsx('block truncate', mono && 'font-mono text-xs', muted ? 'text-ink-500' : 'text-ink-200', className)}
    >
      {text}
    </span>
  )
}
