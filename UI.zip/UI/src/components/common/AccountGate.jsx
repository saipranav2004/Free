import { useState } from 'react';
import { Building2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { Button, Input, Card } from '../ui/primitives.jsx';

/**
 * Identity endpoints are tenant-scoped (account_id required). This gate lets an
 * admin set/confirm their active account id (persisted in localStorage) before
 * reaching the identity screens. If an account id is already known it renders
 * children directly.
 */
export function AccountGate({ children, label = 'Select the account to manage' }) {
  const { accountId, setAccountId } = useAuth();
  const [value, setValue] = useState(accountId || '');
  const [error, setError] = useState('');

  if (accountId) return children;

  const submit = (e) => {
    e.preventDefault();
    if (!value.trim()) {
      setError('Account ID is required.');
      return;
    }
    setAccountId(value.trim());
  };

  return (
    <Card className="mx-auto max-w-md p-6">
      <div className="mb-4 flex items-center gap-2">
        <Building2 className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">{label}</h3>
      </div>
      <form onSubmit={submit} className="space-y-3">
        <Input
          label="Account ID"
          placeholder="ACC-XXXXXXXX"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          error={error}
          autoFocus
        />
        <Button type="submit" className="w-full">
          Continue
        </Button>
      </form>
      <p className="mt-3 text-xs text-slate-400">
        Provided at login (the <code>account_id</code> tenant identifier).
      </p>
    </Card>
  );
}
