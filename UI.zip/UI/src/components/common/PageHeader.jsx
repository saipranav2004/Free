import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { classNames } from '../../utils/format.js';

/**
 * PageHeader — the identity band at the top of every page.
 *
 * Enterprise console conventions:
 *  · Breadcrumb eyebrow gives location without stealing hierarchy
 *  · Title is the object, description is the scope/consequence
 *  · Meta strip carries live context (tenant, counts, last refresh)
 *  · A single hairline divider separates identity from working area, so every
 *    page has the same vertical rhythm regardless of what follows
 *
 * API: { title, description, actions, icon } (unchanged)
 * Additions: breadcrumbs [{label, to?}], meta (node), divider, className
 */
export function PageHeader({
  title,
  description,
  actions,
  icon,
  breadcrumbs,
  meta,
  divider = true,
  className,
}) {
  return (
    <header
      className={classNames(
        'mb-5',
        divider && 'border-b border-line pb-4',
        className
      )}
    >
      {breadcrumbs?.length > 0 && (
        <nav aria-label="Breadcrumb" className="mb-2">
          <ol className="flex flex-wrap items-center gap-1 text-2xs font-medium text-slate-400">
            {breadcrumbs.map((crumb, i) => (
              <li key={`${crumb.label}-${i}`} className="flex items-center gap-1">
                {i > 0 && <ChevronRight className="h-3 w-3 text-slate-300" />}
                {crumb.to ? (
                  <Link
                    to={crumb.to}
                    className="rounded text-slate-500 no-underline transition-colors hover:text-brand-700 hover:no-underline"
                  >
                    {crumb.label}
                  </Link>
                ) : (
                  <span className="text-slate-400">{crumb.label}</span>
                )}
              </li>
            ))}
          </ol>
        </nav>
      )}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between sm:gap-6">
        <div className="flex min-w-0 items-start gap-3">
          {icon && (
            <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-line bg-white text-brand-600 shadow-card">
              {icon}
            </span>
          )}
          <div className="min-w-0">
            <h1 className="truncate text-[19px] font-semibold leading-tight text-ink-900 sm:text-xl">
              {title}
            </h1>
            {description && (
              <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-slate-500">
                {description}
              </p>
            )}
            {meta && (
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-2xs text-slate-500">
                {meta}
              </div>
            )}
          </div>
        </div>
        {actions && (
          <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>
        )}
      </div>
    </header>
  );
}
