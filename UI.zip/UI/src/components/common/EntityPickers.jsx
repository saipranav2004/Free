/**
 * EntityPickers — API-backed pickers for the two identifiers admins must never
 * type by hand: a principal (user) and a role.
 *
 * Enterprise people-pickers (Entra ID, Okta, GCP IAM) always resolve a human
 * name against the directory rather than asking for a UUID: typing a GUID is
 * slow, unverifiable and the most common source of failed assignments. These
 * wrap the type-ahead combobox around the existing list endpoints — no new
 * API surface, no backend change.
 */
import { useMemo } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { SearchableCombobox } from '../ui/primitives.jsx';

/** Principal picker. Falls back to a plain hint when the tenant has no users. */
export function UserPicker({
  value,
  onChange,
  label = 'User',
  placeholder = 'Search users by name or email…',
  hint,
  error,
  required,
  multi = false,
  disabled = false,
  className,
}) {
  const { accountId } = useAuth();

  const users = useResource(
    () =>
      accountId
        ? identityApi.listUsers({ account_id: accountId, per_page: 200 })
        : Promise.resolve({ users: [] }),
    [accountId]
  );

  const options = useMemo(() => {
    const list = users.data?.users || users.data || [];
    return (Array.isArray(list) ? list : []).map((u) => ({
      id: u.user_id,
      label: u.username || u.email || u.user_id,
      description: u.email && u.username ? u.email : u.department || undefined,
      badge: u.status && u.status !== 'ACTIVE' ? u.status : undefined,
    }));
  }, [users.data]);

  return (
    <SearchableCombobox
      className={className}
      label={label}
      placeholder={placeholder}
      searchPlaceholder={placeholder}
      options={options}
      value={value}
      onChange={onChange}
      loading={users.loading}
      multi={multi}
      disabled={disabled}
      required={required}
      error={error || (users.error ? 'Could not load the user directory.' : undefined)}
      hint={hint}
      emptyMessage="No users match that name or email."
    />
  );
}

/** Role picker — used for parent-role inheritance and role assignment. */
export function RolePicker({
  value,
  onChange,
  label = 'Role',
  placeholder = 'Search roles…',
  hint,
  error,
  required,
  multi = false,
  disabled = false,
  excludeId,
  className,
}) {
  const roles = useResource(() => rbacApi.listRoles(), []);

  const options = useMemo(() => {
    const list = roles.data?.roles || roles.data || [];
    return (Array.isArray(list) ? list : [])
      .filter((r) => r.role_id !== excludeId)
      .map((r) => ({
        id: r.role_id,
        label: r.role_name,
        description: r.description || undefined,
        badge: r.role_type === 'SYSTEM' ? 'SYSTEM' : undefined,
      }));
  }, [roles.data, excludeId]);

  return (
    <SearchableCombobox
      className={className}
      label={label}
      placeholder={placeholder}
      searchPlaceholder={placeholder}
      options={options}
      value={value}
      onChange={onChange}
      loading={roles.loading}
      multi={multi}
      disabled={disabled}
      required={required}
      error={error || (roles.error ? 'Could not load roles.' : undefined)}
      hint={hint}
      emptyMessage="No roles match that name."
    />
  );
}
