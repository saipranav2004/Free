// Central place for every enum/status the backend uses, kept in sync with
// internal/models/*.go. Importing these instead of hardcoding string
// literals in components is what prevents "PENDING" vs "Pending" vs
// "pending" typo bugs from silently breaking a status filter or badge color.
//
// Every *_BADGE map below carries BOTH a light-mode and a dark-mode class
// fragment (`dark:` variants) — see src/index.css / themeStore.js for how
// the `dark` class gets toggled on <html>. A badge built from only the old
// dark-console shades (e.g. `text-emerald-300` with no light equivalent)
// reads as barely-visible pale text on a white card in light mode, so this
// is deliberate, not decorative.

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://das-iam.bharatgen.dev'

// ---------------------------------------------------------------------------
// Roles (RBAC) — the three system roles that ship with every install
// ---------------------------------------------------------------------------
export const SYSTEM_ROLES = ['root', 'admin', 'user']

export function isAdminRole(roles) {
  return Array.isArray(roles) && (roles.includes('admin') || roles.includes('root'))
}
export function isRootRole(roles) {
  return Array.isArray(roles) && roles.includes('root')
}

export const ROLE_BADGE = {
  root: 'bg-purple-100 text-purple-700 ring-purple-600/20 dark:bg-purple-500/15 dark:text-purple-300 dark:ring-purple-500/30',
  admin: 'bg-blue-100 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30',
  user: 'bg-slate-100 text-slate-700 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
}

// ---------------------------------------------------------------------------
// Identity Management (users)
// ---------------------------------------------------------------------------
export const USER_STATUS_BADGE = {
  ACTIVE: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  DISABLED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  LOCKED: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  DELETED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// PBAC (policies)
// ---------------------------------------------------------------------------
export const POLICY_EFFECTS = [
  { value: 'allow', label: 'Allow' },
  { value: 'deny', label: 'Deny' },
]

export const POLICY_EFFECT_BADGE = {
  allow: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  deny: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// Common action vocabulary (pam:<module>:<Verb>) shown as suggestions when
// building a policy — not exhaustive/enforced client-side, the server is
// the source of truth for what's a valid action string.
export const COMMON_ACTIONS = [
  'pam:resource:List', 'pam:resource:Read', 'pam:resource:Connect',
  'pam:session:Start', 'pam:session:End',
  'pam:vault:List', 'pam:vault:Read', 'pam:vault:Create', 'pam:vault:Store',
  'pam:vault:Reveal', 'pam:vault:Rotate',
  'pam:jit:Request', 'pam:jit:Cancel', 'pam:breakglass:Use',
  'pam:audit:Read', 'pam:report:Generate',
  '*',
]

// ---------------------------------------------------------------------------
// Resources
// ---------------------------------------------------------------------------

export const RESOURCE_TYPES = [
  { value: 'postgresql', label: 'PostgreSQL' },
  { value: 'mongodb', label: 'MongoDB' },
  { value: 'redis', label: 'Redis' },
  { value: 'clickhouse', label: 'ClickHouse' },
  { value: 'minio', label: 'MinIO' },
  { value: 'qdrant', label: 'Qdrant' },
  { value: 'metabase', label: 'Metabase' },
  { value: 'langfuse', label: 'Langfuse' },
  { value: 'web', label: 'Web Application' },
  { value: 'oracle', label: 'Oracle' },
]

export const CONNECT_MODES = [
  { value: 'web_terminal', label: 'Web terminal (host/port shown, connect with your own client)' },
  { value: 'embed_redirect', label: 'Embed / redirect to console URL' },
]

// ---------------------------------------------------------------------------
// Vault
// ---------------------------------------------------------------------------

export const CREDENTIAL_TYPES = [
  { value: 'password', label: 'Password' },
  { value: 'ssh_key', label: 'SSH Private Key' },
  { value: 'x509_cert', label: 'X.509 Certificate' },
  { value: 'api_key', label: 'API Key / Bearer Token' },
  { value: 'token', label: 'OAuth / OIDC Token' },
  { value: 'connection_string', label: 'Connection String' },
  { value: 'kerberos_keytab', label: 'Kerberos Keytab' },
]

// ---------------------------------------------------------------------------
// JIT
// ---------------------------------------------------------------------------

export const JIT_STATUS = {
  PENDING: 'PENDING',
  WAITING: 'WAITING',
  APPROVED: 'APPROVED',
  DENIED: 'DENIED',
  CANCELLED: 'CANCELLED',
  EXPIRED: 'EXPIRED',
}

export const JIT_STATUS_LABELS = {
  PENDING: 'Pending approval',
  WAITING: 'Cooling-off period',
  APPROVED: 'Approved',
  DENIED: 'Denied',
  CANCELLED: 'Cancelled',
  EXPIRED: 'Expired',
}

export const JIT_STATUS_BADGE = {
  PENDING: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  WAITING: 'bg-orange-100 text-orange-700 ring-orange-600/20 dark:bg-orange-500/15 dark:text-orange-300 dark:ring-orange-500/30',
  APPROVED: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  DENIED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  CANCELLED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  EXPIRED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
}

export const JIT_TYPE = {
  STANDARD: 'STANDARD',
  BREAKGLASS: 'BREAKGLASS',
}

export const GRANT_STATUS = {
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
  REVOKED: 'REVOKED',
}

export const GRANT_STATUS_BADGE = {
  ACTIVE: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  EXPIRED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  REVOKED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// Server-configured defaults (internal/config/config.go's viper defaults).
// These are HINTS ONLY for the UI (placeholders, helper text) — the server
// is always the source of truth and its own validation error is what's
// shown when a submission actually violates the real configured policy,
// which may differ per deployment.
export const JIT_DEFAULTS = {
  DEFAULT_DURATION_MIN: 60,
  MAX_DURATION_MIN: 480,
  MIN_REASON_LENGTH: 10,
  BREAKGLASS_WAIT_MIN: 15,
  BREAKGLASS_MAX_DURATION_MIN: 60,
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

export const SESSION_STATUS_BADGE = {
  ACTIVE: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  COMPLETED: 'bg-slate-100 text-slate-600 ring-slate-600/20 dark:bg-ink-500/15 dark:text-ink-400 dark:ring-ink-500/30',
  KILLED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  FAILED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// Audit
// ---------------------------------------------------------------------------

export const AUDIT_CATEGORIES = [
  'AUTH', 'AUTHZ', 'VAULT', 'SESSION', 'RESOURCE',
  'BREAK_GLASS', 'JIT', 'ADMIN', 'REPORT', 'OTHER',
]

export const AUDIT_OUTCOMES = ['SUCCESS', 'DENIED', 'ERROR', 'PENDING', 'FAILURE']

export const AUDIT_OUTCOME_BADGE = {
  SUCCESS: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  DENIED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  ERROR: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
  PENDING: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  FAILURE: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

export const AUDIT_SEVERITY_BADGE = {
  INFO: 'bg-blue-100 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30',
  WARN: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  CRITICAL: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

export const AUDIT_SORT_OPTIONS = [
  { value: 'occurred_at_desc', label: 'Newest first' },
  { value: 'occurred_at_asc', label: 'Oldest first' },
  { value: 'sequence_desc', label: 'Sequence (desc)' },
]

// ---------------------------------------------------------------------------
// Recording
// ---------------------------------------------------------------------------

export const RECORDING_STATUS_BADGE = {
  PENDING: 'bg-amber-100 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30',
  RECORDING: 'bg-blue-100 text-blue-700 ring-blue-600/20 dark:bg-blue-500/15 dark:text-blue-300 dark:ring-blue-500/30',
  COMPLETED: 'bg-emerald-100 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30',
  FAILED: 'bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------

export const DEFAULT_PAGE_SIZE = 20
export const SESSIONS_POLL_MS = 15000 // no push channel on the backend yet
export const SEARCH_DEBOUNCE_MS = 350
