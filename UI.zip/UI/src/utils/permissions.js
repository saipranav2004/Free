// Front-end permission helpers. These ONLY control UI visibility — the
// backend (OPA + @require_permission / @require_admin) is the real authority.

/**
 * Admin detection.
 *
 * Bug fix — the navbar showed "User" for a genuine administrator. The profile
 * payload (`GET /auth/me`) is not consistent about where the role lives: it may
 * arrive as `role: 'admin'`, `account_type: 'admin'`, `roles: ['admin']`,
 * `roles: [{ role_name: 'admin' }]`, or `is_admin: true` — and the registration
 * response uses BOTH `role` and `account_type`. The old check only looked at
 * `roles` (as strings) and `account_type`, so the very common `role: 'admin'`
 * shape fell through to the generic label. Every shape is recognised now.
 */
const ADMIN_WORDS = ['admin', 'administrator', 'root', 'rootadmin', 'root_admin', 'superadmin', 'super_admin', 'owner'];

/** Every role-ish token on a profile, lower-cased, from any payload shape. */
export function roleTokens(user) {
  if (!user) return [];
  const out = [];
  const push = (v) => {
    if (!v) return;
    if (typeof v === 'string') out.push(v.toLowerCase().trim());
    else if (Array.isArray(v)) v.forEach(push);
    else if (typeof v === 'object') push(v.role_name || v.name || v.role || v.slug);
  };
  push(user.role);
  push(user.roles);
  push(user.account_type);
  push(user.account_types);
  push(user.user_type);
  push(user.role_names);
  return out.filter(Boolean);
}

export function isAdmin(user) {
  if (!user) return false;
  if (user.is_admin === true || user.is_root === true || user.is_superuser === true) return true;
  return roleTokens(user).some((token) => ADMIN_WORDS.includes(token));
}

/**
 * The label to render in the navbar and profile panel.
 *
 * Prefers the tenant's own role name (so a custom role such as "Security
 * Analyst" is shown verbatim, title-cased) and only falls back to a generic
 * label when the profile genuinely carries no role at all.
 */
export function roleLabel(user) {
  if (!user) return 'Signed out';
  if (isAdmin(user)) {
    const tokens = roleTokens(user);
    const isRootAdmin = tokens.some((t) => t.includes('root')) || user.is_root === true;
    return isRootAdmin ? 'Root administrator' : 'Administrator';
  }
  const first = roleTokens(user)[0];
  if (!first) return 'User';
  // "security_analyst" / "security-analyst" → "Security analyst"
  const words = first.replace(/[_-]+/g, ' ').trim();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/**
 * The ACCOUNT-TYPE label — exactly two values, by product requirement:
 *
 *   account_type === 'admin'  → "Admin"
 *   anything else             → "User"
 *
 * Bug fix — the top navigation rendered `user?.account_type || 'User'`, so a
 * genuine administrator whose profile spelled the role somewhere other than
 * `account_type` (see `roleTokens`) was labelled "User", and a tenant that did
 * send `account_type` leaked its raw lower-case value ("admin", "service") into
 * the header. Both the navbar chip and the profile menu use this helper now, so
 * there is one answer to "what is this account?" everywhere in the console.
 */
/**
 * DEPRECATED (kept only so nothing that still imports it breaks): the console's
 * "Admin" / "User" indicator no longer infers the answer from the profile
 * payload — it reads `account_type` from the Get-User-Details response. Use
 * `accountTypeDisplayLabel(accountType)` / `isAdminAccountType(accountType)`
 * below instead. No component imports this function any more.
 */
export function accountTypeLabel(user) {
  if (!user) return 'User';
  return isAdmin(user) ? 'Admin' : 'User';
}

/* ═══════════════════════════════════════════════════════════════════════════
   ACCOUNT TYPE — the single source of truth for "Admin" vs "User".
   ═══════════════════════════════════════════════════════════════════════════
   The console reads the logged-in principal from the tenant-scoped user-detail
   endpoint:

     GET /api/v1/identity/accounts/<account_id>/users/<user_id>
     → { data: { account_type: "admin", … }, success: true }

   `data.account_type` is the ONLY input to these helpers — no role tokens, no
   inference, no hardcoded label. AuthContext performs the fetch and exposes the
   raw value as `accountType`; the Topbar profile chip and every admin-only
   surface (IDP routes) derive from it through the two functions below.
   ═══════════════════════════════════════════════════════════════════════════ */

export const ADMIN_ACCOUNT_TYPE = 'admin';

/** True only when the API's `account_type` is exactly the admin account type. */
export function isAdminAccountType(accountType) {
  return String(accountType ?? '').trim().toLowerCase() === ADMIN_ACCOUNT_TYPE;
}

/**
 * The label rendered in the top navigation profile:
 *   account_type === 'admin' → "Admin"
 *   anything else            → "User"
 * Nothing else is ever displayed, so no raw payload value can leak into the UI.
 */
export function accountTypeDisplayLabel(accountType) {
  return isAdminAccountType(accountType) ? 'Admin' : 'User';
}

export function hasRole(user, role) {
  if (!user) return false;
  const roles = user.roles || [];
  return roles.includes(role);
}

// Root / super-admin check. This ONLY controls UI visibility — the backend
// (`is_root_user` in integrations/oracle_db/config.py) is the real authority.
// The root admin is identified by IAM user id; the seeded id is
// b41250cc-84ae-4f19-adcf-c0bc32ebc91b.
export function isRoot(user) {
  if (!user) return false;
  const id = (user.id || user.sub || user.user_id || '').toString().toLowerCase();
  return id === 'b41250cc-84ae-4f19-adcf-c0bc32ebc91b';
}

// Simple capability gate used by RequirePermission route wrapper.
export function can(user, permission) {
  if (!user) return false;
  if (isAdmin(user)) return true;
  // Delegated permissions (populated by identity middleware) take over for
  // non-admin human users.
  const delegations = user.delegations || [];
  return delegations.some((d) =>
    Array.isArray(d.permissions) ? d.permissions.includes(permission) : false
  );
}
