/**
 * profileCache — a display-only fallback for user profile fields.
 *
 * WHY THIS EXISTS
 * The tenant user detail route does not always echo `first_name` /
 * `last_name` back in its GET payload, so a name that saved (or was supplied
 * at creation) correctly could render as an em dash on the next load of
 * UserDetailPage. The page resolves its profile from three sources in priority
 * order — detail route → directory row from the users LIST route → this cache —
 * so these values only ever FILL BLANKS. They never override something the API
 * returned, and they are never sent back to the server.
 *
 * Written by:
 *   · UsersPage      — right after a successful create (the form values)
 *   · UserDetailPage — right after a successful edit (the saved values)
 */
const KEY = 'iam-user-profile-cache';

/** Read the cached profile for one user; always returns an object. */
export function readProfileCache(userId) {
  if (!userId) return {};
  try {
    const all = JSON.parse(window.localStorage.getItem(KEY) || '{}');
    return all[userId] || {};
  } catch {
    return {};
  }
}

/** Merge `profile` into the cached entry for `userId`. */
export function writeProfileCache(userId, profile) {
  if (!userId || !profile) return;
  try {
    const all = JSON.parse(window.localStorage.getItem(KEY) || '{}');
    all[userId] = { ...(all[userId] || {}), ...profile };
    window.localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    /* storage unavailable (private mode / quota) — the API stays the source of truth */
  }
}
