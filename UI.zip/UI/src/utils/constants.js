// Values mirror the backend constants so the UI and API never drift.
// (authentication/constants.py, identity/constants.py, authorization/constants.py)

export const AUTH_USER_STATUS = {
  PENDING_VERIFICATION: 'PENDING_VERIFICATION',
  ACTIVE: 'ACTIVE',
  DISABLED: 'DISABLED',
  LOCKED: 'LOCKED',
  DELETED: 'DELETED',
};

export const IDENTITY_USER_STATUS = {
  ACTIVE: 'ACTIVE',
  DISABLED: 'DISABLED',
  LOCKED: 'LOCKED',
  OFFBOARDED: 'OFFBOARDED',
  DELETED: 'DELETED',
};

export const USER_TYPE = {
  LOCAL: 'LOCAL',
  SSO: 'SSO',
  HYBRID: 'HYBRID',
};

export const ACCOUNT_TYPE = {
  USER: 'user',
  SERVICE: 'service',
  ADMIN: 'admin',
};

export const ROLE_TYPE = {
  SYSTEM: 'SYSTEM',
  CUSTOM: 'CUSTOM',
};

export const ROLE_STATUS = {
  ACTIVE: 'ACTIVE',
  DISABLED: 'DISABLED',
};

export const POLICY_STATUS = {
  ACTIVE: 'ACTIVE',
  DISABLED: 'DISABLED',
};

// Default policy-document schema version used when authoring new PBAC policies.
// (Inferred — adjust to match backend CreatePolicyRequestSchema when confirmed.)
export const POLICY_DOCUMENT_VERSION = '2025-01-01';

// ---------------------------------------------------------------------------
// Microsoft 365 (IAM-protected service catalog)
// ---------------------------------------------------------------------------
// The M365 blueprint DEFAULTS `resource_arn` to
//   m365:<tenant>/default/<service>
// when a request omits it. We mirror that default tenant here so the PDP
// *preview* check in the UI uses the exact same ARN the backend enforces with.
// Keep this in sync with your deployment's M365 tenant id. If your IAM policies
// use a different ARN pattern (e.g. m365:tenant/default/*), change it here.
export const M365_TENANT_ID = 'a2799cfb-23df-44e4-8caa-d81f03a4b3fc';

// Build the canonical M365 resource ARN for a service (mirrors backend default).
export const m365Arn = (service) => `m365:${M365_TENANT_ID}/default/${service}`;

export const POLICY_EFFECT = {
  ALLOW: 'Allow',
  DENY: 'Deny',
};

export const API_KEY_STATUS = {
  ACTIVE: 'active',
  REVOKED: 'revoked',
  EXPIRED: 'expired',
  ROTATED: 'rotated',
};

export const DELEGATION_STATUS = {
  ACTIVE: 'active',
  REVOKED: 'revoked',
  EXPIRED: 'expired',
};

export const DELEGATION_SCOPE = {
  GROUP: 'group',
  DEPARTMENT: 'department',
  RESOURCE_TYPE: 'resource_type',
};

export const TENANT_STATUS = {
  ACTIVE: 'active',
  SUSPENDED: 'suspended',
  DELETED: 'deleted',
};

export const SESSION_LOGIN_METHOD = {
  PASSWORD: 'PASSWORD',
  SSO: 'SSO',
  REFRESH: 'REFRESH',
};

// Status -> tailwind classes for badges. Keep one source of truth.
export const STATUS_STYLES = {
  ACTIVE: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  ENABLED: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  LOCKED: 'bg-amber-50 text-amber-700 ring-amber-600/20',
  PENDING_VERIFICATION: 'bg-sky-50 text-sky-700 ring-sky-600/20',
  DISABLED: 'bg-slate-100 text-slate-600 ring-slate-500/20',
  OFFBOARDED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  DELETED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  SUSPENDED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  EXPIRED: 'bg-amber-50 text-amber-700 ring-amber-600/20',
  REVOKED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
  ROTATED: 'bg-slate-100 text-slate-600 ring-slate-500/20',
};
