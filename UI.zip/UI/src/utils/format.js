// Small, dependency-free formatting helpers.

export function formatDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  });
}

export function formatRelative(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  const diff = (d.getTime() - Date.now()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
  const abs = Math.abs(diff);
  if (abs < 60) return rtf.format(Math.round(diff), 'second');
  if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute');
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), 'hour');
  return rtf.format(Math.round(diff / 86400), 'day');
}

export function initials(name = '') {
  return name
    .split(/[.\s@_-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
}

export function maskToken(token = '') {
  if (!token || token.length < 12) return token;
  return `${token.slice(0, 6)}••••••••${token.slice(-4)}`;
}

export function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

/**
 * Safely pull an array out of a backend list response regardless of how the
 * envelope was (or wasn't) unwrapped:
 *   - a bare array
 *   - { <key>: [...] }
 *   - { data: <bare array> }            (envelope not unwrapped)
 *   - { data: { <key>: [...] } }        (idempotent)
 * Returns [] when nothing usable is found.
 */
export function extractList(payload, key) {
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload[key])) return payload[key];
  if (payload.data) {
    if (Array.isArray(payload.data[key])) return payload.data[key];
    if (Array.isArray(payload.data)) return payload.data;
  }
  return [];
}

/** Truncate a long id/uuid for compact display: `8fe86694…c833`. */
export function shortId(id, head = 8, tail = 4) {
  if (!id) return '—';
  const s = String(id);
  if (s.length <= head + tail + 1) return s;
  return `${s.slice(0, head)}…${s.slice(-tail)}`;
}
