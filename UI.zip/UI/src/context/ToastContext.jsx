import { createContext, useCallback, useContext, useState } from 'react';
import { ToastViewport } from '../components/ui/Toast.jsx';

const ToastContext = createContext(null);

let idSeq = 0;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const dismiss = useCallback((id) => {
    setToasts((list) => list.filter((t) => t.id !== id));
  }, []);

  const push = useCallback(
    (toast) => {
      const id = ++idSeq;
      const entry = {
        id,
        type: 'info',
        duration: 4000,
        ...toast,
      };
      setToasts((list) => [...list, entry]);
      if (entry.duration > 0) {
        setTimeout(() => dismiss(id), entry.duration);
      }
      return id;
    },
    [dismiss]
  );

  const api = {
    toasts,
    dismiss,
    show: push,
    success: (message, opts = {}) => push({ ...opts, type: 'success', message }),
    error: (message, opts = {}) =>
      push({ ...opts, type: 'error', message, duration: opts.duration ?? 6000 }),
    info: (message, opts = {}) => push({ ...opts, type: 'info', message }),
    warning: (message, opts = {}) => push({ ...opts, type: 'warning', message }),
  };

  return (
    <ToastContext.Provider value={api}>
      {children}
      <ToastViewport toasts={toasts} onDismiss={dismiss} />
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
