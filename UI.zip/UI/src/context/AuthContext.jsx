import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../lib/api/auth.js';
import { identityApi } from '../lib/api/identity.js';
import { mfaApi } from '../lib/api/mfa.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { rbacApi } from '../lib/api/rbac.js';
import { tokenStore } from '../lib/tokenStore.js';
import { roleTokens, isAdminAccountType } from '../utils/permissions.js';
import { extractList } from '../utils/format.js';

/**
 * Read `account_type` out of the Get-User-Details response.
 *
 * The contract is exactly:
 *   GET /api/v1/identity/accounts/<account_id>/users/<user_id>
 *   → { "data": { "account_type": "admin", … }, "success": true, "message": … }
 *
 * apiClient already unwraps the `{ success, message, data }` envelope, so the
 * resolved value is the inner `data` object. Both shapes are still handled (an
 * un-unwrapped envelope, and the `{ user: {…} }` variant some routes emit) so
 * the field is read from wherever the deployment puts it — but ONLY ever from
 * `account_type`; no role inference happens here.
 */
function readAccountType(payload) {
  if (!payload || typeof payload !== 'object') return null;
  const body =
    payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data)
      ? { ...payload, ...payload.data }
      : payload;
  const flat =
    body.user && typeof body.user === 'object' && !Array.isArray(body.user)
      ? { ...body, ...body.user }
      : body;
  const value = flat.account_type;
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

/**
 * Merge two profile payloads without losing role information.
 *
 * Bug fix — the navbar showed "User" for an administrator. `/auth/me` and the
 * login response do not carry the same fields: one may send `account_type`, the
 * other `role` or `roles[]`, and either may omit the role entirely. Replacing
 * the stored profile with whichever payload arrived last therefore erased the
 * only role marker the session had. Fields from the fresher payload win, but a
 * key it does not carry is preserved rather than dropped.
 */
function mergeProfiles(base, fresh) {
  if (!fresh || typeof fresh !== 'object') return base || null;
  if (!base || typeof base !== 'object') return fresh;
  const merged = { ...base, ...fresh };
  // Never let an absent/empty role field overwrite one we already resolved.
  ['role', 'roles', 'account_type', 'user_type', 'role_names', 'is_admin'].forEach((key) => {
    const incoming = fresh[key];
    const isEmpty =
      incoming == null ||
      incoming === '' ||
      (Array.isArray(incoming) && incoming.length === 0);
    if (isEmpty && base[key] != null) merged[key] = base[key];
  });
  return merged;
}

/**
 * Last-resort role resolution.
 *
 * If a profile carries no role token at all, the tenant's own assignment graph
 * is the authority: GET /authz/users/<id>/roles (an endpoint the console already
 * uses) returns the roles held by this principal. Storing those names as `roles`
 * lets `isAdmin()` / `accountTypeLabel()` answer correctly for the rest of the
 * session, so the header, the profile menu and every admin-only surface agree.
 * Failure is silent by design — it is an enhancement, never a gate.
 */
async function withResolvedRoles(profile) {
  if (!profile || typeof profile !== 'object') return profile;
  if (roleTokens(profile).length > 0) return profile;
  const userId = profile.user_id || profile.id || profile.sub;
  if (!userId) return profile;
  try {
    const res = await rbacApi.listUserRoles(userId);
    const names = extractList(res, 'roles')
      .map((r) => (typeof r === 'string' ? r : r?.role_name || r?.name || r?.role))
      .filter(Boolean);
    return names.length ? { ...profile, roles: names } : profile;
  } catch {
    return profile;
  }
}

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => tokenStore.getUser());
  const [accessToken, setAccessToken] = useState(() =>
    tokenStore.getAccessToken()
  );
  const [accountId, setAccountId] = useState(() => tokenStore.getAccountId());
  const [bootstrapping, setBootstrapping] = useState(true);
  /* The authoritative account type for the signed-in principal, read from the
     tenant-scoped user-detail endpoint (see readAccountType above). `null` until
     it has been answered — consumers must wait on `accountTypeLoading` rather
     than assuming "not admin". */
  const [accountType, setAccountType] = useState(null);
  const [accountTypeLoading, setAccountTypeLoading] = useState(false);
  const navigate = useNavigate();

  // On first load:
  //  1. If the URL carries SSO tokens (?access_token&refresh_token), consume
  //     them — this runs regardless of which route the IdP/browser lands on —
  //     fetch the profile, strip the tokens from the URL, then go to the
  //     dashboard.
  //  2. Otherwise re-hydrate the profile if we have a token but no user.
  useEffect(() => {
    let cancelled = false;

    const consumeSso = async () => {
      // Tokens may arrive in the query string OR the URL fragment.
      const search = new URLSearchParams(window.location.search);
      const hash = new URLSearchParams(window.location.hash.replace(/^#/, ''));
      const read = (k) => search.get(k) || hash.get(k);

      // ---- SSO step-up MFA (patched backend) ----
      // When the user has MFA enabled, the backend's SSO callback redirects
      // here with `mfa_required` + `mfa_challenge_token` instead of tokens.
      // Route straight to the MFA page so the second factor can be verified
      // before any session is established.
      const mfaRequired = read('mfa_required');
      const mfaChallengeToken = read('mfa_challenge_token');
      if (mfaRequired && mfaChallengeToken) {
        window.history.replaceState(
          {},
          document.title,
          window.location.pathname + (window.location.hash || '')
        );
        if (!cancelled) {
          navigate('/login/mfa', {
            replace: true,
            state: { challengeToken: mfaChallengeToken, ssoMfaPending: true },
          });
          setBootstrapping(false);
        }
        return true;
      }

      const access = read('access_token');
      const refresh = read('refresh_token');
      if (!access || !refresh) return false;
      const acc = read('account_id') || read('tenant_id') || null;
      // Provisionally install the tokens ONLY so we can read the profile
      // (to learn whether MFA is enabled). The session is not committed yet.
      tokenStore.setTokens(access, refresh);
      if (acc) tokenStore.setAccountId(acc);
      // Strip tokens from the URL so they aren't leaked via history/referers.
      window.history.replaceState({}, document.title, window.location.pathname);
      let profile = null;
      try {
        profile = await authApi.me();
      } catch {
        profile = null;
      }

      // ---- MFA gate for SSO users ----
      // If MFA is enabled we must NOT drop the user straight into the app.
      // Send them to the MFA page. With the backend SSO MFA gate applied the
      // page becomes a real verification step; without it the page explains
      // why the sign-in cannot complete (the user is never silently logged in).
      if (profile?.mfa_enabled) {
        tokenStore.clear(); // discard the provisional tokens
        if (!cancelled) {
          navigate('/login/mfa', {
            replace: true,
            state: { ssoMfaPending: true, noChallenge: true },
          });
          setBootstrapping(false);
        }
        return true;
      }

      // No MFA required: persist the profile + tokens and enter the app.
      const resolved = await withResolvedRoles(profile || {});
      tokenStore.setUser(resolved);
      setUser(resolved);
      const aid = resolved?.account_id || resolved?.accountId || acc;
      if (aid) {
        tokenStore.setAccountId(aid);
        setAccountId(aid);
      }
      setAccessToken(access);
      setAccountId(tokenStore.getAccountId());
      if (!cancelled) {
        navigate('/', { replace: true });
        setBootstrapping(false);
      }
      return true;
    };

    const token = tokenStore.getAccessToken();
    const existing = tokenStore.getUser();
    const hasUser = !!existing && Object.keys(existing).length > 0;

    (async () => {
      if (await consumeSso()) return;
      if (!token) {
        setBootstrapping(false);
        return;
      }

      if (hasUser) {
        /* A cached profile paints the shell immediately — no spinner on reload.
           It is then reconciled against /auth/me in the background so a role
           change (or a payload that was missing the role) is picked up without
           blocking the first render. A transient failure here must NOT sign the
           operator out: the token is still valid until the API says otherwise. */
        setBootstrapping(false);
        try {
          const fresh = await authApi.me();
          const merged = await withResolvedRoles(mergeProfiles(existing, fresh));
          if (!cancelled && merged) {
            tokenStore.setUser(merged);
            setUser(merged);
          }
        } catch {
          /* keep the cached profile; the api client handles a real 401 */
        }
        return;
      }

      try {
        const u = await authApi.me();
        const resolved = await withResolvedRoles(u);
        if (!cancelled) {
          tokenStore.setUser(resolved);
          setUser(resolved);
        }
      } catch {
        tokenStore.clear();
        if (!cancelled) {
          setUser(null);
          setAccessToken(null);
        }
      } finally {
        if (!cancelled) setBootstrapping(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const _applySession = useCallback((result, accountIdValue) => {
    const { access_token, refresh_token, user: u } = result;
    tokenStore.setTokens(access_token, refresh_token);
    tokenStore.setUser(u);
    if (accountIdValue) {
      tokenStore.setAccountId(accountIdValue);
      setAccountId(accountIdValue);
    }
    setAccessToken(access_token);
    setUser(u);
    /* The login / MFA response is not guaranteed to carry the role, so the
       profile is completed right after the session is installed (merge + role
       resolution). Fire-and-forget: the caller navigates immediately and the
       header updates as soon as the answer lands. */
    (async () => {
      try {
        const fresh = await authApi.me().catch(() => null);
        const merged = await withResolvedRoles(mergeProfiles(u, fresh));
        if (merged) {
          tokenStore.setUser(merged);
          setUser(merged);
        }
      } catch {
        /* keep the login payload */
      }
    })();
    return u;
  }, []);

  // Step 1 of login. Returns { mfaRequired, challengeToken?, user? }.
  const login = useCallback(
    async ({ identifier, password, accountId }) => {
      const result = await authApi.login({ identifier, password, account_id: accountId });
      if (result?.mfa_required) {
        // Persist account id even for the MFA step so it's available after.
        if (accountId) {
          tokenStore.setAccountId(accountId);
          setAccountId(accountId);
        }
        return { mfaRequired: true, challengeToken: result.mfa_challenge_token };
      }
      _applySession(result, accountId);
      return { mfaRequired: false, user: result.user };
    },
    [_applySession]
  );

  const completeMfa = useCallback(
    async ({ code, challengeToken }) => {
      const result = await mfaApi.verifyMfa({
        mfa_challenge_token: challengeToken,
        code,
      });
      _applySession(result, tokenStore.getAccountId());
      return result.user;
    },
    [_applySession]
  );

  const logout = useCallback(
    async (allSessions = false) => {
      try {
        await sessionsApi.logout(allSessions, tokenStore.getRefreshToken());
      } catch {
        /* best effort */
      }
      tokenStore.clear();
      setUser(null);
      setAccessToken(null);
      // The account type belongs to the session that just ended.
      setAccountType(null);
    },
    []
  );

  // SSO tokens are now consumed centrally on mount (see the bootstrap effect
  // above) so the callback works on any route. This helper is kept for
  // explicit use and also fetches the profile so the user is fully populated.
  const applyTokensFromUrl = useCallback(
    async (result, accountIdValue) => {
      _applySession(result, accountIdValue || tokenStore.getAccountId());
      try {
        const fresh = await authApi.me();
        const merged = await withResolvedRoles(mergeProfiles(tokenStore.getUser(), fresh));
        tokenStore.setUser(merged);
        setUser(merged);
      } catch {
        /* keep the token; profile re-hydrates on next load */
      }
    },
    [_applySession]
  );

  /* ── Account type (Get User Details) ─────────────────────────────────────
     Fetched as soon as both the user id and the tenant are known, and re-fetched
     whenever either changes (login, tenant switch, sign-out). This is the only
     place the console asks "what kind of account is this?". */
  const profileUserId = user?.user_id || user?.id || user?.sub || null;
  const profileAccountId = accountId || user?.account_id || user?.accountId || null;

  const refreshAccountType = useCallback(async () => {
    if (!profileUserId || !profileAccountId) {
      setAccountType(null);
      return null;
    }
    setAccountTypeLoading(true);
    try {
      // GET /api/v1/identity/accounts/<account_id>/users/<user_id>
      const res = await identityApi.getUser(profileUserId, profileAccountId);
      const next = readAccountType(res);
      setAccountType(next);
      return next;
    } catch {
      /* A failed read must not silently promote or demote anyone: the value stays
         unknown and admin-only surfaces stay closed. */
      setAccountType(null);
      return null;
    } finally {
      setAccountTypeLoading(false);
    }
  }, [profileUserId, profileAccountId]);

  useEffect(() => {
    let cancelled = false;
    if (!profileUserId || !profileAccountId) {
      setAccountType(null);
      setAccountTypeLoading(false);
      return undefined;
    }
    setAccountTypeLoading(true);
    identityApi
      .getUser(profileUserId, profileAccountId)
      .then((res) => {
        if (!cancelled) setAccountType(readAccountType(res));
      })
      .catch(() => {
        if (!cancelled) setAccountType(null);
      })
      .finally(() => {
        if (!cancelled) setAccountTypeLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [profileUserId, profileAccountId]);

  const refreshProfile = useCallback(async () => {
    const fresh = await authApi.me();
    const merged = await withResolvedRoles(mergeProfiles(tokenStore.getUser(), fresh));
    tokenStore.setUser(merged);
    setUser(merged);
    return merged;
  }, []);

  const value = useMemo(
    () => ({
      user,
      accessToken,
      accountId,
      /* Raw API value + the two derived answers every surface needs. */
      accountType,
      accountTypeLoading,
      isAdminAccount: isAdminAccountType(accountType),
      refreshAccountType,
      isAuthenticated: !!accessToken && !!user,
      bootstrapping,
      login,
      completeMfa,
      logout,
      refreshProfile,
      applyTokensFromUrl,
      setAccountId: (id) => {
        tokenStore.setAccountId(id);
        setAccountId(id);
      },
      setUser: (u) => {
        tokenStore.setUser(u);
        setUser(u);
      },
    }),
    [
      user,
      accessToken,
      accountId,
      accountType,
      accountTypeLoading,
      refreshAccountType,
      bootstrapping,
      login,
      completeMfa,
      logout,
      refreshProfile,
      applyTokensFromUrl,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
