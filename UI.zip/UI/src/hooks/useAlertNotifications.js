import { useCallback, useEffect, useRef, useState } from 'react';
import { alertsApi } from '../lib/api/alerts.js';

/**
 * useAlertNotifications — unread-denial counter for the Topbar bell.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * HOW "UNREAD" IS DEFINED
 * ═══════════════════════════════════════════════════════════════════════════
 * The alerts API is a read-only analytical feed (GET /identities/alerts) with
 * no per-user read state, so unread has to be derived on the client. The only
 * monotonic signal it exposes is the total number of DENY events, so this hook
 * keeps a *baseline* — the total that was on the server the last time the admin
 * looked — and treats the difference as unread:
 *
 *     unread = max(0, currentTotal - seenTotal)
 *
 * · First ever load seeds the baseline to whatever is already there, so a new
 *   admin is not greeted by a badge counting historical denials.
 * · `markRead()` moves the baseline to the current total → badge returns to 0.
 * · The next denial makes the difference 1, so counting restarts at 1 exactly
 *   as an enterprise inbox behaves.
 * · The baseline lives in localStorage per account, so it survives reloads and
 *   does not leak between tenants.
 *
 * The poll is deliberately quiet: one request per interval asking for a single
 * row (`page_size: 1`) — the totals live in `stats` / `pagination`, so no event
 * payload is transferred. Polling pauses while the tab is hidden.
 */

const STORAGE_KEY = 'iam-alerts-seen';
const POLL_MS = 60_000;

function readBaseline(accountId) {
  try {
    const all = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '{}');
    const entry = all[accountId || '_'];
    return typeof entry?.total === 'number' ? entry : null;
  } catch {
    return null;
  }
}

function writeBaseline(accountId, total) {
  try {
    const all = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '{}');
    all[accountId || '_'] = { total, at: new Date().toISOString() };
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
  } catch {
    /* storage unavailable — the counter degrades to session-only */
  }
}

/** Pull the denial total out of whichever envelope the alerts API returns. */
function resolveTotal(payload) {
  if (!payload) return null;
  const body = payload.data && !Array.isArray(payload.data) ? { ...payload, ...payload.data } : payload;
  const candidates = [
    body?.stats?.total_deny,
    body?.pagination?.total,
    body?.total,
    Array.isArray(body?.items) ? body.items.length : undefined,
    Array.isArray(body?.alerts) ? body.alerts.length : undefined,
    Array.isArray(body) ? body.length : undefined,
  ];
  const found = candidates.find((v) => typeof v === 'number' && Number.isFinite(v));
  return found ?? null;
}

export function useAlertNotifications(accountId, { enabled = true } = {}) {
  const [total, setTotal] = useState(null);
  const [seen, setSeen] = useState(() => readBaseline(accountId)?.total ?? null);
  const [lastCheckedAt, setLastCheckedAt] = useState(null);
  const totalRef = useRef(null);

  // A tenant switch means a different baseline.
  useEffect(() => {
    setSeen(readBaseline(accountId)?.total ?? null);
    setTotal(null);
    totalRef.current = null;
  }, [accountId]);

  const check = useCallback(async () => {
    if (!enabled) return;
    try {
      const res = await alertsApi.list({ page: 1, page_size: 1 });
      const next = resolveTotal(res);
      if (next == null) return;
      totalRef.current = next;
      setTotal(next);
      setLastCheckedAt(new Date());
      // Seed the baseline on the very first successful read so pre-existing
      // denials never appear as unread.
      setSeen((prev) => {
        if (prev != null) return prev;
        writeBaseline(accountId, next);
        return next;
      });
    } catch {
      /* Alerts are admin-only and may 403 for non-root operators — stay silent
         rather than surfacing a failed background poll in the header. */
    }
  }, [accountId, enabled]);

  useEffect(() => {
    if (!enabled) return undefined;
    check();
    let timer = window.setInterval(() => {
      if (document.visibilityState === 'visible') check();
    }, POLL_MS);
    // Catch up immediately when the operator returns to the tab.
    const onVisible = () => {
      if (document.visibilityState === 'visible') check();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.clearInterval(timer);
      timer = null;
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [check, enabled]);

  const markRead = useCallback(() => {
    const current = totalRef.current;
    if (current == null) return;
    writeBaseline(accountId, current);
    setSeen(current);
  }, [accountId]);

  // Reviewing the Alerts tab counts as reading them, wherever the operator
  // arrived from (bell, sidebar, deep link). PamPage dispatches this event.
  useEffect(() => {
    const onRead = () => markRead();
    window.addEventListener('iam:alerts-read', onRead);
    return () => window.removeEventListener('iam:alerts-read', onRead);
  }, [markRead]);

  const unread = total != null && seen != null ? Math.max(0, total - seen) : 0;

  return { unread, total, lastCheckedAt, markRead, refresh: check };
}
