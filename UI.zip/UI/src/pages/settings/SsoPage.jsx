import { useNavigate } from 'react-router-dom';
import { Plug, Monitor, ShieldCheck } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Badge } from '../../components/ui/primitives.jsx';

const PROVIDERS = (import.meta.env.VITE_SSO_PROVIDERS || 'entra_id')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

export default function SsoPage() {
  const navigate = useNavigate();

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="SSO Providers"
        description="Single Sign-On via standards-compliant OIDC (entra_id, etc.)."
        actions={
          <Button variant="secondary" onClick={() => navigate('/login')}>
            Try login
          </Button>
        }
      />

      <Card className="p-6">
        <div className="flex items-center gap-2">
          <Plug className="h-5 w-5 text-brand-600" />
          <h3 className="text-sm font-semibold text-ink-900">Configured providers</h3>
        </div>
        <p className="mt-1 text-xs text-slate-500">
          Providers are registered in <code>IAM_SSO_PROVIDERS</code> (DB) and driven entirely by
          their configuration — no provider-specific code branching. Domain restriction and
          auto-provisioning are enforced server-side.
        </p>

        <div className="mt-4 space-y-3">
          {PROVIDERS.map((p) => (
            <div key={p} className="flex items-center justify-between rounded-lg border border-line px-4 py-3">
              <div className="flex items-center gap-3">
                <Monitor className="h-5 w-5 text-brand-600" />
                <div>
                  <p className="text-sm font-medium text-ink-900">{p}</p>
                  <p className="text-xs text-slate-400">OIDC · PKCE · nonce-replay protection</p>
                </div>
              </div>
              <Badge tone="green">Enabled</Badge>
            </div>
          ))}
        </div>

        <div className="mt-5 rounded-lg bg-slate-50 p-4 text-sm text-slate-600">
          <div className="flex items-center gap-2 font-medium text-ink-800">
            <ShieldCheck className="h-4 w-4 text-brand-600" /> How it works
          </div>
          <ol className="mt-2 list-decimal space-y-1 pl-5">
            <li>User clicks the provider → backend builds an OIDC authorize URL (PKCE + state + nonce).</li>
            <li>IdP redirects back to <code>/api/v1/auth/sso/callback</code> → tokens exchanged, ID token verified.</li>
            <li>Account matched by subject, linked by email, or JIT-provisioned per domain rules.</li>
            <li>Our own JWT session is issued and returned to the dashboard.</li>
          </ol>
        </div>
      </Card>
    </div>
  );
}
