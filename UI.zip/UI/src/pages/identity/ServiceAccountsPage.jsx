import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { KeySquare, Plus, Trash2, KeyRound } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { AccountGate } from '../../components/common/AccountGate.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, StatusBadge, EmptyState, Badge } from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

function ServiceAccountsInner() {
  const { accountId } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ name: '', description: '' });
  const [saving, setSaving] = useState(false);
  const [delId, setDelId] = useState(null);

  const fetcher = () => identityApi.listServiceAccounts();
  const list = useResource(fetcher, [accountId]);
  const data = list.data?.service_accounts || [];

  const create = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await identityApi.createServiceAccount({ name: form.name, description: form.description });
      toast.success('Service account created.');
      setCreateOpen(false);
      setForm({ name: '', description: '' });
      list.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create service account.');
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    try {
      await identityApi.deleteServiceAccount(delId);
      toast.success('Service account deleted — its keys were revoked.');
      setDelId(null);
      list.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Deletion failed.');
    }
  };

  const columns = [
    { id: 'name', header: 'Name', render: (r) => <span className="font-medium text-ink-900">{r.NAME}</span> },
    { id: 'description', header: 'Description', render: (r) => r.DESCRIPTION || '—' },
    { id: 'active_keys', header: 'Active keys', render: (r) => r.ACTIVE_KEYS ?? '—' },
    { id: 'status', header: 'Status', render: (r) => <StatusBadge status={(r.STATUS || 'ACTIVE').toUpperCase()} /> },
    {
      id: 'actions',
      header: '',
      render: (r) => (
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="sm" onClick={() => navigate(`/identity/api-keys?sa=${r.ACCOUNT_ID}`)}>
            <KeyRound className="h-4 w-4" /> Keys
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setDelId(r.ACCOUNT_ID)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Service Accounts"
        description="Non-human identities for machine-to-machine access."
        actions={<Button onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4" /> New service account</Button>}
      />
      <DataTable
        columns={columns}
        data={data}
        loading={list.loading}
        empty={{ title: 'No service accounts', description: 'Create one to issue API keys for automation.' }}
      />

      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="New service account"
        footer={<><Button variant="secondary" onClick={() => setCreateOpen(false)}>Cancel</Button><Button onClick={create} loading={saving}>Create</Button></>}
      >
        <form onSubmit={create} className="space-y-4">
          <Input label="Name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
        </form>
      </Modal>

      <ConfirmDialog open={!!delId} onClose={() => setDelId(null)} onConfirm={remove} danger title="Delete service account" message="All API keys owned by this account will be revoked." />
    </div>
  );
}

export default function ServiceAccountsPage() {
  return <AccountGate><ServiceAccountsInner /></AccountGate>;
}
