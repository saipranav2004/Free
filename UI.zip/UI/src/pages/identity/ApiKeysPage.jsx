import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { KeyRound, Plus, Trash2, Copy, Check, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { AccountGate } from '../../components/common/AccountGate.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, StatusBadge, EmptyState, Badge } from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { formatDateTime, maskToken } from '../../utils/format.js';
import { API_KEY_STATUS } from '../../utils/constants.js';

function ApiKeysInner() {
  const { accountId } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const saId = params.get('sa');

  const [genOpen, setGenOpen] = useState(false);
  const [form, setForm] = useState({ key_name: 'default', expires_in_days: 365 });
  const [saving, setSaving] = useState(false);
  const [generated, setGenerated] = useState(null);

  const fetcher = () => identityApi.listApiKeys(saId ? { service_account_id: saId } : {});
  const list = useResource(fetcher, [saId]);
  const data = list.data?.api_keys || [];

  const generate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await identityApi.generateApiKey({
        service_account_id: saId,
        key_name: form.key_name,
        expires_in_days: Number(form.expires_in_days),
      });
      setGenerated(res);
      setGenOpen(false);
      list.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not generate key.');
    } finally {
      setSaving(false);
    }
  };

  const revoke = async (keyId) => {
    try {
      await identityApi.revokeApiKey(keyId);
      toast.success('API key revoked.');
      list.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Revoke failed.');
    }
  };

  // NOTE: list rows come from Oracle as UPPERCASE keys (KEY_ID, KEY_NAME,
  // KEY_PREFIX, STATUS, EXPIRES_AT, LAST_USED_AT); the generate response uses
  // lowercase (api_key, key_id, ...) which the success Modal reads correctly.
  const columns = [
    { id: 'key_name', header: 'Name', render: (r) => <span className="font-medium text-ink-900">{r.KEY_NAME || r.key_name}</span> },
    { id: 'key_prefix', header: 'Prefix', render: (r) => <code className="text-xs">{r.KEY_PREFIX || r.key_prefix}</code> },
    { id: 'status', header: 'Status', render: (r) => <StatusBadge status={(r.STATUS || r.status || 'active').toUpperCase()} /> },
    { id: 'expires_at', header: 'Expires', render: (r) => formatDateTime(r.EXPIRES_AT || r.expires_at) },
    { id: 'last_used_at', header: 'Last used', render: (r) => formatDateTime(r.LAST_USED_AT || r.last_used_at) },
    {
      id: 'actions',
      header: '',
      render: (r) => (
        <div className="flex justify-end">
          <Button variant="ghost" size="sm" onClick={() => revoke(r.KEY_ID || r.key_id)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      {saId && (
        <button onClick={() => navigate('/identity/service-accounts')} className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700">
          <ArrowLeft className="h-4 w-4" /> Service accounts
        </button>
      )}
      <PageHeader
        title="API Keys"
        description={saId ? `Keys for service account ${saId}` : 'All API keys in this account.'}
        actions={<Button onClick={() => setGenOpen(true)} disabled={!saId}><Plus className="h-4 w-4" /> Generate key</Button>}
      />

      {!saId && (
        <p className="mb-4 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700">
          Open API keys from a specific service account to generate new ones.
        </p>
      )}

      <DataTable
        columns={columns}
        data={data}
        loading={list.loading}
        empty={{ title: 'No API keys', description: 'Generate a key to enable programmatic access.' }}
      />

      <Modal open={genOpen} onClose={() => setGenOpen(false)} title="Generate API key"
        footer={<><Button variant="secondary" onClick={() => setGenOpen(false)}>Cancel</Button><Button onClick={generate} loading={saving}>Generate</Button></>}>
        <form onSubmit={generate} className="space-y-4">
          <Input label="Key name" value={form.key_name} onChange={(e) => setForm((f) => ({ ...f, key_name: e.target.value }))} required />
          <Input label="Expires in (days)" type="number" value={form.expires_in_days} onChange={(e) => setForm((f) => ({ ...f, expires_in_days: e.target.value }))} min={1} max={3650} />
        </form>
      </Modal>

      <Modal open={!!generated} onClose={() => setGenerated(null)} title="API key generated"
        footer={<Button onClick={() => setGenerated(null)}>Done</Button>}>
        <p className="text-sm text-slate-500">{generated?.message}</p>
        <div className="mt-3 flex items-center justify-between rounded-lg bg-slate-50 p-3">
          <code className="text-sm text-ink-900">{maskToken(generated?.api_key || '')}</code>
          <Button variant="ghost" size="sm" onClick={() => navigator.clipboard?.writeText(generated?.api_key || '')}>
            <Copy className="h-4 w-4" />
          </Button>
        </div>
        <p className="mt-2 text-xs text-amber-600">Store this secret now — it won't be shown again.</p>
      </Modal>
    </div>
  );
}

export default function ApiKeysPage() {
  return <AccountGate><ApiKeysInner /></AccountGate>;
}
