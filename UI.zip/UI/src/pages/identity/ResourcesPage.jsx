/**
 * ResourcesPage — Enterprise resource management for IAM/PAM.
 *
 * Enterprise research findings (AWS IAM, Azure AD, CyberArk, BeyondTrust):
 *  - Resources are the core entities protected by policies
 *  - "Search-first, Action-second" design for thousands of entries
 *  - Data-dense tables optimized for filtering and quick scanning
 *  - Deactivation workflow: Soft-disable with audit trail (not delete)
 *  - Status indicators: Active, Inactive, Disabled
 *
 * Layout:
 *  ┌─────────────────────────────────────────────────────┐
 *  │ Resources                                  [+ New] │
 *  ├─────────────────────────────────────────────────────┤
 *  │ [Total] [Active] [Inactive]  │  [Search] [Filter] │
 *  ├─────────────────────────────────────────────────────┤
 *  │ Name        │ Type    │ ARN         │ Status │ ... │
 *  │ api-1       │ api     │ iam:api/... │ Active │ ... │
 *  │ app-2       │ app     │ iam:app/... │ Inactive│ ...│
 *  └─────────────────────────────────────────────────────┘
 */
import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Boxes, Plus, Trash2, Search, Filter, Eye, Edit2 } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { resourcesApi } from '../../lib/api/resources.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Card, Button, Input, Select, Spinner, StatusBadge,
  EmptyState, Badge, StatCard
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { classNames } from '../../utils/format.js';

// Enterprise: Resource types commonly found in IAM platforms
const RESOURCE_TYPES = [
  { value: 'api', label: 'API' },
  { value: 'application', label: 'Application' },
  { value: 'dataset', label: 'Dataset' },
  { value: 'service', label: 'Service' },
  { value: 'database', label: 'Database' },
  { value: 'storage', label: 'Storage' },
];

// ──────────────────────────────────────────────────────────────────────────────
// ResourcesInner — the actual resources page content
// ──────────────────────────────────────────────────────────────────────────────
function ResourcesInner() {
  const toast = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const [open, setOpen] = useState(false);
  const [viewResource, setViewResource] = useState(null);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [filterType, setFilterType] = useState('all');
  const [form, setForm] = useState({
    resource_name: '',
    resource_type: 'api',
    resource_arn: '',
    target_url: '',
    is_active: true,
    metadata: '{}',
  });
  const [saving, setSaving] = useState(false);
  const [deactivating, setDeactivating] = useState(null);

  // Fetch resources list (placeholder — actual list endpoint not provided)
  // TODO: Add GET /api/v1/resources endpoint when backend provides it
  const resources = useResource(() => Promise.resolve([]), []);
  const data = Array.isArray(resources.data)
    ? resources.data
    : (resources.data?.resources || []);

  // Filter and search resources
  const filteredData = data.filter((r) => {
    const matchesSearch =
      !searchQuery ||
      r.resource_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.resource_arn?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.target_url?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || r.resource_type === filterType;
    return matchesSearch && matchesType;
  });

  // Calculate stats
  const stats = {
    total: data.length,
    active: data.filter((r) => r.is_active).length,
    inactive: data.filter((r) => !r.is_active).length,
  };

  // Handle resource creation
  const createResource = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      // Parse metadata JSON
      let metadata = {};
      try {
        metadata = JSON.parse(form.metadata || '{}');
      } catch {
        throw new Error('Invalid JSON in metadata field');
      }

      await resourcesApi.create({
        resource_name: form.resource_name,
        resource_type: form.resource_type,
        resource_arn: form.resource_arn,
        target_url: form.target_url,
        is_active: form.is_active,
        metadata,
      });
      toast.success('Resource created successfully.');
      setOpen(false);
      resetForm();
      resources.reload();
    } catch (err) {
      toast.error(err.message || err.userMessage || 'Could not create resource.');
    } finally {
      setSaving(false);
    }
  };

  // Handle resource deactivation
  const deactivate = async (id) => {
    setDeactivating(id);
    try {
      await resourcesApi.deactivate(id);
      toast.success('Resource deactivated successfully.');
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not deactivate resource.');
    } finally {
      setDeactivating(null);
    }
  };

  // Reset form to initial state
  const resetForm = () => {
    setForm({
      resource_name: '',
      resource_type: 'api',
      resource_arn: '',
      target_url: '',
      is_active: true,
      metadata: '{}',
    });
  };

  // Table columns for resource list
  const columns = [
    {
      id: 'name',
      header: 'Resource Name',
      render: (r) => (
        <div className="flex items-center gap-2">
          <span className="font-medium text-ink-900">{r.resource_name}</span>
          <Badge tone="slate">{r.resource_type}</Badge>
        </div>
      ),
    },
    {
      id: 'arn',
      header: 'ARN',
      render: (r) => (
        <code className="font-mono text-xs text-slate-600">{r.resource_arn}</code>
      ),
    },
    {
      id: 'url',
      header: 'Target URL',
      render: (r) => (
        <span className="max-w-[200px] truncate text-sm text-slate-600" title={r.target_url}>
          {r.target_url || '—'}
        </span>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.is_active ? 'ACTIVE' : 'DISABLED'} />,
    },
    {
      id: 'actions',
      header: '',
      render: (r) => (
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setViewResource(r)}
            title="View details"
          >
            <Eye className="h-4 w-4" />
          </Button>
          {r.is_active && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => deactivate(r.resource_id)}
              loading={deactivating === r.resource_id}
              title="Deactivate resource"
              className="text-rose-600 hover:bg-rose-50 hover:text-rose-700"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page header with create button */}
      <PageHeader
        title="Resources"
        description="Manage protected resources for attribute-based access control."
        icon={<Boxes className="h-5 w-5" />}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Create resource
          </Button>
        }
      />

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Total Resources" value={stats.total} icon={Boxes} tone="brand" />
        <StatCard label="Active" value={stats.active} icon={Boxes} tone="green" />
        <StatCard label="Inactive" value={stats.inactive} icon={Boxes} tone="slate" />
      </div>

      {/* Search and filter bar */}
      <Card className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-base pl-9 w-64"
              />
            </div>
            <Select value={filterType} onChange={(e) => setFilterType(e.target.value)}>
              <option value="all">All Types</option>
              {RESOURCE_TYPES.map((t) => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </Select>
          </div>
          <div className="text-sm text-slate-500">
            {filteredData.length} resource{filteredData.length !== 1 ? 's' : ''}
          </div>
        </div>
      </Card>

      {/* Resource list */}
      {resources.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : filteredData.length === 0 ? (
        <EmptyState
          icon={Boxes}
          title={searchQuery || filterType !== 'all' ? 'No resources match your filters' : 'No resources'}
          description={
            searchQuery || filterType !== 'all'
              ? 'Try adjusting your search or filter criteria.'
              : 'Create a resource to protect with attribute-based policies.'
          }
          action={
            !searchQuery && filterType === 'all' && (
              <Button onClick={() => setOpen(true)}>Create resource</Button>
            )
          }
        />
      ) : (
        <DataTable columns={columns} data={filteredData} loading={false} />
      )}

      {/* Create Resource Modal */}
      <Modal
        open={open}
        onClose={() => { setOpen(false); resetForm(); }}
        title="Create Resource"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setOpen(false); resetForm(); }}>
              Cancel
            </Button>
            <Button onClick={createResource} loading={saving}>
              Create Resource
            </Button>
          </>
        }
      >
        <form onSubmit={createResource} className="space-y-4">
          <Input
            label="Resource Name"
            value={form.resource_name}
            onChange={(e) => setForm((f) => ({ ...f, resource_name: e.target.value }))}
            required
            placeholder="user-management-api"
          />
          <Select
            label="Resource Type"
            value={form.resource_type}
            onChange={(e) => setForm((f) => ({ ...f, resource_type: e.target.value }))}
          >
            {RESOURCE_TYPES.map((t) => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </Select>
          <Input
            label="ARN"
            value={form.resource_arn}
            onChange={(e) => setForm((f) => ({ ...f, resource_arn: e.target.value }))}
            required
            placeholder="iam:api:user-management"
            hint="Amazon Resource Name for this resource"
          />
          <Input
            label="Target URL"
            value={form.target_url}
            onChange={(e) => setForm((f) => ({ ...f, target_url: e.target.value }))}
            placeholder="https://api.example.com"
          />
          <div>
            <label className="label-base">Metadata (JSON)</label>
            <textarea
              value={form.metadata}
              onChange={(e) => setForm((f) => ({ ...f, metadata: e.target.value }))}
              rows={3}
              className="input-base font-mono text-xs"
              placeholder='{"env": "prod", "team": "backend"}'
            />
            <p className="mt-1 text-xs text-slate-400">Optional metadata for this resource</p>
          </div>
        </form>
      </Modal>

      {/* View Resource Modal */}
      <Modal
        open={!!viewResource}
        onClose={() => setViewResource(null)}
        title="Resource Details"
        footer={
          <Button variant="secondary" onClick={() => setViewResource(null)}>
            Close
          </Button>
        }
      >
        {viewResource && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-medium text-slate-500">Name</p>
                <p className="text-sm font-medium text-ink-900">{viewResource.resource_name}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-500">Type</p>
                <Badge tone="slate">{viewResource.resource_type}</Badge>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-500">ARN</p>
                <code className="font-mono text-xs text-slate-600">{viewResource.resource_arn}</code>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-500">Status</p>
                <StatusBadge status={viewResource.is_active ? 'ACTIVE' : 'DISABLED'} />
              </div>
              <div className="col-span-2">
                <p className="text-xs font-medium text-slate-500">Target URL</p>
                <p className="text-sm text-slate-600">{viewResource.target_url || '—'}</p>
              </div>
              {viewResource.metadata && Object.keys(viewResource.metadata).length > 0 && (
                <div className="col-span-2">
                  <p className="text-xs font-medium text-slate-500">Metadata</p>
                  <pre className="mt-1 rounded-lg bg-slate-50 p-3 text-xs text-slate-600">
                    {JSON.stringify(viewResource.metadata, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Default export
// ──────────────────────────────────────────────────────────────────────────────
export default function ResourcesPage() {
  return <ResourcesInner />;
}
