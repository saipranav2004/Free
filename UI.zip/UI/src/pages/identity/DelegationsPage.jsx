/**
 * DelegationsPage — Enterprise temporary access / break-glass delegation management.
 *
 * Enterprise research findings (CyberArk, BeyondTrust, SailPoint):
 *  - Delegations allow temporary granting of specific permissions
 *  - Break-glass workflows with mandatory audit trail
 *  - Status indicators: Active, Revoked, Expired
 *  - Confirmation required for revoke action (compliance)
 *
 * APIs:
 *  - GET  /api/v1/identity/delegations        → list all delegations
 *  - POST /api/v1/identity/delegations        → create delegation
 *  - DELETE /api/v1/identity/delegations/:id  → revoke delegation
 *
 * Layout:
 *  ┌─────────────────────────────────────────────────────┐
 *  │ Delegations                                [+ New] │
 *  ├─────────────────────────────────────────────────────┤
 *  │ [Total] [Active] [Revoked]  │  [Search]            │
 *  ├─────────────────────────────────────────────────────┤
 *  │ Delegate    │ Scope      │ Permissions │ Status│... │
 *  │ john.doe    │ group:eng  │ user:read   │Active │ ...│
 *  │ jane.smith  │ dept:sales │ group:...   │Revoked│ ...│
 *  └─────────────────────────────────────────────────────┘
 */
import { useState } from 'react';
import { UserCog, Plus, Trash2, Shield, ShieldOff, Clock, AlertTriangle } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { AccountGate } from '../../components/common/AccountGate.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, Select, Spinner, StatusBadge, Badge, EmptyState, SummaryBar,
  SearchableCombobox, Toolbar, SearchInput, IconButton, InlineAlert, DescriptionList,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ExpiryInput, toIsoExpiry, isPastExpiry } from '../../components/ui/ExpiryInput.jsx';
import { formatDateTime } from '../../utils/format.js';
import { DELEGATION_SCOPE } from '../../utils/constants.js';

// All available permissions for delegation
const ALL_PERMISSIONS = [
  'user:create', 'user:read', 'user:update', 'user:disable',
  'group:manage', 'group:add_member', 'group:remove_member',
  'role:assign', 'role:remove', 'policy:read', 'audit:read',
];

// ──────────────────────────────────────────────────────────────────────────────
// DelegationsInner — the actual delegations page content
// ──────────────────────────────────────────────────────────────────────────────
function DelegationsInner() {
  const toast = useToast();
  const { accountId } = useAuth();
  const [open, setOpen] = useState(false);
  const [revokeConfirm, setRevokeConfirm] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [form, setForm] = useState({
    delegate_user_id: '',
    scope_type: 'group',
    scope_id: '',
    permissions: ['user:read'],
    expires_at: '',
  });
  const [saving, setSaving] = useState(false);

  // Fetch delegations list
  const list = useResource(() => identityApi.listDelegations(), []);

  // Fetch users for the Delegate User combobox (only when modal is open)
  const usersResource = useResource(
    () => open ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null,
    [open, accountId]
  );
  const usersList = usersResource.data?.users || [];
  const userOptions = usersList.map((u) => ({
    id: u.user_id,
    label: u.username || u.email || u.user_id,
    description: u.email,
    badge: u.status,
  }));

  // Fetch groups for scope_id combobox (based on selected scope_type)
  const groupsResource = useResource(
    () => (open && form.scope_type === 'group') ? rbacApi.listGroups() : null,
    [open, form.scope_type]
  );
  const groupsList = groupsResource.data?.groups || [];
  const scopeOptions = groupsList.map((g) => ({
    id: g.group_id,
    label: g.group_name || g.group_id,
    description: g.description || `${g.member_count ?? 0} members`,
  }));
  const data = list.data?.delegations || list.data || [];

  // Filter delegations based on search
  const filteredData = data.filter((d) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      d.delegate_username?.toLowerCase().includes(query) ||
      d.delegate_user_id?.toLowerCase().includes(query) ||
      d.scope_id?.toLowerCase().includes(query) ||
      d.scope_type?.toLowerCase().includes(query)
    );
  });

  // Calculate stats
  const stats = {
    total: data.length,
    active: data.filter((d) => (d.status || 'active').toLowerCase() === 'active').length,
    revoked: data.filter((d) => (d.status || 'active').toLowerCase() === 'revoked').length,
    expired: data.filter((d) => (d.status || 'active').toLowerCase() === 'expired').length,
  };

  // Create delegation
  const create = async (e) => {
    e.preventDefault();
    // Validate required fields before submission
    if (!form.delegate_user_id) {
      toast.error('Please select a delegate user.');
      return;
    }
    if (!form.scope_id) {
      toast.error('Please select a scope.');
      return;
    }
    if (form.permissions.length === 0) {
      toast.error('Please select at least one permission.');
      return;
    }
    // An expiry in the past would expire the delegation the moment it is made.
    if (isPastExpiry(form.expires_at)) {
      toast.error('Choose an expiry date of today or later.');
      return;
    }
    setSaving(true);
    try {
      await identityApi.createDelegation({
        account_id: accountId,
        ...form,
        expires_at: toIsoExpiry(form.expires_at),
      });
      toast.success('Delegation created successfully.');
      setOpen(false);
      resetForm();
      list.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create delegation.');
    } finally {
      setSaving(false);
    }
  };

  // Revoke delegation
  const revoke = async (id) => {
    try {
      await identityApi.revokeDelegation(id);
      toast.success('Delegation revoked successfully.');
      setRevokeConfirm(null);
      list.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Revoke failed.');
    }
  };

  // Reset form
  const resetForm = () => {
    setForm({
      delegate_user_id: '',
      scope_type: 'group',
      scope_id: '',
      permissions: ['user:read'],
      expires_at: '',
    });
  };

  // Table columns
  const columns = [
    {
      id: 'delegate',
      header: 'Delegate',
      primary: true,
      sortable: true,
      sortValue: (r) => (r.delegate_username || r.delegate_user_id || '').toLowerCase(),
      render: (r) => (
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-ink-900">
            {r.delegate_username || r.delegate_user_id}
          </p>
          {r.delegate_username && (
            <p className="truncate font-mono text-xs text-slate-500">{r.delegate_user_id}</p>
          )}
        </div>
      ),
    },
    {
      id: 'scope',
      header: 'Scope',
      render: (r) => (
        <div className="flex min-w-0 items-center gap-1.5">
          <Badge tone="sky">{r.scope_type}</Badge>
          <span className="truncate font-mono text-xs text-slate-600">{r.scope_id}</span>
        </div>
      ),
    },
    {
      id: 'permissions',
      header: 'Permissions',
      render: (r) => (
        <div className="flex flex-wrap gap-1 max-w-[200px]">
          {(r.permissions || []).slice(0, 3).map((p) => (
            <Badge key={p} tone="brand">{p}</Badge>
          ))}
          {(r.permissions || []).length > 3 && (
            <Badge tone="slate">+{r.permissions.length - 3}</Badge>
          )}
        </div>
      ),
    },
    {
      id: 'expires',
      header: 'Expires',
      render: (r) => (
        <div className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5 text-slate-400" />
          <span className="text-sm text-slate-600">
            {r.expires_at ? formatDateTime(r.expires_at) : 'Never'}
          </span>
        </div>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={(r.status || 'active').toUpperCase()} />,
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex justify-end">
          <IconButton
            icon={Trash2}
            title="Revoke delegation"
            tone="danger"
            onClick={(e) => {
              e.stopPropagation();
              setRevokeConfirm(r);
            }}
          />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page header */}
      <PageHeader
        title="Delegations"
        description="Temporarily grant specific permissions to another user for break-glass or coverage scenarios."
        icon={<UserCog className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Identity' }, { label: 'Delegations' }]}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New delegation
          </Button>
        }
      />

      {/* Lifecycle summary — the console's standard band (see SummaryBar), the
          same four figures the tile strip carried, at a third of the height.
          Re-derived from the loaded rows, so a create or a revoke moves them. */}
      <SummaryBar
        ariaLabel="Delegation summary"
        loading={list.loading}
        items={[
          { id: 'total', label: 'Total', value: stats.total, hint: 'All delegations', icon: UserCog },
          { id: 'active', label: 'Active', value: stats.active, hint: 'Currently granting access', tone: 'positive', icon: Shield },
          { id: 'revoked', label: 'Revoked', value: stats.revoked, hint: 'Withdrawn by an admin', tone: 'danger', icon: ShieldOff },
          { id: 'expired', label: 'Expired', value: stats.expired, hint: 'Past their expiry', tone: 'warning', icon: Clock },
        ]}
      />

      {/* Filter bar */}
      <Toolbar
        right={
          <span className="text-2xs text-slate-500 tabular">
            {filteredData.length} of {data.length} delegation{data.length === 1 ? '' : 's'}
          </span>
        }
      >
        <SearchInput
          value={searchQuery}
          onChange={setSearchQuery}
          placeholder="Search delegate, scope or type…"
          width="w-full sm:w-80"
        />
      </Toolbar>

      {/* Delegations table */}
      {list.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : filteredData.length === 0 ? (
        <EmptyState
          icon={UserCog}
          title={searchQuery ? 'No delegations match your search' : 'No delegations'}
          description={
            searchQuery
              ? 'Try adjusting your search criteria.'
              : 'Create a delegation to temporarily grant permissions to another user.'
          }
          action={
            !searchQuery && (
              <Button onClick={() => setOpen(true)}>Create delegation</Button>
            )
          }
        />
      ) : (
        <DataTable
          columns={columns}
          data={filteredData}
          loading={false}
          columnsStorageKey="iam-delegations-columns"
        />
      )}

      {/* Create Delegation Modal */}
      <Modal
        open={open}
        onClose={() => { setOpen(false); resetForm(); }}
        title="Create delegation"
        description="Delegated permissions are additive, scoped, and fully audited."
        icon={UserCog}
        footer={
          <>
            <Button variant="secondary" onClick={() => { setOpen(false); resetForm(); }}>
              Cancel
            </Button>
            <Button onClick={create} loading={saving}>
              Create Delegation
            </Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          {/* Delegate User — searchable combobox */}
          <SearchableCombobox
            label="Delegate User"
            options={userOptions}
            value={form.delegate_user_id}
            onChange={(id) => setForm((f) => ({ ...f, delegate_user_id: id }))}
            placeholder="Choose a user to delegate to…"
            searchPlaceholder="Search by name or email…"
            loading={usersResource.loading}
            hint="The user who will receive delegated permissions"
          />
          <Select
            label="Scope Type"
            value={form.scope_type}
            onChange={(e) => setForm((f) => ({ ...f, scope_type: e.target.value, scope_id: '' }))}
          >
            {Object.values(DELEGATION_SCOPE).map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </Select>
          {/* Scope ID — searchable combobox based on scope type */}
          {form.scope_type === 'group' ? (
            <SearchableCombobox
              label="Scope ID"
              options={scopeOptions}
              value={form.scope_id}
              onChange={(id) => setForm((f) => ({ ...f, scope_id: id }))}
              placeholder="Choose a group…"
              searchPlaceholder="Search groups…"
              loading={groupsResource.loading}
              hint="The specific scope this delegation applies to"
            />
          ) : (
            <Input
              label="Scope ID"
              value={form.scope_id}
              onChange={(e) => setForm((f) => ({ ...f, scope_id: e.target.value }))}
              required
              placeholder="department / resource_type"
              hint="The specific scope this delegation applies to"
            />
          )}
          {/* Permissions — multi-select searchable combobox */}
          <SearchableCombobox
            label="Permissions"
            options={ALL_PERMISSIONS.map((p) => ({ id: p, label: p }))}
            value={form.permissions}
            onChange={(perms) => setForm((f) => ({ ...f, permissions: perms }))}
            multi
            placeholder="Select permissions…"
            searchPlaceholder="Search permissions…"
            hint={`${form.permissions.length} permission${form.permissions.length !== 1 ? 's' : ''} selected`}
          />
          <ExpiryInput
            label="Expires at (optional)"
            value={form.expires_at}
            onChange={(e) => setForm((f) => ({ ...f, expires_at: e.target.value }))}
            hint="Leave empty for no expiration. Past dates are disabled."
          />
        </form>
      </Modal>

      {/* Revoke Confirmation Modal */}
      <Modal
        open={!!revokeConfirm}
        onClose={() => setRevokeConfirm(null)}
        title="Revoke delegation"
        icon={AlertTriangle}
        tone="danger"
        size="sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setRevokeConfirm(null)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={() => revoke(revokeConfirm?.delegation_id)} data-autofocus>
              Revoke delegation
            </Button>
          </>
        }
      >
        {revokeConfirm && (
          <div className="space-y-4">
            <InlineAlert tone="danger">
              The delegate loses every permission below immediately. This cannot be undone.
            </InlineAlert>
            <div className="rounded-lg border border-line bg-slate-50/70 p-3">
              <DescriptionList
                items={[
                  {
                    label: 'Delegate',
                    value: revokeConfirm.delegate_username || revokeConfirm.delegate_user_id,
                  },
                  {
                    label: 'Scope',
                    value: revokeConfirm.scope_type + ':' + revokeConfirm.scope_id,
                    mono: true,
                  },
                  {
                    label: 'Permissions',
                    wide: true,
                    value: (
                      <span className="flex flex-wrap gap-1">
                        {(revokeConfirm.permissions || []).map((perm) => (
                          <Badge key={perm} tone="brand" mono>
                            {perm}
                          </Badge>
                        ))}
                      </span>
                    ),
                  },
                ]}
              />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Default export — wraps inner component with AccountGate
// ──────────────────────────────────────────────────────────────────────────────
export default function DelegationsPage() {
  return <AccountGate><DelegationsInner /></AccountGate>;
}
