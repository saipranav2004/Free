import { useState } from 'react';
import { Building2, Plus, Search } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, StatusBadge } from '../../components/ui/primitives.jsx';

export default function TenantsPage() {
  const toast = useToast();
  const [form, setForm] = useState({ company_name: '', domain: '' });
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);

  const register = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await identityApi.registerTenant(form);
      setResult(res);
      toast.success('Tenant registered.');
      setForm({ company_name: '', domain: '' });
    } catch (err) {
      toast.error(err.userMessage || 'Registration failed.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Tenants" description="Register a company / account in the IAM platform." />

      <Card className="p-6">
        <form onSubmit={register} className="space-y-4">
          <Input label="Company name" value={form.company_name} onChange={(e) => setForm((f) => ({ ...f, company_name: e.target.value }))} required />
          <Input label="Domain" value={form.domain} onChange={(e) => setForm((f) => ({ ...f, domain: e.target.value }))} placeholder="acme.com" required hint="Used to scope SSO and email identities." />
          <Button type="submit" loading={saving}><Plus className="h-4 w-4" /> Register tenant</Button>
        </form>

        {result && (
          <div className="mt-5 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
            <div className="mb-2 flex items-center gap-2">
              <Building2 className="h-5 w-5 text-emerald-600" />
              <p className="text-sm font-semibold text-emerald-800">Tenant registered</p>
            </div>
            <dl className="space-y-1 text-sm">
              <Row label="Account ID" value={<code className="font-medium">{result.account_id}</code>} />
              <Row label="Company" value={result.company_name} />
              <Row label="Domain" value={result.domain} />
              <Row label="Status" value={<StatusBadge status={(result.status || 'active').toUpperCase()} />} />
            </dl>
            <p className="mt-3 text-xs text-emerald-700">
              Next: bootstrap the first admin for this account.
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-ink-800">{value}</dd>
    </div>
  );
}
