import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Plus, Trash2, UserX, RotateCcw, Eye, UserCog, Search, Download } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { AccountGate } from '../../components/common/AccountGate.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Select, Spinner, StatusBadge, EmptyState, StatCard } from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { Pagination } from '../../components/common/Pagination.jsx';
import { formatDateTime, initials } from '../../utils/format.js';
import { IDENTITY_USER_STATUS } from '../../utils/constants.js';
import * as XLSX from "xlsx";

const downloadCredentials = (user) => {
  const data = [
    {
      Username: user.username,
      Password: user.password,
      Email: user.email,
      "First Name": user.first_name,
      "Last Name": user.last_name,
      Department: user.department,
      Title: user.title,
      "Created At": new Date().toLocaleString(),
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();

  XLSX.utils.book_append_sheet(workbook, worksheet, "Credentials");

  XLSX.writeFile(
    workbook,
    `${user.username}_credentials.xlsx`
  );
};

function UsersInner() {
  const { accountId } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [filters, setFilters] = useState({ status: '', search: '', page: 1, per_page: 10 });
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    email: '',
    first_name: '',
    last_name: '',
    department: '',
    title: '',
  });
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState(null);
  const [offboardConfirm, setOffboardConfirm] = useState(null);

  const fetcher = () =>
    identityApi.listUsers({
      account_id: accountId,
      status: filters.status || undefined,
      search: filters.search || undefined,
      page: filters.page,
      per_page: filters.per_page,
    });
  const users = useResource(fetcher, [accountId, filters.status, filters.search, filters.page, filters.per_page]);

  const data = users.data?.users || [];
  const pagination = users.data?.pagination || { total: 0, page: 1, per_page: 10, total_pages: 1 };

  // Enterprise: compute status counts from the full user list for stat cards.
  // We use the API pagination total for the overall count and the current page
  // data for status breakdown (a reasonable approximation for the current view).
  const statusCounts = useMemo(() => {
    return {
      total: pagination.total || 0,
      active: data.filter((u) => u.status === 'ACTIVE').length,
      disabled: data.filter((u) => u.status === 'DISABLED').length,
      other: data.filter((u) => u.status !== 'ACTIVE' && u.status !== 'DISABLED').length,
    };
  }, [data, pagination.total]);

  const create = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const res = await identityApi.createUser({
        account_id: accountId,
        ...form,
      });

      // Automatically download Excel
      downloadCredentials({
        ...res,
        email: form.email,
        first_name: form.first_name,
        last_name: form.last_name,
        department: form.department,
        title: form.title,
      });

      setCreated(res);
      setCreateOpen(false);

      setForm({
        email: "",
        first_name: "",
        last_name: "",
        department: "",
        title: "",
      });

      users.reload();
    } catch (err) {
      toast.error(err.userMessage || "Could not create user.");
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (userId, status) => {
    try {
      if (status === 'ACTIVE') await identityApi.enableUser(userId, accountId);
      else await identityApi.disableUser(userId, accountId);
      toast.success(`User ${status.toLowerCase()}.`);
      users.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Action failed.');
    }
  };

  const offboard = async (userId) => {
    try {
      await identityApi.offboardUser(userId, 'Admin-initiated offboarding');
      toast.success('User offboarded — all access revoked.');
      users.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Offboarding failed.');
    }
  };

  // Enterprise: columns with user avatars, structured display, and labeled actions.
  // Avatars provide quick visual identification (pattern from Azure AD / Okta).
  // Action buttons use native title attributes for tooltip clarity.
  const columns = [
    {
      id: 'username',
      header: 'User',
      render: (r) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
            {initials(r.username || r.email || 'U')}
          </span>
          <div>
            <p className="font-medium text-ink-900">{r.username}</p>
            <p className="text-xs text-slate-400">{r.email}</p>
          </div>
        </div>
      ),
    },
    { id: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { id: 'department', header: 'Department', render: (r) => r.department || '—' },
    { id: 'title', header: 'Title', render: (r) => r.title || '—' },
    {
      id: 'last_login_at',
      header: 'Last login',
      render: (r) => (
        <span className="whitespace-nowrap text-sm text-slate-600">
          {formatDateTime(r.last_login_at)}
        </span>
      ),
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex justify-end gap-1">
          <button
            title="View user details"
            onClick={(e) => { e.stopPropagation(); navigate(`/identity/users/${r.user_id}`); }}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-brand-600"
          >
            <Eye className="h-4 w-4" />
          </button>
          {r.status === 'ACTIVE' ? (
            <button
              title="Disable user"
              onClick={(e) => { e.stopPropagation(); setStatus(r.user_id, 'DISABLED'); }}
              className="rounded-lg p-1.5 text-slate-400 transition hover:bg-amber-50 hover:text-amber-600"
            >
              <UserX className="h-4 w-4" />
            </button>
          ) : (
            <button
              title="Enable user"
              onClick={(e) => { e.stopPropagation(); setStatus(r.user_id, 'ACTIVE'); }}
              className="rounded-lg p-1.5 text-slate-400 transition hover:bg-emerald-50 hover:text-emerald-600"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          )}
          <button
            title="Offboard user (revoke all access)"
            onClick={(e) => { e.stopPropagation(); setOffboardConfirm(r); }}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Users"
        description={`Local identity & lifecycle for account ${accountId}.`}
        icon={<UserCog className="h-5 w-5" />}
        actions={
          <div className="flex items-center gap-2">
            {/* Enterprise: export current filtered results to Excel */}
            <Button variant="secondary" onClick={() => {
              if (data.length) {
                const exportData = data.map((u) => ({
                  Username: u.username,
                  Email: u.email,
                  Status: u.status,
                  Department: u.department || '',
                  Title: u.title || '',
                  'Last Login': u.last_login_at || '',
                }));
                const ws = XLSX.utils.json_to_sheet(exportData);
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Users');
                XLSX.writeFile(wb, `users_export_${new Date().toISOString().slice(0, 10)}.xlsx`);
              }
            }}>
              <Download className="h-4 w-4" /> Export
            </Button>
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="h-4 w-4" /> New user
            </Button>
          </div>
        }
      />

      {/* Enterprise: summary stat cards for current page view (Azure AD / Okta pattern).
          Note: counts reflect the current page, not the full dataset. */}
      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Total users" value={statusCounts.total} icon={Users} tone="brand" />
        <StatCard label="Active" value={statusCounts.active} icon={Users} tone="green" />
        <StatCard label="Disabled" value={statusCounts.disabled} icon={UserX} tone="slate" />
        <StatCard label="Other" value={statusCounts.other} icon={UserCog} tone="amber" />
      </div>

      {/* Enterprise: filter bar with search, status dropdown, and clear action */}
      <Card className="mb-4 p-3">
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search by username or email…"
                value={filters.search}
                onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value, page: 1 }))}
                className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-300"
              />
            </div>
          </div>
          <div className="w-44">
            <Select
              label="Status"
              value={filters.status}
              onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value, page: 1 }))}
            >
              <option value="">All statuses</option>
              {Object.values(IDENTITY_USER_STATUS).map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </Select>
          </div>
          {(filters.search || filters.status) && (
            <Button variant="ghost" size="sm" onClick={() => setFilters({ status: '', search: '', page: 1, per_page: 10 })}>
              Clear filters
            </Button>
          )}
        </div>
      </Card>

      <DataTable
        columns={columns}
        data={data}
        loading={users.loading}
        onRowClick={(r) => navigate(`/identity/users/${r.user_id}`)}
        empty={{ title: 'No users found', description: 'Try adjusting your filters or create your first user.' }}
      />
      <Pagination
        page={pagination.page}
        perPage={pagination.per_page}
        total={pagination.total}
        onPageChange={(p) => setFilters((f) => ({ ...f, page: p }))}
      />

      {/* Create user */}
      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create user"
        footer={
          <>
            <Button variant="secondary" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={create} loading={saving}>Create</Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          <Input label="First name" value={form.first_name} onChange={(e) => setForm((f) => ({ ...f, first_name: e.target.value }))} required />
          <Input label="Last name" value={form.last_name} onChange={(e) => setForm((f) => ({ ...f, last_name: e.target.value }))} required />
          <Input label="Email" type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} required />
          <Input label="Department" value={form.department} onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))} />
          <Input label="Title" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
        </form>
      </Modal>

      {/* Generated credentials (shown once) */}
      <Modal
        open={!!created}
        onClose={() => setCreated(null)}
        title="User created"
        footer={<Button onClick={() => setCreated(null)}>Done</Button>}
      >
        <p className="text-sm text-slate-500">{created?.message}</p>
        <div className="mt-3 space-y-2 rounded-lg bg-slate-50 p-3 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-500">Username</span>
            <code className="font-medium text-ink-900">{created?.username}</code>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Password</span>
            <code className="font-medium text-ink-900">{created?.password}</code>
          </div>
        </div>
        <p className="mt-2 text-xs text-amber-600">
          Save these credentials now — the password will not be shown again.
        </p>
      </Modal>

      {/* Offboard confirmation dialog */}
      <ConfirmDialog
        open={!!offboardConfirm}
        onClose={() => setOffboardConfirm(null)}
        onConfirm={() => {
          offboard(offboardConfirm?.user_id);
          setOffboardConfirm(null);
        }}
        danger
        title="Offboard user"
        message={`Are you sure you want to offboard ${offboardConfirm?.username || offboardConfirm?.user_id}? This will revoke ALL access immediately. This action cannot be undone.`}
      />
    </div>
  );
}

export default function UsersPage() {
  return (
    <AccountGate>
      <UsersInner />
    </AccountGate>
  );
}
