import { useState } from 'react';
import { Rocket, KeyRound, Search } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, Badge, StatusBadge } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';

export default function BootstrapPage() {
  const toast = useToast();
  const [form, setForm] = useState({
    account_id: '',
    email: '',
    first_name: '',
    last_name: '',
  });
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState(null);
  const [statusOpen, setStatusOpen] = useState(false);
  const [lookup, setLookup] = useState({ account_id: '', result: null, loading: false });

  const bootstrap = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await identityApi.bootstrapAdmin(form);
      setCreated(res);
      toast.success('Admin bootstrapped.');
    } catch (err) {
      toast.error(err.userMessage || 'Bootstrap failed.');
    } finally {
      setSaving(false);
    }
  };

  const checkStatus = async (e) => {
    e.preventDefault();
    setLookup((l) => ({ ...l, loading: true, result: null }));
    try {
      const res = await identityApi.bootstrapStatus(lookup.account_id);
      setLookup((l) => ({ ...l, result: res, loading: false }));
    } catch (err) {
      toast.error(err.userMessage || 'Lookup failed.');
      setLookup((l) => ({ ...l, loading: false }));
    }
  };

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Admin Bootstrap" description="Create the first administrator for an account." />

      <Card className="p-6">
        <form onSubmit={bootstrap} className="space-y-4">
          <Input label="Account ID" value={form.account_id} onChange={(e) => setForm((f) => ({ ...f, account_id: e.target.value }))} required placeholder="ACC-XXXXXXXX" />
          <Input label="Email" type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} required />
          <div className="grid grid-cols-2 gap-3">
            <Input label="First name" value={form.first_name} onChange={(e) => setForm((f) => ({ ...f, first_name: e.target.value }))} required />
            <Input label="Last name" value={form.last_name} onChange={(e) => setForm((f) => ({ ...f, last_name: e.target.value }))} required />
          </div>
          <Button type="submit" loading={saving}><Rocket className="h-4 w-4" /> Bootstrap admin</Button>
        </form>

        <div className="mt-6 border-t border-slate-100 pt-4">
          <button onClick={() => setStatusOpen(true)} className="text-sm text-brand-600 hover:underline">
            Check bootstrap status for an account
          </button>
        </div>
      </Card>

      {/* Generated admin credentials (shown once) */}
      <Modal open={!!created} onClose={() => setCreated(null)} title="Administrator created"
        footer={<Button onClick={() => setCreated(null)}>Done</Button>}>
        <p className="text-sm text-slate-500">{created?.message}</p>
        <div className="mt-3 space-y-2 rounded-lg bg-slate-50 p-3 text-sm">
          <div className="flex justify-between"><span className="text-slate-500">Username</span><code className="font-medium text-ink-900">{created?.username}</code></div>
          <div className="flex justify-between"><span className="text-slate-500">Password</span><code className="font-medium text-ink-900">{created?.password}</code></div>
          <div className="flex justify-between"><span className="text-slate-500">Role</span><Badge tone="brand">{created?.role}</Badge></div>
        </div>
        <p className="mt-2 text-xs text-amber-600">Save these credentials — the password won't be shown again.</p>
      </Modal>

      {/* Status lookup */}
      <Modal open={statusOpen} onClose={() => setStatusOpen(false)} title="Bootstrap status"
        footer={<Button onClick={() => setStatusOpen(false)}>Close</Button>}>
        <form onSubmit={checkStatus} className="space-y-3">
          <Input label="Account ID" value={lookup.account_id} onChange={(e) => setLookup((l) => ({ ...l, account_id: e.target.value }))} required />
          <Button type="submit" loading={lookup.loading}><Search className="h-4 w-4" /> Check</Button>
        </form>
        {lookup.result && (
          <div className="mt-4 rounded-lg bg-slate-50 p-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">{lookup.result.company_name}</span>
              <StatusBadge status={lookup.result.bootstrap_completed ? 'ACTIVE' : 'PENDING_VERIFICATION'} />
            </div>
            <p className="mt-1 text-xs text-slate-500">{lookup.result.message}</p>
          </div>
        )}
      </Modal>
    </div>
  );
}
