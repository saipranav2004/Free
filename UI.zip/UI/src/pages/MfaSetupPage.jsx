import { useState } from 'react';
import { ShieldCheck, RefreshCw, Trash2, Copy, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { authApi } from '../lib/api/auth.js';
import { mfaApi } from '../lib/api/mfa.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import { Card, Button, Input, Badge, Spinner, StatusBadge } from '../components/ui/primitives.jsx';
import { Modal } from '../components/ui/Modal.jsx';

export default function MfaSetupPage() {
  const { user, refreshProfile } = useAuth();
  const toast = useToast();
  const profile = useResource(() => authApi.me(), []);
  const enabled = profile.data?.mfa_enabled ?? user?.mfa_enabled ?? false;

  const [setup, setSetup] = useState(null); // { mfa_device_id, secret, provisioning_uri, qr_code_base64 }
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [backupCodes, setBackupCodes] = useState(null);
  const [disableOpen, setDisableOpen] = useState(false);
  const [regenOpen, setRegenOpen] = useState(false);
  const [creds, setCreds] = useState({ password: '', code: '' });
  const [copied, setCopied] = useState(false);

  const startSetup = async () => {
    setBusy(true);
    try {
      const res = await mfaApi.setupInitiate();
      setSetup(res);
    } catch (err) {
      toast.error(err.userMessage || 'Could not start MFA setup.');
    } finally {
      setBusy(false);
    }
  };

  const verify = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await mfaApi.setupVerify(setup.mfa_device_id, code);
      setBackupCodes(res.backup_codes);
      setSetup(null);
      setCode('');
      await refreshProfile?.();
      toast.success('MFA enabled.');
    } catch (err) {
      toast.error(err.userMessage || 'Invalid code.');
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await mfaApi.disable(creds.password, creds.code);
      toast.success('MFA disabled.');
      setDisableOpen(false);
      await refreshProfile?.();
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable MFA.');
    } finally {
      setBusy(false);
    }
  };

  const regenerate = async () => {
    setBusy(true);
    try {
      const res = await mfaApi.regenerateBackupCodes(creds.password);
      setBackupCodes(res.backup_codes);
      toast.success('New backup codes generated.');
    } catch (err) {
      toast.error(err.userMessage || 'Could not regenerate codes.');
    } finally {
      setBusy(false);
    }
  };

  const copyCodes = () => {
    navigator.clipboard?.writeText((backupCodes || []).join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div>
      <PageHeader
        title="Multi-Factor Authentication"
        description="Protect your account with a TOTP authenticator app."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-brand-600" />
              <h3 className="text-[13.5px] font-semibold text-ink-900">Authenticator app</h3>
            </div>
            <StatusBadge status={enabled ? 'ACTIVE' : 'DISABLED'} />
          </div>

          {enabled ? (
            <div className="mt-4 space-y-3">
              <p className="text-sm text-slate-500">
                MFA is active. You'll be prompted for a code at login.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => setRegenOpen(true)}>
                  <RefreshCw className="h-4 w-4" /> Regenerate backup codes
                </Button>
                <Button variant="danger" onClick={() => setDisableOpen(true)}>
                  <Trash2 className="h-4 w-4" /> Disable MFA
                </Button>
              </div>
            </div>
          ) : setup ? (
            <form onSubmit={verify} className="mt-4 space-y-4">
              <div className="rounded-lg border border-line p-3 text-center">
                {setup.qr_code_base64 ? (
                  <img
                    src={`data:image/png;base64,${setup.qr_code_base64}`}
                    alt="Authenticator QR"
                    className="mx-auto h-44 w-44"
                  />
                ) : (
                  <p className="text-sm text-slate-500">Scan the URI in your app.</p>
                )}
                <p className="mt-2 break-all text-xs text-slate-400">
                  {setup.provisioning_uri}
                </p>
              </div>
              <Input
                label="Manual key (if you can't scan)"
                value={setup.secret}
                readOnly
                onFocus={(e) => e.target.select()}
              />
              <Input
                label="6-digit code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                inputMode="numeric"
                maxLength={6}
                required
              />
              <Button type="submit" loading={busy}>
                Verify &amp; enable
              </Button>
            </form>
          ) : (
            <div className="mt-4">
              <p className="text-sm text-slate-500">
                Add an extra layer of security by requiring a time-based one-time
                code at login.
              </p>
              <Button className="mt-4" onClick={startSetup} loading={busy}>
                Set up authenticator
              </Button>
            </div>
          )}
        </Card>

        <Card className="p-6">
          <h3 className="text-[13.5px] font-semibold text-ink-900">About MFA</h3>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-slate-600">
            <li>Uses standard TOTP (Google Authenticator, 1Password, etc.).</li>
            <li>Backup codes let you recover access if you lose your device.</li>
            <li>Disabling MFA requires your password and a current code.</li>
            <li>Your backend enforces MFA gating at the PDP for sensitive actions.</li>
          </ul>
          <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
            <Badge tone="sky">TOTP</Badge>
            <Badge tone="slate">Backup codes</Badge>
          </div>
        </Card>
      </div>

      {backupCodes && (
        <Card className="mt-6 p-6">
          <div className="flex items-center justify-between">
            <h3 className="text-[13.5px] font-semibold text-ink-900">Save your backup codes</h3>
            <Button variant="secondary" size="sm" onClick={copyCodes}>
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}{' '}
              {copied ? 'Copied' : 'Copy'}
            </Button>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Each code works once. Store them somewhere safe.
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {backupCodes.map((c) => (
              <code
                key={c}
                className="rounded-md bg-slate-100 px-2 py-1.5 text-center text-sm font-medium text-ink-700"
              >
                {c}
              </code>
            ))}
          </div>
        </Card>
      )}

      <Modal
        open={disableOpen || regenOpen}
        onClose={() => {
          setDisableOpen(false);
          setRegenOpen(false);
        }}
        title={regenOpen ? 'Regenerate backup codes' : 'Confirm with credentials'}
        footer={
          <>
            <Button variant="secondary" onClick={() => { setDisableOpen(false); setRegenOpen(false); }}>
              Cancel
            </Button>
            <Button
              variant={regenOpen ? 'primary' : 'danger'}
              loading={busy}
              onClick={regenOpen ? regenerate : disable}
            >
              {regenOpen ? 'Regenerate' : 'Disable MFA'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input label="Password" type="password" value={creds.password} onChange={(e) => setCreds((c) => ({ ...c, password: e.target.value }))} required />
          <Input label="Current MFA code" value={creds.code} onChange={(e) => setCreds((c) => ({ ...c, code: e.target.value }))} inputMode="numeric" required />
        </div>
      </Modal>
    </div>
  );
}
