import { useState } from 'react';
import { KeyRound, ShieldCheck, Mail, AtSign, Fingerprint } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { authApi } from '../lib/api/auth.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import { Card, Button, Input, Badge, Spinner, StatusBadge } from '../components/ui/primitives.jsx';
import { Modal } from '../components/ui/Modal.jsx';
import { formatDateTime } from '../utils/format.js';

export default function ProfilePage() {
  const { user, refreshProfile } = useAuth();
  const toast = useToast();
  const profile = useResource(() => authApi.me(), []);
  const data = profile.data || user || {};

  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState({ old_password: '', new_password: '', confirm_new_password: '' });
  const [saving, setSaving] = useState(false);

  const changePassword = async (e) => {
    e.preventDefault();
    if (pw.new_password !== pw.confirm_new_password) {
      toast.error('New passwords do not match.');
      return;
    }
    setSaving(true);
    try {
      await authApi.changePassword(pw);
      toast.success('Password changed. Please re-authenticate on other devices.');
      setPwOpen(false);
      setPw({ old_password: '', new_password: '', confirm_new_password: '' });
    } catch (err) {
      toast.error(err.userMessage || 'Could not change password.');
    } finally {
      setSaving(false);
    }
  };

  if (profile.loading && !user) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  const attrs = data.attributes_name || {};

  return (
    <div>
      <PageHeader title="My Profile" description="Your identity, security posture and credentials." />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-1">
          <div className="flex flex-col items-center text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-brand-600 text-2xl font-semibold text-white">
              {(data.username || data.email || 'U').slice(0, 2).toUpperCase()}
            </div>
            <h2 className="mt-3 text-lg font-semibold text-ink-900">{data.username}</h2>
            <p className="text-sm text-slate-500">{data.email}</p>
            <div className="mt-3 flex flex-wrap justify-center gap-1.5">
              <StatusBadge status={data.status} />
              <Badge tone={data.mfa_enabled ? 'green' : 'amber'}>
                {data.mfa_enabled ? 'MFA on' : 'MFA off'}
              </Badge>
              {data.user_type && <Badge tone="brand">{data.user_type}</Badge>}
            </div>
          </div>
          <div className="mt-6 space-y-3 border-t border-slate-100 pt-4 text-sm">
            <Row icon={Mail} label="Email" value={data.email} />
            <Row icon={AtSign} label="Username" value={data.username} />
            <Row icon={ShieldCheck} label="Type" value={data.user_type} />
            <Row icon={Fingerprint} label="Last login" value={formatDateTime(data.last_login_at)} />
          </div>
          <Button className="mt-6 w-full" variant="secondary" onClick={() => setPwOpen(true)}>
            <KeyRound className="h-4 w-4" /> Change password
          </Button>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <h3 className="text-sm font-semibold text-ink-900">Profile attributes (ABAC)</h3>
          <p className="mt-1 text-xs text-slate-500">
            Attributes used by the policy engine for fine-grained (PBAC) decisions.
          </p>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {Object.keys(attrs).length ? (
              Object.entries(attrs).map(([k, v]) => (
                <div key={k} className="rounded-lg border border-slate-200 px-3 py-2">
                  <p className="text-xs text-slate-400">{k}</p>
                  <p className="text-sm font-medium text-ink-800">{String(v)}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400">No attributes set.</p>
            )}
          </div>
        </Card>
      </div>

      <Modal
        open={pwOpen}
        onClose={() => setPwOpen(false)}
        title="Change password"
        footer={
          <>
            <Button variant="secondary" onClick={() => setPwOpen(false)}>
              Cancel
            </Button>
            <Button onClick={changePassword} loading={saving}>
              Update password
            </Button>
          </>
        }
      >
        <form
          onSubmit={changePassword}
          className="space-y-4"
          onClick={(e) => e.stopPropagation()}
        >
          <Input label="Current password" type="password" value={pw.old_password} onChange={(e) => setPw((p) => ({ ...p, old_password: e.target.value }))} required />
          <Input label="New password" type="password" value={pw.new_password} onChange={(e) => setPw((p) => ({ ...p, new_password: e.target.value }))} required hint="Min 10 chars; upper, lower, digit & special." />
          <Input label="Confirm new password" type="password" value={pw.confirm_new_password} onChange={(e) => setPw((p) => ({ ...p, confirm_new_password: e.target.value }))} required />
        </form>
      </Modal>
    </div>
  );
}

function Row({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="h-4 w-4 text-slate-400" />
      <span className="text-slate-500">{label}</span>
      <span className="ml-auto font-medium text-ink-800">{value || '—'}</span>
    </div>
  );
}
