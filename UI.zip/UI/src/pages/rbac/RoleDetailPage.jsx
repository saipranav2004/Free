import { useState, useRef, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, UserPlus, FileLock2, Users, Search, ChevronDown, Check, ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, StatusBadge, Badge, EmptyState } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { classNames } from '../../utils/format.js';

/**
 * Premium Enterprise Role Detail Page.
 *
 * Bug fix: The authz role detail endpoint (GET /authz/roles/<id>) only returns
 * counts, not the actual user/policy arrays. The authz role-users and
 * role-policies endpoints lack GET handlers (only POST/DELETE). Instead, we
 * use the identity module's endpoint:
 *   GET /api/v1/identity/accounts/<account_id>/roles/<role_id>
 * which calls RoleService.get_role_with_users() and returns the full
 * user list + policy list in a single response.
 *
 * Features:
 *  - Searchable combobox for assigning users (enterprise pattern)
 *  - Searchable combobox for attaching policies (matching Assign User UX)
 *  - Summary stats row for quick visibility
 *  - Premium card design for assigned users and attached policies
 *  - Proper revoke/detach with correct IDs
 */
export default function RoleDetailPage() {
  const { roleId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  // ── Bug fix: Use identity endpoint which returns role WITH users + policies ──
  // The authz GET /roles/<id> only returns counts (no user/policy arrays).
  // The authz GET /roles/<id>/users has no GET handler (only POST).
  // The identity GET /accounts/<id>/roles/<id> returns everything in one call.
  const { accountId } = useAuth();
  const role = useResource(
    () => (accountId ? identityApi.getRole(accountId, roleId) : null),
    [accountId, roleId]
  );

  // All policies list (for the attach dropdown)
  const policies = useResource(() => pbacApi.listPolicies(), []);

  // Modal states
  const [userOpen, setUserOpen] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [disableOpen, setDisableOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // Form states
  const [userId, setUserId] = useState('');
  const [policyId, setPolicyId] = useState('');
  const [form, setForm] = useState({ description: '', parent_role_id: '' });

  // ── User combobox state ──
  const [userSearch, setUserSearch] = useState('');
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const userDropdownRef = useRef(null);
  const userSearchInputRef = useRef(null);

  // ── Policy combobox state ──
  const [policySearch, setPolicySearch] = useState('');
  const [policyDropdownOpen, setPolicyDropdownOpen] = useState(false);
  const policyDropdownRef = useRef(null);
  const policySearchInputRef = useRef(null);

  // Close user dropdown on outside click
  useEffect(() => {
    if (!userDropdownOpen) return;
    const handleClick = (e) => {
      if (userDropdownRef.current && !userDropdownRef.current.contains(e.target)) {
        setUserDropdownOpen(false);
        setUserSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [userDropdownOpen]);

  // Close policy dropdown on outside click
  useEffect(() => {
    if (!policyDropdownOpen) return;
    const handleClick = (e) => {
      if (policyDropdownRef.current && !policyDropdownRef.current.contains(e.target)) {
        setPolicyDropdownOpen(false);
        setPolicySearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [policyDropdownOpen]);

  // Focus search inputs when dropdowns open
  useEffect(() => {
    if (userDropdownOpen && userSearchInputRef.current) {
      userSearchInputRef.current.focus();
    }
  }, [userDropdownOpen]);

  useEffect(() => {
    if (policyDropdownOpen && policySearchInputRef.current) {
      policySearchInputRef.current.focus();
    }
  }, [policyDropdownOpen]);

  // ── Users data for combobox ──
  const usersResource = useResource(
    () => (userOpen && accountId ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null),
    [userOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];

  const filteredUsers = usersList.filter((u) => {
    if (!userSearch.trim()) return true;
    const q = userSearch.toLowerCase();
    return (
      (u.username && u.username.toLowerCase().includes(q)) ||
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.user_id && u.user_id.toLowerCase().includes(q))
    );
  });

  const selectedUser = usersList.find((u) => u.user_id === userId);

  const selectUser = useCallback((id) => {
    setUserId(id);
    setUserDropdownOpen(false);
    setUserSearch('');
  }, []);

  // ── Policies data for combobox ──
  const policiesList = Array.isArray(policies.data) ? policies.data : [];

  const filteredPolicies = policiesList.filter((p) => {
    if (!policySearch.trim()) return true;
    const q = policySearch.toLowerCase();
    return (
      (p.policy_name && p.policy_name.toLowerCase().includes(q)) ||
      (p.description && p.description.toLowerCase().includes(q)) ||
      (p.policy_id && p.policy_id.toLowerCase().includes(q))
    );
  });

  const selectedPolicy = policiesList.find((p) => p.policy_id === policyId);

  const selectPolicy = useCallback((id) => {
    setPolicyId(id);
    setPolicyDropdownOpen(false);
    setPolicySearch('');
  }, []);

  // ── Role data extraction ──
  const data = role.data || {};

  // Bug fix: Extract users and policies from the identity endpoint response.
  // identity.services.RoleService.get_role_with_users() returns:
  //   { ..., users: [...], user_count: N, policies: [...] }
  const users = data.users || [];
  const attachedPolicies = data.policies || [];

  const openEdit = () => {
    setForm({ description: data.description || '', parent_role_id: data.parent_role_id || '' });
    setEditOpen(true);
  };

  // Helper to reload all data after mutations
  const reloadAll = () => {
    role.reload();
  };

  const assignUser = async (e) => {
    e.preventDefault();
    if (!userId) { toast.error('Please select a user.'); return; }
    setBusy(true);
    try {
      await rbacApi.assignRoleToUser(roleId, userId);
      toast.success('Role assigned.');
      setUserOpen(false);
      setUserId('');
      setUserDropdownOpen(false);
      setUserSearch('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not assign role.');
    } finally {
      setBusy(false);
    }
  };

  // Enterprise: revoke uses role_id + user_id via the RBAC endpoint.
  // The identity endpoint returns users without assignment_id, so we use
  // DELETE /api/v1/authz/roles/<role_id>/users/<user_id> (RoleUserDetailAPI).
  const revokeUser = async (userId) => {
    try {
      await rbacApi.revokeRoleFromUserById(roleId, userId);
      toast.success('Role revoked.');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke role.');
    }
  };

  const attachPolicy = async (e) => {
    e.preventDefault();
    if (!policyId) { toast.error('Please select a policy.'); return; }
    setBusy(true);
    try {
      await rbacApi.attachPolicyToRole(roleId, policyId);
      toast.success('Policy attached.');
      setPolicyOpen(false);
      setPolicyId('');
      setPolicyDropdownOpen(false);
      setPolicySearch('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach policy.');
    } finally {
      setBusy(false);
    }
  };

  // Detach uses role_id + policy_id via the RBAC endpoint.
  // The identity endpoint returns policies without role_policy_id, so we use
  // DELETE /api/v1/authz/roles/<role_id>/policies/<policy_id> (RolePolicyDetailAPI).
  const detachPolicy = async (policyId) => {
    try {
      await rbacApi.detachPolicyFromRoleById(roleId, policyId);
      toast.success('Policy detached.');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not detach policy.');
    }
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await rbacApi.updateRole(roleId, form);
      toast.success('Role updated.');
      setEditOpen(false);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not update role.');
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await rbacApi.disableRole(roleId);
      toast.success('Role disabled.');
      navigate('/rbac/roles');
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable role.');
    } finally {
      setBusy(false);
      setDisableOpen(false);
    }
  };

  if (role.loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => navigate('/rbac/roles')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Roles
      </button>

      <PageHeader
        title={data.role_name}
        description={data.description}
        icon={<ShieldCheck className="h-5 w-5" />}
        actions={
          <>
            <Button variant="secondary" onClick={openEdit}>Edit</Button>
            <Button variant="danger" onClick={() => setDisableOpen(true)}>
              <Trash2 className="h-4 w-4" /> Disable
            </Button>
          </>
        }
      />

      {/* Enterprise: summary stats row for quick visibility */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-brand-50 p-2 text-brand-600">
            <Users className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Assigned Users</p>
            <p className="text-lg font-semibold text-ink-900">{users.length}</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
            <FileLock2 className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Attached Policies</p>
            <p className="text-lg font-semibold text-ink-900">{attachedPolicies.length}</p>
          </div>
        </Card>
        {data.parent_role_id && (
          <Card className="flex items-center gap-3 p-4">
            <div className="rounded-lg bg-slate-100 p-2 text-slate-600">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Inherits From</p>
              <p className="text-sm font-medium text-ink-900">Parent role</p>
            </div>
          </Card>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* ── Assigned Users Card ── */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-ink-900">
              <Users className="h-4 w-4 text-brand-600" /> Assigned users
            </h3>
            <Button size="sm" onClick={() => setUserOpen(true)}>
              <UserPlus className="h-4 w-4" /> Assign
            </Button>
          </div>
          {role.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : users.length ? (
            <ul className="divide-y divide-slate-100">
              {users.map((u) => (
                <li key={u.user_id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                      {u.username?.charAt(0)?.toUpperCase() || '?'}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{u.username}</p>
                      <p className="text-xs text-slate-400">{u.email}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => revokeUser(u.user_id)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="rounded-full bg-slate-100 p-3 mb-3">
                <Users className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No users assigned</p>
              <p className="mt-1 text-xs text-slate-500">Assign users to grant this role's permissions.</p>
              <Button size="sm" className="mt-3" onClick={() => setUserOpen(true)}>
                <UserPlus className="h-4 w-4" /> Assign user
              </Button>
            </div>
          )}
        </Card>

        {/* ── Attached Policies Card ── */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-ink-900">
              <FileLock2 className="h-4 w-4 text-emerald-600" /> Attached policies
            </h3>
            <Button size="sm" onClick={() => setPolicyOpen(true)}>
              <Plus className="h-4 w-4" /> Attach
            </Button>
          </div>
          {role.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : attachedPolicies.length ? (
            <ul className="divide-y divide-slate-100">
              {attachedPolicies.map((p) => (
                <li key={p.policy_id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-semibold text-emerald-700">
                      <FileLock2 className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{p.policy_name}</p>
                      {p.description && <p className="text-xs text-slate-400">{p.description}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => detachPolicy(p.policy_id)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="rounded-full bg-slate-100 p-3 mb-3">
                <FileLock2 className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No policies attached</p>
              <p className="mt-1 text-xs text-slate-500">Attach policies to define what this role can access.</p>
              <Button size="sm" className="mt-3" onClick={() => setPolicyOpen(true)}>
                <Plus className="h-4 w-4" /> Attach policy
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          MODALS
          ═══════════════════════════════════════════════════════════════════════ */}

      {/* ── Assign User Modal ── */}
      <Modal
        open={userOpen}
        onClose={() => { setUserOpen(false); setUserDropdownOpen(false); setUserSearch(''); }}
        title="Assign user"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setUserOpen(false); setUserDropdownOpen(false); setUserSearch(''); }}>Cancel</Button>
            <Button onClick={assignUser} loading={busy}>Assign</Button>
          </>
        }
      >
        <form onSubmit={assignUser} className="space-y-4">
          <div className="w-full">
            <label className="label-base">User</label>
            {usersResource.loading ? (
              <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2.5">
                <Spinner className="h-4 w-4" />
                <span className="text-sm text-slate-500">Loading users…</span>
              </div>
            ) : usersResource.error ? (
              <p className="text-sm text-rose-600">Failed to load users: {usersResource.error}</p>
            ) : usersList.length === 0 ? (
              <p className="text-sm text-slate-500">No users found in this account.</p>
            ) : (
              <div ref={userDropdownRef} className="relative">
                <button
                  type="button"
                  onClick={() => setUserDropdownOpen((o) => !o)}
                  className={classNames(
                    'flex w-full items-center justify-between gap-2 rounded-lg border bg-white px-3 py-2.5 text-left text-sm transition hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-300',
                    userDropdownOpen ? 'border-brand-400 ring-2 ring-brand-300' : 'border-slate-200'
                  )}
                >
                  {selectedUser ? (
                    <span className="flex items-center gap-2">
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                        {selectedUser.username?.charAt(0)?.toUpperCase() || '?'}
                      </span>
                      <span className="font-medium text-ink-900">{selectedUser.username}</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-500">{selectedUser.email}</span>
                    </span>
                  ) : (
                    <span className="text-slate-400">Choose a user…</span>
                  )}
                  <ChevronDown className={classNames('h-4 w-4 shrink-0 text-slate-400 transition-transform', userDropdownOpen && 'rotate-180')} />
                </button>

                {userDropdownOpen && (
                  <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
                    <div className="border-b border-slate-100 p-2">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <input
                          ref={userSearchInputRef}
                          type="text"
                          placeholder="Search by name or email…"
                          value={userSearch}
                          onChange={(e) => setUserSearch(e.target.value)}
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-8 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-300"
                        />
                      </div>
                    </div>
                    <div className="max-h-60 overflow-y-auto p-1">
                      {filteredUsers.length === 0 ? (
                        <p className="px-3 py-4 text-center text-sm text-slate-400">No users match your search.</p>
                      ) : (
                        filteredUsers.map((u) => {
                          const isSelected = u.user_id === userId;
                          return (
                            <button
                              key={u.user_id}
                              type="button"
                              onClick={() => selectUser(u.user_id)}
                              className={classNames(
                                'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition',
                                isSelected ? 'bg-brand-50' : 'hover:bg-slate-50'
                              )}
                            >
                              <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                                {u.username?.charAt(0)?.toUpperCase() || '?'}
                              </span>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="truncate text-sm font-medium text-ink-900">{u.username}</span>
                                  <span className={classNames(
                                    'inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset',
                                    u.status === 'ACTIVE'
                                      ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20'
                                      : 'bg-slate-100 text-slate-600 ring-slate-500/20'
                                  )}>
                                    {u.status}
                                  </span>
                                </div>
                                <p className="truncate text-xs text-slate-400">{u.email}</p>
                              </div>
                              {isSelected && <Check className="h-4 w-4 shrink-0 text-brand-600" />}
                            </button>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
            <p className="mt-1 text-xs text-slate-400">Select a user to assign this role to.</p>
          </div>
        </form>
      </Modal>

      {/* ── Attach Policy Modal ── */}
      <Modal
        open={policyOpen}
        onClose={() => { setPolicyOpen(false); setPolicyDropdownOpen(false); setPolicySearch(''); setPolicyId(''); }}
        title="Attach policy"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setPolicyOpen(false); setPolicyDropdownOpen(false); setPolicySearch(''); setPolicyId(''); }}>Cancel</Button>
            <Button onClick={attachPolicy} loading={busy}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attachPolicy} className="space-y-4">
          <div className="w-full">
            <label className="label-base">Policy</label>
            {policies.loading ? (
              <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2.5">
                <Spinner className="h-4 w-4" />
                <span className="text-sm text-slate-500">Loading policies…</span>
              </div>
            ) : policiesList.length === 0 ? (
              <p className="text-sm text-slate-500">No policies available. Create a policy first.</p>
            ) : (
              <div ref={policyDropdownRef} className="relative">
                <button
                  type="button"
                  onClick={() => setPolicyDropdownOpen((o) => !o)}
                  className={classNames(
                    'flex w-full items-center justify-between gap-2 rounded-lg border bg-white px-3 py-2.5 text-left text-sm transition hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-300',
                    policyDropdownOpen ? 'border-brand-400 ring-2 ring-brand-300' : 'border-slate-200'
                  )}
                >
                  {selectedPolicy ? (
                    <span className="flex items-center gap-2">
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-emerald-100 text-xs font-semibold text-emerald-700">
                        <FileLock2 className="h-3.5 w-3.5" />
                      </span>
                      <span className="font-medium text-ink-900">{selectedPolicy.policy_name}</span>
                      {selectedPolicy.status && (
                        <span className={classNames(
                          'inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset',
                          selectedPolicy.status === 'ACTIVE'
                            ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20'
                            : 'bg-slate-100 text-slate-600 ring-slate-500/20'
                        )}>
                          {selectedPolicy.status}
                        </span>
                      )}
                    </span>
                  ) : (
                    <span className="text-slate-400">Choose a policy…</span>
                  )}
                  <ChevronDown className={classNames('h-4 w-4 shrink-0 text-slate-400 transition-transform', policyDropdownOpen && 'rotate-180')} />
                </button>

                {policyDropdownOpen && (
                  <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
                    <div className="border-b border-slate-100 p-2">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <input
                          ref={policySearchInputRef}
                          type="text"
                          placeholder="Search by name or description…"
                          value={policySearch}
                          onChange={(e) => setPolicySearch(e.target.value)}
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-8 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-300"
                        />
                      </div>
                    </div>
                    <div className="max-h-60 overflow-y-auto p-1">
                      {filteredPolicies.length === 0 ? (
                        <p className="px-3 py-4 text-center text-sm text-slate-400">No policies match your search.</p>
                      ) : (
                        filteredPolicies.map((p) => {
                          const isSelected = p.policy_id === policyId;
                          return (
                            <button
                              key={p.policy_id}
                              type="button"
                              onClick={() => selectPolicy(p.policy_id)}
                              className={classNames(
                                'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition',
                                isSelected ? 'bg-emerald-50' : 'hover:bg-slate-50'
                              )}
                            >
                              <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-semibold text-emerald-700">
                                <FileLock2 className="h-4 w-4" />
                              </span>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="truncate text-sm font-medium text-ink-900">{p.policy_name}</span>
                                  {p.is_system_policy && <Badge tone="brand">SYSTEM</Badge>}
                                  {p.status && (
                                    <span className={classNames(
                                      'inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset',
                                      p.status === 'ACTIVE'
                                        ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20'
                                        : 'bg-slate-100 text-slate-600 ring-slate-500/20'
                                    )}>
                                      {p.status}
                                    </span>
                                  )}
                                </div>
                                {p.description && <p className="truncate text-xs text-slate-400">{p.description}</p>}
                              </div>
                              {isSelected && <Check className="h-4 w-4 shrink-0 text-emerald-600" />}
                            </button>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
            <p className="mt-1 text-xs text-slate-400">Select a policy to attach to this role.</p>
          </div>
        </form>
      </Modal>

      {/* ── Edit Role Modal ── */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit role"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={saveEdit} loading={busy}>Save</Button>
          </>
        }
      >
        <form onSubmit={saveEdit} className="space-y-4">
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          <Input label="Parent role ID" value={form.parent_role_id} onChange={(e) => setForm((f) => ({ ...f, parent_role_id: e.target.value }))} placeholder="UUID to inherit policies" />
        </form>
      </Modal>

      <ConfirmDialog
        open={disableOpen}
        onClose={() => setDisableOpen(false)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Disable role"
        message="Users assigned this role will lose its permissions."
      />
    </div>
  );
}
