import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UsersRound, Plus, ChevronRight, Users, Search, UserCog } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, StatusBadge, EmptyState } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { extractList } from '../../utils/format.js';

/**
 * Premium Enterprise Groups Page.
 *
 * Enterprise refinements:
 *  - Inline search/filter for quick group lookup
 *  - Better visual hierarchy with member count badges
 *  - Premium empty states with actionable CTAs
 */
export default function GroupsPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const groups = useResource(() => rbacApi.listGroups(), []);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ group_name: '', description: '' });
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  const create = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await rbacApi.createGroup(form);
      toast.success('Group created.');
      setOpen(false);
      setForm({ group_name: '', description: '' });
      groups.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create group.');
    } finally {
      setSaving(false);
    }
  };

  const data = extractList(groups.data, 'groups');

  // Enterprise: inline search filter
  const filteredGroups = data.filter((g) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (g.group_name && g.group_name.toLowerCase().includes(q)) ||
      (g.description && g.description.toLowerCase().includes(q))
    );
  });

  return (
    <div>
      <PageHeader
        title="Groups"
        description="Organize users and attach roles at scale (RBAC)."
        icon={<UsersRound className="h-5 w-5" />}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New group
          </Button>
        }
      />

      {/* Enterprise: inline search bar */}
      {data.length > 3 && (
        <div className="mb-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search groups…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
            />
          </div>
        </div>
      )}

      {groups.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          icon={UsersRound}
          title="No groups yet"
          description="Create a group to start organizing access."
          action={<Button onClick={() => setOpen(true)}>New group</Button>}
        />
      ) : filteredGroups.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <p className="text-sm text-slate-500">No groups match "{search}"</p>
          <Button variant="ghost" size="sm" className="mt-2" onClick={() => setSearch('')}>Clear search</Button>
        </div>
      ) : (
        <Card>
          <ul className="divide-y divide-slate-100">
            {filteredGroups.map((g) => (
              <li key={g.group_id}>
                <button
                  onClick={() => navigate(`/rbac/groups/${g.group_id}`)}
                  className="flex w-full items-center justify-between px-5 py-4 text-left hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                      <UserCog className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-ink-900">{g.group_name}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{g.description || 'No description'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">
                      <Users className="h-3 w-3" />
                      {g.member_count ?? 0} members
                    </span>
                    <StatusBadge status={g.status} />
                    <ChevronRight className="h-4 w-4 text-slate-300" />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Create group"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={create} loading={saving}>
              Create
            </Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          <Input label="Group name" value={form.group_name} onChange={(e) => setForm((f) => ({ ...f, group_name: e.target.value }))} required />
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
        </form>
      </Modal>
    </div>
  );
}
