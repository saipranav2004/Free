import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Plus, ChevronRight, Shield, Users, FileLock2 } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, Select, StatusBadge, Badge, EmptyState, Toolbar, SearchInput, IconButton,
  FormErrorSummary,
} from '../../components/ui/primitives.jsx';
import { RolePicker } from '../../components/common/EntityPickers.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { extractList, classNames } from '../../utils/format.js';

/**
 * Count resolution.
 *
 * Bug fix: the list endpoint and the detail endpoints disagree on the key used
 * for these counts (`assigned_users_count` on authz, `user_count` on identity,
 * a materialised `users` array on some builds). Reading only one of them made
 * the list show "3 assigned" while the detail page showed 0. Resolve every
 * known shape here, and return null — rendered as "—" — when the backend
 * genuinely did not send a count, so the table never invents a zero.
 */
const userCountOf = (r) =>
  r?.assigned_users_count ??
  r?.user_count ??
  r?.users_count ??
  (Array.isArray(r?.users) ? r.users.length : null);

const policyCountOf = (r) =>
  r?.attached_policies_count ??
  r?.policy_count ??
  r?.policies_count ??
  (Array.isArray(r?.policies) ? r.policies.length : null);

/**
 * RolesPage — RBAC role inventory.
 *
 * Consistent list-page anatomy used across the console:
 *   PageHeader → Toolbar (search + scope) → DataTable → row detail navigation
 * Roles are shown as a table rather than cards: administrators compare type,
 * assignment counts and status across many roles at once.
 */
export default function RolesPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const roles = useResource(() => rbacApi.listRoles(), []);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({
    role_name: '',
    description: '',
    role_type: 'CUSTOM',
    parent_role_id: '',
  });

  const data = extractList(roles.data, 'roles');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (r) =>
        r.role_name?.toLowerCase().includes(q) ||
        r.description?.toLowerCase().includes(q) ||
        r.role_type?.toLowerCase().includes(q)
    );
  }, [data, search]);

  const validate = () => {
    const next = {};
    const name = form.role_name.trim();
    if (!name) next.role_name = 'Role name is required.';
    else if (name.length < 3) next.role_name = 'Use at least 3 characters so the role is recognisable.';
    else if (data.some((r) => r.role_name?.toLowerCase() === name.toLowerCase())) {
      next.role_name = 'A role with this name already exists.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const create = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      await rbacApi.createRole({ ...form, parent_role_id: form.parent_role_id || null });
      toast.success('Role created.');
      setOpen(false);
      setForm({ role_name: '', description: '', role_type: 'CUSTOM', parent_role_id: '' });
      roles.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create role.');
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    {
      id: 'role_name',
      header: 'Role',
      primary: true,
      sortable: true,
      render: (r) => (
        <div className="flex items-center gap-3">
          <span
            className={classNames(
              'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg',
              r.role_type === 'SYSTEM' ? 'bg-brand-50 text-brand-700' : 'bg-slate-100 text-slate-500'
            )}
          >
            {r.role_type === 'SYSTEM' ? <Shield className="h-4 w-4" /> : <ShieldCheck className="h-4 w-4" />}
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium text-ink-900">{r.role_name}</p>
            <p className="truncate text-xs text-slate-500">{r.description || 'No description'}</p>
          </div>
        </div>
      ),
    },
    {
      id: 'role_type',
      header: 'Type',
      sortable: true,
      render: (r) => <Badge tone={r.role_type === 'SYSTEM' ? 'brand' : 'slate'}>{r.role_type}</Badge>,
    },
    {
      id: 'assigned_users_count',
      header: 'Assigned users',
      sortable: true,
      render: (r) => {
        const count = userCountOf(r);
        return count != null ? (
          <span className="inline-flex items-center gap-1.5 text-[13px] text-ink-800 tabular">
            <Users className="h-3.5 w-3.5 text-slate-400" />
            {count}
          </span>
        ) : (
          <span className="text-slate-400">—</span>
        );
      },
    },
    {
      id: 'policy_count',
      header: 'Policies',
      sortable: true,
      render: (r) => {
        const count = policyCountOf(r);
        return count != null ? (
          <span className="inline-flex items-center gap-1.5 text-[13px] text-ink-800 tabular">
            <FileLock2 className="h-3.5 w-3.5 text-slate-400" />
            {count}
          </span>
        ) : (
          <span className="text-slate-400">—</span>
        );
      },
    },
    {
      id: 'status',
      header: 'Status',
      sortable: true,
      render: (r) => <StatusBadge status={r.status} />,
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <IconButton
          icon={ChevronRight}
          title="Open role"
          tone="brand"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/rbac/roles/${r.role_id}`);
          }}
        />
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Roles"
        description="Define roles, inherit from parents and attach policies (RBAC / PBAC)."
        icon={<ShieldCheck className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Access control' }, { label: 'Roles' }]}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New role
          </Button>
        }
      />

      <div className="space-y-4">
        <Toolbar
          right={
            <span className="text-2xs text-slate-500 tabular">
              {filtered.length} of {data.length} role{data.length === 1 ? '' : 's'}
            </span>
          }
        >
          <SearchInput value={search} onChange={setSearch} placeholder="Search roles…" />
        </Toolbar>

        {roles.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={roles.loading}
            onRowClick={(r) => navigate(`/rbac/roles/${r.role_id}`)}
            densityStorageKey="iam-table-density"
            columnsStorageKey="iam-roles-columns"
            empty={{
              icon: ShieldCheck,
              title: `No roles match “${search}”`,
              description: 'Adjust the search to see more results.',
              action: (
                <Button variant="secondary" onClick={() => setSearch('')}>
                  Clear search
                </Button>
              ),
            }}
          />
        ) : (
          <EmptyState
            icon={ShieldCheck}
            title="No roles yet"
            description="Create a role and attach policies to grant access consistently."
            action={<Button onClick={() => setOpen(true)}>New role</Button>}
          />
        )}
      </div>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Create role"
        description="Roles bundle policies so access can be granted and revoked as one unit."
        icon={ShieldCheck}
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={create} loading={saving}>
              Create role
            </Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          <FormErrorSummary errors={errors} />
          <Input
            label="Role name"
            value={form.role_name}
            error={errors.role_name}
            onChange={(e) => {
              setForm((f) => ({ ...f, role_name: e.target.value }));
              setErrors((x) => ({ ...x, role_name: undefined }));
            }}
            required
            placeholder="platform-operator"
            hint="Lowercase, hyphenated names read best in policy documents."
          />
          <Input
            label="Description"
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            placeholder="What this role is allowed to do"
          />
          <Select
            label="Role type"
            value={form.role_type}
            onChange={(e) => setForm((f) => ({ ...f, role_type: e.target.value }))}
            hint="System roles are managed by the platform and cannot be reassigned freely."
          >
            <option value="CUSTOM">CUSTOM</option>
            <option value="SYSTEM">SYSTEM</option>
          </Select>
          <RolePicker
            label="Parent role"
            value={form.parent_role_id}
            onChange={(id) => setForm((f) => ({ ...f, parent_role_id: id || '' }))}
            placeholder="Search roles to inherit from…"
            hint="Optional. The new role inherits every policy attached to the parent."
          />
        </form>
      </Modal>
    </div>
  );
}
