import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Plus, ChevronRight, Shield, Users, FileLock2, Search } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Select, Spinner, StatusBadge, Badge, EmptyState } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { extractList, classNames } from '../../utils/format.js';

/**
 * Premium Enterprise Roles Page.
 *
 * Enterprise refinements:
 *  - Inline search/filter for quick role lookup
 *  - Better visual hierarchy with role type badges
 *  - Assigned users count as secondary metadata
 *  - Premium empty states with actionable CTAs
 */
export default function RolesPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const roles = useResource(() => rbacApi.listRoles(), []);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    role_name: '',
    description: '',
    role_type: 'CUSTOM',
    parent_role_id: '',
  });
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  const create = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await rbacApi.createRole({
        ...form,
        parent_role_id: form.parent_role_id || null,
      });
      toast.success('Role created.');
      setOpen(false);
      setForm({ role_name: '', description: '', role_type: 'CUSTOM', parent_role_id: '' });
      roles.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create role.');
    } finally {
      setSaving(false);
    }
  };

  const data = extractList(roles.data, 'roles');

  // Enterprise: inline search filter
  const filteredRoles = data.filter((r) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (r.role_name && r.role_name.toLowerCase().includes(q)) ||
      (r.description && r.description.toLowerCase().includes(q))
    );
  });

  return (
    <div>
      <PageHeader
        title="Roles"
        description="Define roles and attach policies (RBAC / PBAC)."
        icon={<ShieldCheck className="h-5 w-5" />}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New role
          </Button>
        }
      />

      {/* Enterprise: inline search bar */}
      {data.length > 3 && (
        <div className="mb-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search roles…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
            />
          </div>
        </div>
      )}

      {roles.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          icon={ShieldCheck}
          title="No roles yet"
          description="Create a role and attach policies to grant access."
          action={<Button onClick={() => setOpen(true)}>New role</Button>}
        />
      ) : filteredRoles.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <p className="text-sm text-slate-500">No roles match "{search}"</p>
          <Button variant="ghost" size="sm" className="mt-2" onClick={() => setSearch('')}>Clear search</Button>
        </div>
      ) : (
        <Card>
          <ul className="divide-y divide-slate-100">
            {filteredRoles.map((r) => (
              <li key={r.role_id}>
                <button
                  onClick={() => navigate(`/rbac/roles/${r.role_id}`)}
                  className="flex w-full items-center justify-between px-5 py-4 text-left hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className={classNames(
                      'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
                      r.role_type === 'SYSTEM' ? 'bg-brand-100 text-brand-600' : 'bg-slate-100 text-slate-500'
                    )}>
                      {r.role_type === 'SYSTEM' ? <Shield className="h-5 w-5" /> : <ShieldCheck className="h-5 w-5" />}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-ink-900">{r.role_name}</p>
                        <Badge tone={r.role_type === 'SYSTEM' ? 'brand' : 'slate'}>
                          {r.role_type}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{r.description || 'No description'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {r.assigned_users_count != null && r.assigned_users_count > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">
                        <Users className="h-3 w-3" />
                        {r.assigned_users_count}
                      </span>
                    )}
                    <StatusBadge status={r.status} />
                    <ChevronRight className="h-4 w-4 text-slate-300" />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Create role"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={create} loading={saving}>Create</Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          <Input label="Role name" value={form.role_name} onChange={(e) => setForm((f) => ({ ...f, role_name: e.target.value }))} required />
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          <Select label="Role type" value={form.role_type} onChange={(e) => setForm((f) => ({ ...f, role_type: e.target.value }))}>
            <option value="CUSTOM">CUSTOM</option>
            <option value="SYSTEM">SYSTEM</option>
          </Select>
          <Input label="Parent role ID (optional)" value={form.parent_role_id} onChange={(e) => setForm((f) => ({ ...f, parent_role_id: e.target.value }))} placeholder="UUID to inherit policies" />
        </form>
      </Modal>
    </div>
  );
}
