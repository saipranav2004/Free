import { useEffect, useMemo, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, Code2, UserPlus, Link2 } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { pbacApi } from '../../lib/api/pbac.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { identityApi } from '../../lib/api/identity.js';
import { useResource } from '../../hooks/useResource.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Select, Textarea, Spinner, Badge, SearchableCombobox } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { POLICY_DOCUMENT_VERSION } from '../../utils/constants.js';
import { extractList } from '../../utils/format.js';

/* Wildcard is a first-class choice in a policy statement, so it belongs in the
   picker rather than forcing the operator back to free text. */
const WILDCARD_OPTION = {
  id: '*',
  label: 'All resources  (*)',
  description: 'Matches every resource ARN',
};

/** Statement.Resource is stored as a comma-joined string; the picker wants an array. */
const parseResources = (value) =>
  String(value || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

const joinResources = (list) => (Array.isArray(list) ? list.join(', ') : '');

const blankStatement = () => ({
  sid: '',
  effect: 'Allow',
  action: '',
  resource: '',
  condition: '',
});

export default function PolicyEditorPage() {
  const { policyId } = useParams();
  const isEdit = !!policyId;
  const navigate = useNavigate();
  const toast = useToast();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState(POLICY_DOCUMENT_VERSION);
  const [statements, setStatements] = useState([blankStatement()]);
  const [rawMode, setRawMode] = useState(false);
  const [rawText, setRawText] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [attachOpen, setAttachOpen] = useState(false);
  const [attachForm, setAttachForm] = useState({ user_id: '', expires_at: '' });
  const [attaching, setAttaching] = useState(false);
  const [nameError, setNameError] = useState('');

  /* The principal picker below is the shared SearchableCombobox primitive,
     which owns its own search / open / focus state. The page-level dropdown
     state this file used to carry was unused after that refactor. */

  // Fetch all users for the attach-policy dropdown.
  // Reuses the same identityApi.listUsers endpoint that UsersPage uses.
  // useResource refetches when attachOpen toggles because the fetcher function
  // identity changes (new function reference is created by useCallback).
  const { accountId } = useAuth();
  const usersResource = useResource(
    () => (attachOpen && accountId ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null),
    [attachOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];

  /* ── Resource registry for the statement Resource picker ──────────────────
     Statements reference resources by ARN, and typing an ARN by hand is the
     easiest thing in this editor to get silently wrong. The registry
     (GET /api/v1/resources) is loaded once and offered as a searchable
     multi-select: policy documents legitimately list several resources, so the
     field is multi with select-all over the current filter. */
  const resourcesResource = useResource(() => pbacApi.listResources(), []);
  const registryResources = extractList(resourcesResource.data, 'resources');

  const resourceOptions = useMemo(() => {
    const opts = registryResources
      .filter((r) => r.resource_arn)
      .map((r) => ({
        id: r.resource_arn,
        label: r.resource_name || r.resource_arn,
        description: r.resource_arn,
        badge: r.is_active === false ? 'INACTIVE' : r.resource_type || undefined,
      }));
    return [WILDCARD_OPTION, ...opts];
  }, [registryResources]);

  /* An existing policy may reference an ARN that is no longer registered (or a
     pattern like `iam:user/*`). Those values must stay selectable, so they are
     appended as options rather than silently dropped when the form loads. */
  const optionsForStatement = (statement) => {
    const known = new Set(resourceOptions.map((o) => o.id));
    const extras = parseResources(statement.resource)
      .filter((arn) => !known.has(arn))
      .map((arn) => ({
        id: arn,
        label: arn,
        description: 'Not in the resource registry',
        badge: 'CUSTOM',
      }));
    return extras.length ? [...resourceOptions, ...extras] : resourceOptions;
  };

  useEffect(() => {
    if (!isEdit) return;
    pbacApi
      .getPolicy(policyId)
      .then((p) => {
        setName(p.policy_name || '');
        setDescription(p.description || '');
        const doc = p.policy_document || {};
        setVersion(doc.Version || POLICY_DOCUMENT_VERSION);
        const stmts = Array.isArray(doc.Statement) ? doc.Statement : [];
        setStatements(
          stmts.length
            ? stmts.map((s) => ({
                sid: s.Sid || '',
                effect: s.Effect || 'Allow',
                action: Array.isArray(s.Action) ? s.Action.join(', ') : s.Action || '',
                resource: Array.isArray(s.Resource) ? s.Resource.join(', ') : s.Resource || '',
                condition: s.Condition ? JSON.stringify(s.Condition, null, 2) : '',
              }))
            : [blankStatement()]
        );
      })
      .catch((err) => toast.error(err.userMessage || 'Could not load policy.'))
      .finally(() => setLoading(false));
  }, [isEdit, policyId, toast]);

  const updateStatement = (i, key, value) =>
    setStatements((list) => list.map((s, idx) => (idx === i ? { ...s, [key]: value } : s)));
  const addStatement = () => setStatements((list) => [...list, blankStatement()]);
  const removeStatement = (i) =>
    setStatements((list) => list.filter((_, idx) => idx !== i));

  /**
   * Raw-JSON toggle.
   *
   * Bug fix: `rawText` started empty and was never seeded, so switching to
   * "Raw JSON" showed a blank editor and saving from it threw
   * "Unexpected end of JSON input". Entering raw mode now serialises the
   * current document into the textarea, and leaving it parses the JSON back
   * into the statement form (invalid JSON keeps the form untouched and says so)
   * so no work is lost either way.
   */
  const toggleRawMode = () => {
    if (!rawMode) {
      let seed = rawText;
      try {
        seed = JSON.stringify(buildDocument(), null, 2);
      } catch {
        seed =
          rawText ||
          JSON.stringify({ Version: version, Statement: [] }, null, 2);
      }
      setRawText(seed);
      setRawMode(true);
      return;
    }
    try {
      const parsed = JSON.parse(rawText);
      const stmts = Array.isArray(parsed.Statement) ? parsed.Statement : [];
      setVersion(parsed.Version || version);
      setStatements(
        stmts.length
          ? stmts.map((s) => ({
              sid: s.Sid || '',
              effect: s.Effect || 'Allow',
              action: Array.isArray(s.Action) ? s.Action.join(', ') : s.Action || '',
              resource: Array.isArray(s.Resource) ? s.Resource.join(', ') : s.Resource || '',
              condition: s.Condition ? JSON.stringify(s.Condition, null, 2) : '',
            }))
          : [blankStatement()]
      );
      setRawMode(false);
    } catch {
      toast.error('The raw document is not valid JSON — fix it before switching back.');
    }
  };

  const buildDocument = () => {
    if (rawMode) {
      const parsed = JSON.parse(rawText);
      if (!Array.isArray(parsed.Statement) || parsed.Statement.length === 0)
        throw new Error('Policy document must include a non-empty Statement array.');
      return parsed;
    }
    const valid = statements.filter((s) => s.action.trim() && s.resource.trim());
    if (!valid.length) throw new Error('Add at least one statement with an action and resource.');
    const Statement = valid.map((s) => {
      const toField = (v) =>
        v.includes(',') ? v.split(',').map((x) => x.trim()).filter(Boolean) : v.trim();
      const stmt = {
        Effect: s.effect,
        Action: toField(s.action),
        Resource: toField(s.resource),
      };
      if (s.sid.trim()) stmt.Sid = s.sid.trim();
      if (s.condition.trim()) {
        try {
          stmt.Condition = JSON.parse(s.condition);
        } catch {
          throw new Error('Condition must be valid JSON.');
        }
      }
      return stmt;
    });
    return { Version: version, Statement };
  };

  const save = async () => {
    // A policy without a name is rejected by the API with an opaque 400, so
    // catch it here where the field can be highlighted.
    if (!name.trim()) {
      setNameError('Policy name is required.');
      toast.error('Give the policy a name before saving.');
      return;
    }
    setNameError('');
    setSaving(true);
    try {
      const policy_document = buildDocument();
      const payload = { policy_name: name, description, policy_document };
      if (isEdit) await pbacApi.updatePolicy(policyId, payload);
      else await pbacApi.createPolicy(payload);
      toast.success(`Policy ${isEdit ? 'updated' : 'created'}.`);
      navigate('/pbac/policies');
    } catch (err) {
      toast.error(err.message || err.userMessage || 'Could not save policy.');
    } finally {
      setSaving(false);
    }
  };

  const attach = async (e) => {
    e.preventDefault();
    if (!attachForm.user_id) { toast.error('Select a user first.'); return; }
    setAttaching(true);
    try {
      await pbacApi.attachPolicyToUser({
        user_id: attachForm.user_id,
        policy_id: policyId,
        // `datetime-local` yields "2026-07-29T10:00" with no timezone; the API
        // expects ISO 8601 — the same conversion UserDetailPage does.
        expires_at: attachForm.expires_at
          ? new Date(attachForm.expires_at).toISOString()
          : null,
      });
      toast.success('Policy attached to user (PBAC).');
      setAttachOpen(false);
      setAttachForm({ user_id: '', expires_at: '' });
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach policy.');
    } finally {
      setAttaching(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  const preview = (() => {
    try {
      return JSON.stringify(buildDocument(), null, 2);
    } catch {
      return '// fix validation errors to preview';
    }
  })();

  return (
    <div>
      <button
        onClick={() => navigate('/pbac/policies')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Policies
      </button>

      <PageHeader
        title={isEdit ? 'Edit policy' : 'New policy'}
        description="Define allow/deny statements evaluated by OPA."
        actions={
          isEdit ? (
            <Button variant="outline" onClick={() => setAttachOpen(true)}>
              <UserPlus className="h-4 w-4" /> Attach to user
            </Button>
          ) : null
        }
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="space-y-4 p-5">
            <Input
              label="Policy name"
              value={name}
              error={nameError}
              onChange={(e) => {
                setName(e.target.value);
                setNameError('');
              }}
              required
            />
            <Input label="Description" value={description} onChange={(e) => setDescription(e.target.value)} />

            <div className="flex items-center justify-between">
              <h3 className="text-[13.5px] font-semibold text-ink-900">Statements</h3>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" onClick={toggleRawMode}>
                  <Code2 className="h-4 w-4" /> {rawMode ? 'Form' : 'Raw JSON'}
                </Button>
                {!rawMode && (
                  <Button size="sm" onClick={addStatement}>
                    <Plus className="h-4 w-4" /> Add
                  </Button>
                )}
              </div>
            </div>

            {rawMode ? (
              <Textarea
                rows={16}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                className="font-mono text-xs"
                placeholder='{ "Version": "2025-01-01", "Statement": [ ... ] }'
              />
            ) : (
              <div className="space-y-3">
                {statements.map((s, i) => (
                  <div key={i} className="rounded-lg border border-line p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-400">Statement {i + 1}</span>
                      <button
                        type="button"
                        onClick={() => removeStatement(i)}
                        className="text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <Select value={s.effect} onChange={(e) => updateStatement(i, 'effect', e.target.value)}>
                        <option value="Allow">Allow</option>
                        <option value="Deny">Deny</option>
                      </Select>
                      <Input
                        label="Sid (optional)"
                        value={s.sid}
                        onChange={(e) => updateStatement(i, 'sid', e.target.value)}
                      />
                      <Input
                        label="Action"
                        value={s.action}
                        onChange={(e) => updateStatement(i, 'action', e.target.value)}
                        placeholder="iam:user:Read or iam:*"
                      />
                      {/* Resource picker — real ARNs from the registry, never
                          a hand-typed string. */}
                      <SearchableCombobox
                        label="Resource"
                        multi
                        required
                        options={optionsForStatement(s)}
                        value={parseResources(s.resource)}
                        onChange={(list) => updateStatement(i, 'resource', joinResources(list))}
                        loading={resourcesResource.loading}
                        error={
                          resourcesResource.error ? 'Failed to load the resource registry.' : undefined
                        }
                        placeholder="Select resources…"
                        searchPlaceholder="Search resources by name or ARN…"
                        hint="From the resource registry. Choose “All resources” for a wildcard."
                        emptyMessage="No resources match that search."
                      />
                      <div className="sm:col-span-2">
                        <Textarea
                          label="Condition (JSON, optional)"
                          rows={2}
                          value={s.condition}
                          onChange={(e) => updateStatement(i, 'condition', e.target.value)}
                          className="font-mono text-xs"
                          placeholder='{ "StringEquals": { "user.department": "engineering" } }'
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <Card className="h-fit p-5">
          <h3 className="text-[13.5px] font-semibold text-ink-900">Preview</h3>
          <p className="mb-2 text-xs text-slate-400">Generated policy document</p>
          <pre className="max-h-[60vh] overflow-auto rounded-lg bg-ink-900 p-3 text-xs text-emerald-200">
            {preview}
          </pre>
          <Button className="mt-4 w-full" onClick={save} loading={saving}>
            {isEdit ? 'Save changes' : 'Create policy'}
          </Button>
        </Card>

          {/* Blast radius before the edit, not after it. */}
          {isEdit && <PolicyUsage policyId={policyId} />}
      </div>

      <Modal
        open={attachOpen}
        onClose={() => { setAttachOpen(false); setAttachForm({ user_id: '', expires_at: '' }); }}
        title="Attach policy to user"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setAttachOpen(false); setAttachForm({ user_id: '', expires_at: '' }); }}>Cancel</Button>
            <Button onClick={attach} loading={attaching} disabled={!attachForm.user_id}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attach} className="space-y-4">
          {/* Type-ahead principal picker — same endpoint (identityApi.listUsers),
              one field: typing filters the directory list underneath it. */}
          <SearchableCombobox
            label="User"
            required
            options={usersList.map((u) => ({
              id: u.user_id,
              label: u.username || u.email || u.user_id,
              description: u.email,
              badge: u.status && u.status !== 'ACTIVE' ? u.status : undefined,
            }))}
            value={attachForm.user_id}
            onChange={(id) => setAttachForm((f) => ({ ...f, user_id: id || '' }))}
            loading={usersResource.loading}
            error={usersResource.error ? 'Failed to load the user directory.' : undefined}
            placeholder="Search users by name or email…"
            hint="Type to filter the tenant directory."
            emptyMessage="No users match that name or email."
          />

          <Input label="Expires at (optional)" type="datetime-local" value={attachForm.expires_at} onChange={(e) => setAttachForm((f) => ({ ...f, expires_at: e.target.value }))} />
          <p className="text-xs text-slate-400">
            Directly attaches this policy to a user (PBAC), independent of roles.
          </p>
        </form>
      </Modal>
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   PolicyUsage — "where is this policy used?"

   Disabling or editing a policy is a blast-radius decision, so the roles that
   depend on it belong on the same screen as the edit form. Read-only: it lists
   roles (existing endpoint) and asks each for its attachments, capped so the
   page never fires an unbounded number of requests.
   ═══════════════════════════════════════════════════════════════════════════ */
function PolicyUsage({ policyId }) {
  const [state, setState] = useState({ loading: true, roles: [], truncated: false });

  useEffect(() => {
    let cancelled = false;
    setState({ loading: true, roles: [], truncated: false });

    rbacApi
      .listRoles()
      .then((res) => {
        const all = extractList(res, 'roles');
        const scan = all.slice(0, 30);
        return Promise.allSettled(
          scan.map((role) =>
            rbacApi.listRolePolicies(role.role_id).then((rp) => ({ role, attachments: rp }))
          )
        ).then((results) => ({ results, truncated: all.length > scan.length }));
      })
      .then(({ results, truncated }) => {
        if (cancelled) return;
        const roles = [];
        results.forEach((r) => {
          if (r.status !== 'fulfilled') return;
          const { role, attachments } = r.value;
          const arr = extractList(attachments, 'policies').length
            ? extractList(attachments, 'policies')
            : extractList(attachments, 'role_policies');
          if (arr.some((a) => (a.policy_id || a.policy?.policy_id) === policyId)) roles.push(role);
        });
        setState({ loading: false, roles, truncated });
      })
      .catch(() => !cancelled && setState({ loading: false, roles: [], truncated: false }));

    return () => {
      cancelled = true;
    };
  }, [policyId]);

  return (
    <Card className="mt-4 p-5">
      <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
        <Link2 className="h-4 w-4 text-slate-400" /> Where this policy is used
      </h3>
      <p className="mt-0.5 text-xs text-slate-500">
        Roles that inherit these permissions today.
      </p>

      {state.loading ? (
        <div className="flex justify-center py-6">
          <Spinner className="h-4 w-4" />
        </div>
      ) : state.roles.length === 0 ? (
        <p className="mt-3 rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2.5 text-xs text-slate-500">
          Not attached to any role. Changes here affect only direct user attachments.
        </p>
      ) : (
        <ul className="mt-3 space-y-1.5">
          {state.roles.map((role) => (
            <li key={role.role_id}>
              <Link
                to={`/rbac/roles/${role.role_id}`}
                className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 no-underline transition-colors hover:bg-slate-50 hover:no-underline"
              >
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-medium text-ink-900">
                    {role.role_name}
                  </span>
                  {role.description && (
                    <span className="block truncate text-2xs text-slate-500">{role.description}</span>
                  )}
                </span>
                {role.assigned_users_count != null && (
                  <Badge tone="slate">{role.assigned_users_count} users</Badge>
                )}
              </Link>
            </li>
          ))}
        </ul>
      )}

      {state.truncated && (
        <p className="mt-2 text-2xs text-slate-400">
          Checked the first 30 roles. Narrow the role list to audit the rest.
        </p>
      )}
    </Card>
  );
}
