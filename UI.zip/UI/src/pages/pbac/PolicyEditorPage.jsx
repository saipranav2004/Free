import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, Code2, UserPlus, Link2, Search, ChevronDown, Check } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { pbacApi } from '../../lib/api/pbac.js';
import { identityApi } from '../../lib/api/identity.js';
import { useResource } from '../../hooks/useResource.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Select, Textarea, Spinner, Badge } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { POLICY_DOCUMENT_VERSION } from '../../utils/constants.js';

const blankStatement = () => ({
  sid: '',
  effect: 'Allow',
  action: '',
  resource: '',
  condition: '',
});

export default function PolicyEditorPage() {
  const { policyId } = useParams();
  const isEdit = !!policyId;
  const navigate = useNavigate();
  const toast = useToast();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState(POLICY_DOCUMENT_VERSION);
  const [statements, setStatements] = useState([blankStatement()]);
  const [rawMode, setRawMode] = useState(false);
  const [rawText, setRawText] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [attachOpen, setAttachOpen] = useState(false);
  const [attachForm, setAttachForm] = useState({ user_id: '', expires_at: '' });
  const [userSearch, setUserSearch] = useState('');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const searchInputRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    if (!dropdownOpen) return;
    const handleClick = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
        setUserSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [dropdownOpen]);

  // Focus search input when dropdown opens
  useEffect(() => {
    if (dropdownOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [dropdownOpen]);

  // Fetch all users for the attach-policy dropdown.
  // Reuses the same identityApi.listUsers endpoint that UsersPage uses.
  // useResource refetches when attachOpen toggles because the fetcher function
  // identity changes (new function reference is created by useCallback).
  const { accountId } = useAuth();
  const usersResource = useResource(
    () => (attachOpen && accountId ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null),
    [attachOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];

  const filteredUsers = usersList.filter((u) => {
    if (!userSearch.trim()) return true;
    const q = userSearch.toLowerCase();
    return (
      (u.username && u.username.toLowerCase().includes(q)) ||
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.user_id && u.user_id.toLowerCase().includes(q))
    );
  });

  const selectedUser = usersList.find((u) => u.user_id === attachForm.user_id);

  const selectUser = useCallback((userId) => {
    setAttachForm((f) => ({ ...f, user_id: userId }));
    setDropdownOpen(false);
    setUserSearch('');
  }, []);

  useEffect(() => {
    if (!isEdit) return;
    pbacApi
      .getPolicy(policyId)
      .then((p) => {
        setName(p.policy_name || '');
        setDescription(p.description || '');
        const doc = p.policy_document || {};
        setVersion(doc.Version || POLICY_DOCUMENT_VERSION);
        const stmts = Array.isArray(doc.Statement) ? doc.Statement : [];
        setStatements(
          stmts.length
            ? stmts.map((s) => ({
                sid: s.Sid || '',
                effect: s.Effect || 'Allow',
                action: Array.isArray(s.Action) ? s.Action.join(', ') : s.Action || '',
                resource: Array.isArray(s.Resource) ? s.Resource.join(', ') : s.Resource || '',
                condition: s.Condition ? JSON.stringify(s.Condition, null, 2) : '',
              }))
            : [blankStatement()]
        );
      })
      .catch((err) => toast.error(err.userMessage || 'Could not load policy.'))
      .finally(() => setLoading(false));
  }, [isEdit, policyId, toast]);

  const updateStatement = (i, key, value) =>
    setStatements((list) => list.map((s, idx) => (idx === i ? { ...s, [key]: value } : s)));
  const addStatement = () => setStatements((list) => [...list, blankStatement()]);
  const removeStatement = (i) =>
    setStatements((list) => list.filter((_, idx) => idx !== i));

  const buildDocument = () => {
    if (rawMode) {
      const parsed = JSON.parse(rawText);
      if (!Array.isArray(parsed.Statement) || parsed.Statement.length === 0)
        throw new Error('Policy document must include a non-empty Statement array.');
      return parsed;
    }
    const valid = statements.filter((s) => s.action.trim() && s.resource.trim());
    if (!valid.length) throw new Error('Add at least one statement with an action and resource.');
    const Statement = valid.map((s) => {
      const toField = (v) =>
        v.includes(',') ? v.split(',').map((x) => x.trim()).filter(Boolean) : v.trim();
      const stmt = {
        Effect: s.effect,
        Action: toField(s.action),
        Resource: toField(s.resource),
      };
      if (s.sid.trim()) stmt.Sid = s.sid.trim();
      if (s.condition.trim()) {
        try {
          stmt.Condition = JSON.parse(s.condition);
        } catch {
          throw new Error('Condition must be valid JSON.');
        }
      }
      return stmt;
    });
    return { Version: version, Statement };
  };

  const save = async () => {
    setSaving(true);
    try {
      const policy_document = buildDocument();
      const payload = { policy_name: name, description, policy_document };
      if (isEdit) await pbacApi.updatePolicy(policyId, payload);
      else await pbacApi.createPolicy(payload);
      toast.success(`Policy ${isEdit ? 'updated' : 'created'}.`);
      navigate('/pbac/policies');
    } catch (err) {
      toast.error(err.message || err.userMessage || 'Could not save policy.');
    } finally {
      setSaving(false);
    }
  };

  const attach = async (e) => {
    e.preventDefault();
    try {
      await pbacApi.attachPolicyToUser({
        user_id: attachForm.user_id,
        policy_id: policyId,
        expires_at: attachForm.expires_at || null,
      });
      toast.success('Policy attached to user (PBAC).');
      setAttachOpen(false);
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach policy.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  const preview = (() => {
    try {
      return JSON.stringify(buildDocument(), null, 2);
    } catch {
      return '// fix validation errors to preview';
    }
  })();

  return (
    <div>
      <button
        onClick={() => navigate('/pbac/policies')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Policies
      </button>

      <PageHeader
        title={isEdit ? 'Edit policy' : 'New policy'}
        description="Define allow/deny statements evaluated by OPA."
        actions={
          isEdit ? (
            <Button variant="outline" onClick={() => setAttachOpen(true)}>
              <UserPlus className="h-4 w-4" /> Attach to user
            </Button>
          ) : null
        }
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="space-y-4 p-5">
            <Input label="Policy name" value={name} onChange={(e) => setName(e.target.value)} required />
            <Input label="Description" value={description} onChange={(e) => setDescription(e.target.value)} />

            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-ink-900">Statements</h3>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" onClick={() => setRawMode((m) => !m)}>
                  <Code2 className="h-4 w-4" /> {rawMode ? 'Form' : 'Raw JSON'}
                </Button>
                {!rawMode && (
                  <Button size="sm" onClick={addStatement}>
                    <Plus className="h-4 w-4" /> Add
                  </Button>
                )}
              </div>
            </div>

            {rawMode ? (
              <Textarea
                rows={16}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                className="font-mono text-xs"
                placeholder='{ "Version": "2025-01-01", "Statement": [ ... ] }'
              />
            ) : (
              <div className="space-y-3">
                {statements.map((s, i) => (
                  <div key={i} className="rounded-lg border border-slate-200 p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-400">Statement {i + 1}</span>
                      <button
                        type="button"
                        onClick={() => removeStatement(i)}
                        className="text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <Select value={s.effect} onChange={(e) => updateStatement(i, 'effect', e.target.value)}>
                        <option value="Allow">Allow</option>
                        <option value="Deny">Deny</option>
                      </Select>
                      <Input
                        label="Sid (optional)"
                        value={s.sid}
                        onChange={(e) => updateStatement(i, 'sid', e.target.value)}
                      />
                      <Input
                        label="Action"
                        value={s.action}
                        onChange={(e) => updateStatement(i, 'action', e.target.value)}
                        placeholder="iam:user:Read or iam:*"
                      />
                      <Input
                        label="Resource"
                        value={s.resource}
                        onChange={(e) => updateStatement(i, 'resource', e.target.value)}
                        placeholder="iam:user/* or *"
                      />
                      <div className="sm:col-span-2">
                        <Textarea
                          label="Condition (JSON, optional)"
                          rows={2}
                          value={s.condition}
                          onChange={(e) => updateStatement(i, 'condition', e.target.value)}
                          className="font-mono text-xs"
                          placeholder='{ "StringEquals": { "user.department": "engineering" } }'
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <Card className="h-fit p-5">
          <h3 className="text-sm font-semibold text-ink-900">Preview</h3>
          <p className="mb-2 text-xs text-slate-400">Generated policy document</p>
          <pre className="max-h-[60vh] overflow-auto rounded-lg bg-ink-900 p-3 text-xs text-emerald-200">
            {preview}
          </pre>
          <Button className="mt-4 w-full" onClick={save} loading={saving}>
            {isEdit ? 'Save changes' : 'Create policy'}
          </Button>
        </Card>
      </div>

      <Modal
        open={attachOpen}
        onClose={() => { setAttachOpen(false); setAttachForm({ user_id: '', expires_at: '' }); setDropdownOpen(false); setUserSearch(''); }}
        title="Attach policy to user"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setAttachOpen(false); setAttachForm({ user_id: '', expires_at: '' }); setDropdownOpen(false); setUserSearch(''); }}>Cancel</Button>
            <Button onClick={attach}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attach} className="space-y-4">
          {/* Professional user combobox: reuses identityApi.listUsers (same endpoint as
              UsersPage). Shows structured options with username, email, and status badge.
              Inline search filters the list. Selected value is the user_id UUID. */}
          <div className="w-full">
            <label className="label-base">User</label>
            {usersResource.loading ? (
              <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2.5">
                <Spinner className="h-4 w-4" />
                <span className="text-sm text-slate-500">Loading users…</span>
              </div>
            ) : usersResource.error ? (
              <p className="text-sm text-rose-600">Failed to load users: {usersResource.error}</p>
            ) : usersList.length === 0 ? (
              <p className="text-sm text-slate-500">No users found in this account.</p>
            ) : (
              <div ref={dropdownRef} className="relative">
                {/* Trigger button */}
                <button
                  type="button"
                  onClick={() => setDropdownOpen((o) => !o)}
                  className={`flex w-full items-center justify-between gap-2 rounded-lg border bg-white px-3 py-2.5 text-left text-sm transition hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-300 ${dropdownOpen ? 'border-brand-400 ring-2 ring-brand-300' : 'border-slate-200'}`}
                >
                  {selectedUser ? (
                    <span className="flex items-center gap-2">
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                        {selectedUser.username?.charAt(0)?.toUpperCase() || '?'}
                      </span>
                      <span className="font-medium text-ink-900">{selectedUser.username}</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-500">{selectedUser.email}</span>
                    </span>
                  ) : (
                    <span className="text-slate-400">Choose a user…</span>
                  )}
                  <ChevronDown className={`h-4 w-4 shrink-0 text-slate-400 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown panel */}
                {dropdownOpen && (
                  <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
                    {/* Search input */}
                    <div className="border-b border-slate-100 p-2">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <input
                          ref={searchInputRef}
                          type="text"
                          placeholder="Search by name or email…"
                          value={userSearch}
                          onChange={(e) => setUserSearch(e.target.value)}
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-8 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-300"
                        />
                      </div>
                    </div>

                    {/* User list */}
                    <div className="max-h-60 overflow-y-auto p-1">
                      {filteredUsers.length === 0 ? (
                        <p className="px-3 py-4 text-center text-sm text-slate-400">No users match your search.</p>
                      ) : (
                        filteredUsers.map((u) => {
                          const isSelected = u.user_id === attachForm.user_id;
                          return (
                            <button
                              key={u.user_id}
                              type="button"
                              onClick={() => selectUser(u.user_id)}
                              className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition ${isSelected ? 'bg-brand-50' : 'hover:bg-slate-50'}`}
                            >
                              <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                                {u.username?.charAt(0)?.toUpperCase() || '?'}
                              </span>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="truncate text-sm font-medium text-ink-900">{u.username}</span>
                                  <span className={`inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset ${
                                    u.status === 'ACTIVE'
                                      ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20'
                                      : 'bg-slate-100 text-slate-600 ring-slate-500/20'
                                  }`}>
                                    {u.status}
                                  </span>
                                </div>
                                <p className="truncate text-xs text-slate-400">{u.email}</p>
                              </div>
                              {isSelected && <Check className="h-4 w-4 shrink-0 text-brand-600" />}
                            </button>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
            <p className="mt-1 text-xs text-slate-400">Select a user to attach this policy to.</p>
          </div>
          <Input label="Expires at (optional)" type="datetime-local" value={attachForm.expires_at} onChange={(e) => setAttachForm((f) => ({ ...f, expires_at: e.target.value }))} />
          <p className="text-xs text-slate-400">
            Directly attaches this policy to a user (PBAC), independent of roles.
          </p>
        </form>
      </Modal>
    </div>
  );
}
