import { useState } from 'react';
import { GitBranch, ShieldCheck, ShieldX } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea } from '../../components/ui/primitives.jsx';
import { UserPicker } from '../../components/common/EntityPickers.jsx';
import { classNames } from '../../utils/format.js';

export default function AuthzCheckPage() {
  const toast = useToast();
  const [form, setForm] = useState({
    user_id: '',
    action: '',
    resource_arn: '',
    resource_attributes: '',
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const run = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    try {
      let attrs = {};
      if (form.resource_attributes.trim()) {
        try {
          attrs = JSON.parse(form.resource_attributes);
        } catch {
          toast.error('Resource attributes must be valid JSON.');
          setLoading(false);
          return;
        }
      }
      const res = await pbacApi.check({
        user_id: form.user_id,
        action: form.action,
        resource_arn: form.resource_arn,
        resource_attributes: attrs,
      });
      setResult(res);
    } catch (err) {
      toast.error(err.userMessage || 'Decision check failed.');
    } finally {
      setLoading(false);
    }
  };

  const allowed = result?.allowed ?? result?.decision ?? result?.result;

  return (
    <div>
      <PageHeader
        title="Decision Simulator"
        description="Test the PDP (RBAC + PBAC) for a given principal, action and resource."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <form onSubmit={run} className="space-y-4">
            <UserPicker
              value={form.user_id}
              onChange={(id) => setForm((f) => ({ ...f, user_id: id || '' }))}
              label="Principal"
              required
              hint="Resolved against the tenant directory — no UUIDs to copy."
            />
            <Input label="Action" value={form.action} onChange={set('action')} placeholder="iam:user:Read" required />
            <Input label="Resource ARN" value={form.resource_arn} onChange={set('resource_arn')} placeholder="iam:user/*" required />
            <Textarea
              label="Resource attributes (JSON, optional)"
              rows={4}
              value={form.resource_attributes}
              onChange={set('resource_attributes')}
              className="font-mono text-xs"
              placeholder='{ "department": "engineering" }'
            />
            <Button type="submit" loading={loading} className="w-full">
              <GitBranch className="h-4 w-4" /> Evaluate
            </Button>
          </form>
        </Card>

        <Card className="flex flex-col p-5">
          <h3 className="text-sm font-semibold text-ink-900">Result</h3>
          {result == null ? (
            <div className="flex flex-1 flex-col items-center justify-center text-center text-sm text-slate-400">
              <GitBranch className="mb-2 h-8 w-8 text-slate-300" />
              Run a simulation to see the allow/deny decision.
            </div>
          ) : (
            <div className="flex flex-1 flex-col">
              <div
                className={classNames(
                  'flex items-center gap-3 rounded-xl p-4',
                  allowed ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                )}
              >
                {allowed ? <ShieldCheck className="h-6 w-6" /> : <ShieldX className="h-6 w-6" />}
                <div>
                  <p className="text-sm font-semibold">
                    {allowed ? 'ALLOW' : 'DENY'}
                  </p>
                  <p className="text-xs opacity-80">OPA policy decision</p>
                </div>
              </div>
              <pre className="mt-4 flex-1 overflow-auto rounded-lg bg-ink-900 p-3 text-xs text-emerald-200">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
