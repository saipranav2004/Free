import { useState } from 'react';
import { Boxes, Plus, Trash2 } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, StatusBadge, EmptyState, Badge } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';

export default function ResourcesPage() {
  const toast = useToast();
  const resources = useResource(() => pbacApi.listResources(), []);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', type: '', arn: '', target_url: '' });
  const [saving, setSaving] = useState(false);

  const register = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await pbacApi.registerResource(form);
      toast.success('Resource registered.');
      setOpen(false);
      setForm({ name: '', type: '', arn: '', target_url: '' });
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not register resource.');
    } finally {
      setSaving(false);
    }
  };

  const disable = async (id) => {
    try {
      await pbacApi.disableResource(id);
      toast.success('Resource disabled.');
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable resource.');
    }
  };

  // Tolerant of both a raw array and an inferred { resources: [...] } envelope.
  const data = Array.isArray(resources.data) ? resources.data : (resources.data?.resources || []);

  return (
    <div>
      <PageHeader
        title="Resources (ABAC)"
        description="Register protected resources for attribute-based evaluation."
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Register resource
          </Button>
        }
      />

      {resources.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          icon={Boxes}
          title="No resources"
          description="Register a resource (e.g. an app or dataset) to use in policies."
          action={<Button onClick={() => setOpen(true)}>Register resource</Button>}
        />
      ) : (
        <Card>
          <ul className="divide-y divide-slate-100">
            {data.map((r) => (
              <li key={r.resource_id} className="flex items-center justify-between px-5 py-4">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-ink-900">{r.resource_name}</p>
                    <Badge tone="slate">{r.resource_type}</Badge>
                  </div>
                  <p className="font-mono text-xs text-slate-500">{r.resource_arn}</p>
                </div>
                <div className="flex items-center gap-3">
                  <StatusBadge status={r.is_active ? 'ACTIVE' : 'DISABLED'} />
                  <Button variant="ghost" size="sm" onClick={() => disable(r.resource_id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Register resource"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={register} loading={saving}>Register</Button>
          </>
        }
      >
        <form onSubmit={register} className="space-y-4">
          <Input label="Name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
          <Input label="Type" value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))} placeholder="application | dataset" required />
          <Input label="ARN" value={form.arn} onChange={(e) => setForm((f) => ({ ...f, arn: e.target.value }))} placeholder="iam:app/my-app" required />
          <Input label="Target URL" value={form.target_url} onChange={(e) => setForm((f) => ({ ...f, target_url: e.target.value }))} placeholder="https://…" required />
        </form>
      </Modal>
    </div>
  );
}
