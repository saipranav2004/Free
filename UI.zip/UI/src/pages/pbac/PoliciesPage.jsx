import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileLock2, Plus, Trash2, Search, Edit3 } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Spinner, StatusBadge, Badge, EmptyState } from '../../components/ui/primitives.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

/**
 * Premium Enterprise Policies Page.
 *
 * Enterprise refinements:
 *  - Inline search/filter for quick policy lookup
 *  - Better visual hierarchy with policy type badges
 *  - Premium empty states with actionable CTAs
 *  - Professional row design with icons and status
 */
export default function PoliciesPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const policies = useResource(() => pbacApi.listPolicies(), []);
  const [disableId, setDisableId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');

  const disable = async () => {
    setBusy(true);
    try {
      await pbacApi.disablePolicy(disableId);
      toast.success('Policy disabled.');
      policies.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable policy.');
    } finally {
      setBusy(false);
      setDisableId(null);
    }
  };

  const data = Array.isArray(policies.data) ? policies.data : (policies.data?.policies || []);

  // Enterprise: inline search filter
  const filteredPolicies = data.filter((p) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (p.policy_name && p.policy_name.toLowerCase().includes(q)) ||
      (p.description && p.description.toLowerCase().includes(q))
    );
  });

  return (
    <div>
      <PageHeader
        title="Policies (PBAC)"
        description="Attribute-based policies evaluated by OPA."
        icon={<FileLock2 className="h-5 w-5" />}
        actions={
          <Button onClick={() => navigate('/pbac/policies/new')}>
            <Plus className="h-4 w-4" /> New policy
          </Button>
        }
      />

      {/* Enterprise: inline search bar */}
      {data.length > 3 && (
        <div className="mb-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search policies…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-ink-900 placeholder-slate-400 transition focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-200"
            />
          </div>
        </div>
      )}

      {policies.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          icon={FileLock2}
          title="No policies yet"
          description="Create a policy to start expressing fine-grained access rules."
          action={<Button onClick={() => navigate('/pbac/policies/new')}>New policy</Button>}
        />
      ) : filteredPolicies.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <p className="text-sm text-slate-500">No policies match "{search}"</p>
          <Button variant="ghost" size="sm" className="mt-2" onClick={() => setSearch('')}>Clear search</Button>
        </div>
      ) : (
        <Card>
          <ul className="divide-y divide-slate-100">
            {filteredPolicies.map((p) => (
              <li key={p.policy_id}>
                <div className="flex items-center justify-between px-5 py-4 hover:bg-slate-50 transition-colors">
                  <button
                    onClick={() => navigate(`/pbac/policies/${p.policy_id}`)}
                    className="flex flex-1 items-center gap-3 text-left"
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                      <FileLock2 className="h-5 w-5" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-ink-900">{p.policy_name}</p>
                        {p.is_system_policy && <Badge tone="brand">SYSTEM</Badge>}
                        <StatusBadge status={p.status} />
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{p.description || 'No description'}</p>
                    </div>
                  </button>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`/pbac/policies/${p.policy_id}`)}
                      className="text-slate-400 hover:text-brand-600 hover:bg-brand-50"
                    >
                      <Edit3 className="h-4 w-4" /> Edit
                    </Button>
                    {!p.is_system_policy && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setDisableId(p.policy_id)}
                        className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <ConfirmDialog
        open={!!disableId}
        onClose={() => setDisableId(null)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Disable policy"
        message="Active policy documents will no longer be evaluated by the PDP."
      />
    </div>
  );
}
