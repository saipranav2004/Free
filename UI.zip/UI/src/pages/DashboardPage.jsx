/**
 * DashboardPage — Enterprise-grade IAM control center dashboard.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * DESIGN DECISIONS (Research: Azure Entra ID, Okta, CyberArk, SailPoint)
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * 1. COMPACT SECURITY POSTURE — inline health bar with status chips
 *    (CyberArk / BeyondTrust pattern — dense, not card-heavy)
 *
 * 2. OPERATIONAL METRICS — compact stat cards with subtle icons and
 *    action links (Okta / Google Admin Console pattern)
 *
 * 3. RISK SIGNALS — actionable risk-based cards instead of generic cards
 *
 * 4. RECENT ACTIVITY — timeline-style feed with severity indicators
 *
 * 5. ACCOUNT CONTEXT — compact sidebar card
 *
 * QUICK ACTIONS SECTION REMOVED per requirements.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * CONSTRAINTS
 * ═══════════════════════════════════════════════════════════════════════════════
 * - Frontend only. Backend folder is strictly for studying APIs.
 * - No git commands.
 * - Existing color palette preserved.
 * - Production-grade, maintainable code.
 */
import { useNavigate } from 'react-router-dom';
import { useMemo } from 'react';
import {
  Users,
  UsersRound,
  ShieldCheck,
  FileLock2,
  KeyRound,
  AlertTriangle,
  ArrowRight,
  Clock,
  Fingerprint,
  Activity,
  Shield,
  Lock,
  CheckCircle2,
  XCircle,
  UserCog,
  Layers,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { rbacApi } from '../lib/api/rbac.js';
import { pbacApi } from '../lib/api/pbac.js';
import { identityApi } from '../lib/api/identity.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { identityAuditApi } from '../lib/api/identityAudit.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import { Card, Button, Spinner, Badge } from '../components/ui/primitives.jsx';
import { isAdmin } from '../utils/permissions.js';
import { formatDateTime, classNames } from '../utils/format.js';

// ═══════════════════════════════════════════════════════════════════════════════
// Security Posture Bar — Compact inline health indicator
// Inspired by CyberArk / SailPoint posture dashboards
// ═══════════════════════════════════════════════════════════════════════════════
function SecurityPostureBar({ user, sessionsData, roles, groups, policies }) {
  const navigate = useNavigate();

  const healthDimensions = useMemo(() => {
    const activeSessions = Array.isArray(sessionsData) ? sessionsData.length : 0;
    const rolesCount = roles?.roles?.length ?? 0;
    const groupsCount = groups?.groups?.length ?? 0;
    const policiesCount = policies?.length ?? 0;

    return [
      {
        label: 'MFA',
        status: !!user?.mfa_enabled,
        description: user?.mfa_enabled ? 'Enabled' : 'Not enabled',
        action: user?.mfa_enabled ? null : '/security/mfa',
      },
      {
        label: 'Sessions',
        status: activeSessions > 0 && activeSessions < 10,
        description: `${activeSessions} active`,
        action: '/security/sessions',
      },
      {
        label: 'RBAC',
        status: rolesCount > 0 && groupsCount > 0,
        description: `${rolesCount}R · ${groupsCount}G`,
        action: '/rbac/roles',
      },
      {
        label: 'PBAC',
        status: policiesCount > 0,
        description: `${policiesCount} policies`,
        action: '/pbac/policies',
      },
    ];
  }, [user, sessionsData, roles, groups, policies]);

  const passedCount = healthDimensions.filter(d => d.status).length;
  const totalCount = healthDimensions.length;
  const healthScore = totalCount > 0 ? Math.round((passedCount / totalCount) * 100) : 0;
  const healthLevel = healthScore >= 75 ? 'good' : healthScore >= 50 ? 'moderate' : 'critical';

  const scoreColors = {
    good: 'text-emerald-600',
    moderate: 'text-amber-600',
    critical: 'text-rose-600',
  };

  const barColors = {
    good: 'bg-emerald-500',
    moderate: 'bg-amber-500',
    critical: 'bg-rose-500',
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className={classNames(
            'flex h-8 w-8 items-center justify-center rounded-lg',
            healthLevel === 'good' ? 'bg-emerald-50' : healthLevel === 'moderate' ? 'bg-amber-50' : 'bg-rose-50'
          )}>
            <ShieldCheck className={classNames('h-4 w-4', scoreColors[healthLevel])} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-ink-900">Security Posture</h3>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className={classNames('text-lg font-bold', scoreColors[healthLevel])}>
            {healthScore}%
          </span>
          <Badge tone={healthLevel === 'good' ? 'green' : healthLevel === 'moderate' ? 'amber' : 'red'}>
            {healthLevel === 'good' ? 'Healthy' : healthLevel === 'moderate' ? 'Moderate' : 'Critical'}
          </Badge>
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-1.5 w-full rounded-full bg-slate-100 mb-3">
        <div
          className={classNames('h-1.5 rounded-full transition-all duration-500', barColors[healthLevel])}
          style={{ width: `${healthScore}%` }}
        />
      </div>

      {/* Compact dimension chips */}
      <div className="flex flex-wrap gap-2">
        {healthDimensions.map((dim) => (
          <button
            key={dim.label}
            onClick={() => dim.action && navigate(dim.action)}
            className={classNames(
              'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium transition',
              dim.status
                ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100',
              dim.action ? 'cursor-pointer' : 'cursor-default'
            )}
          >
            {dim.status ? (
              <CheckCircle2 className="h-3 w-3" />
            ) : (
              <XCircle className="h-3 w-3" />
            )}
            {dim.label}
            <span className="text-[10px] opacity-70">{dim.description}</span>
          </button>
        ))}
      </div>

      {healthLevel !== 'good' && (
        <button
          onClick={() => navigate('/security/mfa')}
          className="mt-3 w-full rounded-lg border border-slate-200 bg-white py-2 text-xs font-medium text-brand-600 transition hover:bg-brand-50 hover:border-brand-200"
        >
          Improve Security Posture
        </button>
      )}
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Operational Metrics — Compact stat cards with actionable links
// Okta / Google Admin Console pattern
// ═══════════════════════════════════════════════════════════════════════════════
function OperationalMetrics({ totals, sessionsData }) {
  const navigate = useNavigate();
  const activeSessions = Array.isArray(sessionsData) ? sessionsData.length : 0;

  const metrics = [
    {
      label: 'Users',
      value: totals.users,
      icon: Users,
      tone: 'brand',
      action: '/identity/users',
    },
    {
      label: 'Sessions',
      value: activeSessions,
      icon: KeyRound,
      tone: 'green',
      action: '/security/sessions',
    },
    {
      label: 'Roles',
      value: totals.roles,
      icon: ShieldCheck,
      tone: 'amber',
      action: '/rbac/roles',
    },
    {
      label: 'Policies',
      value: totals.policies,
      icon: FileLock2,
      tone: 'slate',
      action: '/pbac/policies',
    },
    {
      label: 'Groups',
      value: totals.groups,
      icon: UsersRound,
      tone: 'sky',
      action: '/rbac/groups',
    },
    {
      label: 'Delegations',
      value: totals.delegations,
      icon: UserCog,
      tone: 'brand',
      action: '/identity/delegations',
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      {metrics.map((metric) => (
        <button
          key={metric.label}
          onClick={() => navigate(metric.action)}
          className={classNames(
            'group text-left rounded-xl border border-slate-100 bg-white p-4 transition-all duration-200',
            'hover:shadow-md hover:border-brand-200 hover:-translate-y-0.5'
          )}
        >
          <div className={classNames(
            'flex h-8 w-8 items-center justify-center rounded-lg mb-2 transition',
            metric.tone === 'brand' && 'bg-brand-50 text-brand-600 group-hover:bg-brand-100',
            metric.tone === 'green' && 'bg-emerald-50 text-emerald-600 group-hover:bg-emerald-100',
            metric.tone === 'amber' && 'bg-amber-50 text-amber-600 group-hover:bg-amber-100',
            metric.tone === 'slate' && 'bg-slate-100 text-slate-600 group-hover:bg-slate-200',
            metric.tone === 'sky' && 'bg-sky-50 text-sky-600 group-hover:bg-sky-100',
          )}>
            <metric.icon className="h-4 w-4" />
          </div>
          <div className="text-xl font-bold text-ink-900">
            {metric.value?.toLocaleString?.() ?? metric.value ?? '—'}
          </div>
          <div className="text-xs text-slate-500 mt-0.5">{metric.label}</div>
        </button>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Risk Signals — Actionable security signals for admins
// Azure Entra ID risk-based pattern
// ═══════════════════════════════════════════════════════════════════════════════
function RiskSignals({ user, sessionsData, totals }) {
  const navigate = useNavigate();
  const activeSessions = Array.isArray(sessionsData) ? sessionsData.length : 0;

  const signals = useMemo(() => {
    const items = [];

    if (!user?.mfa_enabled) {
      items.push({
        severity: 'high',
        title: 'MFA not enabled',
        description: 'Your account is protected only by a password.',
        action: '/security/mfa',
        actionLabel: 'Enable MFA',
      });
    }

    if (activeSessions > 5) {
      items.push({
        severity: 'medium',
        title: `${activeSessions} active sessions`,
        description: 'Review and revoke unrecognized sessions.',
        action: '/security/sessions',
        actionLabel: 'Review sessions',
      });
    }

    if (totals.roles === 0 && totals.groups === 0) {
      items.push({
        severity: 'medium',
        title: 'No RBAC configured',
        description: 'Roles and groups are not set up yet.',
        action: '/rbac/roles',
        actionLabel: 'Configure RBAC',
      });
    }

    if (totals.policies === 0) {
      items.push({
        severity: 'low',
        title: 'No PBAC policies',
        description: 'Create policies for fine-grained access control.',
        action: '/pbac/policies',
        actionLabel: 'Create policy',
      });
    }

    return items;
  }, [user, sessionsData, totals]);

  if (signals.length === 0) return null;

  const severityConfig = {
    high: { bg: 'bg-rose-50', border: 'border-rose-200', icon: 'text-rose-600', dot: 'bg-rose-500' },
    medium: { bg: 'bg-amber-50', border: 'border-amber-200', icon: 'text-amber-600', dot: 'bg-amber-500' },
    low: { bg: 'bg-sky-50', border: 'border-sky-200', icon: 'text-sky-600', dot: 'bg-sky-500' },
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-50">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
          </div>
          <h3 className="text-sm font-semibold text-ink-900">Risk Signals</h3>
        </div>
        <Badge tone="amber">{signals.length}</Badge>
      </div>

      <div className="space-y-2">
        {signals.map((signal, i) => {
          const cfg = severityConfig[signal.severity];
          return (
            <div
              key={i}
              className={classNames('flex items-center gap-3 rounded-lg border p-3', cfg.bg, cfg.border)}
            >
              <div className={classNames('h-2 w-2 shrink-0 rounded-full', cfg.dot)} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-ink-900">{signal.title}</p>
                <p className="text-xs text-slate-500">{signal.description}</p>
              </div>
              <button
                onClick={() => navigate(signal.action)}
                className="shrink-0 text-xs font-medium text-brand-600 hover:text-brand-700 transition"
              >
                {signal.actionLabel}
              </button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Recent Activity — Timeline-style security events feed
// ═══════════════════════════════════════════════════════════════════════════════
function RecentActivitySection() {
  const navigate = useNavigate();

  const logsFetcher = () => identityAuditApi.list({
    page: 1,
    page_size: 6,
  });
  const logs = useResource(logsFetcher, []);

  const rawLogs = logs?.data;
  const items = Array.isArray(rawLogs)
    ? rawLogs
    : rawLogs?.items || rawLogs?.logs || rawLogs?.data || [];

  const getSeverity = (event) => {
    const decision = String(event?.decision || '').toUpperCase();
    const status = String(event?.status || '').toUpperCase();

    if (decision === 'DENY' || status === 'FAILURE') {
      return { color: 'bg-rose-500', label: 'Denied', icon: XCircle };
    }
    if (decision === 'ALLOW' || status === 'SUCCESS') {
      return { color: 'bg-emerald-500', label: 'Allowed', icon: CheckCircle2 };
    }
    return { color: 'bg-slate-400', label: 'Info', icon: Activity };
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-50">
            <Activity className="h-4 w-4 text-brand-600" />
          </div>
          <h3 className="text-sm font-semibold text-ink-900">Recent Activity</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/pam')}
        >
          View all <ArrowRight className="h-3 w-3" />
        </Button>
      </div>

      {logs.loading ? (
        <div className="flex items-center justify-center py-8">
          <Spinner className="h-5 w-5" />
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-8">
          <Activity className="h-6 w-6 text-slate-300 mx-auto mb-2" />
          <p className="text-xs text-slate-500">No recent activity</p>
        </div>
      ) : (
        <div className="space-y-1">
          {items.slice(0, 6).map((event, i) => {
            const sev = getSeverity(event);
            const SevIcon = sev.icon;
            return (
              <button
                key={event?.audit_id || i}
                onClick={() => navigate('/pam')}
                className="w-full flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-left hover:bg-slate-50 transition-colors"
              >
                <div className={classNames(
                  'flex h-6 w-6 shrink-0 items-center justify-center rounded-full',
                  sev.color === 'bg-rose-500' ? 'bg-rose-100 text-rose-600' :
                  sev.color === 'bg-emerald-500' ? 'bg-emerald-100 text-emerald-600' :
                  'bg-slate-100 text-slate-600'
                )}>
                  <SevIcon className="h-3 w-3" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-ink-900 truncate">
                    {event?.action || event?.event_type || 'Security event'}
                  </p>
                  <p className="text-[10px] text-slate-400 truncate">
                    {event?.username || event?.user_id || 'System'}
                    {event?.resource_name ? ` · ${event.resource_name}` : ''}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[10px] text-slate-400">
                    {formatDateTime(event?.created_at)}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Account Overview — Compact identity card
// ═══════════════════════════════════════════════════════════════════════════════
function AccountOverviewCard({ user, sessionsData }) {
  const activeSessions = Array.isArray(sessionsData) ? sessionsData.length : 0;

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2.5 mb-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100">
          <Fingerprint className="h-4 w-4 text-slate-600" />
        </div>
        <h3 className="text-sm font-semibold text-ink-900">Account</h3>
      </div>

      <div className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-50 mb-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-xs font-semibold text-white shrink-0">
          {(user?.username || user?.email || 'U').slice(0, 2).toUpperCase()}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-ink-900 truncate">{user?.username || '—'}</p>
          <p className="text-[11px] text-slate-500 truncate">{user?.email || '—'}</p>
        </div>
        <Badge tone={isAdmin(user) ? 'brand' : 'slate'}>
          {isAdmin(user) ? 'Admin' : user?.account_type || 'User'}
        </Badge>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Lock className="h-3 w-3" /> MFA
          </span>
          <Badge tone={user?.mfa_enabled ? 'green' : 'amber'}>
            {user?.mfa_enabled ? 'Enabled' : 'Disabled'}
          </Badge>
        </div>

        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500 flex items-center gap-1.5">
            <KeyRound className="h-3 w-3" /> Sessions
          </span>
          <span className="font-medium text-ink-900">{activeSessions}</span>
        </div>

        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Clock className="h-3 w-3" /> Last login
          </span>
          <span className="font-medium text-ink-900">{formatDateTime(user?.last_login_at)}</span>
        </div>
      </div>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Quick Links — Compact navigation shortcuts
// ═══════════════════════════════════════════════════════════════════════════════
function QuickLinksCard() {
  const navigate = useNavigate();

  const links = [
    { label: 'Users', icon: Users, action: '/identity/users' },
    { label: 'Roles', icon: ShieldCheck, action: '/rbac/roles' },
    { label: 'Policies', icon: FileLock2, action: '/pbac/policies' },
    { label: 'Groups', icon: UsersRound, action: '/rbac/groups' },
    { label: 'Resources', icon: Layers, action: '/pbac/resources' },
    { label: 'Sessions', icon: KeyRound, action: '/security/sessions' },
  ];

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2.5 mb-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100">
          <Layers className="h-4 w-4 text-slate-600" />
        </div>
        <h3 className="text-sm font-semibold text-ink-900">Navigate</h3>
      </div>

      <div className="grid grid-cols-3 gap-1.5">
        {links.map((link) => (
          <button
            key={link.label}
            onClick={() => navigate(link.action)}
            className="flex flex-col items-center gap-1 rounded-lg p-2.5 text-center transition hover:bg-slate-50"
          >
            <link.icon className="h-4 w-4 text-slate-500" />
            <span className="text-[11px] font-medium text-slate-600">{link.label}</span>
          </button>
        ))}
      </div>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main Dashboard Page
// ═══════════════════════════════════════════════════════════════════════════════
export default function DashboardPage() {
  const { user, accountId } = useAuth();
  const navigate = useNavigate();

  // Fetch all required data
  const groups = useResource(() => rbacApi.listGroups(), []);
  const roles = useResource(() => rbacApi.listRoles(), []);
  const policies = useResource(() => pbacApi.listPolicies(), []);
  const users = useResource(
    () =>
      accountId
        ? identityApi.listUsers({ account_id: accountId, per_page: 1 })
        : Promise.resolve({ users: [], pagination: { total: 0 } }),
    [accountId]
  );
  const sessions = useResource(() => sessionsApi.list(), []);
  const delegations = useResource(() => identityApi.listDelegations(), []);

  const loading = groups.loading || roles.loading || policies.loading;

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  const delegationsData = delegations.data?.delegations || delegations.data || [];

  const totals = {
    users: users.data?.pagination?.total ?? '—',
    groups: groups.data?.groups?.length ?? 0,
    roles: roles.data?.roles?.length ?? 0,
    policies: policies.data?.length ?? 0,
    delegations: delegationsData.length,
  };

  const admin = isAdmin(user);
  const sessionsLoaded = !sessions.loading && !sessions.error;
  const sessionsData = sessionsLoaded ? sessions.data : null;

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <PageHeader
        title={`Welcome back, ${user?.username || 'Admin'}`}
        description="Your enterprise identity & access management control center."
        actions={
          admin ? (
            <Button onClick={() => navigate('/identity/users')}>
              <Users className="h-4 w-4" /> Manage Users
            </Button>
          ) : null
        }
      />

      {/* MFA Warning Banner */}
      {!user?.mfa_enabled && (
        <Card className="flex items-center gap-4 border-amber-200 bg-gradient-to-r from-amber-50 to-white p-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-100 shrink-0">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-amber-900">Security Alert</p>
            <p className="text-xs text-amber-700">
              Multi-factor authentication is not enabled. Your account is vulnerable to credential-based attacks.
            </p>
          </div>
          <Button variant="primary" size="sm" onClick={() => navigate('/security/mfa')}>
            Enable MFA
          </Button>
        </Card>
      )}

      {/* Row 1: Security Posture (compact) + Account + Navigate */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        <div className="lg:col-span-6">
          <SecurityPostureBar
            user={user}
            sessionsData={sessionsData}
            roles={roles.data}
            groups={groups.data}
            policies={policies.data}
          />
        </div>
        <div className="lg:col-span-3">
          <AccountOverviewCard user={user} sessionsData={sessionsData} />
        </div>
        <div className="lg:col-span-3">
          <QuickLinksCard />
        </div>
      </div>

      {/* Row 2: Operational Metrics — compact stat grid */}
      <div>
        <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Overview</h2>
        <OperationalMetrics totals={totals} sessionsData={sessionsData} />
      </div>

      {/* Row 3: Risk Signals + Recent Activity */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <div className="lg:col-span-4">
          <RiskSignals user={user} sessionsData={sessionsData} totals={totals} />
        </div>
        <div className="lg:col-span-8">
          <RecentActivitySection />
        </div>
      </div>
    </div>
  );
}
