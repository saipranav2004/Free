/**
 * DashboardPage — the IAM control centre landing view.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * INFORMATION ARCHITECTURE
 * ═══════════════════════════════════════════════════════════════════════════
 * Enterprise identity consoles answer four questions, in this order:
 *
 *   1. "Is my tenant secure right now?"      → Security posture (scored)
 *   2. "What do I have to fix?"              → Attention required (ranked)
 *   3. "How big is my access surface?"       → Footprint KPIs
 *   4. "What just happened?"                 → Recent authorisation activity
 *
 * So the page reads top-left → down: posture and remediation share the fold,
 * the KPI strip quantifies the estate below it, and the activity feed plus
 * account context close the page. Nothing here is decorative: the previous
 * "Navigate" tile duplicated the sidebar and has been removed, and the
 * decorative clock is gone. Quick Actions stays removed, per requirements.
 *
 * Frontend only — every number comes from an existing API via useResource.
 * ═══════════════════════════════════════════════════════════════════════════
 */
import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, ShieldCheck, FileLock2, KeyRound, ArrowRight, Clock,
  Activity, Lock, CheckCircle2, XCircle, RefreshCw, Fingerprint,
  ChevronRight, ShieldAlert, Gauge, Layers, PieChart,
  // UsersRound (Groups) and UserCog (Delegations) are unused while those
  // surfaces are commented out — restore them with the tiles below.
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { rbacApi } from '../lib/api/rbac.js';
import { pbacApi } from '../lib/api/pbac.js';
import { identityApi } from '../lib/api/identity.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { identityAuditApi } from '../lib/api/identityAudit.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import {
  Panel, Button, Badge, StatCard, Skeleton, InlineAlert, MetricRow, IconButton,
  RankBar,
} from '../components/ui/primitives.jsx';
import { accountTypeDisplayLabel, isAdminAccountType } from '../utils/permissions.js';
import { formatDateTime, formatRelative, classNames, extractList } from '../utils/format.js';

/* ── Posture model ─────────────────────────────────────────────────────────── */

function usePosture({ user, sessions, roles, policies }) {
  return useMemo(() => {
    /* Bug fix — "0 roles" under Role-Based Access Control.
       These counts read `roles.roles.length` directly, so any other envelope
       the list endpoint can answer with (a bare array, or { data: { roles } })
       collapsed to 0 while the Roles page — which uses extractList — showed the
       real rows. All three counts now go through the same helper. */
    const activeSessions = Array.isArray(sessions) ? sessions.length : 0;
    const rolesCount = extractList(roles, 'roles').length;
    // const groupsCount = extractList(groups, 'groups').length;   ← Groups withheld
    const policiesCount = extractList(policies, 'policies').length;

    const controls = [
      {
        id: 'mfa',
        label: 'Multi-factor authentication',
        detail: user?.mfa_enabled ? 'Enabled on your account' : 'Password is the only factor',
        pass: !!user?.mfa_enabled,
        to: '/security/mfa',
        cta: user?.mfa_enabled ? 'Manage' : 'Enable MFA',
      },
      {
        id: 'sessions',
        label: 'Session hygiene',
        detail:
          activeSessions === 0
            ? 'No active sessions reported'
            : `${activeSessions} active session${activeSessions === 1 ? '' : 's'}`,
        pass: activeSessions > 0 && activeSessions < 10,
        to: '/security/sessions',
        cta: 'Review',
      },
      {
        id: 'rbac',
        label: 'Role-based access control',
        /* Groups are temporarily withheld from the console, so the control is
           assessed on roles alone. Restore the group half with the pages. */
        detail: `${rolesCount} role${rolesCount === 1 ? '' : 's'} defined for this tenant`,
        pass: rolesCount > 0,
        to: '/rbac/roles',
        cta: 'Configure',
      },
      {
        id: 'pbac',
        label: 'Policy-based access control',
        detail: `${policiesCount} polic${policiesCount === 1 ? 'y' : 'ies'} evaluated by the PDP`,
        pass: policiesCount > 0,
        to: '/pbac/policies',
        cta: 'Configure',
      },
    ];

    const passed = controls.filter((c) => c.pass).length;
    const score = controls.length ? Math.round((passed / controls.length) * 100) : 0;
    const level = score >= 75 ? 'good' : score >= 50 ? 'moderate' : 'critical';

    return { controls, passed, total: controls.length, score, level, activeSessions };
  }, [user, sessions, roles, policies]);
}

const LEVEL_COPY = {
  good: { label: 'Healthy', tone: 'green', text: 'text-emerald-600', ring: '#059669' },
  moderate: { label: 'Needs attention', tone: 'amber', text: 'text-amber-600', ring: '#d97706' },
  critical: { label: 'Critical', tone: 'red', text: 'text-rose-600', ring: '#e11d48' },
};

/* ── Posture panel ─────────────────────────────────────────────────────────── */

function SecurityPosture({ posture, loading }) {
  const navigate = useNavigate();
  const cfg = LEVEL_COPY[posture.level];
  const circumference = 2 * Math.PI * 34;
  const dash = (posture.score / 100) * circumference;

  return (
    <Panel
      title="Security posture"
      subtitle="Baseline identity controls for this tenant"
      icon={Gauge}
      action={<Badge tone={cfg.tone} dot>{cfg.label}</Badge>}
      className="h-full"
    >
      <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
        {/* Score dial */}
        <div className="flex shrink-0 items-center gap-4">
          <div className="relative h-[84px] w-[84px]">
            <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
              <circle cx="40" cy="40" r="34" fill="none" stroke="#eef1f6" strokeWidth="8" />
              {!loading && (
                <circle
                  cx="40"
                  cy="40"
                  r="34"
                  fill="none"
                  stroke={cfg.ring}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${dash} ${circumference}`}
                  className="transition-[stroke-dasharray] duration-700 ease-out"
                />
              )}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              {loading ? (
                <Skeleton className="h-6 w-10" />
              ) : (
                <>
                  <span className={classNames('text-[20px] font-semibold leading-none tabular', cfg.text)}>
                    {posture.score}
                  </span>
                  <span className="mt-0.5 text-3xs font-medium uppercase tracking-[0.08em] text-slate-400">
                    score
                  </span>
                </>
              )}
            </div>
          </div>
          <div className="sm:hidden">
            <p className="text-[13px] font-semibold text-ink-900">
              {posture.passed} of {posture.total} controls passing
            </p>
          </div>
        </div>

        {/* Control checklist */}
        <ul className="min-w-0 flex-1 divide-y divide-line-soft">
          {posture.controls.map((control) => (
            <li key={control.id} className="flex items-center gap-3 py-2 first:pt-0 last:pb-0">
              {control.pass ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
              ) : (
                <XCircle className="h-4 w-4 shrink-0 text-rose-500" />
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium text-ink-900">{control.label}</p>
                <p className="truncate text-xs text-slate-500">{control.detail}</p>
              </div>
              <button
                type="button"
                onClick={() => navigate(control.to)}
                className="inline-flex shrink-0 items-center gap-0.5 rounded-md px-1.5 py-1 text-2xs font-semibold text-brand-700 transition-colors hover:bg-brand-50"
              >
                {control.cta}
                <ChevronRight className="h-3 w-3" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </Panel>
  );
}

/* ── Attention required ────────────────────────────────────────────────────── */

const SEVERITY = {
  high: { label: 'High', dot: 'bg-rose-500', badge: 'red' },
  medium: { label: 'Medium', dot: 'bg-amber-500', badge: 'amber' },
  low: { label: 'Low', dot: 'bg-sky-500', badge: 'sky' },
};

function AttentionPanel({ posture, totals, user }) {
  const navigate = useNavigate();

  const signals = useMemo(() => {
    const items = [];
    if (!user?.mfa_enabled) {
      items.push({
        severity: 'high',
        title: 'MFA not enabled for your account',
        description: 'Privileged administration without a second factor.',
        to: '/security/mfa',
        cta: 'Enable',
      });
    }
    if (posture.activeSessions > 5) {
      items.push({
        severity: 'medium',
        title: `${posture.activeSessions} concurrent sessions`,
        description: 'Revoke sessions you do not recognise.',
        to: '/security/sessions',
        cta: 'Review',
      });
    }
    if (totals.rolesCount === 0) {
      items.push({
        severity: 'medium',
        title: 'No RBAC structure configured',
        description: 'Access cannot be granted consistently without roles.',
        to: '/rbac/roles',
        cta: 'Configure',
      });
    }
    if (totals.policiesCount === 0) {
      items.push({
        severity: 'low',
        title: 'No PBAC policies defined',
        description: 'Fine-grained conditions are not being evaluated.',
        to: '/pbac/policies',
        cta: 'Create',
      });
    }
    // ── Delegation finding — TEMPORARILY COMMENTED OUT ──────────────────────
    // The Delegations page is withheld for now, so this signal has nowhere to
    // link. Restore it together with the page and its route.
    // if (totals.delegationsCount > 0) {
    //   items.push({
    //     severity: 'low',
    //     title: `${totals.delegationsCount} active delegation${totals.delegationsCount === 1 ? '' : 's'}`,
    //     description: 'Temporary access should be time-bound and reviewed.',
    //     to: '/identity/delegations',
    //     cta: 'Audit',
    //   });
    // }
    return items;
  }, [posture.activeSessions, totals, user]);

  return (
    <Panel
      title="Attention required"
      subtitle={signals.length ? 'Ranked by security impact' : undefined}
      icon={ShieldAlert}
      action={signals.length > 0 && <Badge tone="amber">{signals.length}</Badge>}
      className="h-full"
      flush={signals.length > 0}
    >
      {signals.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50">
            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
          </span>
          <p className="mt-3 text-[13px] font-semibold text-ink-900">No open findings</p>
          <p className="mt-1 max-w-[220px] text-xs text-slate-500">
            Baseline controls are configured for this tenant.
          </p>
        </div>
      ) : (
        <ul className="divide-y divide-line-soft">
          {signals.map((signal, i) => {
            const sev = SEVERITY[signal.severity];
            return (
              <li key={i} className="flex items-start gap-3 px-4 py-3 sm:px-5">
                <span className={classNames('mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full', sev.dot)} />
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium leading-snug text-ink-900">{signal.title}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-slate-500">{signal.description}</p>
                </div>
                <Button variant="ghost" size="xs" onClick={() => navigate(signal.to)}>
                  {signal.cta}
                  <ArrowRight className="h-3 w-3" />
                </Button>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

/* ── Standing access concentration ─────────────────────────────────────────
   "Which roles carry the standing access?" is the question an identity reviewer
   asks after posture. Entra ID and Okta both answer it on the landing page,
   because a single role holding most of the directory is the finding that
   matters. Derived entirely from the roles list already loaded — no new call. */
function RoleConcentration({ roles, loading }) {
  const navigate = useNavigate();

  const { rows, max, unassigned, totalRoles } = useMemo(() => {
    const list = extractList(roles, 'roles').map((r) => ({
      id: r.role_id,
      name: r.role_name || 'Unnamed role',
      type: r.role_type,
      count:
        r.assigned_users_count ??
        r.user_count ??
        r.users_count ??
        (Array.isArray(r.users) ? r.users.length : 0),
    }));
    const sorted = [...list].sort((a, b) => b.count - a.count);
    return {
      rows: sorted.slice(0, 5),
      max: sorted.length ? Math.max(...sorted.map((r) => r.count), 1) : 0,
      unassigned: list.filter((r) => !r.count).length,
      totalRoles: list.length,
    };
  }, [roles]);

  return (
    <Panel
      title="Standing access concentration"
      subtitle="Roles ranked by assigned principals"
      icon={Layers}
      action={
        <Button variant="ghost" size="sm" onClick={() => navigate('/rbac/roles')}>
          All roles
          <ArrowRight className="h-3.5 w-3.5" />
        </Button>
      }
      className="h-full"
      footer={
        totalRoles > 0 ? (
          <span className="flex items-center justify-between text-2xs text-slate-500">
            <span>
              {totalRoles} role{totalRoles === 1 ? '' : 's'} defined
            </span>
            <span className={unassigned ? 'text-amber-700' : undefined}>
              {unassigned
                ? `${unassigned} with no assignments`
                : 'Every role is in use'}
            </span>
          </span>
        ) : undefined
      }
    >
      {loading ? (
        <div className="space-y-3.5">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="space-y-1.5">
              <Skeleton className="h-3 w-40" />
              <Skeleton className="h-1 w-full" />
            </div>
          ))}
        </div>
      ) : rows.length === 0 ? (
        <div className="py-6 text-center">
          <p className="text-[13px] font-medium text-ink-800">No roles defined yet</p>
          <p className="mt-1 text-xs text-slate-500">
            Roles are how standing access is granted and reviewed.
          </p>
          <Button variant="secondary" size="sm" className="mt-3" onClick={() => navigate('/rbac/roles')}>
            Create a role
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {rows.map((row, i) => (
            <RankBar
              key={row.id || row.name}
              label={row.name}
              value={row.count}
              max={max}
              /* Only the leader takes colour — the rest stay neutral, so the
                 concentration reads instantly. */
              tone={i === 0 && row.count > 0 ? 'brand' : 'slate'}
              suffix={row.count === 1 ? ' user' : ' users'}
              leading={
                row.type === 'SYSTEM' ? (
                  <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-brand-500" />
                ) : (
                  <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-slate-300" />
                )
              }
              onClick={row.id ? () => navigate(`/rbac/roles/${row.id}`) : undefined}
              actionHint={`Open ${row.name}`}
            />
          ))}
        </div>
      )}
    </Panel>
  );
}

/* ── Directory composition ─────────────────────────────────────────────────
   Lifecycle state of the whole directory, read from the tenant-wide totals the
   list endpoint reports (per_page=1 + status filter → pagination.total), so the
   numbers describe the DIRECTORY and not the current page of a table. */
function DirectoryComposition({ total, active, disabled, loading }) {
  const navigate = useNavigate();
  const other = Math.max(0, (total || 0) - (active || 0) - (disabled || 0));
  const denominator = total || 0;
  const pct = (n) => (denominator > 0 ? Math.round((n / denominator) * 100) : 0);

  const segments = [
    { key: 'active', label: 'Active', value: active || 0, bar: 'bg-emerald-500', tone: 'green' },
    { key: 'disabled', label: 'Disabled', value: disabled || 0, bar: 'bg-slate-400', tone: 'slate' },
    { key: 'other', label: 'Other states', value: other, bar: 'bg-amber-400', tone: 'amber' },
  ];

  return (
    <Panel
      title="Directory composition"
      subtitle="Lifecycle state across the tenant"
      icon={PieChart}
      action={
        <Button variant="ghost" size="sm" onClick={() => navigate('/identity/users')}>
          Directory
          <ArrowRight className="h-3.5 w-3.5" />
        </Button>
      }
      className="h-full"
    >
      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-2 w-full rounded-full" />
          <Skeleton className="h-3 w-32" />
          <Skeleton className="h-3 w-40" />
        </div>
      ) : (
        <>
          <div className="flex items-end justify-between gap-4">
            <div>
              <p className="text-[26px] font-semibold leading-none text-ink-900 tabular">
                {denominator.toLocaleString()}
              </p>
              <p className="mt-1 text-2xs font-medium uppercase tracking-[0.07em] text-slate-500">
                Identities under management
              </p>
            </div>
            <Badge tone={pct(active) >= 80 ? 'green' : 'amber'} dot>
              {pct(active)}% active
            </Badge>
          </div>

          {/* Stacked share bar — one hairline object, no chart chrome. */}
          <div className="mt-4 flex h-2 w-full overflow-hidden rounded-full bg-slate-100">
            {segments.map((s) =>
              s.value > 0 ? (
                <span
                  key={s.key}
                  className={classNames('h-full', s.bar)}
                  style={{ width: `${Math.max(pct(s.value), 1)}%` }}
                  title={`${s.label}: ${s.value.toLocaleString()}`}
                />
              ) : null
            )}
          </div>

          <div className="mt-3 divide-y divide-line-soft">
            {segments.map((s) => (
              <MetricRow
                key={s.key}
                label={s.label}
                value={
                  <span className="flex items-center gap-2">
                    <span className="text-slate-400">{pct(s.value)}%</span>
                    <span>{s.value.toLocaleString()}</span>
                  </span>
                }
              />
            ))}
          </div>
        </>
      )}
    </Panel>
  );
}

/* ── Recent activity ──────────────────────────────────────────────────────── */

function decisionOf(event) {
  const decision = String(event?.decision || '').toUpperCase();
  const status = String(event?.status || '').toUpperCase();
  if (decision === 'DENY' || status === 'FAILURE') {
    return { tone: 'red', label: 'Denied', Icon: XCircle, wrap: 'bg-rose-50 text-rose-600' };
  }
  if (decision === 'ALLOW' || status === 'SUCCESS') {
    return { tone: 'green', label: 'Allowed', Icon: CheckCircle2, wrap: 'bg-emerald-50 text-emerald-600' };
  }
  return { tone: 'slate', label: 'Info', Icon: Activity, wrap: 'bg-slate-100 text-slate-500' };
}

function RecentActivity() {
  const navigate = useNavigate();
  /* The audit route is tenant-scoped and admin-gated: without `account_id` the
     backend cannot resolve the caller's role and refuses the request, which is
     what left this panel permanently empty. Same fix as PamPage. */
  const { accountId } = useAuth();
  const logs = useResource(
    () => identityAuditApi.list({ account_id: accountId || undefined, page: 1, page_size: 7 }),
    [accountId]
  );

  const raw = logs?.data;
  const items = Array.isArray(raw) ? raw : raw?.items || raw?.logs || raw?.data || [];

  return (
    <Panel
      title="Recent authorisation activity"
      icon={Activity}
      action={
        <>
          <IconButton
            icon={RefreshCw}
            title="Refresh activity"
            onClick={() => logs.reload?.()}
            loading={logs.loading}
          />
          <Button variant="ghost" size="sm" onClick={() => navigate('/pam/audit-logs')}>
            Open PAM
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </>
      }
      flush
      className="h-full"
    >
      {logs.loading ? (
        <div className="space-y-3 px-4 py-4 sm:px-5">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center gap-3">
              <Skeleton className="h-7 w-7 rounded-lg" />
              <Skeleton className="h-3.5 flex-1" />
              <Skeleton className="h-3 w-16" />
            </div>
          ))}
        </div>
      ) : logs.error ? (
        <div className="px-4 py-8 text-center sm:px-5">
          <p className="text-[13px] font-medium text-ink-800">Activity unavailable</p>
          <p className="mt-1 text-xs text-slate-500">{logs.error}</p>
          <Button variant="secondary" size="sm" className="mt-3" onClick={() => logs.reload?.()}>
            Retry
          </Button>
        </div>
      ) : items.length === 0 ? (
        <div className="px-4 py-10 text-center sm:px-5">
          <p className="text-[13px] font-medium text-ink-800">No recent events</p>
          <p className="mt-1 text-xs text-slate-500">
            Authorisation decisions will appear here as they are recorded.
          </p>
        </div>
      ) : (
        <ul className="divide-y divide-line-soft">
          {items.slice(0, 7).map((event, i) => {
            const d = decisionOf(event);
            return (
              <li key={event?.audit_id || i}>
                <button
                  type="button"
                  onClick={() => navigate('/pam/audit-logs')}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-slate-50 sm:px-5"
                >
                  <span
                    className={classNames(
                      'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg',
                      d.wrap
                    )}
                  >
                    <d.Icon className="h-3.5 w-3.5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate font-mono text-xs font-medium text-ink-900">
                        {event?.action || event?.event_type || 'security.event'}
                      </span>
                      <Badge tone={d.tone}>{d.label}</Badge>
                    </span>
                    <span className="mt-0.5 block truncate text-2xs text-slate-500">
                      {event?.username || event?.user_id || 'system'}
                      {event?.resource_name ? ` → ${event.resource_name}` : ''}
                    </span>
                  </span>
                  <span className="shrink-0 text-right text-2xs text-slate-400">
                    {formatDateTime(event?.created_at)}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

/* ── Account context ──────────────────────────────────────────────────────── */

function AccountPanel({ user, posture, accountId, accountType }) {
  const navigate = useNavigate();
  /* "Admin" / "User" comes from the same single source as the top navigation:
     `account_type` on GET /identity/accounts/<acc>/users/<id>. */
  const admin = isAdminAccountType(accountType);

  return (
    <Panel
      title="Your account"
      icon={Fingerprint}
      action={
        <Button variant="ghost" size="sm" onClick={() => navigate('/profile')}>
          Profile
        </Button>
      }
      className="h-full"
    >
      <div className="flex items-center gap-3 rounded-lg border border-line-soft bg-slate-50/70 p-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-2xs font-bold text-white">
          {(user?.username || user?.email || 'U').slice(0, 2).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold text-ink-900">{user?.username || '—'}</p>
          <p className="truncate text-2xs text-slate-500">{user?.email || '—'}</p>
        </div>
        <Badge tone={admin ? 'brand' : 'slate'}>{accountTypeDisplayLabel(accountType)}</Badge>
      </div>

      <div className="mt-3 divide-y divide-line-soft">
        <MetricRow
          label="MFA"
          icon={Lock}
          value={
            <Badge tone={user?.mfa_enabled ? 'green' : 'amber'} dot>
              {user?.mfa_enabled ? 'Enabled' : 'Disabled'}
            </Badge>
          }
        />
        <MetricRow label="Active sessions" icon={KeyRound} value={posture.activeSessions} />
        <MetricRow
          label="Last sign-in"
          icon={Clock}
          value={user?.last_login_at ? formatRelative(user.last_login_at) : '—'}
        />
        {accountId && (
          <MetricRow
            label="Tenant"
            icon={ShieldCheck}
            value={<span className="font-mono text-2xs text-ink-800">{accountId}</span>}
          />
        )}
      </div>
    </Panel>
  );
}

/* ── Page ─────────────────────────────────────────────────────────────────── */

export default function DashboardPage() {
  const { user, accountId, accountType } = useAuth();
  const navigate = useNavigate();

  /* ── Groups + Delegations — TEMPORARILY COMMENTED OUT ─────────────────────
     Both pages are withheld, so the dashboard no longer reads their inventories
     (one request each saved). Restore these two resources together with the
     pages, their routes, the KPI tiles and the posture/finding lines above.
  const groups = useResource(() => accountId ? identityApi.listGroups(accountId) : Promise.resolve({ groups: [] }), [accountId]);
  const delegations = useResource(() => identityApi.listDelegations(), []);
  */
  const roles = useResource(() => rbacApi.listRoles(), []);
  const policies = useResource(() => pbacApi.listPolicies(), []);
  const users = useResource(
    () =>
      accountId
        ? identityApi.listUsers({ account_id: accountId, per_page: 1 })
        : Promise.resolve({ users: [], pagination: { total: 0 } }),
    [accountId]
  );
  /* Tenant-wide lifecycle totals for the composition panel. `per_page: 1` keeps
     the payload tiny — only `pagination.total` is read — and the status filter is
     the same one the Users page uses, so the two screens can never disagree. */
  const activeUsers = useResource(
    () =>
      accountId
        ? identityApi.listUsers({ account_id: accountId, status: 'ACTIVE', per_page: 1 })
        : Promise.resolve({ pagination: { total: 0 } }),
    [accountId]
  );
  const disabledUsers = useResource(
    () =>
      accountId
        ? identityApi.listUsers({ account_id: accountId, status: 'DISABLED', per_page: 1 })
        : Promise.resolve({ pagination: { total: 0 } }),
    [accountId]
  );
  const sessions = useResource(() => sessionsApi.list(), []);

  const coreLoading = roles.loading || policies.loading;
  const sessionsData = !sessions.loading && !sessions.error ? sessions.data : null;

  const posture = usePosture({
    user,
    sessions: sessionsData,
    roles: roles.data,
    policies: policies.data,
  });

  // Same envelope-tolerant resolution as usePosture above, so the posture
  // checklist can never disagree with the Roles / Policies pages. Every count
  // re-derives on reload, so create and delete move them.
  const rolesCount = extractList(roles.data, 'roles').length;
  const policiesCount = extractList(policies.data, 'policies').length;

  const totals = { rolesCount, policiesCount };

  /* Directory totals — declared before the KPI strip so both the tiles and the
     composition panel read the same numbers. */
  const totalUsers = users.data?.pagination?.total ?? 0;
  const activeCount = activeUsers.data?.pagination?.total ?? 0;
  const disabledCount = disabledUsers.data?.pagination?.total ?? 0;
  const directoryLoading = users.loading || activeUsers.loading || disabledUsers.loading;
  const postureCfg = LEVEL_COPY[posture.level];

  /* ══ ACCESS FOOTPRINT KPI STRIP — TEMPORARILY COMMENTED OUT ════════════════
     Hidden at the product owner's request, together with the section that
     rendered it (search for "Access footprint" below). Every count it used
     (users / active users / sessions / roles / policies) is still resolved above
     for the posture panel, the insight row and the findings list, so restoring
     this block is a straight uncomment — re-add the Groups and Delegations
     tiles only when those pages come back.

  const kpis = [
    {
      label: 'Users',
      value: users.data?.pagination?.total ?? (users.loading ? null : '—'),
      icon: Users,
      tone: 'brand',
      to: '/identity/users',
      loading: users.loading,
      hint: activeUsers.loading ? undefined : `${activeCount.toLocaleString()} active`,
    },
    {
      label: 'Sessions',
      value: posture.activeSessions,
      icon: KeyRound,
      tone: 'green',
      to: '/security/sessions',
      loading: sessions.loading,
      hint: 'Signed in now',
    },
    {
      label: 'Roles',
      value: rolesCount,
      icon: ShieldCheck,
      tone: 'sky',
      to: '/rbac/roles',
      loading: roles.loading,
      hint: 'Standing access',
    },
    {
      label: 'Policies',
      value: policiesCount,
      icon: FileLock2,
      tone: 'amber',
      to: '/pbac/policies',
      loading: policies.loading,
      hint: 'Evaluated per request',
    },
    // Groups + Delegations tiles — withheld with their pages:
    // { label: 'Groups', value: groupsCount, icon: UsersRound, tone: 'slate', to: '/rbac/groups', loading: groups.loading, hint: 'Membership sets' },
    // { label: 'Delegations', value: delegationsCount, icon: UserCog, tone: 'brand', to: '/identity/delegations', loading: delegations.loading, hint: 'Temporary access' },
  ];
  ═══════════════════════════════════════════════════════════════════════ */

  const reloadAll = () => {
    roles.reload?.();
    policies.reload?.();
    users.reload?.();
    activeUsers.reload?.();
    disabledUsers.reload?.();
    sessions.reload?.();
    // groups.reload?.();        ← restore with the Groups page
    // delegations.reload?.();   ← restore with the Delegations page
  };

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${user?.username || 'administrator'}`}
        description="Tenant-wide identity posture, open findings and privileged activity."
        meta={
          <>
            {/* Posture verdict travels with the page title: an operator should
                know the answer before they finish reading the header. */}
            <span className="inline-flex items-center gap-1.5">
              <Gauge className="h-3.5 w-3.5 text-slate-400" />
              Posture
              <Badge tone={postureCfg.tone} dot>
                {postureCfg.label} · {posture.score}
              </Badge>
            </span>
            {accountId && (
              <span className="inline-flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-slate-400" />
                Tenant <span className="font-mono text-slate-600">{accountId}</span>
              </span>
            )}
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-slate-400" />
              {posture.passed} of {posture.total} baseline controls passing
            </span>
          </>
        }
        actions={
          <>
            <Button variant="secondary" onClick={reloadAll} loading={coreLoading}>
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            {isAdminAccountType(accountType) && (
              <Button onClick={() => navigate('/identity/users')}>
                <Users className="h-4 w-4" />
                Manage users
              </Button>
            )}
          </>
        }
      />

      <div className="space-y-4">
        {!user?.mfa_enabled && (
          <InlineAlert
            tone="warning"
            title="Multi-factor authentication is not enabled"
            action={
              <Button size="sm" onClick={() => navigate('/security/mfa')}>
                Enable MFA
              </Button>
            }
          >
            This administrator account is protected by a password alone, leaving it exposed to
            credential-based attacks.
          </InlineAlert>
        )}

        {/* ── The fold ──────────────────────────────────────────────────────
            "Am I secure?" and "what must I fix?" are the two questions an
            administrator opens this page with, so they answer side by side with
            equal visual weight — 6 and 6 of a 12-column grid rather than 8 / 4.
            An equal split also stops the findings list from reading as a
            sidebar afterthought, which is exactly what it is not.
            `items-stretch` + `h-full` on both panels keeps the two cards the
            same height however many findings there are. */}
        <div className="grid grid-cols-1 items-stretch gap-4 lg:grid-cols-2 xl:grid-cols-12">
          <div className="xl:col-span-6">
            <SecurityPosture posture={posture} loading={coreLoading} />
          </div>
          <div className="xl:col-span-6">
            <AttentionPanel posture={posture} totals={totals} user={user} />
          </div>
        </div>

        {/* ══ ACCESS FOOTPRINT — TEMPORARILY COMMENTED OUT ════════════════════
            The KPI tile strip ("Everything this tenant governs") is hidden at
            the product owner's request. The rest of the dashboard — posture,
            findings, standing-access concentration, directory composition,
            activity and account context — is unchanged. Restore by uncommenting
            this section and the `kpis` array above.

        <section>
          <div className="mb-2 flex items-end justify-between gap-3">
            <div>
              <h2 className="text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                Access footprint
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Everything this tenant governs. Select a tile to open its inventory.
              </p>
            </div>
            <Button variant="ghost" size="xs" onClick={() => navigate('/identity/users')}>
              Open directory
              <ArrowRight className="h-3 w-3" />
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
            {kpis.map((kpi) => (
              <StatCard
                key={kpi.label}
                label={kpi.label}
                value={typeof kpi.value === 'number' ? kpi.value.toLocaleString() : kpi.value}
                hint={kpi.hint}
                icon={kpi.icon}
                tone={kpi.tone}
                loading={kpi.loading}
                onClick={() => navigate(kpi.to)}
              />
            ))}
          </div>
        </section>
            ═════════════════════════════════════════════════════════════ */}

        {/* ── Insight row ─────────────────────────────────────────────
            Counts say how much; these two say WHERE. Concentration of standing
            access and directory lifecycle state are the two reviews an identity
            team runs weekly, so they get equal width under the KPI strip. */}
        <div className="grid grid-cols-1 items-stretch gap-4 lg:grid-cols-2">
          <RoleConcentration roles={roles.data} loading={roles.loading} />
          <DirectoryComposition
            total={totalUsers}
            active={activeCount}
            disabled={disabledCount}
            loading={directoryLoading}
          />
        </div>

        {/* ── Activity + account ───────────────────────────────────────────
            The event stream needs the width (it carries principal, action and
            resource on one line); the account panel is a reference card, so 7/5
            rather than 8/4 — the panel stops looking stretched and the stream
            stops truncating. */}
        <div className="grid grid-cols-1 items-stretch gap-4 xl:grid-cols-12">
          <div className="xl:col-span-7">
            <RecentActivity />
          </div>
          <div className="xl:col-span-5">
            <AccountPanel user={user} posture={posture} accountId={accountId} accountType={accountType} />
          </div>
        </div>
      </div>
    </div>
  );
}
