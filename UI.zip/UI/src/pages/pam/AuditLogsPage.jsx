/**
 * AuditLogsPage — PAM · Audit Logs (`/pam/audit-logs`).
 *
 * Previously the first tab of the single PAM page; now a page of its own with
 * its own sidebar entry, so an investigation can be linked to, bookmarked and
 * returned to without carrying a `?tab=` parameter.
 *
 * Drill-through: the Alerts page links here with `?search=<term>&decision=denied`,
 * which is read once and applied as the opening filter set.
 */
import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ScrollText } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { AuditLogsSection, PamErrorBoundary } from './parts.jsx';

export default function AuditLogsPage() {
  const [searchParams] = useSearchParams();
  const search = searchParams.get('search') || '';
  const decision = searchParams.get('decision') || '';

  /* A preset only exists when the URL actually carries one, so opening the page
     normally starts from the unfiltered trail. */
  const preset = useMemo(
    () => (search || decision ? { search, severity: decision || 'denied' } : null),
    [search, decision]
  );

  return (
    <div>
      <PageHeader
        title="Audit Logs"
        description="Authentication and authorisation evidence for the tenant — filter, scan and inspect any event."
        icon={<ScrollText className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'PAM' }, { label: 'Audit Logs' }]}
      />

      <PamErrorBoundary>
        <AuditLogsSection preset={preset} />
      </PamErrorBoundary>
    </div>
  );
}
