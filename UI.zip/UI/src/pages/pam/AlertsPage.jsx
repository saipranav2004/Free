/**
 * AlertsPage — PAM · Alerts (`/pam/alerts`).
 *
 * Previously the second tab of the single PAM page; now a page of its own with
 * its own sidebar entry and a stable URL, which is what the notifications bell
 * in the Topbar links to.
 *
 * Ranked rows drill through to the audit trail page, handing over the search
 * term and the DENY decision in the URL.
 */
import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { AlertsSection, PamErrorBoundary } from './parts.jsx';

export default function AlertsPage() {
  const navigate = useNavigate();

  const investigate = useCallback(
    (term) => {
      navigate(
        `/pam/audit-logs?search=${encodeURIComponent(term || '')}&decision=denied`
      );
    },
    [navigate]
  );

  return (
    <div>
      <PageHeader
        title="Alerts"
        description="Denial analytics for the tenant — volume, distribution and the principals, resources and actions being refused."
        icon={<ShieldAlert className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'PAM' }, { label: 'Alerts' }]}
      />

      <PamErrorBoundary>
        <AlertsSection onInvestigate={investigate} />
      </PamErrorBoundary>
    </div>
  );
}
