/**
 * PamPage — Privileged Access Management hub.
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * DESIGN DECISIONS (Research: CyberArk, Splunk, Sentinel)
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * 1. TAB-BASED APPROACH — Keeping Audit Logs and Alerts in separate tabs.
 *    If the alerts API is down, users still see audit logs.
 *
 * 2. SPLIT-VIEW FORMAT — Both tabs use the same layout:
 *    - Left: Activity Feed (chronological event list with severity indicators)
 *    - Right: Event Detail Panel (shows full details when an event is clicked)
 *    This is the SIEM gold standard (Splunk, Sentinel, Chronicle).
 *
 * 3. RESPONSIVE MASTER-DETAIL — On mobile, tapping an event shows the detail
 *    panel full-screen with a back button (mobile-first responsive pattern).
 *
 * 4. DATA MAPPING FIX — Properly extracts data from nested audit_event objects
 *    and handles missing fields gracefully.
 *
 * 5. NO FAKE DATA — Only real API responses are displayed.
 *
 * 6. ALERTS TAB — No filters, purely analytical view with:
 *    - Stat cards (Total Denials, Unique Users, Last 24h, Affected Resources)
 *    - Trend Visualization (24h, 7d, 30d)
 *    - Severity Distribution (High/Medium/Low)
 *    - User Risk Patterns (Top denied users)
 *    - Resource Hotspots (Most targeted resources)
 *    - Top Denied Actions (with progress bars)
 *    - Recent Denials list (clickable for details)
 *
 * ═══════════════════════════════════════════════════════════════════════════════
 * CONSTRAINTS
 * ═══════════════════════════════════════════════════════════════════════════════
 * - Frontend only. Backend folder is strictly for studying APIs.
 * - No git commands.
 * - Existing color palette preserved.
 * - No fake data — only real API responses.
 * - Production-grade, maintainable code.
 */
import { useState, useCallback, useRef, useEffect, useMemo, Component } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ShieldAlert,
  ScrollText,
  Activity,
  AlertTriangle,
  Clock,
  Pause,
  Play,
  RefreshCw,
  Download,
  XCircle,
  Users,
  ArrowLeft,
  TrendingUp,
  BarChart3,
  Target,
  UserX,
  CheckCircle2,
} from 'lucide-react';
import { useResource } from '../../hooks/useResource.js';
import { alertsApi } from '../../lib/api/alerts.js';
import { identityAuditApi } from '../../lib/api/identityAudit.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Badge, Spinner } from '../../components/ui/primitives.jsx';
import { ActivityFeed } from '../../components/pam/ActivityFeed.jsx';
import { EventDetailPanel } from '../../components/pam/EventDetailPanel.jsx';
import { PamFilters } from '../../components/pam/PamFilters.jsx';
import { formatDateTime, classNames } from '../../utils/format.js';

// ─── Tab configuration ───────────────────────────────────────────────────────
const TABS = [
  {
    id: 'audit',
    label: 'Audit Logs',
    description: 'Authentication & authorization activity across the platform',
    icon: ScrollText,
  },
  {
    id: 'alerts',
    label: 'Alerts',
    description: 'Security alerts and denial analytics',
    icon: ShieldAlert,
  },
];

// ─── Color palette for analytics ──────────────────────────────────────────────
const BRAND_COLOR = '#1f47f5';
const AMBER_COLOR = '#d97706';
const SLATE_COLOR = '#64748b';
const ROSE_COLOR = '#e11d48';

// ─── Format action names for better readability ───────────────────────────────
function formatActionName(action) {
  if (!action) return 'Authorization Event';
  const actionMap = {
    'role:assign': 'Role Assignment',
    'role:remove': 'Role Removal',
    'policy:read': 'Policy Read',
    'resource:read': 'Resource Read',
    'resource:create': 'Resource Create',
    'user:login': 'User Login',
    'user:logout': 'User Logout',
    'mfa:verify': 'MFA Verification',
    'session:create': 'Session Create',
    'session:revoke': 'Session Revoke',
  };
  return actionMap[action] || action.split(':').map(word =>
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
}

// ─── Horizontal progress bar for "Top N" analytics ───────────────────────────
function ProgressBar({ label, value, maxValue, color = BRAND_COLOR }) {
  const percentage = maxValue > 0 ? Math.round((value / maxValue) * 100) : 0;
  return (
    <div className="group">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-medium text-slate-700 truncate max-w-[180px]" title={label}>{label}</span>
        <span className="text-xs font-semibold text-ink-900">{value?.toLocaleString?.() ?? value ?? 0}</span>
      </div>
      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500 ease-out" style={{ width: `${Math.max(percentage, 2)}%`, backgroundColor: color }} />
      </div>
    </div>
  );
}

// ─── Trend Visualization Card ─────────────────────────────────────────────────
function TrendVisualization({ trend }) {
  if (!trend) return null;
  const maxValue = Math.max(trend.last_24h || 0, trend.last_7d || 0, trend.last_30d || 0, 1);
  const periods = [
    { label: 'Last 24 Hours', value: trend.last_24h || 0, color: 'bg-rose-500' },
    { label: 'Last 7 Days', value: trend.last_7d || 0, color: 'bg-amber-500' },
    { label: 'Last 30 Days', value: trend.last_30d || 0, color: 'bg-slate-400' },
  ];
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-4 w-4 text-rose-500" />
        <p className="text-sm font-semibold text-ink-900">Denial Trend</p>
      </div>
      <div className="space-y-4">
        {periods.map((period) => (
          <div key={period.label}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-slate-600">{period.label}</span>
              <span className="text-sm font-bold text-ink-900">{period.value.toLocaleString()}</span>
            </div>
            <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
              <div className={classNames('h-full rounded-full transition-all duration-700', period.color)} style={{ width: `${(period.value / maxValue) * 100}%` }} />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── Severity Distribution Bar ────────────────────────────────────────────────
function SeverityDistributionBar({ stats }) {
  const total = stats?.total_deny || 0;
  const severities = useMemo(() => {
    const actionGroups = stats?.deny_by_action || [];
    const highSeverity = actionGroups.filter(a => a.action?.includes('role:') || a.action?.includes('admin')).reduce((sum, a) => sum + (a.count || 0), 0);
    const mediumSeverity = actionGroups.filter(a => a.action?.includes('policy:') || a.action?.includes('resource:')).reduce((sum, a) => sum + (a.count || 0), 0);
    const lowSeverity = total - highSeverity - mediumSeverity;
    return [
      { label: 'High', count: Math.max(0, highSeverity), color: 'bg-rose-500' },
      { label: 'Medium', count: Math.max(0, mediumSeverity), color: 'bg-amber-500' },
      { label: 'Low', count: Math.max(0, lowSeverity), color: 'bg-slate-400' },
    ].filter(s => s.count > 0);
  }, [stats, total]);
  if (total === 0) return null;
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <BarChart3 className="h-4 w-4 text-brand-500" />
        <p className="text-sm font-semibold text-ink-900">Severity Distribution</p>
      </div>
      <div className="flex h-4 rounded-full overflow-hidden mb-3">
        {severities.map((sev) => (
          <div key={sev.label} className={classNames('transition-all duration-500', sev.color)} style={{ width: `${(sev.count / total) * 100}%` }} title={`${sev.label}: ${sev.count} denials`} />
        ))}
      </div>
      <div className="flex flex-wrap gap-4">
        {severities.map((sev) => (
          <div key={sev.label} className="flex items-center gap-2">
            <div className={classNames('w-3 h-3 rounded-full', sev.color)} />
            <span className="text-xs text-slate-600">{sev.label} ({sev.count})</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── User Risk Patterns Card ──────────────────────────────────────────────────
function UserRiskPatterns({ denyByUser, maxValue }) {
  if (!denyByUser?.length) return null;
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <UserX className="h-4 w-4 text-amber-500" />
        <p className="text-sm font-semibold text-ink-900">Top Denied Users</p>
      </div>
      <div className="space-y-3">
        {denyByUser.slice(0, 6).map((item, i) => {
          const username = item.username || item.user_id || 'Unknown';
          const count = item.count || 0;
          const percentage = maxValue > 0 ? (count / maxValue) * 100 : 0;
          return (
            <div key={username + i} className="group">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-100 text-xs font-semibold text-amber-700">{username.charAt(0).toUpperCase()}</div>
                  <span className="text-xs font-medium text-slate-700 truncate max-w-[150px]" title={username}>{username}</span>
                </div>
                <span className="text-xs font-bold text-ink-900">{count}</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full rounded-full bg-amber-500 transition-all duration-500" style={{ width: `${Math.max(percentage, 2)}%` }} />
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── Resource Hotspot Card ────────────────────────────────────────────────────
function ResourceHotspots({ denyByResource, maxValue }) {
  if (!denyByResource?.length) return null;
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-4">
        <Target className="h-4 w-4 text-slate-500" />
        <p className="text-sm font-semibold text-ink-900">Targeted Resources</p>
      </div>
      <div className="space-y-3">
        {denyByResource.slice(0, 6).map((item, i) => {
          const resource = item.resource || 'Unknown';
          const count = item.count || 0;
          const percentage = maxValue > 0 ? (count / maxValue) * 100 : 0;
          return (
            <div key={resource + i} className="group">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-slate-700 truncate max-w-[180px]" title={resource}>{resource}</span>
                <span className="text-xs font-bold text-ink-900">{count}</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full rounded-full bg-slate-500 transition-all duration-500" style={{ width: `${Math.max(percentage, 2)}%` }} />
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── ErrorBoundary ───────────────────────────────────────────────────────────
class PamErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    console.error('[PamPage] Render error:', error, info?.componentStack);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-rose-300 bg-rose-50 px-6 py-20 text-center">
          <AlertTriangle className="mb-4 h-10 w-10 text-rose-500" />
          <p className="text-sm font-semibold text-rose-800">Section failed to render</p>
          <p className="mt-1.5 max-w-md text-sm text-rose-600">{this.state.error?.message || 'An unexpected error occurred.'}</p>
          <button onClick={() => this.setState({ hasError: false, error: null })} className="mt-4 rounded-lg bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700">Try again</button>
        </div>
      );
    }
    return this.props.children;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Audit Logs Tab — split-view with Activity Feed + Detail Panel + Filters
// ═══════════════════════════════════════════════════════════════════════════════
function AuditLogsTab() {
  const navigate = useNavigate();
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const autoRefreshRef = useRef(null);

  const [filters, setFilters] = useState({ severity: 'all', type: 'all', search: '', from: '', to: '' });
  const [appliedFilters, setAppliedFilters] = useState({ severity: 'all', type: 'all', search: '', from: '', to: '', page: 1, page_size: 20 });

  const fetcher = useCallback(() => identityAuditApi.list({
    type: appliedFilters.type !== 'all' ? appliedFilters.type : undefined,
    search: appliedFilters.search || undefined,
    from: appliedFilters.from || undefined,
    to: appliedFilters.to || undefined,
    page: appliedFilters.page,
    page_size: appliedFilters.page_size,
  }), [appliedFilters.type, appliedFilters.search, appliedFilters.from, appliedFilters.to, appliedFilters.page, appliedFilters.page_size]);

  const logs = useResource(fetcher, [appliedFilters.type, appliedFilters.search, appliedFilters.from, appliedFilters.to, appliedFilters.page, appliedFilters.page_size]);

  const rawLogs = logs?.data;
  const items = Array.isArray(rawLogs) ? rawLogs : rawLogs?.items || rawLogs?.logs || rawLogs?.data || [];
  const pagination = logs?.data?.pagination || { page: 1, page_size: 20, total: 0, total_pages: 1 };

  const filteredItems = useMemo(() => {
    if (filters.severity === 'all') return items;
    return items.filter(e => {
      const d = String(e?.decision || '').toUpperCase();
      const s = String(e?.status || '').toUpperCase();
      if (filters.severity === 'denied') return d === 'DENY' || s === 'FAILURE';
      if (filters.severity === 'success') return d === 'ALLOW' || d === 'SUCCESS' || s === 'SUCCESS';
      return true;
    });
  }, [items, filters.severity]);

  useEffect(() => {
    if (!autoRefresh) return;
    autoRefreshRef.current = setInterval(() => { logs?.reload?.(); setLastUpdated(new Date()); }, 30_000);
    return () => { if (autoRefreshRef.current) clearInterval(autoRefreshRef.current); };
  }, [autoRefresh]);

  const handleFilterChange = useCallback((key, value) => {
    setFilters(f => ({ ...f, [key]: value }));
    if (key !== 'search') setAppliedFilters(a => ({ ...a, [key]: value, page: 1 }));
  }, []);

  const handleSearch = useCallback((searchValue) => { setAppliedFilters(a => ({ ...a, search: searchValue, page: 1 })); }, []);
  const handleReset = useCallback(() => { const empty = { severity: 'all', type: 'all', search: '', from: '', to: '' }; setFilters(empty); setAppliedFilters({ ...empty, page: 1, page_size: 20 }); }, []);
  const handlePageChange = useCallback((page) => { setAppliedFilters(a => ({ ...a, page })); setSelectedEvent(null); }, []);

  const handleExport = useCallback(() => {
    if (!filteredItems?.length) return;
    const headers = ['Time', 'Type', 'User', 'Action', 'Decision', 'Resource', 'Status', 'IP'];
    const rows = filteredItems.map(r => [r?.created_at || '', r?.log_type || '', r?.username || r?.user_id || '', r?.action || r?.event_type || '', r?.decision || '', r?.resource_name || r?.resource || '', r?.status || '', r?.ip_address || '']);
    const csv = [headers, ...rows].map(row => row.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `audit-logs-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }, [filteredItems]);

  const counts = useMemo(() => ({
    denied: items.filter(e => { const d = String(e?.decision || '').toUpperCase(); const s = String(e?.status || '').toUpperCase(); return d === 'DENY' || s === 'FAILURE'; }).length,
    success: items.filter(e => { const d = String(e?.decision || '').toUpperCase(); const s = String(e?.status || '').toUpperCase(); return d === 'ALLOW' || d === 'SUCCESS' || s === 'SUCCESS'; }).length,
  }), [items]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant={autoRefresh ? 'primary' : 'outline'} size="sm" onClick={() => setAutoRefresh(v => !v)}>
            {autoRefresh ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {autoRefresh ? 'Live' : 'Auto-refresh'}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { logs?.reload?.(); setLastUpdated(new Date()); }}><RefreshCw className="h-3.5 w-3.5" /></Button>
          <Button variant="outline" size="sm" onClick={handleExport} disabled={!filteredItems?.length}><Download className="h-3.5 w-3.5" /> Export CSV</Button>
        </div>
        {(lastUpdated || autoRefresh) && (
          <span className="flex items-center gap-1.5 text-xs text-slate-400"><Clock className="h-3 w-3" />{lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString()}` : 'Auto-refresh on'}{autoRefresh && <span className="text-brand-500">· 30s</span>}</span>
        )}
      </div>
      <Card className="p-4 overflow-x-auto"><PamFilters filters={filters} onFilterChange={handleFilterChange} onSearch={handleSearch} onReset={handleReset} counts={counts} /></Card>
      <div className={classNames('rounded-xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 lg:grid-cols-5', selectedEvent ? 'min-h-[520px]' : '')}>
        <div className={classNames('lg:col-span-3 border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col', selectedEvent ? 'hidden lg:flex' : 'flex')}>
          <ActivityFeed events={filteredItems} selectedEvent={selectedEvent} onSelectEvent={setSelectedEvent} loading={logs?.loading && filteredItems.length === 0} error={logs?.error && filteredItems.length === 0 ? logs.error : null} pagination={pagination} onPageChange={handlePageChange} onRetry={() => logs?.reload?.()} emptyMessage="No audit events match the current filters." />
        </div>
        <div className={classNames('lg:col-span-2 flex flex-col bg-slate-50/30', selectedEvent ? 'flex' : 'hidden lg:flex')} style={{ minHeight: '400px' }}>
          {selectedEvent && (<button onClick={() => setSelectedEvent(null)} className="flex items-center gap-2 px-4 py-3 border-b border-slate-200 bg-white text-sm font-medium text-slate-600 hover:bg-slate-50 lg:hidden"><ArrowLeft className="h-4 w-4" /> Back to feed</button>)}
          <EventDetailPanel event={selectedEvent} onClose={() => setSelectedEvent(null)} onNavigateToUser={(userId) => navigate(`/identity/users/${userId}`)} onNavigateToResource={(resource) => navigate(`/identity/resources?search=${encodeURIComponent(resource)}`)} />
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Alerts Tab — NO filters, purely analytical view with all analytics components
// Research: CyberArk Trends & Insights, BeyondTrust Identity Security Insights
// ═══════════════════════════════════════════════════════════════════════════════
function AlertsTab() {
  const navigate = useNavigate();
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const autoRefreshRef = useRef(null);
  const alertsRef = useRef(null);

  const fetcher = useCallback(() => alertsApi.list({ page: 1, page_size: 100 }), []);
  const alerts = useResource(fetcher, []);
  alertsRef.current = alerts;

  const raw = alerts?.data;
  const items = Array.isArray(raw) ? raw : raw?.items || raw?.logs || raw?.data || [];

  const normalizedItems = useMemo(() => {
    return items.map(item => {
      const event = item?.audit_event || item || {};
      const userProfile = item?.user_profile || {};
      return {
        audit_id: event?.audit_id || event?.id || item?.audit_id || item?.id,
        action: event?.action || event?.event_type || item?.action || item?.event_type,
        username: userProfile?.username || event?.username || item?.username || event?.user_id,
        email: userProfile?.email || event?.email || item?.email,
        resource_name: event?.resource_name || event?.resource || item?.resource_name || item?.resource,
        decision: event?.decision || event?.status || item?.decision,
        status: event?.status || item?.status,
        ip_address: event?.ip_address || item?.ip_address,
        created_at: event?.created_at || item?.created_at,
        details: event?.details || item?.details,
        log_type: event?.log_type || item?.log_type,
        user_agent: event?.user_agent || item?.user_agent,
        audit_event: event,
        user_profile: userProfile,
      };
    }).filter(item => item.audit_id);
  }, [items]);

  const stats = raw?.stats || { total_deny: 0, unique_users: 0, unique_actions: 0, unique_resources: 0, deny_by_action: [], deny_by_resource: [], deny_by_user: [], trend: { last_24h: 0, last_7d: 0, last_30d: 0 } };

  useEffect(() => {
    if (!autoRefresh) return;
    autoRefreshRef.current = setInterval(() => { alertsRef.current?.reload?.(); setLastUpdated(new Date()); }, 60_000);
    return () => { if (autoRefreshRef.current) clearInterval(autoRefreshRef.current); };
  }, [autoRefresh]);

  const actionData = (stats.deny_by_action || []).map((item) => ({ name: formatActionName(item.action || 'Unknown'), value: item.count || 0 }));
  const userData = (stats.deny_by_user || []).map((item) => ({ name: item.username || item.user_id || 'Unknown', value: item.count || 0 }));
  const resourceData = (stats.deny_by_resource || []).map((item) => ({ name: item.resource || 'Unknown', value: item.count || 0 }));
  const maxAction = Math.max(...actionData.map(d => d.value), 1);
  const maxUser = Math.max(...userData.map(d => d.value), 1);
  const maxResource = Math.max(...resourceData.map(d => d.value), 1);

  const [page, setPage] = useState(1);
  const pageSize = 20;
  const totalPages = Math.max(1, Math.ceil(normalizedItems.length / pageSize));
  const safePage = Math.min(page, totalPages);
  useEffect(() => { setPage(1); }, [totalPages]);
  const paginatedItems = normalizedItems.slice((safePage - 1) * pageSize, safePage * pageSize);
  const pagination = { page: safePage, page_size: pageSize, total: normalizedItems.length, total_pages: totalPages };

  return (
    <div className="space-y-4">
      {/* ── Stat cards ── */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="p-4"><div className="flex items-center gap-3"><div className="rounded-lg p-2 bg-rose-50 text-rose-600"><XCircle className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="text-xs text-slate-500">Total Denials</p><p className="text-lg font-semibold text-ink-900">{stats.total_deny?.toLocaleString?.() ?? stats.total_deny ?? '—'}</p></div></div></Card>
        <Card className="p-4"><div className="flex items-center gap-3"><div className="rounded-lg p-2 bg-amber-50 text-amber-600"><Users className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="text-xs text-slate-500">Unique Users</p><p className="text-lg font-semibold text-ink-900">{stats.unique_users?.toLocaleString?.() ?? stats.unique_users ?? '—'}</p></div></div></Card>
        <Card className="p-4"><div className="flex items-center gap-3"><div className="rounded-lg p-2 bg-brand-50 text-brand-600"><Activity className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="text-xs text-slate-500">Last 24 Hours</p><p className="text-lg font-semibold text-ink-900">{stats.trend?.last_24h?.toLocaleString?.() ?? stats.trend?.last_24h ?? '—'}</p></div></div></Card>
        <Card className="p-4"><div className="flex items-center gap-3"><div className="rounded-lg p-2 bg-slate-100 text-slate-600"><ShieldAlert className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="text-xs text-slate-500">Affected Resources</p><p className="text-lg font-semibold text-ink-900">{stats.unique_resources?.toLocaleString?.() ?? stats.unique_resources ?? '—'}</p></div></div></Card>
      </div>

      {/* ── Controls bar ── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant={autoRefresh ? 'primary' : 'outline'} size="sm" onClick={() => setAutoRefresh(v => !v)}>
            {autoRefresh ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {autoRefresh ? 'Live' : 'Auto-refresh'}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { alerts?.reload?.(); setLastUpdated(new Date()); }}><RefreshCw className="h-3.5 w-3.5" /></Button>
        </div>
        {(lastUpdated || autoRefresh) && (
          <span className="flex items-center gap-1.5 text-xs text-slate-400"><Clock className="h-3 w-3" />{lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString()}` : 'Auto-refresh on'}{autoRefresh && <span className="text-brand-500">· 60s</span>}</span>
        )}
      </div>

      {/* ── Trend Visualization ── */}
      <TrendVisualization trend={stats.trend} />

      {/* ── Severity Distribution ── */}
      <SeverityDistributionBar stats={stats} />

      {/* ── Analytics Grid ── */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <UserRiskPatterns denyByUser={stats.deny_by_user} maxValue={maxUser} />
        <ResourceHotspots denyByResource={stats.deny_by_resource} maxValue={maxResource} />
        {actionData.length > 0 && (
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-4"><BarChart3 className="h-4 w-4 text-brand-500" /><p className="text-sm font-semibold text-ink-900">Top Denied Actions</p></div>
            <div className="space-y-3">{actionData.slice(0, 6).map((item) => (<ProgressBar key={item.name} label={item.name} value={item.value} maxValue={maxAction} color={BRAND_COLOR} />))}</div>
          </Card>
        )}
      </div>

      {/* ── Split View ── */}
      <div className={classNames('rounded-xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 lg:grid-cols-5', selectedEvent ? 'min-h-[520px]' : '')}>
        <div className={classNames('lg:col-span-3 border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col', selectedEvent ? 'hidden lg:flex' : 'flex')}>
          <ActivityFeed events={paginatedItems} selectedEvent={selectedEvent} onSelectEvent={setSelectedEvent} loading={alerts?.loading && paginatedItems.length === 0} error={alerts?.error && paginatedItems.length === 0 ? alerts.error : null} pagination={pagination} onPageChange={(p) => { setPage(p); setSelectedEvent(null); }} onRetry={() => alerts?.reload?.()} emptyMessage="No denial alerts detected." />
        </div>
        <div className={classNames('lg:col-span-2 flex flex-col bg-slate-50/30', selectedEvent ? 'flex' : 'hidden lg:flex')} style={{ minHeight: '400px' }}>
          {selectedEvent && (<button onClick={() => setSelectedEvent(null)} className="flex items-center gap-2 px-4 py-3 border-b border-slate-200 bg-white text-sm font-medium text-slate-600 hover:bg-slate-50 lg:hidden"><ArrowLeft className="h-4 w-4" /> Back to feed</button>)}
          <EventDetailPanel event={selectedEvent} onClose={() => setSelectedEvent(null)} onNavigateToUser={(userId) => navigate(`/identity/users/${userId}`)} onNavigateToResource={(resource) => navigate(`/identity/resources?search=${encodeURIComponent(resource)}`)} />
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// PamPage — main PAM page with tabbed Audit Logs + Alerts
// ═══════════════════════════════════════════════════════════════════════════════
export default function PamPage() {
  const [activeTab, setActiveTab] = useState('audit');
  return (
    <div className="space-y-6">
      <PageHeader title="Privileged Access Management" description="Monitor privileged access, audit trails, and security alerts in one place." icon={<Activity className="h-5 w-5" />} />
      <div className="border-b border-slate-200 overflow-x-auto">
        <nav className="-mb-px flex gap-1 min-w-max" role="tablist" aria-label="PAM sections">
          {TABS.map((tab) => {
            const isActive = tab.id === activeTab;
            const Icon = tab.icon;
            return (
              <button key={tab.id} id={`tab-${tab.id}`} role="tab" aria-selected={isActive} aria-controls={`tabpanel-${tab.id}`} onClick={() => setActiveTab(tab.id)} className={classNames('relative flex items-center gap-2 rounded-t-lg px-4 sm:px-5 py-3 text-sm sm:text-[15px] font-semibold transition-all duration-150', isActive ? 'text-brand-700 bg-brand-50/60' : 'text-slate-500 hover:text-ink-800 hover:bg-slate-50')}>
                <Icon className={classNames('h-4 w-4', isActive ? 'text-brand-600' : 'text-slate-400')} />
                <span>{tab.label}</span>
                {isActive && <span className="absolute -bottom-[1px] left-4 right-4 h-[3px] rounded-full bg-brand-600" />}
              </button>
            );
          })}
        </nav>
      </div>
      {activeTab === 'audit' && <div id="tabpanel-audit" role="tabpanel" aria-labelledby="tab-audit" className="mt-2"><PamErrorBoundary><AuditLogsTab /></PamErrorBoundary></div>}
      {activeTab === 'alerts' && <div id="tabpanel-alerts" role="tabpanel" aria-labelledby="tab-alerts" className="mt-2"><PamErrorBoundary><AlertsTab /></PamErrorBoundary></div>}
    </div>
  );
}
