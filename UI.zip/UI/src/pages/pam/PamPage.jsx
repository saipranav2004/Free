/**
 * PamPage — compatibility shell for `/pam`.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT CHANGED
 * ═══════════════════════════════════════════════════════════════════════════
 * PAM used to be ONE page with two tabs (Audit Logs · Alerts) selected by a
 * `?tab=` query parameter. It is now two dedicated pages, each with its own
 * route and its own entry in the PAM sidebar:
 *
 *     /pam/audit-logs   → pages/pam/AuditLogsPage.jsx
 *     /pam/alerts       → pages/pam/AlertsPage.jsx
 *
 * Both surfaces themselves live in pages/pam/parts.jsx — the same endpoints,
 * parameters and response handling as the former tabs, nothing re-implemented.
 *
 * This shell only resolves the old links so nothing 404s or lands nowhere:
 *   /pam                → /pam/audit-logs   (the default working view)
 *   /pam?tab=alerts     → /pam/alerts       (legacy notifications-bell link)
 * ═══════════════════════════════════════════════════════════════════════════
 */
import { Navigate, useSearchParams } from 'react-router-dom';

export default function PamPage() {
  const [searchParams] = useSearchParams();
  const tab = searchParams.get('tab');
  const to = tab === 'alerts' ? '/pam/alerts' : '/pam/audit-logs';
  return <Navigate to={to} replace />;
}
