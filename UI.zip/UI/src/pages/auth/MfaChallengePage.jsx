import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { Button, Input, Card } from '../../components/ui/primitives.jsx';

export default function MfaChallengePage() {
  const { completeMfa } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const challengeToken = location.state?.challengeToken;
  const ssoMfaPending = location.state?.ssoMfaPending;
  const noChallenge = location.state?.noChallenge;

  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);

  // SSO user with MFA enabled, but the backend SSO callback did not issue an
  // MFA challenge (the SSO MFA gate isn't wired up yet). We must not let them
  // in — show why the sign-in cannot complete instead of a silent login.
  if (ssoMfaPending && !challengeToken) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-ink-900 to-ink-700 p-4">
        <Card className="max-w-sm p-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500 text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h2 className="text-base font-semibold text-ink-900">
            Multi-factor authentication required
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Your account has MFA enabled, so this Microsoft sign-in must be
            verified with a second factor. The SSO backend did not issue an MFA
            challenge — enable the SSO MFA gate on the backend (mirror the
            password-login MFA step) so this sign-in can be completed.
          </p>
          <Button className="mt-4" onClick={() => navigate('/login')}>
            Back to login
          </Button>
        </Card>
      </div>
    );
  }

  if (!challengeToken) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink-900 p-4">
        <Card className="max-w-sm p-6 text-center">
          <p className="text-sm text-slate-600">
            Your session expired. Please sign in again.
          </p>
          <Button className="mt-4" onClick={() => navigate('/login')}>
            Back to login
          </Button>
        </Card>
      </div>
    );
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await completeMfa({ code, challengeToken });
      toast.success('Verified.');
      navigate('/', { replace: true });
    } catch (err) {
      toast.error(err.userMessage || 'Invalid code.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-ink-900 to-ink-700 p-4">
      <Card className="w-full max-w-md p-6">
        <div className="mb-4 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500 text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-semibold text-ink-900">Two-factor verification</h1>
          <p className="mt-1 text-sm text-slate-500">
            Enter the 6-digit code from your authenticator app.
          </p>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <Input
            label="Authentication code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            inputMode="numeric"
            maxLength={8}
            autoFocus
            required
          />
          <Button type="submit" className="w-full" loading={loading}>
            Verify &amp; sign in
          </Button>
        </form>
      </Card>
    </div>
  );
}
