import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { authApi } from '../../lib/api/auth.js';
import { Button, Input, Card } from '../../components/ui/primitives.jsx';

export default function ResetPasswordPage() {
  const toast = useToast();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const token = params.get('token');

  const [form, setForm] = useState({ new_password: '', confirm_password: '' });
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (form.new_password !== form.confirm_password) {
      toast.error('Passwords do not match.');
      return;
    }
    if (!token) {
      toast.error('Missing or invalid reset token.');
      return;
    }
    setLoading(true);
    try {
      await authApi.confirmPasswordReset({
        reset_token: token,
        new_password: form.new_password,
        confirm_password: form.confirm_password,
      });
      toast.success('Password reset. Please sign in.');
      navigate('/login');
    } catch (err) {
      toast.error(err.userMessage || 'Reset failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-ink-900 to-ink-700 p-4">
      <Card className="w-full max-w-md p-6">
        <div className="mb-4 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500 text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-semibold text-ink-900">Choose a new password</h1>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <Input label="New password" type="password" value={form.new_password} onChange={(e) => setForm((f) => ({ ...f, new_password: e.target.value }))} required />
          <Input label="Confirm new password" type="password" value={form.confirm_password} onChange={(e) => setForm((f) => ({ ...f, confirm_password: e.target.value }))} required />
          <Button type="submit" className="w-full" loading={loading}>
            Reset password
          </Button>
        </form>
      </Card>
    </div>
  );
}
