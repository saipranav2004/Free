import { useState } from 'react';
import { Link } from 'react-router-dom';
import { MailCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { authApi } from '../../lib/api/auth.js';
import { Button, Input, Card } from '../../components/ui/primitives.jsx';

export default function ForgotPasswordPage() {
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await authApi.requestPasswordReset({ email });
      setSent(true);
    } catch (err) {
      toast.error(err.userMessage || 'Could not request reset.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-ink-900 to-ink-700 p-4">
      <Card className="w-full max-w-md p-6">
        <h1 className="text-lg font-semibold text-ink-900">Reset your password</h1>
        <p className="mt-1 text-sm text-slate-500">
          Enter your email and we'll send reset instructions if the account exists.
        </p>
        {sent ? (
          <div className="mt-6 flex flex-col items-center text-center">
            <div className="mb-3 rounded-full bg-emerald-50 p-3 text-emerald-600">
              <MailCheck className="h-6 w-6" />
            </div>
            <p className="text-sm text-slate-600">
              If an account exists for <strong>{email}</strong>, a reset link is on
              its way.
            </p>
            <Link to="/login" className="mt-4 text-sm text-brand-600 hover:underline">
              Back to login
            </Link>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="mt-4 space-y-4">
            <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <Button type="submit" className="w-full" loading={loading}>
              Send reset link
            </Button>
            <Link to="/login" className="block text-center text-sm text-brand-600 hover:underline">
              Back to login
            </Link>
          </form>
        )}
      </Card>
    </div>
  );
}
