/**
 * LoginPage — Enterprise IAM login page redesigned to match reference site.
 *
 * Reference: https://dpdpa-dashboard.adapid.link/
 *
 * Design changes:
 *  - Left panel: Dark navy (#0f172a) with subtle grid pattern overlay
 *  - Right panel: Clean white with centered form
 *  - Color palette: Cyan/Blue accent (#0ea5e9) for buttons and highlights
 *  - Typography: Clean sans-serif with proper hierarchy
 *  - Form styling: Minimalist with clear labels and focus states
 *
 * Spacing optimizations:
 *  - Reduced all vertical spacing to fit within single viewport
 *  - Copyright pushed to bottom with mt-auto
 *  - Tighter padding on both panels
 *
 * Layout:
 *  ┌─────────────────────────────────┬─────────────────────┐
 *  │         Dark Navy               │                     │
 *  │         + Grid Pattern          │     White Panel     │
 *  │  [Logo]                         │     Login Form      │
 *  │  [Large Heading]                │                     │
 *  │  [Feature List]                 │                     │
 *  │  [Copyright (bottom)]           │                     │
 *  └─────────────────────────────────┴─────────────────────┘
 */
import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ShieldCheck, KeyRound, Monitor, Lock, Globe } from 'lucide-react';
import { Logo } from '../../components/common/Logo.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { authApi } from '../../lib/api/auth.js';
import { ssoFailureMessage } from '../../utils/errors.js';

import { classNames } from '../../utils/format.js';

const PROVIDERS = (import.meta.env.VITE_SSO_PROVIDERS || 'entra_id')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

/** Operator-facing provider names — never the raw provider key. */
const PROVIDER_LABEL = {
  entra_id: 'Microsoft',
  microsoft: 'Microsoft',
  google: 'Google',
  okta: 'Okta',
};

const providerLabel = (p) =>
  PROVIDER_LABEL[String(p || '').toLowerCase()] ||
  String(p || 'your identity provider').replace(/[_-]+/g, ' ');

function MicrosoftLogo() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      x="0"
      y="0"
      width="20"
      height="20"
      viewBox="0 0 48 48"
      aria-hidden="true"
      focusable="false"
    >
      <path fill="#ff5722" d="M6 6H22V22H6z" transform="rotate(-180 14 14)"></path>
      <path fill="#4caf50" d="M26 6H42V22H26z" transform="rotate(-180 34 14)"></path>
      <path fill="#ffc107" d="M26 26H42V42H26z" transform="rotate(-180 34 34)"></path>
      <path fill="#03a9f4" d="M6 26H22V42H6z" transform="rotate(-180 14 34)"></path>
    </svg>
  );
}

export default function LoginPage() {
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [form, setForm] = useState({ identifier: '', password: '', accountId: '' });
  const [loading, setLoading] = useState(false);
  const [ssoLoading, setSsoLoading] = useState(null);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await login(form);

      if (res.mfaRequired) {
        navigate('/login/mfa', { state: { challengeToken: res.challengeToken } });
        return;
      }

      toast.success('Welcome back!');
      navigate(location.state?.from?.pathname || '/', { replace: true });
    } catch (err) {
      /* Never expose what the backend said about the credentials — the api client
         has already reduced it to a safe sentence; this is only the fallback. */
      toast.error(err.userMessage || 'Sign-in failed. Check your details and try again.');
    } finally {
      setLoading(false);
    }
  };

  const startSso = async (provider) => {
    setSsoLoading(provider);
    try {
      const { authorization_url } = await authApi.ssoLogin(provider, window.location.origin);
      if (!authorization_url) throw new Error('no authorization url');
      window.location.href = authorization_url;
    } catch (err) {
      /* "Sign in with Microsoft" must never surface provider or deployment
         detail (invalid_client, redirect_uri mismatch, AADSTS codes, gateway
         pages). ssoFailureMessage() produces enterprise copy from the status
         alone and logs the real detail for engineers in development. */
      toast.error(ssoFailureMessage(err, providerLabel(provider)));
      setSsoLoading(null);
    }
  };

  return (
    <div className="h-screen overflow-hidden">
      <div className="flex h-screen w-screen flex-col md:flex-row">
        {/* ── Left Marketing Panel ── */}
        {/* Reference site: Dark navy background with subtle grid pattern */}
        {/* Optimized: Reduced padding and spacing for single-viewport fit */}
        <div className="relative flex-1 bg-[#0f172a] p-6 text-white md:min-h-screen">
          {/* Grid pattern overlay — matches reference site's subtle decorative grid */}
          <div
            className="absolute inset-0 opacity-[0.03]"
            aria-hidden="true"
            style={{
              backgroundImage: `
                linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px',
            }}
          />

          {/* Subtle gradient orbs for depth — reference site has soft ambient lighting */}
          <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
            <div className="absolute -left-20 -top-20 h-96 w-96 rounded-full bg-[#0ea5e9]/10 blur-3xl" />
            <div className="absolute -bottom-32 -right-32 h-[500px] w-[500px] rounded-full bg-[#0ea5e9]/5 blur-3xl" />
          </div>

          {/* Flex column with mt-auto to push copyright to bottom */}
          <div className="relative z-10 flex h-full flex-col">
            {/* Logo area — reduced margin */}
            <div className="mt-3">
              <div className="inline-flex items-center rounded-full bg-white/10 px-4 py-2 backdrop-blur-sm">
                <Logo size="lg" variant="clean" className="!h-18 !w-auto brightness-0 invert" />
              </div>
            </div>

            {/* Main heading — reference site style, reduced margin */}
            <h1 className="mt-4 text-4xl font-bold leading-tight md:text-5xl lg:text-[56px]">
              <span className="text-white">Identity</span>
              <br />
              <span className="text-[#0ea5e9]">and Access</span>
              <br />
              <span className="text-white">Management</span>
            </h1>

            {/* Subtitle — reduced margin */}
            <p className="mt-2 max-w-md text-base leading-relaxed text-slate-300">
              Sign in to manage identity, access &amp; integrations with secure authentication
              and centralized IAM control.
            </p>

            {/* Feature list — reference site style with icons, reduced margin */}
            <div className="mt-5 space-y-3">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0ea5e9]/20 backdrop-blur-sm">
                  <ShieldCheck className="h-5 w-5 text-[#0ea5e9]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Protected authentication flows</p>
                  <p className="text-xs text-slate-400">Enterprise-grade security</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0ea5e9]/20 backdrop-blur-sm">
                  <Lock className="h-5 w-5 text-[#0ea5e9]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">SSO support for your organization</p>
                  <p className="text-xs text-slate-400">Microsoft Entra ID integration</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0ea5e9]/20 backdrop-blur-sm">
                  <Globe className="h-5 w-5 text-[#0ea5e9]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Centralized access control</p>
                  <p className="text-xs text-slate-400">RBAC &amp; ABAC policies</p>
                </div>
              </div>
            </div>

            {/* Copyright — pushed to bottom with mt-auto */}
            <p className="mt-auto pt-6 text-xs text-slate-500">
              © 2026 Deep Algorithms Solutions • IAM Control Center
            </p>
          </div>
        </div>

        {/* ── Right Login Panel ── */}
        {/* PREMIUM COMPACT DESIGN: Tight, minimal, enterprise-grade feel */}
        {/* Register Tenant link prominently placed below the form card */}
        <div className="flex flex-1 items-center justify-center bg-gradient-to-br from-slate-50 to-white p-3 md:p-5">
          <div className="w-full max-w-[320px]">
            {/* Logo and header — PREMIUM: tight spacing, clean hierarchy */}
            <div className="mb-3 flex flex-col items-center text-center">
              <Logo size="xl" variant="topbar" className="!h-16 !w-auto" />
              <h2 className="mt-2.5 text-xl font-bold tracking-tight text-[#0f172a]">Welcome back</h2>
              <p className="mt-0.5 text-xs text-slate-500">
                Sign in to access the compliance dashboard
              </p>
            </div>

            {/* PREMIUM Login form card — tight padding, minimal spacing */}
            <div className="rounded-xl border border-slate-200/70 bg-white p-4 shadow-[0_4px_20px_rgb(0,0,0,0.03)]">
              <form onSubmit={onSubmit} className="space-y-2.5">
                {/* PREMIUM Username field — minimal padding, crisp styling */}
                <div>
                  <label htmlFor="identifier" className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Username
                  </label>
                  <input
                    id="identifier"
                    name="identifier"
                    type="text"
                    autoComplete="username"
                    value={form.identifier}
                    onChange={set('identifier')}
                    required
                    className="block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-[13px] text-[#0f172a] placeholder-slate-400 transition-all duration-150 focus:border-[#0ea5e9] focus:outline-none focus:ring-2 focus:ring-[#0ea5e9]/20"
                    placeholder="name@company.com"
                  />
                </div>

                {/* PREMIUM Password field — minimal padding */}
                <div>
                  <label htmlFor="password" className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Password
                  </label>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    value={form.password}
                    onChange={set('password')}
                    required
                    className="block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-[13px] text-[#0f172a] placeholder-slate-400 transition-all duration-150 focus:border-[#0ea5e9] focus:outline-none focus:ring-2 focus:ring-[#0ea5e9]/20"
                    placeholder="••••••••"
                  />
                </div>

                {/* PREMIUM Account ID field — minimal spacing with helper text */}
                <div>
                  <label htmlFor="accountId" className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Account ID (tenant)
                  </label>
                  <input
                    id="accountId"
                    name="accountId"
                    type="text"
                    required
                    value={form.accountId}
                    onChange={set('accountId')}
                    className="block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-[13px] text-[#0f172a] placeholder-slate-400 transition-all duration-150 focus:border-[#0ea5e9] focus:outline-none focus:ring-2 focus:ring-[#0ea5e9]/20"
                    placeholder="ACC-XXXXXXXX"
 />
                  <p className="mt-0.5 text-[10px] text-slate-400">Required by the backend login contract.</p>
                </div>

                 {/* PREMIUM Forgot password — inline with fields */}
                <div className="flex items-center justify-end">
                  <a
                    className="text-[11px] font-medium text-[#0ea5e9] hover:text-[#0284c7] transition-colors"
                    href="/login/forgot"
                  >
                    Forgot password?
                  </a>
                </div>

                {/* PREMIUM Sign in button — tight, clean */}
                <button
                  type="submit"
                  disabled={loading}
                  className={classNames(
                    'flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2 text-[13px] font-semibold text-white transition-all duration-150',
                    loading
                      ? 'bg-[#0ea5e9]/70 cursor-not-allowed'
                      : 'bg-gradient-to-r from-[#0ea5e9] to-[#0284c7] hover:from-[#0284c7] hover:to-[#0369a1] hover:shadow-md hover:shadow-[#0ea5e9]/25 active:scale-[0.98]'
                  )}
                >
                  {loading ? (
                    <svg className="h-3.5 w-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  ) : (
                    <KeyRound className="h-3.5 w-3.5" />
                  )}
                  {loading ? 'Signing in...' : 'Sign in securely'}
                </button>
              </form>

              {/* PREMIUM SSO Section — tight divider */}
              {PROVIDERS.length > 0 && (
                <>
                  {/* <div className="my-3 flex items-center gap-2">
                    <span className="h-px flex-1 bg-slate-200" />
                    <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">or</span>
                    <span className="h-px flex-1 bg-slate-200" />
                  </div> */}

                  {/* <div className="space-y-1.5">
                    {PROVIDERS.map((p) => (
                      <button
                        key={p}
                        type="button"
                        disabled={ssoLoading === p}
                        onClick={() => startSso(p)}
                        className={classNames(
                          'flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[12px] font-medium text-[#0f172a] transition-all duration-150',
                          ssoLoading === p
                            ? 'opacity-70 cursor-not-allowed'
                            : 'hover:border-slate-300 hover:bg-slate-50 hover:shadow-sm active:scale-[0.98]'
                        )}
                      >
                        {ssoLoading === p ? (
                          <svg className="h-3.5 w-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                        ) : (
                          p === 'entra_id' ? <MicrosoftLogo /> : <Monitor className="h-3 w-3" />
                        )}
                        {p === 'entra_id' ? 'Sign in with Microsoft' : `Sign in with ${providerLabel(p)}`}
                      </button>
                    ))}
                  </div> */}
                </>
              )}
            </div>

            {/* RESTORED Register Tenant link — prominent, clean, premium */}
            <p className="mt-3 text-center text-[12px] text-slate-500">
              Don't have an account?{' '}
              <a href="/register-tenant" className="font-semibold text-[#0ea5e9] hover:text-[#0284c7] transition-colors">
                Register Tenant
              </a>
            </p>

            {/* PREMIUM Footer — subtle */}
            <p className="mt-2 text-center text-[10px] text-slate-400">
              Protected by your organization's IAM platform.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
