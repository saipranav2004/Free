/**
 * RegisterPage — gated user account registration.
 *
 * SUPER-ADMIN GATE: before the registration form appears, the visitor must
 * enter super_admin_key + super_admin_password (verified against the
 * super_admin table). On success → 15-min Redis token issued → form shown.
 *
 * The POST /api/v1/auth/register call includes X-Super-Admin-Token header.
 * Without a valid token, the backend returns 403.
 *
 * Backend: add @require_super_admin to the RegisterAPI MethodView.
 */
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShieldCheck, KeyRound, Lock, Eye, EyeOff, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { authApi } from '../../lib/api/auth.js';
import { Button, Input, Card } from '../../components/ui/primitives.jsx';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000';

export default function RegisterPage() {
  const toast = useToast();
  const navigate = useNavigate();

  // ── STEP: 'gate' → 'register' ──
  const [step, setStep] = useState('gate');
  const [saToken, setSaToken] = useState('');

  // ── Gate form ──
  const [gate, setGate] = useState({ super_admin_key: '', super_admin_password: '' });
  const [gateLoading, setGateLoading] = useState(false);
  const [gateError, setGateError] = useState(null);
  const [showPw, setShowPw] = useState(false);

  // ── Registration form ──
  const [form, setForm] = useState({ username: '', email: '', password: '', confirm_password: '' });
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  // ═══════════════════════════════════════
  //  GATE: verify super-admin
  // ═══════════════════════════════════════
  const onGateSubmit = async (e) => {
    e.preventDefault();
    if (gateLoading) return;
    setGateError(null);

    if (!gate.super_admin_key.trim() || !gate.super_admin_password) {
      setGateError('Both key and password are required.');
      return;
    }

    setGateLoading(true);
    try {
      const resp = await fetch(`${API_BASE}/api/v1/super-admin/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          super_admin_key: gate.super_admin_key.trim(),
          super_admin_password: gate.super_admin_password,
        }),
      });
      const json = await resp.json();

      if (!resp.ok || !json.success) {
        throw new Error(json?.error || 'Invalid super-admin credentials.');
      }

      setSaToken(json.data.token);
      setStep('register');
      toast.success('Verified. You can now create an account.');
    } catch (err) {
      setGateError(err.message || 'Verification failed.');
    } finally {
      setGateLoading(false);
    }
  };

  // ═══════════════════════════════════════
  //  REGISTRATION
  // ═══════════════════════════════════════
  const onSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm_password) {
      toast.error('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      // Use fetch directly so we can pass the X-Super-Admin-Token header.
      // If your authApi.register supports a headers arg, use that instead.
      const resp = await fetch(`${API_BASE}/api/v1/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Super-Admin-Token': saToken,
        },
        body: JSON.stringify(form),
      });
      const json = await resp.json();

      if (!resp.ok || !json.success) {
        throw new Error(json?.error?.message || json?.error || json?.message || 'Registration failed.');
      }

      toast.success('Account created. You can now sign in.');
      navigate('/login');
    } catch (err) {
      toast.error(err.message || err.userMessage || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  // ═══════════════════════════════════════
  //  RENDER
  // ═══════════════════════════════════════
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-ink-900 to-ink-700 p-4">
      <Card className="w-full max-w-md p-6">
        <div className="mb-4 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500 text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-semibold text-ink-900">
            {step === 'gate' ? 'Super-admin access' : 'Create your account'}
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {step === 'gate'
              ? 'Enter your super-admin credentials to continue.'
              : 'Fill in your details to create an IAM account.'}
          </p>
        </div>

        {/* ═══ STEP 1: GATE ═══ */}
        {step === 'gate' && (
          <>
            {gateError && (
              <div className="mb-4 flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{gateError}</span>
              </div>
            )}

            <form onSubmit={onGateSubmit} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-ink-900">
                  Super-admin key
                </label>
                <div className="relative">
                  <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    autoComplete="off"
                    value={gate.super_admin_key}
                    onChange={(e) => {
                      setGate((g) => ({ ...g, super_admin_key: e.target.value }));
                      setGateError(null);
                    }}
                    placeholder="Enter your super-admin key"
                    className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-10 pr-3 text-sm text-ink-900 placeholder-slate-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium text-ink-900">
                  Super-admin password
                </label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type={showPw ? 'text' : 'password'}
                    autoComplete="off"
                    value={gate.super_admin_password}
                    onChange={(e) => {
                      setGate((g) => ({ ...g, super_admin_password: e.target.value }));
                      setGateError(null);
                    }}
                    placeholder="Enter your super-admin password"
                    className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-10 pr-10 text-sm text-ink-900 placeholder-slate-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    tabIndex={-1}
                  >
                    {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <Button type="submit" className="w-full" loading={gateLoading}>
                {gateLoading ? 'Verifying…' : 'Verify & continue'}
              </Button>
            </form>
          </>
        )}

        {/* ═══ STEP 2: REGISTRATION ═══ */}
        {step === 'register' && (
          <>
            <div className="mb-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>Super-admin verified. You may create an account.</span>
            </div>

            <form onSubmit={onSubmit} className="space-y-4">
              <Input label="Username" name="username" value={form.username} onChange={set('username')} required />
              <Input label="Email" type="email" name="email" value={form.email} onChange={set('email')} required />
              <Input
                label="Password"
                type="password"
                name="password"
                value={form.password}
                onChange={set('password')}
                required
                hint="Min 10 chars; upper, lower, digit & special."
              />
              <Input
                label="Confirm password"
                type="password"
                name="confirm_password"
                value={form.confirm_password}
                onChange={set('confirm_password')}
                required
              />
              <Button type="submit" className="w-full" loading={loading}>
                Register
              </Button>
            </form>
          </>
        )}

        <p className="mt-4 text-center text-sm text-slate-500">
          Already have an account?{' '}
          <Link to="/login" className="text-brand-600 hover:underline">
            Sign in
          </Link>
        </p>
      </Card>
    </div>
  );
}
