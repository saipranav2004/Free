import { useState, useEffect, useMemo } from 'react';
import {
  MonitorSmartphone, LogOut, MapPin, Clock, Laptop, Smartphone,
  Tablet, Globe, Shield,
} from 'lucide-react';
import { useToast } from '../context/ToastContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import { Card, Button, Badge, Spinner, EmptyState } from '../components/ui/primitives.jsx';
import { ConfirmDialog } from '../components/ui/ConfirmDialog.jsx';
import { formatDateTime, formatRelative, classNames } from '../utils/format.js';

/**
 * Parse user-agent string to extract device type and browser info.
 * Enterprise pattern: show meaningful device type instead of raw UA string.
 */
function parseUserAgent(ua = '') {
  if (!ua) return { type: 'unknown', icon: Globe, label: 'Unknown Device', browser: '', os: '' };

  const lower = ua.toLowerCase();

  // Detect device type
  let type = 'desktop';
  let Icon = Laptop;
  if (/android|iphone|ipad|mobile/i.test(lower)) {
    if (/ipad|tablet/i.test(lower)) {
      type = 'tablet';
      Icon = Tablet;
    } else {
      type = 'mobile';
      Icon = Smartphone;
    }
  }

  // Detect browser
  let browser = 'Unknown Browser';
  if (/chrome/i.test(lower) && !/edg/i.test(lower)) browser = 'Chrome';
  else if (/firefox/i.test(lower)) browser = 'Firefox';
  else if (/safari/i.test(lower) && !/chrome/i.test(lower)) browser = 'Safari';
  else if (/edg/i.test(lower)) browser = 'Edge';
  else if (/opera|opr/i.test(lower)) browser = 'Opera';

  // Detect OS
  let os = '';
  if (/windows/i.test(lower)) os = 'Windows';
  else if (/mac os/i.test(lower)) os = 'macOS';
  else if (/linux/i.test(lower)) os = 'Linux';
  else if (/android/i.test(lower)) os = 'Android';
  else if (/iphone|ipad/i.test(lower)) os = 'iOS';

  const label = os ? `${browser} on ${os}` : browser;

  return { type, icon: Icon, label, browser, os };
}

/**
 * Format the login method into a human-readable badge label.
 */
function loginMethodBadge(method) {
  const map = {
    PASSWORD: { label: 'Password', tone: 'slate' },
    SSO: { label: 'SSO', tone: 'brand' },
    REFRESH: { label: 'Token', tone: 'sky' },
  };
  return map[method] || { label: method || 'Session', tone: 'slate' };
}

/**
 * Premium Active Sessions page.
 *
 * Enterprise refinements (Google Account / Microsoft Account / CyberArk patterns):
 *  - "This device" pinned to top with prominent visual treatment
 *  - Device-type icons (laptop, phone, tablet) from user-agent parsing
 *  - Information hierarchy: Device → Context → Metadata
 *  - Relative time displayed prominently, absolute time as secondary
 *  - Polished card design with better spacing and visual separation
 *  - Gradient accent on the current device card
 */
export default function SessionsPage() {
  const toast = useToast();
  const sessions = useResource(() => sessionsApi.list(), []);
  const [revokeId, setRevokeId] = useState(null);
  const [revokeAll, setRevokeAll] = useState(false);
  const [busy, setBusy] = useState(false);

  const doRevoke = async () => {
    setBusy(true);
    try {
      await sessionsApi.revoke(revokeId);
      toast.success('Session revoked.');
      sessions.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke session.');
    } finally {
      setBusy(false);
      setRevokeId(null);
    }
  };

  const doRevokeAll = async () => {
    setBusy(true);
    try {
      await sessionsApi.logout(true, null);
      toast.success('All other sessions signed out.');
      sessions.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke sessions.');
    } finally {
      setBusy(false);
      setRevokeAll(false);
    }
  };

  const data = Array.isArray(sessions.data) ? sessions.data : [];

  // Track the current session to distinguish it from other sessions
  const [currentSessionId, setCurrentSessionId] = useState(null);
  useEffect(() => {
    if (data.length > 0 && !currentSessionId) {
      setCurrentSessionId(data[0]?.session_id);
    }
  }, [data]);

  // Premium: sort sessions — "This device" always first
  const sortedData = useMemo(() => {
    if (!currentSessionId) return data;
    return [...data].sort((a, b) => {
      if (a.session_id === currentSessionId) return -1;
      if (b.session_id === currentSessionId) return 1;
      return 0;
    });
  }, [data, currentSessionId]);

  const otherSessionsCount = data.filter(s => s.session_id !== currentSessionId).length;

  return (
    <div>
      <PageHeader
        title="Active Sessions"
        description="Devices and sessions currently authenticated to your account."
        icon={<MonitorSmartphone className="h-5 w-5" />}
        actions={
          otherSessionsCount > 0 ? (
            <Button variant="danger" onClick={() => setRevokeAll(true)}>
              <LogOut className="h-4 w-4" /> Sign out all other sessions
            </Button>
          ) : null
        }
      />

      {/* Premium: session count summary */}
      {data.length > 0 && (
        <div className="mb-4 flex items-center gap-3 text-sm text-slate-500">
          <Shield className="h-4 w-4 text-brand-500" />
          <span>
            <span className="font-semibold text-ink-800">{data.length}</span> active session{data.length !== 1 ? 's' : ''}
            {otherSessionsCount > 0 && (
              <span className="text-slate-400"> ({otherSessionsCount} other device{otherSessionsCount !== 1 ? 's' : ''})</span>
            )}
          </span>
        </div>
      )}

      {sessions.loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          icon={MonitorSmartphone}
          title="No active sessions"
          description="We couldn't find any active sessions for your account."
        />
      ) : (
        <div className="space-y-3">
          {sortedData.map((s, idx) => {
            const isCurrentRow = s.session_id === currentSessionId;
            const device = parseUserAgent(s.user_agent);
            const method = loginMethodBadge(s.login_method);
            const DeviceIcon = device.icon;

            return (
              <Card
                key={s.session_id}
                className={classNames(
                  'flex flex-col p-0 overflow-hidden transition-all duration-200',
                  isCurrentRow
                    ? // Premium: current device gets a prominent left border accent + subtle bg tint
                      'ring-2 ring-brand-200/60 border-brand-200 bg-gradient-to-r from-brand-50/30 to-white'
                    : 'hover:shadow-md hover:shadow-slate-100'
                )}
              >
                <div className="flex items-start gap-4 p-5">
                  {/* Premium: device type icon with contextual color */}
                  <div className={classNames(
                    'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl',
                    isCurrentRow
                      ? 'bg-brand-100 text-brand-600'
                      : 'bg-slate-100 text-slate-500'
                  )}>
                    <DeviceIcon className="h-5 w-5" />
                  </div>

                  {/* Main content area */}
                  <div className="flex-1 min-w-0">
                    {/* Top row: device label + badges */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-ink-900">
                        {device.label}
                      </span>
                      <span className={classNames(
                        'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ring-1 ring-inset',
                        method.tone === 'brand'
                          ? 'bg-brand-50 text-brand-700 ring-brand-600/20'
                          : method.tone === 'sky'
                            ? 'bg-sky-50 text-sky-700 ring-sky-600/20'
                            : 'bg-slate-100 text-slate-600 ring-slate-500/20'
                      )}>
                        {method.label}
                      </span>
                      {isCurrentRow && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                          This device
                        </span>
                      )}
                    </div>

                    {/* Metadata row — Premium: better hierarchy */}
                    <div className="mt-2 flex items-center gap-4 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-slate-400" />
                        {s.ip_address || 'Unknown IP'}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Globe className="h-3 w-3 text-slate-400" />
                        {device.browser || 'Unknown'}
                        {device.os && <span className="text-slate-400">· {device.os}</span>}
                      </span>
                    </div>

                    {/* Time row — Premium: relative time prominent, absolute secondary */}
                    <div className="mt-1.5 flex items-center gap-4 text-xs text-slate-400">
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span className="font-medium text-slate-500">{formatRelative(s.issued_at)}</span>
                        <span className="text-slate-400">·</span>
                        <span>{formatDateTime(s.issued_at)}</span>
                      </span>
                      {s.expires_at && (
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Expires {formatRelative(s.expires_at)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Action area */}
                  <div className="flex shrink-0 items-center">
                    {isCurrentRow ? (
                      <div className="flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700">
                        <Shield className="h-3.5 w-3.5" />
                        Active
                      </div>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setRevokeId(s.session_id)}
                        className="text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                      >
                        <LogOut className="h-4 w-4" /> Revoke
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <ConfirmDialog
        open={!!revokeId}
        onClose={() => setRevokeId(null)}
        onConfirm={doRevoke}
        danger
        loading={busy}
        title="Revoke session"
        message="This will immediately sign out that device. The user will need to authenticate again."
      />
      <ConfirmDialog
        open={revokeAll}
        onClose={() => setRevokeAll(false)}
        onConfirm={doRevokeAll}
        danger
        loading={busy}
        title="Sign out all other sessions"
        message={`This will terminate ${otherSessionsCount} other active session${otherSessionsCount !== 1 ? 's' : ''}. You will remain signed in on this device.`}
      />
    </div>
  );
}


