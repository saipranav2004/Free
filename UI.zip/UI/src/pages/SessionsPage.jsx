import { useState, useEffect, useMemo } from 'react';
import {
  MonitorSmartphone, LogOut, MapPin, Clock, Laptop, Smartphone,
  Tablet, Globe, Shield,
} from 'lucide-react';
import { useToast } from '../context/ToastContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import { Button, Badge, Spinner, EmptyState, IconButton } from '../components/ui/primitives.jsx';
import { ConfirmDialog } from '../components/ui/ConfirmDialog.jsx';
import { formatDateTime, formatRelative, classNames } from '../utils/format.js';

/**
 * Parse user-agent string to extract device type and browser info.
 * Enterprise pattern: show meaningful device type instead of raw UA string.
 */
function parseUserAgent(ua = '') {
  if (!ua) return { type: 'unknown', icon: Globe, label: 'Unknown Device', browser: '', os: '' };

  const lower = ua.toLowerCase();

  // Detect device type
  let type = 'desktop';
  let Icon = Laptop;
  if (/android|iphone|ipad|mobile/i.test(lower)) {
    if (/ipad|tablet/i.test(lower)) {
      type = 'tablet';
      Icon = Tablet;
    } else {
      type = 'mobile';
      Icon = Smartphone;
    }
  }

  // Detect browser
  let browser = 'Unknown Browser';
  if (/chrome/i.test(lower) && !/edg/i.test(lower)) browser = 'Chrome';
  else if (/firefox/i.test(lower)) browser = 'Firefox';
  else if (/safari/i.test(lower) && !/chrome/i.test(lower)) browser = 'Safari';
  else if (/edg/i.test(lower)) browser = 'Edge';
  else if (/opera|opr/i.test(lower)) browser = 'Opera';

  // Detect OS
  let os = '';
  if (/windows/i.test(lower)) os = 'Windows';
  else if (/mac os/i.test(lower)) os = 'macOS';
  else if (/linux/i.test(lower)) os = 'Linux';
  else if (/android/i.test(lower)) os = 'Android';
  else if (/iphone|ipad/i.test(lower)) os = 'iOS';

  const label = os ? `${browser} on ${os}` : browser;

  return { type, icon: Icon, label, browser, os };
}

/**
 * Format the login method into a human-readable badge label.
 */
function loginMethodBadge(method) {
  const map = {
    PASSWORD: { label: 'Password', tone: 'slate' },
    SSO: { label: 'SSO', tone: 'brand' },
    REFRESH: { label: 'Token', tone: 'sky' },
  };
  return map[method] || { label: method || 'Session', tone: 'slate' };
}

/**
 * Premium Active Sessions page.
 *
 * Enterprise refinements (Google Account / Microsoft Account / CyberArk patterns):
 *  - "This device" pinned to top with prominent visual treatment
 *  - Device-type icons (laptop, phone, tablet) from user-agent parsing
 *  - Information hierarchy: Device → Context → Metadata
 *  - Relative time displayed prominently, absolute time as secondary
 *  - Polished card design with better spacing and visual separation
 *  - Gradient accent on the current device card
 */
export default function SessionsPage() {
  const toast = useToast();
  const sessions = useResource(() => sessionsApi.list(), []);
  const [revokeId, setRevokeId] = useState(null);
  const [revokeAll, setRevokeAll] = useState(false);
  const [busy, setBusy] = useState(false);

  const doRevoke = async () => {
    setBusy(true);
    try {
      await sessionsApi.revoke(revokeId);
      toast.success('Session revoked.');
      sessions.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke session.');
    } finally {
      setBusy(false);
      setRevokeId(null);
    }
  };

  const doRevokeAll = async () => {
    setBusy(true);
    try {
      await sessionsApi.logout(true, null);
      toast.success('All other sessions signed out.');
      sessions.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke sessions.');
    } finally {
      setBusy(false);
      setRevokeAll(false);
    }
  };

  const data = Array.isArray(sessions.data) ? sessions.data : [];

  // Track the current session to distinguish it from other sessions
  const [currentSessionId, setCurrentSessionId] = useState(null);
  useEffect(() => {
    if (data.length > 0 && !currentSessionId) {
      setCurrentSessionId(data[0]?.session_id);
    }
  }, [data]);

  // Premium: sort sessions — "This device" always first
  const sortedData = useMemo(() => {
    if (!currentSessionId) return data;
    return [...data].sort((a, b) => {
      if (a.session_id === currentSessionId) return -1;
      if (b.session_id === currentSessionId) return 1;
      return 0;
    });
  }, [data, currentSessionId]);

  const otherSessionsCount = data.filter(s => s.session_id !== currentSessionId).length;

  return (
    <div>
      <PageHeader
        title="Active sessions"
        description="Devices and sessions currently authenticated to your account."
        icon={<MonitorSmartphone className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Security' }, { label: 'Sessions' }]}
        actions={
          otherSessionsCount > 0 ? (
            <Button variant="danger" onClick={() => setRevokeAll(true)}>
              <LogOut className="h-4 w-4" /> Sign out all other sessions
            </Button>
          ) : null
        }
      />

      {/* Premium: session count summary */}
      {data.length > 0 && (
        <div className="mb-4 flex items-center gap-3 text-sm text-slate-500">
          <Shield className="h-4 w-4 text-brand-500" />
          <span>
            <span className="font-semibold text-ink-800">{data.length}</span> active session{data.length !== 1 ? 's' : ''}
            {otherSessionsCount > 0 && (
              <span className="text-slate-400"> ({otherSessionsCount} other device{otherSessionsCount !== 1 ? 's' : ''})</span>
            )}
          </span>
        </div>
      )}

      {sessions.loading ? (
        <div className="card flex justify-center py-16">
          <Spinner className="h-5 w-5" />
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          icon={MonitorSmartphone}
          title="No active sessions"
          description="We couldn't find any active sessions for your account."
        />
      ) : (
        /* One table-like surface instead of a stack of floating cards: sessions
           are a list to scan, and scanning is easier when rows share edges. */
        <div className="card overflow-hidden">
          <ul className="divide-y divide-line-soft">
            {sortedData.map((s) => {
              const isCurrentRow = s.session_id === currentSessionId;
              const device = parseUserAgent(s.user_agent);
              const method = loginMethodBadge(s.login_method);
              const DeviceIcon = device.icon;

              return (
                <li
                  key={s.session_id}
                  className={classNames(
                    'flex items-start gap-3.5 px-4 py-3.5 transition-colors sm:px-5',
                    isCurrentRow ? 'bg-brand-50/40' : 'hover:bg-slate-50/70'
                  )}
                >
                  <span
                    className={classNames(
                      'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
                      isCurrentRow ? 'bg-brand-50 text-brand-700' : 'bg-slate-100 text-slate-500'
                    )}
                  >
                    <DeviceIcon className="h-4 w-4" />
                  </span>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[13px] font-semibold text-ink-900">{device.label}</span>
                      <Badge tone={method.tone === 'brand' ? 'brand' : method.tone === 'sky' ? 'sky' : 'slate'}>
                        {method.label}
                      </Badge>
                      {isCurrentRow && (
                        <Badge tone="green" dot>
                          This device
                        </Badge>
                      )}
                    </div>

                    <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1.5">
                        <MapPin className="h-3 w-3 text-slate-400" />
                        <span className="font-mono">{s.ip_address || 'Unknown IP'}</span>
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Globe className="h-3 w-3 text-slate-400" />
                        {device.browser || 'Unknown'}
                        {device.os && <span className="text-slate-400">· {device.os}</span>}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Clock className="h-3 w-3 text-slate-400" />
                        Signed in {formatRelative(s.issued_at)}
                        <span className="text-slate-300">·</span>
                        <span className="text-slate-400">{formatDateTime(s.issued_at)}</span>
                      </span>
                      {s.expires_at && (
                        <span className="text-slate-400">Expires {formatRelative(s.expires_at)}</span>
                      )}
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center">
                    {isCurrentRow ? (
                      <span className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-400">
                        Current
                      </span>
                    ) : (
                      <IconButton
                        icon={LogOut}
                        title="Revoke this session"
                        tone="danger"
                        onClick={() => setRevokeId(s.session_id)}
                      />
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      <ConfirmDialog
        open={!!revokeId}
        onClose={() => setRevokeId(null)}
        onConfirm={doRevoke}
        danger
        loading={busy}
        title="Revoke session"
        message="This will immediately sign out that device. The user will need to authenticate again."
      />
      <ConfirmDialog
        open={revokeAll}
        onClose={() => setRevokeAll(false)}
        onConfirm={doRevokeAll}
        danger
        loading={busy}
        title="Sign out all other sessions"
        message={`This will terminate ${otherSessionsCount} other active session${otherSessionsCount !== 1 ? 's' : ''}. You will remain signed in on this device.`}
      />
    </div>
  );
}


