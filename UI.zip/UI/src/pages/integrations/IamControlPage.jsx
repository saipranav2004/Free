import { useState } from 'react';
import { Network, Activity, GitBranch, ShieldCheck, ShieldX } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { integrationApi } from '../../lib/api/integration.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea, Spinner, Badge } from '../../components/ui/primitives.jsx';
import { UserPicker } from '../../components/common/EntityPickers.jsx';
import { classNames } from '../../utils/format.js';

export default function IamControlPage() {
  const toast = useToast();
  const health = useResource(() => integrationApi.iamControl.health(), []);

  const [form, setForm] = useState({ user_id: '', action: '', resource_arn: '', resource_attributes: '' });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const decide = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    try {
      // iam_middleware.IAMConnectedApp.check() posts to /api/v1/authz/check.
      const res = await integrationApi.iamControl.decision({
        user_id: form.user_id,
        action: form.action,
        resource_arn: form.resource_arn,
        resource_attributes: form.resource_attributes.trim() ? JSON.parse(form.resource_attributes) : {},
      });
      setResult(res);
    } catch (err) {
      toast.error(err.userMessage || 'Decision request failed.');
    } finally {
      setLoading(false);
    }
  };

  const allowed = result?.allowed ?? result?.decision ?? result?.result;

  return (
    <div>
      <PageHeader
        title="IAM Control (as a Service)"
        description="Expose the Policy Decision Point (PDP) as a reusable, callable decision API for any connected service."
      />

      <div className="mb-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-700">
        <span>
          <code>iam_middleware.IAMConnectedApp</code> is a server-side SDK (not a microservice).
          Its <code>check()</code> calls <code>POST /api/v1/authz/check</code> — that is the IAM-Control
          decision surface used below, backed by the same OPA/AuthorizationService PDP.
        </span>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-1">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-brand-600" />
            <h3 className="text-sm font-semibold text-ink-900">PDP health</h3>
          </div>
          {health.loading ? (
            <div className="mt-3"><Spinner /></div>
          ) : health.error ? (
            <p className="mt-3 text-xs text-rose-600">{health.error}</p>
          ) : (
            <div className="mt-3">
              <Badge tone={health.data?.status === 'ok' || health.data?.status === 'healthy' ? 'green' : 'amber'}>
                {health.data?.status || 'reachable'}
              </Badge>
              <p className="mt-2 text-xs text-slate-400">
                {health.data?.version ? `version ${health.data.version}` : 'OPA + PDP reachability (GET /health)'}
              </p>
            </div>
          )}
        </Card>

        <Card className="p-5 lg:col-span-2">
          <h3 className="text-sm font-semibold text-ink-900">Evaluate a decision</h3>
          <form onSubmit={decide} className="mt-3 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <UserPicker
              value={form.user_id}
              onChange={(id) => setForm((f) => ({ ...f, user_id: id || '' }))}
              label="Principal"
              required
              hint="Resolved against the tenant directory."
            />
            <Input label="Action" value={form.action} onChange={set('action')} placeholder="m365:mail:Read" required />
            <Input label="Resource ARN" value={form.resource_arn} onChange={set('resource_arn')} placeholder="m365:tenant/default/mail" required />
            <Textarea label="Resource attributes (JSON)" rows={2} value={form.resource_attributes} onChange={set('resource_attributes')} className="font-mono text-xs" placeholder='{ "department": "eng" }' />
            <div className="sm:col-span-2">
              <Button type="submit" loading={loading}><GitBranch className="h-4 w-4" /> Decide</Button>
            </div>
          </form>

          {result != null && (
            <div className={classNames('mt-4 flex items-center gap-3 rounded-xl p-4', allowed ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700')}>
              {allowed ? <ShieldCheck className="h-6 w-6" /> : <ShieldX className="h-6 w-6" />}
              <div>
                <p className="text-sm font-semibold">{allowed ? 'ALLOW' : 'DENY'}</p>
                {result?.reason && <p className="text-xs opacity-80">{result.reason}</p>}
              </div>
            </div>
          )}
          {result != null && (
            <pre className="mt-4 max-h-72 overflow-auto rounded-lg bg-ink-900 p-3 text-xs text-emerald-200">
              {JSON.stringify(result, null, 2)}
            </pre>
          )}
        </Card>
      </div>

      <Card className="mt-6 p-5">
        <div className="flex items-center gap-2">
          <Network className="h-5 w-5 text-brand-600" />
          <h3 className="text-sm font-semibold text-ink-900">How connected services use this</h3>
        </div>
        <p className="mt-2 text-sm text-slate-500">
          A downstream service instantiates <code>IAMConnectedApp(iam_base_url, service_token)</code> and
          decorates protected routes with <code>@app.enforce(action, resource_arn_builder)</code>. Every request
          is forwarded to <code>POST /api/v1/authz/check</code>; the PDP returns{' '}
          <code>{'{ "allowed": true|false, "reason": "..." }'}</code>. Use the simulator above to preview
          exactly what a connected app would receive for any principal/action/resource.
        </p>
      </Card>
    </div>
  );
}
