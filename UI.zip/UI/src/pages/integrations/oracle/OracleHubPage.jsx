import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Database, Plus, Server, ShieldCheck } from 'lucide-react';
import { useResource } from '../../../hooks/useResource.js';
import { useToast } from '../../../context/ToastContext.jsx';
import { PageHeader } from '../../../components/common/PageHeader.jsx';
import { Card, Button, Badge, EmptyState, Spinner, Input } from '../../../components/ui/primitives.jsx';
import { Modal } from '../../../components/ui/Modal.jsx';
import { oracleApi } from '../../../lib/api/oracle.js';

function ConnectionCard({ conn, onDelete }) {
  const navigate = useNavigate();
  return (
    <Card className="flex flex-col p-5">
      <div className="flex items-start justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
          <Server className="h-5 w-5" />
        </div>
        <Badge tone={conn.status === 'ACTIVE' ? 'green' : 'amber'}>{conn.status || 'ACTIVE'}</Badge>
      </div>
      <h3 className="mt-3 text-sm font-semibold text-ink-900">{conn.name}</h3>
      <p className="mt-1 text-xs text-slate-500">
        {conn.host}:{conn.port} · {conn.service_name}
      </p>
      <p className="mt-1 text-xs text-slate-400">Admin: {conn.admin_user}</p>
      <div className="mt-4 flex items-center justify-between">
        <Button size="sm" variant="secondary" onClick={() => navigate(`/integrations/oracle/${conn.connection_id}`)}>
          Manage
        </Button>
        <Button size="sm" variant="ghost" onClick={() => onDelete(conn)}>
          Remove
        </Button>
      </div>
    </Card>
  );
}

function RegisterModal({ open, onClose, onCreated }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    name: '', host: '', port: '1521', service_name: '', admin_user: '', password: '', ssl: false,
  });
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await oracleApi.registerConnection({
        ...form,
        port: Number(form.port) || 1521,
        ssl: !!form.ssl,
      });
      toast.success('Oracle connection registered.');
      onCreated();
      onClose();
    } catch (err) {
      toast.error(err.userMessage || 'Could not register connection.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Register Oracle DB connection"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} loading={busy}>Register</Button>
        </>
      }
    >
      <form onSubmit={submit} className="space-y-4">
        <Input label="Name" value={form.name} onChange={set('name')} required hint="A friendly label for this database." />
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2">
            <Input label="Host" value={form.host} onChange={set('host')} required />
          </div>
          <Input label="Port" value={form.port} onChange={set('port')} required />
        </div>
        <Input label="Service name" value={form.service_name} onChange={set('service_name')} required />
        <Input label="Admin user" value={form.admin_user} onChange={set('admin_user')} required />
        <Input label="Admin password" type="password" value={form.password} onChange={set('password')} required />
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input type="checkbox" checked={form.ssl} onChange={(e) => setForm((f) => ({ ...f, ssl: e.target.checked }))} />
          Use TCPS / wallet (SSL)
        </label>
      </form>
    </Modal>
  );
}

export default function OracleHubPage() {
  const toast = useToast();
  const navigate = useNavigate();
  const connections = useResource(() => oracleApi.listConnections(), []);
  const [registerOpen, setRegisterOpen] = useState(false);

  const confirmDelete = async (conn) => {
    if (!window.confirm(`Remove Oracle connection "${conn.name}"? This also clears its IAM grant ledger.`)) return;
    try {
      await oracleApi.deleteConnection(conn.connection_id);
      toast.success('Connection removed.');
      connections.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not remove connection.');
    }
  };

  const rows = Array.isArray(connections.data) ? connections.data : [];

  return (
    <div>
      <PageHeader
        title="Oracle Database"
        description="Oracle DB is exposed as a fully IAM-governed target. Register a database, then control every action through IAM policies (PBAC/RBAC) enforced server-side by the OPA PDP — the root admin holds implicit full access and delegates scoped access via policies attached to users/roles."
        icon={<Database className="h-5 w-5" />}
        actions={<Button onClick={() => setRegisterOpen(true)}><Plus className="h-4 w-4" /> Register</Button>}
      />

      <div className="mb-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-700">
        <ShieldCheck className="h-4 w-4" />
        All Oracle actions are enforced by the IAM PDP (OPA). The root admin has implicit full
        access; every other principal is governed by <code>oracle:*</code> policies attached to
        their user/roles (PBAC/RBAC).
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5 text-brand-600" />
            <h3 className="text-sm font-semibold text-ink-900">Registered Oracle databases</h3>
          </div>
          <Button size="sm" variant="secondary" onClick={connections.reload} loading={connections.loading}>
            Reload
          </Button>
        </div>

        <div className="mt-4">
          {connections.loading ? (
            <div className="py-10 text-center"><Spinner /></div>
          ) : rows.length ? (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
              {rows.map((c) => (
                <ConnectionCard key={c.connection_id} conn={c} onDelete={confirmDelete} />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={Database}
              title="No Oracle databases"
              description="Register your first Oracle DB connection to start managing access from IAM."
            />
          )}
        </div>
      </Card>

      <RegisterModal open={registerOpen} onClose={() => setRegisterOpen(false)} onCreated={() => connections.reload()} />
    </div>
  );
}
