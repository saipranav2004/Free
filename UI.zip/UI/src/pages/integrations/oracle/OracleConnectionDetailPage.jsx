import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, Database, Plus, KeyRound, Lock, Unlock, Trash2, UserPlus,
} from 'lucide-react';
import { useResource } from '../../../hooks/useResource.js';
import { useToast } from '../../../context/ToastContext.jsx';
import { PageHeader } from '../../../components/common/PageHeader.jsx';
import {
  Card, Button, Badge, EmptyState, Spinner, Input, Tabs,
} from '../../../components/ui/primitives.jsx';
import { Modal } from '../../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.jsx';
import { oracleApi } from '../../../lib/api/oracle.js';

/* ----------------------------- Provision modal ----------------------------- */
function ProvisionModal({ connectionId, onClose, onCreated }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ db_user: '', password: '', iam_user_id: '' });
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await oracleApi.provisionUser(connectionId, {
        db_user: form.db_user,
        password: form.password,
        iam_user_id: form.iam_user_id || undefined,
      });
      toast.success('DB account provisioned.');
      onCreated();
      onClose();
    } catch (err) {
      toast.error(err.userMessage || 'Could not provision account.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title="Provision Oracle DB account"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} loading={busy}>Provision</Button>
        </>
      }
    >
      <form onSubmit={submit} className="space-y-4">
        <Input label="DB username" value={form.db_user} onChange={set('db_user')} required hint="Oracle identifier (A-Z 0-9 _ $ #)." />
        <Input label="Password" type="password" value={form.password} onChange={set('password')} required />
        <Input label="Link to IAM user id (optional)" value={form.iam_user_id} onChange={set('iam_user_id')}
          hint="Records who in IAM owns this DB account in the grant ledger." />
      </form>
    </Modal>
  );
}

/* ----------------------------- Manage (grants) modal ----------------------------- */
function UserManageModal({ connectionId, dbUser, onClose, onChanged }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [priv, setPriv] = useState('');
  const [dropOpen, setDropOpen] = useState(false);
  const grants = useResource(() => oracleApi.listGrants(connectionId, dbUser), [connectionId, dbUser]);

  const doGrant = async (e) => {
    e.preventDefault();
    if (!priv.trim()) return;
    setBusy(true);
    try {
      await oracleApi.grant(connectionId, dbUser, { privilege_or_role: priv.trim() });
      toast.success(`Granted ${priv.trim()}.`);
      setPriv('');
      grants.reload();
      onChanged();
    } catch (err) {
      toast.error(err.userMessage || 'Could not grant.');
    } finally {
      setBusy(false);
    }
  };

  const doRevoke = async (p) => {
    setBusy(true);
    try {
      await oracleApi.revoke(connectionId, dbUser, { privilege_or_role: p });
      toast.success(`Revoked ${p}.`);
      grants.reload();
      onChanged();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke.');
    } finally {
      setBusy(false);
    }
  };

  const doState = async (locked) => {
    setBusy(true);
    try {
      if (locked) await oracleApi.lock(connectionId, dbUser);
      else await oracleApi.unlock(connectionId, dbUser);
      toast.success(locked ? 'Account locked.' : 'Account unlocked.');
      onChanged();
    } catch (err) {
      toast.error(err.userMessage || 'Action failed.');
    } finally {
      setBusy(false);
    }
  };

  const doDrop = async () => {
    setBusy(true);
    try {
      await oracleApi.dropUser(connectionId, dbUser, { cascade: true });
      toast.success('DB account dropped.');
      setDropOpen(false);
      onClose();
      onChanged();
    } catch (err) {
      toast.error(err.userMessage || 'Could not drop account.');
    } finally {
      setBusy(false);
    }
  };

  const grantRows = Array.isArray(grants.data) ? grants.data : [];

  return (
    <Modal
      open
      onClose={onClose}
      title={`Manage ${dbUser}`}
      footer={
        <div className="flex justify-between">
          <Button variant="danger" onClick={() => setDropOpen(true)} loading={busy}>
            <Trash2 className="h-4 w-4" /> Drop
          </Button>
          <Button variant="secondary" onClick={onClose}>Close</Button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => doState(true)} loading={busy}><Lock className="h-4 w-4" /> Lock</Button>
          <Button size="sm" variant="outline" onClick={() => doState(false)} loading={busy}><Unlock className="h-4 w-4" /> Unlock</Button>
        </div>

        <form onSubmit={doGrant} className="flex items-end gap-2">
          <Input label="Grant privilege / role (coarse)" value={priv} onChange={(e) => setPriv(e.target.value)}
            placeholder="e.g. CONNECT, SELECT ANY TABLE, DBA" required />
          <Button type="submit" loading={busy}><KeyRound className="h-4 w-4" /> Grant</Button>
        </form>

        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Current grants</p>
          {grants.loading ? (
            <div className="py-4 text-center"><Spinner /></div>
          ) : grantRows.length ? (
            <ul className="max-h-60 space-y-1.5 overflow-auto">
              {grantRows.map((g, i) => (
                <li key={i} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2">
                  <div>
                    <span className="text-sm font-medium text-ink-800">{g.privilege}</span>
                    <Badge tone="slate" className="ml-2">{g.kind}</Badge>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => doRevoke(g.privilege)}>Revoke</Button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-slate-400">No grants recorded.</p>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={dropOpen}
        onClose={() => setDropOpen(false)}
        onConfirm={doDrop}
        danger
        loading={busy}
        title="Drop DB account"
        message={`Permanently drop "${dbUser}" (CASCADE) from the Oracle database?`}
      />
    </Modal>
  );
}

/* ----------------------------- Query Console tab ----------------------------- */
function QueryTab({ connectionId }) {
  const toast = useToast();
  const [sql, setSql] = useState('SELECT 1 FROM DUAL');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const scope = useResource(() => oracleApi.getQueryScope(connectionId), [connectionId]);

  const scopeData = scope.data || {};

  const run = async () => {
    if (!sql.trim()) return;
    setBusy(true); setError(null); setResult(null);
    const t0 = performance.now();
    try {
      const r = await oracleApi.runQuery(connectionId, { sql, limit: 1000, timeout_ms: 30000 });
      setResult({ ...r, elapsed: Math.round(performance.now() - t0) });
      toast.success('Query executed.');
    } catch (e) {
      setError(e.userMessage || 'Query failed.');
    } finally { setBusy(false); }
  };

  return (
    <Card className="p-5">
      <div className="mb-4 flex items-center gap-2">
        <Database className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Query Console</h3>
        <span className="ml-auto text-xs text-slate-400">Executed within your IAM-granted scope</span>
      </div>

      {/* Permissions panel — fast policy check, no DB enumeration */}
      <div className="mb-4 rounded-lg border border-slate-100 bg-slate-50 p-3 text-xs">
        <p className="mb-1 font-semibold uppercase tracking-wide text-slate-500">Your permissions</p>
        {scope.loading ? (
          <p className="text-slate-400">Checking policy…</p>
        ) : scope.error ? (
          <p className="text-rose-600">Could not load permissions.</p>
        ) : scopeData.full_access ? (
          <p className="font-medium text-emerald-700">
            Full access — you may perform every Oracle action on this connection (root/admin).
          </p>
        ) : (
          <div>
            <p className="mb-2 text-slate-500">Allowed actions on this connection:</p>
            <div className="flex flex-wrap gap-1.5">
              {(scopeData.allowed_actions || []).map((a) => (
                <span key={a} className="rounded bg-brand-50 px-2 py-0.5 font-medium text-brand-700">{a}</span>
              ))}
              {(scopeData.allowed_actions || []).length === 0 && (
                <span className="text-rose-600">No Oracle actions permitted.</span>
              )}
            </div>
          </div>
        )}
      </div>

      <textarea
        className="w-full rounded-lg border border-slate-200 p-3 font-mono text-sm"
        rows={8}
        value={sql}
        onChange={(e) => setSql(e.target.value)}
        spellCheck={false}
      />

      <div className="mt-3 flex items-center gap-3">
        <Button onClick={run} loading={busy}><KeyRound className="h-4 w-4" /> Run query</Button>
        {result && (
          <span className="text-xs text-slate-500">
            {result.statement_type === 'DML'
              ? `${result.affected_rows} row(s) affected`
              : `${result.row_count} row(s)${result.truncated ? ' (truncated)' : ''}`}{' '}
            · {result.elapsed} ms
          </span>
        )}
      </div>

      {error && (
        <div className="mt-3 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{error}</div>
      )}

      {result && result.statement_type === 'QUERY' && (
        <div className="mt-4 overflow-auto rounded-lg border border-slate-100">
          {result.rows.length === 0 ? (
            <p className="p-4 text-sm text-slate-400">No rows returned.</p>
          ) : (
            <table className="min-w-full text-xs">
              <thead className="bg-slate-50 text-left">
                <tr>
                  {result.columns.map((c) => (
                    <th key={c} className="px-3 py-2 font-semibold text-slate-600">{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {result.rows.map((row, i) => (
                  <tr key={i}>
                    {result.columns.map((c) => (
                      <td key={c} className="px-3 py-1.5 text-ink-800">{String(row[c]) ?? ''}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </Card>
  );
}

/* ----------------------------- Page ----------------------------- */
export default function OracleConnectionDetailPage() {
  const { connectionId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [tab, setTab] = useState('users');
  const [manage, setManage] = useState(null);
  const [provisionOpen, setProvisionOpen] = useState(false);

  const conn = useResource(() => oracleApi.getConnection(connectionId), [connectionId]);
  const users = useResource(() => oracleApi.listUsers(connectionId), [connectionId]);

  const removeConnection = async () => {
    if (!window.confirm('Remove this Oracle connection and its IAM grant ledger?')) return;
    try {
      await oracleApi.deleteConnection(connectionId);
      toast.success('Connection removed.');
      navigate('/integrations/oracle');
    } catch (err) {
      toast.error(err.userMessage || 'Could not remove connection.');
    }
  };

  const userRows = Array.isArray(users.data) ? users.data : [];

  return (
    <div>
      <Link to="/integrations/oracle" className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700">
        <ArrowLeft className="h-4 w-4" /> Oracle databases
      </Link>

      <PageHeader
        title={conn.data?.name || 'Oracle connection'}
        description={conn.data ? `${conn.data.host}:${conn.data.port} · ${conn.data.service_name}` : 'Loading…'}
        icon={<Database className="h-5 w-5" />}
        actions={
          <Button variant="danger" onClick={removeConnection}><Trash2 className="h-4 w-4" /> Remove</Button>
        }
      />

      <Tabs
        tabs={[
          { id: 'users', label: 'DB Users', count: userRows.length },
          { id: 'query', label: 'Query Console' },
          { id: 'about', label: 'Connection' },
        ]}
        active={tab}
        onChange={setTab}
      />

      <div className="mt-5">
        {tab === 'users' && (
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-brand-600" />
                <h3 className="text-sm font-semibold text-ink-900">Database accounts</h3>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="secondary" onClick={users.reload} loading={users.loading}>Reload</Button>
                <Button size="sm" onClick={() => setProvisionOpen(true)}><Plus className="h-4 w-4" /> Provision</Button>
              </div>
            </div>

            <div className="mt-4">
              {users.loading ? (
                <div className="py-10 text-center"><Spinner /></div>
              ) : users.error ? (
                <p className="text-sm text-rose-600">{users.error}</p>
              ) : userRows.length ? (
                <ul className="divide-y divide-slate-100">
                  {userRows.map((u) => (
                    <li key={u.username} className="flex items-center justify-between gap-2 py-2.5">
                      <div className="flex items-center gap-2">
                        <Database className="h-4 w-4 text-brand-600" />
                        <span className="text-sm font-medium text-ink-800">{u.username}</span>
                        <Badge tone={String(u.account_status).includes('LOCK') ? 'rose' : 'slate'}>
                          {u.account_status}
                        </Badge>
                      </div>
                      <Button size="sm" variant="ghost" onClick={() => setManage(u.username)}>Manage</Button>
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState icon={Database} title="No DB accounts" description="Provision an account or grant access to an existing one." />
              )}
            </div>
          </Card>
        )}

        {tab === 'query' && <QueryTab connectionId={connectionId} />}

        {tab === 'about' && (
          <Card className="p-5">
            {conn.loading ? (
              <div className="py-10 text-center"><Spinner /></div>
            ) : conn.data ? (
              <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Name" value={conn.data.name} />
                <Field label="Host" value={`${conn.data.host}:${conn.data.port}`} />
                <Field label="Service name" value={conn.data.service_name} />
                <Field label="Admin user" value={conn.data.admin_user} />
                <Field label="SSL" value={conn.data.ssl ? 'Yes' : 'No'} />
                <Field label="Status" value={conn.data.status} />
              </dl>
            ) : (
              <p className="text-sm text-rose-600">{conn.error || 'Could not load connection.'}</p>
            )}
          </Card>
        )}
      </div>

      {manage && (
        <UserManageModal
          connectionId={connectionId}
          dbUser={manage}
          onClose={() => setManage(null)}
          onChanged={() => users.reload()}
        />
      )}
      {provisionOpen && (
        <ProvisionModal
          connectionId={connectionId}
          onClose={() => setProvisionOpen(false)}
          onCreated={() => users.reload()}
        />
      )}
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <dt className="text-xs text-slate-400">{label}</dt>
      <dd className="text-sm font-medium text-ink-800">{value || '—'}</dd>
    </div>
  );
}
