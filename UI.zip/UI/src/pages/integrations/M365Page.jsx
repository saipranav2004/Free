import { Navigate } from 'react-router-dom';

/**
 * @deprecated The single M365 page has been replaced by a service catalog:
 *   - /integrations/m365            (hub / overview)
 *   - /integrations/m365/:service   (per-service pages)
 * Kept only so any stale imports fall through to the new hub.
 */
export default function M365Page() {
  return <Navigate to="/integrations/m365" replace />;
}
