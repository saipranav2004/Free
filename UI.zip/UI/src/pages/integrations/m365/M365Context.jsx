import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useAuth } from '../../../context/AuthContext.jsx';

/**
 * Shared M365 context.
 *
 * The M365 connectors are *user-scoped* (most endpoints require an `ms_user`
 * UPN/email). We keep that value in one place so it survives navigation between
 * the hub and the individual service pages, persisting it to localStorage so a
 * refresh does not lose it.
 *
 * Default behaviour: when nothing has been explicitly chosen, the M365 identity
 * falls back to the signed-in user's email (the most common case — you manage
 * your own mailbox/contacts by default).
 */
const M365Ctx = createContext(null);

const STORAGE_KEY = 'iam.m365.msUser';

export function M365Provider({ children }) {
  const { user } = useAuth();
  const [msUser, setMsUserState] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) || '';
    } catch {
      return '';
    }
  });

  const setMsUser = useCallback((value) => {
    const next = (value || '').trim();
    setMsUserState(next);
    try {
      if (next) localStorage.setItem(STORAGE_KEY, next);
      else localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore storage errors */
    }
  }, []);

  // Default the M365 identity to the logged-in user's email once auth resolves
  // (only when the user hasn't set an explicit value).
  useEffect(() => {
    if (!msUser && user?.email) {
      setMsUser(user.email);
    }
  }, [user, msUser, setMsUser]);

  return (
    <M365Ctx.Provider value={{ msUser, setMsUser }}>{children}</M365Ctx.Provider>
  );
}

export function useM365() {
  const ctx = useContext(M365Ctx);
  if (!ctx) {
    throw new Error('useM365() must be used within an <M365Provider>');
  }
  return ctx;
}
