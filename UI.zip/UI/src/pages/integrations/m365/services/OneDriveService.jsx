import { useState, useRef } from 'react';
import { FolderOpen, FolderPlus, Upload, Share2, Trash2, RefreshCw, File as FileIcon } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365 } from '../M365Context.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
  MsUserGuard,
  JsonView,
} from '../parts.jsx';

const driveCols = [
  { id: 'name', header: 'Name', render: (r) => <span className="font-medium">{r.name || r.id}</span> },
  { id: 'type', header: 'Type', render: (r) => <Badge tone="slate">{r.folder ? 'folder' : r.file ? 'file' : 'item'}</Badge> },
  { id: 'size', header: 'Size', render: (r) => (r.size != null ? `${(r.size / 1024).toFixed(1)} KB` : '—') },
];

function ItemsCard() {
  const { msUser } = useM365();
  const [itemId, setItemId] = useState('root');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.driveItems({ ms_user: msUser, item_id: itemId || 'root' }));
  return (
    <ResultCard
      title="Drive items"
      description="GET /api/v1/m365/onedrive/items"
      icon={FolderOpen}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={driveCols}
      emptyTitle="No items"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function ItemDetailCard() {
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.driveItem(id, { ms_user: msUser }));
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Item detail</h3>
      <p className="mt-1 text-xs text-slate-400">GET /api/v1/m365/onedrive/items/&lt;id&gt;</p>
      <div className="mt-3 flex gap-2">
        <Input placeholder="item id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="secondary" onClick={load} loading={action.loading} disabled={!id}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <div className="mt-3">
        {action.loading ? null : action.error ? (
          <p className="text-xs text-rose-600">{action.error}</p>
        ) : action.data ? (
          <JsonView data={action.data} />
        ) : (
          <EmptyState icon={FileIcon} title="No item loaded" />
        )}
      </div>
    </Card>
  );
}

function CreateFolderCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [name, setName] = useState('');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    try {
      await action.run(() => integrationApi.m365.createFolder({ ms_user: msUser, folder_name: name }));
      toast.success('Folder created.');
      setName('');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <FolderPlus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create folder</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="Folder name" value={name} onChange={(e) => setName(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!name}>
          <FolderPlus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function UploadCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const fileRef = useRef(null);
  const action = useM365Action();
  const upload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await action.run(() =>
        integrationApi.m365.uploadFile({ ms_user: msUser, filename: file.name }, file)
      );
      toast.success(`Uploaded ${file.name}.`);
      if (fileRef.current) fileRef.current.value = '';
    } catch (err) {
      toast.error(err.userMessage || 'Upload failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Upload className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Upload file</h3>
      </div>
      <p className="mt-1 text-xs text-slate-400">POST /api/v1/m365/onedrive/upload (raw body)</p>
      <div className="mt-3">
        <input ref={fileRef} type="file" onChange={upload} className="block w-full text-sm text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-brand-700 hover:file:bg-brand-100" />
        {action.loading && <p className="mt-2 text-xs text-slate-400">Uploading…</p>}
        {action.error && <p className="mt-2 text-xs text-rose-600">{action.error}</p>}
      </div>
    </Card>
  );
}

function ShareCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [shareType, setShareType] = useState('view');
  const action = useM365Action();
  const share = async (e) => {
    e.preventDefault();
    try {
      const res = await action.run(() =>
        integrationApi.m365.shareDriveItem(id, { ms_user: msUser, share_type: shareType })
      );
      toast.success('Sharing link created.');
      if (res?.webUrl || res?.link?.webUrl) window.open(res.webUrl || res.link.webUrl, '_blank');
    } catch (err) {
      toast.error(err.userMessage || 'Share failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Share2 className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Share item</h3>
      </div>
      <form onSubmit={share} className="mt-3 space-y-3">
        <Input label="Item id" value={id} onChange={(e) => setId(e.target.value)} />
        <select
          className="input-base"
          value={shareType}
          onChange={(e) => setShareType(e.target.value)}
        >
          <option value="view">View</option>
          <option value="edit">Edit</option>
        </select>
        <Button type="submit" loading={action.loading} disabled={!id}>
          <Share2 className="h-4 w-4" /> Share
        </Button>
      </form>
    </Card>
  );
}

function DeleteItemCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deleteDriveItem(id, { ms_user: msUser }));
      toast.success('Item deleted.');
      setOpen(false); setId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete item</h3>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="item id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="danger" disabled={!id} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={id} />
    </Card>
  );
}

export default function OneDriveService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<FolderOpen className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <MsUserGuard service={service}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <ItemsCard />
          <ItemDetailCard />
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <CreateFolderCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <UploadCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.share} service={service.service}>
            <ShareCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
            <DeleteItemCard userId={userId} />
          </PermissionGate>
        </div>
      </MsUserGuard>
    </div>
  );
}
