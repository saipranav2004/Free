import { useState } from 'react';
import { FileText, Plus, ExternalLink, Share2, Trash2, RefreshCw } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365 } from '../M365Context.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
  MsUserGuard,
  JsonView,
} from '../parts.jsx';

function CreateCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [filename, setFilename] = useState('');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    try {
      const res = await action.run(() =>
        integrationApi.m365.createWord({ ms_user: msUser, filename: filename || undefined })
      );
      toast.success('Word document created.');
      if (res?.id || res?.item_id) {
        window.open(
          `/api/v1/m365/word/documents/${res.id || res.item_id}/open?ms_user=${encodeURIComponent(msUser)}`,
          '_blank'
        );
      }
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create document</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="Filename" value={filename} onChange={(e) => setFilename(e.target.value)} placeholder="Report.docx" />
        <Button type="submit" loading={action.loading}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function DetailCard() {
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.wordDocument(id, { ms_user: msUser }));
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Document detail</h3>
      <p className="mt-1 text-xs text-slate-400">GET /api/v1/m365/word/documents/&lt;id&gt;</p>
      <div className="mt-3 flex gap-2">
        <Input placeholder="document id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="secondary" onClick={load} loading={action.loading} disabled={!id}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <div className="mt-3">
        {action.loading ? null : action.error ? (
          <p className="text-xs text-rose-600">{action.error}</p>
        ) : action.data ? (
          <JsonView data={action.data} />
        ) : (
          <EmptyState icon={FileText} title="No document loaded" />
        )}
      </div>
    </Card>
  );
}

function OpenCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [url, setUrl] = useState('');
  const action = useM365Action();
  const open = async (e) => {
    e.preventDefault();
    try {
      const res = await action.run(() => integrationApi.m365.openWord(id, { ms_user: msUser }));
      const webUrl = res?.webUrl;
      setUrl(webUrl || '');
      if (webUrl) {
        window.open(webUrl, '_blank');
        toast.success('Opening document in Office Online…');
      } else {
        toast.success('Document metadata loaded.');
      }
    } catch (err) {
      toast.error(err.userMessage || 'Open failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <ExternalLink className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Open in Office Online</h3>
      </div>
      <form onSubmit={open} className="mt-3 space-y-3">
        <Input label="Document id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!id}>
          <ExternalLink className="h-4 w-4" /> Open
        </Button>
        {url && (
          <a href={url} target="_blank" rel="noreferrer" className="block truncate text-xs text-brand-600 hover:underline">
            {url}
          </a>
        )}
      </form>
    </Card>
  );
}

function ShareCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [shareType, setShareType] = useState('view');
  const action = useM365Action();
  const share = async (e) => {
    e.preventDefault();
    try {
      const res = await action.run(() =>
        integrationApi.m365.shareWord(id, { ms_user: msUser, share_type: shareType })
      );
      toast.success('Sharing link created.');
      const link = res?.webUrl || res?.link?.webUrl;
      if (link) window.open(link, '_blank');
    } catch (err) {
      toast.error(err.userMessage || 'Share failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Share2 className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Share document</h3>
      </div>
      <form onSubmit={share} className="mt-3 space-y-3">
        <Input label="Document id" value={id} onChange={(e) => setId(e.target.value)} />
        <select className="input-base" value={shareType} onChange={(e) => setShareType(e.target.value)}>
          <option value="view">View</option>
          <option value="edit">Edit</option>
        </select>
        <Button type="submit" loading={action.loading} disabled={!id}>
          <Share2 className="h-4 w-4" /> Share
        </Button>
      </form>
    </Card>
  );
}

function DeleteCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deleteWord(id, { ms_user: msUser }));
      toast.success('Document deleted.');
      setOpen(false); setId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete document</h3>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="document id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="danger" disabled={!id} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={id} />
    </Card>
  );
}

export default function WordService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<FileText className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <MsUserGuard service={service}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <PermissionGate userId={userId} action={service.permissions.create} service={service.service}>
            <CreateCard userId={userId} />
          </PermissionGate>
          <DetailCard />
          <PermissionGate userId={userId} action={service.permissions.read} service={service.service}>
            <OpenCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.share} service={service.service}>
            <ShareCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
            <DeleteCard userId={userId} />
          </PermissionGate>
        </div>
      </MsUserGuard>
    </div>
  );
}
