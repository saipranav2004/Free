import { useState } from 'react';
import { MessagesSquare, Plus, Trash2, Send, RefreshCw, Hash } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea, EmptyState } from '../../../../components/ui/primitives.jsx';
import { DataTable } from '../../../../components/ui/DataTable.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
} from '../parts.jsx';

const channelCols = [
  { id: 'displayName', header: 'Channel', render: (r) => <span className="font-medium">{r.displayName || r.id}</span> },
  { id: 'description', header: 'Description', render: (r) => r.description || '—' },
  { id: 'id', header: 'Id', render: (r) => <code className="text-xs">{r.id}</code> },
];
const msgCols = [
  { id: 'from', header: 'From', render: (r) => r.from?.user?.displayName || '—' },
  { id: 'body', header: 'Message', render: (r) => r.body?.content || '—' },
  { id: 'created', header: 'Created', render: (r) => r.createdDateTime || '—' },
];

function CreateTeamCard({ userId }) {
  const toast = useToast();
  const [teamData, setTeamData] = useState('{\n  "displayName": "Project Apollo",\n  "description": "Cross-functional team"\n}');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    let parsed;
    try {
      parsed = JSON.parse(teamData);
    } catch {
      return toast.error('team_data must be valid JSON.');
    }
    try {
      await action.run(() => integrationApi.m365.createTeam({ team_data: parsed }));
      toast.success('Team created.');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create team</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Textarea label="team_data (JSON)" rows={5} value={teamData} onChange={(e) => setTeamData(e.target.value)} />
        <Button type="submit" loading={action.loading}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function DeleteTeamCard({ userId }) {
  const toast = useToast();
  const [teamId, setTeamId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deleteTeam(teamId));
      toast.success('Team deleted.');
      setOpen(false); setTeamId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete team</h3>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="team id" value={teamId} onChange={(e) => setTeamId(e.target.value)} />
        <Button variant="danger" disabled={!teamId} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={teamId} />
    </Card>
  );
}

function ChannelsCard() {
  const toast = useToast();
  const [teamId, setTeamId] = useState('');
  const [channelName, setChannelName] = useState('');
  const listAction = useM365Action();
  const createAction = useM365Action();
  const load = () => listAction.run(() => integrationApi.m365.channels(teamId));
  const create = async (e) => {
    e.preventDefault();
    try {
      await createAction.run(() => integrationApi.m365.createChannel(teamId, { channel_name: channelName }));
      toast.success('Channel created.');
      setChannelName('');
      load();
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Channels</h3>
      <p className="mt-1 text-xs text-slate-400">GET/POST /api/v1/m365/teams/&lt;team_id&gt;/channels</p>
      <div className="mt-3 flex gap-2">
        <Input placeholder="team id" value={teamId} onChange={(e) => setTeamId(e.target.value)} />
        <Button variant="secondary" onClick={load} loading={listAction.loading} disabled={!teamId}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="new channel name" value={channelName} onChange={(e) => setChannelName(e.target.value)} />
        <Button onClick={create} loading={createAction.loading} disabled={!teamId || !channelName}>
          <Hash className="h-4 w-4" /> Add
        </Button>
      </div>
      <div className="mt-3">
        {listAction.loading ? null : listAction.error ? (
          <p className="text-xs text-rose-600">{listAction.error}</p>
        ) : Array.isArray(listAction.data?.value) && listAction.data.value.length ? (
          <DataTable columns={channelCols} data={listAction.data.value} />
        ) : listAction.data ? (
          <EmptyState icon={Hash} title="No channels" />
        ) : null}
      </div>
    </Card>
  );
}

function MessagesCard() {
  const toast = useToast();
  const [teamId, setTeamId] = useState('');
  const [channelId, setChannelId] = useState('');
  const [message, setMessage] = useState('');
  const listAction = useM365Action();
  const sendAction = useM365Action();
  const load = () => listAction.run(() => integrationApi.m365.channelMessages(teamId, channelId));
  const send = async (e) => {
    e.preventDefault();
    try {
      await sendAction.run(() => integrationApi.m365.sendChannelMessage(teamId, channelId, { message }));
      toast.success('Message sent.');
      setMessage('');
      load();
    } catch (err) {
      toast.error(err.userMessage || 'Send failed.');
    }
  };
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Channel messages</h3>
      <p className="mt-1 text-xs text-slate-400">POST/GET /api/v1/m365/teams/&lt;team_id&gt;/channels/&lt;channel_id&gt;/messages</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Input placeholder="team id" value={teamId} onChange={(e) => setTeamId(e.target.value)} />
        <Input placeholder="channel id" value={channelId} onChange={(e) => setChannelId(e.target.value)} />
      </div>
      <div className="mt-2 flex gap-2">
        <Button variant="secondary" onClick={load} loading={listAction.loading} disabled={!teamId || !channelId}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <form onSubmit={send} className="mt-3 space-y-2">
        <Textarea label="Message" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} />
        <Button type="submit" loading={sendAction.loading} disabled={!teamId || !channelId || !message}>
          <Send className="h-4 w-4" /> Send
        </Button>
      </form>
      <div className="mt-3">
        {listAction.loading ? null : listAction.error ? (
          <p className="text-xs text-rose-600">{listAction.error}</p>
        ) : Array.isArray(listAction.data?.value) && listAction.data.value.length ? (
          <DataTable columns={msgCols} data={listAction.data.value} />
        ) : listAction.data ? (
          <EmptyState icon={MessagesSquare} title="No messages" />
        ) : null}
      </div>
    </Card>
  );
}

export default function TeamsService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<MessagesSquare className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <PermissionGate userId={userId} action={service.permissions.create} service={service.service}>
          <CreateTeamCard userId={userId} />
        </PermissionGate>
        <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
          <DeleteTeamCard userId={userId} />
        </PermissionGate>
        <PermissionGate userId={userId} action={service.permissions.read} service={service.service}>
          <ChannelsCard />
        </PermissionGate>
        <PermissionGate userId={userId} action={service.permissions.message} service={service.service}>
          <MessagesCard />
        </PermissionGate>
      </div>
    </div>
  );
}
