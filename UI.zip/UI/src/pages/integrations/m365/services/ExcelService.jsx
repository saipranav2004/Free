import { useState } from 'react';
import { FileSpreadsheet, Plus, Table, RefreshCw, Save } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365 } from '../M365Context.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  PermissionBadges,
  MsUserGuard,
  JsonView,
} from '../parts.jsx';

const wsCols = [
  { id: 'name', header: 'Worksheet', render: (r) => <span className="font-medium">{r.name || r.id}</span> },
  { id: 'id', header: 'Id', render: (r) => <code className="text-xs">{r.id || r.name}</code> },
];

function CreateWorkbookCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [filename, setFilename] = useState('');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    try {
      await action.run(() =>
        integrationApi.m365.createWorkbook({ ms_user: msUser, filename: filename || undefined })
      );
      toast.success('Workbook created in OneDrive.');
      setFilename('');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create workbook</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="Filename" value={filename} onChange={(e) => setFilename(e.target.value)} placeholder="Budget.xlsx" />
        <Button type="submit" loading={action.loading}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function WorksheetsCard() {
  const { msUser } = useM365();
  const [itemId, setItemId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.worksheets(itemId, { ms_user: msUser }));
  return (
    <ResultCard
      title="Worksheets"
      description="GET /api/v1/m365/excel/workbooks/<id>/worksheets"
      icon={Table}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={wsCols}
      emptyTitle="No worksheets"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading} disabled={!itemId}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function CreateWorksheetCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [itemId, setItemId] = useState('');
  const [name, setName] = useState('');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    try {
      await action.run(() =>
        integrationApi.m365.createWorksheet(itemId, { ms_user: msUser, worksheet_name: name })
      );
      toast.success('Worksheet created.');
      setName('');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Table className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Add worksheet</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="Workbook item id" value={itemId} onChange={(e) => setItemId(e.target.value)} />
        <Input label="Worksheet name" value={name} onChange={(e) => setName(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!itemId || !name}>
          <Table className="h-4 w-4" /> Add
        </Button>
      </form>
    </Card>
  );
}

function RangeCard() {
  const { msUser } = useM365();
  const [itemId, setItemId] = useState('');
  const [worksheet, setWorksheet] = useState('Sheet1');
  const [range, setRange] = useState('A1:B10');
  const action = useM365Action();
  const load = () =>
    action.run(() =>
      integrationApi.m365.excelRange(itemId, { ms_user: msUser, worksheet, range })
    );
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Table className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Read range</h3>
      </div>
      <p className="mt-1 text-xs text-slate-400">GET /api/v1/m365/excel/workbooks/&lt;id&gt;/range</p>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Input label="Workbook id" value={itemId} onChange={(e) => setItemId(e.target.value)} />
        <Input label="Worksheet" value={worksheet} onChange={(e) => setWorksheet(e.target.value)} />
        <Input label="Range" value={range} onChange={(e) => setRange(e.target.value)} />
        <div className="flex items-end">
          <Button variant="secondary" onClick={load} loading={action.loading} disabled={!itemId}>
            <RefreshCw className="h-3.5 w-3.5" /> Load
          </Button>
        </div>
      </div>
      <div className="mt-3">
        {action.loading ? null : action.error ? (
          <p className="text-xs text-rose-600">{action.error}</p>
        ) : action.data ? (
          <JsonView data={action.data} />
        ) : (
          <EmptyState icon={Table} title="No range loaded" />
        )}
      </div>
    </Card>
  );
}

function UpdateRangeCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [itemId, setItemId] = useState('');
  const [worksheet, setWorksheet] = useState('Sheet1');
  const [range, setRange] = useState('A1:B2');
  const [values, setValues] = useState('[["A1","B1"],["A2","B2"]]');
  const action = useM365Action();
  const update = async (e) => {
    e.preventDefault();
    let parsed;
    try {
      parsed = JSON.parse(values);
    } catch {
      return toast.error('Values must be a 2D JSON array.');
    }
    try {
      await action.run(() =>
        integrationApi.m365.updateExcelRange(itemId, {
          ms_user: msUser,
          worksheet,
          range,
          values: parsed,
        })
      );
      toast.success('Range updated.');
    } catch (err) {
      toast.error(err.userMessage || 'Update failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Save className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Update range</h3>
      </div>
      <form onSubmit={update} className="mt-3 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Input label="Workbook id" value={itemId} onChange={(e) => setItemId(e.target.value)} />
          <Input label="Worksheet" value={worksheet} onChange={(e) => setWorksheet(e.target.value)} />
        </div>
        <Input label="Range" value={range} onChange={(e) => setRange(e.target.value)} />
        <Textarea label="Values (2D JSON array)" rows={4} value={values} onChange={(e) => setValues(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!itemId}>
          <Save className="h-4 w-4" /> Update
        </Button>
      </form>
    </Card>
  );
}

export default function ExcelService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<FileSpreadsheet className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <MsUserGuard service={service}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <PermissionGate userId={userId} action={service.permissions.create} service={service.service}>
            <CreateWorkbookCard userId={userId} />
          </PermissionGate>
          <WorksheetsCard />
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <CreateWorksheetCard userId={userId} />
          </PermissionGate>
          <RangeCard />
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <UpdateRangeCard userId={userId} />
          </PermissionGate>
        </div>
      </MsUserGuard>
    </div>
  );
}
