import { useState } from 'react';
import { Presentation, Plus, ExternalLink, Share2, Trash2, RefreshCw } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365 } from '../M365Context.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
  MsUserGuard,
  JsonView,
} from '../parts.jsx';

function CreateCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [filename, setFilename] = useState('');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    try {
      await action.run(() =>
        integrationApi.m365.createPresentation({ ms_user: msUser, filename: filename || undefined })
      );
      toast.success('Presentation created in OneDrive.');
      setFilename('');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create presentation</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="Filename" value={filename} onChange={(e) => setFilename(e.target.value)} placeholder="Deck.pptx" />
        <Button type="submit" loading={action.loading}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function DetailCard() {
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.presentation(id, { ms_user: msUser }));
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Presentation detail</h3>
      <p className="mt-1 text-xs text-slate-400">GET /api/v1/m365/powerpoint/presentations/&lt;id&gt;</p>
      <div className="mt-3 flex gap-2">
        <Input placeholder="presentation id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="secondary" onClick={load} loading={action.loading} disabled={!id}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <div className="mt-3">
        {action.loading ? null : action.error ? (
          <p className="text-xs text-rose-600">{action.error}</p>
        ) : action.data ? (
          <JsonView data={action.data} />
        ) : (
          <EmptyState icon={Presentation} title="No presentation loaded" />
        )}
      </div>
    </Card>
  );
}

function ShareCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [shareType, setShareType] = useState('view');
  const action = useM365Action();
  const share = async (e) => {
    e.preventDefault();
    try {
      const res = await action.run(() =>
        integrationApi.m365.sharePresentation(id, { ms_user: msUser, share_type: shareType })
      );
      toast.success('Sharing link created.');
      const link = res?.webUrl || res?.link?.webUrl;
      if (link) window.open(link, '_blank');
    } catch (err) {
      toast.error(err.userMessage || 'Share failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Share2 className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Share presentation</h3>
      </div>
      <form onSubmit={share} className="mt-3 space-y-3">
        <Input label="Presentation id" value={id} onChange={(e) => setId(e.target.value)} />
        <select className="input-base" value={shareType} onChange={(e) => setShareType(e.target.value)}>
          <option value="view">View</option>
          <option value="edit">Edit</option>
        </select>
        <Button type="submit" loading={action.loading} disabled={!id}>
          <Share2 className="h-4 w-4" /> Share
        </Button>
      </form>
    </Card>
  );
}

function DeleteCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deletePresentation(id, { ms_user: msUser }));
      toast.success('Presentation deleted.');
      setOpen(false); setId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete presentation</h3>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="presentation id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="danger" disabled={!id} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={id} />
    </Card>
  );
}

export default function PowerPointService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<Presentation className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <MsUserGuard service={service}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <PermissionGate userId={userId} action={service.permissions.create} service={service.service}>
            <CreateCard userId={userId} />
          </PermissionGate>
          <DetailCard />
          <PermissionGate userId={userId} action={service.permissions.share} service={service.service}>
            <ShareCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
            <DeleteCard userId={userId} />
          </PermissionGate>
        </div>
      </MsUserGuard>
    </div>
  );
}
