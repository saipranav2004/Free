import { useState } from 'react';
import { Calendar as CalIcon, Plus, Trash2, RefreshCw, Pencil } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365 } from '../M365Context.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
  MsUserGuard,
} from '../parts.jsx';

const evtCols = [
  { id: 'subject', header: 'Subject', render: (r) => <span className="font-medium">{r.subject || r.id}</span> },
  { id: 'start', header: 'Start', render: (r) => r.start?.dateTime || r.start || '—' },
  { id: 'location', header: 'Location', render: (r) => r.location?.displayName || '—' },
  { id: 'organizer', header: 'Organizer', render: (r) => r.organizer?.emailAddress?.address || '—' },
];

function EventsCard() {
  const { msUser } = useM365();
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.calendarEvents({ ms_user: msUser, top: 20 }));
  return (
    <ResultCard
      title="Calendar events"
      description="GET /api/v1/m365/calendar/events"
      icon={CalIcon}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={evtCols}
      emptyTitle="No events"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function CreateEventCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const action = useM365Action();
  const [subject, setSubject] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [location, setLocation] = useState('');
  const create = async (e) => {
    e.preventDefault();
    try {
      await action.run(() =>
        integrationApi.m365.createEvent({
          ms_user: msUser,
          event_data: {
            subject,
            start: { dateTime: start, timeZone: 'UTC' },
            end: { dateTime: end, timeZone: 'UTC' },
            location: location ? { displayName: location } : undefined,
          },
        })
      );
      toast.success('Event created.');
      setSubject(''); setStart(''); setEnd(''); setLocation('');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create event</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <div className="grid grid-cols-2 gap-3">
          <Input type="datetime-local" label="Start" value={start} onChange={(e) => setStart(e.target.value)} />
          <Input type="datetime-local" label="End" value={end} onChange={(e) => setEnd(e.target.value)} />
        </div>
        <Input label="Location (optional)" value={location} onChange={(e) => setLocation(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!subject || !start || !end}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function UpdateEventCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [patch, setPatch] = useState('{\n  "isRead": true\n}');
  const action = useM365Action();
  const update = async (e) => {
    e.preventDefault();
    let updates;
    try {
      updates = JSON.parse(patch);
    } catch {
      return toast.error('Updates must be valid JSON.');
    }
    try {
      await action.run(() => integrationApi.m365.updateEvent(id, { ms_user: msUser, updates }));
      toast.success('Event updated.');
    } catch (err) {
      toast.error(err.userMessage || 'Update failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Pencil className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Update event</h3>
      </div>
      <form onSubmit={update} className="mt-3 space-y-3">
        <Input label="Event id" value={id} onChange={(e) => setId(e.target.value)} />
        <Textarea label="Updates (JSON)" rows={4} value={patch} onChange={(e) => setPatch(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!id}>
          <Pencil className="h-4 w-4" /> Update
        </Button>
      </form>
    </Card>
  );
}

function DeleteEventCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deleteEvent(id, { ms_user: msUser }));
      toast.success('Event deleted.');
      setOpen(false); setId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete event</h3>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="event id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="danger" disabled={!id} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={id} />
    </Card>
  );
}

export default function CalendarService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<CalIcon className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <MsUserGuard service={service}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <EventsCard />
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <CreateEventCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <UpdateEventCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
            <DeleteEventCard userId={userId} />
          </PermissionGate>
        </div>
      </MsUserGuard>
    </div>
  );
}
