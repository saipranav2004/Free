import { useState } from 'react';
import { Building2, List, Boxes, Plus, Trash2, RefreshCw } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { DataTable } from '../../../../components/ui/DataTable.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
  JsonView,
} from '../parts.jsx';

const listCols = [
  { id: 'name', header: 'List', render: (r) => <span className="font-medium">{r.name || r.id}</span> },
  { id: 'id', header: 'Id', render: (r) => <code className="text-xs">{r.id}</code> },
];
const itemCols = [
  { id: 'id', header: 'Id', render: (r) => <code className="text-xs">{r.id}</code> },
  {
    id: 'fields',
    header: 'Fields',
    render: (r) => (
      <span className="text-xs text-slate-500">{r.fields ? JSON.stringify(r.fields).slice(0, 80) + '…' : '—'}</span>
    ),
  },
];

function SiteCard() {
  const [siteId, setSiteId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.sharePointSite(siteId));
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Site</h3>
      <p className="mt-1 text-xs text-slate-400">GET /api/v1/m365/sharepoint/sites/&lt;site_id&gt;</p>
      <div className="mt-3 flex gap-2">
        <Input placeholder="site id (e.g. contoso.sharepoint.com:/sites/Team)" value={siteId} onChange={(e) => setSiteId(e.target.value)} />
        <Button variant="secondary" onClick={load} loading={action.loading} disabled={!siteId}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <div className="mt-3">
        {action.loading ? null : action.error ? (
          <p className="text-xs text-rose-600">{action.error}</p>
        ) : action.data ? (
          <JsonView data={action.data} />
        ) : (
          <EmptyState icon={Building2} title="No site loaded" />
        )}
      </div>
    </Card>
  );
}

function ListsCard() {
  const [siteId, setSiteId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.sharePointLists(siteId));
  return (
    <ResultCard
      title="Lists"
      description="GET /api/v1/m365/sharepoint/sites/<site_id>/lists"
      icon={List}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={listCols}
      emptyTitle="No lists"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading} disabled={!siteId}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function ItemsCard() {
  const [siteId, setSiteId] = useState('');
  const [listId, setListId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.sharePointItems(siteId, listId));
  return (
    <ResultCard
      title="List items"
      description="GET /api/v1/m365/sharepoint/sites/<site_id>/lists/<list_id>/items"
      icon={Boxes}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={itemCols}
      emptyTitle="No items"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading} disabled={!siteId || !listId}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function CreateItemCard({ userId }) {
  const toast = useToast();
  const [siteId, setSiteId] = useState('');
  const [listId, setListId] = useState('');
  const [fields, setFields] = useState('{\n  "Title": "New item"\n}');
  const action = useM365Action();
  const create = async (e) => {
    e.preventDefault();
    let parsed;
    try {
      parsed = JSON.parse(fields);
    } catch {
      return toast.error('Fields must be valid JSON.');
    }
    try {
      await action.run(() => integrationApi.m365.createSharePointItem(siteId, listId, { fields: parsed }));
      toast.success('List item created.');
    } catch (err) {
      toast.error(err.userMessage || 'Create failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create list item</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Input label="Site id" value={siteId} onChange={(e) => setSiteId(e.target.value)} />
          <Input label="List id" value={listId} onChange={(e) => setListId(e.target.value)} />
        </div>
        <Textarea label="Fields (JSON)" rows={4} value={fields} onChange={(e) => setFields(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!siteId || !listId}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </form>
    </Card>
  );
}

function DeleteItemCard({ userId }) {
  const toast = useToast();
  const [siteId, setSiteId] = useState('');
  const [listId, setListId] = useState('');
  const [itemId, setItemId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deleteSharePointItem(siteId, listId, itemId));
      toast.success('List item deleted.');
      setOpen(false); setItemId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete list item</h3>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <Input placeholder="site id" value={siteId} onChange={(e) => setSiteId(e.target.value)} />
        <Input placeholder="list id" value={listId} onChange={(e) => setListId(e.target.value)} />
        <Input placeholder="item id" value={itemId} onChange={(e) => setItemId(e.target.value)} />
      </div>
      <div className="mt-3">
        <Button variant="danger" disabled={!siteId || !listId || !itemId} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={itemId} />
    </Card>
  );
}

export default function SharePointService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<Building2 className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <SiteCard />
        <ListsCard />
        <ItemsCard />
        <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
          <CreateItemCard userId={userId} />
        </PermissionGate>
        <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
          <DeleteItemCard userId={userId} />
        </PermissionGate>
      </div>
    </div>
  );
}
