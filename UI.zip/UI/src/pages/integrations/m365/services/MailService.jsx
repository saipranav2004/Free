import { useState } from 'react';
import { Mail, Send, FileEdit, Trash2, RefreshCw } from 'lucide-react';
import { useAuth } from '../../../../context/AuthContext.jsx';
import { useToast } from '../../../../context/ToastContext.jsx';
import { useM365 } from '../M365Context.jsx';
import { useM365Action } from '../hooks.js';
import { PageHeader } from '../../../../components/common/PageHeader.jsx';
import { Card, Button, Input, Textarea, Select, Badge, EmptyState } from '../../../../components/ui/primitives.jsx';
import { integrationApi } from '../../../../lib/api/integration.js';
import {
  ResultCard,
  PermissionGate,
  ConfirmDelete,
  PermissionBadges,
  MsUserGuard,
} from '../parts.jsx';

const mailCols = [
  { id: 'subject', header: 'Subject', render: (r) => <span className="font-medium">{r.subject || r.id || '—'}</span> },
  { id: 'from', header: 'From', render: (r) => r.from?.emailAddress?.address || r.from || '—' },
  { id: 'received', header: 'Received', render: (r) => r.receivedDateTime || '—' },
  { id: 'isRead', header: 'Read', render: (r) => <Badge tone={r.isRead ? 'green' : 'slate'}>{r.isRead ? 'Yes' : 'No'}</Badge> },
];
const folderCols = [
  { id: 'displayName', header: 'Folder', render: (r) => <span className="font-medium">{r.displayName || r.id}</span> },
  { id: 'id', header: 'Id', render: (r) => <code className="text-xs">{r.id}</code> },
];

/**
 * Build a Microsoft Graph `toRecipients` array from a comma-separated string.
 * Graph requires [{ emailAddress: { address } }], NOT plain strings.
 */
const buildRecipients = (to) =>
  to
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .map((address) => ({ emailAddress: { address } }));

function MessagesCard() {
  const { msUser } = useM365();
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.mailMessages({ ms_user: msUser, top: 20 }));
  return (
    <ResultCard
      title="Mail messages"
      description="GET /api/v1/m365/mail/messages"
      icon={Mail}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={mailCols}
      emptyTitle="No messages"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function FoldersCard() {
  const { msUser } = useM365();
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.mailFolders({ ms_user: msUser }));
  return (
    <ResultCard
      title="Mail folders"
      description="GET /api/v1/m365/mail/folders"
      icon={Mail}
      loading={action.loading}
      error={action.error}
      data={action.data?.value}
      columns={folderCols}
      emptyTitle="No folders"
      headerAction={
        <Button size="sm" variant="secondary" onClick={load} loading={action.loading}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      }
    />
  );
}

function MessageDetailCard() {
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const action = useM365Action();
  const load = () => action.run(() => integrationApi.m365.mailMessage(id, { ms_user: msUser }));
  return (
    <Card className="p-5">
      <h3 className="text-sm font-semibold text-ink-900">Message detail</h3>
      <p className="mt-1 text-xs text-slate-400">GET /api/v1/m365/mail/messages/&lt;id&gt;</p>
      <div className="mt-3 flex gap-2">
        <Input placeholder="message id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="secondary" onClick={load} loading={action.loading} disabled={!id}>
          <RefreshCw className="h-3.5 w-3.5" /> Load
        </Button>
      </div>
      <div className="mt-3">
        {action.loading ? null : action.error ? (
          <p className="text-xs text-rose-600">{action.error}</p>
        ) : action.data ? (
          <pre className="max-h-80 overflow-auto rounded-lg bg-ink-900 p-3 text-xs text-emerald-200">
            {JSON.stringify(action.data, null, 2)}
          </pre>
        ) : (
          <EmptyState icon={Mail} title="No message loaded" />
        )}
      </div>
    </Card>
  );
}

function SendMailCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const action = useM365Action();
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [bodyType, setBodyType] = useState('text');
  const send = async (e) => {
    e.preventDefault();
    try {
      await action.run(() =>
        integrationApi.m365.sendMail({
          ms_user: msUser,
          message: {
            subject,
            // Graph requires body to be an object, not a raw string.
            body: { contentType: bodyType, content: body },
            // Graph requires [{ emailAddress: { address } }], not plain strings.
            toRecipients: buildRecipients(to),
          },
        })
      );
      toast.success('Mail sent via the M365 connector.');
      setTo(''); setSubject(''); setBody(''); setBodyType('text');
    } catch (err) {
      toast.error(err.userMessage || 'Send failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Send className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Send mail</h3>
      </div>
      <form onSubmit={send} className="mt-3 space-y-3">
        <Input label="To (comma-separated)" value={to} onChange={(e) => setTo(e.target.value)} placeholder="bob@contoso.com, carol@contoso.com" />
        <Input label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <Select label="Body format" value={bodyType} onChange={(e) => setBodyType(e.target.value)}>
          <option value="text">Plain text</option>
          <option value="html">HTML</option>
        </Select>
        <Textarea label="Body" rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!to || !subject}>
          <Send className="h-4 w-4" /> Send
        </Button>
      </form>
    </Card>
  );
}

function DraftCard() {
  const toast = useToast();
  const { msUser } = useM365();
  const action = useM365Action();
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [bodyType, setBodyType] = useState('text');
  const create = async (e) => {
    e.preventDefault();
    try {
      await action.run(() =>
        integrationApi.m365.createDraft({
          ms_user: msUser,
          message: {
            subject,
            body: { contentType: bodyType, content: body },
            toRecipients: buildRecipients(to),
          },
        })
      );
      toast.success('Draft created.');
      setTo(''); setSubject(''); setBody(''); setBodyType('text');
    } catch (err) {
      toast.error(err.userMessage || 'Draft failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <FileEdit className="h-5 w-5 text-brand-600" />
        <h3 className="text-sm font-semibold text-ink-900">Create draft</h3>
      </div>
      <form onSubmit={create} className="mt-3 space-y-3">
        <Input label="To (comma-separated)" value={to} onChange={(e) => setTo(e.target.value)} />
        <Input label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <Select label="Body format" value={bodyType} onChange={(e) => setBodyType(e.target.value)}>
          <option value="text">Plain text</option>
          <option value="html">HTML</option>
        </Select>
        <Textarea label="Body" rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
        <Button type="submit" loading={action.loading} disabled={!subject}>
          <FileEdit className="h-4 w-4" /> Create draft
        </Button>
      </form>
    </Card>
  );
}

function DeleteCard({ userId }) {
  const toast = useToast();
  const { msUser } = useM365();
  const [id, setId] = useState('');
  const [open, setOpen] = useState(false);
  const action = useM365Action();
  const remove = async () => {
    try {
      await action.run(() => integrationApi.m365.deleteMessage(id, { ms_user: msUser }));
      toast.success('Message deleted.');
      setOpen(false); setId('');
    } catch (err) {
      toast.error(err.userMessage || 'Delete failed.');
    }
  };
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <Trash2 className="h-5 w-5 text-rose-600" />
        <h3 className="text-sm font-semibold text-ink-900">Delete message</h3>
      </div>
      <div className="mt-3 flex gap-2">
        <Input placeholder="message id" value={id} onChange={(e) => setId(e.target.value)} />
        <Button variant="danger" disabled={!id} onClick={() => setOpen(true)}>
          <Trash2 className="h-4 w-4" /> Delete
        </Button>
      </div>
      <ConfirmDelete open={open} onClose={() => setOpen(false)} onConfirm={remove} busy={action.loading} resource={id} />
    </Card>
  );
}

export default function MailService({ service }) {
  const { user } = useAuth();
  const userId = user?.user_id;
  return (
    <div>
      <PageHeader
        title={service.name}
        description={service.description}
        icon={<Mail className="h-5 w-5" />}
        actions={<PermissionBadges permissions={service.permissions} />}
      />
      <MsUserGuard service={service}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <MessagesCard />
          <FoldersCard />
          <MessageDetailCard />
          <PermissionGate userId={userId} action={service.permissions.send} service={service.service}>
            <SendMailCard userId={userId} />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.write} service={service.service}>
            <DraftCard />
          </PermissionGate>
          <PermissionGate userId={userId} action={service.permissions.delete} service={service.service}>
            <DeleteCard userId={userId} />
          </PermissionGate>
        </div>
      </MsUserGuard>
    </div>
  );
}
