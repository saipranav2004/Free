import { useParams, Navigate } from 'react-router-dom';
import { M365Shell, PendingService } from './parts.jsx';
import { M365_SERVICE_MAP } from './registry.js';

import MailService from './services/MailService.jsx';
import CalendarService from './services/CalendarService.jsx';
import OneDriveService from './services/OneDriveService.jsx';
import WordService from './services/WordService.jsx';
import ExcelService from './services/ExcelService.jsx';
import PowerPointService from './services/PowerPointService.jsx';
import SharePointService from './services/SharePointService.jsx';
import TeamsService from './services/TeamsService.jsx';

const SERVICE_COMPONENTS = {
  mail: MailService,
  calendar: CalendarService,
  onedrive: OneDriveService,
  word: WordService,
  excel: ExcelService,
  powerpoint: PowerPointService,
  sharepoint: SharePointService,
  teams: TeamsService,
};

export default function M365ServicePage() {
  const { service } = useParams();
  const svc = M365_SERVICE_MAP[service];

  if (!svc) return <Navigate to="/integrations/m365" replace />;

  const Component = SERVICE_COMPONENTS[service] || (() => <PendingService service={svc} />);

  return (
    <M365Shell active={service} requiresMsUser={svc.requiresMsUser}>
      <Component service={svc} />
    </M365Shell>
  );
}
