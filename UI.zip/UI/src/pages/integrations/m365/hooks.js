import { useCallback, useEffect, useState } from 'react';
import { pbacApi } from '../../../lib/api/pbac.js';
import { m365Arn } from '../../../utils/constants.js';

/**
 * Live PDP preview for a single (user, action, service) tuple.
 * The real enforcement always happens server-side; this is a *preview* so the
 * UI can show Granted / Denied / Verify-on-use. It fails OPEN: if the decision
 * endpoint is unreachable (e.g. admin-only), we surface "Verify on use" and let
 * the actual request be decided by the backend.
 *
 * @param {string} userId  IAM user id (from auth)
 * @param {string} action  IAM action, e.g. "m365:mail:Send"
 * @param {string} service M365 service key used to build the ARN
 */
export function useM365Permission(userId, action, service) {
  const arn = service ? m365Arn(service) : null;
  const [state, setState] = useState({
    loading: Boolean(userId && action),
    allowed: false,
    reason: '',
    errored: false,
  });

  useEffect(() => {
    if (!userId || !action) {
      setState({ loading: false, allowed: false, reason: '', errored: false });
      return undefined;
    }
    let cancelled = false;
    setState({ loading: true, allowed: false, reason: '', errored: false });
    pbacApi
      .check({ user_id: userId, action, resource_arn: arn })
      .then((res) => {
        if (!cancelled)
          setState({
            loading: false,
            allowed: !!res?.allowed,
            reason: res?.reason || '',
            errored: false,
          });
      })
      .catch(() => {
        if (!cancelled)
          setState({ loading: false, allowed: false, reason: '', errored: true });
      });
    return () => {
      cancelled = true;
    };
  }, [userId, action, arn]);

  return state;
}

/**
 * Reusable async action state (manual trigger). Returns { loading, data, error, run }.
 * `run(fn)` executes fn, tracks loading and normalizes errors to `error`.
 */
export function useM365Action() {
  const [state, setState] = useState({ loading: false, data: null, error: null });

  const run = useCallback(async (fn) => {
    setState({ loading: true, data: null, error: null });
    try {
      const data = await fn();
      setState({ loading: false, data, error: null });
      return data;
    } catch (err) {
      setState({
        loading: false,
        data: null,
        error: err?.userMessage || err?.message || 'Request failed.',
      });
      throw err;
    }
  }, []);

  return { ...state, run };
}
