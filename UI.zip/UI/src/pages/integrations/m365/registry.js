import {
  Mail,
  Calendar,
  FolderOpen,
  FileText,
  FileSpreadsheet,
  Presentation,
  Building2,
  MessagesSquare,
  Notebook,
  ListChecks,
} from 'lucide-react';

/**
 * Single source of truth for the M365 service catalog surfaced in the UI.
 *
 * `id`        – URL segment (/integrations/m365/<id>)
 * `service`   – M365 resource key used to build the IAM ARN (m365Arn)
 * `permissions` – IAM actions the connector enforces (for badges + PDP preview)
 * `requiresMsUser` – whether endpoints need an ms_user (UPN/email). App-only
 *                    services (Teams, SharePoint) do not.
 * `status`    – 'live' (blueprint registered) | 'pending' (connector exists
 *                but no routes registered yet in the backend)
 * `accent`    – tailwind classes for the icon chip
 */
export const M365_SERVICES = [
  {
    id: 'mail',
    name: 'Outlook Mail',
    icon: Mail,
    description: 'Read mailbox messages, send mail, manage drafts and folders.',
    service: 'mail',
    requiresMsUser: true,
    status: 'live',
    accent: 'bg-sky-50 text-sky-600',
    permissions: {
      read: 'm365:mail:Read',
      write: 'm365:mail:Write',
      send: 'm365:mail:Send',
      delete: 'm365:mail:Delete',
    },
  },
  {
    id: 'calendar',
    name: 'Calendar',
    icon: Calendar,
    description: 'List, create, update and delete calendar events.',
    service: 'calendar',
    requiresMsUser: true,
    status: 'live',
    accent: 'bg-amber-50 text-amber-600',
    permissions: {
      read: 'm365:calendar:Read',
      write: 'm365:calendar:Write',
      delete: 'm365:calendar:Delete',
    },
  },
  {
    id: 'onedrive',
    name: 'OneDrive',
    icon: FolderOpen,
    description: 'Browse, upload, create folders and share drive items.',
    service: 'onedrive',
    requiresMsUser: true,
    status: 'live',
    accent: 'bg-blue-50 text-blue-600',
    permissions: {
      read: 'm365:onedrive:Read',
      write: 'm365:onedrive:Write',
      delete: 'm365:onedrive:Delete',
      share: 'm365:onedrive:Share',
    },
  },
  {
    id: 'word',
    name: 'Word',
    icon: FileText,
    description: 'Create, open, share and delete Word documents.',
    service: 'word',
    requiresMsUser: true,
    status: 'live',
    accent: 'bg-blue-50 text-blue-600',
    permissions: {
      read: 'm365:word:Read',
      create: 'm365:word:Create',
      delete: 'm365:word:Delete',
      share: 'm365:word:Share',
    },
  },
  {
    id: 'excel',
    name: 'Excel',
    icon: FileSpreadsheet,
    description: 'Create workbooks, manage worksheets and edit cell ranges.',
    service: 'excel',
    requiresMsUser: true,
    status: 'live',
    accent: 'bg-emerald-50 text-emerald-600',
    permissions: {
      read: 'm365:excel:Read',
      write: 'm365:excel:Write',
      create: 'm365:excel:Create',
      delete: 'm365:excel:Delete',
    },
  },
  {
    id: 'powerpoint',
    name: 'PowerPoint',
    icon: Presentation,
    description: 'Create, open, share and delete presentations.',
    service: 'powerpoint',
    requiresMsUser: true,
    status: 'live',
    accent: 'bg-orange-50 text-orange-600',
    permissions: {
      read: 'm365:powerpoint:Read',
      create: 'm365:powerpoint:Create',
      delete: 'm365:powerpoint:Delete',
      share: 'm365:powerpoint:Share',
    },
  },
  {
    id: 'sharepoint',
    name: 'SharePoint',
    icon: Building2,
    description: 'Read sites/lists and manage list items (app-only).',
    service: 'sharepoint',
    requiresMsUser: false,
    status: 'live',
    accent: 'bg-rose-50 text-rose-600',
    permissions: {
      read: 'm365:sharepoint:Read',
      write: 'm365:sharepoint:Write',
      delete: 'm365:sharepoint:Delete',
    },
  },
  {
    id: 'teams',
    name: 'Teams',
    icon: MessagesSquare,
    description: 'Create teams, manage channels and post messages (app-only).',
    service: 'teams',
    requiresMsUser: false,
    status: 'live',
    accent: 'bg-violet-50 text-violet-600',
    permissions: {
      read: 'm365:teams:Read',
      create: 'm365:teams:Create',
      write: 'm365:teams:Write',
      message: 'm365:teams:Message',
      delete: 'm365:teams:Delete',
    },
  },
  {
    id: 'onenote',
    name: 'OneNote',
    icon: Notebook,
    description: 'Notebooks and sections (connector ready, API pending).',
    service: 'onenote',
    requiresMsUser: true,
    status: 'pending',
    accent: 'bg-fuchsia-50 text-fuchsia-600',
    permissions: {
      read: 'm365:onenote:Read',
      write: 'm365:onenote:Write',
      delete: 'm365:onenote:Delete',
    },
  },
  {
    id: 'planner',
    name: 'Planner',
    icon: ListChecks,
    description: 'Tasks and buckets (connector ready, API pending).',
    service: 'planner',
    requiresMsUser: true,
    status: 'pending',
    accent: 'bg-teal-50 text-teal-600',
    permissions: {
      read: 'm365:planner:Read',
      write: 'm365:planner:Write',
      delete: 'm365:planner:Delete',
    },
  },
];

export const M365_SERVICE_MAP = Object.fromEntries(
  M365_SERVICES.map((s) => [s.id, s])
);

export const M365_LIVE_SERVICES = M365_SERVICES.filter((s) => s.status === 'live');
export const M365_PENDING_SERVICES = M365_SERVICES.filter((s) => s.status === 'pending');
