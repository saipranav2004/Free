import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  Lock,
  Cloud,
  ShieldCheck,
  KeyRound,
} from 'lucide-react';
import {
  Card,
  Button,
  Input,
  Badge,
  Spinner,
  EmptyState,
} from '../../../components/ui/primitives.jsx';
import { DataTable } from '../../../components/ui/DataTable.jsx';
import { Modal } from '../../../components/ui/Modal.jsx';
import { classNames } from '../../../utils/format.js';
import { useResource } from '../../../hooks/useResource.js';
import { useM365 } from './M365Context.jsx';
import { useM365Permission } from './hooks.js';
import { integrationApi } from '../../../lib/api/integration.js';
import { M365_SERVICES } from './registry.js';

/* ──────────────────────────────────────────────────────────────────────────
 * Access badge + denied panel
 * ──────────────────────────────────────────────────────────────────────── */
export function AccessBadge({ access }) {
  if (access.loading) return <Badge tone="slate">Checking…</Badge>;
  if (access.errored) return <Badge tone="amber">Verify on use</Badge>;
  return access.allowed ? (
    <Badge tone="green">Granted</Badge>
  ) : (
    <Badge tone="red">Denied</Badge>
  );
}

export function DeniedPanel({ action, onTryAnyway, note }) {
  return (
    <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">
      <div className="flex items-center gap-2 font-medium">
        <Lock className="h-4 w-4" /> Access denied by IAM policy
      </div>
      <p className="mt-1 text-xs text-rose-600">
        Required permission: <code>{action}</code>
      </p>
      <p className="mt-1 text-xs text-rose-600">
        {note ||
          'Request this permission from your IAM administrator, or use “Try anyway” to let the backend decide on the real request.'}
      </p>
      {onTryAnyway && (
        <Button variant="outline" size="sm" className="mt-2" onClick={onTryAnyway}>
          Try anyway
        </Button>
      )}
    </div>
  );
}

/**
 * Gates write/delete UI behind a live PDP preview for `action`.
 * Fails open: if the decision endpoint is unreachable we still render the
 * children (the backend makes the final call) but flag it for the user.
 */
export function PermissionGate({ userId, action, service, children, label }) {
  const perm = useM365Permission(userId, action, service);
  const [force, setForce] = useState(false);

  if (perm.loading) {
    return (
      <div className="py-8 text-center text-sm text-slate-400">
        <Spinner className="mx-auto" />
      </div>
    );
  }
  if (perm.errored) {
    return (
      <div>
        <div className="mb-3 flex items-center gap-2">
          <Badge tone="amber">Verify on use</Badge>
          <span className="text-xs text-slate-400">{action}</span>
        </div>
        {children}
      </div>
    );
  }
  if (perm.allowed || force) return children;
  return <DeniedPanel action={action} onTryAnyway={() => setForce(true)} />;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Result rendering
 * ──────────────────────────────────────────────────────────────────────── */
export function JsonView({ data }) {
  if (data == null) return <p className="text-xs text-slate-400">No data.</p>;
  const text = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
  return (
    <pre className="max-h-96 overflow-auto rounded-lg bg-ink-900 p-3 text-xs leading-relaxed text-emerald-200">
      {text}
    </pre>
  );
}

/**
 * Card that shows a header (with optional action button) and renders the
 * result of a manual fetch: spinner / error / table / JSON / empty state.
 */
export function ResultCard({
  title,
  description,
  icon: Icon,
  loading,
  error,
  data,
  columns,
  emptyTitle = 'No data',
  headerAction,
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {Icon && <Icon className="h-5 w-5 text-brand-600" />}
          <h3 className="text-sm font-semibold text-ink-900">{title}</h3>
        </div>
        {headerAction}
      </div>
      {description && <p className="mt-1 text-xs text-slate-400">{description}</p>}
      <div className="mt-3">
        {loading ? (
          <div className="py-6 text-center">
            <Spinner />
          </div>
        ) : error ? (
          <p className="text-xs text-rose-600">{error}</p>
        ) : columns && Array.isArray(data) && data.length ? (
          <DataTable columns={columns} data={data} />
        ) : data != null ? (
          <JsonView data={data} />
        ) : (
          <EmptyState icon={Icon} title={emptyTitle} />
        )}
      </div>
    </Card>
  );
}

export function ConfirmDelete({ open, onClose, onConfirm, busy, resource }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Confirm deletion"
      description="This action cannot be undone."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="danger" loading={busy} onClick={onConfirm}>
            Delete
          </Button>
        </>
      }
    >
      <p className="text-sm text-slate-600">
        You are about to delete{' '}
        <code className="rounded bg-slate-100 px-1 py-0.5 text-xs">{resource}</code>.
        This permanently removes the item in Microsoft 365.
      </p>
    </Modal>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * Shell: user bar + service tabs + children
 * ──────────────────────────────────────────────────────────────────────── */
export function ServiceTabs({ active }) {
  const tabs = [
    { id: 'overview', label: 'Overview', to: '/integrations/m365' },
    ...M365_SERVICES.map((s) => ({
      id: s.id,
      label: s.name,
      to: `/integrations/m365/${s.id}`,
    })),
  ];
  return (
    <div className="flex gap-1 overflow-x-auto border-b border-line">
      {tabs.map((t) => (
        <NavLink
          key={t.id}
          to={t.to}
          end={t.id === 'overview'}
          className={({ isActive }) =>
            classNames(
              'relative -mb-px whitespace-nowrap border-b-2 px-3 py-2 text-sm font-medium transition',
              isActive || active === t.id
                ? 'border-brand-600 text-brand-700'
                : 'border-transparent text-slate-500 hover:text-ink-700'
            )
          }
        >
          {t.label}
        </NavLink>
      ))}
    </div>
  );
}

export function M365UserBar({ requiresMsUser = true }) {
  const { msUser, setMsUser } = useM365();
  const health = useResource(() => integrationApi.m365.health(), []);

  return (
    <Card className="flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
      <div className="flex-1">
        <Input
          label="ms_user (UPN / email)"
          hint={
            requiresMsUser
              ? 'Most M365 endpoints act on this Microsoft 365 identity.'
              : 'Not required for this app-only service.'
          }
          placeholder="alice@contoso.com"
          value={msUser}
          onChange={(e) => setMsUser(e.target.value)}
          disabled={!requiresMsUser}
        />
      </div>
      <div className="flex items-center gap-2 text-xs">
        <Cloud className="h-4 w-4 text-slate-400" />
        {health.loading ? (
          <span className="text-slate-400">Checking connector…</span>
        ) : health.error ? (
          <Badge tone="amber">Connector: verify on use</Badge>
        ) : (
          <Badge tone="green">Connector: healthy</Badge>
        )}
      </div>
    </Card>
  );
}

export function M365Shell({ active, requiresMsUser, children }) {
  return (
    <div className="space-y-4">
      <M365UserBar requiresMsUser={requiresMsUser} />
      <ServiceTabs active={active} />
      {children}
    </div>
  );
}

/** Shown for connectors that exist but have no registered API routes yet. */
export function PendingService({ service }) {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 text-sm font-medium text-ink-900">
        <ShieldCheck className="h-5 w-5 text-brand-600" />
        Connector implemented — API endpoints pending
      </div>
      <p className="mt-2 text-sm text-slate-500">
        The <code>{service.name}</code> connector class is present in the backend
        <code> integrations/m365/connectors/</code> package, but its routes are not
        yet registered in the M365 blueprint. The client methods are wired and will
        become live as soon as the backend registers them.
      </p>
      <div className="mt-3 flex flex-wrap gap-1">
        {Object.values(service.permissions).map((p) => (
          <Badge key={p} tone="slate">
            <KeyRound className="mr-1 h-3 w-3" />
            {p}
          </Badge>
        ))}
      </div>
    </Card>
  );
}

/**
 * For user-scoped services, block the UI until an ms_user is provided in the
 * shared bar. App-only services (Teams, SharePoint) skip this.
 */
export function MsUserGuard({ service, children }) {
  const { msUser } = useM365();
  if (service.requiresMsUser && !msUser) {
    return (
      <Card className="p-6 text-center">
        <p className="text-sm font-medium text-ink-900">
          Enter an <code>ms_user</code> to use {service.name}
        </p>
        <p className="mx-auto mt-1 max-w-md text-xs text-slate-500">
          This service acts on a specific Microsoft 365 identity. Set the UPN/email
          in the field above, then come back to this tab.
        </p>
      </Card>
    );
  }
  return children;
}

/** Row of static IAM action badges for a service. */
export function PermissionBadges({ permissions }) {
  return (
    <div className="flex flex-wrap gap-1">
      {Object.values(permissions).map((p) => (
        <Badge key={p} tone="slate">
          <KeyRound className="mr-1 h-3 w-3" />
          {p}
        </Badge>
      ))}
    </div>
  );
}
