import { Link } from 'react-router-dom';
import { Cloud, FolderOpen, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../../context/AuthContext.jsx';
import { useResource } from '../../../hooks/useResource.js';
import { PageHeader } from '../../../components/common/PageHeader.jsx';
import { Card, Button, Badge, EmptyState, Spinner } from '../../../components/ui/primitives.jsx';
import { DataTable } from '../../../components/ui/DataTable.jsx';
import { integrationApi } from '../../../lib/api/integration.js';
import { M365_SERVICES, M365_LIVE_SERVICES, M365_PENDING_SERVICES } from './registry.js';
import { M365Shell, AccessBadge, PermissionBadges } from './parts.jsx';
import { useM365Permission } from './hooks.js';

function CatalogCard({ service, userId }) {
  const read = useM365Permission(userId, service.permissions.read, service.service);
  const Icon = service.icon;
  return (
    <Card className="flex flex-col p-5">
      <div className="flex items-start justify-between">
        <div className={`rounded-lg p-2.5 ${service.accent}`}>
          <Icon className="h-5 w-5" />
        </div>
        <Badge tone={service.status === 'live' ? 'green' : 'amber'}>
          {service.status === 'live' ? 'Live' : 'Pending'}
        </Badge>
      </div>
      <h3 className="mt-3 text-sm font-semibold text-ink-900">{service.name}</h3>
      <p className="mt-1 text-xs text-slate-500">{service.description}</p>
      <div className="mt-3">
        <PermissionBadges permissions={service.permissions} />
      </div>
      <div className="mt-4 flex items-center justify-between">
        <AccessBadge access={read} />
        <Link to={`/integrations/m365/${service.id}`}>
          <Button size="sm" variant="secondary">
            Open
          </Button>
        </Link>
      </div>
    </Card>
  );
}

function RegisteredResources() {
  const resources = useResource(() => integrationApi.m365.resources(), []);
  const rows = Array.isArray(resources.data) ? resources.data : [];
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FolderOpen className="h-5 w-5 text-brand-600" />
          <h3 className="text-sm font-semibold text-ink-900">Registered M365 resources</h3>
        </div>
        <Button size="sm" variant="secondary" onClick={resources.reload} loading={resources.loading}>
          Reload
        </Button>
      </div>
      <p className="mt-1 text-xs text-slate-400">
        Resources the identity is permitted to launch (IAM resource registry).
      </p>
      <div className="mt-3">
        {resources.loading ? (
          <div className="py-6 text-center">
            <Spinner />
          </div>
        ) : rows.length ? (
          <DataTable
            columns={[
              { id: 'name', header: 'Name', render: (r) => <span className="font-medium">{r.resource_name || r.name}</span> },
              { id: 'arn', header: 'ARN', render: (r) => <code className="text-xs">{r.resource_arn}</code> },
              { id: 'type', header: 'Type', render: (r) => <Badge tone="slate">{r.resource_type}</Badge> },
            ]}
            data={rows}
          />
        ) : (
          <EmptyState icon={FolderOpen} title="No resources" description="No M365 resources registered yet." />
        )}
      </div>
    </Card>
  );
}

export default function M365HubPage() {
  const { user } = useAuth();
  const userId = user?.user_id;

  return (
    <div>
      <PageHeader
        title="Microsoft 365"
        description="M365 is exposed as a set of IAM-protected services. Every action requires an IAM permission enforced by the Policy Decision Point (PDP) on each call — the badges below are a live preview."
        icon={<Cloud className="h-5 w-5" />}
      />

      <M365Shell active="overview" requiresMsUser>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
          {M365_SERVICES.map((svc) => (
            <CatalogCard key={svc.id} service={svc} userId={userId} />
          ))}
        </div>

        <div className="mt-2 flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="h-4 w-4" />
          {M365_LIVE_SERVICES.length} live services · {M365_PENDING_SERVICES.length} connector(s)
          pending API registration.
        </div>

        <RegisteredResources />
      </M365Shell>
    </div>
  );
}
