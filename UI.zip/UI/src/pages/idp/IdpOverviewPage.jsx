/**
 * IDP Overview Page — shows all adopted tenants with federation status,
 * Graph sync info, and MFA configuration.
 *
 * Enterprise pattern: Equivalent to Azure AD's "All tenants" view or Okta's
 * "Organizations" dashboard. Provides a single-pane view of all federated
 * identity providers.
 *
 * Converted from frontend 2/templates/overview.html (Jinja + vanilla JS).
 * APIs use VITE_IDP_API_BASE_URL (separate from IAM backend).
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Cloud, RefreshCw, AlertCircle, Users,
  ExternalLink, ChevronDown, ChevronUp,
} from 'lucide-react';
import { listTenants, getFederationStatus, getSyncStatus, toggleFederation, saveMfaConfig, getMfaMethods, testGraphConnection, saveGraphCredentials, syncDirectory } from '../../lib/api/idp.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Spinner } from '../../components/ui/primitives.jsx';
import { classNames } from '../../utils/format.js';

// Platform display config
const PLATFORMS = {
  entra: { label: 'Microsoft Entra', color: 'blue', icon: Cloud },
  google: { label: 'Google Workspace', color: 'green', icon: Cloud },
};

const SEG = (p) => (p === 'entra' ? 'entraid' : p);

export default function IdpOverviewPage() {
  const navigate = useNavigate();
  const [tenants, setTenants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [mfaMethods, setMfaMethods] = useState({ primary: [], stepup: [], modes: ['external', 'idp'] });

  const loadTenants = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [tenantList, methods] = await Promise.all([
        listTenants(),
        getMfaMethods().catch(() => ({ primary: [], stepup: [], modes: ['external', 'idp'] })),
      ]);
      setTenants(tenantList);
      setMfaMethods(methods);
    } catch (err) {
      // Provide specific guidance when the IDP API URL is not configured
      const msg = err.userMessage || '';
      if (msg.includes('Network Error') || msg.includes('ECONNREFUSED') || msg.includes('Failed to fetch') || msg.includes('does not exist')) {
        setError(
          'Could not connect to the IDP service. '
          + 'This page requires VITE_IDP_API_BASE_URL to be set in your .env file '
          + 'pointing to a separate AdapID server (not the IAM backend). '
          + 'See .env.example for details.'
        );
      } else {
        setError(msg || 'Could not load tenants.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTenants();
  }, [loadTenants]);

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  if (error) {
    return (
      <div>
        <PageHeader
          title="IDP Overview"
          description="All adopted identity provider tenants"
          icon={<Cloud className="h-5 w-5" />}
          actions={
            <Button onClick={loadTenants}>
              <RefreshCw className="h-4 w-4" /> Retry
            </Button>
          }
        />
        <Card className="p-6">
          <div className="flex items-center gap-3 text-rose-600">
            <AlertCircle className="h-5 w-5" />
            <span className="text-sm">{error}</span>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="IDP Overview"
        description="All adopted identity provider tenants with federation, sync, and MFA status."
        icon={<Cloud className="h-5 w-5" />}
        actions={
          <Button onClick={() => navigate('/idp/tenants')}>
            <Users className="h-4 w-4" /> Adopt Tenant
          </Button>
        }
      />

      {tenants.length === 0 ? (
        <Card className="p-8 text-center">
          <Cloud className="mx-auto h-10 w-10 text-slate-300" />
          <p className="mt-3 text-sm font-medium text-slate-500">No tenants adopted yet</p>
          <p className="mt-1 text-xs text-slate-400">
            Adopt a tenant to start federating identities.
          </p>
          <Button className="mt-4" onClick={() => navigate('/idp/tenants')}>
            Adopt your first tenant
          </Button>
        </Card>
      ) : (
        <div className="space-y-4">
          {tenants.map((t) => (
            <TenantCard
              key={t.tenant_id}
              tenant={t}
              expanded={expandedId === t.tenant_id}
              onToggle={() => setExpandedId(expandedId === t.tenant_id ? null : t.tenant_id)}
              mfaMethods={mfaMethods}
              idpBase={import.meta.env.VITE_IDP_API_BASE_URL || 'http://localhost:5000'}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * TenantCard — renders a single adopted tenant with federation toggle,
 * Graph sync controls, and MFA policy.
 *
 * Enterprise pattern: Each tenant card shows domain, platform, schema,
 * consent state, and actionable controls (sync, federation, MFA).
 */
function TenantCard({ tenant, expanded, onToggle, mfaMethods, idpBase }) {
  const t = tenant;
  const platform = PLATFORMS[t.platform] || { label: t.platform, color: 'slate', icon: Cloud };
  const isEntra = (t.platform || '').toLowerCase() === 'entra';
  const dep = t.deprecated || t.consent_state === 'deprecated';

  // Federation state
  const [fedStatus, setFedStatus] = useState(null);
  const [fedLoading, setFedLoading] = useState(false);

  // Graph credentials
  const [graphClientId, setGraphClientId] = useState('');
  const [graphClientSecret, setGraphClientSecret] = useState('');
  const [graphMsg, setGraphMsg] = useState('');
  const [graphLoading, setGraphLoading] = useState(false);

  // Sync
  const [syncMsg, setSyncMsg] = useState('');

  // MFA
  const [mfaPrimary, setMfaPrimary] = useState(t.mfa_method || 'behaviour');
  const [stepupMode, setStepupMode] = useState(t.stepup_mode || 'external');
  const [stepupMethod, setStepupMethod] = useState(t.stepup_method || 'dummy_approve');
  const [mfaMsg, setMfaMsg] = useState('');

  // Cleanup sync polling on unmount to prevent memory leaks
  const syncPollCleanupRef = useRef(null);
  useEffect(() => {
    return () => { if (syncPollCleanupRef.current) syncPollCleanupRef.current(); };
  }, []);

  // Load federation status when expanded
  useEffect(() => {
    if (!expanded || !isEntra || dep) return;
    let cancelled = false;
    (async () => {
      try {
        const d = await getFederationStatus(t.tenant_id);
        if (!cancelled) setFedStatus(d);
      } catch { /* ignore */ }
    })();
    return () => { cancelled = true; };
  }, [expanded, isEntra, dep, t.tenant_id]);

  const handleFederationToggle = async () => {
    if (!fedStatus) return;
    const turningOn = !fedStatus.status?.authentication_type || fedStatus.status.authentication_type !== 'Federated';
    if (turningOn && !window.confirm('Turn federation ON? Converts the domain to Federated in Entra.')) return;
    if (!turningOn && !window.confirm('Turn federation OFF? Reverts to Managed.')) return;

    setFedLoading(true);
    try {
      const d = await toggleFederation(t.tenant_id, turningOn);
      if (d.ok) {
        setFedStatus((s) => ({ ...s, status: { authentication_type: turningOn ? 'Federated' : 'Managed' } }));
      }
    } catch { /* ignore */ }
    setFedLoading(false);
  };

  const handleGraphTest = async () => {
    setGraphLoading(true);
    setGraphMsg('Contacting Microsoft Graph…');
    try {
      const d = await testGraphConnection(
        t.tenant_id, graphClientId, graphClientSecret
      );
      if (d.ok) {
        setGraphMsg(`Connected — ${d.sample_count} user(s).`);
      } else {
        setGraphMsg(`Failed at ${d.stage || 'request'}: ${d.detail || d.error || 'unknown'}`);
      }
    } catch (err) {
      setGraphMsg(`Failed: ${err.userMessage || err.message}`);
    }
    setGraphLoading(false);
  };

  const handleGraphSave = async () => {
    setGraphLoading(true);
    setGraphMsg('Saving…');
    try {
      await saveGraphCredentials(t.tenant_id, graphClientId, graphClientSecret);
      setGraphMsg('Saved (encrypted).');
      setGraphClientSecret('');
    } catch (err) {
      setGraphMsg(`Failed: ${err.userMessage || err.message}`);
    }
    setGraphLoading(false);
  };

  const handleSync = async () => {
    setSyncMsg('Starting…');
    try {
      const d = await syncDirectory(t.tenant_id);
      if (!d.ok && !d.job_id) {
        setSyncMsg(`Could not start: ${d.error || 'unknown'}`);
        return;
      }
      const jobId = d.job_id;
      // Poll for completion — clean up on unmount to prevent memory leaks
      let cancelled = false;
      const pollId = setInterval(async () => {
        if (cancelled) { clearInterval(pollId); return; }
        try {
          const jd = await getSyncStatus(t.tenant_id, jobId);
          const job = jd.job;
          if (!job) return;
          setSyncMsg({
            queued: 'Queued…', running: 'Syncing…', succeeded: 'Sync complete.', failed: 'Sync failed.',
          }[job.status] || job.status);
          if (job.status === 'succeeded' || job.status === 'failed') {
            clearInterval(pollId);
          }
        } catch { /* ignore */ }
      }, 2000);
      // Store cleanup function so the component can clean up on unmount
      syncPollCleanupRef.current = () => { cancelled = true; clearInterval(pollId); };
    } catch (err) {
      setSyncMsg(`Failed: ${err.userMessage || err.message}`);
    }
  };

  const handleMfaSave = async () => {
    setMfaMsg('Saving MFA policy…');
    try {
      const r = await saveMfaConfig(t.tenant_id, {
        mfa_method: mfaPrimary,
        stepup_mode: stepupMode,
        stepup_method: stepupMethod,
      });
      if (r.saved) {
        setMfaMsg(`Saved — primary ${r.mfa_method}, step-up ${r.stepup_mode}${r.stepup_mode === 'idp' ? ` (${r.stepup_method})` : ''}.`);
      } else {
        setMfaMsg(`Failed: ${r.error || 'unknown'}`);
      }
    } catch (err) {
      setMfaMsg(`Failed: ${err.userMessage || err.message}`);
    }
  };

  const seg = SEG(t.platform);
  const ssoUrl = `${idpBase}/saml/${seg}/${t.tenant_id}/sso`;
  const metadataUrl = `${idpBase}/saml/${seg}/${t.tenant_id}/metadata`;

  const chipClass = dep
    ? 'bg-rose-50 text-rose-700 ring-rose-600/20'
    : t.consent_state === 'adopted'
      ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20'
      : 'bg-amber-50 text-amber-700 ring-amber-600/20';

  return (
    <Card className="overflow-hidden">
      {/* Header */}
      <div
        className="flex cursor-pointer items-center justify-between px-5 py-4 transition hover:bg-slate-50"
        onClick={onToggle}
      >
        <div className="flex items-center gap-3">
          <div className={classNames(
            'flex h-9 w-9 items-center justify-center rounded-lg text-sm font-semibold',
            platform.color === 'blue' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'
          )}>
            <platform.icon className="h-4 w-4" />
          </div>
          <div>
            <p className="text-sm font-semibold text-ink-900">{t.display_name || t.tenant_id}</p>
            <p className="text-xs text-slate-500">
              {t.verified_domain || '(no domain)'} · {platform.label} · schema <code className="text-[11px]">{t.schema_name || '—'}</code>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className={classNames(
            'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ring-1 ring-inset',
            chipClass
          )}>
            {dep ? 'deprecated' : t.consent_state}
          </span>
          {expanded ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
        </div>
      </div>

      {/* Expanded body */}
      {expanded && (
        <div className="border-t border-slate-100 px-5 py-4 space-y-4">
          {/* SSO URLs */}
          <div className="rounded-lg bg-slate-50 p-3 text-xs space-y-1.5">
            <div className="flex gap-2">
              <span className="w-24 shrink-0 text-slate-400">SSO URL</span>
              <code className="break-all text-blue-600">{ssoUrl}</code>
              <a href={ssoUrl} target="_blank" rel="noreferrer" className="shrink-0 text-slate-400 hover:text-blue-600">
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
            {isEntra && (
              <div className="flex gap-2">
                <span className="w-24 shrink-0 text-slate-400">Metadata</span>
                <code className="break-all text-blue-600">{metadataUrl}</code>
              </div>
            )}
          </div>

          {/* Graph credentials (Entra only) */}
          {isEntra && !dep && (
            <div className="space-y-3">
              <p className="text-xs font-semibold text-ink-900">Microsoft Graph</p>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <div>
                  <label className="text-xs text-slate-500">Client ID</label>
                  <input
                    type="text"
                    value={graphClientId}
                    onChange={(e) => setGraphClientId(e.target.value)}
                    placeholder="Application (client) ID"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">Client Secret</label>
                  <input
                    type="password"
                    value={graphClientSecret}
                    onChange={(e) => setGraphClientSecret(e.target.value)}
                    placeholder="Client secret (encrypted at rest)"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="secondary" onClick={handleGraphTest} loading={graphLoading}>
                  Test connection
                </Button>
                <Button size="sm" variant="ghost" onClick={handleGraphSave} loading={graphLoading}>
                  Save credentials
                </Button>
                <Button size="sm" variant="ghost" onClick={handleSync} loading={!!syncMsg && syncMsg.includes('Syncing')}>
                  Sync directory
                </Button>
              </div>
              {graphMsg && <p className="text-xs text-slate-500">{graphMsg}</p>}
              {syncMsg && <p className="text-xs text-slate-500">{syncMsg}</p>}

              {/* Federation toggle */}
              {fedStatus && (
                <div className="flex items-center gap-3 pt-2 border-t border-slate-100">
                  <span className="text-xs text-slate-500">Federation</span>
                  <button
                    onClick={handleFederationToggle}
                    disabled={fedLoading || (!fedStatus.has_synced)}
                    className={classNames(
                      'relative inline-flex h-5 w-9 items-center rounded-full transition-colors',
                      fedStatus.status?.authentication_type === 'Federated' ? 'bg-brand-600' : 'bg-slate-300',
                      (fedLoading || !fedStatus.has_synced) && 'opacity-50 cursor-not-allowed'
                    )}
                  >
                    <span
                      className={classNames(
                        'inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform',
                        fedStatus.status?.authentication_type === 'Federated' ? 'translate-x-4' : 'translate-x-0.5'
                      )}
                    />
                  </button>
                  <span className="text-xs text-slate-400">
                    {fedStatus.status?.authentication_type === 'Federated' ? 'Federated' : 'Managed'}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* MFA Policy */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <p className="text-xs font-semibold text-ink-900">MFA Policy</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="text-xs text-slate-500">Primary method</label>
                <select
                  value={mfaPrimary}
                  onChange={(e) => setMfaPrimary(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
                >
                  {mfaMethods.primary.map((m) => (
                    <option key={m.name} value={m.name}>{m.label}</option>
                  ))}
                  {mfaMethods.primary.length === 0 && <option value="behaviour">behaviour</option>}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500">Step-up mode</label>
                <select
                  value={stepupMode}
                  onChange={(e) => {
                    setStepupMode(e.target.value);
                    if (e.target.value !== 'idp') setStepupMethod('dummy_approve');
                  }}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
                >
                  {mfaMethods.modes.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500">Step-up method <span className="text-slate-400">(idp only)</span></label>
                <select
                  value={stepupMethod}
                  disabled={stepupMode !== 'idp'}
                  onChange={(e) => setStepupMethod(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm disabled:bg-slate-100"
                >
                  {mfaMethods.stepup.map((m) => (
                    <option key={m.name} value={m.name}>{m.label}</option>
                  ))}
                  {mfaMethods.stepup.length === 0 && <option value="dummy_approve">dummy_approve</option>}
                </select>
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={handleMfaSave}>Save MFA policy</Button>
            {mfaMsg && <p className="text-xs text-slate-500">{mfaMsg}</p>}
          </div>
        </div>
      )}
    </Card>
  );
}
