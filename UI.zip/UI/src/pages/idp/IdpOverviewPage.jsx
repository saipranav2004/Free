/**
 * IdpOverviewPage — every adopted IDP tenant.
 *
 * Port of `templates/overview.html` + `static/tenant_cards.js`. The card itself
 * lives in components/idp/TenantConfigCard.jsx because the adopt wizard renders
 * the same card on its final step — exactly as the original shared one script
 * between both pages.
 *
 * Page anatomy follows the rest of the console: header → summary tiles →
 * toolbar → list. Tiles double as filters, and each tile is derived from the
 * loaded rows so it moves with every refresh.
 *
 * All requests go through lib/api/idp.js, which targets VITE_IDP_API_BASE_URL —
 * a separate service from the IAM backend.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cloud, RefreshCw, Plus, Network, ShieldCheck, AlertTriangle } from 'lucide-react';
import {
  listTenants, getMfaMethods, MFA_METHOD_FALLBACK,
} from '../../lib/api/idp.js';
import { useResource } from '../../hooks/useResource.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, EmptyState, Toolbar, SearchInput, SummaryBar, SegmentedControl,
} from '../../components/ui/primitives.jsx';
import { TenantConfigCard } from '../../components/idp/TenantConfigCard.jsx';

/* ── Microsoft Entra — TEMPORARILY DISABLED ────────────────────────────────
   The Entra tile and filter are switched off behind this flag rather than
   deleted; flip it back to `true` to restore them. Already-adopted Entra
   tenants still LIST (hiding a federated tenant would be worse than showing
   it) — their Entra-specific controls are what the flag hides, in
   TenantConfigCard. */
const ENTRA_ENABLED = false;

const PLATFORM_FILTERS = [
  { value: 'all', label: 'All' },
  // { value: 'entra', label: 'Entra' },
  { value: 'google', label: 'Google' },
  // Selectable from the summary band as well, so the control mirrors it.
  { value: 'deprecated', label: 'Deprecated' },
];

const isGoogle = (t) => String(t?.platform || '').toLowerCase() === 'google';
const isDeprecated = (t) => !!t?.deprecated || t?.consent_state === 'deprecated';

export default function IdpOverviewPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');

  /* Bug fix — a hard reload of an IDP page raced the auth bootstrap: these
     requests fired while AuthProvider was still re-hydrating, went out without
     a token, failed, and never retried (the page looked permanently broken
     until an in-app navigation re-mounted it). Gating on `bootstrapping` and
     keying the resources on `accessToken` means the first request happens once
     the session exists, and a token that arrives late re-triggers the fetch. */
  const { accessToken, bootstrapping } = useAuth();
  const sessionReady = !bootstrapping && !!accessToken;

  const tenants = useResource(
    () => (sessionReady ? listTenants() : null),
    [sessionReady]
  );
  const mfa = useResource(
    () => (sessionReady ? getMfaMethods().catch(() => MFA_METHOD_FALLBACK) : null),
    [sessionReady]
  );

  const rows = Array.isArray(tenants.data) ? tenants.data : [];
  const methods = mfa.data || MFA_METHOD_FALLBACK;

  const stats = useMemo(
    () => ({
      total: rows.length,
      entra: rows.filter((t) => !isGoogle(t) && !isDeprecated(t)).length,
      google: rows.filter((t) => isGoogle(t) && !isDeprecated(t)).length,
      deprecated: rows.filter(isDeprecated).length,
    }),
    [rows]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((t) => {
      if (platformFilter === 'entra' && isGoogle(t)) return false;
      if (platformFilter === 'google' && !isGoogle(t)) return false;
      // The band's "Deprecated" figure is a facet, so it has to narrow the list
      // it counts — an active facet that changed nothing would be a lie.
      if (platformFilter === 'deprecated' && !isDeprecated(t)) return false;
      if (!q) return true;
      return (
        String(t.display_name || '').toLowerCase().includes(q) ||
        String(t.verified_domain || '').toLowerCase().includes(q) ||
        String(t.tenant_id || '').toLowerCase().includes(q) ||
        String(t.schema_name || '').toLowerCase().includes(q) ||
        String(t.platform || '').toLowerCase().includes(q)
      );
    });
  }, [rows, search, platformFilter]);

  // A mutation inside a card (sync, federation, policy) can change what the
  // list reports, so the page re-reads rather than trusting local state.
  const reload = useCallback(() => {
    tenants.reload();
  }, [tenants]);

  // Keep the browser tab honest about which service is being administered.
  useEffect(() => {
    document.title = 'IDP · Federation overview';
  }, []);

  return (
    <div>
      <PageHeader
        title="Federation overview"
        description="Every added identity-provider tenant, with directory sync, federation state and MFA policy."
        icon={<Network className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Identity provider' }, { label: 'Overview' }]}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={reload} loading={tenants.loading}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button onClick={() => navigate('/idp/tenants')}>
              <Plus className="h-4 w-4" /> Add tenant
            </Button>
          </div>
        }
      />

      <div className="space-y-4">
        {/* Federation facets — the console's standard summary band (see
            SummaryBar): the same figures the tile strip carried, each one
            filtering the list to the platform it counts, with the active facet
            marked so it always agrees with the platform control below. */}
        <SummaryBar
          ariaLabel="Federation summary"
          loading={tenants.loading}
          value={platformFilter}
          onSelect={setPlatformFilter}
          items={[
            {
              id: 'all',
              label: 'Added tenants',
              value: stats.total,
              hint: 'Federated through this IdP',
              icon: Cloud,
            },
            ...(ENTRA_ENABLED
              ? [
                  {
                    id: 'entra',
                    label: 'Microsoft Entra',
                    value: stats.entra,
                    hint: 'Graph sync + federation',
                    tone: 'muted',
                    icon: ShieldCheck,
                  },
                ]
              : []),
            {
              id: 'google',
              label: 'Google Workspace',
              value: stats.google,
              hint: 'SAML metadata consumers',
              tone: 'positive',
              icon: ShieldCheck,
            },
            {
              id: 'deprecated',
              label: 'Deprecated',
              value: stats.deprecated,
              hint: 'Endpoints published, changes locked',
              tone: stats.deprecated ? 'warning' : 'muted',
              icon: AlertTriangle,
            },
          ]}
        />

        <Toolbar
          right={
            <div className="flex items-center gap-2">
              <SegmentedControl
                size="sm"
                ariaLabel="Filter by platform"
                value={platformFilter}
                onChange={setPlatformFilter}
                options={PLATFORM_FILTERS}
              />
              <span className="text-2xs text-slate-500 tabular">
                {filtered.length} of {stats.total} tenant{stats.total === 1 ? '' : 's'}
              </span>
            </div>
          }
        >
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search domain, display name, tenant id or schema…"
          />
        </Toolbar>

        {/* A failed load must never read as "no tenants" — the IDP service is a
            separate host, so an unreachable base URL is the likeliest cause. */}
        {tenants.error && !tenants.loading ? (
          <EmptyState
            icon={AlertTriangle}
            title="Could not reach the IDP service"
            description={tenants.error}
            action={
              <div className="flex items-center justify-center gap-2">
                <Button onClick={reload}>Retry</Button>
              </div>
            }
          />
        ) : bootstrapping || !sessionReady || tenants.loading ? (
          <EmptyState
            icon={Cloud}
            title="Loading tenants…"
            description="Reading the added tenants from the identity-provider service."
          />
        ) : rows.length === 0 ? (
          <EmptyState
            icon={Cloud}
            title="No tenants added yet"
            description="Add a verified domain to start federating identities through this IdP."
            action={<Button onClick={() => navigate('/idp/tenants')}>Add your first tenant</Button>}
          />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={Cloud}
            title={search ? `No tenants match “${search}”` : 'No tenants in this view'}
            description="Adjust the search or platform filter to see more."
            action={
              <Button
                variant="secondary"
                onClick={() => {
                  setSearch('');
                  setPlatformFilter('all');
                }}
              >
                Clear filters
              </Button>
            }
          />
        ) : (
          <div className="space-y-3">
            {filtered.map((t) => (
              <TenantConfigCard
                key={t.tenant_id}
                tenant={t}
                mfaMethods={methods}
                onChanged={reload}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
