/**
 * IDP Tenants Page — 4-step wizard for adopting a new tenant.
 *
 * Enterprise pattern: Equivalent to Azure AD's "Add tenant" wizard or Okta's
 * "Add SSO integration" flow. Guides the admin through:
 *   1. Platform selection (Entra / Google)
 *   2. Prerequisites / domain check
 *   3. Tenant details & credentials
 *   4. Configure (MFA policy)
 *
 * Converted from frontend 2/templates/tenants.html (Jinja + vanilla JS).
 * APIs use VITE_IDP_API_BASE_URL (separate from IAM backend).
 */
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Cloud, ArrowLeft, ArrowRight, Check, AlertCircle,
} from 'lucide-react';
import {
  checkDomain, adoptTenant, saveGraphCredentials,
  getMfaMethods, saveMfaConfig,
} from '../../lib/api/idp.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button } from '../../components/ui/primitives.jsx';
import { classNames } from '../../utils/format.js';

const STEPS = [
  { id: 'platform', label: '1 · Platform', short: 'Platform' },
  { id: 'prereq', label: '2 · Prerequisites', short: 'Prereq' },
  { id: 'details', label: '3 · Details', short: 'Details' },
  { id: 'config', label: '4 · Configure', short: 'Config' },
];

export default function IdpTenantsPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState('platform');
  const [platform, setPlatform] = useState('entra');

  // Domain check state
  const [domain, setDomain] = useState('');
  const [domainChecking, setDomainChecking] = useState(false);
  const [domainResult, setDomainResult] = useState(null);
  const [domainError, setDomainError] = useState('');

  // Entra details
  const [entraForm, setEntraForm] = useState({
    display_name: '',
    platform_id: '',
    graph_client_id: '',
    graph_client_secret: '',
  });
  const [entraSaving, setEntraSaving] = useState(false);
  const [entraMsg, setEntraMsg] = useState('');

  // Google details
  const [googleForm, setGoogleForm] = useState({
    display_name: '',
    sp_entity_id: '',
    sp_acs_url: '',
    sp_certificate: '',
  });
  const [googleSaving, setGoogleSaving] = useState(false);
  const [googleMsg, setGoogleMsg] = useState('');

  // Config step
  const [configTenant, setConfigTenant] = useState(null);
  const [mfaMethods, setMfaMethods] = useState({ primary: [], stepup: [], modes: ['external', 'idp'] });
  const [mfaPrimary, setMfaPrimary] = useState('behaviour');
  const [stepupMode, setStepupMode] = useState('external');
  const [stepupMethod, setStepupMethod] = useState('dummy_approve');
  const [configMsg, setConfigMsg] = useState('');

  // ─── Step Navigation ───
  const goNext = () => {
    const idx = STEPS.findIndex((s) => s.id === step);
    if (idx < STEPS.length - 1) setStep(STEPS[idx + 1].id);
  };
  const goBack = () => {
    const idx = STEPS.findIndex((s) => s.id === step);
    if (idx > 0) setStep(STEPS[idx - 1].id);
  };

  // ─── Domain Check ───
  // Returns the check result so callers can chain actions without stale state.
  const handleDomainCheck = async () => {
    if (!domain.trim()) { setDomainError('Enter a domain.'); return null; }
    setDomainChecking(true);
    setDomainError('');
    setDomainResult(null);
    try {
      const d = await checkDomain(domain.trim());
      if (!d.found) {
        setDomainError(d.error || 'Domain not found in master table.');
        return null;
      }
      setDomainResult(d);
      if (d.adopted) {
        const rec = d.record || {};
        if (platform === 'entra') {
          setEntraForm({
            display_name: rec.display_name || '',
            platform_id: rec.platform_id || '',
            graph_client_id: rec.graph_client_id || '',
            graph_client_secret: '',
          });
        } else {
          setGoogleForm({
            display_name: rec.display_name || '',
            sp_entity_id: rec.sp_entity_id || '',
            sp_acs_url: rec.sp_acs_url || '',
            sp_certificate: '',
          });
        }
      }
      return d;
    } catch (err) {
      setDomainError(err.userMessage || 'Check failed.');
      return null;
    } finally {
      setDomainChecking(false);
    }
  };

  // ─── Entra: Save & Adopt ───
  const handleEntraSave = async () => {
    setEntraSaving(true);
    setEntraMsg('');
    try {
      const adoptRes = await adoptTenant({
        domain: domain.trim(),
        platform: 'entra',
        display_name: entraForm.display_name,
        platform_id: entraForm.platform_id,
      });
      const tenantId = adoptRes.tenant?.tenant_id;
      if (entraForm.graph_client_id && entraForm.graph_client_secret && tenantId) {
        setEntraMsg('Saving Graph credentials…');
        await saveGraphCredentials(tenantId, entraForm.graph_client_id, entraForm.graph_client_secret);
      }
      setConfigTenant(adoptRes.tenant);
      setEntraMsg('Saved.');
      goNext();
    } catch (err) {
      setEntraMsg(err.userMessage || 'Failed.');
    } finally {
      setEntraSaving(false);
    }
  };

  // ─── Google: Adopt ───
  const handleGoogleAdopt = async () => {
    setGoogleSaving(true);
    setGoogleMsg('');
    try {
      const adoptRes = await adoptTenant({
        domain: domain.trim(),
        platform: 'google',
        display_name: googleForm.display_name,
        sp_entity_id: googleForm.sp_entity_id,
        sp_acs_url: googleForm.sp_acs_url,
        sp_certificate: googleForm.sp_certificate,
      });
      setConfigTenant(adoptRes.tenant);
      setGoogleMsg('Adopted.');
      goNext();
    } catch (err) {
      setGoogleMsg(err.userMessage || 'Failed.');
    } finally {
      setGoogleSaving(false);
    }
  };

  // ─── Config Step: Load MFA methods ───
  useEffect(() => {
    if (step !== 'config') return;
    getMfaMethods().then(setMfaMethods).catch(() => {});
    if (configTenant) {
      setMfaPrimary(configTenant.mfa_method || 'behaviour');
      setStepupMode(configTenant.stepup_mode || 'external');
      setStepupMethod(configTenant.stepup_method || 'dummy_approve');
    }
  }, [step, configTenant]);

  const handleMfaSave = async () => {
    if (!configTenant) return;
    setConfigMsg('Saving…');
    try {
      const r = await saveMfaConfig(configTenant.tenant_id, {
        mfa_method: mfaPrimary,
        stepup_mode: stepupMode,
        stepup_method: stepupMethod,
      });
      if (r.saved) {
        setConfigMsg(`Saved — primary ${r.mfa_method}, step-up ${r.stepup_mode}${r.stepup_mode === 'idp' ? ` (${r.stepup_method})` : ''}.`);
      } else {
        setConfigMsg(`Failed: ${r.error || 'unknown'}`);
      }
    } catch (err) {
      setConfigMsg(`Failed: ${err.userMessage || err.message}`);
    }
  };

  // ─── Prerequisites content ───
  const renderPrerequisites = () => {
    if (platform === 'entra') {
      return (
        <div className="space-y-4">
          <div className="rounded-lg border border-blue-200 bg-blue-50 p-4">
            <p className="text-sm font-semibold text-blue-900">Microsoft Entra — Before you adopt</p>
            <ol className="mt-2 space-y-1 text-sm text-blue-800 list-decimal list-inside">
              <li>Register (or reuse) an app in Entra; note the <em>Application (client) ID</em> and <em>Directory (tenant) ID</em>.</li>
              <li>Create a client secret — you'll paste it on the next step to enable directory sync.</li>
              <li>Grant the app Microsoft Graph application permissions and admin-consent them.</li>
              <li>Have the <em>verified domain</em> ready (it must already exist in the master table).</li>
            </ol>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
            <Button onClick={goNext}>Next <ArrowRight className="h-4 w-4" /></Button>
          </div>
        </div>
      );
    }

    // Google: domain check + prereq values
    return (
      <div className="space-y-4">
        <p className="text-sm text-slate-600">
          Enter the domain; we look up its tenant and generate the exact IdP values to paste into the Google Admin console.
        </p>
        <div>
          <label className="text-xs text-slate-500">Domain <span className="text-slate-400">(must exist in master table)</span></label>
          <div className="mt-1 flex gap-2">
            <input
              type="text"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              placeholder="yourdomain.com"
              className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
            />
            <Button onClick={handleDomainCheck} loading={domainChecking}>Check domain</Button>
          </div>
          {domainError && <p className="mt-1 text-xs text-rose-600">{domainError}</p>}
        </div>

        {domainResult && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4">
            <p className="text-sm text-emerald-800">Found tenant {domainResult.tenant_id}{domainResult.schema_exists ? '' : ' (schema not provisioned yet!)'}.</p>
            <div className="mt-3 space-y-1 text-xs">
              <div className="flex gap-2"><span className="w-32 text-slate-500">IdP Entity ID</span><code className="break-all text-blue-600">{domainResult.idp_issuer || '—'}</code></div>
              <div className="flex gap-2"><span className="w-32 text-slate-500">SSO URL</span><code className="break-all text-blue-600">{domainResult.sso_url || '—'}</code></div>
              <div className="flex gap-2"><span className="w-32 text-slate-500">Sign-out URL</span><code className="break-all text-blue-600">{domainResult.slo_url || '—'}</code></div>
            </div>
          </div>
        )}

        <div className="flex gap-2">
          <Button variant="secondary" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
          <Button onClick={async () => { const result = await handleDomainCheck(); if (result) goNext(); }}>
            Next <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div>
      <button
        onClick={() => navigate('/idp/overview')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> IDP Overview
      </button>

      <PageHeader
        title="Adopt a Tenant"
        description="Four steps: pick the platform, follow prerequisites, enter details, then configure."
        icon={<Cloud className="h-5 w-5" />}
      />

      {/* Step indicator */}
      <div className="mb-6 flex items-center gap-1 overflow-x-auto">
        {STEPS.map((s, i) => {
          const currentIdx = STEPS.findIndex((x) => x.id === step);
          const sIdx = i;
          const isCurrent = s.id === step;
          const isDone = sIdx < currentIdx;
          return (
            <button
              key={s.id}
              onClick={() => { if (isDone) setStep(s.id); }}
              disabled={!isDone && !isCurrent}
              className={classNames(
                'flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-all',
                isCurrent
                  ? 'bg-brand-50 text-brand-700 ring-1 ring-brand-200'
                  : isDone
                    ? 'text-emerald-600 hover:bg-emerald-50 cursor-pointer'
                    : 'text-slate-400 cursor-not-allowed'
              )}
            >
              {isDone ? <Check className="h-3.5 w-3.5" /> : null}
              <span className="hidden sm:inline">{s.label}</span>
              <span className="sm:hidden">{s.short}</span>
            </button>
          );
        })}
      </div>

      {/* Step content */}
      <Card className="p-6">
        {/* STEP 1: Platform */}
        {step === 'platform' && (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-ink-900">Which platform are you integrating?</label>
              <div className="mt-2 space-y-2">
                {[
                  { value: 'entra', label: 'Microsoft Entra', desc: 'Azure AD / Entra ID federation' },
                  { value: 'google', label: 'Google Workspace', desc: 'Google Workspace SAML federation' },
                ].map((p) => (
                  <button
                    key={p.value}
                    onClick={() => setPlatform(p.value)}
                    className={classNames(
                      'flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-all',
                      platform === p.value
                        ? 'border-brand-400 bg-brand-50 ring-1 ring-brand-200'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    )}
                  >
                    <div className={classNames(
                      'flex h-8 w-8 items-center justify-center rounded-lg',
                      platform === p.value ? 'bg-brand-100 text-brand-600' : 'bg-slate-100 text-slate-500'
                    )}>
                      <Cloud className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-ink-900">{p.label}</p>
                      <p className="text-xs text-slate-500">{p.desc}</p>
                    </div>
                    {platform === p.value && <Check className="ml-auto h-4 w-4 text-brand-600" />}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={goNext}>Next <ArrowRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}

        {/* STEP 2: Prerequisites */}
        {step === 'prereq' && renderPrerequisites()}

        {/* STEP 3: Details */}
        {step === 'details' && (
          <div className="space-y-4">
            {/* Domain check */}
            <div>
              <label className="text-xs text-slate-500">Domain <span className="text-slate-400">(must exist in master table)</span></label>
              <div className="mt-1 flex gap-2">
                <input
                  type="text"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  placeholder="yourdomain.com"
                  className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                />
                <Button onClick={handleDomainCheck} loading={domainChecking}>Check domain</Button>
              </div>
              {domainError && <p className="mt-1 text-xs text-rose-600">{domainError}</p>}
            </div>

            {/* Entra details form */}
            {platform === 'entra' && domainResult && (
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div>
                  <label className="text-xs text-slate-500">Display name</label>
                  <input
                    type="text"
                    value={entraForm.display_name}
                    onChange={(e) => setEntraForm((f) => ({ ...f, display_name: e.target.value }))}
                    placeholder="Contoso"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">Directory (tenant) ID <span className="text-slate-400">(Entra tenant GUID)</span></label>
                  <input
                    type="text"
                    value={entraForm.platform_id}
                    onChange={(e) => setEntraForm((f) => ({ ...f, platform_id: e.target.value }))}
                    placeholder="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">Graph client ID</label>
                  <input
                    type="text"
                    value={entraForm.graph_client_id}
                    onChange={(e) => setEntraForm((f) => ({ ...f, graph_client_id: e.target.value }))}
                    placeholder="Application (client) ID"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">Graph client secret <span className="text-slate-400">(stored encrypted)</span></label>
                  <input
                    type="password"
                    value={entraForm.graph_client_secret}
                    onChange={(e) => setEntraForm((f) => ({ ...f, graph_client_secret: e.target.value }))}
                    placeholder="Client secret"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                {entraMsg && <p className="text-xs text-slate-500">{entraMsg}</p>}
              </div>
            )}

            {/* Google details form */}
            {platform === 'google' && domainResult && (
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div>
                  <label className="text-xs text-slate-500">Display name</label>
                  <input
                    type="text"
                    value={googleForm.display_name}
                    onChange={(e) => setGoogleForm((f) => ({ ...f, display_name: e.target.value }))}
                    placeholder="Contoso"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">SP Entity ID <span className="text-slate-400">(from Google)</span></label>
                  <input
                    type="text"
                    value={googleForm.sp_entity_id}
                    onChange={(e) => setGoogleForm((f) => ({ ...f, sp_entity_id: e.target.value }))}
                    placeholder="google.com/a/yourdomain.com"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">SP ACS URL <span className="text-slate-400">(from Google)</span></label>
                  <input
                    type="text"
                    value={googleForm.sp_acs_url}
                    onChange={(e) => setGoogleForm((f) => ({ ...f, sp_acs_url: e.target.value }))}
                    placeholder="https://www.google.com/a/yourdomain.com/acs"
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500">SP Certificate (PEM) <span className="text-slate-400">(optional)</span></label>
                  <textarea
                    value={googleForm.sp_certificate}
                    onChange={(e) => setGoogleForm((f) => ({ ...f, sp_certificate: e.target.value }))}
                    placeholder={"-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----"}
                    rows={4}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs transition focus:border-brand-400 focus:outline-none focus:ring-1 focus:ring-brand-300"
                  />
                </div>
                {googleMsg && <p className="text-xs text-slate-500">{googleMsg}</p>}
              </div>
            )}

            <div className="flex gap-2 pt-3 border-t border-slate-100">
              <Button variant="secondary" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
              {platform === 'entra' ? (
                <Button onClick={handleEntraSave} loading={entraSaving}>Save & continue</Button>
              ) : (
                <Button onClick={handleGoogleAdopt} loading={googleSaving}>Adopt & continue</Button>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: Configure */}
        {step === 'config' && (
          <div className="space-y-4">
            {!configTenant ? (
              <p className="text-sm text-slate-500">Adopt a tenant first to configure it here.</p>
            ) : (
              <>
                <div className="rounded-lg bg-slate-50 p-3 text-xs space-y-1">
                  <div className="flex gap-2"><span className="w-28 text-slate-400">Tenant</span><code className="text-ink-900">{configTenant.tenant_id}</code></div>
                  <div className="flex gap-2"><span className="w-28 text-slate-400">Domain</span><code className="text-ink-900">{configTenant.verified_domain || '—'}</code></div>
                  <div className="flex gap-2"><span className="w-28 text-slate-400">Platform</span><code className="text-ink-900">{configTenant.platform}</code></div>
                </div>

                <p className="text-xs font-semibold text-ink-900">MFA Policy</p>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div>
                    <label className="text-xs text-slate-500">Primary method</label>
                    <select
                      value={mfaPrimary}
                      onChange={(e) => setMfaPrimary(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
                    >
                      {mfaMethods.primary.map((m) => (
                        <option key={m.name} value={m.name}>{m.label}</option>
                      ))}
                      {mfaMethods.primary.length === 0 && <option value="behaviour">behaviour</option>}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-500">Step-up mode</label>
                    <select
                      value={stepupMode}
                      onChange={(e) => {
                        setStepupMode(e.target.value);
                        if (e.target.value !== 'idp') setStepupMethod('dummy_approve');
                      }}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
                    >
                      {mfaMethods.modes.map((m) => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-500">Step-up method <span className="text-slate-400">(idp only)</span></label>
                    <select
                      value={stepupMethod}
                      disabled={stepupMode !== 'idp'}
                      onChange={(e) => setStepupMethod(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm disabled:bg-slate-100"
                    >
                      {mfaMethods.stepup.map((m) => (
                        <option key={m.name} value={m.name}>{m.label}</option>
                      ))}
                      {mfaMethods.stepup.length === 0 && <option value="dummy_approve">dummy_approve</option>}
                    </select>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
                  <Button onClick={handleMfaSave}>Save MFA policy</Button>
                </div>
                {configMsg && <p className="text-xs text-slate-500">{configMsg}</p>}
              </>
            )}
          </div>
        )}
      </Card>
    </div>
  );
}
