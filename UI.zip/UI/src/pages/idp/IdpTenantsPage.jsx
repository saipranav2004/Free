/**
 * IdpTenantsPage — the four-step "adopt a tenant" wizard.
 *
 * Port of `templates/tenants.html`. The original's two platform paths are
 * preserved exactly, because they are genuinely different sequences:
 *
 *   Microsoft Entra                    Google Workspace
 *   1 Platform                         1 Platform
 *   2 Prerequisites (read-only)        2 Domain → we emit the IdP values that
 *                                        embed the tenant id, for pasting into
 *                                        the Google Admin console
 *   3 Domain check → details +         3 SP details (entity id, ACS, cert)
 *     Graph credentials
 *   4 Configure the adopted tenant     4 Configure the adopted tenant
 *
 * Step 4 renders the shared TenantConfigCard — the same component the Overview
 * page uses — so the tenant just adopted can be configured immediately, with
 * the same controls it will have later. The card is fed from a fresh read of
 * /api/tenants rather than the adopt response, so schema, consent state and
 * policy are the server's values.
 *
 * Requests go through lib/api/idp.js (VITE_IDP_API_BASE_URL — separate service).
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Cloud, ArrowLeft, ArrowRight, Check, Copy, AlertTriangle, CheckCircle2, Network,
} from 'lucide-react';
import {
  checkDomain, adoptTenant, saveGraphCredentials, getTenant, getMfaMethods,
  MFA_METHOD_FALLBACK, samlEndpoints,
} from '../../lib/api/idp.js';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Card, Button, Input, Textarea, Badge, Spinner, IconButton,
} from '../../components/ui/primitives.jsx';
import { TenantConfigCard } from '../../components/idp/TenantConfigCard.jsx';
import { classNames } from '../../utils/format.js';

const STEPS = [
  { id: 'platform', n: '1', label: 'Platform' },
  { id: 'two', n: '2', label: 'Prerequisites', googleLabel: 'Domain' },
  { id: 'three', n: '3', label: 'Details' },
  { id: 'config', n: '4', label: 'Configure' },
];

/* ── Microsoft Entra — TEMPORARILY DISABLED ────────────────────────────────
   Every Entra surface (platform choice, prerequisites step, Graph credentials,
   directory sync, the federation switch and the Entra tile/filter) is switched
   off behind this one flag rather than deleted, so the flow can be restored by
   flipping it back to `true` with no code archaeology. The Google Workspace
   path is unaffected. */
const ENTRA_ENABLED = false;

const PLATFORMS = [
  // {
  //   value: 'entra',
  //   label: 'Microsoft Entra',
  //   desc: 'Directory sync over Microsoft Graph, then federate the domain.',
  // },
  {
    value: 'google',
    label: 'Google Workspace',
    desc: 'Custom SAML app — Google consumes this IdP’s metadata.',
  },
];

const EMPTY_ENTRA = { display_name: '', platform_id: '', graph_client_id: '', graph_client_secret: '' };
const EMPTY_GOOGLE = { display_name: '', sp_entity_id: '', sp_acs_url: '', sp_certificate: '' };

/** One copyable IdP value for the Google Admin console. */
function ValueRow({ label, value }) {
  const toast = useToast();
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(`${label} copied.`);
    } catch {
      toast.error('Clipboard is unavailable in this browser.');
    }
  };
  return (
    <div className="flex items-start gap-2 py-1">
      <span className="w-[132px] shrink-0 text-2xs font-medium uppercase tracking-[0.06em] text-slate-400">
        {label}
      </span>
      <code className="min-w-0 flex-1 break-all font-mono text-xs text-brand-700">{value || '—'}</code>
      {value && <IconButton icon={Copy} title={`Copy ${label}`} size="xs" onClick={copy} />}
    </div>
  );
}

export default function IdpTenantsPage() {
  const navigate = useNavigate();
  const toast = useToast();
  /* See IdpOverviewPage: on a hard reload the session is still re-hydrating, so
     nothing here may call the service until it exists. Every request on this
     page is user-initiated, which is why a gate on the submit paths is enough —
     but step 4 loads on mount, so it waits on this. */
  const { accessToken, bootstrapping } = useAuth();
  const sessionReady = !bootstrapping && !!accessToken;

  const [step, setStep] = useState('platform');
  // Google is the only selectable platform while Entra is disabled.
  const [platform, setPlatform] = useState(ENTRA_ENABLED ? 'entra' : 'google');
  const isGoogle = !ENTRA_ENABLED || platform === 'google';

  // Domain resolution — the check result is the gate for every later step.
  const [domain, setDomain] = useState('');
  const [checking, setChecking] = useState(false);
  const [checked, setChecked] = useState(null); // the /api/tenants/check payload
  const [checkError, setCheckError] = useState('');

  const [entraForm, setEntraForm] = useState(EMPTY_ENTRA);
  const [googleForm, setGoogleForm] = useState(EMPTY_GOOGLE);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState(null); // { tone, text }

  // Step 4
  const [configTenantId, setConfigTenantId] = useState(null);
  const [configTenant, setConfigTenant] = useState(null);
  const [configLoading, setConfigLoading] = useState(false);
  const [configError, setConfigError] = useState('');
  const [mfaMethods, setMfaMethods] = useState(MFA_METHOD_FALLBACK);

  const stepIndex = STEPS.findIndex((s) => s.id === step);
  const goTo = (id) => setStep(id);
  const goNext = () => { if (stepIndex < STEPS.length - 1) setStep(STEPS[stepIndex + 1].id); };
  const goBack = () => { if (stepIndex > 0) setStep(STEPS[stepIndex - 1].id); };

  /* Switching platform invalidates a resolved domain: the two paths ask for
     different things and a check carries platform-specific pre-fill. */
  const changePlatform = (value) => {
    if (value === platform) return;
    setPlatform(value);
    setChecked(null);
    setCheckError('');
    setSaveMsg(null);
    setEntraForm(EMPTY_ENTRA);
    setGoogleForm(EMPTY_GOOGLE);
  };

  /** POST /api/tenants/check — resolve the domain and pre-fill if adopted. */
  const runCheck = useCallback(async () => {
    const value = domain.trim();
    if (!value) {
      setCheckError('Enter a domain.');
      return null;
    }
    setChecking(true);
    setCheckError('');
    setChecked(null);
    setSaveMsg(null);
    try {
      const d = await checkDomain(value);
      if (!d?.found) {
        setCheckError(d?.error || 'That domain is not in the master table.');
        return null;
      }
      setChecked(d);
      // An already-adopted tenant pre-fills, so "re-adopt" is an edit rather
      // than a blank form the admin has to retype.
      if (d.adopted) {
        const rec = d.record || {};
        if (platform === 'entra') {
          setEntraForm({
            display_name: rec.display_name || '',
            platform_id: rec.platform_id || '',
            graph_client_id: rec.graph_client_id || '',
            graph_client_secret: '',
          });
        } else {
          setGoogleForm({
            display_name: rec.display_name || '',
            sp_entity_id: rec.sp_entity_id || '',
            sp_acs_url: rec.sp_acs_url || '',
            sp_certificate: '',
          });
        }
      }
      return d;
    } catch (err) {
      setCheckError(err.userMessage || 'The domain check failed.');
      return null;
    } finally {
      setChecking(false);
    }
  }, [domain, platform]);

  /** True when an adopted tenant's form is untouched — nothing to re-submit. */
  const unchanged = useMemo(() => {
    if (!checked?.adopted) return false;
    const rec = checked.record || {};
    if (platform === 'entra') {
      return (
        !entraForm.graph_client_secret.trim() &&
        entraForm.display_name.trim() === (rec.display_name || '') &&
        entraForm.platform_id.trim() === (rec.platform_id || '') &&
        entraForm.graph_client_id.trim() === (rec.graph_client_id || '')
      );
    }
    return (
      !googleForm.sp_certificate.trim() &&
      googleForm.display_name.trim() === (rec.display_name || '') &&
      googleForm.sp_entity_id.trim() === (rec.sp_entity_id || '') &&
      googleForm.sp_acs_url.trim() === (rec.sp_acs_url || '')
    );
  }, [checked, platform, entraForm, googleForm]);

  const openConfig = (tenantId) => {
    setConfigTenantId(tenantId);
    goTo('config');
  };

  /** Entra: adopt, then save Graph credentials if both were supplied. */
  const submitEntra = async () => {
    if (!checked) {
      setSaveMsg({ tone: 'err', text: 'Check the domain first.' });
      return;
    }
    if (!entraForm.display_name.trim()) {
      setSaveMsg({ tone: 'err', text: 'Enter a display name.' });
      return;
    }
    if (!entraForm.platform_id.trim()) {
      setSaveMsg({ tone: 'err', text: 'Enter the Directory (tenant) ID.' });
      return;
    }
    // Nothing edited on an already-adopted tenant → skip a pointless write.
    if (unchanged) {
      openConfig(checked.tenant_id);
      return;
    }

    setSaving(true);
    setSaveMsg({ tone: 'info', text: 'Adding tenant…' });
    try {
      const res = await adoptTenant({
        domain: checked.domain || domain.trim(),
        platform: 'entra',
        display_name: entraForm.display_name.trim(),
        platform_id: entraForm.platform_id.trim(),
      });
      const tenantId = res?.tenant?.tenant_id || checked.tenant_id;

      const cid = entraForm.graph_client_id.trim();
      const secret = entraForm.graph_client_secret.trim();
      if (cid && secret) {
        setSaveMsg({ tone: 'info', text: 'Saving Graph credentials…' });
        await saveGraphCredentials(tenantId, cid, secret);
      }
      toast.success('Tenant added.');
      openConfig(tenantId);
    } catch (err) {
      setSaveMsg({ tone: 'err', text: err.userMessage || 'Could not add tenant.' });
    } finally {
      setSaving(false);
    }
  };

  /** Google: adopt with the SP details. */
  const submitGoogle = async () => {
    if (!checked) {
      setSaveMsg({ tone: 'err', text: 'Check the domain on step 2 first.' });
      return;
    }
    if (!googleForm.sp_entity_id.trim() || !googleForm.sp_acs_url.trim()) {
      setSaveMsg({ tone: 'err', text: 'SP Entity ID and ACS URL are both required.' });
      return;
    }
    if (unchanged) {
      openConfig(checked.tenant_id);
      return;
    }

    setSaving(true);
    setSaveMsg({ tone: 'info', text: 'Adding tenant…' });
    try {
      const res = await adoptTenant({
        domain: checked.domain || domain.trim(),
        platform: 'google',
        display_name: googleForm.display_name.trim(),
        sp_entity_id: googleForm.sp_entity_id.trim(),
        sp_acs_url: googleForm.sp_acs_url.trim(),
        // Blank keeps the certificate already on file.
        sp_certificate: googleForm.sp_certificate.trim(),
      });
      toast.success('Tenant added.');
      openConfig(res?.tenant?.tenant_id || checked.tenant_id);
    } catch (err) {
      setSaveMsg({ tone: 'err', text: err.userMessage || 'Could not add tenant.' });
    } finally {
      setSaving(false);
    }
  };

  /* Step 4 reads the tenant back from the service so the card shows the stored
     record (schema, consent state, saved policy) rather than the adopt echo. */
  const loadConfigTenant = useCallback(async () => {
    if (!configTenantId) return;
    setConfigLoading(true);
    setConfigError('');
    try {
      const [t, methods] = await Promise.all([
        getTenant(configTenantId),
        getMfaMethods().catch(() => MFA_METHOD_FALLBACK),
      ]);
      if (!t) {
        setConfigError('The tenant could not be found in the tenant list.');
      }
      setConfigTenant(t);
      setMfaMethods(methods || MFA_METHOD_FALLBACK);
    } catch (err) {
      setConfigError(err.userMessage || 'Could not load the tenant.');
    } finally {
      setConfigLoading(false);
    }
  }, [configTenantId]);

  useEffect(() => {
    if (step === 'config' && sessionReady) loadConfigTenant();
  }, [step, sessionReady, loadConfigTenant]);

  const endpoints = checked?.tenant_id ? samlEndpoints('google', checked.tenant_id) : null;

  /* ── Resolved-domain banner, shared by both paths ── */
  const renderCheckResult = () => {
    if (checkError) {
      return (
        <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-600" />
          <p className="text-xs leading-snug text-rose-700">{checkError}</p>
        </div>
      );
    }
    if (!checked) return null;
    return (
      <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2.5">
        <div className="flex items-start gap-2">
          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-emerald-800">
              Tenant {checked.tenant_id}
              {checked.adopted ? ' is already added' : ' found'}
            </p>
            <p className="mt-0.5 text-[11px] leading-snug text-emerald-700">
              {checked.adopted
                ? 'The fields below are pre-filled. Update and save, or continue straight to configuration.'
                : checked.schema_exists === false
                  ? 'Its schema is not provisioned yet — adding it will still record the tenant.'
                  : `Schema ${checked.schema || '—'} is provisioned.`}
            </p>
            {checked.adopted && (
              <Button
                variant="secondary"
                size="sm"
                className="mt-2"
                onClick={() => openConfig(checked.tenant_id)}
              >
                Continue to configure <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
          {checked.adopted && <Badge tone="green">added</Badge>}
        </div>
      </div>
    );
  };

  const domainField = (
    <div className="flex items-end gap-2">
      <Input
        label="Domain"
        className="flex-1"
        value={domain}
        onChange={(e) => setDomain(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); runCheck(); } }}
        placeholder="yourdomain.com"
        autoComplete="off"
        hint="Must already exist as a verified domain in the master table."
        required
      />
      <Button className="mb-6" onClick={runCheck} loading={checking}>
        Check domain
      </Button>
    </div>
  );

  return (
    <div>
      <PageHeader
        title="Add a tenant"
        description="Pick the platform, satisfy the prerequisites, enter the details after the domain is verified, then configure the tenant."
        icon={<Cloud className="h-4.5 w-4.5" />}
        breadcrumbs={[
          { label: 'Identity provider' },
          { label: 'Overview', to: '/idp/overview' },
          { label: 'Add a tenant' },
        ]}
        actions={
          <Button variant="secondary" onClick={() => navigate('/idp/overview')}>
            <Network className="h-4 w-4" /> All tenants
          </Button>
        }
      />

      {/* ── Step rail ── */}
      <div className="mb-4 flex items-center gap-1 overflow-x-auto border-b border-line pb-px">
        {STEPS.map((s, i) => {
          const isCurrent = s.id === step;
          const isDone = i < stepIndex;
          const label = isGoogle && s.googleLabel ? s.googleLabel : s.label;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => { if (isDone) goTo(s.id); }}
              disabled={!isDone && !isCurrent}
              aria-current={isCurrent ? 'step' : undefined}
              className={classNames(
                'flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-2.5 text-[13px] font-medium transition-colors focus-visible:outline-none',
                isCurrent
                  ? 'border-brand-500 text-brand-700'
                  : isDone
                    ? 'cursor-pointer border-transparent text-emerald-600 hover:text-emerald-700'
                    : 'cursor-not-allowed border-transparent text-slate-400'
              )}
            >
              {isDone ? (
                <Check className="h-3.5 w-3.5" />
              ) : (
                <span
                  className={classNames(
                    'flex h-4 w-4 items-center justify-center rounded-full text-3xs font-bold',
                    isCurrent ? 'bg-brand-100 text-brand-700' : 'bg-slate-100 text-slate-400'
                  )}
                >
                  {s.n}
                </span>
              )}
              {label}
            </button>
          );
        })}
      </div>

      {/* ── STEP 1: platform ── */}
      {step === 'platform' && (
        <Card className="p-5">
          <p className="text-sm font-medium text-ink-900">Which platform are you integrating?</p>
          <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {PLATFORMS.map((p) => {
              const active = platform === p.value;
              return (
                <button
                  key={p.value}
                  type="button"
                  onClick={() => changePlatform(p.value)}
                  aria-pressed={active}
                  className={classNames(
                    'flex items-start gap-3 rounded-xl border p-3.5 text-left transition-colors focus-visible:outline-none',
                    active
                      ? 'border-brand-400 bg-brand-50/60 ring-1 ring-brand-200'
                      : 'border-line hover:border-slate-300 hover:bg-slate-50'
                  )}
                >
                  <span
                    className={classNames(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg',
                      active ? 'bg-brand-100 text-brand-700' : 'bg-slate-100 text-slate-500'
                    )}
                  >
                    <Cloud className="h-4 w-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-semibold text-ink-900">{p.label}</span>
                    <span className="mt-0.5 block text-xs leading-snug text-slate-500">{p.desc}</span>
                  </span>
                  {active && <Check className="h-4 w-4 shrink-0 text-brand-600" />}
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex justify-end">
            <Button onClick={goNext}>Next <ArrowRight className="h-4 w-4" /></Button>
          </div>
        </Card>
      )}

      {/* ── STEP 2 ── Entra: prerequisites. Google: domain → IdP values. */}
      {step === 'two' && (
        <Card className="space-y-4 p-5">
          {ENTRA_ENABLED && !isGoogle ? (
            <>
              <div className="rounded-lg border border-brand-200 bg-brand-50/60 p-4">
                <p className="text-[13px] font-semibold text-ink-900">
                  Microsoft Entra — before you add
                </p>
                <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-xs leading-relaxed text-ink-700">
                  <li>
                    Register (or reuse) an app in Entra; note the <em className="not-italic font-medium text-brand-700">Application (client) ID</em> and{' '}
                    <em className="not-italic font-medium text-brand-700">Directory (tenant) ID</em>.
                  </li>
                  <li>Create a client secret — you will paste it on the next step to enable directory sync.</li>
                  <li>Grant the app the Microsoft Graph application permissions and admin-consent them.</li>
                  <li>Have the verified domain ready — it must already exist in the master table.</li>
                </ol>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
                <Button onClick={goNext}>Next <ArrowRight className="h-4 w-4" /></Button>
              </div>
            </>
          ) : (
            <>
              <div className="rounded-lg border border-brand-200 bg-brand-50/60 p-4">
                <p className="text-[13px] font-semibold text-ink-900">
                  Google Workspace — start with your domain
                </p>
                <p className="mt-1 text-xs leading-relaxed text-ink-700">
                  The IdP values below embed the tenant id, so the domain has to be resolved first.
                  Paste them into Google Admin console → Web and mobile apps → Add custom SAML app.
                </p>
              </div>

              {domainField}
              {renderCheckResult()}

              {endpoints && (
                <div className="rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2.5">
                  <p className="mb-1 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                    Give these to Google
                  </p>
                  <ValueRow label="IdP Entity ID" value={endpoints.entityId} />
                  <ValueRow label="SSO URL" value={endpoints.sso} />
                  <ValueRow label="Sign-out URL" value={endpoints.slo} />
                  <ValueRow label="Change password" value={endpoints.changePassword} />
                  <ValueRow label="Metadata" value={endpoints.metadata} />
                  <p className="mt-1.5 text-[11px] text-slate-500">
                    Certificate: your AdapID signing certificate, published in the metadata above.
                  </p>
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="secondary" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
                <Button
                  onClick={async () => {
                    // Resolve first if the admin skipped the explicit check.
                    const result = checked || (await runCheck());
                    if (result) goNext();
                  }}
                  loading={checking}
                >
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </Card>
      )}

      {/* ── STEP 3 ── Entra: domain check + details. Google: SP details. */}
      {step === 'three' && (
        <Card className="space-y-4 p-5">
          {ENTRA_ENABLED && !isGoogle && (
            <>
              {domainField}
              {renderCheckResult()}
            </>
          )}

          {isGoogle && !checked && (
            <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
              <p className="text-xs leading-snug text-amber-800">
                Resolve the domain on step 2 before entering the service-provider details.
              </p>
            </div>
          )}

          {ENTRA_ENABLED && !isGoogle && checked && (
            <div className="space-y-3 border-t border-line-soft pt-4">
              <Input
                label="Display name"
                value={entraForm.display_name}
                onChange={(e) => setEntraForm((f) => ({ ...f, display_name: e.target.value }))}
                placeholder="Contoso"
                autoComplete="off"
                required
              />
              <Input
                label="Directory (tenant) ID"
                value={entraForm.platform_id}
                onChange={(e) => setEntraForm((f) => ({ ...f, platform_id: e.target.value }))}
                placeholder="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
                hint="The Entra tenant GUID."
                className="font-mono"
                autoComplete="off"
                required
              />
              <Input
                label="Graph client ID"
                value={entraForm.graph_client_id}
                onChange={(e) => setEntraForm((f) => ({ ...f, graph_client_id: e.target.value }))}
                placeholder="Application (client) ID"
                autoComplete="off"
              />
              <Input
                label="Graph client secret"
                type="password"
                value={entraForm.graph_client_secret}
                onChange={(e) => setEntraForm((f) => ({ ...f, graph_client_secret: e.target.value }))}
                /* A secret already on file is never returned by the API, so the
                   placeholder says what leaving this blank will do. */
                placeholder={checked.has_secret ? '•••••••• (secret on file)' : 'Client secret'}
                hint={
                  checked.has_secret
                    ? 'Stored encrypted. Leave blank to keep the secret already on file.'
                    : 'Stored encrypted; required with the client ID to enable directory sync.'
                }
                autoComplete="new-password"
              />
            </div>
          )}

          {isGoogle && checked && (
            <div className="space-y-3">
              <Input
                label="Display name"
                value={googleForm.display_name}
                onChange={(e) => setGoogleForm((f) => ({ ...f, display_name: e.target.value }))}
                placeholder="Contoso"
                autoComplete="off"
              />
              <Input
                label="SP Entity ID"
                value={googleForm.sp_entity_id}
                onChange={(e) => setGoogleForm((f) => ({ ...f, sp_entity_id: e.target.value }))}
                placeholder="google.com/a/yourdomain.com"
                hint="Copied from the Google custom SAML app."
                autoComplete="off"
                required
              />
              <Input
                label="SP ACS URL"
                value={googleForm.sp_acs_url}
                onChange={(e) => setGoogleForm((f) => ({ ...f, sp_acs_url: e.target.value }))}
                placeholder="https://www.google.com/a/yourdomain.com/acs"
                autoComplete="off"
                required
              />
              <Textarea
                label="SP certificate (PEM)"
                rows={5}
                value={googleForm.sp_certificate}
                onChange={(e) => setGoogleForm((f) => ({ ...f, sp_certificate: e.target.value }))}
                placeholder={
                  checked.has_certificate
                    ? '•••••••• (certificate on file — leave blank to keep)'
                    : '-----BEGIN CERTIFICATE-----\n…\n-----END CERTIFICATE-----'
                }
                hint="Optional. When set, the assertion is encrypted with this certificate."
                className="font-mono text-xs"
              />
            </div>
          )}

          {saveMsg && (
            <p
              className={classNames(
                'text-xs leading-snug',
                saveMsg.tone === 'ok'
                  ? 'text-emerald-700'
                  : saveMsg.tone === 'err'
                    ? 'text-rose-600'
                    : 'text-slate-500'
              )}
            >
              {saveMsg.text}
            </p>
          )}

          <div className="flex gap-2 border-t border-line-soft pt-4">
            <Button variant="secondary" onClick={goBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
            {ENTRA_ENABLED && !isGoogle ? (
              <Button onClick={submitEntra} loading={saving} disabled={!checked}>
                {unchanged ? 'Continue' : 'Save & continue'}
                <ArrowRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={submitGoogle} loading={saving} disabled={!checked}>
                {unchanged ? 'Continue' : 'Add & continue'}
                <ArrowRight className="h-4 w-4" />
              </Button>
            )}
          </div>
        </Card>
      )}

      {/* ── STEP 4: configure the adopted tenant (shared card) ── */}
      {step === 'config' && (
        <div className="space-y-3">
          {!configTenantId ? (
            <Card className="p-5">
              <p className="text-sm font-medium text-ink-900">Nothing to configure yet</p>
              <p className="mt-1 text-xs text-slate-500">
                Add a tenant on the previous steps and it will open here.
              </p>
              <Button className="mt-3" variant="secondary" onClick={() => goTo('platform')}>
                <ArrowLeft className="h-4 w-4" /> Start over
              </Button>
            </Card>
          ) : configLoading ? (
            <div className="flex justify-center py-16">
              <Spinner className="h-7 w-7" />
            </div>
          ) : configError ? (
            <Card className="p-5">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
                <div>
                  <p className="text-sm font-medium text-ink-900">{configError}</p>
                  <div className="mt-3 flex gap-2">
                    <Button variant="secondary" onClick={loadConfigTenant}>Retry</Button>
                    <Button onClick={() => navigate('/idp/overview')}>Go to overview</Button>
                  </div>
                </div>
              </div>
            </Card>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs text-slate-500">
                  Configure this tenant now, or manage every tenant from the overview.
                </p>
                <Button variant="secondary" size="sm" onClick={() => navigate('/idp/overview')}>
                  <Network className="h-3.5 w-3.5" /> All tenants
                </Button>
              </div>
              <TenantConfigCard
                tenant={configTenant}
                mfaMethods={mfaMethods}
                defaultExpanded
                showDetails
                onChanged={loadConfigTenant}
              />
            </>
          )}
        </div>
      )}
    </div>
  );
}
