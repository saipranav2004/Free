/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        /**
         * Brand ramp — retuned to a calmer, deeper royal blue.
         * The previous ramp (#3366ff / #1f47f5) read as consumer-electric;
         * enterprise security consoles use a lower-chroma blue so that
         * semantic status colours (emerald / amber / rose) stay dominant.
         */
        brand: {
          50: '#f1f4fd',
          100: '#e0e7fa',
          200: '#c5d1f4',
          300: '#9fb1ea',
          400: '#7189dc',
          500: '#4f68cb',
          600: '#3b51b8',
          700: '#324298',
          800: '#2b387c',
          900: '#273263',
        },
        ink: {
          900: '#0d1424',
          800: '#151d31',
          700: '#293349',
          600: '#41506b',
        },
        /** Neutral surface tokens (used alongside Tailwind's slate scale). */
        canvas: '#f4f5f8',
        line: {
          DEFAULT: '#e3e7ee',
          soft: '#eef1f6',
          strong: '#d2d8e3',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      spacing: {
        4.5: '1.125rem',
        13: '3.25rem',
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }], // 11px
        '3xs': ['0.625rem', { lineHeight: '0.875rem' }], // 10px
      },
      boxShadow: {
        card: '0 1px 2px rgba(13, 20, 36, 0.04)',
        raised: '0 1px 2px rgba(13, 20, 36, 0.05), 0 4px 12px -4px rgba(13, 20, 36, 0.08)',
        popover: '0 4px 6px -2px rgba(13, 20, 36, 0.06), 0 12px 28px -8px rgba(13, 20, 36, 0.18)',
        overlay: '0 24px 48px -12px rgba(13, 20, 36, 0.28)',
        rail: '1px 0 0 rgba(227, 231, 238, 1)',
      },
      keyframes: {
        'fade-in': {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        'dialog-in': {
          from: { opacity: '0', transform: 'translateY(8px) scale(0.985)' },
          to: { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'pop-in': {
          from: { opacity: '0', transform: 'translateY(-4px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'toast-in': {
          from: { opacity: '0', transform: 'translateX(12px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
        'bar-grow': {
          from: { transform: 'scaleX(0)' },
          to: { transform: 'scaleX(1)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 140ms ease-out',
        'dialog-in': 'dialog-in 160ms cubic-bezier(0.22, 1, 0.36, 1)',
        'pop-in': 'pop-in 120ms ease-out',
        'toast-in': 'toast-in 180ms cubic-bezier(0.22, 1, 0.36, 1)',
      },
    },
  },
  plugins: [],
};
