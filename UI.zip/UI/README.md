# IAM Control Center — Dashboard Frontend

A production-quality **IAM administration dashboard** for the Flask / Oracle / OPA
IAM backend described in the `iam_final-*.pdf` source export. It is built with
**React 18 + JavaScript + Tailwind CSS (Vite)** and wires **every confirmed
backend API** end-to-end, plus a policy-decision simulator and a live Microsoft
365 connector surface.

---

## Table of contents
- [Tech stack](#tech-stack)
- [Project structure](#project-structure)
- [Getting started](#getting-started)
- [Authentication flows](#authentication-flows)
  - [Tenant / account_id gate](#tenant--account_id-gate)
  - [Two-step MFA login](#two-step-mfa-login)
  - [SSO (entra_id)](#sso-microsoft-entra-id)
- [Backend API mapping (confirmed vs inferred)](#backend-api-mapping)
- [Response envelope & error handling](#response-envelope--error-handling)
- [Pages / feature map](#pages--feature-map)
- [Known gaps / inferred endpoints](#known-gaps--inferred-endpoints)

---

## Tech stack
| Concern        | Choice |
|----------------|--------|
| UI framework   | React 18.3 (`react`, `react-dom`) |
| Routing        | `react-router-dom` v6 (protected shell, lazy-friendly) |
| Build tool     | Vite 5 |
| Styling        | Tailwind CSS 3.4 (+ PostCSS / Autoprefixer) |
| HTTP           | `axios` (single instance, interceptors) |
| Icons          | `lucide-react` |
| Utilities      | `clsx` |
| Auth state     | React Context (`AuthContext`) + `localStorage` token store |
| Toasts         | React Context (`ToastContext`) |

---

## Project structure
```
iam-dashboard/
├── index.html
├── vite.config.js            # dev proxy → http://localhost:5000
├── tailwind.config.js
├── postcss.config.js
├── .env.example
├── public/favicon.svg
└── src/
    ├── main.jsx              # root render + providers
    ├── App.jsx
    ├── index.css             # tailwind layers + design tokens
    ├── routes/AppRoutes.jsx  # all routes, protected shell
    ├── lib/
    │   ├── apiClient.js      # axios: envelope unwrap + 401 auto-refresh
    │   ├── tokenStore.js     # localStorage: tokens, user, account_id
    │   └── api/              # one module per backend domain
    │       ├── auth.js       ├── mfa.js        ├── sessions.js
    │       ├── rbac.js       ├── pbac.js       ├── identity.js
    │       └── integration.js
    ├── context/              # AuthContext, ToastContext
    ├── hooks/useResource.js  # minimal GET data hook {data,loading,error,reload}
    ├── utils/                # constants, format, permissions
    ├── components/
    │   ├── ui/               # primitives, Modal, ConfirmDialog, Toast, DataTable
    │   ├── common/           # PageHeader, Pagination, AccountGate
    │   └── layout/           # Sidebar, Topbar, AppLayout, ProtectedRoute
    └── pages/                # auth / identity / rbac / pbac / integrations / settings
```

---

## Getting started
```bash
# 1. install
npm install

# 2. configure (optional — defaults use the dev proxy)
cp .env.example .env
#   VITE_API_BASE_URL=      # leave empty in dev → proxied to :5000
#   VITE_SSO_PROVIDERS=entra_id

# 3. ensure the Flask IAM backend is running on :5000, then:
npm run dev          # http://localhost:5173  (proxies /api and /.well-known → :5000)

# production build
npm run build        # → dist/
npm run preview      # serve the built bundle
```

**Vite dev proxy** (`vite.config.js`) forwards `/api` and `/.well-known` to
`http://localhost:5000`, so no CORS / cookie headaches during development. For a
production build, set `VITE_API_BASE_URL` to your gateway and the same base is
used for every request (including the `/api/v1/auth/refresh` token rotation
call, which is made on the raw `axios` instance).

---

## Authentication flows

### Tenant / `account_id` gate
The backend login contract requires a **tenant identifier** (`account_id`). The
dashboard therefore:
- Persists `account_id` in `localStorage` (`tokenStore.setAccountId`) alongside
  the access/refresh tokens.
- Renders `AccountGate` around tenant-scoped screens (Identity, etc.). If no
  `account_id` is present, the page prompts the operator to set/select the
  active tenant before making any `/api/v1/identity/accounts/<account_id>/...`
  call.
- Surfaces an "Account ID (tenant)" field on the login form.

### Two-step MFA login
1. **Login** → `POST /api/v1/auth/login` with
   `{ identifier, password, account_id }` (confirmed endpoint).
   - If `mfa_required: true` → backend returns `{ mfa_challenge_token }`.
     `AuthContext.login` returns `{ mfaRequired: true, challengeToken }` and the
     app routes to `/login/mfa`.
   - Otherwise the response carries the token bundle + `user`; `AuthContext`
     applies the session immediately.
2. **MFA verify** → `POST /api/v1/auth/mfa/login/verify` with
   `{ mfa_challenge_token, code }` (confirmed endpoint, **`mfaApi.verifyMfa`**).
   Returns the token bundle; `AuthContext.completeMfa` applies it.

> ⚠️ This `verifyMfa` (login step) is **distinct** from `mfaApi.setupVerify`
> (`POST /api/v1/auth/mfa/setup/verify`), which is the TOTP *enrollment* step.

### SSO (entra_id)
1. User clicks a provider button → `POST /api/v1/auth/sso/login`
   `{ provider_name, redirect_uri }` → backend returns `{ authorization_url }`.
2. Browser is redirected to the IdP. After consent, Entra redirects back to the
   backend SSO callback, which issues our own JWT session and bounces the
   browser to the dashboard with `?access_token=...&refresh_token=...&account_id=...`
   in the query string (handled by `LoginPage` → `AuthContext.applyTokensFromUrl`).

---

## Backend API mapping

> Legend — ✅ **Confirmed**: the exact `url_rules` / route were present in the
> provided PDFs. 🟡 **Inferred**: the service/schema was confirmed but the
> view `url_rules` were **not** included in any PDF; the path follows the
> established `/api/v1/...` convention and is clearly flagged in code.

### Authentication — `src/lib/api/auth.js`, `mfa.js`, `sessions.js` ✅
| Method | Endpoint | Notes |
|--------|----------|-------|
| POST | `/api/v1/auth/register` | |
| POST | `/api/v1/auth/login` | requires `account_id` |
| POST | `/api/v1/auth/mfa/login/verify` | login step 2 (verifyMfa) |
| POST | `/api/v1/auth/refresh` | opaque refresh token → new RS256 access token |
| POST | `/api/v1/auth/logout` | `{ all_sessions, refresh_token }` |
| POST | `/api/v1/auth/password/change` | |
| POST | `/api/v1/auth/password/reset/request` | |
| POST | `/api/v1/auth/password/reset/confirm` | |
| GET  | `/api/v1/auth/me` | |
| POST | `/api/v1/auth/mfa/setup/initiate` | returns `mfa_device_id`, `secret`, `qr_code_base64` |
| POST | `/api/v1/auth/mfa/setup/verify` | enrollment step (`setupVerify`) |
| POST | `/api/v1/auth/mfa/disable` | |
| POST | `/api/v1/auth/mfa/backup-codes/regenerate` | |
| GET  | `/api/v1/auth/sessions` | |
| DELETE | `/api/v1/auth/sessions/<session_id>` | |
| POST | `/api/v1/auth/sso/login` | → `{ authorization_url }` |
| GET  | `/api/v1/auth/sso/callback` | Entra redirect target |
| GET  | `/.well-known/jwks.json` | RS256 public keys |

### RBAC — `src/lib/api/rbac.js` ✅ (url_rules confirmed, PDF part 3)
| Endpoint | Purpose |
|----------|---------|
| `/api/v1/authz/groups` (GET,POST) | list / create groups |
| `/api/v1/authz/groups/<id>` (GET,PATCH,DELETE) | group detail / update / disable |
| `/api/v1/authz/groups/<id>/members` (POST,GET) | add / list members |
| `/api/v1/authz/groups/<id>/members/<user_id>` (DELETE) | remove member |
| `/api/v1/authz/groups/<id>/roles` (POST) / `.../roles/<role_id>` (DELETE) | attach / detach role |
| `/api/v1/authz/roles` (GET,POST) | list / create roles |
| `/api/v1/authz/roles/<id>` (GET,PATCH,DELETE) | role detail / update / disable |
| `/api/v1/authz/roles/<id>/users` (POST) / `.../users/<user_id>` (DELETE) | assign / revoke user |
| `/api/v1/authz/roles/<id>/policies` (POST) / `.../policies/<policy_id>` (DELETE) | attach / detach policy |
| `/api/v1/authz/users/<user_id>/effective-policies` (GET) | merged RBAC+PBAC view |

### Identity & lifecycle — `src/lib/api/identity.js` ✅ (url_rules confirmed, PDF part 7)
| Endpoint | Purpose |
|----------|---------|
| `/api/v1/identity/register` (POST) | tenant (company) registration |
| `/api/v1/identity/bootstrap-admin` (POST) | bootstrap first admin |
| `/api/v1/identity/bootstrap-status/<account_id>` (GET) | |
| `/api/v1/identity/users` (GET w/ required `account_id`, POST) | user list / create (one-time creds) |
| `/api/v1/identity/accounts/<account_id>/users/<user_id>` (GET,PUT,DELETE) | |
| `.../users/<user_id>/enable` · `/disable` · `/access` (POST/GET) | lifecycle + access summary |
| `/api/v1/identity/accounts/<account_id>/groups[/<group_id>]` | tenant-scoped groups |
| `.../groups/<group_id>/members` (POST,GET) · `.../members/<user_id>` (DELETE) | |
| `/api/v1/identity/accounts/<account_id>/roles[/<role_id>]` | tenant-scoped roles |
| `.../users/<user_id>/roles` (POST) · `.../roles/<role_id>` (DELETE) | assign / remove |
| `/api/v1/identity/users/<user_id>/offboard` (POST) | **no** `account_id` segment |
| `/api/v1/identity/users/<user_id>/reinstate` (POST) | **no** `account_id` segment |
| `/api/v1/identity/service-accounts` (GET,POST) · `/<account_id>` (GET,PUT,DELETE) | |
| `/api/v1/identity/api-keys` (GET,POST) · `/<key_id>` (GET,DELETE) · `/<key_id>/rotate` (POST) | |
| `/api/v1/identity/delegations` (GET,POST) · `/<delegation_id>` (DELETE) · `/my` (GET) | |

### Microsoft 365 — `src/lib/api/integration.js` ✅ (m365_bp, PDF parts 7/8)
M365 blueprint `url_prefix = /api/v1/m365`:
| Method | Endpoint | Required params |
|--------|----------|-----------------|
| GET  | `/api/v1/m365/resources` | – |
| GET  | `/api/v1/m365/mail/messages` | `ms_user` (UPN/GUID) |
| POST | `/api/v1/m365/mail/send` | `{ ms_user, message, resource_arn? }` |
| GET  | `/api/v1/m365/teams` | – |
| GET  | `/api/v1/m365/calendar/events` | `ms_user`, `resource_arn?` |
| GET  | `/api/v1/m365/drive/items` | `drive_id?`, `resource_arn?` |
| POST | `/api/v1/m365/word/create` | `{ ms_user, filename?, resource_arn? }` |
| GET  | `/api/v1/m365/word/open/<item_id>` | `ms_user` |

All M365 actions are enforced by the IAM PDP (e.g. `m365:mail:Read`,
`m365:mail:Send`, `m365:teams:Read`, `m365:calendar:Read`,
`m365:onedrive:Read`, `m365:word:Create/Read`).

### IAM-Control as a Service — `src/lib/api/integration.js` ✅ (PDP)
`iam_middleware.IAMConnectedApp` is a **server-side SDK**, not an HTTP
microservice — there is **no** `/api/v1/iam-control/*` route in the provided
code. Its `check()` method calls `POST /api/v1/authz/check`, so that is the
IAM-Control decision surface the dashboard uses:
| Method | Endpoint | Payload |
|--------|----------|---------|
| GET  | `/health` | liveness (app.py) |
| POST | `/api/v1/authz/check` | `{ user_id, action, resource_arn, resource_attributes }` → `{ allowed, reason }` |

### PBAC (policies / resources) — `src/lib/api/pbac.js` 🟡 **Inferred**
`PolicyService`, `ResourceService`, `AuthorizationService` and the policy
schemas (including `CreatePolicyRequestSchema`, `AttachPolicyRequestSchema`,
`CheckPermissionRequestSchema`) are **confirmed** in the PDFs, but the view
`url_rules` for policies & resources were **never included** in any of the 9
PDFs. The following paths follow the established `/api/v1/authz/*` convention
and are flagged `Inferred` in code — adjust once the backend `url_rules` are
shared:
```
GET    /api/v1/authz/policies
POST   /api/v1/authz/policies
GET    /api/v1/authz/policies/<id>
PATCH  /api/v1/authz/policies/<id>
POST   /api/v1/authz/policies/<id>/disable
POST   /api/v1/authz/policies/attach                 # { policy_id, user_id, expires_at? }
DELETE /api/v1/authz/policies/attachments/<id>
GET    /api/v1/authz/policies/attachments?user_id=   # list user attachments
GET    /api/v1/authz/resources
POST   /api/v1/authz/resources
POST   /api/v1/authz/resources/<id>/disable
POST   /api/v1/authz/check                            # PDP (CONFIRMED via iam_middleware)
```
The `check` (decision) endpoint **is** confirmed (used by `iam_middleware`);
only the policy/resource CRUD paths are inferred.

---

## Response envelope & error handling
The backend wraps every response in `success_response`
`{ success, message, data, errors, meta }`. The axios client
(`src/lib/apiClient.js`):
- **Unwraps** the envelope on success so every API call resolves to its inner
  `data` (e.g. `listUsers()` → `{ users, pagination }`).
- **Normalizes** failures into `error.userMessage` (falls back through
  `message` → `error.message` → `error_code`).
- **Auto-rotates** the RS256 access token on `401` via `/api/v1/auth/refresh`
  (fail-closed: a refresh failure clears storage and redirects to `/login`).

Data shapes the UI relies on (all confirmed in the PDFs):
- `listUsers` → `{ users:[], pagination:{page,per_page,total,total_pages} }`
- `listServiceAccounts` → `{ service_accounts:[] }` with **UPPERCASE** keys
  (`ACCOUNT_ID`, `NAME`, `DESCRIPTION`, `STATUS`, `CREATED_AT`, `ACTIVE_KEYS`…)
- `listApiKeys` → `{ api_keys:[] }` (`KEY_ID`, `KEY_NAME`, `KEY_PREFIX`,
  `STATUS`, `EXPIRES_AT`, `LAST_USED_AT`, `SERVICE_ACCOUNT_ID`)
- `listDelegations` → `{ delegations:[] }` (`delegate_username`,
  `scope_type`, `scope_id`, `permissions` [parsed array], `status`,
  `delegation_id`)
- `createUser` / `bootstrapAdmin` / `registerTenant` / `generateApiKey` return
  the secret (`password` / `api_key`) **once** — surfaced in the UI, never
  re-fetched.
- MFA login verify → token bundle `{ access_token, refresh_token, token_type,
  expires_in, session_id, user }`.

---

## Pages / feature map
| Area | Route | Highlights |
|------|-------|-----------|
| Auth | `/login`, `/login/mfa`, `/register`, `/login/forgot`, `/login/reset` | MFA step 2, SSO buttons, reset flow |
| Overview | `/` | stats from groups/roles/policies/users |
| Profile | `/profile` | `GET /auth/me` + change password |
| Security | `/security/mfa` | TOTP QR enroll, verify, backup codes, disable/regen |
| Security | `/security/sessions` | list/revoke sessions |
| Identity | `/identity/users`, `/identity/users/:userId` | create (one-time creds), profile/roles/groups/effective-policies tabs |
| Identity | `/identity/service-accounts`, `/identity/api-keys`, `/identity/delegations` | lifecycle + keys + delegations |
| Identity | `/identity/tenants`, `/identity/bootstrap` | tenant registration + admin bootstrap |
| RBAC | `/rbac/groups`, `/rbac/groups/:id`, `/rbac/roles`, `/rbac/roles/:id` | membership & policy attachment |
| PBAC | `/pbac/policies`, `/pbac/policies/new`, `/pbac/policies/:id`, `/pbac/resources` | editor (form + raw JSON + preview) |
| PBAC | `/pbac/check` | **Decision Simulator** (`/api/v1/authz/check`) |
| Integrations | `/integrations/m365` | live M365 connector surface |
| Integrations | `/integrations/iam-control` | PDP decision API (`/api/v1/authz/check`) + `/health` |
| Settings | `/settings/sso` | SSO provider explainer (Entra ID) |

---

## Known gaps / inferred endpoints
1. **PBAC policy/resource CRUD paths are inferred** (🟡 above). The services and
   schemas exist in the PDFs; only the view `url_rules` were missing. Update
   `src/lib/api/pbac.js` when the backend `url_rules` are shared.
2. **M365 `ms_user`** is a required query/`ms_user` body param for mail,
   calendar, drive and Word endpoints (per `m365_bp`). The M365 page collects it
   once in a top bar; clear errors surface if it is missing.
3. **No `/iam-control/*` microservice** — by design. IAM-Control reuses the PDP
   (`/api/v1/authz/check`). The `IamControlPage` documents this and the
   `iam_middleware` SDK usage.
4. Build artifacts live in `dist/` (git-ignored). `npm run build` is verified
   green.

---

## License
Internal IAM tooling — treat as proprietary.
