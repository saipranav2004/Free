# PAM Console — Frontend Redesign & Bug Fixes

## Run it

```bash
npm install
npm run dev            # dev server
npm run build          # production build  (verified passing)
npx eslint src         # lint             (verified: 0 problems)
node verify.mjs        # regression harness (verified: 18/18)
node audit-tokens.mjs  # dead-class audit   (verified: PASS)
```

`VITE_API_BASE_URL` still controls the backend origin. No API contract changed.

---

## Resource opening behaviour — preserved

**I have preserved the original resource opening behavior (desktop agent first,
fallback to browser) exactly as it existed earlier.**

Same three endpoints, same `pam-agent://` URL scheme, same session lifecycle.
What was added is the fallback that never existed:

`src/lib/agentLaunch.js` → `attemptAgentHandoff()` writes the `pam-agent://`
URL to a hidden iframe and watches for `blur` / `visibilitychange` / `pagehide`
inside a 2200 ms window. A handoff that fires those events means the OS handed
control to the desktop agent. Silence means no handler is registered, and
`ConnectPanel` then falls through to `openInBrowser()` automatically.

The previous implementation did `window.location.href = launchUrl` — no
fallback, no success detection, and it tore down the SPA when the scheme had no
handler.

---

## The six reported bugs

### 1. Identity detail requesting `/identity/users/undefined`

Root cause was in the **list**, not the detail page. It rendered
`` to={`/admin/identity/${u.id}`} `` unconditionally. When the primary key is
serialised under any name other than `id`, the template literal produces the
*string* `"undefined"` — a structurally valid URL segment. The router matched,
the detail page mounted, and it fetched a user literally named "undefined".

- `lib/entity.js` → `entityId()` probes the plausible key names, returns `null`
  when there is none.
- `IdentityListPage` renders an id-less row as **inert with a visible warning**
  instead of a link to nowhere, and banners the count.
- `IdentityDetailPage` guards the route param with `isUsableId()`.
- `api/identity.js` → `requireId()` throws a shaped 400 on every id-bearing
  call, so a malformed request can never reach the backend.

### 2. Reveal Credentials always "expired"

Deterministic, not flaky. `useCountdown(result?.expires_at)` was called with
`undefined` before the reveal landed, so its state sat at `0`. On the frame
`setResult(data)` committed, the expiry effect — declared *after* the hook, so
it runs in the same commit — read the stale `remainingMs === 0` alongside a
truthy `result` and discarded the secret before the countdown had ever measured
the real deadline.

- `hooks/useCountdown.js` now returns `{ remainingMs, remainingSec, expired,
  unknown, target }` and recomputes inline when the target changes mid-render.
  `expired` is **false** until the hook has actually measured the current
  target. Callers branch on `expired`, never on `remainingMs <= 0`.
- `RevealCredentialModal` memoises the deadline, falls back to
  `REVEAL_FALLBACK_TTL_SEC` when the server omits `expires_at`, reads the secret
  through a null-safe accessor (`result.plaintext.length` used to throw on a key
  mismatch), and guards against a stale tick.

### 3. Storing credentials failing with `AccountName` / `Credential` required

**[Likely — confirm against the Go source.]** Those are Go *struct field names*.
Gin's validator reports the struct field, not the JSON tag, when
`binding:"required"` fails. So the handler binds `account_name` + `credential`
while the form posted `username` + `secret` — neither required field was ever
present.

- `api/adminResources.js` sends `account_name` + `credential`, with the legacy
  keys retained as inert aliases.
- The form field is labelled **Account name**, is marked required, and validates
  client-side.
- `lib/apiError.js` → `applyServerFieldErrors()` maps PascalCase server field
  names back onto form fields, so a future mismatch shows up *on the input*
  rather than as a generic toast.

> Once you have confirmed the handler's real field names, delete the aliases.

### 4. Admin JIT requests visible on Overview but not on the JIT page

Both screens hit the same endpoint. Two independent causes, both closed:

- Overview always sent `status=PENDING`; the JIT page defaulted its filter to
  `""` and therefore **omitted `status` entirely**. Both screens now send an
  explicit status set and never omit it — the default queue is
  `PENDING + WAITING`, and "All statuses" sends the full enumeration rather than
  nothing. Sent as both a repeated `status` and a comma-joined `statuses`, since
  single- and multi-valued handlers disagree on which they read.
- The page read `data.requests` directly, so any other envelope key rendered as
  empty **with no error**. `api/admin.js` → `normalizePaged()` resolves the
  collection via `readCollection()` regardless of key.

### 5. No connect-to-agent on resources

Three compounding defects:

- Both connect buttons were `disabled={!info.has_credential}`, and credential
  storage was itself broken (Bug 3) — so the button was permanently greyed out.
  Credential state is now **advisory, not a hard gate**.
- The handoff was `window.location.href` with no fallback (see above).
- There was no single "Connect" action. There is now one: `createLaunch` →
  `attemptAgentHandoff` → automatic browser fallback. A 409 (device not paired)
  shows inline pairing **and still falls back to the browser**.

### 6. Audit — reports and search both broken

**Search:** free text was wired to the `action` parameter, an exact-match field
over values like `pam:vault:Reveal`. Nobody types that verbatim, so search
matched nothing while doing exactly what it was told. Free text now goes out as
free text (`q`, with `search`/`query` aliases); `action` gets its own explicit
exact-match input, which is what it was always good for.

**Reports** — four separate faults:

1. No time range was ever sent. A compliance report is *defined* by its
   reporting period. There is now a range picker with presets and a custom
   range, and a range is always sent. **[Guessing]** on the exact parameter
   names — `start_date`/`end_date`, `from`/`to` and `start_time`/`end_time` are
   all sent. Unknown JSON members are ignored under `ShouldBindJSON`, so this is
   inert; one look at `audit_handler.go` collapses it to a single pair.
2. `responseType: 'blob'` made JSON error bodies opaque, so the server's real
   message was replaced with generic text. `lib/http.js` now re-hydrates blob
   error bodies in the interceptor.
3. A JSON error returned with HTTP 200 was saved as a corrupt `.pdf`.
   `assertBinaryBlob()` refuses to download a non-binary body.
4. The global 20 s timeout aborted server-side rendering. Reports now use
   `REPORT_TIMEOUT_MS` (120 s).

---

## Additional defects found by reading the code

**The single largest visual defect.** `tailwind.config.js` defined `ink` at
shades 50/200/400/500 only, while the code used `ink-100` **90×**, `ink-300`
**29×** and `ink-600` **8×**. Those **127 classes compiled to nothing** — every
"primary" table value, every form label, every chevron silently inherited the
body colour, collapsing the entire type hierarchy to one grey. There is no build
error for this. Full ramps are now defined, and `audit-tokens.mjs` resolves the
real theme and fails on any dead class. (It caught three I introduced myself:
`pl-6.5`, `pl-8.5`.) Same class of bug: `h-4.5 w-4.5` in StatCard — `4.5` was
never in the spacing scale.

Also fixed:

- **`ConfirmDialog` reason persisted between opens** — grant A's justification
  was written into grant B's immutable audit record. A compliance defect, not a
  cosmetic one. Reset on open; type-to-confirm added for destructive actions.
- **Modals**: Escape was an `onKeyDown` on a non-focusable div (never fired).
  Now a document-level handler, plus backdrop close, scroll lock with scrollbar
  compensation, focus trap and restore, portal rendering, and a `busy` state
  that blocks dismissal mid-request.
- **`ErrorBoundary` never reset on navigation** — one throw made the whole
  console look dead until a hard reload. Now keyed on `location.pathname`.
- **`index.html` hardcoded `class="dark"`** — light-mode users got a flash. Now
  a pre-paint script mirroring the theme store.
- **Query cache not cleared on logout** — one account's data was visible to the
  next. `queryClient.clear()` on sign-out.
- **`LiveDuration` only ticked on the 15 s poll**, so a "live" session duration
  jumped in 15-second steps. Now ticks every second.
- **Org-wide sessions had pagination hard-disabled** — an admin could only ever
  see page 1 of a busy environment.
- **Break-glass duration**: toggling break-glass left an 8 h duration in a field
  whose server ceiling had just dropped to 1 h — guaranteed rejection with no
  visible cause.
- **`PairAgentPanel`** counted *revoked* devices as paired, and recreated its
  countdown interval on every tick.
- **`MfaEnrollment`** now blocks navigation while one-time backup codes are on
  screen — the backend never returns them again.
- Conflicting duplicate `dark:text-red-*` classes in AppLayout (cancelled each
  other out); "Back to Resources" on the 404 page linked to the Dashboard;
  mobile drawer stayed open after navigation; lists were `<ul>/<li>` everywhere
  instead of semantic tables (no column alignment, no headers, screen readers
  got a list); no skeletons anywhere, only centred spinners.

---

## Structure

```
src/ui/          design system — 14 primitives, single import surface
src/lib/         http, error normalisation, entity resolvers, agent launch
src/api/         one module per backend area; contracts unchanged
src/hooks/       useCountdown, useDebouncedValue, useDocumentTitle
src/config/      every backend enum, status and badge map in one place
src/components/  feature components, grouped by area
src/pages/       route components; admin pages under pages/admin/
```

`src/ui/` replaces the old ad-hoc `components/common/*` primitives — those are
gone, and nothing imports them (verified by grep).

---

## Verification performed

| Check | Result |
|---|---|
| `npx vite build` | Passes — 1,783 modules, 19 lazy route chunks |
| `npx eslint src` | 0 problems |
| `node verify.mjs` | 18/18 pass |
| `node audit-tokens.mjs` | PASS — no dead classes |
| Emitted CSS spot-check | `text-ink-100/300/600`, `h-4.5`, `pl-8.5` all emit real rules |
| Stale imports of removed primitives | None |
| `useCountdown` consumers on the new object API | All 5 |

**Not performed: no browser smoke test, and no run against a live backend.** The
compiler cannot catch a render-time crash, so treat first-run-through as
untested. I cannot claim "no bugs remaining" for a 9k-line rewrite verified
without a running backend — what I can claim is that every defect listed above
is real and traced to a specific line.

**Two items need one check against the Go source:** Bug 3's payload field names,
and Bug 6's date-range parameter names.
