/**
 * Dead-utility audit.
 *
 * Catches the defect class that silently flattened this console's entire
 * type hierarchy: a Tailwind class that looks correct, passes review, and
 * compiles to absolutely nothing because the value is not in the resolved
 * theme. There is no build error for this — only an audit finds it.
 */
import fs from 'fs'
import path from 'path'
import resolveConfig from 'tailwindcss/resolveConfig.js'

const cfg = (await import('./tailwind.config.js')).default
const t = resolveConfig(cfg).theme
const setOf = (o) => new Set(Object.keys(o))

const scales = {
  spacing: setOf(t.spacing),
  maxWidth: setOf(t.maxWidth),
  minWidth: setOf(t.minWidth),
  fontSize: setOf(t.fontSize),
  borderRadius: setOf(t.borderRadius),
  boxShadow: setOf(t.boxShadow),
  colors: t.colors,
}

const files = []
;(function walk(d) {
  for (const f of fs.readdirSync(d)) {
    const p = path.join(d, f)
    fs.statSync(p).isDirectory() ? walk(p) : /\.(jsx?|css|html)$/.test(f) && files.push(p)
  }
})('src')
files.push('index.html')

// Only inspect string literals that plausibly hold class names, so prose in
// comments ("top-level", "bottom-right") cannot produce phantom findings.
const CLASSISH = /['"`]([^'"`\n]*?)['"`]/g
const SKIP = /^(\[|.*%|full|auto|px|screen|fit|min|max|none|inherit|reverse|prose|dvh|svh|lvh)$/
const isFraction = (v) => /^\d+\/\d+$/.test(v)
// Prop values that are single hyphenated words and would otherwise be
// mistaken for utilities (e.g. sonner's position="bottom-right").
const NON_CLASS = new Set([
  'top-right', 'top-left', 'top-center',
  'bottom-right', 'bottom-left', 'bottom-center',
])

const rules = [
  [/(?:^|\s)-?(?:[hw]|size|[mp][tblrxyse]?|gap(?:-[xy])?|space-[xy]|inset(?:-[xy])?|top|left|right|bottom|translate-[xy])-([\w.]+)$/, 'spacing'],
  [/(?:^|\s)max-w-([\w.]+)$/, 'maxWidth'],
  [/(?:^|\s)min-w-([\w.]+)$/, 'minWidth'],
  [/(?:^|\s)text-(xs|sm|base|lg|xl|\d?xl|2xs)$/, 'fontSize'],
  [/(?:^|\s)rounded(?:-[tblrse]{1,2})?-([\w.]+)$/, 'borderRadius'],
  [/(?:^|\s)shadow-([\w.]+)$/, 'boxShadow'],
]

const bad = {}
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8')
  let lit
  while ((lit = CLASSISH.exec(src))) {
    for (const token of lit[1].split(/\s+/)) {
      if (NON_CLASS.has(token)) continue
      const cls = token.replace(/^(?:dark|hover|focus|focus-visible|active|disabled|group-hover|peer-focus|sm|md|lg|xl|2xl|first|last|odd|even|read-only|motion-safe|motion-reduce):/g, '')
      for (const [re, scale] of rules) {
        const m = cls.match(re)
        if (!m) continue
        const v = m[1]
        if (SKIP.test(v) || isFraction(v)) continue
        if (!scales[scale].has(v)) (bad[`${scale}: ${cls}`] ??= new Set()).add(f)
      }
    }
  }
}

// Colour shades — the original 127-dead-class bug.
const COLOR = /(?:^|\s)(?:bg|text|border|ring|divide|placeholder|from|to|via|fill|stroke|accent|caret|outline|decoration)-(surface|ink|brand)-(\d+)/g
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8')
  let m
  COLOR.lastIndex = 0
  while ((m = COLOR.exec(src))) {
    const [, fam, shade] = m
    if (!scales.colors[fam] || !(shade in scales.colors[fam])) {
      (bad[`color: ${fam}-${shade}`] ??= new Set()).add(f)
    }
  }
}

const keys = Object.keys(bad).sort()
if (!keys.length) {
  console.log('PASS — every spacing / max-width / font-size / radius / shadow / colour utility used')
  console.log('       resolves to a real value in the theme. No dead classes.')
  process.exit(0)
}
for (const k of keys) console.log('DEAD ->', k, '::', [...bad[k]].slice(0, 4).join(', '))
process.exit(1)
