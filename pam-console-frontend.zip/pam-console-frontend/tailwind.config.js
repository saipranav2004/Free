/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // ---------------------------------------------------------------
        // Every shade is backed by a CSS custom property (src/index.css).
        // `:root` = light values, `.dark` = dark values. The
        // `<alpha-value>` placeholder keeps `/50` opacity modifiers working.
        //
        // FIX (pre-existing bug): the old config defined ONLY ink 50/200/
        // 400/500 while the app used ink-100 (90x), ink-300 (29x) and
        // ink-600 (8x). Those 127 classes compiled to nothing, so most
        // "primary" text silently fell back to the body color and the
        // entire type hierarchy collapsed. The full ramp is defined now.
        // ---------------------------------------------------------------
        surface: {
          950: 'rgb(var(--surface-950) / <alpha-value>)',
          900: 'rgb(var(--surface-900) / <alpha-value>)',
          875: 'rgb(var(--surface-875) / <alpha-value>)',
          850: 'rgb(var(--surface-850) / <alpha-value>)',
          800: 'rgb(var(--surface-800) / <alpha-value>)',
          700: 'rgb(var(--surface-700) / <alpha-value>)',
          600: 'rgb(var(--surface-600) / <alpha-value>)',
        },
        ink: {
          50: 'rgb(var(--ink-50) / <alpha-value>)',
          100: 'rgb(var(--ink-100) / <alpha-value>)',
          200: 'rgb(var(--ink-200) / <alpha-value>)',
          300: 'rgb(var(--ink-300) / <alpha-value>)',
          400: 'rgb(var(--ink-400) / <alpha-value>)',
          500: 'rgb(var(--ink-500) / <alpha-value>)',
          600: 'rgb(var(--ink-600) / <alpha-value>)',
          700: 'rgb(var(--ink-700) / <alpha-value>)',
        },
        brand: {
          50: 'rgb(var(--brand-50) / <alpha-value>)',
          100: 'rgb(var(--brand-100) / <alpha-value>)',
          200: 'rgb(var(--brand-200) / <alpha-value>)',
          400: 'rgb(var(--brand-400) / <alpha-value>)',
          500: 'rgb(var(--brand-500) / <alpha-value>)',
          600: 'rgb(var(--brand-600) / <alpha-value>)',
          700: 'rgb(var(--brand-700) / <alpha-value>)',
        },
      },
      spacing: {
        // `h-4.5 w-4.5` was used in StatCard but never existed -> no-op.
        4.5: '1.125rem',
        // 6.5 / 8.5 are the icon-inset paddings for controls with a leading
        // icon (search fields, the duration input) and the hanging indent
        // under a Callout icon. Tailwind's default scale stops at x.5 for
        // 0.5-3.5 only, so these were silently compiling to nothing until
        // the token audit caught them.
        6.5: '1.625rem',
        8.5: '2.125rem',
        13: '3.25rem',
        18: '4.5rem',
      },
      fontFamily: {
        sans: ['Inter var', 'Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'JetBrains Mono', 'Menlo', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem', letterSpacing: '0.01em' }],
      },
      borderRadius: {
        card: '0.625rem',
      },
      boxShadow: {
        // Enterprise elevation: tight, low-opacity, layered — not a blur blob.
        xs: '0 1px 2px 0 rgb(var(--shadow-rgb) / 0.05)',
        sm: '0 1px 3px 0 rgb(var(--shadow-rgb) / 0.08), 0 1px 2px -1px rgb(var(--shadow-rgb) / 0.06)',
        card: '0 1px 2px 0 rgb(var(--shadow-rgb) / 0.06), 0 0 0 1px rgb(var(--shadow-rgb) / 0.03)',
        pop: '0 10px 24px -6px rgb(var(--shadow-rgb) / 0.18), 0 4px 8px -4px rgb(var(--shadow-rgb) / 0.10)',
        modal: '0 24px 56px -12px rgb(var(--shadow-rgb) / 0.32), 0 8px 16px -8px rgb(var(--shadow-rgb) / 0.16)',
      },
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'scale-in': {
          from: { opacity: '0', transform: 'translateY(6px) scale(0.985)' },
          to: { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'slide-down': {
          from: { opacity: '0', transform: 'translateY(-4px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
      },
      animation: {
        'fade-in': 'fade-in 140ms ease-out',
        'scale-in': 'scale-in 160ms cubic-bezier(0.16, 1, 0.3, 1)',
        'slide-down': 'slide-down 120ms ease-out',
      },
    },
  },
  plugins: [],
}
