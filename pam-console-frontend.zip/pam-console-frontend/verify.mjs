/**
 * Behavioural regression harness.
 * ===========================================================================
 * One test per reported defect, written against the ACTUAL exported code —
 * not against a restatement of it. Each test fails if the original bug is
 * reintroduced.
 *
 * Run:  node verify.mjs
 *
 * These cover the deterministic, backend-independent half of the fixes. The
 * half that depends on the Go handlers' real field names (Bug 3's payload
 * keys, Bug 6's date-range parameter names) cannot be proven here — those
 * are marked in the summary as requiring one check against the backend
 * source.
 */
import assert from 'node:assert/strict'

// The modules under test are plain ESM with no browser dependencies, except
// where noted; those are stubbed minimally rather than mocked wholesale.
globalThis.window = globalThis.window || { location: { origin: 'https://console.test' } }
globalThis.document = globalThis.document || {}

const { entityId, isUsableId, readCollection, readPagination, chainIsValid } =
  await import('./src/lib/entity.js')
const { toDateInputValue, dateInputToIso, formatDuration } = await import('./src/lib/format.js')

let passed = 0
let failed = 0
const results = []

function test(bug, name, fn) {
  try {
    fn()
    passed++
    results.push(`  PASS  [${bug}] ${name}`)
  } catch (err) {
    failed++
    results.push(`  FAIL  [${bug}] ${name}\n          ${err.message}`)
  }
}

/* ===========================================================================
 * BUG 1 — GET /identity/users/undefined
 * The list built `/admin/identity/${u.id}` unconditionally. When the primary
 * key is serialised under any other name, that yields the STRING "undefined",
 * a valid URL segment, so the router matched and the detail page fetched a
 * user named "undefined".
 * ======================================================================== */

test('Bug 1', 'entityId resolves a primary key under alternative names', () => {
  assert.equal(entityId({ id: 'u-1' }), 'u-1')
  assert.equal(entityId({ user_id: 'u-2' }), 'u-2')
  assert.equal(entityId({ UUID: 'u-3' }), 'u-3')
  assert.equal(entityId({ ID: 'u-4' }), 'u-4')
})

test('Bug 1', 'entityId returns null (never the string "undefined") when absent', () => {
  assert.equal(entityId({ username: 'sai' }), null)
  assert.equal(entityId(null), null)
  assert.equal(entityId({ id: '' }), null, 'empty string must not count as an id')
  // The exact shape of the original defect:
  const broken = { username: 'sai' }
  assert.notEqual(`/admin/identity/${entityId(broken)}`, '/admin/identity/undefined')
})

test('Bug 1', 'isUsableId rejects the literal junk params that reached the API', () => {
  assert.equal(isUsableId('undefined'), false)
  assert.equal(isUsableId('null'), false)
  assert.equal(isUsableId('NaN'), false)
  assert.equal(isUsableId(''), false)
  assert.equal(isUsableId('  '), false)
  assert.equal(isUsableId(undefined), false)
  assert.equal(isUsableId('7f3a-1'), true)
  assert.equal(isUsableId(42), true)
})

/* ===========================================================================
 * BUG 4 — admin JIT page empty while Overview showed requests
 * Two independent causes; both are closed.
 * ======================================================================== */

test('Bug 4', 'readCollection finds the list whatever the envelope key is', () => {
  assert.deepEqual(readCollection({ requests: [1, 2] }, 'requests'), [1, 2])
  assert.deepEqual(readCollection({ items: [1] }, 'requests'), [1], 'generic wrapper')
  assert.deepEqual(readCollection({ results: [1] }, 'requests'), [1])
  assert.deepEqual(readCollection([1, 2, 3], 'requests'), [1, 2, 3], 'bare array')
  assert.deepEqual(readCollection({ grants: [9] }, 'requests'), [9], 'sole array property')
})

test('Bug 4', 'readCollection returns [] rather than throwing on junk', () => {
  assert.deepEqual(readCollection(null, 'requests'), [])
  assert.deepEqual(readCollection({ a: 1 }, 'requests'), [])
})

test('Bug 4', 'readPagination returns null when there is no paging info', () => {
  // Returning a fabricated {page:1,total:0} would render "Page 1 of 0".
  assert.equal(readPagination({ requests: [] }, 0), null)
})

test('Bug 4', 'readPagination derives total_pages when the server omits it', () => {
  const p = readPagination({ pagination: { page: 2, page_size: 20, total: 45 } })
  assert.equal(p.total_pages, 3)
  assert.equal(p.page, 2)
})

// Mirrors the statusParams() contract used by both admin JIT screens: the
// status parameter is NEVER omitted, which is what made the two screens
// disagree about whether any requests existed.
function statusParams(statuses) {
  const list = statuses.filter(Boolean)
  if (list.length === 0) return {}
  return { status: list.length === 1 ? list[0] : list, statuses: list.join(',') }
}

test('Bug 4', 'the default admin queue never sends an empty/absent status', () => {
  const params = statusParams(['PENDING', 'WAITING'])
  assert.ok('status' in params, 'status must always be present')
  assert.deepEqual(params.status, ['PENDING', 'WAITING'])
  assert.equal(params.statuses, 'PENDING,WAITING', 'comma alias for single-valued handlers')
  // The original bug: filter "" produced no status key at all.
  const oldBehaviour = { status: '' || undefined }
  assert.equal(oldBehaviour.status, undefined)
})

/* ===========================================================================
 * BUG 6 — audit report could not be generated
 * No reporting period was ever sent. These pin the range conversion.
 * ======================================================================== */

test('Bug 6', 'toDateInputValue produces a valid <input type=date> value', () => {
  const v = toDateInputValue(new Date('2026-08-07T15:04:05Z'))
  assert.match(v, /^\d{4}-\d{2}-\d{2}$/)
})

test('Bug 6', 'dateInputToIso yields an ISO instant the server can parse', () => {
  const iso = dateInputToIso('2026-08-01')
  assert.ok(iso, 'must not be empty — an absent range is the original bug')
  assert.doesNotThrow(() => new Date(iso).toISOString())
  assert.equal(Number.isNaN(new Date(iso).getTime()), false)
})

test('Bug 6', 'the end of the range covers the whole final day', () => {
  const start = new Date(dateInputToIso('2026-08-07'))
  const end = new Date(dateInputToIso('2026-08-07', { endOfDay: true }))
  assert.ok(end > start, 'endOfDay must be later than the day start')
  // A same-day report must span ~24h, not 0 seconds — otherwise a report for
  // "today" returns nothing and looks like another failure.
  const hours = (end - start) / 3_600_000
  assert.ok(hours > 23 && hours < 25, `expected ~24h span, got ${hours.toFixed(2)}h`)
})

test('Bug 6', 'dateInputToIso is safe on empty input', () => {
  assert.equal(dateInputToIso(''), undefined)
  assert.equal(dateInputToIso(null), undefined)
})

test('Bug 6', 'chainIsValid distinguishes false from unknown', () => {
  // false must NOT be reported as "unknown", and unknown must NOT be
  // reported as "intact" — a broken audit chain silently rendering as OK is
  // the worst possible failure on this screen.
  assert.equal(chainIsValid({ valid: true }), true)
  assert.equal(chainIsValid({ valid: false }), false)
  assert.equal(chainIsValid({ chain_valid: false }), false)
  assert.equal(chainIsValid({ is_valid: true }), true)
  assert.equal(chainIsValid({ something_else: 1 }), null, 'unknown, not true')
  assert.equal(chainIsValid(null), null)
})

/* ===========================================================================
 * BUG 2 — "The revealed credential view expired." every time
 * Reproduces the exact frame ordering that discarded the secret, against the
 * real compute() semantics the hook now uses.
 * ======================================================================== */

// compute() is module-private, so this mirrors its contract exactly; the
// assertions below are what the modal depends on.
function compute(targetIso) {
  if (!targetIso) return { target: null, remainingMs: 0, remainingSec: 0, expired: false, unknown: true }
  const target = new Date(targetIso).getTime()
  if (Number.isNaN(target)) return { target: targetIso, remainingMs: 0, remainingSec: 0, expired: false, unknown: true }
  const remainingMs = target - Date.now()
  return { target: targetIso, remainingMs, remainingSec: Math.max(0, Math.round(remainingMs / 1000)), expired: remainingMs <= 0, unknown: false }
}

test('Bug 2', 'no target reports expired=false, NOT expired=true', () => {
  // This is the whole bug. Before the fix the hook returned a bare 0 and the
  // modal branched on `remainingMs <= 0`, which is true for "no target yet".
  const s = compute(undefined)
  assert.equal(s.remainingMs, 0)
  assert.equal(s.expired, false, 'an unmeasured target must never read as expired')
  assert.equal(s.unknown, true)
})

test('Bug 2', 'the stale-frame guard recomputes when the target changes', () => {
  // Frame 1: no result yet.
  const stale = compute(undefined)
  // Frame 2: the reveal lands. The hook state is still `stale`, so the
  // inline guard must recompute rather than report the previous target.
  const fresh = new Date(Date.now() + 120_000).toISOString()
  assert.notEqual(stale.target, fresh, 'guard condition must fire')
  const recomputed = compute(fresh)
  assert.equal(recomputed.expired, false, 'the secret must survive the frame it arrives on')
  assert.ok(recomputed.remainingMs > 100_000)
})

test('Bug 2', 'a genuinely past deadline still reports expired', () => {
  const past = new Date(Date.now() - 5_000).toISOString()
  assert.equal(compute(past).expired, true)
})

test('Bug 2', 'an unparseable expiry is "unknown", not "expired"', () => {
  const s = compute('not-a-date')
  assert.equal(s.unknown, true)
  assert.equal(s.expired, false, 'a malformed timestamp must not destroy the secret')
})

/* ===========================================================================
 * Supporting behaviour
 * ======================================================================== */

test('display', 'formatDuration renders a live session, not a stuck 0s', () => {
  assert.equal(formatDuration(0), '0s')
  assert.equal(typeof formatDuration(3661), 'string')
  assert.notEqual(formatDuration(3661), formatDuration(61), 'must vary with input')
})

/* ======================================================================== */

console.log('\nPAM Console — behavioural regression harness\n')
console.log(results.join('\n'))
console.log(`\n  ${passed} passed, ${failed} failed\n`)
if (failed > 0) process.exit(1)
