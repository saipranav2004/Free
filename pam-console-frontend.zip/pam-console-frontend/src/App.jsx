import { lazy, Suspense, useEffect } from 'react'
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import { toast } from 'sonner'
import { registerSessionExpiredHandler } from './lib/http'
import { ProtectedRoute } from './components/auth/ProtectedRoute'
import { AdminRoute } from './components/auth/AdminRoute'
import { AppLayout } from './components/common/AppLayout'
import { ErrorBoundary } from './components/common/ErrorBoundary'
import { FullPageSpinner } from './ui'
import LoginPage from './pages/auth/LoginPage'
import MfaVerifyPage from './pages/auth/MfaVerifyPage'

// Route-level code splitting: each feature area is its own chunk, loaded only
// when the user navigates there. Bundling Vault/Audit/Admin into the main
// chunk would bloat the very first load (the login screen) for every user,
// most of whom will not touch half these areas in a session.
const DashboardPage = lazy(() => import('./pages/DashboardPage'))
const ResourcesPage = lazy(() => import('./pages/resources/ResourcesPage'))
const ResourceDetailPage = lazy(() => import('./pages/resources/ResourceDetailPage'))
const VaultPage = lazy(() => import('./pages/vault/VaultPage'))
const SessionsPage = lazy(() => import('./pages/sessions/SessionsPage'))
const JitPage = lazy(() => import('./pages/jit/JitPage'))
const JitRequestDetailPage = lazy(() => import('./pages/jit/JitRequestDetailPage'))
const AuditPage = lazy(() => import('./pages/audit/AuditPage'))
const SettingsPage = lazy(() => import('./pages/SettingsPage'))
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'))

// Admin Center — its own subtree, wrapped in <AdminRoute> so a non-admin
// never downloads these chunks.
const AdminOverviewPage = lazy(() => import('./pages/admin/AdminOverviewPage'))
const IdentityListPage = lazy(() => import('./pages/admin/IdentityListPage'))
const IdentityDetailPage = lazy(() => import('./pages/admin/IdentityDetailPage'))
const RolesPage = lazy(() => import('./pages/admin/RolesPage'))
const PoliciesPage = lazy(() => import('./pages/admin/PoliciesPage'))
const AdminJitPage = lazy(() => import('./pages/admin/AdminJitPage'))
const AdminAuditPage = lazy(() => import('./pages/admin/AdminAuditPage'))
const AdminVaultOpsPage = lazy(() => import('./pages/admin/AdminVaultOpsPage'))

// Bridges the plain-JS http.js module (which cannot call hooks) to the
// router: on a 401 that ends a previously-valid session, navigate to /login
// and show exactly one toast no matter how many concurrent requests
// triggered it (the dedup guard itself lives in lib/http.js).
function SessionExpiredBridge() {
  const navigate = useNavigate()
  useEffect(() => {
    registerSessionExpiredHandler(() => {
      toast.error('Your session has expired', {
        description: 'Please sign in again to continue.',
      })
      navigate('/login', { replace: true })
    })
  }, [navigate])
  return null
}

/**
 * Per-route boundary + suspense.
 *
 * `resetKey` is the pathname: once a section threw, the previous
 * implementation kept showing the error screen even after the user navigated
 * somewhere healthy, so the whole console looked dead until a hard reload.
 */
function SuspenseRoute({ children }) {
  const location = useLocation()
  return (
    <ErrorBoundary resetKey={location.pathname}>
      <Suspense fallback={<FullPageSpinner />}>{children}</Suspense>
    </ErrorBoundary>
  )
}

export default function App() {
  return (
    <>
      <SessionExpiredBridge />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/mfa-verify" element={<MfaVerifyPage />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route index element={<SuspenseRoute><DashboardPage /></SuspenseRoute>} />
            <Route path="resources" element={<SuspenseRoute><ResourcesPage /></SuspenseRoute>} />
            <Route path="resources/:id" element={<SuspenseRoute><ResourceDetailPage /></SuspenseRoute>} />
            <Route path="vault/*" element={<SuspenseRoute><VaultPage /></SuspenseRoute>} />
            <Route path="sessions" element={<SuspenseRoute><SessionsPage /></SuspenseRoute>} />
            <Route path="jit" element={<SuspenseRoute><JitPage /></SuspenseRoute>} />
            <Route path="jit/requests/:id" element={<SuspenseRoute><JitRequestDetailPage /></SuspenseRoute>} />
            <Route path="audit" element={<SuspenseRoute><AuditPage /></SuspenseRoute>} />
            <Route path="settings" element={<SuspenseRoute><SettingsPage /></SuspenseRoute>} />

            {/* Admin Center — client-side gate only. Every request these
                pages make is independently enforced server-side by
                middleware.RequireAdmin; this just stops the shell flashing
                on screen for a non-admin before their first request 403s. */}
            <Route path="admin" element={<AdminRoute />}>
              <Route index element={<SuspenseRoute><AdminOverviewPage /></SuspenseRoute>} />
              <Route path="identity" element={<SuspenseRoute><IdentityListPage /></SuspenseRoute>} />
              <Route path="identity/:id" element={<SuspenseRoute><IdentityDetailPage /></SuspenseRoute>} />
              <Route path="roles" element={<SuspenseRoute><RolesPage /></SuspenseRoute>} />
              <Route path="policies" element={<SuspenseRoute><PoliciesPage /></SuspenseRoute>} />
              <Route path="jit" element={<SuspenseRoute><AdminJitPage /></SuspenseRoute>} />
              <Route path="audit" element={<SuspenseRoute><AdminAuditPage /></SuspenseRoute>} />
              <Route path="vault-ops" element={<SuspenseRoute><AdminVaultOpsPage /></SuspenseRoute>} />
            </Route>

            <Route path="*" element={<SuspenseRoute><NotFoundPage /></SuspenseRoute>} />
          </Route>
        </Route>
      </Routes>
    </>
  )
}
