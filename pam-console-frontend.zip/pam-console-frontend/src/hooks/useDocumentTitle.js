import { useEffect } from 'react'

/** Keeps the browser tab title in sync with the current screen. Operators
 *  routinely keep this console open in one of many tabs; a static
 *  "PAM Console" title makes it unfindable. */
export function useDocumentTitle(title) {
  useEffect(() => {
    if (!title) return undefined
    const previous = document.title
    document.title = `${title} · PAM Console`
    return () => {
      document.title = previous
    }
  }, [title])
}
