import { useEffect, useState } from 'react'

/**
 * Debounced mirror of a rapidly changing value (search boxes).
 *
 * Keeping this as a hook rather than a per-page useEffect matters for
 * perceived latency: the input stays fully responsive because it is
 * uncontrolled by the network, while the query key only moves once typing
 * settles — so a filter change never fires one request per keystroke.
 */
export function useDebouncedValue(value, delay = 300) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])

  return debounced
}
