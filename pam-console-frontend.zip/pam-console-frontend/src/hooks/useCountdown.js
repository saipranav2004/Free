import { useEffect, useState } from 'react'

/**
 * Ticks once a second while `targetIso` is in the future.
 *
 * Returns { remainingMs, expired } rather than a bare number. That extra
 * flag is not cosmetic — it is the fix for the reveal-credential bug.
 *
 * WHAT WENT WRONG BEFORE
 * ----------------------
 * The hook returned only `remainingMs`, initialised from whatever target it
 * was first called with. In RevealCredentialModal the target starts as
 * `undefined` (no result yet) so the internal state is 0. On the render
 * where the reveal result arrives, three things happen in this order:
 *
 *   1. the component re-renders with `result` set, but the hook's state is
 *      still the stale 0 from the previous target;
 *   2. the hook's own effect runs and *schedules* an update to the real
 *      positive value;
 *   3. the modal's expiry effect — declared after the hook, so it runs in
 *      the same commit, before that scheduled update lands — reads
 *      `remainingMs === 0` while `result` is truthy and immediately
 *      discards the secret with "The revealed credential view expired."
 *
 * So the view expired on the very first frame, every single time,
 * deterministically. `expired` is false until the hook has actually measured
 * the current target, which closes that window. Callers must branch on
 * `expired`, never on `remainingMs <= 0`.
 *
 * Also fixed here: the interval is cleared on unmount and re-created when
 * the target changes, so navigating away and back cannot stack intervals.
 */
export function useCountdown(targetIso) {
  const [state, setState] = useState(() => compute(targetIso))

  useEffect(() => {
    setState(compute(targetIso))
    if (!targetIso) return undefined

    const interval = setInterval(() => {
      const next = compute(targetIso)
      setState(next)
      if (next.expired) clearInterval(interval)
    }, 1000)

    return () => clearInterval(interval)
  }, [targetIso])

  // Guard against the stale-state frame described above: if the target has
  // changed but the effect has not run yet, recompute inline for this render
  // rather than reporting the previous target's value.
  if (state.target !== (targetIso || null)) {
    return compute(targetIso)
  }
  return state
}

function compute(targetIso) {
  if (!targetIso) {
    return { target: null, remainingMs: 0, remainingSec: 0, expired: false, unknown: true }
  }
  const target = new Date(targetIso).getTime()
  if (Number.isNaN(target)) {
    return { target: targetIso, remainingMs: 0, remainingSec: 0, expired: false, unknown: true }
  }
  const remainingMs = target - Date.now()
  return {
    target: targetIso,
    remainingMs,
    remainingSec: Math.max(0, Math.round(remainingMs / 1000)),
    expired: remainingMs <= 0,
    unknown: false,
  }
}

/** Re-renders on an interval without owning any value — used to keep a live
 *  session's elapsed time moving between server polls. */
export function useTicker(intervalMs = 1000, enabled = true) {
  const [, setTick] = useState(0)
  useEffect(() => {
    if (!enabled) return undefined
    const id = setInterval(() => setTick((t) => (t + 1) % 1_000_000), intervalMs)
    return () => clearInterval(id)
  }, [intervalMs, enabled])
}
