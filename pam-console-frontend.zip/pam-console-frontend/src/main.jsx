import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom'
import { Toaster } from 'sonner'
import App from './App.jsx'
import { ErrorBoundary } from './components/common/ErrorBoundary'
import { useThemeStore } from './store/themeStore'
import './index.css'

// Bridges the theme store to sonner so toasts match whichever mode the rest
// of the app is in, instead of always rendering as a dark toast on a light
// page. `duration` is raised over the library default: a privileged-access
// console shows error toasts that operators need time to actually read.
function ThemedToaster() {
  const isDark = useThemeStore((s) => s.isDark)
  return (
    <Toaster
      theme={isDark ? 'dark' : 'light'}
      position="bottom-right"
      richColors
      closeButton
      expand={false}
      visibleToasts={4}
      duration={5000}
      gap={10}
      toastOptions={{
        classNames: {
          toast: 'font-sans shadow-pop',
          title: 'text-sm font-semibold',
          description: 'text-xs opacity-90',
        },
      }}
    />
  )
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // A privileged-access console must not silently retry a failed fetch
      // three times with exponential backoff (react-query's default) — that
      // turns one 403 into four network calls and delays the error the user
      // actually needs to see. One fast retry for transient blips; anything
      // that fails twice is shown.
      retry: (failureCount, error) => {
        const status = error?.response?.status
        // Never retry a deterministic client-side rejection.
        if (status && status >= 400 && status < 500) return false
        return failureCount < 1
      },
      refetchOnWindowFocus: false,
      // 30s keeps navigation between screens instant (cached data renders
      // immediately while a background refetch runs) without ever showing
      // meaningfully stale privileged state.
      staleTime: 30_000,
      gcTime: 5 * 60_000,
    },
    mutations: {
      retry: 0, // never auto-retry a write — could double-submit a real action
    },
  },
})

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <App />
        </BrowserRouter>
        <ThemedToaster />
      </QueryClientProvider>
    </ErrorBoundary>
  </StrictMode>
)
