import { useEffect, useRef, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { ShieldAlert, KeyRound, Clock } from 'lucide-react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import clsx from 'clsx'
import { createJitRequest, createBreakglassRequest } from '../../api/jit'
import { listResources } from '../../api/resources'
import { JIT_DEFAULTS, DURATION_PRESETS } from '../../config/constants'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { entityId } from '../../lib/entity'
import {
  Modal, Button, Field, Input, Select, Textarea, Checkbox, Callout, FormSection,
} from '../../ui'

const schema = z.object({
  resource_id: z.string().min(1, 'Select a resource'),
  action: z.string().optional(),
  duration_minutes: z.coerce
    .number({ invalid_type_error: 'Enter a number of minutes' })
    .int('Whole minutes only')
    .min(1, 'Must be at least 1 minute')
    .max(
      JIT_DEFAULTS.MAX_DURATION_MIN,
      `Cannot exceed ${JIT_DEFAULTS.MAX_DURATION_MIN} minutes — the server will reject anything longer`
    ),
  reason: z
    .string()
    .trim()
    .min(
      JIT_DEFAULTS.MIN_REASON_LENGTH,
      `At least ${JIT_DEFAULTS.MIN_REASON_LENGTH} characters — the server requires a substantive reason`
    ),
  ticket_ref: z.string().optional(),
})

/**
 * A fresh idempotency key per *open* of the modal — not per render, and not
 * per mount. Reopening for a genuinely different second request must get a
 * NEW key, or the backend (jit_handler.go's Create) treats it as a replay
 * and silently returns the first request instead of creating one.
 */
function useIdempotencyKey(open) {
  const ref = useRef(null)
  useEffect(() => {
    if (open) {
      ref.current =
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(16).slice(2)}`
    }
  }, [open])
  return ref
}

export function CreateJitRequestModal({ open, onClose, defaultResourceId, defaultBreakglass = false }) {
  const [isBreakglass, setIsBreakglass] = useState(defaultBreakglass)
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const idempotencyKeyRef = useIdempotencyKey(open)

  const {
    register, handleSubmit, reset, setValue, watch, setError, formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      resource_id: defaultResourceId || '',
      duration_minutes: JIT_DEFAULTS.DEFAULT_DURATION_MIN,
      reason: '',
    },
  })

  const duration = watch('duration_minutes')
  const maxDuration = isBreakglass
    ? JIT_DEFAULTS.BREAKGLASS_MAX_DURATION_MIN
    : JIT_DEFAULTS.MAX_DURATION_MIN

  // FIX: duration was computed from `isBreakglass` in defaultValues only, so
  // toggling break-glass left an 8h duration in a field whose server ceiling
  // had just dropped to 1h — a guaranteed rejection with no visible cause.
  useEffect(() => {
    if (!open) return
    setValue(
      'duration_minutes',
      isBreakglass ? JIT_DEFAULTS.BREAKGLASS_MAX_DURATION_MIN : JIT_DEFAULTS.DEFAULT_DURATION_MIN,
      { shouldValidate: false }
    )
  }, [isBreakglass, open, setValue])

  useEffect(() => {
    if (open) {
      setIsBreakglass(defaultBreakglass)
      reset({
        resource_id: defaultResourceId || '',
        duration_minutes: defaultBreakglass
          ? JIT_DEFAULTS.BREAKGLASS_MAX_DURATION_MIN
          : JIT_DEFAULTS.DEFAULT_DURATION_MIN,
        reason: '',
        action: '',
        ticket_ref: '',
      })
    }
  }, [open, defaultBreakglass, defaultResourceId, reset])

  const resourcesQuery = useQuery({
    queryKey: ['resources', 'flat'],
    queryFn: ({ signal }) => listResources({ signal }),
    enabled: open,
    staleTime: 30_000,
  })

  const mutation = useMutation({
    mutationFn: (values) => {
      const payload = {
        resource_id: values.resource_id,
        action: values.action || undefined,
        duration_minutes: Number(values.duration_minutes),
        reason: values.reason,
        ticket_ref: values.ticket_ref || undefined,
      }
      return isBreakglass
        ? createBreakglassRequest(payload, idempotencyKeyRef.current)
        : createJitRequest(payload, idempotencyKeyRef.current)
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['jit'] })
      queryClient.invalidateQueries({ queryKey: ['admin', 'jit-requests'] })
      toast.success(isBreakglass ? 'Break-glass access raised' : 'Access request submitted', {
        description: isBreakglass
          ? 'A CRITICAL alert has been raised and the cooling-off period has started.'
          : 'An approver has been notified.',
      })
      onClose()
      const id = entityId(data?.request)
      if (id) navigate(`/jit/requests/${id}`)
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not submit request', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))
  const resources = resourcesQuery.data?.resources || []

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      size="lg"
      icon={isBreakglass ? ShieldAlert : KeyRound}
      iconTone={isBreakglass ? 'danger' : 'brand'}
      title={isBreakglass ? 'Break-glass emergency access' : 'Request time-boxed access'}
      description={
        isBreakglass
          ? 'Use only when normal approval is not possible. Fully recorded and reviewed.'
          : 'Access is granted for a fixed window and revoked automatically when it expires.'
      }
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            variant={isBreakglass ? 'danger' : 'primary'}
            loading={mutation.isPending}
            onClick={submit}
          >
            {isBreakglass ? 'Raise emergency access' : 'Submit request'}
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-5">
        {isBreakglass && (
          <Callout tone="danger" icon={ShieldAlert} title="This raises a CRITICAL security alert">
            Access does not activate until a {JIT_DEFAULTS.BREAKGLASS_WAIT_MIN}-minute cooling-off
            period elapses, during which an administrator can revoke it. The whole session is
            recorded and reviewed.
          </Callout>
        )}

        <FormSection title="Access">
          <Field label="Resource" error={errors.resource_id?.message} required>
            {({ id, ...a }) => (
              <Select id={id} {...a} data-autofocus error={!!errors.resource_id} disabled={resourcesQuery.isLoading} {...register('resource_id')}>
                <option value="">{resourcesQuery.isLoading ? 'Loading resources…' : 'Select a resource…'}</option>
                {resources.map((r) => {
                  const rid = entityId(r)
                  return (
                    <option key={rid} value={rid}>
                      {r.name} ({r.host}:{r.port})
                    </option>
                  )
                })}
              </Select>
            )}
          </Field>

          <Field label="Action" hint="Optional — e.g. read, write, admin. Narrows what the grant permits.">
            {({ id, ...a }) => <Input id={id} {...a} placeholder="read" {...register('action')} />}
          </Field>
        </FormSection>

        <FormSection title="Duration">
          <div>
            <div className="mb-2.5 flex flex-wrap gap-1.5">
              {DURATION_PRESETS.filter((p) => p.minutes <= maxDuration).map((p) => (
                <button
                  key={p.minutes}
                  type="button"
                  onClick={() => setValue('duration_minutes', p.minutes, { shouldValidate: true })}
                  className={clsx(
                    'rounded-md border px-2.5 py-1 text-xs font-medium tabular-nums transition-colors',
                    Number(duration) === p.minutes
                      ? 'border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-400'
                      : 'border-surface-700 bg-surface-900 text-ink-300 hover:bg-surface-850'
                  )}
                >
                  {p.label}
                </button>
              ))}
            </div>
            <Field
              label="Minutes"
              error={errors.duration_minutes?.message}
              hint={`Server maximum for ${isBreakglass ? 'break-glass' : 'standard'} requests is ${maxDuration} minutes.`}
              required
            >
              {({ id, ...a }) => (
                <div className="relative">
                  <Clock className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500" aria-hidden="true" />
                  <Input id={id} {...a} inputMode="numeric" className="pl-8.5 tabular-nums" error={!!errors.duration_minutes} {...register('duration_minutes')} />
                </div>
              )}
            </Field>
          </div>
        </FormSection>

        <FormSection title="Justification">
          <Field
            label="Reason"
            error={errors.reason?.message}
            hint={`At least ${JIT_DEFAULTS.MIN_REASON_LENGTH} characters. This is what the approver reads and what the audit record keeps.`}
            required
          >
            {({ id, ...a }) => (
              <Textarea id={id} {...a} rows={3} error={!!errors.reason} placeholder="e.g. INC-4821 — replication lag investigation on the orders replica" {...register('reason')} />
            )}
          </Field>
          <Field label="Ticket reference" hint="Optional — e.g. JIRA-1234, INC-4821.">
            {({ id, ...a }) => <Input id={id} {...a} {...register('ticket_ref')} />}
          </Field>
        </FormSection>

        {!defaultBreakglass && (
          <div className="rounded-lg border border-surface-700 bg-surface-850 p-1">
            <Checkbox
              label="This is a break-glass emergency request"
              hint="No approver, mandatory cooling-off period, always recorded, raises a CRITICAL alert."
              checked={isBreakglass}
              onChange={(e) => setIsBreakglass(e.target.checked)}
            />
          </div>
        )}
      </form>
    </Modal>
  )
}
