import { useEffect, useRef, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Laptop, RefreshCw } from 'lucide-react'
import { initAgentPairing, listAgentDevices } from '../../api/agent'
import { apiErrorMessage } from '../../lib/apiError'
import { Card, CardHeader, CardBody, Button, CopyableValue, Callout } from '../../ui'

/**
 * The pairing code is a one-time bootstrap secret (5 min default TTL, hashed
 * at rest — AgentService.InitPairing) proving "I am at the keyboard of a
 * machine I control", exactly once. After the CLI redeems it, all further
 * trust is the device's own Ed25519 keypair. That is why this shows a
 * countdown: a stale code left on screen produces a confusing 401 on the
 * CLI side.
 *
 * FIXES:
 *  - The countdown effect depended on `remainingSeconds`, so it tore down
 *    and recreated the interval on every single tick. Now one interval per
 *    code, driven by a ref-held deadline.
 *  - "check paired" counted ALL devices including revoked ones, so a user
 *    with a previously-revoked device was told pairing had succeeded when it
 *    had not. It now counts only ACTIVE devices.
 */
export function PairAgentPanel({ onPaired, publicBaseURLHint }) {
  const queryClient = useQueryClient()
  const [remainingSeconds, setRemainingSeconds] = useState(null)
  const deadlineRef = useRef(null)

  const pairInit = useMutation({
    mutationFn: () => initAgentPairing(),
    onSuccess: (data) => {
      const ttl = Number(data?.expires_in_seconds) || 300
      deadlineRef.current = Date.now() + ttl * 1000
      setRemainingSeconds(ttl)
    },
  })

  useEffect(() => {
    if (!deadlineRef.current) return undefined
    const id = setInterval(() => {
      const left = Math.max(0, Math.round((deadlineRef.current - Date.now()) / 1000))
      setRemainingSeconds(left)
      if (left <= 0) clearInterval(id)
    }, 1000)
    return () => clearInterval(id)
  }, [pairInit.data])

  const checkPaired = useMutation({
    mutationFn: () => listAgentDevices(),
    onSuccess: (data) => {
      const active = (data?.devices || []).filter((d) => d.status === 'ACTIVE')
      if (active.length > 0) {
        queryClient.invalidateQueries({ queryKey: ['agent', 'devices'] })
        onPaired?.()
      }
    },
  })

  const code = pairInit.data?.pairing_code
  const expired = remainingSeconds != null && remainingSeconds <= 0
  const server = publicBaseURLHint || window.location.origin
  const command = code ? `pam-agent pair --code ${code} --server ${server}` : ''
  const noneFound =
    checkPaired.isSuccess && (checkPaired.data?.devices || []).filter((d) => d.status === 'ACTIVE').length === 0

  return (
    <Card>
      <CardHeader
        title="Pair the desktop agent"
        description="Install pam-agent once, then pair it to your account with a one-time code."
      />
      <CardBody className="space-y-4">
        {!code || expired ? (
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400">
              <Laptop className="h-4 w-4" aria-hidden="true" />
            </span>
            <Button variant="primary" loading={pairInit.isPending} onClick={() => pairInit.mutate()}>
              {expired ? 'Generate a new code' : 'Generate pairing code'}
            </Button>
            {expired && <span className="text-xs text-ink-500">Previous code expired.</span>}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3 rounded-lg border border-surface-700 bg-surface-850 px-3.5 py-3">
              <code className="font-mono text-xl font-semibold tracking-[0.25em] text-ink-50">
                {code}
              </code>
              <span
                className={
                  'rounded-full px-2 py-0.5 text-2xs font-medium tabular-nums ' +
                  (remainingSeconds < 60
                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400'
                    : 'bg-surface-800 text-ink-400')
                }
              >
                expires in {Math.max(remainingSeconds, 0)}s
              </span>
            </div>

            <div>
              <p className="mb-1.5 text-xs font-medium text-ink-400">Run this on your machine</p>
              <CopyableValue value={command} label="Copy command" truncate={false} />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                size="sm"
                variant="secondary"
                icon={RefreshCw}
                loading={checkPaired.isPending}
                onClick={() => checkPaired.mutate()}
              >
                I&apos;ve run this — check
              </Button>
              {noneFound && (
                <span className="text-xs text-amber-700 dark:text-amber-400">
                  No active device seen yet — confirm the command completed successfully.
                </span>
              )}
            </div>
          </div>
        )}

        {pairInit.isError && (
          <Callout tone="danger">{apiErrorMessage(pairInit.error)}</Callout>
        )}
      </CardBody>
    </Card>
  )
}
