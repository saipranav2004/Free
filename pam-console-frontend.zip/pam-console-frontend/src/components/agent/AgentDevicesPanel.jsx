import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Laptop, Trash2, Plus } from 'lucide-react'
import { listAgentDevices, revokeAgentDevice } from '../../api/agent'
import { apiErrorMessage } from '../../lib/apiError'
import { formatRelativeToNow, formatAbsolute } from '../../lib/format'
import { entityId } from '../../lib/entity'
import {
  Card, CardHeader, Button, Badge, QueryState, TableSkeleton,
  EmptyState, ConfirmDialog, Table, TBody, TR, TD, CellStack,
} from '../../ui'
import { PairAgentPanel } from './PairAgentPanel'

/** Settings-page section: the full device-management view. ConnectPanel
 *  embeds only PairAgentPanel inline for the "no device yet" case. */
export function AgentDevicesPanel() {
  const queryClient = useQueryClient()
  const [showPairing, setShowPairing] = useState(false)
  const [revokeTarget, setRevokeTarget] = useState(null)

  const devicesQuery = useQuery({
    queryKey: ['agent', 'devices'],
    queryFn: ({ signal }) => listAgentDevices(signal),
  })

  const revokeMutation = useMutation({
    mutationFn: (deviceId) => revokeAgentDevice(deviceId),
    onSuccess: () => {
      toast.success('Device revoked', { description: 'That machine can no longer launch connections.' })
      setRevokeTarget(null)
      queryClient.invalidateQueries({ queryKey: ['agent', 'devices'] })
    },
    onError: (err) => {
      toast.error('Could not revoke device', { description: apiErrorMessage(err) })
      setRevokeTarget(null)
    },
  })

  const activeDevices = (devicesQuery.data?.devices || []).filter((d) => d.status === 'ACTIVE')

  return (
    <>
      <Card>
        <CardHeader
          title="Desktop agent devices"
          description="Machines paired to open connections through the pam-agent desktop app instead of the browser."
          actions={
            <Button size="sm" variant="secondary" icon={Plus} onClick={() => setShowPairing((s) => !s)}>
              {showPairing ? 'Hide' : 'Pair a device'}
            </Button>
          }
        />

        {showPairing && (
          <div className="border-b border-surface-700 p-4">
            <PairAgentPanel
              onPaired={() => {
                setShowPairing(false)
                queryClient.invalidateQueries({ queryKey: ['agent', 'devices'] })
                toast.success('Desktop agent paired')
              }}
            />
          </div>
        )}

        <QueryState
          query={devicesQuery}
          skeleton={<TableSkeleton rows={2} cols={3} />}
          empty={() => activeDevices.length === 0}
          emptyState={
            <EmptyState
              compact
              icon={Laptop}
              title="No devices paired"
              description="Pair a machine to open resources directly in your own client tools."
              action={
                <Button size="sm" variant="secondary" icon={Plus} onClick={() => setShowPairing(true)}>
                  Pair a device
                </Button>
              }
            />
          }
        >
          {() => (
            <Table>
              <TBody>
                {activeDevices.map((d) => {
                  const id = entityId(d)
                  return (
                    <TR key={id}>
                      <TD>
                        <CellStack
                          icon={
                            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-800 text-ink-400">
                              <Laptop className="h-4 w-4" aria-hidden="true" />
                            </span>
                          }
                          primary={d.device_name || 'Unnamed device'}
                          secondary={
                            <span title={d.last_seen_at ? formatAbsolute(d.last_seen_at) : undefined}>
                              Last seen {d.last_seen_at ? formatRelativeToNow(d.last_seen_at) : 'never'}
                            </span>
                          }
                        />
                      </TD>
                      <TD align="right">
                        <Badge tone="success">Active</Badge>
                      </TD>
                      <TD align="right">
                        <Button
                          size="xs"
                          variant="dangerOutline"
                          icon={Trash2}
                          onClick={() => setRevokeTarget(d)}
                        >
                          Revoke
                        </Button>
                      </TD>
                    </TR>
                  )
                })}
              </TBody>
            </Table>
          )}
        </QueryState>
      </Card>

      <ConfirmDialog
        open={!!revokeTarget}
        title={`Revoke "${revokeTarget?.device_name || 'this device'}"?`}
        description="That machine will no longer be able to open connections through the desktop agent. It can be paired again later."
        confirmLabel="Revoke device"
        destructive
        isLoading={revokeMutation.isPending}
        onConfirm={() => revokeMutation.mutate(entityId(revokeTarget))}
        onCancel={() => setRevokeTarget(null)}
      />
    </>
  )
}
