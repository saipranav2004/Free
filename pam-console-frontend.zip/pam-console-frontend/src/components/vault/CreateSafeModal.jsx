import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Vault } from 'lucide-react'
import { createSafe } from '../../api/vault'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { Modal, Button, Field, Input, Textarea } from '../../ui'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  description: z.string().optional(),
  retention_days: z.coerce
    .number()
    .int('Must be a whole number of days')
    .min(1, 'Must be at least 1 day')
    .max(3650, 'Cannot exceed 3650 days'),
})

export function CreateSafeModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema), defaultValues: { retention_days: 365 } })

  useEffect(() => {
    if (open) reset({ retention_days: 365 })
  }, [open, reset])

  const mutation = useMutation({
    mutationFn: createSafe,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vault', 'safes'] })
      toast.success('Safe created')
      onClose()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not create safe', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      icon={Vault}
      title="Create a safe"
      description="Safes group credentials by ownership and retention policy."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Create safe
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        <Field label="Name" error={errors.name?.message} required>
          {({ id, ...a }) => (
            <Input id={id} {...a} data-autofocus error={!!errors.name} placeholder="Production databases" {...register('name')} />
          )}
        </Field>
        <Field label="Description" hint="Optional — who owns this safe and what it holds.">
          {({ id, ...a }) => <Textarea id={id} {...a} rows={2} {...register('description')} />}
        </Field>
        <Field
          label="Retention (days)"
          error={errors.retention_days?.message}
          hint="How long deleted credential versions are kept before permanent purge."
          required
        >
          {({ id, ...a }) => (
            <Input id={id} {...a} inputMode="numeric" error={!!errors.retention_days} {...register('retention_days')} />
          )}
        </Field>
      </form>
    </Modal>
  )
}
