import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { KeyRound } from 'lucide-react'
import { createCredential, listCredentialTypes } from '../../api/vault'
import { CREDENTIAL_TYPES } from '../../config/constants'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { Modal, Button, Field, Input, Select, Textarea, FormSection } from '../../ui'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  account_name: z.string().trim().min(1, 'Required — the account this credential signs in as'),
  credential_type: z.string().min(1, 'Select a type'),
  secret_plaintext: z.string().trim().min(1, 'Required'),
  description: z.string().optional(),
  rotation_interval_days: z.coerce.number().int().min(0, 'Must be 0 or more'),
})

export function CreateCredentialModal({ open, onClose, safeId, folderId }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { rotation_interval_days: 0, credential_type: 'password' },
  })

  useEffect(() => {
    if (open) reset({ rotation_interval_days: 0, credential_type: 'password' })
  }, [open, reset])

  // Fetched rather than hardcoded — the vault's own supported types come
  // from vault_service.go's ListCredentialTypes, so this list cannot drift
  // from what the backend will actually accept. Falls back to the static
  // list if the endpoint is unavailable, so the form still works.
  const typesQuery = useQuery({
    queryKey: ['vault', 'credential-types'],
    queryFn: ({ signal }) => listCredentialTypes(signal),
    enabled: open,
    staleTime: Infinity,
    retry: false,
  })

  const types =
    Array.isArray(typesQuery.data) && typesQuery.data.length > 0
      ? typesQuery.data.map((t) => ({ value: t.type ?? t.value, label: t.label ?? t.type }))
      : CREDENTIAL_TYPES

  const mutation = useMutation({
    mutationFn: (values) => createCredential(safeId, { ...values, folder_id: folderId || undefined }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vault', 'safes', safeId, 'credentials'] })
      toast.success('Credential stored', { description: 'Encrypted at rest with envelope encryption.' })
      onClose()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError, { AccountName: 'account_name', SecretPlaintext: 'secret_plaintext' })) {
        toast.error('Could not store credential', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      size="lg"
      icon={KeyRound}
      title="Store a credential"
      description="The secret is encrypted before it leaves the server and is never returned to the browser without an audited reveal."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Store credential
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-5">
        <FormSection title="Identity">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Display name" error={errors.name?.message} required>
              {({ id, ...a }) => (
                <Input id={id} {...a} data-autofocus error={!!errors.name} placeholder="Orders DB — service account" {...register('name')} />
              )}
            </Field>
            <Field label="Account name" error={errors.account_name?.message} hint="The account this authenticates as." required>
              {({ id, ...a }) => (
                <Input id={id} {...a} error={!!errors.account_name} placeholder="svc_orders" {...register('account_name')} />
              )}
            </Field>
          </div>
          <Field label="Type" error={errors.credential_type?.message} required>
            {({ id, ...a }) => (
              <Select id={id} {...a} error={!!errors.credential_type} disabled={typesQuery.isLoading} {...register('credential_type')}>
                {typesQuery.isLoading && <option value="">Loading…</option>}
                {types.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </Select>
            )}
          </Field>
        </FormSection>

        <FormSection title="Secret">
          <Field label="Value" error={errors.secret_plaintext?.message} hint="Encrypted at rest with envelope encryption before storage." required>
            {({ id, ...a }) => (
              <Textarea id={id} {...a} rows={3} className="font-mono text-xs" error={!!errors.secret_plaintext} {...register('secret_plaintext')} />
            )}
          </Field>
        </FormSection>

        <FormSection title="Lifecycle">
          <Field label="Description" hint="Optional">
            {({ id, ...a }) => <Input id={id} {...a} {...register('description')} />}
          </Field>
          <Field
            label="Rotation interval (days)"
            error={errors.rotation_interval_days?.message}
            hint="0 disables automatic rotation scheduling."
          >
            {({ id, ...a }) => (
              <Input id={id} {...a} inputMode="numeric" error={!!errors.rotation_interval_days} {...register('rotation_interval_days')} />
            )}
          </Field>
        </FormSection>
      </form>
    </Modal>
  )
}
