import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ShieldAlert, Download, Upload } from 'lucide-react'
import { createBackup, restoreBackup } from '../../api/adminVault'
import { formatBytes, formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  Card, CardHeader, CardBody, Button, ConfirmDialog, CopyableValue, Callout,
  DescriptionList, DescriptionItem, Field, Input,
} from '../../ui'

/**
 * Whole-vault backup/restore. Restore overwrites live Vault state from an
 * encrypted archive — the highest blast radius operation in the console — so
 * it is kept visually separate from day-to-day credential management and
 * gated behind type-to-confirm rather than a single click.
 *
 * NOTE: these two calls are hardcoded backend-side to a local MinIO/S3
 * endpoint (vault_handler.go, independent of per-deployment env config), so
 * expect a connection error in any environment that has not stood that up.
 * That is an environment gap, not a frontend bug — the server's own message
 * is surfaced as-is.
 */
export function BackupRestorePanel() {
  const [lastBackup, setLastBackup] = useState(null)
  const [restoreKey, setRestoreKey] = useState('')
  const [confirmRestoreOpen, setConfirmRestoreOpen] = useState(false)

  const backupMutation = useMutation({
    mutationFn: createBackup,
    onSuccess: (meta) => {
      setLastBackup(meta)
      toast.success('Encrypted backup created', {
        description: 'Store the object key somewhere you can find it during an incident.',
      })
    },
    onError: (err) => toast.error('Backup failed', { description: apiErrorMessage(err) }),
  })

  const restoreMutation = useMutation({
    mutationFn: (key) => restoreBackup(key),
    onSuccess: () => {
      toast.success('Vault restored from backup')
      setConfirmRestoreOpen(false)
    },
    onError: (err) => {
      toast.error('Restore failed', { description: apiErrorMessage(err) })
      setConfirmRestoreOpen(false)
    },
  })

  return (
    <>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader title="Create backup" description="Envelope-encrypted archive of the entire Vault state." />
          <CardBody className="space-y-4">
            <p className="text-sm leading-relaxed text-ink-400">
              Produces an encrypted archive of every safe, folder, credential and version, uploaded
              to object storage. The archive is useless without the KMS key.
            </p>
            <Button
              variant="primary"
              icon={Download}
              loading={backupMutation.isPending}
              onClick={() => backupMutation.mutate()}
            >
              Create backup now
            </Button>

            {lastBackup && (
              <div className="rounded-lg border border-surface-700 bg-surface-850 p-3.5">
                <DescriptionList cols="100px 1fr">
                  <DescriptionItem label="Backup ID" mono>
                    {lastBackup.backup_id}
                  </DescriptionItem>
                  <DescriptionItem label="Created">{formatDateTime(lastBackup.timestamp)}</DescriptionItem>
                  <DescriptionItem label="Size">{formatBytes(lastBackup.size_bytes)}</DescriptionItem>
                </DescriptionList>
                <div className="mt-3">
                  <p className="mb-1.5 text-xs font-medium text-ink-400">Object key</p>
                  <CopyableValue value={lastBackup.s3_object_key} label="Copy key" truncate={false} />
                </div>
              </div>
            )}
          </CardBody>
        </Card>

        <Card className="border-red-200 dark:border-red-900/40">
          <CardHeader title="Restore from backup" description="Destructive — overwrites current Vault state." />
          <CardBody className="space-y-4">
            <Callout tone="danger" icon={ShieldAlert} title="This cannot be undone">
              Restoring replaces every safe, credential and version currently in the Vault with the
              contents of the archive. Any credential stored since that backup is lost.
            </Callout>

            <Field label="Object key of the backup to restore" required>
              {({ id, ...a }) => (
                <Input
                  id={id}
                  {...a}
                  value={restoreKey}
                  onChange={(e) => setRestoreKey(e.target.value)}
                  className="font-mono text-xs"
                  placeholder="vault-backups/2026-08-07T10-00-00Z.enc"
                />
              )}
            </Field>

            <Button
              variant="danger"
              icon={Upload}
              disabled={restoreKey.trim().length === 0}
              onClick={() => setConfirmRestoreOpen(true)}
            >
              Restore from this key
            </Button>
          </CardBody>
        </Card>
      </div>

      <ConfirmDialog
        open={confirmRestoreOpen}
        title="Restore the entire Vault from backup?"
        description="Every credential currently stored will be replaced by the contents of this archive."
        confirmLabel="Restore Vault"
        destructive
        confirmPhrase="RESTORE"
        requireReason
        reasonLabel="Reason for restore"
        reasonHint="Recorded in the audit log alongside the archive key."
        isLoading={restoreMutation.isPending}
        onConfirm={() => restoreMutation.mutate(restoreKey.trim())}
        onCancel={() => setConfirmRestoreOpen(false)}
      >
        <div className="rounded-lg border border-surface-700 bg-surface-850 p-3">
          <p className="mb-1 text-xs font-medium text-ink-400">Archive</p>
          <code className="block break-all font-mono text-xs text-ink-100">{restoreKey}</code>
        </div>
      </ConfirmDialog>
    </>
  )
}
