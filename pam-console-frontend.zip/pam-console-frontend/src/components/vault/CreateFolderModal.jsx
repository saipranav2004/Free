import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { FolderTree } from 'lucide-react'
import { createFolder } from '../../api/vault'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { Modal, Button, Field, Input } from '../../ui'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  path: z
    .string()
    .trim()
    .min(1, 'Required')
    .refine((v) => v.startsWith('/'), 'Path must start with "/"'),
})

export function CreateFolderModal({ open, onClose, safeId, parentFolderId }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })

  useEffect(() => {
    if (open) reset({ name: '', path: '' })
  }, [open, reset])

  const mutation = useMutation({
    mutationFn: (values) =>
      createFolder(safeId, { ...values, parent_folder_id: parentFolderId || undefined }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vault', 'safes', safeId, 'folders'] })
      toast.success('Folder created')
      onClose()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not create folder', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      icon={FolderTree}
      title="Create a folder"
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Create folder
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        <Field label="Name" error={errors.name?.message} required>
          {({ id, ...a }) => <Input id={id} {...a} data-autofocus error={!!errors.name} {...register('name')} />}
        </Field>
        <Field label="Path" error={errors.path?.message} hint="e.g. /prod-databases/mysql" required>
          {({ id, ...a }) => (
            <Input id={id} {...a} className="font-mono text-xs" error={!!errors.path} placeholder="/…" {...register('path')} />
          )}
        </Field>
      </form>
    </Modal>
  )
}
