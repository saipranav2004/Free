import { useEffect, useMemo, useState } from 'react'
import { ShieldAlert, Eye, EyeOff, Clock } from 'lucide-react'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import { revealCredential } from '../../api/vault'
import { normalizeApiError, isMfaRequiredError } from '../../lib/apiError'
import { useCountdown } from '../../hooks/useCountdown'
import { formatDuration } from '../../lib/format'
import { REVEAL_FALLBACK_TTL_SEC } from '../../config/constants'
import { Modal, Button, Field, Textarea, Callout, CopyButton } from '../../ui'

/**
 * ===========================================================================
 * REVEAL CREDENTIAL
 * ===========================================================================
 * BUG FIX — the reveal always failed instantly with
 *     "The revealed credential view expired."
 *
 * ROOT CAUSE (deterministic, every time, not a race in the usual sense):
 *
 *   const remainingMs = useCountdown(result?.expires_at)   // hook effect #1
 *   useEffect(() => { ... }, [open])                       // effect #2
 *   useEffect(() => {                                      // effect #3
 *     if (result && remainingMs <= 0) { setResult(null); toast(...) }
 *   }, [remainingMs, result])
 *
 * Before the reveal succeeds, `result` is null, so useCountdown is called
 * with `undefined` and its internal state settles at 0. The moment
 * `setResult(data)` lands:
 *
 *   1. the component re-renders with `result` truthy, but useCountdown's
 *      state is STILL the stale 0 — it only updates from inside its own
 *      effect;
 *   2. effects then run in declaration order, so the countdown's effect
 *      schedules the real value…
 *   3. …but effect #3 runs in the same commit with the pre-update closure,
 *      sees `result != null && remainingMs === 0`, and immediately discards
 *      the secret.
 *
 * The expiry check fired one frame after a *successful* reveal, before the
 * timer had ever measured the real expires_at. The user was told the view
 * expired; it had never opened.
 *
 * THE FIX, in three parts:
 *   a) useCountdown now reports an explicit `expired` flag that is false
 *      until the hook has actually measured the current target, and
 *      recomputes inline when the target changes mid-render. Callers branch
 *      on `expired`, never on `remainingMs <= 0`.
 *   b) The expiry effect additionally re-derives the deadline from
 *      `result.expires_at` itself, so it cannot act on a stale tick.
 *   c) If the backend omits `expires_at`, a local TTL is applied instead of
 *      treating "no deadline" as "already expired" (which is what
 *      `undefined <= 0` silently did).
 *
 * Also fixed here: `result.plaintext.length` threw a TypeError whenever the
 * secret came back under a different key or as a non-string, which turned a
 * successful reveal into a blank error boundary.
 */
function readSecret(result) {
  if (!result) return ''
  const value = result.plaintext ?? result.secret ?? result.value ?? result.credential ?? ''
  return typeof value === 'string' ? value : String(value ?? '')
}

export function RevealCredentialModal({ open, onClose, credentialId, accountName }) {
  const [reason, setReason] = useState('')
  const [revealed, setRevealed] = useState(false)
  const [result, setResult] = useState(null)

  // Establish a deadline exactly once per reveal, so a re-render can never
  // move it and the fallback TTL is stable.
  const deadline = useMemo(() => {
    if (!result) return null
    if (result.expires_at) return result.expires_at
    return new Date(Date.now() + REVEAL_FALLBACK_TTL_SEC * 1000).toISOString()
  }, [result])

  const { remainingSec, expired } = useCountdown(deadline)
  const secret = readSecret(result)

  // Never let a decrypted secret linger longer than it must: clear on every
  // close (cancel, Escape, backdrop, or unmount from navigation), not only
  // on an explicit "Done".
  useEffect(() => {
    if (!open) {
      setResult(null)
      setRevealed(false)
      setReason('')
    }
  }, [open])

  // Expiry. Guarded twice — see (a) and (b) in the header comment.
  useEffect(() => {
    if (!result || !deadline) return
    if (!expired) return
    if (new Date(deadline).getTime() > Date.now()) return // stale tick guard
    setResult(null)
    setRevealed(false)
    toast.info('The revealed credential is no longer displayed', {
      description: 'Reveal again to view it — a new audit entry will be recorded.',
    })
  }, [expired, result, deadline])

  const mutation = useMutation({
    mutationFn: () => revealCredential(credentialId, reason.trim()),
    onSuccess: (data) => {
      setResult(data)
      setRevealed(false)
    },
    onError: (err) => {
      const normalized = normalizeApiError(err)
      if (isMfaRequiredError(normalized)) {
        toast.error('MFA verification required', {
          description: 'Complete multi-factor authentication in Settings, then try again.',
        })
        return
      }
      toast.error('Could not reveal credential', { description: normalized.message })
    },
  })

  const close = () => {
    if (mutation.isPending) return
    onClose()
  }

  const urgent = remainingSec > 0 && remainingSec <= 15

  return (
    <Modal
      open={open}
      onClose={close}
      busy={mutation.isPending}
      size="md"
      icon={ShieldAlert}
      iconTone="warning"
      title="Reveal credential"
      description={
        result
          ? undefined
          : `Revealing ${accountName || 'this credential'} is written to the audit log with the reason you provide.`
      }
      footer={
        result ? (
          <Button variant="secondary" onClick={close}>
            Done
          </Button>
        ) : (
          <>
            <Button variant="ghost" onClick={close} disabled={mutation.isPending}>
              Cancel
            </Button>
            <Button
              variant="warning"
              loading={mutation.isPending}
              disabled={reason.trim().length === 0}
              onClick={() => mutation.mutate()}
            >
              Reveal credential
            </Button>
          </>
        )
      }
    >
      {!result ? (
        <div className="space-y-4">
          <Callout tone="warning" icon={ShieldAlert}>
            This action requires MFA to have been verified this session and is recorded against your
            account permanently.
          </Callout>

          <Field
            label="Reason for access"
            hint="Recorded in the immutable audit log. Reference a ticket where possible."
            required
          >
            {({ id, ...a11y }) => (
              <Textarea
                id={id}
                {...a11y}
                data-autofocus
                rows={3}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. INC-4821 — restoring the reporting replica"
              />
            )}
          </Field>
        </div>
      ) : (
        <div className="space-y-4">
          <div
            className={
              'flex items-center gap-2 rounded-lg border px-3 py-2.5 text-xs font-medium ' +
              (urgent
                ? 'border-red-300 bg-red-50 text-red-700 dark:border-red-500/40 dark:bg-red-500/10 dark:text-red-300'
                : 'border-amber-300 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300')
            }
            role="status"
            aria-live="polite"
          >
            <Clock className="h-3.5 w-3.5 flex-none" aria-hidden="true" />
            Hidden again in{' '}
            <span className="tabular-nums font-semibold">{formatDuration(remainingSec)}</span>
            <span className="opacity-80">— viewing again requires a new audit entry.</span>
          </div>

          <div>
            <p className="mb-1.5 text-xs font-medium text-ink-400">
              {result.account_name || accountName || 'Credential'}
              {result.credential_type ? ` · ${result.credential_type}` : ''}
            </p>
            <div className="flex items-start gap-2">
              <code className="min-w-0 flex-1 whitespace-pre-wrap break-all rounded-md border border-surface-700 bg-surface-800 px-2.5 py-2 font-mono text-xs leading-relaxed text-ink-50">
                {revealed ? secret || '(empty value returned)' : '•'.repeat(Math.min(28, secret.length || 12))}
              </code>
              <Button
                size="sm"
                variant="secondary"
                icon={revealed ? EyeOff : Eye}
                onClick={() => setRevealed((v) => !v)}
                aria-pressed={revealed}
              >
                {revealed ? 'Hide' : 'Show'}
              </Button>
              <CopyButton value={secret} />
            </div>
          </div>

          <p className="text-xs leading-relaxed text-ink-500">
            Do not paste this value into a shared document or chat. Prefer connecting through the
            desktop agent, which injects the credential without exposing it.
          </p>
        </div>
      )}
    </Modal>
  )
}
