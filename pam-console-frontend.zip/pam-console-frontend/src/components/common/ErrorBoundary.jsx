import { Component } from 'react'
import { AlertTriangle, RotateCcw } from 'lucide-react'

/**
 * A single bad render anywhere in the tree — a null-deref on an unexpected
 * API shape, a third-party component throwing — must never take down the
 * whole console with a blank white screen. That is the worst possible
 * failure mode for a tool used to manage privileged access.
 *
 * Deliberately class-based: error boundaries are not expressible as hooks in
 * React 18. This is the one legitimate class component in the codebase.
 *
 * FIX: `resetKey` lets the router reset the boundary on navigation. Without
 * it, once a section threw, the error screen persisted even after the user
 * navigated somewhere healthy — the console looked permanently broken until
 * a full page reload.
 */
export class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { error: null, resetKey: props.resetKey }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  static getDerivedStateFromProps(props, state) {
    if (props.resetKey !== state.resetKey) {
      return { error: null, resetKey: props.resetKey }
    }
    return null
  }

  componentDidCatch(error, info) {
    // In a real deployment this is where you would forward to Sentry.
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary] caught render error:', error, info)
  }

  reset = () => this.setState({ error: null })

  render() {
    if (this.state.error) {
      return (
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 p-8 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
            <AlertTriangle className="h-6 w-6" aria-hidden="true" />
          </span>
          <div>
            <h2 className="text-base font-semibold text-ink-50">Something went wrong</h2>
            <p className="mx-auto mt-1.5 max-w-md text-sm leading-relaxed text-ink-400">
              This section hit an unexpected error and couldn&apos;t render. The rest of the
              console still works — try again, or navigate elsewhere.
            </p>
          </div>
          {import.meta.env.DEV && (
            <pre className="max-h-64 max-w-2xl overflow-auto rounded-lg border border-surface-700 bg-surface-900 p-3 text-left text-xs text-red-600 dark:text-red-400">
              {String(this.state.error?.stack || this.state.error)}
            </pre>
          )}
          <button
            onClick={this.reset}
            className="inline-flex h-9 items-center gap-2 rounded-md border border-surface-700 bg-surface-900 px-3.5 text-sm font-medium text-ink-100 shadow-xs transition-colors hover:bg-surface-850"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> Try again
          </button>
        </div>
      )
    }
    return this.props.children
  }
}
