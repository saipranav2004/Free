import { Sun, Moon, Monitor } from 'lucide-react'
import clsx from 'clsx'
import { useThemeStore } from '../../store/themeStore'

const ICONS = { light: Sun, dark: Moon, system: Monitor }
const LABELS = { light: 'Light', dark: 'Dark', system: 'System' }
const NEXT = { light: 'dark', dark: 'system', system: 'light' }

/** One button cycling light → dark → system. A compact topbar slot does not
 *  justify a 3-way segmented control for a setting most people set once. */
export function ThemeToggle({ compact = false }) {
  const theme = useThemeStore((s) => s.theme)
  const cycleTheme = useThemeStore((s) => s.cycleTheme)
  const Icon = ICONS[theme] || Monitor

  return (
    <button
      type="button"
      onClick={cycleTheme}
      title={`Theme: ${LABELS[theme]} — click for ${LABELS[NEXT[theme]]}`}
      aria-label={`Switch theme. Currently ${LABELS[theme]}.`}
      className={clsx(
        'flex flex-none items-center justify-center rounded-md text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-100',
        compact ? 'h-8 w-8' : 'h-9 gap-2 border border-surface-700 bg-surface-900 px-3 text-xs font-medium'
      )}
    >
      <Icon className="h-4 w-4" aria-hidden="true" />
      {!compact && LABELS[theme]}
    </button>
  )
}
