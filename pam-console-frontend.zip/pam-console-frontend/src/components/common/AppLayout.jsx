import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useEffect, useRef, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  LayoutDashboard, Boxes, Vault, Radio, KeyRound, ScrollText, ShieldCheck,
  LogOut, Settings as SettingsIcon, Users, Lock, FileKey2, ServerCog,
  ClipboardList, Archive, Menu, X, ChevronDown, ChevronsLeft, ChevronsRight,
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { me, logout as logoutApi } from '../../api/auth'
import { listJitRequests } from '../../api/admin'
import { ROLE_BADGE, JIT_STATUS, JIT_POLL_MS } from '../../config/constants'
import { Badge } from '../../ui/Badge'
import { ThemeToggle } from './ThemeToggle'
import { toast } from 'sonner'

// Self-service — visible to every authenticated user.
const CONSOLE_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/resources', label: 'Resources', icon: Boxes },
  { to: '/vault', label: 'Vault', icon: Vault },
  { to: '/sessions', label: 'Sessions', icon: Radio },
  { to: '/jit', label: 'JIT Access', icon: KeyRound },
  { to: '/audit', label: 'Audit', icon: ScrollText },
]

// Admin Center — rendered only for accounts holding "admin" or "root" (see
// AdminRoute for the matching route guard). This is PAM's control plane;
// there is no separate admin login, just a section that appears once the JWT
// says you may see it.
const ADMIN_NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/identity', label: 'Identity', icon: Users },
  { to: '/admin/roles', label: 'Roles', icon: Lock },
  { to: '/admin/policies', label: 'Policies', icon: FileKey2 },
  { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound, badgeKey: 'pendingJit' },
  { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
  { to: '/admin/vault-ops', label: 'Vault Operations', icon: Archive },
]

function NavItem({ to, label, icon: Icon, end, onNavigate, collapsed, count }) {
  return (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      title={collapsed ? label : undefined}
      className={({ isActive }) =>
        clsx(
          'group relative flex items-center gap-2.5 rounded-md text-sm font-medium transition-colors',
          collapsed ? 'justify-center px-2 py-2' : 'px-2.5 py-2',
          isActive
            ? 'bg-brand-50 text-brand-700 dark:bg-brand-500/12 dark:text-brand-400'
            : 'text-ink-400 hover:bg-surface-850 hover:text-ink-100'
        )
      }
    >
      {({ isActive }) => (
        <>
          {/* Active rail — a 2px marker reads as "you are here" far faster
              than a background tint alone at a glance across a tall nav. */}
          <span
            aria-hidden="true"
            className={clsx(
              'absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r-full bg-brand-600 transition-opacity dark:bg-brand-400',
              isActive ? 'opacity-100' : 'opacity-0'
            )}
          />
          <Icon className="h-4 w-4 flex-none" aria-hidden="true" />
          {!collapsed && <span className="flex-1 truncate">{label}</span>}
          {!collapsed && count > 0 && (
            <span className="flex-none rounded-full bg-amber-100 px-1.5 py-px text-2xs font-semibold tabular-nums text-amber-800 dark:bg-amber-500/20 dark:text-amber-300">
              {count > 99 ? '99+' : count}
            </span>
          )}
          {collapsed && count > 0 && (
            <span
              className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-amber-500"
              aria-hidden="true"
            />
          )}
        </>
      )}
    </NavLink>
  )
}

function SidebarContent({ isAdmin, onNavigate, collapsed, counts }) {
  return (
    <>
      <div
        className={clsx(
          'flex flex-none items-center gap-2.5 border-b border-surface-700 px-3',
          collapsed ? 'h-14 justify-center' : 'h-14'
        )}
      >
        <span className="flex h-7 w-7 flex-none items-center justify-center rounded-md bg-brand-600 text-white shadow-xs">
          <ServerCog className="h-4 w-4" aria-hidden="true" />
        </span>
        {!collapsed && (
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold leading-tight tracking-tight text-ink-50">
              PAM Console
            </span>
            <span className="block truncate text-2xs leading-tight text-ink-500">
              Privileged Access
            </span>
          </span>
        )}
      </div>

      <nav className="flex-1 space-y-5 overflow-y-auto px-2 py-3" aria-label="Main">
        <div className="space-y-0.5">
          {!collapsed && (
            <p className="px-2.5 pb-1.5 text-2xs font-semibold uppercase tracking-wider text-ink-500">
              Console
            </p>
          )}
          {CONSOLE_NAV.map((item) => (
            <NavItem key={item.to} {...item} onNavigate={onNavigate} collapsed={collapsed} />
          ))}
        </div>

        {isAdmin && (
          <div className="space-y-0.5">
            {!collapsed ? (
              <p className="flex items-center gap-1.5 px-2.5 pb-1.5 text-2xs font-semibold uppercase tracking-wider text-ink-500">
                <ShieldCheck className="h-3 w-3 text-amber-500" aria-hidden="true" />
                Admin Center
              </p>
            ) : (
              <div className="mx-2 my-2 border-t border-surface-700" aria-hidden="true" />
            )}
            {ADMIN_NAV.map((item) => (
              <NavItem
                key={item.to}
                {...item}
                count={item.badgeKey ? counts?.[item.badgeKey] : undefined}
                onNavigate={onNavigate}
                collapsed={collapsed}
              />
            ))}
          </div>
        )}
      </nav>
    </>
  )
}

function SidebarFooter({ user, roles, loadingUser, collapsed, onToggleCollapse }) {
  if (collapsed) {
    return (
      <div className="flex-none border-t border-surface-700 p-2">
        <button
          onClick={onToggleCollapse}
          title="Expand sidebar"
          aria-label="Expand sidebar"
          className="flex h-8 w-full items-center justify-center rounded-md text-ink-500 transition-colors hover:bg-surface-850 hover:text-ink-100"
        >
          <ChevronsRight className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    )
  }

  return (
    <div className="flex-none border-t border-surface-700 p-2.5">
      <div className="rounded-md bg-surface-850 px-2.5 py-2">
        <p className="truncate text-xs font-medium text-ink-100" title={user?.username}>
          {user?.username || (loadingUser ? '…' : 'Signed in')}
        </p>
        <div className="mt-1.5 flex flex-wrap gap-1">
          {roles.length === 0 && !loadingUser && (
            <Badge size="xs" tone="neutral">
              no roles
            </Badge>
          )}
          {roles.map((r) => (
            <Badge key={r} size="xs" className={ROLE_BADGE[r] || ROLE_BADGE.user}>
              {r}
            </Badge>
          ))}
        </div>
      </div>
      <button
        onClick={onToggleCollapse}
        className="mt-2 flex h-7 w-full items-center justify-center gap-1.5 rounded-md text-2xs font-medium text-ink-500 transition-colors hover:bg-surface-850 hover:text-ink-200"
      >
        <ChevronsLeft className="h-3.5 w-3.5" aria-hidden="true" /> Collapse
      </button>
    </div>
  )
}

const COLLAPSE_KEY = 'pam_nav_collapsed'

export function AppLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const queryClient = useQueryClient()
  const user = useAuthStore((s) => s.user)
  const setUser = useAuthStore((s) => s.setUser)
  const doLogout = useAuthStore((s) => s.logout)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(COLLAPSE_KEY) === '1'
    } catch {
      return false
    }
  })
  const menuRef = useRef(null)
  const mainRef = useRef(null)

  // /auth/me is the source of truth for "who am I" — login returns only
  // access_token/expires_at, not the profile, so this is what populates the
  // header and the isAdmin() check the Admin Center nav depends on.
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal), retry: false })

  useEffect(() => {
    if (meQuery.data) setUser(meQuery.data)
  }, [meQuery.data, setUser])

  // Pending-approval count in the nav. An approval queue an admin has to
  // navigate to in order to discover is a queue that goes unworked; the
  // count makes the workload visible from anywhere in the console.
  const pendingJitQuery = useQuery({
    queryKey: ['admin', 'jit-requests', 'nav-pending-count'],
    queryFn: ({ signal }) =>
      listJitRequests({ page: 1, page_size: 1, status: JIT_STATUS.PENDING }, signal),
    enabled: isAdmin,
    refetchInterval: JIT_POLL_MS,
    retry: false,
  })
  const pendingJit = pendingJitQuery.data?.pagination?.total ?? 0

  useEffect(() => {
    try {
      localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0')
    } catch {
      /* private browsing — preference simply will not persist */
    }
  }, [collapsed])

  // Close the mobile drawer and the user menu on any navigation. Without
  // this, tapping a link on mobile left the overlay covering the page it had
  // just navigated to.
  useEffect(() => {
    setMobileNavOpen(false)
    setUserMenuOpen(false)
    mainRef.current?.scrollTo({ top: 0 })
  }, [location.pathname])

  // Dismiss the user menu on outside click or Escape.
  useEffect(() => {
    if (!userMenuOpen) return undefined
    const onDown = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setUserMenuOpen(false)
    }
    const onKey = (e) => e.key === 'Escape' && setUserMenuOpen(false)
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [userMenuOpen])

  const handleLogout = async () => {
    try {
      await logoutApi()
    } catch {
      // Even if the server-side logout fails (network blip, already-expired
      // token) the local session is still cleared below. A failed logout call
      // must never leave a user stuck "logged in" client-side after they
      // explicitly asked to sign out.
    } finally {
      doLogout()
      queryClient.clear() // never leave one account's cached data for the next
      navigate('/login', { replace: true })
      toast.success('Signed out')
    }
  }

  const roles = user?.roles || []
  const counts = { pendingJit }

  return (
    <div className="flex min-h-screen bg-surface-950">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-[60] focus:rounded-md focus:bg-brand-600 focus:px-3 focus:py-2 focus:text-sm focus:font-medium focus:text-white"
      >
        Skip to content
      </a>

      {/* Desktop sidebar */}
      <aside
        className={clsx(
          'hidden flex-none flex-col border-r border-surface-700 bg-surface-900 transition-[width] duration-200 md:flex',
          collapsed ? 'w-[4.25rem]' : 'w-60'
        )}
      >
        <SidebarContent isAdmin={isAdmin} onNavigate={() => {}} collapsed={collapsed} counts={counts} />
        <SidebarFooter
          user={user}
          roles={roles}
          loadingUser={meQuery.isLoading}
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((v) => !v)}
        />
      </aside>

      {/* Mobile drawer */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div
            className="fixed inset-0 bg-slate-950/60 animate-fade-in"
            onClick={() => setMobileNavOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative flex w-[17rem] flex-col border-r border-surface-700 bg-surface-900 shadow-modal">
            <button
              onClick={() => setMobileNavOpen(false)}
              className="absolute right-2.5 top-3.5 rounded-md p-1.5 text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-100"
              aria-label="Close menu"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>
            <SidebarContent
              isAdmin={isAdmin}
              onNavigate={() => setMobileNavOpen(false)}
              collapsed={false}
              counts={counts}
            />
            <SidebarFooter
              user={user}
              roles={roles}
              loadingUser={meQuery.isLoading}
              collapsed={false}
              onToggleCollapse={() => setCollapsed((v) => !v)}
            />
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 flex-none items-center gap-3 border-b border-surface-700 bg-surface-900/85 px-4 backdrop-blur-md">
          <button
            onClick={() => setMobileNavOpen(true)}
            className="rounded-md p-1.5 text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-100 md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" aria-hidden="true" />
          </button>
          <span className="flex-1 text-sm font-semibold text-ink-50 md:hidden">PAM Console</span>

          <div className="ml-auto flex items-center gap-1.5">
            <ThemeToggle compact />

            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setUserMenuOpen((v) => !v)}
                aria-haspopup="menu"
                aria-expanded={userMenuOpen}
                className="flex h-8 items-center gap-2 rounded-md pl-1 pr-2 text-sm text-ink-200 transition-colors hover:bg-surface-800"
              >
                <span className="flex h-6 w-6 flex-none items-center justify-center rounded-full bg-brand-600 text-2xs font-semibold uppercase text-white">
                  {(user?.username || '?').slice(0, 2)}
                </span>
                <span className="hidden max-w-[9rem] truncate font-medium sm:inline" title={user?.username}>
                  {user?.username || (meQuery.isLoading ? '…' : 'Signed in')}
                </span>
                <ChevronDown
                  className={clsx(
                    'h-3.5 w-3.5 flex-none text-ink-500 transition-transform',
                    userMenuOpen && 'rotate-180'
                  )}
                  aria-hidden="true"
                />
              </button>

              {userMenuOpen && (
                <div
                  role="menu"
                  className="absolute right-0 z-40 mt-1.5 w-56 overflow-hidden rounded-lg border border-surface-700 bg-surface-900 shadow-pop animate-slide-down"
                >
                  <div className="border-b border-surface-700 bg-surface-875 px-3 py-2.5">
                    <p className="truncate text-sm font-medium text-ink-50">{user?.username || '—'}</p>
                    <p className="truncate text-xs text-ink-500">{user?.email || '—'}</p>
                    {roles.length > 0 && (
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {roles.map((r) => (
                          <Badge key={r} size="xs" className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                            {r}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <NavLink
                    to="/settings"
                    role="menuitem"
                    className="flex items-center gap-2.5 px-3 py-2 text-sm text-ink-200 transition-colors hover:bg-surface-850"
                  >
                    <SettingsIcon className="h-4 w-4 text-ink-500" aria-hidden="true" /> Settings
                  </NavLink>
                  <button
                    role="menuitem"
                    onClick={handleLogout}
                    className="flex w-full items-center gap-2.5 border-t border-surface-700 px-3 py-2 text-left text-sm text-red-600 transition-colors hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                  >
                    <LogOut className="h-4 w-4" aria-hidden="true" /> Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <main id="main-content" ref={mainRef} className="min-w-0 flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[86rem] px-4 py-6 sm:px-6 lg:px-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
