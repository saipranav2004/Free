import clsx from 'clsx'
import {
  Database, Layers, Zap, Archive, Search as SearchIcon, BarChart3, Activity, Globe, Boxes,
} from 'lucide-react'

const ICONS = {
  postgresql: { Icon: Database, color: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-50 dark:bg-sky-500/12' },
  mongodb: { Icon: Layers, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-500/12' },
  redis: { Icon: Zap, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-500/12' },
  clickhouse: { Icon: Activity, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-500/12' },
  minio: { Icon: Archive, color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-50 dark:bg-orange-500/12' },
  qdrant: { Icon: SearchIcon, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-500/12' },
  metabase: { Icon: BarChart3, color: 'text-yellow-600 dark:text-yellow-400', bg: 'bg-yellow-50 dark:bg-yellow-500/12' },
  langfuse: { Icon: Activity, color: 'text-pink-600 dark:text-pink-400', bg: 'bg-pink-50 dark:bg-pink-500/12' },
  web: { Icon: Globe, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-500/12' },
  oracle: { Icon: Database, color: 'text-rose-600 dark:text-rose-400', bg: 'bg-rose-50 dark:bg-rose-500/12' },
}

const FALLBACK = { Icon: Boxes, color: 'text-ink-400', bg: 'bg-surface-800' }

/** Bare glyph. */
export function ResourceTypeIcon({ type, className = 'h-4 w-4' }) {
  const { Icon, color } = ICONS[type] || FALLBACK
  return <Icon className={clsx(className, color)} aria-hidden="true" />
}

/** Glyph in a tinted tile — the list/table presentation. A coloured tile
 *  gives a scannable anchor per row, which a bare icon on a flat background
 *  does not. */
export function ResourceTypeTile({ type, size = 'md' }) {
  const { Icon, color, bg } = ICONS[type] || FALLBACK
  const box = size === 'lg' ? 'h-10 w-10' : size === 'sm' ? 'h-7 w-7' : 'h-9 w-9'
  const glyph = size === 'lg' ? 'h-5 w-5' : size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4'
  return (
    <span className={clsx('flex flex-none items-center justify-center rounded-lg', box, bg)}>
      <Icon className={clsx(glyph, color)} aria-hidden="true" />
    </span>
  )
}
