import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Boxes } from 'lucide-react'
import { createResource } from '../../api/adminResources'
import { RESOURCE_TYPES, CONNECT_MODES, DEFAULT_PORTS } from '../../config/constants'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import {
  Modal, Button, Field, Input, Select, Textarea, Checkbox, FormSection,
} from '../../ui'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  description: z.string().optional(),
  resource_type: z.string().min(1, 'Select a resource type'),
  host: z.string().trim().min(1, 'Required'),
  // Coerce here rather than trusting <input type="number">, which can still
  // submit "", "e" or "-" on some browsers and keyboards.
  port: z.coerce
    .number({ invalid_type_error: 'Port must be a number' })
    .int('Port must be a whole number')
    .min(1, 'Port must be between 1 and 65535')
    .max(65535, 'Port must be between 1 and 65535'),
  database_name: z.string().optional(),
  connect_mode: z.string().optional(),
  console_url: z
    .string()
    .optional()
    .refine((v) => !v || /^https?:\/\//.test(v), 'Must start with http:// or https://'),
  extra_config: z
    .string()
    .optional()
    .refine((v) => {
      if (!v || v.trim() === '') return true
      try {
        JSON.parse(v)
        return true
      } catch {
        return false
      }
    }, 'Must be valid JSON'),
  requires_jit: z.boolean().optional(),
  always_record: z.boolean().optional(),
})

export function CreateResourceModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    setError,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { connect_mode: 'web_terminal', requires_jit: false, always_record: false },
  })

  const connectMode = watch('connect_mode')
  const resourceType = watch('resource_type')

  // Pre-fill the conventional port when a type is chosen and the field is
  // still untouched. Small thing, but it removes a lookup from every single
  // resource registration.
  useEffect(() => {
    if (!resourceType) return
    const suggested = DEFAULT_PORTS[resourceType]
    if (suggested) setValue('port', suggested, { shouldValidate: false })
  }, [resourceType, setValue])

  useEffect(() => {
    if (open) reset({ connect_mode: 'web_terminal', requires_jit: false, always_record: false })
  }, [open, reset])

  const mutation = useMutation({
    mutationFn: createResource,
    onSuccess: (created) => {
      queryClient.invalidateQueries({ queryKey: ['resources'] })
      toast.success('Resource registered', {
        description: `${created?.name || 'The resource'} is now available in the catalogue.`,
      })
      onClose()
    },
    onError: (err) => {
      // Attach per-field server validation inline where possible instead of
      // only firing a toast the user has to translate back to a field.
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not register resource', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((values) => mutation.mutate(values))

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      size="xl"
      icon={Boxes}
      title="Register a resource"
      description="Add a system PAM can broker and audit access to."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Register resource
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-6">
        <FormSection title="Identity">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Name" error={errors.name?.message} required>
              {({ id, ...a11y }) => (
                <Input id={id} {...a11y} data-autofocus error={!!errors.name} placeholder="prod-orders-db" {...register('name')} />
              )}
            </Field>
            <Field label="Type" error={errors.resource_type?.message} required>
              {({ id, ...a11y }) => (
                <Select id={id} {...a11y} error={!!errors.resource_type} {...register('resource_type')}>
                  <option value="">Select a type…</option>
                  {RESOURCE_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
          </div>
          <Field label="Description" hint="Optional — helps operators pick the right system.">
            {({ id, ...a11y }) => (
              <Textarea id={id} {...a11y} rows={2} placeholder="Primary orders database, EU region" {...register('description')} />
            )}
          </Field>
        </FormSection>

        <FormSection title="Network">
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="sm:col-span-2">
              <Field label="Host" error={errors.host?.message} required>
                {({ id, ...a11y }) => (
                  <Input id={id} {...a11y} error={!!errors.host} placeholder="db.internal.example.com" {...register('host')} />
                )}
              </Field>
            </div>
            <Field label="Port" error={errors.port?.message} required>
              {({ id, ...a11y }) => (
                <Input id={id} {...a11y} inputMode="numeric" error={!!errors.port} {...register('port')} />
              )}
            </Field>
          </div>
          <Field label="Database name" hint="Optional — for database resources.">
            {({ id, ...a11y }) => <Input id={id} {...a11y} {...register('database_name')} />}
          </Field>
        </FormSection>

        <FormSection title="How it opens">
          <Field
            label="Connect mode"
            hint={CONNECT_MODES.find((m) => m.value === connectMode)?.hint}
          >
            {({ id, ...a11y }) => (
              <Select id={id} {...a11y} {...register('connect_mode')}>
                {CONNECT_MODES.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </Select>
            )}
          </Field>
          <Field
            label="Console URL"
            error={errors.console_url?.message}
            hint={
              connectMode === 'embed_redirect'
                ? 'Required for this mode — used as the browser target when the desktop agent is unavailable.'
                : 'Optional — offered as the browser fallback when the desktop agent is unavailable.'
            }
          >
            {({ id, ...a11y }) => (
              <Input id={id} {...a11y} error={!!errors.console_url} placeholder="https://console.example.com" {...register('console_url')} />
            )}
          </Field>
        </FormSection>

        <FormSection title="Controls">
          <div className="space-y-1 rounded-lg border border-surface-700 bg-surface-850 p-3">
            <Checkbox
              label="Requires JIT approval"
              hint="No standing access. Every connection needs an approved, time-boxed request."
              {...register('requires_jit')}
            />
            <Checkbox
              label="Always record sessions"
              hint="Session recording cannot be skipped for this resource."
              {...register('always_record')}
            />
          </div>
          <Field
            label="Extra configuration"
            error={errors.extra_config?.message}
            hint="Optional protocol-specific settings as a JSON object."
          >
            {({ id, ...a11y }) => (
              <Textarea id={id} {...a11y} rows={2} className="font-mono text-xs" placeholder="{}" error={!!errors.extra_config} {...register('extra_config')} />
            )}
          </Field>
        </FormSection>
      </form>
    </Modal>
  )
}
