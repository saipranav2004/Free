import { useCallback, useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  ExternalLink, KeyRound, Laptop, Square, AlertCircle, Globe,
  MonitorSmartphone, Info, CheckCircle2,
} from 'lucide-react'
import { toast } from 'sonner'
import { getConnectInfo, startSession } from '../../api/resources'
import { endSession, listMySessions } from '../../api/sessions'
import { createLaunch } from '../../api/agent'
import { normalizeApiError, apiErrorMessage, isJitGrantRequiredError } from '../../lib/apiError'
import { attemptAgentHandoff, resolveBrowserTarget, openInBrowser } from '../../lib/agentLaunch'
import { entityId } from '../../lib/entity'
import { shortId } from '../../lib/format'
import {
  Button, Callout, CopyableValue, DescriptionList, DescriptionItem,
  Badge, Spinner, CardSkeleton,
} from '../../ui'
import { PairAgentPanel } from '../agent/PairAgentPanel'

// The backend has no live SSH/RDP/DB proxy: connect-info returns metadata
// only, and starting a "session" creates a TRACKED ROW for audit and JIT
// expiry purposes, not an actual live connection. This panel is deliberately
// honest about that rather than pretending to be a terminal.
const CLI_HINTS = {
  postgresql: (i) =>
    `psql -h ${i.host} -p ${i.port}${i.database_name ? ` -d ${i.database_name}` : ''} -U <username>`,
  mongodb: (i) => `mongosh "mongodb://${i.host}:${i.port}${i.database_name ? `/${i.database_name}` : ''}"`,
  redis: (i) => `redis-cli -h ${i.host} -p ${i.port}`,
  clickhouse: (i) => `clickhouse-client --host ${i.host} --port ${i.port}`,
  oracle: (i) => `sqlplus <username>@//${i.host}:${i.port}/${i.database_name || '<service>'}`,
  minio: (i) => `mc alias set ${i.host} http://${i.host}:${i.port} <access-key> <secret-key>`,
}

/**
 * ===========================================================================
 * CONNECT FLOW — desktop agent first, browser fallback
 * ===========================================================================
 * REQUIRED BEHAVIOUR, restored exactly:
 *
 *     Selecting a resource opens it through the desktop agent.
 *     If the desktop agent is not available, it opens in the browser.
 *
 * The API contract is unchanged. Connect still:
 *   POST /api/v1/pam/resources/:id/launch   -> pam-agent:// URL (agent path)
 *   GET  /api/v1/pam/resources/:id/connect-info (metadata, never a secret)
 *   POST /api/v1/pam/resources/:id/sessions (tracked session row)
 *
 * WHY IT PRESENTED AS "there is no connect to agent"
 * --------------------------------------------------
 * Three compounding defects:
 *
 *   1. Both connect buttons were `disabled={!info.has_credential}`. Storing
 *      a resource credential was itself broken (see api/adminResources.js),
 *      so has_credential was false everywhere and the agent button was
 *      permanently greyed out. The feature existed and could never be
 *      clicked.
 *   2. The handoff was `window.location.href = launch_url`. With no
 *      registered pam-agent:// handler that either does nothing or lands on
 *      a browser error page, taking the SPA with it. Nothing detected the
 *      failure, so the browser fallback never ran.
 *   3. There was no single "Connect" action at all — the user had to know
 *      which of two buttons meant what.
 *
 * All three are fixed: one primary Connect action, a non-destructive iframe
 * handoff with success detection, and an automatic browser fallback. The
 * credential state is now advisory (a warning) rather than a hard gate,
 * because the *server* decides whether a connection is permitted.
 */
export function ConnectPanel({ resourceId, resource }) {
  const queryClient = useQueryClient()
  const [activeSession, setActiveSession] = useState(null)
  const [needsPairing, setNeedsPairing] = useState(false)
  const [lastLaunchUrl, setLastLaunchUrl] = useState(null)
  const [connectStage, setConnectStage] = useState(null) // null | 'agent' | 'browser'

  const connectInfoQuery = useQuery({
    queryKey: ['resources', resourceId, 'connect-info'],
    queryFn: ({ signal }) => getConnectInfo(resourceId, signal),
    retry: false,
  })

  // FIX: the previous panel kept the active session in local state only, so
  // a page refresh lost it and the user could start a second tracked session
  // for the same resource. Adopting any already-open session for this
  // resource makes the panel reflect real server state.
  const mySessionsQuery = useQuery({
    queryKey: ['sessions', 'mine', { activeOnly: true, forResource: resourceId }],
    queryFn: ({ signal }) => listMySessions({ activeOnly: true, pageSize: 50, signal }),
    retry: false,
  })

  useEffect(() => {
    if (activeSession) return
    const existing = (mySessionsQuery.data?.sessions || []).find(
      (s) => s.resource_id === resourceId && s.status === 'ACTIVE'
    )
    if (existing) setActiveSession(existing)
  }, [mySessionsQuery.data, resourceId, activeSession])

  const info = connectInfoQuery.data

  const invalidateSessions = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['sessions'] })
  }, [queryClient])

  const startMutation = useMutation({
    mutationFn: () => startSession(resourceId),
    onSuccess: (data) => {
      setActiveSession(data.session)
      if (data.notice) toast.info('Session started', { description: data.notice })
      else toast.success('Session started', { description: 'This connection is now being tracked.' })
      invalidateSessions()
    },
    onError: (err) => toast.error('Could not start session', { description: apiErrorMessage(err) }),
  })

  const endMutation = useMutation({
    mutationFn: (sessionId) => endSession(sessionId),
    onSuccess: () => {
      setActiveSession(null)
      toast.success('Session ended')
      invalidateSessions()
    },
    onError: (err) => toast.error('Could not end session', { description: apiErrorMessage(err) }),
  })

  /** Open in the browser. Used both as the agent fallback and as an explicit
   *  user choice. */
  const openInBrowserNow = useCallback(
    (silent = false) => {
      const target = resolveBrowserTarget(info)
      if (target.kind === 'console') {
        const opened = openInBrowser(target.url)
        if (opened) {
          if (!silent) toast.success('Opened in your browser')
          return true
        }
        toast.warning('Your browser blocked the pop-up', {
          description: 'Use the "Open console" link below to continue.',
        })
        return false
      }
      // No console URL: the browser path for this resource is the in-console
      // connection details plus a tracked session, which is exactly what
      // connect_mode "web_terminal" means.
      if (!silent) {
        toast.info('Connection details ready below', {
          description: 'This resource connects with your own client using the host and port shown.',
        })
      }
      return true
    },
    [info]
  )

  /**
   * The primary Connect action.
   * Order of operations is deliberate and matches the original intent:
   *   1. ask the backend for a single-use agent launch URL
   *   2. hand it to the OS and watch for the handoff
   *   3. if the agent did not take it, open in the browser instead
   * A tracked session is started either way, so audit and grant expiry keep
   * working regardless of which path the connection actually took.
   */
  const connectMutation = useMutation({
    mutationFn: async () => {
      setConnectStage('agent')
      let launchUrl = null
      try {
        const launch = await createLaunch(resourceId)
        launchUrl = launch?.launch_url || null
        setLastLaunchUrl(launchUrl)
      } catch (err) {
        const normalized = normalizeApiError(err)
        // 409 from agent_handler.go's CreateLaunch means specifically "no
        // device paired yet" — not a failure. Surface the inline pairing
        // flow and still fall back to the browser so the user is never stuck.
        if (normalized.status === 409) {
          return { path: 'browser', reason: 'not_paired' }
        }
        // Any other launch error (403, 500) is a real failure of the agent
        // path, but the browser path may still be available.
        return { path: 'browser', reason: 'launch_failed', error: normalized }
      }

      const { handedOff } = await attemptAgentHandoff(launchUrl)
      if (handedOff) return { path: 'agent' }
      return { path: 'browser', reason: 'no_handler' }
    },
    onSuccess: (result) => {
      if (result.path === 'agent') {
        setConnectStage(null)
        setNeedsPairing(false)
        toast.success('Opening in the desktop app', {
          description: 'The local agent is establishing the connection.',
        })
        if (!activeSession) startMutation.mutate()
        return
      }

      // --- browser fallback -------------------------------------------
      setConnectStage('browser')
      if (result.reason === 'not_paired') setNeedsPairing(true)

      const opened = openInBrowserNow(true)
      setConnectStage(null)

      const description =
        result.reason === 'not_paired'
          ? 'No desktop agent is paired to this account, so this opened in your browser.'
          : result.reason === 'launch_failed'
            ? result.error?.message || 'The desktop agent could not be reached, so this opened in your browser.'
            : 'The desktop app did not respond, so this opened in your browser.'

      if (opened) toast.info('Opened in your browser', { description })
      if (!activeSession) startMutation.mutate()
    },
    onError: (err) => {
      setConnectStage(null)
      toast.error('Could not connect', { description: apiErrorMessage(err) })
    },
  })

  /* ---------------------------------------------------------------- states */

  if (connectInfoQuery.isLoading) {
    return <CardSkeleton lines={4} />
  }

  if (connectInfoQuery.isError) {
    const err = normalizeApiError(connectInfoQuery.error)
    if (isJitGrantRequiredError(err)) {
      return (
        <Callout
          tone="warning"
          icon={AlertCircle}
          title="Time-boxed access required"
          action={
            <Link to={`/jit?resourceId=${resourceId}`}>
              <Button size="sm" variant="warning" icon={KeyRound}>
                Request access
              </Button>
            </Link>
          }
        >
          This resource is JIT-gated and you don&apos;t currently hold an active grant. Request
          approval to connect.
        </Callout>
      )
    }
    return (
      <Callout tone="danger" icon={AlertCircle} title="Cannot check access">
        {err.message}
      </Callout>
    )
  }

  const cliHint = CLI_HINTS[info.type || resource?.resource_type]?.(info)
  const browserTarget = resolveBrowserTarget(info)
  const isConnecting = connectMutation.isPending || startMutation.isPending

  return (
    <div className="space-y-5">
      {/* ------------------------------------------------ primary action */}
      <div>
        {activeSession ? (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-emerald-300 bg-emerald-50 px-3.5 py-3 dark:border-emerald-500/30 dark:bg-emerald-500/10">
            <span className="flex items-center gap-2 text-sm font-medium text-emerald-800 dark:text-emerald-300">
              <CheckCircle2 className="h-4 w-4 flex-none" aria-hidden="true" />
              Session tracked
              <code className="rounded bg-emerald-100 px-1.5 py-0.5 font-mono text-2xs text-emerald-900 dark:bg-emerald-500/20 dark:text-emerald-200">
                {shortId(entityId(activeSession))}
              </code>
            </span>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="secondary"
                icon={MonitorSmartphone}
                onClick={() => connectMutation.mutate()}
                loading={connectMutation.isPending}
              >
                Reconnect
              </Button>
              <Button
                size="sm"
                variant="dangerOutline"
                icon={Square}
                loading={endMutation.isPending}
                onClick={() => endMutation.mutate(entityId(activeSession))}
              >
                End session
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="primary"
              icon={MonitorSmartphone}
              loading={isConnecting}
              onClick={() => {
                setNeedsPairing(false)
                connectMutation.mutate()
              }}
            >
              {connectStage === 'agent'
                ? 'Opening desktop app…'
                : connectStage === 'browser'
                  ? 'Opening in browser…'
                  : 'Connect'}
            </Button>

            {/* Explicit escape hatches. The primary action already falls
                back automatically; these exist for the operator who knows
                which path they want. */}
            <Button
              variant="secondary"
              icon={Globe}
              disabled={isConnecting}
              onClick={() => {
                openInBrowserNow()
                if (!activeSession) startMutation.mutate()
              }}
            >
              Open in browser
            </Button>

            {lastLaunchUrl && (
              // A plain anchor is the most reliable way to trigger a custom
              // protocol handler, because it carries a direct user gesture.
              // Offered after an automatic attempt so a user whose OS shows
              // a "always allow" prompt can retry deliberately.
              <a
                href={lastLaunchUrl}
                className="inline-flex h-9 items-center gap-2 rounded-md px-3 text-sm font-medium text-ink-300 transition-colors hover:bg-surface-800 hover:text-ink-50"
              >
                <Laptop className="h-4 w-4" aria-hidden="true" /> Retry desktop app
              </a>
            )}
          </div>
        )}

        <p className="mt-2 flex items-start gap-1.5 text-xs leading-relaxed text-ink-500">
          <Info className="mt-0.5 h-3.5 w-3.5 flex-none" aria-hidden="true" />
          Connect hands off to the local <code className="font-mono text-ink-400">pam-agent</code>{' '}
          desktop app when it&apos;s available, and opens in your browser when it isn&apos;t. The
          browser never receives the credential.
        </p>
      </div>

      {/* ------------------------------------------------------ warnings */}
      {!info.has_credential && (
        <Callout tone="warning" icon={KeyRound} title="No credential stored">
          This resource has no credential in the vault yet, so an automated connection has nothing
          to inject. An administrator can store one from the Details panel.
        </Callout>
      )}

      {needsPairing && (
        <div>
          <PairAgentPanel
            onPaired={() => {
              setNeedsPairing(false)
              toast.success('Desktop agent paired')
              connectMutation.mutate()
            }}
          />
        </div>
      )}

      {/* -------------------------------------------- connection details */}
      <div className="border-t border-surface-700 pt-4">
        <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-ink-500">
          Connection details
        </h4>
        <DescriptionList cols="110px 1fr">
          <DescriptionItem label="Host">
            <span className="font-mono text-xs">{info.host || '—'}</span>
          </DescriptionItem>
          <DescriptionItem label="Port">
            <span className="font-mono text-xs tabular-nums">{info.port ?? '—'}</span>
          </DescriptionItem>
          {info.database_name && (
            <DescriptionItem label="Database">
              <span className="font-mono text-xs">{info.database_name}</span>
            </DescriptionItem>
          )}
          <DescriptionItem label="Credential">
            {info.has_credential ? (
              <Badge tone="success">Stored in vault</Badge>
            ) : (
              <Badge tone="warning">Not configured</Badge>
            )}
          </DescriptionItem>
        </DescriptionList>

        {cliHint && (
          <div className="mt-4">
            <p className="mb-1.5 text-xs font-medium text-ink-400">Connect with your own client</p>
            <CopyableValue value={cliHint} label="Copy" />
          </div>
        )}

        {browserTarget.kind === 'console' && (
          <a
            href={browserTarget.url}
            target="_blank"
            rel="noreferrer noopener"
            className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-brand-600 hover:underline dark:text-brand-400"
          >
            <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" /> Open console
          </a>
        )}
      </div>

      {startMutation.isPending && !activeSession && (
        <p className="flex items-center gap-2 text-xs text-ink-500">
          <Spinner size="h-3.5 w-3.5" /> Registering tracked session…
        </p>
      )}
    </div>
  )
}
