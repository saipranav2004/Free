import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { UserPlus } from 'lucide-react'
import { createUser } from '../../api/identity'
import { listRoles } from '../../api/rbac'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { Modal, Button, Field, Input, Select, FormSection, Callout } from '../../ui'

const schema = z.object({
  username: z
    .string()
    .trim()
    .min(3, 'At least 3 characters')
    .max(64)
    .regex(/^[a-zA-Z0-9._-]+$/, 'Letters, digits, dot, underscore and hyphen only'),
  email: z.string().trim().email('Enter a valid email address'),
  password: z.string().min(12, 'At least 12 characters — this is a privileged-access console'),
  role_name: z.string().optional(),
})

export function CreateUserModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register, handleSubmit, reset, setError, formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })

  useEffect(() => {
    if (open) reset({ username: '', email: '', password: '', role_name: '' })
  }, [open, reset])

  const rolesQuery = useQuery({
    queryKey: ['rbac', 'roles'],
    queryFn: ({ signal }) => listRoles(signal),
    enabled: open,
    staleTime: 60_000,
    retry: false,
  })

  const mutation = useMutation({
    mutationFn: (values) =>
      createUser({
        username: values.username,
        email: values.email,
        password: values.password,
        role_name: values.role_name || undefined,
      }),
    onSuccess: (user) => {
      queryClient.invalidateQueries({ queryKey: ['identity', 'users'] })
      toast.success('User created', { description: `${user?.username || 'The account'} can now sign in.` })
      onClose()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError, { Password: 'password', Username: 'username', Email: 'email' })) {
        toast.error('Could not create user', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      icon={UserPlus}
      title="Create a user"
      description="The account can sign in immediately. Roles determine what it may do."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Create user
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-5">
        <FormSection title="Identity">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Username" error={errors.username?.message} required>
              {({ id, ...a }) => (
                <Input id={id} {...a} data-autofocus autoComplete="off" error={!!errors.username} {...register('username')} />
              )}
            </Field>
            <Field label="Email" error={errors.email?.message} required>
              {({ id, ...a }) => (
                <Input id={id} {...a} type="email" autoComplete="off" error={!!errors.email} {...register('email')} />
              )}
            </Field>
          </div>
        </FormSection>

        <FormSection title="Initial credentials">
          <Field
            label="Temporary password"
            error={errors.password?.message}
            hint="Share it over a secure channel. The user should change it on first sign-in."
            required
          >
            {({ id, ...a }) => (
              <Input id={id} {...a} type="password" autoComplete="new-password" error={!!errors.password} {...register('password')} />
            )}
          </Field>
        </FormSection>

        <FormSection title="Access">
          <Field
            label="Initial role"
            hint="Optional — additional roles can be assigned from the user's detail page."
          >
            {({ id, ...a }) => (
              <Select id={id} {...a} disabled={rolesQuery.isLoading} {...register('role_name')}>
                <option value="">No role</option>
                {(rolesQuery.data || []).map((r) => (
                  <option key={r.name ?? r.id} value={r.name}>
                    {r.name}
                  </option>
                ))}
              </Select>
            )}
          </Field>
          {rolesQuery.isError && (
            <Callout tone="warning">
              Roles could not be loaded, so none can be assigned here. The user can still be created
              and given a role from their detail page.
            </Callout>
          )}
        </FormSection>
      </form>
    </Modal>
  )
}
