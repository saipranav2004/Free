import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { FileCode2, Plus, X } from 'lucide-react'
import { createPolicy } from '../../api/rbac'
import { COMMON_ACTIONS, POLICY_EFFECTS } from '../../config/constants'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { Modal, Button, Field, Input, Textarea, Select, FormSection, Callout } from '../../ui'

const schema = z.object({
  name: z.string().trim().min(2, 'At least 2 characters').max(128),
  description: z.string().trim().min(1, 'Describe what this policy permits or blocks'),
  effect: z.enum(['allow', 'deny']),
  resource_pattern: z.string().trim().min(1, 'Required — use * to match everything'),
})

/**
 * PBAC policy authoring.
 *
 * Actions are a *set*, not a free-text blob. The previous approach of a
 * comma-separated string meant one stray space produced an action string the
 * policy engine would never match, with no feedback — the policy simply never
 * fired. Here each action is added as a discrete chip, deduplicated, and the
 * common vocabulary is offered directly.
 */
export function CreatePolicyModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const [actions, setActions] = useState([])
  const [actionDraft, setActionDraft] = useState('')
  const {
    register, handleSubmit, reset, setError, formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { effect: 'allow', resource_pattern: '*' },
  })

  useEffect(() => {
    if (open) {
      reset({ name: '', description: '', effect: 'allow', resource_pattern: '*' })
      setActions([])
      setActionDraft('')
    }
  }, [open, reset])

  const addAction = (value) => {
    const v = String(value || '').trim()
    if (!v) return
    setActions((prev) => (prev.includes(v) ? prev : [...prev, v]))
    setActionDraft('')
  }

  const mutation = useMutation({
    mutationFn: (values) => createPolicy({ ...values, actions }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rbac', 'policies'] })
      toast.success('Policy created', { description: 'Attach it to a role or a user to take effect.' })
      onClose()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not create policy', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => {
    if (actions.length === 0) {
      toast.error('Add at least one action', {
        description: 'A policy with no actions matches nothing and has no effect.',
      })
      return
    }
    mutation.mutate(v)
  })

  const suggestions = COMMON_ACTIONS.filter((a) => !actions.includes(a)).slice(0, 8)

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      size="lg"
      icon={FileCode2}
      title="Create a policy"
      description="Policies decide what an action against a resource pattern is allowed to do."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Create policy
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-5">
        <FormSection title="Definition">
          <Field label="Name" error={errors.name?.message} required>
            {({ id, ...a }) => (
              <Input id={id} {...a} data-autofocus error={!!errors.name} placeholder="allow-db-read" {...register('name')} />
            )}
          </Field>
          <Field label="Description" error={errors.description?.message} required>
            {({ id, ...a }) => <Textarea id={id} {...a} rows={2} error={!!errors.description} {...register('description')} />}
          </Field>
        </FormSection>

        <FormSection title="Rule">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Effect" error={errors.effect?.message} required>
              {({ id, ...a }) => (
                <Select id={id} {...a} error={!!errors.effect} {...register('effect')}>
                  {POLICY_EFFECTS.map((e) => (
                    <option key={e.value} value={e.value}>
                      {e.label}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <Field
              label="Resource pattern"
              error={errors.resource_pattern?.message}
              hint="* matches everything."
              required
            >
              {({ id, ...a }) => (
                <Input id={id} {...a} className="font-mono text-xs" error={!!errors.resource_pattern} {...register('resource_pattern')} />
              )}
            </Field>
          </div>

          <div>
            <p className="mb-1.5 text-xs font-medium text-ink-300">
              Actions <span className="text-red-600 dark:text-red-400">*</span>
            </p>

            {actions.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-1.5">
                {actions.map((a) => (
                  <span
                    key={a}
                    className="inline-flex items-center gap-1 rounded-md border border-surface-700 bg-surface-850 py-0.5 pl-2 pr-1 font-mono text-2xs text-ink-100"
                  >
                    {a}
                    <button
                      type="button"
                      onClick={() => setActions((prev) => prev.filter((x) => x !== a))}
                      className="rounded p-0.5 text-ink-500 hover:bg-surface-800 hover:text-red-500"
                      aria-label={`Remove ${a}`}
                    >
                      <X className="h-3 w-3" aria-hidden="true" />
                    </button>
                  </span>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <Input
                value={actionDraft}
                onChange={(e) => setActionDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    // Adding an action must not submit the whole form.
                    e.preventDefault()
                    addAction(actionDraft)
                  }
                }}
                className="font-mono text-xs"
                placeholder="pam:vault:Reveal"
              />
              <Button type="button" variant="secondary" icon={Plus} onClick={() => addAction(actionDraft)}>
                Add
              </Button>
            </div>

            {suggestions.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {suggestions.map((a) => (
                  <button
                    key={a}
                    type="button"
                    onClick={() => addAction(a)}
                    className="rounded-md border border-dashed border-surface-600 px-2 py-0.5 font-mono text-2xs text-ink-400 transition-colors hover:border-brand-500 hover:text-brand-500"
                  >
                    + {a}
                  </button>
                ))}
              </div>
            )}

            {actions.length === 0 && (
              <p className="mt-1.5 text-xs text-ink-500">
                A policy with no actions matches nothing.
              </p>
            )}
          </div>
        </FormSection>

        <Callout tone="neutral" title="How this is evaluated">
          Deny always wins over allow. A policy takes effect only once it is attached to a role or
          directly to a user.
        </Callout>
      </form>
    </Modal>
  )
}
