import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Shield } from 'lucide-react'
import { createRole } from '../../api/rbac'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { Modal, Button, Field, Input, Textarea } from '../../ui'

const schema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'At least 2 characters')
    .max(64)
    .regex(/^[a-z0-9_-]+$/, 'Lowercase letters, digits, underscore and hyphen only'),
  description: z.string().trim().min(1, 'Describe what this role is for'),
})

export function CreateRoleModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register, handleSubmit, reset, setError, formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })

  useEffect(() => {
    if (open) reset({ name: '', description: '' })
  }, [open, reset])

  const mutation = useMutation({
    mutationFn: createRole,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rbac', 'roles'] })
      toast.success('Role created', { description: 'Attach policies to give it permissions.' })
      onClose()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not create role', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      icon={Shield}
      title="Create a role"
      description="A role is a named bundle of policies you assign to users."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button variant="primary" loading={mutation.isPending} onClick={submit}>
            Create role
          </Button>
        </>
      }
    >
      <form onSubmit={submit} noValidate className="space-y-4">
        <Field label="Name" error={errors.name?.message} hint="e.g. db-operator, auditor" required>
          {({ id, ...a }) => (
            <Input id={id} {...a} data-autofocus className="font-mono text-xs" error={!!errors.name} {...register('name')} />
          )}
        </Field>
        <Field
          label="Description"
          error={errors.description?.message}
          hint="What this role is for. Reviewers rely on this during access recertification."
          required
        >
          {({ id, ...a }) => <Textarea id={id} {...a} rows={2} error={!!errors.description} {...register('description')} />}
        </Field>
      </form>
    </Modal>
  )
}
