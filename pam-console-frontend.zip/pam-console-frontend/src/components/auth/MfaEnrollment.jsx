import { useEffect, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { ShieldCheck, AlertTriangle, KeyRound } from 'lucide-react'
import { mfaSetupInitiate, mfaSetupVerify } from '../../api/auth'
import { apiErrorMessage } from '../../lib/apiError'
import { Card, CardHeader, CardBody, Button, CopyableValue, CopyButton, Callout, Field } from '../../ui'

/**
 * Three-step enrolment: initiate (QR + secret) → verify (6-digit code
 * activates it and returns backup codes) → explicit acknowledgement that the
 * codes were saved, because they are shown exactly once (auth_handler.go's
 * own comment: "Save these backup codes — they will NOT be shown again").
 *
 * The `backup-codes` step is deliberately NOT auto-dismissed, and a
 * beforeunload warning fires while it is on screen: closing or navigating
 * away right after verify() succeeds permanently loses the codes, because
 * the backend never returns them again.
 */
export function MfaEnrollment({ onEnrolled }) {
  const [step, setStep] = useState('start') // start | qr | backup-codes
  const [setupData, setSetupData] = useState(null)
  const [code, setCode] = useState('')
  const [backupCodes, setBackupCodes] = useState(null)
  const [acknowledged, setAcknowledged] = useState(false)
  const [error, setError] = useState(null)

  // Guard against losing one-time backup codes to an accidental navigation.
  useEffect(() => {
    if (step !== 'backup-codes' || acknowledged) return undefined
    const handler = (e) => {
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [step, acknowledged])

  const initiate = useMutation({
    mutationFn: mfaSetupInitiate,
    onSuccess: (data) => {
      setSetupData(data)
      setStep('qr')
      setError(null)
    },
    onError: (err) => setError(apiErrorMessage(err)),
  })

  const verify = useMutation({
    mutationFn: (value) => mfaSetupVerify(setupData.mfa_device_id, value),
    onSuccess: (data) => {
      setBackupCodes(data.backup_codes || [])
      setStep('backup-codes')
      setError(null)
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      setCode('')
    },
  })

  if (step === 'start') {
    return (
      <Card>
        <CardHeader
          title="Two-factor authentication"
          description="Required before revealing credentials or approving access requests."
        />
        <CardBody className="space-y-4">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-surface-800 text-ink-400">
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            </span>
            <p className="text-sm leading-relaxed text-ink-400">
              Not enabled on this account. Enrolling takes about a minute and uses any standard TOTP
              app — Google Authenticator, 1Password, Authy.
            </p>
          </div>
          {error && <Callout tone="danger">{error}</Callout>}
          <Button variant="primary" icon={ShieldCheck} loading={initiate.isPending} onClick={() => initiate.mutate()}>
            Enable two-factor authentication
          </Button>
        </CardBody>
      </Card>
    )
  }

  if (step === 'qr') {
    return (
      <Card>
        <CardHeader title="Scan the QR code" description="Then enter the 6-digit code to confirm." />
        <CardBody className="space-y-5">
          <div className="flex flex-col gap-5 sm:flex-row">
            {setupData?.qr_code_base64 && (
              <img
                src={`data:image/png;base64,${setupData.qr_code_base64}`}
                alt="Two-factor enrolment QR code"
                className="h-40 w-40 flex-none rounded-lg border border-surface-700 bg-white p-2"
              />
            )}
            <div className="min-w-0 flex-1 space-y-2">
              <p className="text-xs font-medium text-ink-400">Or enter this key manually</p>
              <CopyableValue value={setupData?.secret} label="Copy key" truncate={false} />
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault()
              if (code.trim()) verify.mutate(code.trim())
            }}
            className="space-y-3"
          >
            {error && <Callout tone="danger">{error}</Callout>}
            <Field label="Confirmation code" required>
              {({ id, ...a }) => (
                <input
                  id={id}
                  {...a}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={8}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ''))}
                  className="h-11 w-40 rounded-md border border-surface-700 bg-surface-800 text-center font-mono text-lg tracking-[0.3em] text-ink-50 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/25"
                  placeholder="000000"
                />
              )}
            </Field>
            <Button type="submit" variant="primary" loading={verify.isPending} disabled={code.length === 0}>
              Activate
            </Button>
          </form>
        </CardBody>
      </Card>
    )
  }

  return (
    <Card className="border-amber-300 dark:border-amber-500/40">
      <CardHeader title="Save your backup codes now" />
      <CardBody className="space-y-4">
        <Callout tone="warning" icon={AlertTriangle} title="These will not be shown again">
          Two-factor authentication is active. Each code can be used once if you lose access to your
          authenticator app. Store them in a password manager, not in this browser.
        </Callout>

        <div className="grid grid-cols-2 gap-2 rounded-lg border border-surface-700 bg-surface-850 p-3.5 font-mono text-sm text-ink-100 sm:grid-cols-3">
          {(backupCodes || []).map((c) => (
            <span key={c} className="select-all tabular-nums">
              {c}
            </span>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <CopyButton value={(backupCodes || []).join('\n')} label="Copy all codes" />
          <Button
            variant="primary"
            icon={KeyRound}
            onClick={() => {
              setAcknowledged(true)
              onEnrolled?.()
            }}
          >
            I&apos;ve saved these codes
          </Button>
        </div>
      </CardBody>
    </Card>
  )
}
