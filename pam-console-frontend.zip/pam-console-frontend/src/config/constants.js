// Central place for every enum/status the backend uses, kept in sync with
// internal/models/*.go. Importing these instead of hardcoding string
// literals is what prevents "PENDING" vs "Pending" typo bugs from silently
// breaking a status filter or badge colour.
//
// Every *_BADGE map carries BOTH light and dark class fragments. A badge
// built only from dark-console shades reads as near-invisible pale text on a
// white card in light mode.

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080'

export const DEFAULT_TIMEOUT_MS = 20_000
// Report rendering is server-side and can legitimately exceed the normal
// read timeout on a wide date range. The old shared 20s ceiling aborted
// those requests before the server finished, surfacing as an unexplained
// "could not generate report".
export const REPORT_TIMEOUT_MS = 120_000

// ---------------------------------------------------------------------------
// Roles (RBAC)
// ---------------------------------------------------------------------------
export const SYSTEM_ROLES = ['root', 'admin', 'user']

export function isAdminRole(roles) {
  return Array.isArray(roles) && (roles.includes('admin') || roles.includes('root'))
}
export function isRootRole(roles) {
  return Array.isArray(roles) && roles.includes('root')
}

export const ROLE_BADGE = {
  root: 'bg-purple-50 text-purple-700 ring-purple-600/20 dark:bg-purple-500/15 dark:text-purple-400 dark:ring-purple-500/30',
  admin: 'bg-brand-50 text-brand-700 ring-brand-600/20 dark:bg-brand-500/15 dark:text-brand-400 dark:ring-brand-500/30',
  user: 'bg-surface-800 text-ink-300 ring-surface-600',
}

// ---------------------------------------------------------------------------
// Identity
// ---------------------------------------------------------------------------
export const USER_STATUSES = ['ACTIVE', 'DISABLED', 'LOCKED']

export const USER_STATUS_BADGE = {
  ACTIVE:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  DISABLED: 'bg-surface-800 text-ink-400 ring-surface-600',
  LOCKED:
    'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-400 dark:ring-amber-500/30',
  DELETED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

export const USER_STATUS_DESCRIPTION = {
  ACTIVE: 'Can sign in and hold access normally.',
  DISABLED: 'Cannot sign in. Existing grants stop being usable.',
  LOCKED: 'Temporarily blocked, usually after repeated failed sign-ins.',
}

// ---------------------------------------------------------------------------
// PBAC
// ---------------------------------------------------------------------------
export const POLICY_EFFECTS = [
  { value: 'allow', label: 'Allow' },
  { value: 'deny', label: 'Deny' },
]

export const POLICY_EFFECT_BADGE = {
  allow:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  deny: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

// Suggestion vocabulary only — the server is the source of truth for what
// counts as a valid action string.
export const COMMON_ACTIONS = [
  'pam:resource:List', 'pam:resource:Read', 'pam:resource:Connect',
  'pam:session:Start', 'pam:session:End',
  'pam:vault:List', 'pam:vault:Read', 'pam:vault:Create', 'pam:vault:Store',
  'pam:vault:Reveal', 'pam:vault:Rotate',
  'pam:jit:Request', 'pam:jit:Cancel', 'pam:breakglass:Use',
  'pam:audit:Read', 'pam:report:Generate',
  '*',
]

// ---------------------------------------------------------------------------
// Resources
// ---------------------------------------------------------------------------
export const RESOURCE_TYPES = [
  { value: 'postgresql', label: 'PostgreSQL' },
  { value: 'mongodb', label: 'MongoDB' },
  { value: 'redis', label: 'Redis' },
  { value: 'clickhouse', label: 'ClickHouse' },
  { value: 'minio', label: 'MinIO' },
  { value: 'qdrant', label: 'Qdrant' },
  { value: 'metabase', label: 'Metabase' },
  { value: 'langfuse', label: 'Langfuse' },
  { value: 'web', label: 'Web Application' },
  { value: 'oracle', label: 'Oracle' },
]

export const DEFAULT_PORTS = {
  postgresql: 5432,
  mongodb: 27017,
  redis: 6379,
  clickhouse: 8123,
  minio: 9000,
  qdrant: 6333,
  metabase: 3000,
  langfuse: 3000,
  web: 443,
  oracle: 1521,
}

export const CONNECT_MODES = [
  {
    value: 'web_terminal',
    label: 'Connection details',
    hint: 'Host and port are shown in the console; the desktop agent or your own client makes the connection.',
  },
  {
    value: 'embed_redirect',
    label: 'Console URL',
    hint: 'Opens the resource’s own web console. Requires a console URL below.',
  },
]

// ---------------------------------------------------------------------------
// Vault
// ---------------------------------------------------------------------------
export const CREDENTIAL_TYPES = [
  { value: 'password', label: 'Password' },
  { value: 'ssh_key', label: 'SSH Private Key' },
  { value: 'x509_cert', label: 'X.509 Certificate' },
  { value: 'api_key', label: 'API Key / Bearer Token' },
  { value: 'token', label: 'OAuth / OIDC Token' },
  { value: 'connection_string', label: 'Connection String' },
  { value: 'kerberos_keytab', label: 'Kerberos Keytab' },
]

// Fallback TTL for a revealed secret when the backend response omits
// expires_at. Without this the view would either never expire (a secret left
// on screen indefinitely) or expire instantly.
export const REVEAL_FALLBACK_TTL_SEC = 120

// ---------------------------------------------------------------------------
// JIT
// ---------------------------------------------------------------------------
export const JIT_STATUS = {
  PENDING: 'PENDING',
  WAITING: 'WAITING',
  APPROVED: 'APPROVED',
  DENIED: 'DENIED',
  CANCELLED: 'CANCELLED',
  EXPIRED: 'EXPIRED',
}

export const JIT_STATUS_LABELS = {
  PENDING: 'Pending approval',
  WAITING: 'Cooling-off period',
  APPROVED: 'Approved',
  DENIED: 'Denied',
  CANCELLED: 'Cancelled',
  EXPIRED: 'Expired',
}

export const JIT_STATUS_BADGE = {
  PENDING:
    'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-400 dark:ring-amber-500/30',
  WAITING:
    'bg-orange-50 text-orange-700 ring-orange-600/20 dark:bg-orange-500/15 dark:text-orange-400 dark:ring-orange-500/30',
  APPROVED:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  DENIED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
  CANCELLED: 'bg-surface-800 text-ink-400 ring-surface-600',
  EXPIRED: 'bg-surface-800 text-ink-400 ring-surface-600',
}

/** Statuses an admin can still act on. */
export const JIT_ACTIONABLE_STATUSES = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

export const JIT_TYPE = { STANDARD: 'STANDARD', BREAKGLASS: 'BREAKGLASS' }

export const GRANT_STATUS = { ACTIVE: 'ACTIVE', EXPIRED: 'EXPIRED', REVOKED: 'REVOKED' }

export const GRANT_STATUS_BADGE = {
  ACTIVE:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  EXPIRED: 'bg-surface-800 text-ink-400 ring-surface-600',
  REVOKED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

// Server-configured defaults (internal/config/config.go viper defaults).
// HINTS ONLY for placeholders and helper text — the server is always the
// source of truth and its own validation error is what is shown when a real
// submission violates the configured policy, which may differ per deployment.
export const JIT_DEFAULTS = {
  DEFAULT_DURATION_MIN: 60,
  MAX_DURATION_MIN: 480,
  MIN_REASON_LENGTH: 10,
  BREAKGLASS_WAIT_MIN: 15,
  BREAKGLASS_MAX_DURATION_MIN: 60,
}

export const DURATION_PRESETS = [
  { minutes: 15, label: '15m' },
  { minutes: 30, label: '30m' },
  { minutes: 60, label: '1h' },
  { minutes: 120, label: '2h' },
  { minutes: 240, label: '4h' },
  { minutes: 480, label: '8h' },
]

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------
export const SESSION_STATUS_BADGE = {
  ACTIVE:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  COMPLETED: 'bg-surface-800 text-ink-400 ring-surface-600',
  KILLED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
  FAILED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// Audit
// ---------------------------------------------------------------------------
export const AUDIT_CATEGORIES = [
  'AUTH', 'AUTHZ', 'VAULT', 'SESSION', 'RESOURCE',
  'BREAK_GLASS', 'JIT', 'ADMIN', 'REPORT', 'OTHER',
]

export const AUDIT_OUTCOMES = ['SUCCESS', 'DENIED', 'ERROR', 'PENDING', 'FAILURE']

export const AUDIT_OUTCOME_BADGE = {
  SUCCESS:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  DENIED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
  ERROR: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
  PENDING:
    'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-400 dark:ring-amber-500/30',
  FAILURE: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

export const AUDIT_SEVERITY_BADGE = {
  INFO: 'bg-brand-50 text-brand-700 ring-brand-600/20 dark:bg-brand-500/15 dark:text-brand-400 dark:ring-brand-500/30',
  WARN: 'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-400 dark:ring-amber-500/30',
  CRITICAL: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

export const REPORT_FORMATS = [
  { value: 'pdf', label: 'PDF', hint: 'Formatted, signed-off compliance document.' },
  { value: 'csv', label: 'CSV', hint: 'Raw rows for spreadsheet or SIEM ingestion.' },
]

export const REPORT_RANGE_PRESETS = [
  { key: '24h', label: 'Last 24 hours', days: 1 },
  { key: '7d', label: 'Last 7 days', days: 7 },
  { key: '30d', label: 'Last 30 days', days: 30 },
  { key: '90d', label: 'Last 90 days', days: 90 },
  { key: 'custom', label: 'Custom range', days: null },
]

// ---------------------------------------------------------------------------
// Recording
// ---------------------------------------------------------------------------
export const RECORDING_STATUS_BADGE = {
  PENDING:
    'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-400 dark:ring-amber-500/30',
  RECORDING:
    'bg-brand-50 text-brand-700 ring-brand-600/20 dark:bg-brand-500/15 dark:text-brand-400 dark:ring-brand-500/30',
  COMPLETED:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  FAILED: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------
export const DEFAULT_PAGE_SIZE = 20
export const SESSIONS_POLL_MS = 15_000 // no push channel on the backend yet
export const JIT_POLL_MS = 30_000
export const SEARCH_DEBOUNCE_MS = 300
