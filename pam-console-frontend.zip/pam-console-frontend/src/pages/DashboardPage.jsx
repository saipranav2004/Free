import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  Boxes, Vault, Radio, KeyRound, ScrollText, ShieldAlert, ArrowRight,
  Users, ClipboardList, Lock, Activity, Clock,
} from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { getStats } from '../api/admin'
import { listMyGrants, listMyJitRequests } from '../api/jit'
import { listMySessions } from '../api/sessions'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { useCountdown } from '../hooks/useCountdown'
import { formatDateTime, formatDuration, formatRelativeToNow } from '../lib/format'
import { pick, resourceLabel, entityId } from '../lib/entity'
import { JIT_STATUS, JIT_STATUS_BADGE, JIT_STATUS_LABELS } from '../config/constants'
import {
  PageHeader, Card, CardHeader, StatCard, Badge, Button,
  EmptyState, QueryState, TableSkeleton, Table, TBody, TR, TD, CellStack,
} from '../ui'

const QUICK_LINKS = [
  { to: '/resources', label: 'Resources', icon: Boxes, description: 'Browse systems you can connect to' },
  { to: '/vault', label: 'Vault', icon: Vault, description: 'Safes, folders and credentials' },
  { to: '/jit', label: 'JIT Access', icon: KeyRound, description: 'Request or track time-boxed access' },
  { to: '/sessions', label: 'Sessions', icon: Radio, description: 'Your connection history' },
  { to: '/audit', label: 'Audit', icon: ScrollText, description: 'Search your activity trail' },
]

/* -------------------------------------------------------------------------
 * Admin view
 * ---------------------------------------------------------------------- */

function AdminDashboard() {
  const statsQuery = useQuery({
    queryKey: ['admin', 'stats'],
    queryFn: ({ signal }) => getStats(signal),
  })
  const s = statsQuery.data
  const loading = statsQuery.isLoading

  // The exact shape of GET /admin/stats is not pinned down by any contract
  // available here, so each tile tries the plausible key names rather than
  // committing to one casing and silently showing "—" for everything.
  const stat = (...keys) => pick(s, ...keys) ?? '—'

  return (
    <>
      <PageHeader
        title="Dashboard"
        description="Organization-wide posture across identity, access, sessions and audit."
        actions={
          <Link to="/admin">
            <Button variant="primary" icon={ShieldAlert}>
              Needs attention
            </Button>
          </Link>
        }
      />

      <section aria-label="Organization statistics">
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-ink-500">
          Identity &amp; access
        </h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Users" icon={Users} loading={loading} to="/admin/identity"
            value={stat('total_users', 'user_count', 'users')} />
          <StatCard label="Resources" icon={Boxes} loading={loading} to="/resources"
            value={stat('total_resources', 'resource_count', 'resources')} />
          <StatCard label="Active grants" icon={Lock} tone="emerald" loading={loading} to="/admin/jit"
            value={stat('active_grants', 'active_grant_count')} />
          <StatCard label="Vault credentials" icon={Vault} loading={loading} to="/vault"
            value={stat('total_credentials', 'credential_count')} />
        </div>
      </section>

      <section aria-label="Live activity" className="mt-7">
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-ink-500">
          Live activity
        </h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Active sessions" icon={Activity} tone="emerald" loading={loading} to="/sessions"
            value={stat('active_sessions', 'active_session_count')} />
          <StatCard label="Pending JIT requests" icon={KeyRound} tone="amber" loading={loading} to="/admin/jit"
            hint="Awaiting a decision"
            value={stat('pending_jit_requests', 'pending_requests', 'pending_jit_count')} />
          <StatCard label="Break-glass (active)" icon={ShieldAlert} tone="red" loading={loading} to="/admin/jit"
            hint="Emergency access in use"
            value={stat('active_breakglass', 'breakglass_active_count', 'active_breakglass_grants')} />
          <StatCard label="Audit events (24h)" icon={ClipboardList} loading={loading} to="/admin/audit"
            value={stat('audit_events_24h', 'recent_audit_count')} />
        </div>
      </section>

      <section aria-label="Admin shortcuts" className="mt-7">
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-ink-500">
          Administration
        </h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { to: '/admin/identity', label: 'Identity', icon: Users, description: 'Accounts, roles, policies' },
            { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound, description: 'Approve, deny, revoke' },
            { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList, description: 'Events, recordings, reports' },
            { to: '/admin/vault-ops', label: 'Vault Operations', icon: Vault, description: 'Backup and restore' },
          ].map((l) => (
            <Link key={l.to} to={l.to} className="group">
              <Card className="flex h-full items-start justify-between gap-3 p-4 transition-[border-color,box-shadow] hover:border-brand-500/50 hover:shadow-sm">
                <span className="min-w-0">
                  <span className="flex items-center gap-2 text-sm font-medium text-ink-50">
                    <l.icon className="h-4 w-4 flex-none text-ink-400" aria-hidden="true" />
                    {l.label}
                  </span>
                  <span className="mt-1 block text-xs text-ink-500">{l.description}</span>
                </span>
                <ArrowRight
                  className="h-4 w-4 flex-none text-ink-600 transition-transform group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </>
  )
}

/* -------------------------------------------------------------------------
 * Self-service view
 * ---------------------------------------------------------------------- */

function GrantCountdown({ expiresAt }) {
  const { remainingSec, expired, unknown } = useCountdown(expiresAt)
  if (unknown) return <span className="text-ink-500">—</span>
  if (expired) return <span className="text-ink-500">Expired</span>
  const urgent = remainingSec < 300
  return (
    <span
      className={
        'inline-flex items-center gap-1.5 text-xs font-medium tabular-nums ' +
        (urgent ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400')
      }
    >
      <Clock className="h-3.5 w-3.5" aria-hidden="true" />
      {formatDuration(remainingSec)} left
    </span>
  )
}

function UserDashboard({ user }) {
  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMyGrants({ activeOnly: true, pageSize: 5, signal }),
  })
  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', 'mine', { status: JIT_STATUS.PENDING, dashboard: true }],
    queryFn: ({ signal }) => listMyJitRequests({ status: JIT_STATUS.PENDING, pageSize: 5, signal }),
  })
  const sessionsQuery = useQuery({
    queryKey: ['sessions', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMySessions({ activeOnly: true, pageSize: 5, signal }),
  })

  const grants = grantsQuery.data?.grants || []
  const requests = requestsQuery.data?.requests || []

  return (
    <>
      <PageHeader
        title={`Welcome${user?.username ? `, ${user.username}` : ''}`}
        description="Your active access, pending requests and live sessions at a glance."
        actions={
          <Link to="/jit">
            <Button variant="primary" icon={KeyRound}>
              Request access
            </Button>
          </Link>
        }
      />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard label="Active grants" icon={Lock} tone="emerald" to="/jit"
          loading={grantsQuery.isLoading}
          value={grantsQuery.data?.pagination?.total ?? grants.length} />
        <StatCard label="Pending requests" icon={KeyRound} tone="amber" to="/jit"
          loading={requestsQuery.isLoading}
          attention={(requestsQuery.data?.pagination?.total ?? requests.length) > 0}
          value={requestsQuery.data?.pagination?.total ?? requests.length} />
        <StatCard label="Active sessions" icon={Activity} to="/sessions"
          loading={sessionsQuery.isLoading}
          value={sessionsQuery.data?.pagination?.total ?? sessionsQuery.data?.sessions?.length ?? 0} />
      </div>

      <div className="mt-7 grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Access expiring soon"
            actions={
              <Link to="/jit" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-400">
                View all
              </Link>
            }
          />
          <QueryState
            query={grantsQuery}
            skeleton={<TableSkeleton rows={3} cols={2} />}
            empty={(d) => (d?.grants || []).length === 0}
            emptyState={
              <EmptyState
                compact
                icon={Lock}
                title="No active access"
                description="You don't currently hold any time-boxed grants."
                action={
                  <Link to="/jit">
                    <Button size="sm" variant="secondary" icon={KeyRound}>
                      Request access
                    </Button>
                  </Link>
                }
              />
            }
          >
            {(data) => (
              <Table>
                <TBody>
                  {(data.grants || []).map((g) => (
                    <TR key={entityId(g)}>
                      <TD>
                        <CellStack
                          primary={resourceLabel(g)}
                          secondary={`Granted ${formatRelativeToNow(g.created_at)}`}
                        />
                      </TD>
                      <TD align="right">
                        <GrantCountdown expiresAt={g.expires_at} />
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            )}
          </QueryState>
        </Card>

        <Card>
          <CardHeader
            title="Awaiting approval"
            actions={
              <Link to="/jit" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-400">
                View all
              </Link>
            }
          />
          <QueryState
            query={requestsQuery}
            skeleton={<TableSkeleton rows={3} cols={2} />}
            empty={(d) => (d?.requests || []).length === 0}
            emptyState={
              <EmptyState
                compact
                icon={KeyRound}
                title="Nothing pending"
                description="You have no requests waiting on an approver."
              />
            }
          >
            {(data) => (
              <Table>
                <TBody>
                  {(data.requests || []).map((r) => {
                    const id = entityId(r)
                    return (
                      <TR key={id}>
                        <TD className="p-0">
                          <Link to={id ? `/jit/requests/${id}` : '/jit'} className="block px-4 py-3">
                            <CellStack
                              primary={resourceLabel(r)}
                              secondary={`Requested ${formatDateTime(r.created_at)}`}
                            />
                          </Link>
                        </TD>
                        <TD align="right">
                          <Badge className={JIT_STATUS_BADGE[r.status]}>
                            {JIT_STATUS_LABELS[r.status] || r.status}
                          </Badge>
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
            )}
          </QueryState>
        </Card>
      </div>

      <section aria-label="Shortcuts" className="mt-7">
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-ink-500">Go to</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {QUICK_LINKS.map((l) => (
            <Link key={l.to} to={l.to} className="group">
              <Card className="flex h-full items-center justify-between gap-3 p-4 transition-[border-color,box-shadow] hover:border-brand-500/50 hover:shadow-sm">
                <span className="flex min-w-0 items-center gap-3">
                  <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400">
                    <l.icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium text-ink-50">{l.label}</span>
                    <span className="block truncate text-xs text-ink-500">{l.description}</span>
                  </span>
                </span>
                <ArrowRight
                  className="h-4 w-4 flex-none text-ink-600 transition-transform group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </>
  )
}

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  useDocumentTitle('Dashboard')
  return isAdmin ? <AdminDashboard /> : <UserDashboard user={user} />
}
