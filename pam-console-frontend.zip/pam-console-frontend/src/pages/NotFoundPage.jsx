import { Link } from 'react-router-dom'
import { Compass } from 'lucide-react'
import { Button } from '../ui'

export default function NotFoundPage() {
  return (
    <div className="flex min-h-[55vh] flex-col items-center justify-center gap-4 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-surface-800 text-ink-400">
        <Compass className="h-6 w-6" aria-hidden="true" />
      </span>
      <div>
        <h1 className="text-lg font-semibold text-ink-50">Page not found</h1>
        <p className="mt-1.5 max-w-sm text-sm text-ink-400">
          This page doesn&apos;t exist, or you don&apos;t have access to it.
        </p>
      </div>
      {/* FIX: previously labelled "Back to Resources" while linking to "/",
          which is the Dashboard. Label and destination now agree. */}
      <Link to="/">
        <Button variant="primary">Back to dashboard</Button>
      </Link>
    </div>
  )
}
