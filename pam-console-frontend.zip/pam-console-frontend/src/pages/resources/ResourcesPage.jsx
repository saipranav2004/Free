import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight, Boxes, ShieldAlert } from 'lucide-react'
import { listResourceGroups } from '../../api/resources'
import { useAuthStore } from '../../store/authStore'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId } from '../../lib/entity'
import { ResourceTypeTile } from '../../components/resources/ResourceTypeIcon'
import { CreateResourceModal } from '../../components/resources/CreateResourceModal'
import {
  PageHeader, Card, CardHeader, Button, Badge, QueryState, TableSkeleton,
  EmptyState, NoResultsState, SearchInput, FilterSelect, Toolbar,
  Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'
import { RESOURCE_TYPES } from '../../config/constants'

export default function ResourcesPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const isAdmin = useAuthStore((s) => s.isAdmin())
  useDocumentTitle('Resources')

  const groupsQuery = useQuery({
    queryKey: ['resources', 'groups'],
    queryFn: ({ signal }) => listResourceGroups(signal),
  })

  // Filtering happens client-side against the already-fetched group payload.
  // The endpoint returns the full catalogue in one call, so a round trip per
  // keystroke would add latency for no benefit.
  const filteredGroups = useMemo(() => {
    const groups = groupsQuery.data || []
    const term = search.trim().toLowerCase()
    return groups
      .map((group) => ({
        ...group,
        resources: (group.resources || []).filter((r) => {
          if (typeFilter && r.resource_type !== typeFilter) return false
          if (!term) return true
          return [r.name, r.host, r.database_name, r.resource_type, r.description]
            .filter(Boolean)
            .some((v) => String(v).toLowerCase().includes(term))
        }),
      }))
      .filter((g) => g.resources.length > 0)
  }, [groupsQuery.data, search, typeFilter])

  const totalShown = filteredGroups.reduce((n, g) => n + g.resources.length, 0)
  const hasFilters = Boolean(search || typeFilter)
  const clearFilters = () => {
    setSearch('')
    setTypeFilter('')
  }

  return (
    <div>
      <PageHeader
        title="Resources"
        description="Systems PAM manages or brokers access to. Connect opens through the desktop agent, or your browser when the agent isn't available."
        actions={
          isAdmin && (
            <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
              Register resource
            </Button>
          )
        }
      />

      <Toolbar className="mb-4">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by name, host or database…"
          className="w-full max-w-xs"
        />
        <FilterSelect
          label="Type"
          value={typeFilter}
          onChange={setTypeFilter}
          options={RESOURCE_TYPES}
          allLabel="All types"
        />
        {hasFilters && (
          <Button size="sm" variant="ghost" onClick={clearFilters}>
            Clear
          </Button>
        )}
        <span className="ml-auto text-xs tabular-nums text-ink-500">
          {totalShown} {totalShown === 1 ? 'resource' : 'resources'}
        </span>
      </Toolbar>

      <QueryState
        query={groupsQuery}
        skeleton={
          <Card>
            <TableSkeleton rows={6} cols={4} />
          </Card>
        }
        empty={(groups) => !groups || groups.length === 0}
        emptyState={
          <Card>
            <EmptyState
              icon={Boxes}
              title="No resources registered"
              description="Register the first system for PAM to broker access to."
              action={
                isAdmin && (
                  <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
                    Register resource
                  </Button>
                )
              }
            />
          </Card>
        }
      >
        {() =>
          filteredGroups.length === 0 ? (
            <Card>
              <NoResultsState onClear={clearFilters} />
            </Card>
          ) : (
            <div className="space-y-5">
              {filteredGroups.map((group) => (
                <Card key={group.name}>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      {group.icon && (
                        <span aria-hidden="true" className="text-base leading-none">
                          {group.icon}
                        </span>
                      )}
                      <h3 className="text-sm font-semibold text-ink-50">{group.name}</h3>
                      <span className="rounded-full bg-surface-800 px-1.5 py-px text-2xs font-medium tabular-nums text-ink-400">
                        {group.resources.length}
                      </span>
                    </div>
                  </CardHeader>

                  <Table>
                    <THead>
                      <tr>
                        <TH>Resource</TH>
                        <TH className="hidden md:table-cell">Type</TH>
                        <TH align="right">Access</TH>
                        <TH width="44" />
                      </tr>
                    </THead>
                    <TBody>
                      {group.resources.map((r) => {
                        const id = entityId(r)
                        return (
                          <TR key={id || r.name} interactive>
                            <TD className="p-0">
                              <Link
                                to={id ? `/resources/${id}` : '#'}
                                className="flex items-center px-4 py-3"
                              >
                                <CellStack
                                  icon={<ResourceTypeTile type={r.resource_type} />}
                                  primary={r.name}
                                  secondary={`${r.host}:${r.port}${r.database_name ? ` · ${r.database_name}` : ''}`}
                                />
                              </Link>
                            </TD>
                            <TD className="hidden md:table-cell">
                              <span className="text-xs text-ink-400">{r.resource_type}</span>
                            </TD>
                            <TD align="right">
                              <div className="flex flex-wrap items-center justify-end gap-1.5">
                                {r.requires_jit && (
                                  <Badge tone="warning" icon={ShieldAlert}>
                                    JIT-gated
                                  </Badge>
                                )}
                                {!r.is_active && <Badge tone="neutral">Inactive</Badge>}
                                {!r.requires_jit && r.is_active && (
                                  <Badge tone="success">Standing</Badge>
                                )}
                              </div>
                            </TD>
                            <TD align="right">
                              <ChevronRight className="h-4 w-4 text-ink-600" aria-hidden="true" />
                            </TD>
                          </TR>
                        )
                      })}
                    </TBody>
                  </Table>
                </Card>
              ))}
            </div>
          )
        }
      </QueryState>

      {isAdmin && <CreateResourceModal open={createOpen} onClose={() => setCreateOpen(false)} />}
    </div>
  )
}
