import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate, useParams } from 'react-router-dom'
import { KeyRound, RefreshCw, Trash2, ShieldAlert, Video, Plug } from 'lucide-react'
import { toast } from 'sonner'
import { getResource } from '../../api/resources'
import { deleteResource, storeResourceCredential, rotateResourceCredential } from '../../api/adminResources'
import { useAuthStore } from '../../store/authStore'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { CREDENTIAL_TYPES } from '../../config/constants'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { isUsableId } from '../../lib/entity'
import { ResourceTypeTile } from '../../components/resources/ResourceTypeIcon'
import { ConnectPanel } from '../../components/resources/ConnectPanel'
import {
  PageHeader, Card, CardHeader, CardBody, Button, Badge, QueryState, CardSkeleton,
  ConfirmDialog, Field, Input, Select, Textarea, DescriptionList, DescriptionItem,
  ErrorState, Callout,
} from '../../ui'

/**
 * Resource-attached credential form.
 * ===========================================================================
 * BUG FIX — storing a credential always failed with
 *     "AccountName is required", "Credential is required"
 *
 * Those are Go struct field names, which Gin's validator reports when a
 * `binding:"required"` rule fails. The handler binds `account_name` and
 * `credential`; this form was posting `username` and `secret`, so both
 * required fields were absent on every submission and the request could
 * never succeed regardless of what the operator typed.
 *
 * The payload mapping now lives in api/adminResources.js (one place, with
 * the reasoning recorded). This form is corrected in two further ways:
 *
 *   - "Account name" is now a required field with its own validation, so the
 *     requirement is visible before submitting rather than discovered from a
 *     server error. It was previously labelled "Username" and marked
 *     optional, which actively led operators to leave it blank.
 *   - Server-side field errors are mapped back onto the matching inputs, so
 *     if the contract ever shifts again the operator sees which field the
 *     server rejected instead of an opaque toast.
 */
const storeSchema = z.object({
  credential_type: z.string().min(1, 'Select a credential type'),
  account_name: z.string().trim().min(1, 'Required — the account this credential signs in as'),
  credential: z.string().trim().min(1, 'Required'),
})

const rotateSchema = z.object({
  credential: z.string().trim().min(1, 'Required'),
})

function CredentialForm({ resourceId, hasCredential }) {
  const queryClient = useQueryClient()
  const [mode, setMode] = useState(null) // null | 'store' | 'rotate'

  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(mode === 'rotate' ? rotateSchema : storeSchema),
    defaultValues: { credential_type: 'password', account_name: '', credential: '' },
  })

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['resources', resourceId] })
    queryClient.invalidateQueries({ queryKey: ['resources', resourceId, 'connect-info'] })
  }

  const storeMutation = useMutation({
    mutationFn: (values) =>
      storeResourceCredential(resourceId, {
        accountName: values.account_name,
        credential: values.credential,
        credentialType: values.credential_type,
      }),
    onSuccess: () => {
      toast.success('Credential stored', { description: 'Encrypted at rest and ready for connections.' })
      invalidate()
      reset()
      setMode(null)
    },
    onError: (err) => {
      // Map "AccountName"/"Credential" style server errors back onto the
      // matching inputs. See lib/apiError.js applyServerFieldErrors.
      const mapped = applyServerFieldErrors(err, setError, {
        AccountName: 'account_name',
        Credential: 'credential',
        CredentialType: 'credential_type',
      })
      if (!mapped) toast.error('Could not store credential', { description: apiErrorMessage(err) })
    },
  })

  const rotateMutation = useMutation({
    mutationFn: (values) => rotateResourceCredential(resourceId, values.credential),
    onSuccess: () => {
      toast.success('Credential rotated')
      invalidate()
      reset()
      setMode(null)
    },
    onError: (err) => toast.error('Could not rotate credential', { description: apiErrorMessage(err) }),
  })

  const active = mode === 'rotate' ? rotateMutation : storeMutation

  if (!mode) {
    return (
      <div className="flex flex-wrap gap-2">
        <Button
          size="sm"
          variant="secondary"
          icon={KeyRound}
          onClick={() => {
            reset({ credential_type: 'password', account_name: '', credential: '' })
            setMode('store')
          }}
        >
          {hasCredential ? 'Replace credential' : 'Store credential'}
        </Button>
        {hasCredential && (
          <Button
            size="sm"
            variant="secondary"
            icon={RefreshCw}
            onClick={() => {
              reset({ credential: '' })
              setMode('rotate')
            }}
          >
            Rotate now
          </Button>
        )}
      </div>
    )
  }

  const submit = handleSubmit((values) => active.mutate(values))

  return (
    <form
      onSubmit={submit}
      noValidate
      className="space-y-3.5 rounded-lg border border-surface-700 bg-surface-850 p-4"
    >
      <p className="text-xs font-semibold uppercase tracking-wider text-ink-400">
        {mode === 'rotate' ? 'Rotate credential' : 'Store credential'}
      </p>

      {mode === 'store' && (
        <>
          <Field label="Credential type" error={errors.credential_type?.message} required>
            {({ id, ...a11y }) => (
              <Select id={id} {...a11y} size="sm" error={!!errors.credential_type} {...register('credential_type')}>
                {CREDENTIAL_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </Select>
            )}
          </Field>

          <Field
            label="Account name"
            error={errors.account_name?.message}
            hint="The account this credential authenticates as, e.g. svc_reporting."
            required
          >
            {({ id, ...a11y }) => (
              <Input id={id} {...a11y} size="sm" error={!!errors.account_name} placeholder="svc_reporting" {...register('account_name')} />
            )}
          </Field>
        </>
      )}

      <Field
        label={mode === 'rotate' ? 'New secret' : 'Secret'}
        error={errors.credential?.message}
        hint="Encrypted with envelope encryption before storage. Never returned to the browser."
        required
      >
        {({ id, ...a11y }) => (
          <Textarea
            id={id}
            {...a11y}
            rows={2}
            className="font-mono text-xs"
            error={!!errors.credential}
            placeholder={mode === 'rotate' ? 'New password or key value' : 'Password or key value'}
            {...register('credential')}
          />
        )}
      </Field>

      <div className="flex justify-end gap-2">
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            reset()
            setMode(null)
          }}
          disabled={active.isPending}
        >
          Cancel
        </Button>
        <Button size="sm" variant="primary" type="submit" loading={active.isPending} onClick={submit}>
          {mode === 'rotate' ? 'Rotate' : 'Store credential'}
        </Button>
      </div>
    </form>
  )
}

export default function ResourceDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false)

  const resourceQuery = useQuery({
    queryKey: ['resources', id],
    queryFn: ({ signal }) => getResource(id, signal),
    enabled: isUsableId(id),
  })

  useDocumentTitle(resourceQuery.data?.name || 'Resource')

  const deleteMutation = useMutation({
    mutationFn: () => deleteResource(id),
    onSuccess: () => {
      toast.success('Resource deleted')
      queryClient.invalidateQueries({ queryKey: ['resources'] })
      navigate('/resources')
    },
    onError: (err) => {
      toast.error('Could not delete resource', { description: apiErrorMessage(err) })
      setConfirmDeleteOpen(false)
    },
  })

  // Guard against a malformed link producing a request for a resource
  // literally named "undefined".
  if (!isUsableId(id)) {
    return (
      <div>
        <PageHeader
          title="Resource"
          breadcrumbs={[{ label: 'Resources', to: '/resources' }, { label: 'Unknown' }]}
        />
        <Card>
          <ErrorState
            title="This link is missing a resource id"
            error={{ response: { data: { error: 'Return to the catalogue and open the resource again.' } } }}
            onRetry={() => navigate('/resources')}
          />
        </Card>
      </div>
    )
  }

  return (
    <div>
      <QueryState query={resourceQuery} skeleton={<CardSkeleton lines={6} />}>
        {(resource) => (
          <>
            <PageHeader
              breadcrumbs={[{ label: 'Resources', to: '/resources' }, { label: resource.name }]}
              title={
                <>
                  <ResourceTypeTile type={resource.resource_type} size="lg" />
                  <span className="truncate">{resource.name}</span>
                </>
              }
              description={resource.description || `${resource.host}:${resource.port}`}
              meta={
                <>
                  {resource.requires_jit ? (
                    <Badge tone="warning" icon={ShieldAlert}>
                      JIT-gated
                    </Badge>
                  ) : (
                    <Badge tone="success">Standing access</Badge>
                  )}
                  {resource.always_record && (
                    <Badge tone="brand" icon={Video}>
                      Always recorded
                    </Badge>
                  )}
                  <Badge tone={resource.is_active ? 'success' : 'neutral'}>
                    {resource.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </>
              }
              actions={
                isAdmin && (
                  <Button variant="dangerOutline" icon={Trash2} onClick={() => setConfirmDeleteOpen(true)}>
                    Delete
                  </Button>
                )
              }
            />

            <div className="grid gap-5 lg:grid-cols-5">
              {/* Connect is the primary job on this page, so it leads and
                  takes the wider column — the previous 50/50 split buried it
                  next to static metadata. */}
              <Card className="lg:col-span-3">
                <CardHeader
                  title="Connect"
                  description="Desktop agent first, browser fallback."
                />
                <CardBody>
                  <ConnectPanel resourceId={id} resource={resource} />
                </CardBody>
              </Card>

              <div className="space-y-5 lg:col-span-2">
                <Card>
                  <CardHeader title="Details" />
                  <CardBody>
                    <DescriptionList cols="110px 1fr">
                      <DescriptionItem label="Type">{resource.resource_type}</DescriptionItem>
                      <DescriptionItem label="Host" mono>
                        {resource.host}
                      </DescriptionItem>
                      <DescriptionItem label="Port" mono>
                        {resource.port}
                      </DescriptionItem>
                      {resource.database_name && (
                        <DescriptionItem label="Database" mono>
                          {resource.database_name}
                        </DescriptionItem>
                      )}
                      <DescriptionItem label="Connect mode">
                        {resource.connect_mode || 'web_terminal'}
                      </DescriptionItem>
                    </DescriptionList>
                  </CardBody>
                </Card>

                {isAdmin && (
                  <Card>
                    <CardHeader
                      title="Credential"
                      description={
                        resource.has_credential
                          ? 'A credential is stored for this resource.'
                          : 'No credential stored yet.'
                      }
                    />
                    <CardBody className="space-y-3">
                      {!resource.has_credential && (
                        <Callout tone="neutral" icon={Plug}>
                          Store a credential so the desktop agent can inject it on connect.
                        </Callout>
                      )}
                      <CredentialForm resourceId={id} hasCredential={resource.has_credential} />
                    </CardBody>
                  </Card>
                )}
              </div>
            </div>

            {isAdmin && (
              <ConfirmDialog
                open={confirmDeleteOpen}
                title={`Delete "${resource.name}"?`}
                description="This removes the resource registration. Stored credentials and history remain in the audit trail."
                confirmLabel="Delete resource"
                destructive
                confirmPhrase={resource.name}
                isLoading={deleteMutation.isPending}
                onConfirm={() => deleteMutation.mutate()}
                onCancel={() => setConfirmDeleteOpen(false)}
              />
            )}
          </>
        )}
      </QueryState>
    </div>
  )
}
