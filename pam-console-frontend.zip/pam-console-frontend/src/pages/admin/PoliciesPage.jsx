import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Plus, FileCode2, Trash2 } from 'lucide-react'
import { listPolicies, deletePolicy } from '../../api/rbac'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId } from '../../lib/entity'
import { apiErrorMessage } from '../../lib/apiError'
import { CreatePolicyModal } from '../../components/admin/CreatePolicyModal'
import {
  PageHeader, Card, CardToolbar, Button, Badge, QueryState, TableSkeleton,
  EmptyState, NoResultsState, SearchInput, FilterSelect, ConfirmDialog, Callout,
  Table, THead, TH, TBody, TR, TD,
} from '../../ui'
import { POLICY_EFFECT_BADGE, POLICY_EFFECTS } from '../../config/constants'

export default function PoliciesPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [search, setSearch] = useState('')
  const [effect, setEffect] = useState('')
  const queryClient = useQueryClient()
  useDocumentTitle('Policies')

  const policiesQuery = useQuery({
    queryKey: ['rbac', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
  })

  const filtered = useMemo(() => {
    const list = policiesQuery.data || []
    const term = search.trim().toLowerCase()
    return list.filter((p) => {
      if (effect && p.effect !== effect) return false
      if (!term) return true
      const haystack = [p.name, p.description, p.resource_pattern, ...(p.actions || [])]
      return haystack.filter(Boolean).some((v) => String(v).toLowerCase().includes(term))
    })
  }, [policiesQuery.data, search, effect])

  const deleteMutation = useMutation({
    mutationFn: (id) => deletePolicy(id),
    onSuccess: () => {
      toast.success('Policy deleted')
      setDeleteTarget(null)
      queryClient.invalidateQueries({ queryKey: ['rbac'] })
    },
    onError: (err) => {
      toast.error('Could not delete policy', { description: apiErrorMessage(err) })
      setDeleteTarget(null)
    },
  })

  const hasFilters = Boolean(search || effect)

  return (
    <div>
      <PageHeader
        breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'Policies' }]}
        title="Policies"
        description="PBAC — each policy allows or denies a set of actions against a resource pattern. Deny always wins."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create policy
          </Button>
        }
      />

      <Card>
        <CardToolbar>
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search name, action or pattern…"
            className="w-full max-w-sm"
          />
          <FilterSelect
            label="Effect"
            value={effect}
            onChange={setEffect}
            options={POLICY_EFFECTS}
            allLabel="Allow and deny"
          />
          {hasFilters && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setSearch('')
                setEffect('')
              }}
            >
              Clear
            </Button>
          )}
          <span className="ml-auto text-xs tabular-nums text-ink-500">{filtered.length} policies</span>
        </CardToolbar>

        <QueryState
          query={policiesQuery}
          skeleton={<TableSkeleton rows={6} cols={4} />}
          empty={(d) => !d || d.length === 0}
          emptyState={
            <EmptyState
              icon={FileCode2}
              title="No policies yet"
              description="Create a policy to define what an action against a resource is permitted to do."
              action={
                <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
                  Create policy
                </Button>
              }
            />
          }
        >
          {() =>
            filtered.length === 0 ? (
              <NoResultsState
                onClear={() => {
                  setSearch('')
                  setEffect('')
                }}
              />
            ) : (
              <Table>
                <THead>
                  <tr>
                    <TH>Policy</TH>
                    <TH className="hidden lg:table-cell">Actions</TH>
                    <TH className="hidden md:table-cell">Resource pattern</TH>
                    <TH align="right">Effect</TH>
                    <TH align="right" width="90" />
                  </tr>
                </THead>
                <TBody>
                  {filtered.map((p) => {
                    const pid = entityId(p)
                    const actions = p.actions || []
                    return (
                      <TR key={pid}>
                        <TD>
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-ink-50">{p.name}</p>
                            <p className="truncate text-xs text-ink-500">{p.description || 'No description'}</p>
                          </div>
                        </TD>
                        <TD className="hidden lg:table-cell">
                          <div className="flex flex-wrap gap-1">
                            {actions.length === 0 ? (
                              <span className="text-xs text-amber-600 dark:text-amber-400">
                                No actions — matches nothing
                              </span>
                            ) : (
                              <>
                                {actions.slice(0, 3).map((a) => (
                                  <code
                                    key={a}
                                    className="rounded border border-surface-700 bg-surface-850 px-1.5 py-0.5 font-mono text-2xs text-ink-300"
                                  >
                                    {a}
                                  </code>
                                ))}
                                {actions.length > 3 && (
                                  <span
                                    className="text-2xs text-ink-500"
                                    title={actions.slice(3).join('\n')}
                                  >
                                    +{actions.length - 3} more
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                        </TD>
                        <TD className="hidden md:table-cell">
                          <code className="font-mono text-xs text-ink-300">{p.resource_pattern || '*'}</code>
                        </TD>
                        <TD align="right">
                          <Badge className={POLICY_EFFECT_BADGE[p.effect]}>{p.effect}</Badge>
                        </TD>
                        <TD align="right">
                          <Button
                            size="xs"
                            variant="dangerOutline"
                            icon={Trash2}
                            onClick={() => setDeleteTarget(p)}
                          >
                            Delete
                          </Button>
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
            )
          }
        </QueryState>
      </Card>

      <Callout tone="neutral" className="mt-4" title="Evaluation order">
        A user's effective permissions are the union of the policies attached to their roles and any
        policies attached to them directly. A matching deny overrides any allow.
      </Callout>

      <CreatePolicyModal open={createOpen} onClose={() => setCreateOpen(false)} />

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete the policy "${deleteTarget?.name}"?`}
        description="Every role and user this policy is attached to loses the access it granted, immediately."
        confirmLabel="Delete policy"
        destructive
        confirmPhrase={deleteTarget?.name}
        isLoading={deleteMutation.isPending}
        onConfirm={() => deleteMutation.mutate(entityId(deleteTarget))}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  )
}
