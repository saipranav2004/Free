import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  Users, Shield, FileCode2, KeyRound, Radio, ShieldAlert, ScrollText,
  Inbox, ArrowRight, Archive, Clock,
} from 'lucide-react'
import { getStats, listJitRequests, listSessions, listBreakglass } from '../../api/admin'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId, requesterLabel, resourceLabel, actorLabel } from '../../lib/entity'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import {
  PageHeader, Card, CardHeader, Badge, StatCard, StatusDot, QueryState,
  TableSkeleton, EmptyState, Table, TBody, TR, TD, CellStack,
} from '../../ui'
import {
  JIT_ACTIONABLE_STATUSES, JIT_STATUS_LABELS, JIT_STATUS_BADGE, JIT_POLL_MS,
} from '../../config/constants'

// Same explicit-status contract as the dedicated approvals page. The
// Overview previously sent status=PENDING while the JIT page sent nothing,
// which is what made the two screens disagree about whether any requests
// existed at all.
function statusParams(statuses) {
  const list = statuses.filter(Boolean)
  if (list.length === 0) return {}
  return { status: list.length === 1 ? list[0] : list, statuses: list.join(',') }
}

/** A Link styled as a ghost button. `Button` renders a real <button>, and
 *  nesting one inside an <a> is invalid HTML, so this borrows the styling
 *  rather than the component. */
function SectionLink({ to, children }) {
  return (
    <Link
      to={to}
      className="inline-flex h-8 select-none items-center gap-1.5 whitespace-nowrap rounded-md px-3 text-xs font-medium text-ink-300 transition-colors hover:bg-surface-800 hover:text-ink-50"
    >
      {children}
      <ArrowRight className="h-3.5 w-3.5 flex-none" aria-hidden="true" />
    </Link>
  )
}

export default function AdminOverviewPage() {
  useDocumentTitle('Admin')

  const statsQuery = useQuery({
    queryKey: ['admin', 'stats'],
    queryFn: ({ signal }) => getStats(signal),
    refetchInterval: JIT_POLL_MS,
  })

  const queueQuery = useQuery({
    queryKey: ['admin', 'jit-requests', 'overview'],
    queryFn: ({ signal }) =>
      listJitRequests({ page: 1, page_size: 5, ...statusParams(JIT_ACTIONABLE_STATUSES) }, signal),
    refetchInterval: JIT_POLL_MS,
  })

  const sessionsQuery = useQuery({
    queryKey: ['admin', 'sessions', 'overview'],
    queryFn: ({ signal }) => listSessions({ page: 1, page_size: 5, active: 'true' }, signal),
    refetchInterval: JIT_POLL_MS,
  })

  const breakglassQuery = useQuery({
    queryKey: ['admin', 'breakglass', 'overview'],
    queryFn: ({ signal }) => listBreakglass({ page: 1, page_size: 5 }, signal),
    retry: false,
  })

  const stats = statsQuery.data || {}
  const pendingCount =
    queueQuery.data?.pagination?.total ?? (queueQuery.data?.requests || []).length
  const activeSessionCount =
    sessionsQuery.data?.pagination?.total ?? (sessionsQuery.data?.sessions || []).length
  const breakglassRequests = breakglassQuery.data?.requests || []

  return (
    <div>
      <PageHeader
        title="Admin Center"
        description="Approvals, active access and organization-wide oversight."
      />

      {/* Attention first: the things an administrator is on the hook for. */}
      <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Awaiting a decision"
          value={pendingCount}
          icon={Inbox}
          tone={pendingCount > 0 ? 'warning' : 'default'}
          attention={pendingCount > 0}
          loading={queueQuery.isLoading}
          hint="JIT requests you can approve or deny"
          to="/admin/jit"
        />
        <StatCard
          label="Active sessions"
          value={activeSessionCount}
          icon={Radio}
          loading={sessionsQuery.isLoading}
          hint="Tracked connections in progress"
          to="/sessions"
        />
        <StatCard
          label="Break-glass (recent)"
          value={breakglassRequests.length}
          icon={ShieldAlert}
          tone={breakglassRequests.length > 0 ? 'danger' : 'default'}
          attention={breakglassRequests.length > 0}
          loading={breakglassQuery.isLoading}
          hint="Emergency access raised"
        />
        <StatCard
          label="Users"
          value={stats.total_users ?? stats.users ?? '—'}
          icon={Users}
          loading={statsQuery.isLoading}
          hint="Accounts in this organization"
          to="/admin/identity"
        />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Approval queue"
            description="Requests still waiting on a decision"
            actions={<SectionLink to="/admin/jit">Open queue</SectionLink>}
          />
          <QueryState
            query={queueQuery}
            skeleton={<TableSkeleton rows={4} cols={3} />}
            empty={(d) => (d?.requests || []).length === 0}
            emptyState={
              <EmptyState
                compact
                icon={Inbox}
                title="Nothing waiting"
                description="Every access request has been decided."
              />
            }
          >
            {(data) => (
              <Table>
                <TBody>
                  {(data.requests || []).map((r) => {
                    const id = entityId(r)
                    return (
                      <TR key={id} interactive>
                        <TD className="p-0">
                          <Link to="/admin/jit" className="flex items-center px-4 py-3">
                            <CellStack
                              icon={
                                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-800 text-ink-400">
                                  {r.type === 'BREAKGLASS' ? (
                                    <ShieldAlert className="h-4 w-4 text-red-500" aria-hidden="true" />
                                  ) : (
                                    <KeyRound className="h-4 w-4" aria-hidden="true" />
                                  )}
                                </span>
                              }
                              primary={`${requesterLabel(r)} → ${resourceLabel(r)}`}
                              secondary={r.reason || 'No reason recorded'}
                            />
                          </Link>
                        </TD>
                        <TD align="right">
                          <Badge className={JIT_STATUS_BADGE[r.status]}>
                            {JIT_STATUS_LABELS[r.status] || r.status}
                          </Badge>
                          <span className="mt-1 block text-2xs text-ink-500">
                            {formatRelativeToNow(r.created_at)}
                          </span>
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
            )}
          </QueryState>
        </Card>

        <Card>
          <CardHeader
            title="Active sessions"
            description="Connections currently in progress"
            actions={<SectionLink to="/sessions">Open sessions</SectionLink>}
          />
          <QueryState
            query={sessionsQuery}
            skeleton={<TableSkeleton rows={4} cols={3} />}
            empty={(d) => (d?.sessions || []).length === 0}
            emptyState={
              <EmptyState compact icon={Radio} title="No active sessions" description="Nothing is connected right now." />
            }
          >
            {(data) => (
              <Table>
                <TBody>
                  {(data.sessions || []).map((s) => (
                    <TR key={entityId(s)}>
                      <TD>
                        <CellStack
                          primary={`${actorLabel(s)} → ${resourceLabel(s)}`}
                          secondary={
                            <span title={formatDateTime(s.started_at, { seconds: true })}>
                              Started {formatRelativeToNow(s.started_at)}
                            </span>
                          }
                        />
                      </TD>
                      <TD align="right">
                        <StatusDot tone="success" label="Active" pulse />
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            )}
          </QueryState>
        </Card>

        {breakglassRequests.length > 0 && (
          <Card className="border-red-200 dark:border-red-900/40 lg:col-span-2">
            <CardHeader
              title="Break-glass activity"
              description="Emergency access that bypassed the normal approval path — every one requires after-the-fact review"
            />
            <Table>
              <TBody>
                {breakglassRequests.map((r) => (
                  <TR key={entityId(r)}>
                    <TD>
                      <CellStack
                        icon={
                          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400">
                            <ShieldAlert className="h-4 w-4" aria-hidden="true" />
                          </span>
                        }
                        primary={`${requesterLabel(r)} → ${resourceLabel(r)}`}
                        secondary={r.reason || 'No reason recorded'}
                      />
                    </TD>
                    <TD align="right">
                      <Badge className={JIT_STATUS_BADGE[r.status]}>
                        {JIT_STATUS_LABELS[r.status] || r.status}
                      </Badge>
                      <span className="mt-1 flex items-center justify-end gap-1 text-2xs text-ink-500">
                        <Clock className="h-3 w-3" aria-hidden="true" />
                        {formatRelativeToNow(r.created_at)}
                      </span>
                    </TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          </Card>
        )}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { to: '/admin/identity', icon: Users, title: 'Identity', body: 'Accounts, lifecycle status and access assignment.' },
          { to: '/admin/roles', icon: Shield, title: 'Roles', body: 'Bundle policies into roles you assign to users.' },
          { to: '/admin/policies', icon: FileCode2, title: 'Policies', body: 'Define what actions are allowed or denied.' },
          { to: '/admin/audit', icon: ScrollText, title: 'Audit', body: 'Organization-wide trail and compliance reports.' },
          { to: '/admin/vault-ops', icon: Archive, title: 'Vault operations', body: 'Whole-vault backup and restore.' },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="group rounded-card border border-surface-700 bg-surface-900 p-4 shadow-card transition-colors hover:border-brand-500/60 hover:bg-surface-875"
          >
            <span className="mb-2.5 flex h-9 w-9 items-center justify-center rounded-lg bg-surface-800 text-ink-400 transition-colors group-hover:bg-brand-50 group-hover:text-brand-600 dark:group-hover:bg-brand-500/15 dark:group-hover:text-brand-400">
              <item.icon className="h-4 w-4" aria-hidden="true" />
            </span>
            <p className="text-sm font-semibold text-ink-50">{item.title}</p>
            <p className="mt-0.5 text-xs leading-relaxed text-ink-400">{item.body}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
