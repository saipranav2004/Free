import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { BackupRestorePanel } from '../../components/vault/BackupRestorePanel'
import { PageHeader, Callout } from '../../ui'
import { ShieldAlert } from 'lucide-react'

export default function AdminVaultOpsPage() {
  useDocumentTitle('Vault operations')

  return (
    <div>
      <PageHeader
        breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'Vault operations' }]}
        title="Vault operations"
        description="Infrastructure-level operations on the credential vault itself, separate from day-to-day credential management."
      />

      <Callout tone="warning" icon={ShieldAlert} className="mb-5" title="Highest blast radius in the console">
        These operations act on the entire vault, not one safe or one credential. Restore in
        particular replaces live state and cannot be undone. Both are recorded in the audit log
        against your account.
      </Callout>

      <BackupRestorePanel />
    </div>
  )
}
