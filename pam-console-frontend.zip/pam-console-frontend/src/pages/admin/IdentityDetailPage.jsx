import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams, useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { KeyRound, Shield, FileCode2, Trash2, Plus, X, UserCog } from 'lucide-react'
import {
  getUser, setUserStatus, deleteUser, resetUserPassword,
  assignRole, removeRole, attachPolicy, detachPolicy,
} from '../../api/identity'
import { listRoles, listPolicies } from '../../api/rbac'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId, isUsableId } from '../../lib/entity'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  PageHeader, Card, CardHeader, CardBody, Button, Badge, QueryState, CardSkeleton,
  ErrorState, ConfirmDialog, DescriptionList, DescriptionItem, Select, Field, Input,
  Modal, Callout,
} from '../../ui'
import { USER_STATUSES, USER_STATUS_BADGE, USER_STATUS_DESCRIPTION, POLICY_EFFECT_BADGE } from '../../config/constants'

function ResetPasswordModal({ open, onClose, userId, username }) {
  const [password, setPassword] = useState('')
  const mutation = useMutation({
    mutationFn: () => resetUserPassword(userId, password),
    onSuccess: () => {
      toast.success('Password reset', { description: `Share the new password with ${username} securely.` })
      setPassword('')
      onClose()
    },
    onError: (err) => toast.error('Could not reset password', { description: apiErrorMessage(err) }),
  })

  const tooShort = password.length > 0 && password.length < 12

  return (
    <Modal
      open={open}
      onClose={() => {
        setPassword('')
        onClose()
      }}
      busy={mutation.isPending}
      icon={KeyRound}
      title={`Reset password for ${username}`}
      description="The user's existing sessions are unaffected until they expire."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            variant="primary"
            loading={mutation.isPending}
            disabled={password.length < 12}
            onClick={() => mutation.mutate()}
          >
            Reset password
          </Button>
        </>
      }
    >
      <Field
        label="New password"
        required
        error={tooShort ? 'At least 12 characters — this is a privileged-access console.' : undefined}
        hint="Share it over a secure channel, never in chat or email."
      >
        {({ id, ...a }) => (
          <Input
            id={id}
            {...a}
            data-autofocus
            type="password"
            autoComplete="new-password"
            error={tooShort}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        )}
      </Field>
    </Modal>
  )
}

export default function IdentityDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [resetOpen, setResetOpen] = useState(false)
  const [statusTarget, setStatusTarget] = useState(null)
  const [roleToAdd, setRoleToAdd] = useState('')
  const [policyToAdd, setPolicyToAdd] = useState('')

  /**
   * BUG FIX — second half of the `/identity/users/undefined` defect.
   *
   * Even with the list fixed, a stale bookmark or a hand-typed URL can still
   * land here with a junk param. `isUsableId` treats the literal strings
   * "undefined"/"null" as unusable, so the query never runs and the user gets
   * an explanation instead of a 404 loop. (api/identity.js throws a shaped
   * 400 as a second line of defence for every id-bearing call.)
   */
  const usable = isUsableId(id)

  const userQuery = useQuery({
    queryKey: ['identity', 'users', id],
    queryFn: ({ signal }) => getUser(id, signal),
    enabled: usable,
  })

  const rolesQuery = useQuery({
    queryKey: ['rbac', 'roles'],
    queryFn: ({ signal }) => listRoles(signal),
    staleTime: 60_000,
    retry: false,
  })
  const policiesQuery = useQuery({
    queryKey: ['rbac', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
    staleTime: 60_000,
    retry: false,
  })

  const user = userQuery.data?.user
  useDocumentTitle(user?.username || 'User')

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['identity'] })

  const statusMutation = useMutation({
    mutationFn: (status) => setUserStatus(id, status),
    onSuccess: (_, status) => {
      toast.success(`Account set to ${status}`)
      setStatusTarget(null)
      invalidate()
    },
    onError: (err) => {
      toast.error('Could not change status', { description: apiErrorMessage(err) })
      setStatusTarget(null)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteUser(id),
    onSuccess: () => {
      toast.success('User deleted')
      invalidate()
      navigate('/admin/identity', { replace: true })
    },
    onError: (err) => {
      toast.error('Could not delete user', { description: apiErrorMessage(err) })
      setDeleteOpen(false)
    },
  })

  const assignRoleMutation = useMutation({
    mutationFn: (roleName) => assignRole(id, roleName),
    onSuccess: () => {
      toast.success('Role assigned')
      setRoleToAdd('')
      invalidate()
    },
    onError: (err) => toast.error('Could not assign role', { description: apiErrorMessage(err) }),
  })

  const removeRoleMutation = useMutation({
    mutationFn: (roleName) => removeRole(id, roleName),
    onSuccess: () => {
      toast.success('Role removed')
      invalidate()
    },
    onError: (err) => toast.error('Could not remove role', { description: apiErrorMessage(err) }),
  })

  const attachPolicyMutation = useMutation({
    mutationFn: (policyId) => attachPolicy(id, policyId),
    onSuccess: () => {
      toast.success('Policy attached')
      setPolicyToAdd('')
      invalidate()
    },
    onError: (err) => toast.error('Could not attach policy', { description: apiErrorMessage(err) }),
  })

  const detachPolicyMutation = useMutation({
    mutationFn: (policyId) => detachPolicy(id, policyId),
    onSuccess: () => {
      toast.success('Policy detached')
      invalidate()
    },
    onError: (err) => toast.error('Could not detach policy', { description: apiErrorMessage(err) }),
  })

  if (!usable) {
    return (
      <div>
        <PageHeader
          breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'Identity', to: '/admin/identity' }]}
          title="User not specified"
        />
        <Card>
          <ErrorState
            title="This link has no user identifier"
            error={{
              response: {
                data: {
                  error:
                    'The address does not contain a usable user id, so nothing can be loaded. Return to the identity list and open the user from there.',
                },
              },
            }}
            onRetry={() => navigate('/admin/identity')}
          />
        </Card>
      </div>
    )
  }

  const assignedRoles = userQuery.data?.access?.roles || user?.roles || []
  const assignedPolicies = userQuery.data?.access?.policies || []
  const assignedRoleNames = assignedRoles.map((r) => (typeof r === 'string' ? r : r.name))
  const assignedPolicyIds = assignedPolicies.map((p) => entityId(p))

  const availableRoles = (rolesQuery.data || []).filter((r) => !assignedRoleNames.includes(r.name))
  const availablePolicies = (policiesQuery.data || []).filter((p) => !assignedPolicyIds.includes(entityId(p)))

  return (
    <div>
      <QueryState query={userQuery} skeleton={<CardSkeleton lines={6} />}>
        {() => (
          <>
            <PageHeader
              breadcrumbs={[
                { label: 'Admin', to: '/admin' },
                { label: 'Identity', to: '/admin/identity' },
                { label: user?.username || 'User' },
              ]}
              title={user?.username || 'User'}
              description={user?.email}
              meta={
                <>
                  <Badge className={USER_STATUS_BADGE[user?.status] || USER_STATUS_BADGE.DISABLED}>
                    {user?.status || 'UNKNOWN'}
                  </Badge>
                  {user?.mfa_enabled ? (
                    <Badge tone="success">MFA enrolled</Badge>
                  ) : (
                    <Badge tone="warning">No MFA</Badge>
                  )}
                </>
              }
              actions={
                <>
                  <Button variant="secondary" icon={KeyRound} onClick={() => setResetOpen(true)}>
                    Reset password
                  </Button>
                  <Button variant="dangerOutline" icon={Trash2} onClick={() => setDeleteOpen(true)}>
                    Delete
                  </Button>
                </>
              }
            />

            <div className="grid gap-5 lg:grid-cols-3">
              <Card className="lg:col-span-1">
                <CardHeader title="Account" />
                <CardBody className="space-y-4">
                  <DescriptionList cols="120px 1fr">
                    <DescriptionItem label="Username">{user?.username}</DescriptionItem>
                    <DescriptionItem label="Email">{user?.email}</DescriptionItem>
                    <DescriptionItem label="Created">{formatDateTime(user?.created_at)}</DescriptionItem>
                    <DescriptionItem label="Last sign-in">
                      {user?.last_login_at ? formatRelativeToNow(user.last_login_at) : 'Never'}
                    </DescriptionItem>
                    <DescriptionItem label="User ID" mono>
                      {entityId(user)}
                    </DescriptionItem>
                  </DescriptionList>

                  <div className="border-t border-surface-700 pt-4">
                    <Field
                      label="Lifecycle status"
                      hint={USER_STATUS_DESCRIPTION[user?.status] || 'Controls whether this account can sign in.'}
                    >
                      {({ id: fid, ...a }) => (
                        <Select
                          id={fid}
                          {...a}
                          value={user?.status || ''}
                          disabled={statusMutation.isPending}
                          onChange={(e) => setStatusTarget(e.target.value)}
                        >
                          {USER_STATUSES.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </Select>
                      )}
                    </Field>
                  </div>
                </CardBody>
              </Card>

              <div className="space-y-5 lg:col-span-2">
                <Card>
                  <CardHeader title="Roles" description="RBAC — bundles of policies granted together." />
                  <CardBody className="space-y-4">
                    {assignedRoleNames.length === 0 ? (
                      <p className="text-sm text-ink-500">No roles assigned.</p>
                    ) : (
                      <div className="flex flex-wrap gap-1.5">
                        {assignedRoleNames.map((name) => (
                          <span
                            key={name}
                            className="inline-flex items-center gap-1 rounded-md border border-surface-700 bg-surface-850 py-1 pl-2.5 pr-1 text-xs"
                          >
                            <Shield className="h-3 w-3 text-ink-400" aria-hidden="true" />
                            <span className="font-medium text-ink-100">{name}</span>
                            <button
                              type="button"
                              disabled={removeRoleMutation.isPending}
                              onClick={() => removeRoleMutation.mutate(name)}
                              className="rounded p-0.5 text-ink-500 transition-colors hover:bg-surface-800 hover:text-red-500 disabled:opacity-50"
                              aria-label={`Remove role ${name}`}
                            >
                              <X className="h-3 w-3" aria-hidden="true" />
                            </button>
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="flex items-end gap-2 border-t border-surface-700 pt-4">
                      <Field label="Assign a role" className="flex-1">
                        {({ id: fid, ...a }) => (
                          <Select
                            id={fid}
                            {...a}
                            value={roleToAdd}
                            disabled={rolesQuery.isLoading || availableRoles.length === 0}
                            onChange={(e) => setRoleToAdd(e.target.value)}
                          >
                            <option value="">
                              {availableRoles.length === 0 ? 'All roles already assigned' : 'Select a role…'}
                            </option>
                            {availableRoles.map((r) => (
                              <option key={r.name ?? entityId(r)} value={r.name}>
                                {r.name}
                              </option>
                            ))}
                          </Select>
                        )}
                      </Field>
                      <Button
                        icon={Plus}
                        variant="secondary"
                        disabled={!roleToAdd}
                        loading={assignRoleMutation.isPending}
                        onClick={() => assignRoleMutation.mutate(roleToAdd)}
                      >
                        Assign
                      </Button>
                    </div>
                  </CardBody>
                </Card>

                <Card>
                  <CardHeader
                    title="Direct policies"
                    description="PBAC — attached to this user specifically, in addition to anything their roles grant."
                  />
                  <CardBody className="space-y-4">
                    {assignedPolicies.length === 0 ? (
                      <p className="text-sm text-ink-500">No policies attached directly to this user.</p>
                    ) : (
                      <ul className="divide-y divide-surface-700 rounded-lg border border-surface-700">
                        {assignedPolicies.map((p) => {
                          const pid = entityId(p)
                          return (
                            <li key={pid} className="flex items-center gap-3 px-3 py-2.5">
                              <FileCode2 className="h-4 w-4 flex-none text-ink-400" aria-hidden="true" />
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-sm font-medium text-ink-100">{p.name}</p>
                                <p className="truncate text-xs text-ink-500">{p.description}</p>
                              </div>
                              <Badge size="xs" className={POLICY_EFFECT_BADGE[p.effect]}>
                                {p.effect}
                              </Badge>
                              <Button
                                size="xs"
                                variant="ghost"
                                disabled={detachPolicyMutation.isPending}
                                onClick={() => detachPolicyMutation.mutate(pid)}
                              >
                                Detach
                              </Button>
                            </li>
                          )
                        })}
                      </ul>
                    )}

                    <div className="flex items-end gap-2 border-t border-surface-700 pt-4">
                      <Field label="Attach a policy" className="flex-1">
                        {({ id: fid, ...a }) => (
                          <Select
                            id={fid}
                            {...a}
                            value={policyToAdd}
                            disabled={policiesQuery.isLoading || availablePolicies.length === 0}
                            onChange={(e) => setPolicyToAdd(e.target.value)}
                          >
                            <option value="">
                              {availablePolicies.length === 0
                                ? 'All policies already attached'
                                : 'Select a policy…'}
                            </option>
                            {availablePolicies.map((p) => (
                              <option key={entityId(p)} value={entityId(p)}>
                                {p.name} ({p.effect})
                              </option>
                            ))}
                          </Select>
                        )}
                      </Field>
                      <Button
                        icon={Plus}
                        variant="secondary"
                        disabled={!policyToAdd}
                        loading={attachPolicyMutation.isPending}
                        onClick={() => attachPolicyMutation.mutate(policyToAdd)}
                      >
                        Attach
                      </Button>
                    </div>

                    <Callout tone="neutral" icon={UserCog} title="Effective access">
                      What this user can actually do is the union of their role policies and these
                      direct policies, with any deny taking precedence.
                    </Callout>
                  </CardBody>
                </Card>
              </div>
            </div>

            <ResetPasswordModal
              open={resetOpen}
              onClose={() => setResetOpen(false)}
              userId={id}
              username={user?.username || 'this user'}
            />

            <ConfirmDialog
              open={!!statusTarget}
              title={`Set ${user?.username || 'this account'} to ${statusTarget}?`}
              description={USER_STATUS_DESCRIPTION[statusTarget] || 'This changes whether the account can sign in.'}
              confirmLabel={`Set to ${statusTarget}`}
              destructive={statusTarget !== 'ACTIVE'}
              requireReason
              reasonLabel="Reason"
              isLoading={statusMutation.isPending}
              onConfirm={() => statusMutation.mutate(statusTarget)}
              onCancel={() => setStatusTarget(null)}
            />

            <ConfirmDialog
              open={deleteOpen}
              title={`Delete ${user?.username || 'this user'}?`}
              description="The account is removed and can no longer sign in. Their audit history is retained."
              confirmLabel="Delete user"
              destructive
              confirmPhrase={user?.username}
              requireReason
              reasonLabel="Reason"
              isLoading={deleteMutation.isPending}
              onConfirm={() => deleteMutation.mutate()}
              onCancel={() => setDeleteOpen(false)}
            />
          </>
        )}
      </QueryState>
    </div>
  )
}
