import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { UserPlus, Users, ChevronRight, AlertTriangle } from 'lucide-react'
import { listUsers } from '../../api/identity'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useDebouncedValue } from '../../hooks/useDebouncedValue'
import { entityId } from '../../lib/entity'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { CreateUserModal } from '../../components/admin/CreateUserModal'
import {
  PageHeader, Card, CardToolbar, Button, Badge, QueryState, TableSkeleton,
  EmptyState, NoResultsState, SearchInput,
  Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'
import { USER_STATUS_BADGE, ROLE_BADGE, SEARCH_DEBOUNCE_MS } from '../../config/constants'

/**
 * Identity list.
 * ===========================================================================
 * BUG FIX — the detail page was issuing
 *     GET /api/v1/pam/admin/identity/users/undefined
 *
 * Root cause was here, not there. The row rendered
 *     to={`/admin/identity/${u.id}`}
 * unconditionally. When the record's primary key is serialised under any key
 * other than `id`, that template literal produces the *string* "undefined" —
 * a structurally valid URL segment. The router matched it, the detail page
 * mounted, and it fetched a user literally named "undefined".
 *
 * Fix: resolve the id through entityId() (which probes the plausible key
 * names), and when no usable id exists, render the row as INERT with a
 * visible warning instead of a link to nowhere. A row you cannot open is a
 * data problem worth seeing; a link that 404s is a bug report.
 */
export default function IdentityListPage() {
  const [searchInput, setSearchInput] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const search = useDebouncedValue(searchInput.trim(), SEARCH_DEBOUNCE_MS)
  useDocumentTitle('Identity')

  const usersQuery = useQuery({
    queryKey: ['identity', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
    placeholderData: (prev) => prev,
  })

  const users = usersQuery.data?.users || []
  const unusable = users.filter((u) => !entityId(u)).length

  return (
    <div>
      <PageHeader
        breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'Identity' }]}
        title="Identity"
        description="User accounts, their lifecycle status, and the roles and policies attached to them."
        actions={
          <Button variant="primary" icon={UserPlus} onClick={() => setCreateOpen(true)}>
            Create user
          </Button>
        }
      />

      <Card>
        <CardToolbar>
          <SearchInput
            value={searchInput}
            onChange={setSearchInput}
            placeholder="Search by username or email…"
            className="w-full max-w-sm"
          />
          <span className="ml-auto text-xs tabular-nums text-ink-500">
            {usersQuery.data?.count ?? users.length} users
          </span>
        </CardToolbar>

        {unusable > 0 && (
          <div className="flex items-start gap-2 border-b border-amber-300 bg-amber-50 px-4 py-2.5 text-xs text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 flex-none" aria-hidden="true" />
            <span>
              {unusable} record{unusable === 1 ? '' : 's'} came back without a usable identifier and
              cannot be opened. This is a backend serialisation problem, not a permissions one.
            </span>
          </div>
        )}

        <QueryState
          query={usersQuery}
          skeleton={<TableSkeleton rows={8} cols={4} />}
          empty={(d) => (d?.users || []).length === 0}
          emptyState={
            search ? (
              <NoResultsState onClear={() => setSearchInput('')} />
            ) : (
              <EmptyState
                icon={Users}
                title="No users yet"
                description="Create the first account to start granting privileged access."
                action={
                  <Button variant="primary" icon={UserPlus} onClick={() => setCreateOpen(true)}>
                    Create user
                  </Button>
                }
              />
            )
          }
        >
          {() => (
            <Table>
              <THead>
                <tr>
                  <TH>User</TH>
                  <TH className="hidden lg:table-cell">Roles</TH>
                  <TH className="hidden xl:table-cell">Last sign-in</TH>
                  <TH align="right">Status</TH>
                  <TH width="44" />
                </tr>
              </THead>
              <TBody>
                {users.map((u, idx) => {
                  const id = entityId(u)
                  const cells = (
                    <>
                      <CellStack
                        icon={
                          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-2xs font-semibold uppercase text-white">
                            {(u.username || '?').slice(0, 2)}
                          </span>
                        }
                        primary={u.username || '—'}
                        secondary={u.email || 'No email recorded'}
                      />
                    </>
                  )
                  return (
                    <TR key={id || `row-${idx}`} interactive={!!id}>
                      <TD className={id ? 'p-0' : undefined}>
                        {id ? (
                          <Link to={`/admin/identity/${id}`} className="flex items-center px-4 py-3">
                            {cells}
                          </Link>
                        ) : (
                          <div className="opacity-60">{cells}</div>
                        )}
                      </TD>
                      <TD className="hidden lg:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {(u.roles || []).length === 0 ? (
                            <span className="text-xs text-ink-500">No roles</span>
                          ) : (
                            (u.roles || []).map((r) => (
                              <Badge key={r} size="xs" className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                                {r}
                              </Badge>
                            ))
                          )}
                        </div>
                      </TD>
                      <TD className="hidden xl:table-cell">
                        <span
                          className="text-xs text-ink-500"
                          title={u.last_login_at ? formatDateTime(u.last_login_at, { seconds: true }) : undefined}
                        >
                          {u.last_login_at ? formatRelativeToNow(u.last_login_at) : 'Never'}
                        </span>
                      </TD>
                      <TD align="right">
                        <Badge className={USER_STATUS_BADGE[u.status] || USER_STATUS_BADGE.DISABLED}>
                          {u.status || 'UNKNOWN'}
                        </Badge>
                      </TD>
                      <TD align="right">
                        {id ? (
                          <ChevronRight className="h-4 w-4 text-ink-600" aria-hidden="true" />
                        ) : (
                          <span title="No usable identifier">
                            <AlertTriangle className="h-4 w-4 text-amber-500" aria-hidden="true" />
                          </span>
                        )}
                      </TD>
                    </TR>
                  )
                })}
              </TBody>
            </Table>
          )}
        </QueryState>
      </Card>

      <CreateUserModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
