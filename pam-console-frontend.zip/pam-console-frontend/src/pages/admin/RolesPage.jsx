import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Plus, Shield, Trash2, FileCode2, X } from 'lucide-react'
import {
  listRoles, getRole, deleteRole, attachPolicyToRole, detachPolicyFromRole,
} from '../../api/rbac'
import { listPolicies } from '../../api/rbac'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId } from '../../lib/entity'
import { apiErrorMessage } from '../../lib/apiError'
import { CreateRoleModal } from '../../components/admin/CreateRoleModal'
import {
  PageHeader, Card, CardHeader, CardBody, Button, Badge, QueryState, TableSkeleton,
  CardSkeleton, EmptyState, ConfirmDialog, Field, Select, Callout,
  Table, TBody, TR, TD, CellStack,
} from '../../ui'
import { SYSTEM_ROLES, ROLE_BADGE, POLICY_EFFECT_BADGE } from '../../config/constants'

/**
 * Master/detail rather than a flat list: a role is meaningless without the
 * policies attached to it, and forcing a navigation to see them makes
 * "what does this role actually permit?" a multi-step question.
 */
export default function RolesPage() {
  const [selectedId, setSelectedId] = useState(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [policyToAttach, setPolicyToAttach] = useState('')
  const queryClient = useQueryClient()
  useDocumentTitle('Roles')

  const rolesQuery = useQuery({
    queryKey: ['rbac', 'roles'],
    queryFn: ({ signal }) => listRoles(signal),
  })

  const roles = rolesQuery.data || []
  const activeId = selectedId || entityId(roles[0]) || null

  const roleQuery = useQuery({
    queryKey: ['rbac', 'roles', activeId],
    queryFn: ({ signal }) => getRole(activeId, signal),
    enabled: !!activeId,
  })

  const policiesQuery = useQuery({
    queryKey: ['rbac', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
    staleTime: 60_000,
    retry: false,
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['rbac'] })

  const deleteMutation = useMutation({
    mutationFn: (roleId) => deleteRole(roleId),
    onSuccess: () => {
      toast.success('Role deleted')
      setDeleteTarget(null)
      setSelectedId(null)
      invalidate()
    },
    onError: (err) => {
      toast.error('Could not delete role', { description: apiErrorMessage(err) })
      setDeleteTarget(null)
    },
  })

  const attachMutation = useMutation({
    mutationFn: (policyId) => attachPolicyToRole(activeId, policyId),
    onSuccess: () => {
      toast.success('Policy attached to role')
      setPolicyToAttach('')
      invalidate()
    },
    onError: (err) => toast.error('Could not attach policy', { description: apiErrorMessage(err) }),
  })

  const detachMutation = useMutation({
    mutationFn: (policyId) => detachPolicyFromRole(activeId, policyId),
    onSuccess: () => {
      toast.success('Policy detached from role')
      invalidate()
    },
    onError: (err) => toast.error('Could not detach policy', { description: apiErrorMessage(err) }),
  })

  const role = roleQuery.data?.role
  const rolePolicies = roleQuery.data?.policies || []
  const attachedIds = rolePolicies.map((p) => entityId(p))
  const availablePolicies = (policiesQuery.data || []).filter((p) => !attachedIds.includes(entityId(p)))
  const isSystemRole = role && SYSTEM_ROLES.includes(role.name)

  return (
    <div>
      <PageHeader
        breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'Roles' }]}
        title="Roles"
        description="RBAC — named bundles of policies you assign to users. A role's permissions are exactly the policies attached to it."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create role
          </Button>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[18rem_1fr]">
        <Card className="h-fit">
          <CardHeader title="All roles" />
          <QueryState
            query={rolesQuery}
            skeleton={<TableSkeleton rows={4} cols={2} />}
            empty={(d) => !d || d.length === 0}
            emptyState={
              <EmptyState
                compact
                icon={Shield}
                title="No roles yet"
                description="Create a role to bundle policies together."
              />
            }
          >
            {() => (
              <Table>
                <TBody>
                  {roles.map((r) => {
                    const rid = entityId(r)
                    const active = rid === activeId
                    return (
                      <TR
                        key={rid}
                        interactive
                        onClick={() => setSelectedId(rid)}
                        className={active ? 'bg-brand-50/70 dark:bg-brand-500/10' : undefined}
                      >
                        <TD>
                          <CellStack
                            icon={
                              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-800 text-ink-400">
                                <Shield className="h-4 w-4" aria-hidden="true" />
                              </span>
                            }
                            primary={
                              <span className="flex items-center gap-2">
                                {r.name}
                                {SYSTEM_ROLES.includes(r.name) && (
                                  <Badge size="xs" className={ROLE_BADGE[r.name] || ROLE_BADGE.user}>
                                    system
                                  </Badge>
                                )}
                              </span>
                            }
                            secondary={r.description || 'No description'}
                          />
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
            )}
          </QueryState>
        </Card>

        <Card>
          {!activeId ? (
            <EmptyState
              icon={Shield}
              title="Select a role"
              description="Pick a role on the left to see and change the policies attached to it."
            />
          ) : (
            <QueryState query={roleQuery} skeleton={<CardSkeleton lines={5} />}>
              {() => (
                <>
                  <CardHeader
                    title={role?.name}
                    description={role?.description}
                    actions={
                      !isSystemRole && (
                        <Button
                          size="sm"
                          variant="dangerOutline"
                          icon={Trash2}
                          onClick={() => setDeleteTarget(role)}
                        >
                          Delete role
                        </Button>
                      )
                    }
                  />
                  <CardBody className="space-y-4">
                    {isSystemRole && (
                      <Callout tone="neutral" icon={Shield} title="Built-in role">
                        System roles cannot be deleted. Their policy attachments can still be
                        adjusted, but changing what <code className="font-mono">admin</code> or{' '}
                        <code className="font-mono">root</code> permits affects every administrator.
                      </Callout>
                    )}

                    <div>
                      <p className="mb-2 text-xs font-medium text-ink-300">Attached policies</p>
                      {rolePolicies.length === 0 ? (
                        <p className="rounded-lg border border-dashed border-surface-600 px-3 py-6 text-center text-sm text-ink-500">
                          No policies attached — this role currently grants nothing.
                        </p>
                      ) : (
                        <ul className="divide-y divide-surface-700 rounded-lg border border-surface-700">
                          {rolePolicies.map((p) => {
                            const pid = entityId(p)
                            return (
                              <li key={pid} className="flex items-center gap-3 px-3 py-2.5">
                                <FileCode2 className="h-4 w-4 flex-none text-ink-400" aria-hidden="true" />
                                <div className="min-w-0 flex-1">
                                  <p className="truncate text-sm font-medium text-ink-100">{p.name}</p>
                                  <p className="truncate text-xs text-ink-500">{p.description}</p>
                                </div>
                                <Badge size="xs" className={POLICY_EFFECT_BADGE[p.effect]}>
                                  {p.effect}
                                </Badge>
                                <button
                                  type="button"
                                  disabled={detachMutation.isPending}
                                  onClick={() => detachMutation.mutate(pid)}
                                  className="rounded p-1 text-ink-500 transition-colors hover:bg-surface-800 hover:text-red-500 disabled:opacity-50"
                                  aria-label={`Detach ${p.name}`}
                                >
                                  <X className="h-3.5 w-3.5" aria-hidden="true" />
                                </button>
                              </li>
                            )
                          })}
                        </ul>
                      )}
                    </div>

                    <div className="flex items-end gap-2 border-t border-surface-700 pt-4">
                      <Field label="Attach a policy" className="flex-1">
                        {({ id: fid, ...a }) => (
                          <Select
                            id={fid}
                            {...a}
                            value={policyToAttach}
                            disabled={policiesQuery.isLoading || availablePolicies.length === 0}
                            onChange={(e) => setPolicyToAttach(e.target.value)}
                          >
                            <option value="">
                              {availablePolicies.length === 0
                                ? 'All policies already attached'
                                : 'Select a policy…'}
                            </option>
                            {availablePolicies.map((p) => (
                              <option key={entityId(p)} value={entityId(p)}>
                                {p.name} ({p.effect})
                              </option>
                            ))}
                          </Select>
                        )}
                      </Field>
                      <Button
                        icon={Plus}
                        variant="secondary"
                        disabled={!policyToAttach}
                        loading={attachMutation.isPending}
                        onClick={() => attachMutation.mutate(policyToAttach)}
                      >
                        Attach
                      </Button>
                    </div>
                  </CardBody>
                </>
              )}
            </QueryState>
          )}
        </Card>
      </div>

      <CreateRoleModal open={createOpen} onClose={() => setCreateOpen(false)} />

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete the role "${deleteTarget?.name}"?`}
        description="Users holding this role lose everything it granted them. Policies themselves are not deleted."
        confirmLabel="Delete role"
        destructive
        confirmPhrase={deleteTarget?.name}
        isLoading={deleteMutation.isPending}
        onConfirm={() => deleteMutation.mutate(entityId(deleteTarget))}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  )
}
