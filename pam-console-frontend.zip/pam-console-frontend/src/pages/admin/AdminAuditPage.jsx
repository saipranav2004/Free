import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ShieldCheck, ShieldAlert, FileText, Download, ScrollText, Filter } from 'lucide-react'
import { listAudit, verifyAudit } from '../../api/admin'
import { generateComplianceReport } from '../../api/audit'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useDebouncedValue } from '../../hooks/useDebouncedValue'
import { formatDateTime, formatRelativeToNow, toDateInputValue, dateInputToIso } from '../../lib/format'
import { actorLabel, targetLabel, chainIsValid } from '../../lib/entity'
import { apiErrorMessage } from '../../lib/apiError'
import {
  PageHeader, Card, CardToolbar, Button, Badge, QueryState, TableSkeleton,
  EmptyState, NoResultsState, SearchInput, FilterSelect, Pagination, Callout,
  Modal, Field, Input,
  Table, THead, TH, TBody, TR, TD,
} from '../../ui'
import {
  AUDIT_CATEGORIES, AUDIT_OUTCOMES, AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE,
  SEARCH_DEBOUNCE_MS, DEFAULT_PAGE_SIZE, REPORT_FORMATS, REPORT_RANGE_PRESETS,
} from '../../config/constants'

function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}

/** Same report dialog contract as the user-facing Audit page — an explicit
 *  reporting period is always sent. See pages/audit/AuditPage.jsx for the
 *  full account of why the previous version could never succeed. */
function ReportModal({ open, onClose, filters }) {
  const [format, setFormat] = useState('pdf')
  const [preset, setPreset] = useState('30d')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')

  useEffect(() => {
    if (!open) return
    setFormat('pdf')
    setPreset('30d')
    const now = new Date()
    setTo(toDateInputValue(now))
    setFrom(toDateInputValue(new Date(now.getTime() - 30 * 86400_000)))
  }, [open])

  useEffect(() => {
    if (preset === 'custom') return
    const days = REPORT_RANGE_PRESETS.find((p) => p.key === preset)?.days
    if (!days) return
    const now = new Date()
    setTo(toDateInputValue(now))
    setFrom(toDateInputValue(new Date(now.getTime() - days * 86400_000)))
  }, [preset])

  const rangeValid = Boolean(from && to && new Date(from) <= new Date(to))

  const mutation = useMutation({
    mutationFn: () =>
      generateComplianceReport({
        format,
        startIso: dateInputToIso(from),
        endIso: dateInputToIso(to, { endOfDay: true }),
        category: filters.category,
        outcome: filters.outcome,
        q: filters.q,
      }),
    onSuccess: (result) => {
      toast.success('Report downloaded', { description: result?.filename })
      onClose()
    },
    onError: (err) => toast.error('Could not generate report', { description: apiErrorMessage(err) }),
  })

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      icon={FileText}
      title="Generate compliance report"
      description="Organization-wide audit export for a reporting period."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            variant="primary"
            icon={Download}
            loading={mutation.isPending}
            disabled={!rangeValid}
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? 'Generating…' : 'Generate & download'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        <div>
          <p className="mb-2 text-xs font-medium text-ink-300">Format</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {REPORT_FORMATS.map((f) => (
              <label
                key={f.value}
                className={
                  'cursor-pointer rounded-lg border p-3 transition-colors ' +
                  (format === f.value
                    ? 'border-brand-500 bg-brand-50 dark:bg-brand-500/10'
                    : 'border-surface-700 bg-surface-900 hover:bg-surface-850')
                }
              >
                <span className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="admin-report-format"
                    className="h-4 w-4"
                    checked={format === f.value}
                    onChange={() => setFormat(f.value)}
                  />
                  <span className="text-sm font-medium text-ink-50">{f.label}</span>
                </span>
                <span className="mt-1 block pl-6 text-xs leading-relaxed text-ink-500">{f.hint}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 text-xs font-medium text-ink-300">Reporting period</p>
          <div className="mb-3 flex flex-wrap gap-1.5">
            {REPORT_RANGE_PRESETS.map((p) => (
              <button
                key={p.key}
                type="button"
                onClick={() => setPreset(p.key)}
                className={
                  'rounded-md border px-2.5 py-1 text-xs font-medium transition-colors ' +
                  (preset === p.key
                    ? 'border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-400'
                    : 'border-surface-700 bg-surface-900 text-ink-300 hover:bg-surface-850')
                }
              >
                {p.label}
              </button>
            ))}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="From" required>
              {({ id, ...a }) => (
                <Input
                  id={id}
                  {...a}
                  type="date"
                  value={from}
                  max={to || undefined}
                  onChange={(e) => {
                    setFrom(e.target.value)
                    setPreset('custom')
                  }}
                />
              )}
            </Field>
            <Field label="To" required>
              {({ id, ...a }) => (
                <Input
                  id={id}
                  {...a}
                  type="date"
                  value={to}
                  min={from || undefined}
                  onChange={(e) => {
                    setTo(e.target.value)
                    setPreset('custom')
                  }}
                />
              )}
            </Field>
          </div>
          {!rangeValid && (from || to) && (
            <p className="mt-2 text-xs font-medium text-red-600 dark:text-red-400">
              The start date must be on or before the end date.
            </p>
          )}
        </div>

        {(filters.category || filters.outcome || filters.q) && (
          <Callout tone="neutral" icon={Filter} title="Scoped by your current filters">
            <ul className="mt-1 space-y-0.5 text-xs">
              {filters.q && <li>Search: {filters.q}</li>}
              {filters.category && <li>Category: {filters.category}</li>}
              {filters.outcome && <li>Outcome: {filters.outcome}</li>}
            </ul>
          </Callout>
        )}
      </div>
    </Modal>
  )
}

export default function AdminAuditPage() {
  const [searchInput, setSearchInput] = useState('')
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [page, setPage] = useState(1)
  const [reportOpen, setReportOpen] = useState(false)
  useDocumentTitle('Organization audit')

  const search = useDebouncedValue(searchInput.trim(), SEARCH_DEBOUNCE_MS)

  useEffect(() => {
    setPage(1)
  }, [search, category, outcome])

  const filters = useMemo(
    () => ({
      // Free text goes out as free text with the conventional aliases — the
      // same fix applied to the user-facing audit search.
      ...(search ? { q: search, search, query: search } : {}),
      ...(category ? { category } : {}),
      ...(outcome ? { outcome } : {}),
    }),
    [search, category, outcome]
  )

  const auditQuery = useQuery({
    queryKey: ['admin', 'audit', { search, category, outcome, page }],
    queryFn: ({ signal }) =>
      listAudit({ ...filters, page, page_size: DEFAULT_PAGE_SIZE }, signal),
    placeholderData: (prev) => prev,
  })

  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error('Verification failed', { description: apiErrorMessage(err) }),
  })

  const hasFilters = Boolean(search || category || outcome)
  const clearFilters = () => {
    setSearchInput('')
    setCategory('')
    setOutcome('')
  }

  const pagination = auditQuery.data?.pagination
  const valid = verifyMutation.isSuccess ? chainIsValid(verifyMutation.data) : null

  return (
    <div>
      <PageHeader
        breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'Audit' }]}
        title="Organization audit"
        description="Every recorded action across the organization, tamper-evident and exportable for compliance."
        actions={
          <>
            <Button
              variant="secondary"
              icon={ShieldCheck}
              loading={verifyMutation.isPending}
              onClick={() => verifyMutation.mutate()}
            >
              Verify chain
            </Button>
            <Button variant="primary" icon={FileText} onClick={() => setReportOpen(true)}>
              Generate report
            </Button>
          </>
        }
      />

      {verifyMutation.isSuccess && (
        <div className="mb-5">
          {valid === true ? (
            <Callout tone="success" icon={ShieldCheck} title="Audit chain intact">
              Every entry forms an unbroken hash chain — no tampering detected.
            </Callout>
          ) : valid === false ? (
            <Callout tone="danger" icon={ShieldAlert} title="Audit chain broken — possible tampering">
              The hash chain does not verify. Preserve the current state and escalate immediately.
            </Callout>
          ) : (
            <Callout tone="neutral" title="Verification result">
              <pre className="mt-1 max-w-full overflow-x-auto text-2xs">
                {JSON.stringify(verifyMutation.data, null, 2)}
              </pre>
            </Callout>
          )}
        </div>
      )}

      <Card>
        <CardToolbar>
          <SearchInput
            value={searchInput}
            onChange={setSearchInput}
            placeholder="Search events, users or resources…"
            className="w-full max-w-sm"
          />
          <FilterSelect
            label="Category"
            value={category}
            onChange={setCategory}
            options={AUDIT_CATEGORIES}
            allLabel="All categories"
          />
          <FilterSelect
            label="Outcome"
            value={outcome}
            onChange={setOutcome}
            options={AUDIT_OUTCOMES}
            allLabel="All outcomes"
          />
          {hasFilters && (
            <Button size="sm" variant="ghost" onClick={clearFilters}>
              Clear
            </Button>
          )}
        </CardToolbar>

        <QueryState
          query={auditQuery}
          skeleton={<TableSkeleton rows={10} cols={4} />}
          empty={(d) => (d?.events || []).length === 0}
          emptyState={
            hasFilters ? (
              <NoResultsState onClear={clearFilters} />
            ) : (
              <EmptyState
                icon={ScrollText}
                title="No audit entries"
                description="Activity across the organization will appear here as it happens."
              />
            )
          }
        >
          {(data) => (
            <>
              <Table>
                <THead>
                  <tr>
                    <TH>Event</TH>
                    <TH className="hidden lg:table-cell">Actor</TH>
                    <TH className="hidden xl:table-cell">When</TH>
                    <TH align="right">Result</TH>
                  </tr>
                </THead>
                <TBody>
                  {(data.events || []).map((item, idx) => {
                    const ts = itemTimestamp(item)
                    return (
                      <TR key={item?.id ?? item?.sequence ?? idx}>
                        <TD>
                          <div className="min-w-0">
                            <p className="flex flex-wrap items-center gap-2 text-sm">
                              <span className="font-mono text-2xs uppercase tracking-wide text-ink-500">
                                {item?.category || 'OTHER'}
                              </span>
                              <span className="font-medium text-ink-50">{item?.action || '—'}</span>
                            </p>
                            <p className="mt-1 truncate text-xs text-ink-500">
                              Target: {targetLabel(item)}
                            </p>
                          </div>
                        </TD>
                        <TD className="hidden lg:table-cell">
                          <span className="text-xs text-ink-300">{actorLabel(item)}</span>
                        </TD>
                        <TD className="hidden xl:table-cell">
                          <span
                            className="text-xs text-ink-500"
                            title={formatDateTime(ts, { seconds: true })}
                          >
                            {ts ? formatRelativeToNow(ts) : '—'}
                          </span>
                        </TD>
                        <TD align="right">
                          <div className="flex flex-wrap items-center justify-end gap-1.5">
                            {item?.severity && (
                              <Badge size="xs" className={AUDIT_SEVERITY_BADGE[item.severity]}>
                                {item.severity}
                              </Badge>
                            )}
                            {item?.outcome && (
                              <Badge className={AUDIT_OUTCOME_BADGE[item.outcome]}>{item.outcome}</Badge>
                            )}
                          </div>
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        filters={{ q: search, category, outcome }}
      />
    </div>
  )
}
