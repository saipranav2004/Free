import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Check, X, ShieldAlert, Inbox, Clock, Lock, KeyRound } from 'lucide-react'
import {
  listJitRequests, listGrants, approveJitRequest, denyJitRequest, revokeGrant,
} from '../../api/admin'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useCountdown } from '../../hooks/useCountdown'
import { entityId, requesterLabel, resourceLabel } from '../../lib/entity'
import { formatDateTime, formatDuration, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  PageHeader, Card, Button, Badge, QueryState, TableSkeleton, EmptyState,
  Pagination, Tabs, Toolbar, FilterSelect, ConfirmDialog, Callout,
  Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'
import {
  JIT_STATUS, JIT_STATUS_LABELS, JIT_STATUS_BADGE, JIT_ACTIONABLE_STATUSES,
  GRANT_STATUS, GRANT_STATUS_BADGE, DEFAULT_PAGE_SIZE, JIT_POLL_MS,
} from '../../config/constants'

/**
 * Admin approval queue.
 * ===========================================================================
 * BUG FIX — "Admin sees JIT requests on the Overview but the dedicated JIT
 * page shows none."
 *
 * Both screens hit the same endpoint. The Overview always sent
 * `status=PENDING`; this page defaulted its filter to "" and therefore
 * omitted `status` entirely, and the endpoint returns nothing for a call
 * with no status rather than everything.
 *
 * Two changes, belt and braces:
 *   1. This page NEVER omits the status parameter. The default queue view is
 *      the actionable set (PENDING + WAITING) sent explicitly; "All statuses"
 *      sends the full enumeration rather than nothing. So even a backend that
 *      treats a missing status as "match nothing" gets an explicit list.
 *   2. api/admin.js resolves the collection from whichever envelope key the
 *      handler used, so a naming difference can never present as "no data".
 *
 * The status parameter is sent BOTH as a repeated `status` and as a
 * comma-joined `statuses`, because a single-valued handler and a multi-valued
 * one disagree on which they read, and an unread extra query parameter is
 * inert. [Guessing] on which one this backend reads — one look at
 * admin_handler.go collapses this to a single line.
 */
function statusParams(statuses) {
  const list = statuses.filter(Boolean)
  if (list.length === 0) return {}
  return { status: list.length === 1 ? list[0] : list, statuses: list.join(',') }
}

const ALL_JIT_STATUSES = Object.values(JIT_STATUS)

function GrantCountdown({ expiresAt }) {
  const { remainingSec, expired, unknown } = useCountdown(expiresAt)
  if (unknown) return <span className="text-xs text-ink-500">—</span>
  if (expired) return <span className="text-xs text-ink-500">Expired</span>
  return (
    <span
      className={
        'inline-flex items-center gap-1.5 text-xs font-medium tabular-nums ' +
        (remainingSec < 300
          ? 'text-amber-600 dark:text-amber-400'
          : 'text-emerald-600 dark:text-emerald-400')
      }
    >
      <Clock className="h-3.5 w-3.5" aria-hidden="true" />
      {formatDuration(remainingSec)}
    </span>
  )
}

export default function AdminJitPage() {
  const [tab, setTab] = useState('queue')
  // Default = the actionable set, sent explicitly. Never "" and never omitted.
  const [statusFilter, setStatusFilter] = useState('__actionable__')
  const [grantStatus, setGrantStatus] = useState(GRANT_STATUS.ACTIVE)
  const [page, setPage] = useState(1)
  const [decision, setDecision] = useState(null) // { kind, request|grant }
  const queryClient = useQueryClient()
  useDocumentTitle('JIT approvals')

  useEffect(() => {
    setPage(1)
  }, [tab, statusFilter, grantStatus])

  const requestStatuses = useMemo(() => {
    if (statusFilter === '__actionable__') return JIT_ACTIONABLE_STATUSES
    if (statusFilter === '__all__') return ALL_JIT_STATUSES
    return [statusFilter]
  }, [statusFilter])

  const requestsQuery = useQuery({
    queryKey: ['admin', 'jit-requests', { page, statuses: requestStatuses }],
    queryFn: ({ signal }) =>
      listJitRequests(
        { page, page_size: DEFAULT_PAGE_SIZE, ...statusParams(requestStatuses) },
        signal
      ),
    enabled: tab === 'queue',
    // The queue is a shared work surface — another admin approving something
    // should not leave this one looking at a stale row they then fail to act
    // on with a 409.
    refetchInterval: tab === 'queue' ? JIT_POLL_MS : false,
    placeholderData: (prev) => prev,
  })

  const grantsQuery = useQuery({
    queryKey: ['admin', 'grants', { page, grantStatus }],
    queryFn: ({ signal }) =>
      listGrants({ page, page_size: DEFAULT_PAGE_SIZE, status: grantStatus || undefined }, signal),
    enabled: tab === 'grants',
    placeholderData: (prev) => prev,
  })

  const activeQuery = tab === 'queue' ? requestsQuery : grantsQuery
  const pagination = activeQuery.data?.pagination

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['admin'] })
    queryClient.invalidateQueries({ queryKey: ['jit'] })
  }

  const approveMutation = useMutation({
    mutationFn: ({ id, reason }) => approveJitRequest(id, reason),
    onSuccess: (data) => {
      toast.success('Request approved', {
        description: data?.expires_at ? `Access expires ${formatDateTime(data.expires_at)}.` : undefined,
      })
      setDecision(null)
      invalidate()
    },
    onError: (err) => {
      toast.error('Could not approve request', { description: apiErrorMessage(err) })
      setDecision(null)
    },
  })

  const denyMutation = useMutation({
    mutationFn: ({ id, reason }) => denyJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request denied')
      setDecision(null)
      invalidate()
    },
    onError: (err) => {
      toast.error('Could not deny request', { description: apiErrorMessage(err) })
      setDecision(null)
    },
  })

  const revokeMutation = useMutation({
    mutationFn: ({ id, reason }) => revokeGrant(id, reason),
    onSuccess: (data) => {
      const killed = data?.sessions_killed
      toast.success('Grant revoked', {
        description: killed ? `${killed} active session${killed === 1 ? '' : 's'} terminated.` : undefined,
      })
      setDecision(null)
      invalidate()
    },
    onError: (err) => {
      toast.error('Could not revoke grant', { description: apiErrorMessage(err) })
      setDecision(null)
    },
  })

  const busy = approveMutation.isPending || denyMutation.isPending || revokeMutation.isPending

  const confirmDecision = (reason) => {
    if (!decision) return
    const id = entityId(decision.item)
    if (decision.kind === 'approve') approveMutation.mutate({ id, reason })
    else if (decision.kind === 'deny') denyMutation.mutate({ id, reason })
    else revokeMutation.mutate({ id, reason })
  }

  const decisionCopy = {
    approve: {
      title: `Approve access for ${requesterLabel(decision?.item)}?`,
      description:
        'Grants time-boxed access for the requested window. Access revokes itself automatically when it expires.',
      confirmLabel: 'Approve request',
      destructive: false,
    },
    deny: {
      title: `Deny access for ${requesterLabel(decision?.item)}?`,
      description: 'The requester is notified. They can submit a new request with more context.',
      confirmLabel: 'Deny request',
      destructive: true,
    },
    revoke: {
      title: `Revoke this grant?`,
      description:
        'Access ends immediately and any active session using it is terminated. This is recorded in the audit log.',
      confirmLabel: 'Revoke grant',
      destructive: true,
    },
  }[decision?.kind || 'approve']

  return (
    <div>
      <PageHeader
        breadcrumbs={[{ label: 'Admin', to: '/admin' }, { label: 'JIT approvals' }]}
        title="JIT approvals"
        description="Approve, deny and revoke time-boxed privileged access. Every decision is attributed to you and recorded."
      />

      <Toolbar className="mb-4">
        <Tabs
          tabs={[
            { key: 'queue', label: 'Request queue', icon: KeyRound },
            { key: 'grants', label: 'Active grants', icon: Lock },
          ]}
          active={tab}
          onChange={setTab}
        />
        <div className="ml-auto">
          {tab === 'queue' ? (
            <FilterSelect
              label="Status"
              value={statusFilter}
              onChange={setStatusFilter}
              options={[
                { value: '__actionable__', label: 'Needs a decision' },
                { value: '__all__', label: 'All statuses' },
                ...ALL_JIT_STATUSES.map((s) => ({ value: s, label: JIT_STATUS_LABELS[s] || s })),
              ]}
              allLabel={null}
            />
          ) : (
            <FilterSelect
              label="Status"
              value={grantStatus}
              onChange={setGrantStatus}
              options={Object.values(GRANT_STATUS)}
              allLabel="All statuses"
            />
          )}
        </div>
      </Toolbar>

      <Card>
        {tab === 'queue' ? (
          <QueryState
            query={requestsQuery}
            skeleton={<TableSkeleton rows={6} cols={5} />}
            empty={(d) => (d?.requests || []).length === 0}
            emptyState={
              <EmptyState
                icon={Inbox}
                title={
                  statusFilter === '__actionable__'
                    ? 'Nothing waiting for a decision'
                    : 'No requests with this status'
                }
                description={
                  statusFilter === '__actionable__'
                    ? 'Approved, denied and expired requests are still visible — change the status filter to see them.'
                    : 'Try a different status filter.'
                }
              />
            }
          >
            {(data) => (
              <>
                <Table>
                  <THead>
                    <tr>
                      <TH>Requester</TH>
                      <TH className="hidden md:table-cell">Resource</TH>
                      <TH className="hidden xl:table-cell">Requested</TH>
                      <TH align="right">Status</TH>
                      <TH align="right" width="190" />
                    </tr>
                  </THead>
                  <TBody>
                    {(data.requests || []).map((r) => {
                      const id = entityId(r)
                      const actionable = JIT_ACTIONABLE_STATUSES.includes(r.status)
                      return (
                        <TR key={id}>
                          <TD>
                            <CellStack
                              primary={
                                <span className="flex items-center gap-2">
                                  {requesterLabel(r)}
                                  {r.type === 'BREAKGLASS' && (
                                    <Badge tone="danger" size="xs" icon={ShieldAlert}>
                                      Break-glass
                                    </Badge>
                                  )}
                                </span>
                              }
                              secondary={r.reason || 'No reason recorded'}
                            />
                          </TD>
                          <TD className="hidden md:table-cell">
                            <span className="text-xs text-ink-300">{resourceLabel(r)}</span>
                            {r.duration_minutes ? (
                              <span className="block text-2xs tabular-nums text-ink-500">
                                {r.duration_minutes} min requested
                              </span>
                            ) : null}
                          </TD>
                          <TD className="hidden xl:table-cell">
                            <span
                              className="text-xs text-ink-500"
                              title={formatDateTime(r.created_at, { seconds: true })}
                            >
                              {formatRelativeToNow(r.created_at)}
                            </span>
                          </TD>
                          <TD align="right">
                            <Badge className={JIT_STATUS_BADGE[r.status]}>
                              {JIT_STATUS_LABELS[r.status] || r.status}
                            </Badge>
                          </TD>
                          <TD align="right">
                            {actionable && (
                              <div className="flex items-center justify-end gap-1.5">
                                <Button
                                  size="xs"
                                  variant="primary"
                                  icon={Check}
                                  disabled={busy}
                                  onClick={() => setDecision({ kind: 'approve', item: r })}
                                >
                                  Approve
                                </Button>
                                <Button
                                  size="xs"
                                  variant="dangerOutline"
                                  icon={X}
                                  disabled={busy}
                                  onClick={() => setDecision({ kind: 'deny', item: r })}
                                >
                                  Deny
                                </Button>
                              </div>
                            )}
                          </TD>
                        </TR>
                      )
                    })}
                  </TBody>
                </Table>
                {pagination && (
                  <Pagination
                    page={pagination.page}
                    pageSize={pagination.page_size}
                    total={pagination.total}
                    totalPages={pagination.total_pages}
                    onPageChange={setPage}
                  />
                )}
              </>
            )}
          </QueryState>
        ) : (
          <QueryState
            query={grantsQuery}
            skeleton={<TableSkeleton rows={6} cols={4} />}
            empty={(d) => (d?.grants || []).length === 0}
            emptyState={
              <EmptyState
                icon={Lock}
                title="No grants with this status"
                description="Approved requests become grants and appear here with a live countdown."
              />
            }
          >
            {(data) => (
              <>
                <Table>
                  <THead>
                    <tr>
                      <TH>Holder</TH>
                      <TH className="hidden md:table-cell">Resource</TH>
                      <TH align="right">Time left</TH>
                      <TH align="right">Status</TH>
                      <TH align="right" width="110" />
                    </tr>
                  </THead>
                  <TBody>
                    {(data.grants || []).map((g) => {
                      const id = entityId(g)
                      return (
                        <TR key={id}>
                          <TD>
                            <CellStack
                              primary={requesterLabel(g)}
                              secondary={
                                g.expires_at ? `Expires ${formatDateTime(g.expires_at)}` : 'No expiry recorded'
                              }
                            />
                          </TD>
                          <TD className="hidden md:table-cell">
                            <span className="text-xs text-ink-300">{resourceLabel(g)}</span>
                          </TD>
                          <TD align="right">
                            {g.status === GRANT_STATUS.ACTIVE ? (
                              <GrantCountdown expiresAt={g.expires_at} />
                            ) : (
                              <span className="text-xs text-ink-500">—</span>
                            )}
                          </TD>
                          <TD align="right">
                            <Badge className={GRANT_STATUS_BADGE[g.status]}>{g.status}</Badge>
                          </TD>
                          <TD align="right">
                            {g.status === GRANT_STATUS.ACTIVE && (
                              <Button
                                size="xs"
                                variant="dangerOutline"
                                disabled={busy}
                                onClick={() => setDecision({ kind: 'revoke', item: g })}
                              >
                                Revoke
                              </Button>
                            )}
                          </TD>
                        </TR>
                      )
                    })}
                  </TBody>
                </Table>
                {pagination && (
                  <Pagination
                    page={pagination.page}
                    pageSize={pagination.page_size}
                    total={pagination.total}
                    totalPages={pagination.total_pages}
                    onPageChange={setPage}
                  />
                )}
              </>
            )}
          </QueryState>
        )}
      </Card>

      <ConfirmDialog
        open={!!decision}
        title={decisionCopy.title}
        description={decisionCopy.description}
        confirmLabel={decisionCopy.confirmLabel}
        destructive={decisionCopy.destructive}
        requireReason
        reasonLabel="Decision reason"
        reasonHint="Recorded against the immutable audit record for this request."
        isLoading={busy}
        onConfirm={confirmDecision}
        onCancel={() => setDecision(null)}
      >
        {decision?.item && (
          <div className="space-y-2 rounded-lg border border-surface-700 bg-surface-850 p-3 text-xs">
            <p className="text-ink-300">
              <span className="text-ink-500">Resource:</span> {resourceLabel(decision.item)}
            </p>
            {decision.item.reason && (
              <p className="text-ink-300">
                <span className="text-ink-500">Stated reason:</span> {decision.item.reason}
              </p>
            )}
            {decision.item.duration_minutes ? (
              <p className="tabular-nums text-ink-300">
                <span className="text-ink-500">Window:</span> {decision.item.duration_minutes} minutes
              </p>
            ) : null}
          </div>
        )}
        {decision?.kind === 'approve' && decision.item?.type === 'BREAKGLASS' && (
          <Callout tone="warning" icon={ShieldAlert} title="Break-glass request">
            This bypasses the normal approval path and is reviewed after the fact. Confirm the
            emergency is real before approving.
          </Callout>
        )}
      </ConfirmDialog>
    </div>
  )
}
