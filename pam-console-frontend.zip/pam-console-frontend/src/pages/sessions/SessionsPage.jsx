import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Square, ShieldAlert, Radio, Users, User } from 'lucide-react'
import { listMySessions, endSession } from '../../api/sessions'
import { listSessions, killSession } from '../../api/admin'
import { useAuthStore } from '../../store/authStore'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useTicker } from '../../hooks/useCountdown'
import { entityId, actorLabel, resourceLabel } from '../../lib/entity'
import { formatDateTime, formatDuration, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import { ResourceTypeTile } from '../../components/resources/ResourceTypeIcon'
import {
  PageHeader, Card, Button, Badge, StatusDot, QueryState, TableSkeleton, EmptyState,
  Pagination, Tabs, Toolbar, Checkbox, ConfirmDialog,
  Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'
import { SESSION_STATUS_BADGE, SESSIONS_POLL_MS, DEFAULT_PAGE_SIZE } from '../../config/constants'

/**
 * Live elapsed time for a still-running session.
 *
 * The backend's duration_seconds is only populated once a session ends
 * (session.go's End()), so an ACTIVE row's own value is always 0 — showing
 * it verbatim gives every live session a permanently stuck "0s".
 *
 * FIX over the previous version: this now ticks. Before, the elapsed time
 * only advanced when the 15s poll happened to re-render the row, so a
 * "live" duration visibly jumped in 15-second steps.
 */
function LiveDuration({ session }) {
  const isActive = session.status === 'ACTIVE'
  useTicker(1000, isActive)
  if (!isActive) return <>{formatDuration(session.duration_seconds)}</>
  const elapsed = (Date.now() - new Date(session.started_at).getTime()) / 1000
  return <>{formatDuration(elapsed)}</>
}

export default function SessionsPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [tab, setTab] = useState('mine')
  const [activeOnly, setActiveOnly] = useState(true)
  const [page, setPage] = useState(1)
  const [killTarget, setKillTarget] = useState(null)
  const queryClient = useQueryClient()
  useDocumentTitle('Sessions')

  const changeTab = (next) => {
    setTab(next)
    setPage(1)
  }
  const changeActiveOnly = (next) => {
    setActiveOnly(next)
    setPage(1)
  }

  const mineQuery = useQuery({
    queryKey: ['sessions', 'mine', { page, activeOnly }],
    queryFn: ({ signal }) => listMySessions({ page, pageSize: DEFAULT_PAGE_SIZE, activeOnly, signal }),
    enabled: tab === 'mine',
    // Poll only while looking at active sessions — a completed-session
    // history view has no reason to refetch every 15s.
    refetchInterval: tab === 'mine' && activeOnly ? SESSIONS_POLL_MS : false,
    placeholderData: (prev) => prev,
  })

  const allQuery = useQuery({
    queryKey: ['sessions', 'all', { page, activeOnly }],
    queryFn: ({ signal }) =>
      listSessions(
        { page, page_size: DEFAULT_PAGE_SIZE, active: activeOnly ? 'true' : undefined },
        signal
      ),
    enabled: tab === 'all' && isAdmin,
    refetchInterval: tab === 'all' && activeOnly ? SESSIONS_POLL_MS : false,
    placeholderData: (prev) => prev,
  })

  const activeQuery = tab === 'mine' ? mineQuery : allQuery
  // FIX: org-wide sessions previously had pagination hard-disabled, so an
  // admin could only ever see the first page of a busy environment.
  const pagination = activeQuery.data?.pagination

  const invalidateAll = () => queryClient.invalidateQueries({ queryKey: ['sessions'] })

  const endMutation = useMutation({
    mutationFn: (id) => endSession(id),
    onSuccess: () => {
      toast.success('Session ended')
      invalidateAll()
    },
    onError: (err) => toast.error('Could not end session', { description: apiErrorMessage(err) }),
  })

  const killMutation = useMutation({
    mutationFn: ({ id, reason }) => killSession(id, reason),
    onSuccess: () => {
      toast.success('Session terminated')
      setKillTarget(null)
      invalidateAll()
    },
    onError: (err) => {
      toast.error('Could not terminate session', { description: apiErrorMessage(err) })
      setKillTarget(null)
    },
  })

  const isMutating = endMutation.isPending || killMutation.isPending

  return (
    <div>
      <PageHeader
        title="Sessions"
        description="Tracked connection sessions. The start/end lifecycle is what audit and JIT grant expiry are enforced against — this is not a live terminal."
      />

      <Toolbar className="mb-4">
        <Tabs
          tabs={[
            { key: 'mine', label: 'My sessions', icon: User },
            ...(isAdmin ? [{ key: 'all', label: 'Organization', icon: Users }] : []),
          ]}
          active={tab}
          onChange={changeTab}
        />
        <div className="ml-auto">
          <Checkbox
            label="Active only"
            checked={activeOnly}
            onChange={(e) => changeActiveOnly(e.target.checked)}
          />
        </div>
      </Toolbar>

      <Card>
        <QueryState
          query={activeQuery}
          skeleton={<TableSkeleton rows={6} cols={5} />}
          empty={(d) => (d?.sessions || []).length === 0}
          emptyState={
            <EmptyState
              icon={Radio}
              title={activeOnly ? 'No active sessions' : 'No sessions found'}
              description={
                activeOnly
                  ? 'Connect to a resource to start a tracked session.'
                  : 'No session history matches this view.'
              }
            />
          }
        >
          {(data) => (
            <>
              <Table>
                <THead>
                  <tr>
                    <TH>Resource</TH>
                    {tab === 'all' && <TH className="hidden lg:table-cell">User</TH>}
                    <TH className="hidden md:table-cell">Started</TH>
                    <TH align="right">Duration</TH>
                    <TH align="right">Status</TH>
                    <TH align="right" width="150" />
                  </tr>
                </THead>
                <TBody>
                  {(data.sessions || []).map((s) => {
                    const id = entityId(s)
                    return (
                      <TR key={id}>
                        <TD>
                          <CellStack
                            icon={<ResourceTypeTile type={s.resource_type} size="sm" />}
                            primary={
                              <span className="flex items-center gap-2">
                                {resourceLabel(s)}
                                {s.is_breakglass && (
                                  <Badge tone="danger" size="xs" icon={ShieldAlert}>
                                    Break-glass
                                  </Badge>
                                )}
                              </span>
                            }
                            secondary={s.protocol || s.resource_type || '—'}
                          />
                        </TD>
                        {tab === 'all' && (
                          <TD className="hidden lg:table-cell">
                            <span className="text-xs text-ink-300">{actorLabel(s)}</span>
                          </TD>
                        )}
                        <TD className="hidden md:table-cell">
                          <span
                            className="text-xs text-ink-500"
                            title={formatDateTime(s.started_at, { seconds: true })}
                          >
                            {formatRelativeToNow(s.started_at)}
                          </span>
                        </TD>
                        <TD align="right">
                          <span className="text-xs tabular-nums text-ink-300">
                            <LiveDuration session={s} />
                          </span>
                        </TD>
                        <TD align="right">
                          {s.status === 'ACTIVE' ? (
                            <StatusDot tone="success" label="Active" pulse />
                          ) : (
                            <Badge className={SESSION_STATUS_BADGE[s.status]}>{s.status}</Badge>
                          )}
                        </TD>
                        <TD align="right">
                          {s.status === 'ACTIVE' && (
                            <div className="flex items-center justify-end gap-1.5">
                              <Button
                                size="xs"
                                variant="secondary"
                                disabled={isMutating}
                                onClick={() => endMutation.mutate(id)}
                              >
                                End
                              </Button>
                              {tab === 'all' && (
                                <Button
                                  size="xs"
                                  variant="dangerOutline"
                                  icon={Square}
                                  disabled={isMutating}
                                  onClick={() => setKillTarget(s)}
                                >
                                  Terminate
                                </Button>
                              )}
                            </div>
                          )}
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <ConfirmDialog
        open={!!killTarget}
        title={`Terminate the session on "${resourceLabel(killTarget)}"?`}
        description="This immediately ends another user's tracked session and is recorded in the audit log."
        confirmLabel="Terminate session"
        destructive
        requireReason
        reasonLabel="Reason"
        isLoading={killMutation.isPending}
        onConfirm={(reason) => killMutation.mutate({ id: entityId(killTarget), reason })}
        onCancel={() => setKillTarget(null)}
      />
    </div>
  )
}
