import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'
import { Eye, History, KeyRound, RefreshCw, ShieldAlert } from 'lucide-react'
import { toast } from 'sonner'
import {
  getCredential, createCredentialVersion, passwordChange, requestCredentialRotation,
} from '../../api/vault'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { isUsableId } from '../../lib/entity'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage, applyServerFieldErrors } from '../../lib/apiError'
import { RevealCredentialModal } from '../../components/vault/RevealCredentialModal'
import {
  PageHeader, Card, CardHeader, CardBody, Button, Badge, QueryState, CardSkeleton,
  Field, Textarea, Input, DescriptionList, DescriptionItem, Tabs,
} from '../../ui'

const versionSchema = z.object({
  secret_plaintext: z.string().trim().min(1, 'Required'),
  reason: z.string().optional(),
})

const quickChangeSchema = z.object({
  secret_plaintext: z.string().trim().min(1, 'Required'),
})

function AddVersionForm({ credentialId }) {
  const queryClient = useQueryClient()
  const {
    register, handleSubmit, reset, setError, formState: { errors },
  } = useForm({ resolver: zodResolver(versionSchema) })

  const mutation = useMutation({
    mutationFn: (v) => createCredentialVersion(credentialId, v.secret_plaintext, v.reason),
    onSuccess: () => {
      toast.success('New version stored', { description: 'The previous version is retained for rollback.' })
      queryClient.invalidateQueries({ queryKey: ['vault', 'credentials', credentialId] })
      reset()
    },
    onError: (err) => {
      if (!applyServerFieldErrors(err, setError)) {
        toast.error('Could not store version', { description: apiErrorMessage(err) })
      }
    },
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <form onSubmit={submit} noValidate className="space-y-3.5">
      <Field label="New secret" error={errors.secret_plaintext?.message} required>
        {({ id, ...a }) => (
          <Textarea id={id} {...a} rows={3} className="font-mono text-xs" error={!!errors.secret_plaintext} {...register('secret_plaintext')} />
        )}
      </Field>
      <Field label="Reason" hint="Optional — stored alongside the new version in the audit trail.">
        {({ id, ...a }) => <Input id={id} {...a} placeholder="e.g. quarterly rotation" {...register('reason')} />}
      </Field>
      <Button type="submit" variant="primary" icon={History} loading={mutation.isPending} onClick={submit}>
        Add version
      </Button>
    </form>
  )
}

function QuickChangeForm({ credentialId }) {
  const queryClient = useQueryClient()
  const {
    register, handleSubmit, reset, formState: { errors },
  } = useForm({ resolver: zodResolver(quickChangeSchema) })

  const mutation = useMutation({
    mutationFn: (v) => passwordChange(credentialId, v.secret_plaintext),
    onSuccess: () => {
      toast.success('Password changed')
      queryClient.invalidateQueries({ queryKey: ['vault', 'credentials', credentialId] })
      reset()
    },
    onError: (err) => toast.error('Could not change password', { description: apiErrorMessage(err) }),
  })

  const submit = handleSubmit((v) => mutation.mutate(v))

  return (
    <form onSubmit={submit} noValidate className="space-y-3.5">
      <Field
        label="New secret"
        error={errors.secret_plaintext?.message}
        hint="Records the same audit trail as Add version, with a fixed reason of 'Manual password change'."
        required
      >
        {({ id, ...a }) => (
          <Textarea id={id} {...a} rows={3} className="font-mono text-xs" error={!!errors.secret_plaintext} {...register('secret_plaintext')} />
        )}
      </Field>
      <Button type="submit" variant="secondary" icon={KeyRound} loading={mutation.isPending} onClick={submit}>
        Quick password change
      </Button>
    </form>
  )
}

export default function CredentialDetailPage() {
  const { safeId, credentialId } = useParams()
  const queryClient = useQueryClient()
  const [revealOpen, setRevealOpen] = useState(false)
  const [updateTab, setUpdateTab] = useState('version')

  const credentialQuery = useQuery({
    queryKey: ['vault', 'credentials', credentialId],
    queryFn: ({ signal }) => getCredential(credentialId, signal),
    enabled: isUsableId(credentialId),
  })

  useDocumentTitle(credentialQuery.data?.name || 'Credential')

  const rotationMutation = useMutation({
    mutationFn: () => requestCredentialRotation(credentialId),
    onSuccess: (job) => {
      toast.success(`Rotation ${job?.status === 'pending' ? 'queued' : job?.status || 'requested'}`)
      queryClient.invalidateQueries({ queryKey: ['vault', 'credentials', credentialId] })
    },
    // A 409 means a rotation is already in progress (ErrRotationInProgress).
    // The generic 409 message covers it clearly enough; the button being
    // disabled while pending prevents most double-submits reaching the
    // server at all.
    onError: (err) => toast.error('Rotation request failed', { description: apiErrorMessage(err) }),
  })

  return (
    <div>
      <QueryState query={credentialQuery} skeleton={<CardSkeleton lines={6} />}>
        {(cred) => (
          <>
            <PageHeader
              breadcrumbs={[
                { label: 'Vault', to: '/vault' },
                { label: 'Safe', to: `/vault/${safeId}` },
                { label: cred.name },
              ]}
              title={cred.name}
              description={`${cred.account_name} · ${cred.credential_type}`}
              meta={
                <>
                  <Badge tone={cred.status === 'active' ? 'success' : 'neutral'}>{cred.status}</Badge>
                  <span className="text-xs text-ink-500">Version {cred.version}</span>
                  {cred.is_breakglass && (
                    <Badge tone="danger" icon={ShieldAlert}>
                      {cred.breakglass_note || 'Emergency-access credential'}
                    </Badge>
                  )}
                </>
              }
              actions={
                <Button variant="warning" icon={Eye} onClick={() => setRevealOpen(true)}>
                  Reveal
                </Button>
              }
            />

            <div className="grid gap-5 lg:grid-cols-2">
              <Card>
                <CardHeader title="Lifecycle" />
                <CardBody className="space-y-4">
                  <DescriptionList cols="140px 1fr">
                    <DescriptionItem label="Rotation interval">
                      {cred.rotation_interval_days > 0
                        ? `${cred.rotation_interval_days} days`
                        : 'Manual only'}
                    </DescriptionItem>
                    <DescriptionItem label="Last rotated">
                      {cred.last_rotated_at ? (
                        <span title={formatDateTime(cred.last_rotated_at, { seconds: true })}>
                          {formatRelativeToNow(cred.last_rotated_at)}
                        </span>
                      ) : (
                        'Never'
                      )}
                    </DescriptionItem>
                    <DescriptionItem label="Next rotation">
                      {formatDateTime(cred.next_rotation_at)}
                    </DescriptionItem>
                    <DescriptionItem label="Created">{formatDateTime(cred.created_at)}</DescriptionItem>
                  </DescriptionList>

                  <div className="border-t border-surface-700 pt-4">
                    <Button
                      variant="secondary"
                      icon={RefreshCw}
                      loading={rotationMutation.isPending}
                      onClick={() => rotationMutation.mutate()}
                    >
                      Request rotation now
                    </Button>
                    <p className="mt-2 text-xs text-ink-500">
                      Queues a rotation job. Any active session using this credential keeps working
                      until it ends.
                    </p>
                  </div>
                </CardBody>
              </Card>

              <Card>
                <CardHeader title="Update secret" />
                <CardBody className="space-y-4">
                  <Tabs
                    tabs={[
                      { key: 'version', label: 'Add version', icon: History },
                      { key: 'quick', label: 'Quick change', icon: KeyRound },
                    ]}
                    active={updateTab}
                    onChange={setUpdateTab}
                  />
                  {updateTab === 'version' ? (
                    <AddVersionForm credentialId={credentialId} />
                  ) : (
                    <QuickChangeForm credentialId={credentialId} />
                  )}
                </CardBody>
              </Card>
            </div>

            <RevealCredentialModal
              open={revealOpen}
              onClose={() => setRevealOpen(false)}
              credentialId={credentialId}
              accountName={cred.account_name}
            />
          </>
        )}
      </QueryState>
    </div>
  )
}
