import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight, Vault as VaultIcon } from 'lucide-react'
import { listSafes } from '../../api/vault'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId } from '../../lib/entity'
import { CreateSafeModal } from '../../components/vault/CreateSafeModal'
import {
  PageHeader, Card, Button, Badge, QueryState, TableSkeleton, EmptyState,
  NoResultsState, SearchInput, Toolbar, Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'

export default function SafesListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [search, setSearch] = useState('')
  useDocumentTitle('Vault')

  const safesQuery = useQuery({
    queryKey: ['vault', 'safes'],
    queryFn: ({ signal }) => listSafes(signal),
  })

  const filtered = useMemo(() => {
    const safes = safesQuery.data || []
    const term = search.trim().toLowerCase()
    if (!term) return safes
    return safes.filter((s) =>
      [s.name, s.description].filter(Boolean).some((v) => String(v).toLowerCase().includes(term))
    )
  }, [safesQuery.data, search])

  return (
    <div>
      <PageHeader
        title="Vault"
        description="Safes group credentials by ownership and retention policy. Every reveal is justified and recorded."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create safe
          </Button>
        }
      />

      <Toolbar className="mb-4">
        <SearchInput value={search} onChange={setSearch} placeholder="Search safes…" className="w-full max-w-xs" />
        <span className="ml-auto text-xs tabular-nums text-ink-500">
          {filtered.length} {filtered.length === 1 ? 'safe' : 'safes'}
        </span>
      </Toolbar>

      <Card>
        <QueryState
          query={safesQuery}
          skeleton={<TableSkeleton rows={4} cols={3} />}
          empty={(safes) => !safes || safes.length === 0}
          emptyState={
            <EmptyState
              icon={VaultIcon}
              title="No safes yet"
              description="Create a safe to start storing credentials under a retention policy."
              action={
                <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
                  Create safe
                </Button>
              }
            />
          }
        >
          {() =>
            filtered.length === 0 ? (
              <NoResultsState onClear={() => setSearch('')} />
            ) : (
              <Table>
                <THead>
                  <tr>
                    <TH>Safe</TH>
                    <TH align="right" className="hidden sm:table-cell">Retention</TH>
                    <TH width="44" />
                  </tr>
                </THead>
                <TBody>
                  {filtered.map((safe) => {
                    const id = entityId(safe)
                    return (
                      <TR key={id} interactive>
                        <TD className="p-0">
                          <Link to={id ? `/vault/${id}` : '#'} className="flex items-center px-4 py-3">
                            <CellStack
                              icon={
                                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-800 text-ink-400">
                                  <VaultIcon className="h-4 w-4" aria-hidden="true" />
                                </span>
                              }
                              primary={
                                <span className="flex items-center gap-2">
                                  {safe.name}
                                  {safe.is_default && <Badge tone="brand" size="xs">Default</Badge>}
                                </span>
                              }
                              secondary={safe.description || 'No description'}
                            />
                          </Link>
                        </TD>
                        <TD align="right" className="hidden sm:table-cell">
                          <span className="text-xs tabular-nums text-ink-400">{safe.retention_days}d</span>
                        </TD>
                        <TD align="right">
                          <ChevronRight className="h-4 w-4 text-ink-600" aria-hidden="true" />
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
            )
          }
        </QueryState>
      </Card>

      <CreateSafeModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
