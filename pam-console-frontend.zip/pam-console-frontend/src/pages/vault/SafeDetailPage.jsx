import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useParams, Link } from 'react-router-dom'
import { Plus, FolderTree, KeyRound, ChevronRight, ShieldAlert } from 'lucide-react'
import { getSafe, listFolders, listCredentials } from '../../api/vault'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { entityId, isUsableId } from '../../lib/entity'
import { formatRelativeToNow } from '../../lib/format'
import { CreateFolderModal } from '../../components/vault/CreateFolderModal'
import { CreateCredentialModal } from '../../components/vault/CreateCredentialModal'
import {
  PageHeader, Card, CardHeader, Button, IconButton, Badge, QueryState, TableSkeleton,
  CardSkeleton, EmptyState, Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'

function CredentialStatusBadge({ status }) {
  return (
    <Badge tone={status === 'active' ? 'success' : 'neutral'}>{status || 'unknown'}</Badge>
  )
}

export default function SafeDetailPage() {
  const { safeId } = useParams()
  const [folderModalOpen, setFolderModalOpen] = useState(false)
  const [credentialModalOpen, setCredentialModalOpen] = useState(false)

  const safeQuery = useQuery({
    queryKey: ['vault', 'safes', safeId],
    queryFn: ({ signal }) => getSafe(safeId, signal),
    enabled: isUsableId(safeId),
  })
  const foldersQuery = useQuery({
    queryKey: ['vault', 'safes', safeId, 'folders'],
    queryFn: ({ signal }) => listFolders(safeId, signal),
    enabled: isUsableId(safeId),
  })
  const credentialsQuery = useQuery({
    queryKey: ['vault', 'safes', safeId, 'credentials'],
    queryFn: ({ signal }) => listCredentials(safeId, signal),
    enabled: isUsableId(safeId),
  })

  useDocumentTitle(safeQuery.data?.name || 'Safe')

  return (
    <div>
      <QueryState query={safeQuery} skeleton={<CardSkeleton lines={3} />}>
        {(safe) => (
          <PageHeader
            breadcrumbs={[{ label: 'Vault', to: '/vault' }, { label: safe.name }]}
            title={safe.name}
            description={safe.description || 'No description'}
            meta={
              <>
                <Badge tone="neutral">{safe.retention_days}d retention</Badge>
                {safe.is_default && <Badge tone="brand">Default safe</Badge>}
              </>
            }
            actions={
              <Button variant="primary" icon={Plus} onClick={() => setCredentialModalOpen(true)}>
                Store credential
              </Button>
            }
          />
        )}
      </QueryState>

      <div className="grid gap-5 lg:grid-cols-[16rem_1fr]">
        <Card className="h-fit">
          <CardHeader>
            <div className="flex items-center justify-between gap-2">
              <h3 className="flex items-center gap-1.5 text-sm font-semibold text-ink-50">
                <FolderTree className="h-4 w-4 text-ink-400" aria-hidden="true" /> Folders
              </h3>
              <IconButton icon={Plus} label="Create folder" size="sm" onClick={() => setFolderModalOpen(true)} />
            </div>
          </CardHeader>
          <QueryState
            query={foldersQuery}
            skeleton={<CardSkeleton lines={3} />}
            empty={(f) => !f || f.length === 0}
            emptyState={<EmptyState compact icon={FolderTree} title="No folders" description="Credentials sit at the safe root." />}
          >
            {(folders) => (
              <ul className="divide-y divide-surface-700">
                {folders.map((f) => (
                  <li key={entityId(f)} className="px-4 py-2.5">
                    <p className="truncate text-sm font-medium text-ink-100">{f.name}</p>
                    <p className="truncate font-mono text-2xs text-ink-500" title={f.path}>
                      {f.path}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </Card>

        <Card>
          <CardHeader
            title="Credentials"
            actions={
              <Button size="sm" variant="secondary" icon={Plus} onClick={() => setCredentialModalOpen(true)}>
                Store credential
              </Button>
            }
          />
          <QueryState
            query={credentialsQuery}
            skeleton={<TableSkeleton rows={5} cols={4} />}
            empty={(c) => !c || c.length === 0}
            emptyState={
              <EmptyState
                icon={KeyRound}
                title="No credentials in this safe"
                description="Store the first credential to make it available for brokered connections."
                action={
                  <Button variant="primary" icon={Plus} onClick={() => setCredentialModalOpen(true)}>
                    Store credential
                  </Button>
                }
              />
            }
          >
            {(credentials) => (
              <Table>
                <THead>
                  <tr>
                    <TH>Credential</TH>
                    <TH className="hidden md:table-cell">Last rotated</TH>
                    <TH align="right">Status</TH>
                    <TH width="44" />
                  </tr>
                </THead>
                <TBody>
                  {credentials.map((c) => {
                    const id = entityId(c)
                    return (
                      <TR key={id} interactive>
                        <TD className="p-0">
                          <Link
                            to={id ? `/vault/${safeId}/credentials/${id}` : '#'}
                            className="flex items-center px-4 py-3"
                          >
                            <CellStack
                              icon={
                                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-800 text-ink-400">
                                  <KeyRound className="h-4 w-4" aria-hidden="true" />
                                </span>
                              }
                              primary={
                                <span className="flex items-center gap-2">
                                  {c.name}
                                  {c.is_breakglass && (
                                    <Badge tone="danger" size="xs" icon={ShieldAlert}>
                                      Break-glass
                                    </Badge>
                                  )}
                                </span>
                              }
                              secondary={`${c.account_name} · ${c.credential_type}`}
                            />
                          </Link>
                        </TD>
                        <TD className="hidden md:table-cell">
                          <span className="text-xs text-ink-500">
                            {c.last_rotated_at ? formatRelativeToNow(c.last_rotated_at) : 'Never'}
                          </span>
                        </TD>
                        <TD align="right">
                          <CredentialStatusBadge status={c.status} />
                        </TD>
                        <TD align="right">
                          <ChevronRight className="h-4 w-4 text-ink-600" aria-hidden="true" />
                        </TD>
                      </TR>
                    )
                  })}
                </TBody>
              </Table>
            )}
          </QueryState>
        </Card>
      </div>

      <CreateFolderModal open={folderModalOpen} onClose={() => setFolderModalOpen(false)} safeId={safeId} />
      <CreateCredentialModal
        open={credentialModalOpen}
        onClose={() => setCredentialModalOpen(false)}
        safeId={safeId}
      />
    </div>
  )
}
