import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ShieldCheck, User } from 'lucide-react'
import { me } from '../api/auth'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import { MfaEnrollment } from '../components/auth/MfaEnrollment'
import { AgentDevicesPanel } from '../components/agent/AgentDevicesPanel'
import { ROLE_BADGE } from '../config/constants'
import {
  PageHeader, Card, CardHeader, CardBody, Badge, QueryState, CardSkeleton,
  DescriptionList, DescriptionItem, Callout,
} from '../ui'

export default function SettingsPage() {
  const queryClient = useQueryClient()
  const [justEnrolled, setJustEnrolled] = useState(false)
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal) })
  useDocumentTitle('Settings')

  const mfaActive = justEnrolled || meQuery.data?.mfa_enabled

  return (
    <div>
      <PageHeader
        title="Settings"
        description="Your account, multi-factor authentication, and paired desktop agents."
      />

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          {justEnrolled ? (
            <Card>
              <CardHeader title="Two-factor authentication" />
              <CardBody>
                <Callout tone="success" icon={ShieldCheck} title="MFA is active on your account">
                  Sensitive actions such as revealing a credential or approving a request will now
                  prompt for your authenticator code.
                </Callout>
              </CardBody>
            </Card>
          ) : (
            <MfaEnrollment
              onEnrolled={() => {
                setJustEnrolled(true)
                queryClient.invalidateQueries({ queryKey: ['me'] })
                toast.success('Two-factor authentication enabled')
              }}
            />
          )}

          <AgentDevicesPanel />
        </div>

        <Card className="h-fit">
          <CardHeader title="Account" />
          <QueryState query={meQuery} skeleton={<CardSkeleton lines={4} />}>
            {(data) => (
              <CardBody>
                <div className="mb-4 flex items-center gap-3">
                  <span className="flex h-11 w-11 flex-none items-center justify-center rounded-full bg-brand-600 text-sm font-semibold uppercase text-white">
                    {(data.username || '?').slice(0, 2)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink-50">{data.username}</p>
                    <p className="truncate text-xs text-ink-500">{data.email}</p>
                  </div>
                </div>

                <DescriptionList cols="90px 1fr">
                  <DescriptionItem label="Roles">
                    <div className="flex flex-wrap gap-1">
                      {(data.roles || []).length === 0 && <span className="text-ink-500">None</span>}
                      {(data.roles || []).map((r) => (
                        <Badge key={r} className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                          {r}
                        </Badge>
                      ))}
                    </div>
                  </DescriptionItem>
                  <DescriptionItem label="MFA">
                    {data.mfa_verified ? (
                      <Badge tone="success">Verified this session</Badge>
                    ) : mfaActive ? (
                      <Badge tone="warning">Enrolled, not verified this session</Badge>
                    ) : (
                      <Badge tone="neutral">Not enrolled</Badge>
                    )}
                  </DescriptionItem>
                </DescriptionList>

                {!data.mfa_verified && (
                  <p className="mt-4 border-t border-surface-700 pt-3 text-xs leading-relaxed text-ink-500">
                    <User className="mr-1 inline h-3 w-3 align-[-2px]" aria-hidden="true" />
                    Revealing credentials and approving requests require MFA to have been verified
                    in the current session.
                  </p>
                )}
              </CardBody>
            )}
          </QueryState>
        </Card>
      </div>
    </div>
  )
}
