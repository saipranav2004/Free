import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'
import { toast } from 'sonner'
import { ShieldAlert, Clock, CheckCircle2, XCircle, Hourglass } from 'lucide-react'
import { getJitRequest, cancelJitRequest } from '../../api/jit'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useCountdown } from '../../hooks/useCountdown'
import { isUsableId, resourceLabel } from '../../lib/entity'
import { formatDateTime, formatDuration, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  PageHeader, Card, CardHeader, CardBody, Button, Badge, QueryState, CardSkeleton,
  ConfirmDialog, DescriptionList, DescriptionItem, Callout, EmptyState,
} from '../../ui'
import { JIT_STATUS, JIT_STATUS_LABELS, JIT_STATUS_BADGE, GRANT_STATUS_BADGE } from '../../config/constants'

const CANCELLABLE = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

// The field a resulting grant is nested under is not pinned down by the
// contract available here, so check the shapes that would make sense and
// otherwise fall back to an expiry-looking field on the request itself, so
// the countdown still works even if the nesting name differs.
function extractGrant(request) {
  if (!request) return null
  if (request.grant) return request.grant
  if (Array.isArray(request.grants) && request.grants.length > 0) return request.grants[0]
  return null
}

function Countdown({ targetIso }) {
  const { remainingSec, expired, unknown } = useCountdown(targetIso)
  if (unknown) return <span className="text-ink-500">—</span>
  if (expired) return <span className="text-ink-500">Expired</span>
  return (
    <span className="inline-flex items-center gap-1.5 font-medium tabular-nums text-emerald-600 dark:text-emerald-400">
      <Clock className="h-3.5 w-3.5" aria-hidden="true" />
      {formatDuration(remainingSec)} remaining
    </span>
  )
}

/** Vertical status timeline — an operator reading a request needs the story
 *  (raised → decided → active → expires), not a flat key/value dump. */
function Timeline({ request, grant }) {
  const steps = [
    {
      key: 'requested',
      label: 'Requested',
      at: request?.created_at,
      icon: Hourglass,
      tone: 'neutral',
      done: true,
    },
  ]

  if (request?.approved_at) {
    steps.push({ key: 'approved', label: 'Approved', at: request.approved_at, icon: CheckCircle2, tone: 'success', done: true })
  } else if (request?.denied_at) {
    steps.push({ key: 'denied', label: 'Denied', at: request.denied_at, icon: XCircle, tone: 'danger', done: true })
  } else if (request?.status === JIT_STATUS.WAITING) {
    steps.push({ key: 'waiting', label: 'Cooling-off period', at: request?.available_at, icon: Hourglass, tone: 'warning', done: false })
  } else if (request?.status === JIT_STATUS.PENDING) {
    steps.push({ key: 'pending', label: 'Awaiting an approver', at: null, icon: Hourglass, tone: 'warning', done: false })
  }

  if (grant?.expires_at) {
    steps.push({ key: 'expires', label: 'Access expires', at: grant.expires_at, icon: Clock, tone: 'neutral', done: false })
  }

  const toneColor = {
    neutral: 'bg-surface-700 text-ink-300',
    success: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400',
    danger: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-400',
    warning: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400',
  }

  return (
    <ol className="relative space-y-5 pl-1">
      {steps.map((s, i) => (
        <li key={s.key} className="relative flex gap-3.5">
          {i < steps.length - 1 && (
            <span className="absolute left-[0.9375rem] top-8 h-[calc(100%+0.5rem)] w-px bg-surface-700" aria-hidden="true" />
          )}
          <span
            className={
              'relative z-10 flex h-8 w-8 flex-none items-center justify-center rounded-full ' +
              toneColor[s.tone]
            }
          >
            <s.icon className="h-4 w-4" aria-hidden="true" />
          </span>
          <div className="min-w-0 pt-1">
            <p className="text-sm font-medium text-ink-100">{s.label}</p>
            <p className="mt-0.5 text-xs text-ink-500">
              {s.at ? (
                <span title={formatDateTime(s.at, { seconds: true })}>
                  {formatDateTime(s.at)} · {formatRelativeToNow(s.at)}
                </span>
              ) : (
                'Not yet'
              )}
            </p>
          </div>
        </li>
      ))}
    </ol>
  )
}

export default function JitRequestDetailPage() {
  const { id } = useParams()
  const queryClient = useQueryClient()
  const [cancelOpen, setCancelOpen] = useState(false)

  const requestQuery = useQuery({
    queryKey: ['jit', 'requests', id],
    queryFn: ({ signal }) => getJitRequest(id, signal),
    enabled: isUsableId(id),
    // Poll while the outcome is still moving, so a user watching an approval
    // does not have to refresh manually.
    refetchInterval: (query) => {
      const status = query.state.data?.status
      return status === JIT_STATUS.PENDING || status === JIT_STATUS.WAITING ? 15_000 : false
    },
  })

  useDocumentTitle('Access request')

  const cancelMutation = useMutation({
    mutationFn: (reason) => cancelJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request withdrawn')
      setCancelOpen(false)
      queryClient.invalidateQueries({ queryKey: ['jit'] })
    },
    onError: (err) => {
      toast.error('Could not cancel request', { description: apiErrorMessage(err) })
      setCancelOpen(false)
    },
  })

  return (
    <div>
      <QueryState query={requestQuery} skeleton={<CardSkeleton lines={6} />}>
        {(request) => {
          const grant = extractGrant(request)
          const isBreakglass = request?.type === 'BREAKGLASS'
          const expiryIso = grant?.expires_at || request?.expires_at || null
          const canCancel = CANCELLABLE.includes(request?.status)

          return (
            <>
              <PageHeader
                breadcrumbs={[{ label: 'JIT Access', to: '/jit' }, { label: 'Request' }]}
                title={
                  <>
                    {isBreakglass && (
                      <ShieldAlert className="h-5 w-5 flex-none text-red-600 dark:text-red-400" aria-hidden="true" />
                    )}
                    <span className="truncate">{resourceLabel(request)}</span>
                  </>
                }
                description={
                  isBreakglass
                    ? 'Break-glass emergency access request'
                    : 'Time-boxed access request'
                }
                meta={
                  <>
                    <Badge className={JIT_STATUS_BADGE[request?.status]}>
                      {JIT_STATUS_LABELS[request?.status] || request?.status || '—'}
                    </Badge>
                    {request?.duration_minutes && (
                      <span className="text-xs text-ink-500">{request.duration_minutes} minute window</span>
                    )}
                    {request?.ticket_ref && (
                      <span className="text-xs text-ink-500">Ticket {request.ticket_ref}</span>
                    )}
                  </>
                }
                actions={
                  canCancel && (
                    <Button variant="dangerOutline" onClick={() => setCancelOpen(true)}>
                      Withdraw request
                    </Button>
                  )
                }
              />

              {isBreakglass && request?.status === JIT_STATUS.WAITING && (
                <Callout tone="warning" icon={Hourglass} title="Cooling-off period in progress" className="mb-5">
                  Access is not active yet. An administrator can still revoke this request before it
                  becomes usable.
                </Callout>
              )}

              <div className="grid gap-5 lg:grid-cols-3">
                <Card className="lg:col-span-2">
                  <CardHeader title="Request details" />
                  <CardBody>
                    <DescriptionList cols="150px 1fr">
                      <DescriptionItem label="Resource">{resourceLabel(request)}</DescriptionItem>
                      <DescriptionItem label="Type">
                        {isBreakglass ? (
                          <span className="inline-flex items-center gap-1.5 text-red-600 dark:text-red-400">
                            <ShieldAlert className="h-3.5 w-3.5" aria-hidden="true" /> Break-glass
                          </span>
                        ) : (
                          'Standard'
                        )}
                      </DescriptionItem>
                      <DescriptionItem label="Action">{request?.action}</DescriptionItem>
                      <DescriptionItem label="Requested duration">
                        {request?.duration_minutes ? `${request.duration_minutes} minutes` : null}
                      </DescriptionItem>
                      <DescriptionItem label="Reason">{request?.reason}</DescriptionItem>
                      <DescriptionItem label="Ticket reference">{request?.ticket_ref}</DescriptionItem>
                      {request?.decision_reason && (
                        <DescriptionItem label="Decision note">{request.decision_reason}</DescriptionItem>
                      )}
                    </DescriptionList>
                  </CardBody>
                </Card>

                <div className="space-y-5">
                  <Card>
                    <CardHeader title="Progress" />
                    <CardBody>
                      <Timeline request={request} grant={grant} />
                    </CardBody>
                  </Card>

                  <Card>
                    <CardHeader title="Resulting grant" />
                    <CardBody>
                      {grant ? (
                        <DescriptionList cols="110px 1fr">
                          <DescriptionItem label="Status">
                            <Badge className={GRANT_STATUS_BADGE[grant.status]}>{grant.status || '—'}</Badge>
                          </DescriptionItem>
                          <DescriptionItem label="Expires">{formatDateTime(grant.expires_at)}</DescriptionItem>
                          <DescriptionItem label="Time left">
                            <Countdown targetIso={grant.expires_at} />
                          </DescriptionItem>
                        </DescriptionList>
                      ) : expiryIso ? (
                        <DescriptionList cols="110px 1fr">
                          <DescriptionItem label="Expires">{formatDateTime(expiryIso)}</DescriptionItem>
                          <DescriptionItem label="Time left">
                            <Countdown targetIso={expiryIso} />
                          </DescriptionItem>
                        </DescriptionList>
                      ) : (
                        <EmptyState
                          compact
                          icon={Clock}
                          title="No grant yet"
                          description="A grant appears here once this request is approved."
                        />
                      )}
                    </CardBody>
                  </Card>
                </div>
              </div>

              <ConfirmDialog
                open={cancelOpen}
                title="Withdraw this request?"
                description="This withdraws the request. You can submit a new one later if you still need access."
                confirmLabel="Withdraw request"
                destructive
                requireReason
                reasonLabel="Reason"
                isLoading={cancelMutation.isPending}
                onConfirm={(reason) => cancelMutation.mutate(reason)}
                onCancel={() => setCancelOpen(false)}
              />
            </>
          )
        }}
      </QueryState>
    </div>
  )
}
