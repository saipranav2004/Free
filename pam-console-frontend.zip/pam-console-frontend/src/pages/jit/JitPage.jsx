import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link, useSearchParams } from 'react-router-dom'
import { toast } from 'sonner'
import { Plus, ShieldAlert, KeyRound, Lock, Clock, ChevronRight } from 'lucide-react'
import { listMyJitRequests, listMyGrants, cancelJitRequest } from '../../api/jit'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useCountdown } from '../../hooks/useCountdown'
import { entityId, resourceLabel } from '../../lib/entity'
import { formatDateTime, formatDuration, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import { CreateJitRequestModal } from '../../components/jit/CreateJitRequestModal'
import {
  PageHeader, Card, Button, Badge, QueryState, TableSkeleton, EmptyState,
  Pagination, Tabs, Toolbar, FilterSelect, ConfirmDialog,
  Table, THead, TH, TBody, TR, TD, CellStack,
} from '../../ui'
import {
  JIT_STATUS, JIT_STATUS_LABELS, JIT_STATUS_BADGE,
  GRANT_STATUS, GRANT_STATUS_BADGE, DEFAULT_PAGE_SIZE,
} from '../../config/constants'

// The only states a self-service user can still back out of. Anything
// already APPROVED/DENIED/CANCELLED/EXPIRED is settled and the backend's own
// cancel endpoint would 409.
const CANCELLABLE = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

function GrantCountdown({ expiresAt }) {
  const { remainingSec, expired, unknown } = useCountdown(expiresAt)
  if (unknown) return <span className="text-xs text-ink-500">—</span>
  if (expired) return <span className="text-xs text-ink-500">Expired</span>
  const urgent = remainingSec < 300
  return (
    <span
      className={
        'inline-flex items-center gap-1.5 text-xs font-medium tabular-nums ' +
        (urgent ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400')
      }
    >
      <Clock className="h-3.5 w-3.5" aria-hidden="true" />
      {formatDuration(remainingSec)}
    </span>
  )
}

export default function JitPage() {
  const [searchParams] = useSearchParams()
  const deepLinkedResource = searchParams.get('resourceId')

  const [tab, setTab] = useState('requests')
  const [requestStatus, setRequestStatus] = useState('')
  const [grantStatus, setGrantStatus] = useState('')
  const [page, setPage] = useState(1)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalBreakglass, setModalBreakglass] = useState(false)
  const [cancelTarget, setCancelTarget] = useState(null)
  const queryClient = useQueryClient()
  useDocumentTitle('JIT Access')

  // Arriving from a JIT-gated resource opens the request form pre-filled,
  // instead of dropping the user on a list and making them find the button.
  useEffect(() => {
    if (deepLinkedResource) {
      setModalBreakglass(false)
      setModalOpen(true)
    }
  }, [deepLinkedResource])

  // Reset to page 1 on any change that reshapes the result set — otherwise a
  // stale page number carries into a set with fewer pages and the fetch asks
  // for a page that no longer exists.
  const changeTab = (next) => {
    setTab(next)
    setPage(1)
  }

  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', { page, status: requestStatus }],
    queryFn: ({ signal }) =>
      listMyJitRequests({ page, pageSize: DEFAULT_PAGE_SIZE, status: requestStatus || undefined, signal }),
    enabled: tab === 'requests',
    placeholderData: (prev) => prev,
  })

  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', { page, status: grantStatus }],
    queryFn: ({ signal }) =>
      listMyGrants({ page, pageSize: DEFAULT_PAGE_SIZE, status: grantStatus || undefined, signal }),
    enabled: tab === 'grants',
    placeholderData: (prev) => prev,
  })

  const activeQuery = tab === 'requests' ? requestsQuery : grantsQuery
  const pagination = activeQuery.data?.pagination

  const cancelMutation = useMutation({
    mutationFn: ({ id, reason }) => cancelJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request withdrawn')
      setCancelTarget(null)
      queryClient.invalidateQueries({ queryKey: ['jit'] })
    },
    onError: (err) => {
      toast.error('Could not cancel request', { description: apiErrorMessage(err) })
      setCancelTarget(null)
    },
  })

  return (
    <div>
      <PageHeader
        title="Just-in-Time Access"
        description="Request time-boxed access to gated resources. Grants revoke themselves when they expire."
        actions={
          <>
            <Button
              variant="dangerOutline"
              icon={ShieldAlert}
              onClick={() => {
                setModalBreakglass(true)
                setModalOpen(true)
              }}
            >
              Emergency access
            </Button>
            <Button
              variant="primary"
              icon={Plus}
              onClick={() => {
                setModalBreakglass(false)
                setModalOpen(true)
              }}
            >
              New request
            </Button>
          </>
        }
      />

      <Toolbar className="mb-4">
        <Tabs
          tabs={[
            { key: 'requests', label: 'My requests', icon: KeyRound },
            { key: 'grants', label: 'My grants', icon: Lock },
          ]}
          active={tab}
          onChange={changeTab}
        />
        <div className="ml-auto">
          {tab === 'requests' ? (
            <FilterSelect
              label="Status"
              value={requestStatus}
              onChange={(v) => {
                setRequestStatus(v)
                setPage(1)
              }}
              options={Object.values(JIT_STATUS).map((s) => ({ value: s, label: JIT_STATUS_LABELS[s] || s }))}
              allLabel="All statuses"
            />
          ) : (
            <FilterSelect
              label="Status"
              value={grantStatus}
              onChange={(v) => {
                setGrantStatus(v)
                setPage(1)
              }}
              options={Object.values(GRANT_STATUS)}
              allLabel="All statuses"
            />
          )}
        </div>
      </Toolbar>

      <Card>
        {tab === 'requests' ? (
          <QueryState
            query={requestsQuery}
            skeleton={<TableSkeleton rows={6} cols={4} />}
            empty={(d) => (d?.requests || []).length === 0}
            emptyState={
              <EmptyState
                icon={KeyRound}
                title={requestStatus ? 'No requests with this status' : 'No access requests yet'}
                description="Request time-boxed access when you need to reach a gated resource."
                action={
                  <Button variant="primary" icon={Plus} onClick={() => setModalOpen(true)}>
                    New request
                  </Button>
                }
              />
            }
          >
            {(data) => (
              <>
                <Table>
                  <THead>
                    <tr>
                      <TH>Resource</TH>
                      <TH className="hidden lg:table-cell">Requested</TH>
                      <TH align="right">Status</TH>
                      <TH align="right" width="140" />
                    </tr>
                  </THead>
                  <TBody>
                    {(data.requests || []).map((r) => {
                      const id = entityId(r)
                      return (
                        <TR key={id}>
                          <TD className="p-0">
                            <Link to={id ? `/jit/requests/${id}` : '#'} className="block px-4 py-3">
                              <CellStack
                                primary={
                                  <span className="flex items-center gap-2">
                                    {resourceLabel(r)}
                                    {r.type === 'BREAKGLASS' && (
                                      <Badge tone="danger" size="xs" icon={ShieldAlert}>
                                        Break-glass
                                      </Badge>
                                    )}
                                  </span>
                                }
                                secondary={r.reason || 'No reason recorded'}
                              />
                            </Link>
                          </TD>
                          <TD className="hidden lg:table-cell">
                            <span className="text-xs text-ink-500" title={formatDateTime(r.created_at, { seconds: true })}>
                              {formatRelativeToNow(r.created_at)}
                            </span>
                          </TD>
                          <TD align="right">
                            <Badge className={JIT_STATUS_BADGE[r.status]}>
                              {JIT_STATUS_LABELS[r.status] || r.status}
                            </Badge>
                          </TD>
                          <TD align="right">
                            <div className="flex items-center justify-end gap-1.5">
                              {CANCELLABLE.includes(r.status) && (
                                <Button
                                  size="xs"
                                  variant="dangerOutline"
                                  onClick={() => setCancelTarget(r)}
                                  disabled={cancelMutation.isPending}
                                >
                                  Withdraw
                                </Button>
                              )}
                              <Link to={id ? `/jit/requests/${id}` : '#'} aria-label="Open request">
                                <ChevronRight className="h-4 w-4 text-ink-600" aria-hidden="true" />
                              </Link>
                            </div>
                          </TD>
                        </TR>
                      )
                    })}
                  </TBody>
                </Table>
                {pagination && <Pagination {...pagination} pageSize={pagination.page_size} totalPages={pagination.total_pages} onPageChange={setPage} />}
              </>
            )}
          </QueryState>
        ) : (
          <QueryState
            query={grantsQuery}
            skeleton={<TableSkeleton rows={6} cols={4} />}
            empty={(d) => (d?.grants || []).length === 0}
            emptyState={
              <EmptyState
                icon={Lock}
                title={grantStatus ? 'No grants with this status' : 'No grants yet'}
                description="Approved requests appear here with a live countdown to expiry."
              />
            }
          >
            {(data) => (
              <>
                <Table>
                  <THead>
                    <tr>
                      <TH>Resource</TH>
                      <TH className="hidden lg:table-cell">Granted</TH>
                      <TH align="right">Time left</TH>
                      <TH align="right">Status</TH>
                    </tr>
                  </THead>
                  <TBody>
                    {(data.grants || []).map((g) => {
                      const gid = entityId(g)
                      return (
                        <TR key={gid}>
                          <TD className="p-0">
                            <Link
                              to={g.resource_id ? `/resources/${g.resource_id}` : '#'}
                              className="block px-4 py-3"
                            >
                              <CellStack
                                primary={resourceLabel(g)}
                                secondary={g.expires_at ? `Expires ${formatDateTime(g.expires_at)}` : 'No expiry recorded'}
                              />
                            </Link>
                          </TD>
                          <TD className="hidden lg:table-cell">
                            <span className="text-xs text-ink-500">{formatRelativeToNow(g.created_at)}</span>
                          </TD>
                          <TD align="right">
                            {g.status === 'ACTIVE' ? <GrantCountdown expiresAt={g.expires_at} /> : <span className="text-xs text-ink-500">—</span>}
                          </TD>
                          <TD align="right">
                            <Badge className={GRANT_STATUS_BADGE[g.status]}>{g.status}</Badge>
                          </TD>
                        </TR>
                      )
                    })}
                  </TBody>
                </Table>
                {pagination && <Pagination {...pagination} pageSize={pagination.page_size} totalPages={pagination.total_pages} onPageChange={setPage} />}
              </>
            )}
          </QueryState>
        )}
      </Card>

      <CreateJitRequestModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        defaultBreakglass={modalBreakglass}
        defaultResourceId={deepLinkedResource || undefined}
      />

      <ConfirmDialog
        open={!!cancelTarget}
        title={`Withdraw request for "${resourceLabel(cancelTarget) || 'this resource'}"?`}
        description="This withdraws the request. You can submit a new one later if you still need access."
        confirmLabel="Withdraw request"
        destructive
        requireReason
        reasonLabel="Reason"
        isLoading={cancelMutation.isPending}
        onConfirm={(reason) => cancelMutation.mutate({ id: entityId(cancelTarget), reason })}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  )
}
