import { forwardRef, useId } from 'react'
import clsx from 'clsx'
import { Loader2, ServerCog, AlertCircle } from 'lucide-react'
import { ThemeToggle } from '../../components/common/ThemeToggle'

/**
 * Shared chrome for the unauthenticated screens.
 *
 * Deliberately self-contained rather than importing the main design system:
 * these two screens load before any lazy chunk, so keeping their dependency
 * surface small keeps first paint fast. The visual language still matches —
 * the tokens are the same CSS custom properties.
 *
 * The split layout (brand panel + form) is the pattern every enterprise
 * identity product uses, because it gives the sign-in page somewhere to
 * state what the system *is* and what it records, which matters when the
 * audience is an auditor or an operator on their first day.
 */
export function ThemeShell({ title, subtitle, children }) {
  return (
    <div className="flex min-h-screen bg-surface-950">
      <div className="absolute right-4 top-4 z-10">
        <ThemeToggle compact />
      </div>

      {/* Brand panel — desktop only. */}
      <div className="relative hidden w-[46%] flex-col justify-between overflow-hidden border-r border-surface-700 bg-surface-900 p-10 lg:flex">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.06]"
          aria-hidden="true"
          style={{
            backgroundImage:
              'linear-gradient(rgb(var(--ink-400)) 1px, transparent 1px), linear-gradient(90deg, rgb(var(--ink-400)) 1px, transparent 1px)',
            backgroundSize: '36px 36px',
          }}
        />
        <div className="relative flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white shadow-xs">
            <ServerCog className="h-4.5 w-4.5" aria-hidden="true" />
          </span>
          <span className="text-sm font-semibold tracking-tight text-ink-50">PAM Console</span>
        </div>

        <div className="relative max-w-md">
          <h2 className="text-2xl font-semibold leading-tight tracking-tight text-ink-50">
            Standing access is the risk. Time-boxed access is the control.
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-ink-400">
            Every credential is encrypted at rest, every reveal is justified and recorded, and every
            grant expires on its own.
          </p>
          <ul className="mt-6 space-y-2.5 text-sm text-ink-300">
            {[
              'Just-in-time approvals with automatic revocation',
              'Break-glass access with a mandatory cooling-off period',
              'Tamper-evident, hash-chained audit trail',
            ].map((item) => (
              <li key={item} className="flex items-start gap-2.5">
                <span
                  className="mt-1.5 h-1.5 w-1.5 flex-none rounded-full bg-brand-500"
                  aria-hidden="true"
                />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-2xs text-ink-600">
          Authorized use only. Activity on this system is monitored.
        </p>
      </div>

      {/* Form panel */}
      <div className="flex flex-1 items-center justify-center px-4 py-12">
        <div className="w-full max-w-[22rem]">
          <div className="mb-7 lg:hidden">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-600 text-white shadow-xs">
              <ServerCog className="h-5 w-5" aria-hidden="true" />
            </span>
          </div>
          <h1 className="text-lg font-semibold tracking-tight text-ink-50">{title}</h1>
          {subtitle && <p className="mt-1.5 text-sm leading-relaxed text-ink-400">{subtitle}</p>}
          <div className="mt-6">{children}</div>
        </div>
      </div>
    </div>
  )
}

export function Field({ label, error, hint, children }) {
  const id = useId()
  const describedBy = error ? `${id}-err` : hint ? `${id}-hint` : undefined
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium text-ink-300">
        {label}
      </label>
      {children({ id, 'aria-describedby': describedBy, 'aria-invalid': error ? true : undefined })}
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-xs text-ink-500">
          {hint}
        </p>
      )}
      {error && (
        <p
          id={`${id}-err`}
          role="alert"
          className="mt-1.5 flex items-center gap-1 text-xs font-medium text-red-600 dark:text-red-400"
        >
          <AlertCircle className="h-3 w-3 flex-none" aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  )
}

export const Input = forwardRef(function Input({ error, className, ...props }, ref) {
  return (
    <input
      ref={ref}
      className={clsx(
        'h-10 w-full rounded-md border bg-surface-800 px-3 text-sm text-ink-50 shadow-xs',
        'placeholder:text-ink-500 focus:outline-none focus:ring-2',
        error
          ? 'border-red-400 focus:border-red-500 focus:ring-red-500/25 dark:border-red-500/70'
          : 'border-surface-700 hover:border-surface-600 focus:border-brand-500 focus:ring-brand-500/25',
        className
      )}
      {...props}
    />
  )
})

export function Button({ children, loading, icon: Icon, className, ...props }) {
  return (
    <button
      disabled={loading || props.disabled}
      aria-busy={loading || undefined}
      className={clsx(
        'flex h-10 w-full items-center justify-center gap-2 rounded-md bg-brand-600 text-sm font-medium text-white shadow-xs',
        'transition-colors hover:bg-brand-700 active:translate-y-px dark:hover:bg-brand-500',
        'disabled:pointer-events-none disabled:opacity-60',
        className
      )}
      {...props}
    >
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
      ) : (
        Icon && <Icon className="h-4 w-4" aria-hidden="true" />
      )}
      {children}
    </button>
  )
}
