import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useNavigate, useLocation } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { ServerCog, LogIn, AlertCircle, Eye, EyeOff } from 'lucide-react'
import { login } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { apiErrorMessage } from '../../lib/apiError'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { Button, Field, Input, ThemeShell } from './AuthShell'

const schema = z.object({
  identifier: z.string().trim().min(1, 'Enter your username or email'),
  password: z.string().min(1, 'Enter your password'),
})

export default function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const setSession = useAuthStore((s) => s.setSession)
  const setMfaChallenge = useAuthStore((s) => s.setMfaChallenge)
  const [formError, setFormError] = useState(null)
  const [showPassword, setShowPassword] = useState(false)
  useDocumentTitle('Sign in')

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })

  const mutation = useMutation({
    mutationFn: ({ identifier, password }) => login(identifier, password),
    onSuccess: (result) => {
      setFormError(null)
      // LoginResult's fields are `omitempty` on the Go side, so the only
      // reliable way to tell "full session" from "MFA challenge" apart is
      // whether access_token actually came back — not the HTTP status. Both
      // paths return 200: auth_handler.go's Login deliberately treats
      // ErrMFARequired as a *success* response.
      if (result?.access_token) {
        resetSessionExpiredGuard()
        setSession({
          accessToken: result.access_token,
          expiresAt: result.expires_at,
          user: null, // populated by the layout's me() fetch
        })
        navigate(location.state?.from?.pathname || '/', { replace: true })
        return
      }
      if (result?.challenge_token) {
        setMfaChallenge({ challengeToken: result.challenge_token })
        navigate('/mfa-verify', { replace: true })
        return
      }
      // Defensive: neither shape came back. Do not silently do nothing —
      // that is the bug class where a user clicks Sign in, sees no error and
      // no navigation, and concludes the app is frozen.
      setFormError('Unexpected response from the server. Please try again.')
    },
    onError: (err) => setFormError(apiErrorMessage(err)),
  })

  return (
    <ThemeShell
      title="Sign in to PAM Console"
      subtitle="Privileged access is time-boxed, approved, and fully audited."
    >
      <form
        onSubmit={handleSubmit((values) => {
          setFormError(null)
          mutation.mutate(values)
        })}
        noValidate
        className="space-y-4"
      >
        {formError && (
          <div
            role="alert"
            className="flex items-start gap-2 rounded-md border border-red-300 bg-red-50 px-3 py-2.5 text-sm text-red-700 dark:border-red-500/40 dark:bg-red-950/40 dark:text-red-300"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 flex-none" aria-hidden="true" />
            <span>{formError}</span>
          </div>
        )}

        <Field label="Username or email" error={errors.identifier?.message}>
          {(a11y) => (
            <Input
              {...a11y}
              autoFocus
              autoComplete="username"
              placeholder="you@company.com"
              error={!!errors.identifier}
              {...register('identifier')}
            />
          )}
        </Field>

        <Field label="Password" error={errors.password?.message}>
          {(a11y) => (
            <div className="relative">
              <Input
                {...a11y}
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                className="pr-10"
                error={!!errors.password}
                {...register('password')}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                className="absolute right-1.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded text-ink-500 transition-colors hover:bg-surface-700 hover:text-ink-200"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" aria-hidden="true" />
                ) : (
                  <Eye className="h-4 w-4" aria-hidden="true" />
                )}
              </button>
            </div>
          )}
        </Field>

        <Button type="submit" loading={mutation.isPending} icon={LogIn}>
          {mutation.isPending ? 'Signing in…' : 'Sign in'}
        </Button>
      </form>

      <p className="mt-5 border-t border-surface-700 pt-4 text-center text-xs leading-relaxed text-ink-500">
        <ServerCog className="mr-1 inline h-3 w-3 align-[-2px]" aria-hidden="true" />
        All sign-in attempts are recorded in the tamper-evident audit log.
      </p>
    </ThemeShell>
  )
}
