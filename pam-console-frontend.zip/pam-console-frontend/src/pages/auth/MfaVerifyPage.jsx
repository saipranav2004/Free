import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { ShieldCheck, AlertCircle } from 'lucide-react'
import { verifyMfa } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { apiErrorMessage } from '../../lib/apiError'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { ThemeShell, Button } from './AuthShell'

// NOTE ON THE MISSING COUNTDOWN: an older PAM frontend showed a live
// countdown for the MFA challenge. Verified against THIS backend
// (auth_service.go's verifyChallengeToken): the challenge token has no
// expiry check at all — it is parsed and accepted regardless of age. Rather
// than render a countdown that lies about enforcement which does not exist,
// this screen does not claim one. Worth fixing on the backend; not something
// the frontend should paper over with fake UI.
export default function MfaVerifyPage() {
  const navigate = useNavigate()
  const challenge = useAuthStore((s) => s.mfaChallenge)
  const setSession = useAuthStore((s) => s.setSession)
  const clearMfaChallenge = useAuthStore((s) => s.clearMfaChallenge)
  const [code, setCode] = useState('')
  const [error, setError] = useState(null)
  const inputRef = useRef(null)
  useDocumentTitle('Verify your identity')

  // Guard against reaching this screen with no challenge in memory (deep
  // link, back button after the flow completed, stale bookmark). Without
  // this, submitting would 400 with a confusing "malformed challenge token"
  // instead of sending the user back to start a fresh sign-in.
  useEffect(() => {
    if (!challenge?.challengeToken) navigate('/login', { replace: true })
  }, [challenge, navigate])

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const mutation = useMutation({
    mutationFn: (value) => verifyMfa(challenge.challengeToken, value),
    onSuccess: (result) => {
      resetSessionExpiredGuard()
      clearMfaChallenge()
      setSession({ accessToken: result.access_token, expiresAt: result.expires_at, user: null })
      navigate('/', { replace: true })
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      // Clear the code so the user re-types rather than resubmitting the
      // same rejected value, but keep focus so they need not click back in.
      setCode('')
      inputRef.current?.focus()
    },
  })

  const submit = (e) => {
    e?.preventDefault()
    if (code.trim().length === 0 || mutation.isPending) return
    setError(null)
    mutation.mutate(code.trim())
  }

  if (!challenge?.challengeToken) return null

  return (
    <ThemeShell
      title="Verify it's you"
      subtitle="Enter the 6-digit code from your authenticator app."
    >
      <form onSubmit={submit} className="space-y-4">
        {error && (
          <div
            role="alert"
            className="flex items-start gap-2 rounded-md border border-red-300 bg-red-50 px-3 py-2.5 text-sm text-red-700 dark:border-red-500/40 dark:bg-red-950/40 dark:text-red-300"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 flex-none" aria-hidden="true" />
            <span>{error}</span>
          </div>
        )}

        <label htmlFor="mfa-code" className="sr-only">
          Authentication code
        </label>
        <input
          id="mfa-code"
          ref={inputRef}
          inputMode="numeric"
          autoComplete="one-time-code"
          pattern="[0-9]*"
          maxLength={8}
          value={code}
          onChange={(e) => {
            const next = e.target.value.replace(/[^0-9]/g, '')
            setCode(next)
            // Auto-submit at six digits. Operators paste or type this dozens
            // of times a week; the extra click is pure friction.
            if (next.length === 6 && !mutation.isPending) {
              setError(null)
              mutation.mutate(next)
            }
          }}
          className="h-14 w-full rounded-md border border-surface-700 bg-surface-800 text-center font-mono text-2xl tracking-[0.5em] text-ink-50 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/25"
          placeholder="000000"
        />

        <Button type="submit" loading={mutation.isPending} icon={ShieldCheck}>
          {mutation.isPending ? 'Verifying…' : 'Verify'}
        </Button>

        <button
          type="button"
          onClick={() => {
            clearMfaChallenge()
            navigate('/login', { replace: true })
          }}
          className="w-full rounded py-1 text-center text-xs text-ink-500 transition-colors hover:text-ink-300"
        >
          Use a different account
        </button>
      </form>
    </ThemeShell>
  )
}
