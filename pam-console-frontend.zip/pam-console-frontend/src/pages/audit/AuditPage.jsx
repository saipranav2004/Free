import { useMemo, useState, useEffect } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ShieldCheck, ShieldAlert, Download, FileText, ScrollText, Filter } from 'lucide-react'
import { searchAudit, verifyAuditChain, generateComplianceReport } from '../../api/audit'
import { useDocumentTitle } from '../../hooks/useDocumentTitle'
import { useDebouncedValue } from '../../hooks/useDebouncedValue'
import { formatDateTime, formatRelativeToNow, toDateInputValue, dateInputToIso } from '../../lib/format'
import { actorLabel, targetLabel, chainIsValid } from '../../lib/entity'
import { apiErrorMessage } from '../../lib/apiError'
import {
  PageHeader, Card, CardToolbar, Button, Badge, QueryState,
  TableSkeleton, EmptyState, NoResultsState, OffsetPagination, SearchInput, FilterSelect,
  Callout, Modal, Field, Input,
  Table, THead, TH, TBody, TR, TD,
} from '../../ui'
import {
  AUDIT_CATEGORIES, AUDIT_OUTCOMES, AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE,
  SEARCH_DEBOUNCE_MS, REPORT_FORMATS, REPORT_RANGE_PRESETS,
} from '../../config/constants'

const PAGE_LIMIT = 25

function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}

function AuditRow({ item }) {
  const ts = itemTimestamp(item)
  return (
    <TR>
      <TD>
        <div className="min-w-0">
          <p className="flex flex-wrap items-center gap-2 text-sm">
            <span className="font-mono text-2xs uppercase tracking-wide text-ink-500">
              {item?.category || 'OTHER'}
            </span>
            <span className="font-medium text-ink-50">{item?.action || '—'}</span>
          </p>
          <p className="mt-1 truncate text-xs text-ink-500">
            {actorLabel(item)} → {targetLabel(item)}
          </p>
        </div>
      </TD>
      <TD className="hidden lg:table-cell">
        <span className="text-xs text-ink-500" title={formatDateTime(ts, { seconds: true })}>
          {ts ? formatRelativeToNow(ts) : '—'}
        </span>
      </TD>
      <TD align="right">
        <div className="flex flex-wrap items-center justify-end gap-1.5">
          {item?.severity && (
            <Badge size="xs" className={AUDIT_SEVERITY_BADGE[item.severity]}>
              {item.severity}
            </Badge>
          )}
          {item?.outcome && (
            <Badge className={AUDIT_OUTCOME_BADGE[item.outcome]}>{item.outcome}</Badge>
          )}
        </div>
      </TD>
    </TR>
  )
}

/**
 * Compliance report dialog.
 * ===========================================================================
 * BUG FIX — part of "cannot generate reports".
 *
 * The previous UI offered a format radio and nothing else, then posted the
 * list filters as the report request. A compliance report is defined by its
 * reporting period, and no period was ever sent, so a handler that requires
 * one rejected every attempt. This collects an explicit range (with the
 * presets an auditor actually asks for) and always sends it.
 *
 * The remaining half of the fix — surfacing the server's real error instead
 * of a generic message, refusing to save a JSON error body as a .pdf, and
 * giving the request a timeout long enough to render — lives in
 * lib/http.js and api/audit.js.
 */
function ReportModal({ open, onClose, filters }) {
  const [format, setFormat] = useState('pdf')
  const [preset, setPreset] = useState('7d')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')

  useEffect(() => {
    if (!open) return
    setFormat('pdf')
    setPreset('7d')
    const now = new Date()
    setTo(toDateInputValue(now))
    setFrom(toDateInputValue(new Date(now.getTime() - 7 * 86400_000)))
  }, [open])

  useEffect(() => {
    if (preset === 'custom') return
    const days = REPORT_RANGE_PRESETS.find((p) => p.key === preset)?.days
    if (!days) return
    const now = new Date()
    setTo(toDateInputValue(now))
    setFrom(toDateInputValue(new Date(now.getTime() - days * 86400_000)))
  }, [preset])

  const rangeValid = Boolean(from && to && new Date(from) <= new Date(to))

  const mutation = useMutation({
    mutationFn: () =>
      generateComplianceReport({
        format,
        startIso: dateInputToIso(from),
        endIso: dateInputToIso(to, { endOfDay: true }),
        category: filters.category,
        outcome: filters.outcome,
        q: filters.q,
      }),
    onSuccess: (result) => {
      toast.success('Report downloaded', { description: result?.filename })
      onClose()
    },
    onError: (err) =>
      toast.error('Could not generate report', { description: apiErrorMessage(err) }),
  })

  return (
    <Modal
      open={open}
      onClose={onClose}
      busy={mutation.isPending}
      icon={FileText}
      title="Generate compliance report"
      description="Exports the audit trail for a reporting period, scoped by the filters currently applied."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            variant="primary"
            icon={Download}
            loading={mutation.isPending}
            disabled={!rangeValid}
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? 'Generating…' : 'Generate & download'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        <div>
          <p className="mb-2 text-xs font-medium text-ink-300">Format</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {REPORT_FORMATS.map((f) => (
              <label
                key={f.value}
                className={
                  'cursor-pointer rounded-lg border p-3 transition-colors ' +
                  (format === f.value
                    ? 'border-brand-500 bg-brand-50 dark:bg-brand-500/10'
                    : 'border-surface-700 bg-surface-900 hover:bg-surface-850')
                }
              >
                <span className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="report-format"
                    className="h-4 w-4"
                    checked={format === f.value}
                    onChange={() => setFormat(f.value)}
                  />
                  <span className="text-sm font-medium text-ink-50">{f.label}</span>
                </span>
                <span className="mt-1 block pl-6 text-xs leading-relaxed text-ink-500">{f.hint}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 text-xs font-medium text-ink-300">Reporting period</p>
          <div className="mb-3 flex flex-wrap gap-1.5">
            {REPORT_RANGE_PRESETS.map((p) => (
              <button
                key={p.key}
                type="button"
                onClick={() => setPreset(p.key)}
                className={
                  'rounded-md border px-2.5 py-1 text-xs font-medium transition-colors ' +
                  (preset === p.key
                    ? 'border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-400'
                    : 'border-surface-700 bg-surface-900 text-ink-300 hover:bg-surface-850')
                }
              >
                {p.label}
              </button>
            ))}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="From" required>
              {({ id, ...a }) => (
                <Input
                  id={id}
                  {...a}
                  type="date"
                  value={from}
                  max={to || undefined}
                  onChange={(e) => {
                    setFrom(e.target.value)
                    setPreset('custom')
                  }}
                />
              )}
            </Field>
            <Field label="To" required>
              {({ id, ...a }) => (
                <Input
                  id={id}
                  {...a}
                  type="date"
                  value={to}
                  min={from || undefined}
                  onChange={(e) => {
                    setTo(e.target.value)
                    setPreset('custom')
                  }}
                />
              )}
            </Field>
          </div>
          {!rangeValid && (from || to) && (
            <p className="mt-2 text-xs font-medium text-red-600 dark:text-red-400">
              The start date must be on or before the end date.
            </p>
          )}
        </div>

        {(filters.category || filters.outcome || filters.q) && (
          <Callout tone="neutral" icon={Filter} title="Scoped by your current filters">
            <ul className="mt-1 space-y-0.5 text-xs">
              {filters.q && <li>Search: {filters.q}</li>}
              {filters.category && <li>Category: {filters.category}</li>}
              {filters.outcome && <li>Outcome: {filters.outcome}</li>}
            </ul>
          </Callout>
        )}

        <p className="text-xs leading-relaxed text-ink-500">
          Large ranges can take up to two minutes to render. The download starts automatically when
          the report is ready.
        </p>
      </div>
    </Modal>
  )
}

function ChainBanner({ result }) {
  const valid = chainIsValid(result)
  if (valid === true) {
    return (
      <Callout tone="success" icon={ShieldCheck} title="Audit chain intact">
        Every recorded entry in scope forms an unbroken hash chain — no tampering detected.
      </Callout>
    )
  }
  if (valid === false) {
    return (
      <Callout tone="danger" icon={ShieldAlert} title="Audit chain broken — possible tampering">
        The hash chain does not verify. Notify a security administrator immediately and preserve the
        current state for investigation.
      </Callout>
    )
  }
  return (
    <Callout tone="neutral" title="Verification result">
      <pre className="mt-1 max-w-full overflow-x-auto text-2xs">{JSON.stringify(result, null, 2)}</pre>
    </Callout>
  )
}

export default function AuditPage() {
  const [searchInput, setSearchInput] = useState('')
  const [actionInput, setActionInput] = useState('')
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [offset, setOffset] = useState(0)
  const [reportOpen, setReportOpen] = useState(false)
  useDocumentTitle('Audit')

  const search = useDebouncedValue(searchInput.trim(), SEARCH_DEBOUNCE_MS)
  const action = useDebouncedValue(actionInput.trim(), SEARCH_DEBOUNCE_MS)

  // Any filter change invalidates the offset — otherwise "offset 60" can
  // persist into a filtered set with only 10 total items and show nothing.
  useEffect(() => {
    setOffset(0)
  }, [search, action, category, outcome])

  /**
   * BUG FIX — "search is broken".
   *
   * The free-text box used to be wired to `action`, which is an exact-match
   * field over values like "pam:vault:Reveal". Typing "reveal" matched
   * nothing, so search looked broken while doing exactly what it was told.
   * Free text now goes out as free text (`q`, with the conventional aliases
   * this backend already uses elsewhere — see api/audit.js), and `action`
   * gets its own explicit exact-match input, which is what it was always
   * good for.
   */
  const filters = useMemo(
    () => ({
      q: search || undefined,
      action: action || undefined,
      category: category || undefined,
      outcome: outcome || undefined,
    }),
    [search, action, category, outcome]
  )

  const auditQuery = useQuery({
    queryKey: ['audit', 'search', { ...filters, offset }],
    queryFn: ({ signal }) => searchAudit({ ...filters, limit: PAGE_LIMIT, offset }, signal),
    placeholderData: (prev) => prev,
  })

  const verifyMutation = useMutation({
    mutationFn: () => verifyAuditChain(),
    onError: (err) => toast.error('Verification failed', { description: apiErrorMessage(err) }),
  })

  const hasFilters = Boolean(search || action || category || outcome)
  const clearFilters = () => {
    setSearchInput('')
    setActionInput('')
    setCategory('')
    setOutcome('')
  }

  const total = auditQuery.data?.total ?? 0
  const limit = auditQuery.data?.limit ?? PAGE_LIMIT

  return (
    <div>
      <PageHeader
        title="Audit"
        description="Your own audit trail — actions performed by, or affecting, your account."
        actions={
          <>
            <Button
              variant="secondary"
              icon={ShieldCheck}
              loading={verifyMutation.isPending}
              onClick={() => verifyMutation.mutate()}
            >
              Verify chain
            </Button>
            <Button variant="primary" icon={FileText} onClick={() => setReportOpen(true)}>
              Generate report
            </Button>
          </>
        }
      />

      {verifyMutation.isSuccess && (
        <div className="mb-5">
          <ChainBanner result={verifyMutation.data} />
        </div>
      )}

      <Card>
        <CardToolbar>
          <SearchInput
            value={searchInput}
            onChange={setSearchInput}
            placeholder="Search events…"
            className="w-full max-w-xs"
          />
          <Input
            size="sm"
            value={actionInput}
            onChange={(e) => setActionInput(e.target.value)}
            placeholder="Exact action, e.g. pam:vault:Reveal"
            className="max-w-[16rem] font-mono text-xs"
          />
          <FilterSelect
            label="Category"
            value={category}
            onChange={setCategory}
            options={AUDIT_CATEGORIES}
            allLabel="All categories"
          />
          <FilterSelect
            label="Outcome"
            value={outcome}
            onChange={setOutcome}
            options={AUDIT_OUTCOMES}
            allLabel="All outcomes"
          />
          {hasFilters && (
            <Button size="sm" variant="ghost" onClick={clearFilters}>
              Clear
            </Button>
          )}
          <span className="ml-auto text-xs tabular-nums text-ink-500">{total} events</span>
        </CardToolbar>

        <QueryState
          query={auditQuery}
          skeleton={<TableSkeleton rows={8} cols={3} />}
          empty={(d) => (d?.items || []).length === 0}
          emptyState={
            hasFilters ? (
              <NoResultsState onClear={clearFilters} />
            ) : (
              <EmptyState
                icon={ScrollText}
                title="No audit entries yet"
                description="Activity involving your account will appear here as it happens."
              />
            )
          }
        >
          {(data) => (
            <>
              <Table>
                <THead>
                  <tr>
                    <TH>Event</TH>
                    <TH className="hidden lg:table-cell">When</TH>
                    <TH align="right">Result</TH>
                  </tr>
                </THead>
                <TBody>
                  {(data.items || []).map((item, idx) => (
                    <AuditRow key={item?.id ?? item?.sequence ?? idx} item={item} />
                  ))}
                </TBody>
              </Table>
              <OffsetPagination
                offset={offset}
                limit={limit}
                total={total}
                onOffsetChange={setOffset}
              />
            </>
          )}
        </QueryState>
      </Card>

      <p className="mt-3 text-xs leading-relaxed text-ink-500">
        Chain verification checks that the entries in scope form an unbroken, tamper-evident hash
        chain. It is not run automatically — trigger it explicitly.
      </p>

      <ReportModal open={reportOpen} onClose={() => setReportOpen(false)} filters={filters} />
    </div>
  )
}
