import { forwardRef } from 'react'
import clsx from 'clsx'
import { Loader2 } from 'lucide-react'

/**
 * The single button primitive for the whole console.
 *
 * Before this existed, every button in the app was a bespoke string of
 * Tailwind classes — which is why hover, focus, disabled and loading states
 * were inconsistent (several had conflicting `dark:` classes that cancelled
 * each other out, and "loading" was a spinner bolted next to a label that
 * still looked clickable).
 *
 * Enterprise behaviours baked in so no call site can forget them:
 *  - `loading` implies `disabled` AND swaps the leading icon for a spinner
 *    in place, so the control cannot be double-submitted, visibly reads as
 *    busy, and does not change width (no toolbar reflow mid-click).
 *  - `active:translate-y-px` gives a physical press response.
 *  - Disabled removes pointer events entirely — a disabled button that still
 *    shows hover is the classic "is it broken?" support ticket.
 */
const VARIANTS = {
  primary:
    'bg-brand-600 text-white shadow-xs hover:bg-brand-700 active:bg-brand-700 dark:hover:bg-brand-500',
  secondary:
    'border border-surface-700 bg-surface-900 text-ink-100 shadow-xs hover:bg-surface-850 hover:border-surface-600 active:bg-surface-800',
  subtle: 'bg-surface-800 text-ink-100 hover:bg-surface-700 active:bg-surface-700',
  ghost: 'text-ink-300 hover:bg-surface-800 hover:text-ink-50 active:bg-surface-700',
  danger:
    'bg-red-600 text-white shadow-xs hover:bg-red-700 active:bg-red-700 dark:hover:bg-red-500',
  dangerOutline:
    'border border-red-300 text-red-700 hover:bg-red-50 active:bg-red-100 dark:border-red-900/60 dark:text-red-400 dark:hover:bg-red-950/40 dark:active:bg-red-950/60',
  warning:
    'bg-amber-600 text-white shadow-xs hover:bg-amber-700 active:bg-amber-700 dark:hover:bg-amber-500',
}

const SIZES = {
  xs: 'h-7 gap-1.5 px-2.5 text-xs rounded-md',
  sm: 'h-8 gap-1.5 px-3 text-xs rounded-md',
  md: 'h-9 gap-2 px-3.5 text-sm rounded-md',
  lg: 'h-10 gap-2 px-4 text-sm rounded-md',
}

const ICON_SIZES = { xs: 'h-3.5 w-3.5', sm: 'h-3.5 w-3.5', md: 'h-4 w-4', lg: 'h-4 w-4' }

export const Button = forwardRef(function Button(
  {
    variant = 'secondary',
    size = 'md',
    icon: Icon,
    iconRight: IconRight,
    loading = false,
    fullWidth = false,
    className,
    children,
    disabled,
    type = 'button',
    ...props
  },
  ref
) {
  const isDisabled = disabled || loading
  const iconClass = ICON_SIZES[size] || ICON_SIZES.md

  return (
    <button
      ref={ref}
      type={type}
      disabled={isDisabled}
      aria-busy={loading || undefined}
      className={clsx(
        'inline-flex select-none items-center justify-center whitespace-nowrap font-medium',
        'transition-[background-color,border-color,color,box-shadow,transform] duration-150',
        'active:translate-y-px',
        'disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none disabled:active:translate-y-0',
        SIZES[size] || SIZES.md,
        VARIANTS[variant] || VARIANTS.secondary,
        fullWidth && 'w-full',
        className
      )}
      {...props}
    >
      {loading ? (
        <Loader2 className={clsx(iconClass, 'flex-none animate-spin')} aria-hidden="true" />
      ) : (
        Icon && <Icon className={clsx(iconClass, 'flex-none')} aria-hidden="true" />
      )}
      {children}
      {IconRight && !loading && (
        <IconRight className={clsx(iconClass, 'flex-none')} aria-hidden="true" />
      )}
    </button>
  )
})

/** Square icon-only button. `label` is mandatory — it becomes both the
 *  accessible name and the tooltip, so an icon button can never ship
 *  unlabelled. */
export const IconButton = forwardRef(function IconButton(
  { icon: Icon, label, variant = 'ghost', size = 'md', loading = false, className, disabled, ...props },
  ref
) {
  const box = { xs: 'h-7 w-7', sm: 'h-8 w-8', md: 'h-9 w-9', lg: 'h-10 w-10' }[size] || 'h-9 w-9'
  const iconClass = ICON_SIZES[size] || ICON_SIZES.md

  return (
    <button
      ref={ref}
      type="button"
      title={label}
      aria-label={label}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={clsx(
        'inline-flex flex-none items-center justify-center rounded-md transition-colors duration-150',
        'disabled:pointer-events-none disabled:opacity-50',
        box,
        VARIANTS[variant] || VARIANTS.ghost,
        className
      )}
      {...props}
    >
      {loading ? (
        <Loader2 className={clsx(iconClass, 'animate-spin')} aria-hidden="true" />
      ) : (
        <Icon className={iconClass} aria-hidden="true" />
      )}
    </button>
  )
})
