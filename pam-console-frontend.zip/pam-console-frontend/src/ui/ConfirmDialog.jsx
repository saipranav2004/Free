import { useEffect, useState } from 'react'
import { AlertTriangle, ShieldAlert } from 'lucide-react'
import { Modal } from './Modal'
import { Button } from './Button'
import { Field, Textarea } from './Form'

/**
 * Destructive-action confirmation.
 *
 * Fixes over the previous version:
 *  - The reason field kept its value between opens. Revoking grant A, then
 *    opening the dialog for grant B, pre-filled B with A's justification —
 *    which then got written into B's immutable audit record. That is a
 *    compliance defect, not a cosmetic one. Reason now resets on every open.
 *  - Escape and backdrop-close now work (inherited from Modal).
 *  - `confirmPhrase` adds type-to-confirm for the highest-blast-radius
 *    actions (vault restore, user delete), matching how CyberArk and Okta
 *    gate irreversible operations.
 *  - The confirm button reports its own busy state and cannot be
 *    double-fired.
 */
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  destructive = true,
  requireReason = false,
  reasonLabel = 'Reason',
  reasonHint = 'Recorded in the immutable audit log.',
  reasonPlaceholder = 'Required — recorded in the audit log',
  confirmPhrase,
  isLoading = false,
  onConfirm,
  onCancel,
  children,
}) {
  const [reason, setReason] = useState('')
  const [phrase, setPhrase] = useState('')

  // Reset every time the dialog opens — see the compliance note above.
  useEffect(() => {
    if (open) {
      setReason('')
      setPhrase('')
    }
  }, [open])

  const reasonOk = !requireReason || reason.trim().length > 0
  const phraseOk = !confirmPhrase || phrase.trim() === confirmPhrase
  const canConfirm = reasonOk && phraseOk && !isLoading

  return (
    <Modal
      open={open}
      onClose={onCancel}
      busy={isLoading}
      size="md"
      icon={destructive ? AlertTriangle : ShieldAlert}
      iconTone={destructive ? 'danger' : 'brand'}
      title={title}
      description={description}
      footer={
        <>
          <Button variant="ghost" onClick={onCancel} disabled={isLoading}>
            {cancelLabel}
          </Button>
          <Button
            variant={destructive ? 'danger' : 'primary'}
            loading={isLoading}
            disabled={!canConfirm}
            onClick={() => canConfirm && onConfirm(reason.trim())}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {children}

        {requireReason && (
          <Field label={reasonLabel} hint={reasonHint} required>
            {({ id, ...a11y }) => (
              <Textarea
                id={id}
                {...a11y}
                data-autofocus
                rows={3}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder={reasonPlaceholder}
              />
            )}
          </Field>
        )}

        {confirmPhrase && (
          <Field
            label={`Type "${confirmPhrase}" to confirm`}
            hint="This action cannot be undone."
            required
          >
            {({ id, ...a11y }) => (
              <input
                id={id}
                {...a11y}
                value={phrase}
                onChange={(e) => setPhrase(e.target.value)}
                autoComplete="off"
                spellCheck="false"
                className="h-9 w-full rounded-md border border-surface-700 bg-surface-800 px-3 font-mono text-sm text-ink-50 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/25"
                placeholder={confirmPhrase}
              />
            )}
          </Field>
        )}

        {!requireReason && !confirmPhrase && !children && null}
      </div>
    </Modal>
  )
}
