import clsx from 'clsx'
import { AlertTriangle, Inbox, Loader2, RefreshCw, SearchX } from 'lucide-react'
import { Button } from './Button'
import { apiErrorMessage } from '../lib/apiError'

export function Spinner({ className, size = 'h-4 w-4', label = 'Loading' }) {
  return <Loader2 className={clsx(size, 'animate-spin text-ink-400', className)} aria-label={label} />
}

export function FullPageSpinner({ label = 'Loading…' }) {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-ink-400">
      <Spinner size="h-6 w-6" />
      <span className="text-sm">{label}</span>
    </div>
  )
}

/* ---------------------------------------------------------------------------
 * Skeletons
 * ---------------------------------------------------------------------------
 * A centred spinner tells the user "something is happening"; a skeleton
 * tells them *what* is about to appear and holds the layout so the page
 * does not jump when data lands. That difference is most of the perceived
 * latency the brief asked about — the network time is identical, but the
 * console stops feeling like it stalls.
 */
export function Skeleton({ className }) {
  return <div className={clsx('skeleton rounded', className)} aria-hidden="true" />
}

export function TableSkeleton({ rows = 6, cols = 4 }) {
  return (
    <div className="divide-y divide-surface-700" aria-busy="true" aria-label="Loading data">
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="flex items-center gap-4 px-4 py-3.5">
          <Skeleton className="h-8 w-8 flex-none rounded-lg" />
          <div className="min-w-0 flex-1 space-y-2">
            <Skeleton className="h-3.5 w-[38%]" />
            <Skeleton className="h-3 w-[22%]" />
          </div>
          {Array.from({ length: Math.max(0, cols - 2) }).map((__, c) => (
            <Skeleton key={c} className="hidden h-4 w-16 flex-none sm:block" />
          ))}
          <Skeleton className="h-5 w-16 flex-none rounded-full" />
        </div>
      ))}
    </div>
  )
}

export function CardSkeleton({ lines = 4 }) {
  return (
    <div className="space-y-3 p-4" aria-busy="true">
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <Skeleton className="h-3 w-24 flex-none" />
          <Skeleton className="h-3 flex-1" style={{ maxWidth: `${60 + ((i * 13) % 30)}%` }} />
        </div>
      ))}
    </div>
  )
}

export function StatSkeleton() {
  return (
    <div className="space-y-2.5" aria-busy="true">
      <Skeleton className="h-3 w-20" />
      <Skeleton className="h-7 w-14" />
    </div>
  )
}

/* ------------------------------------------------------------------------ */

export function EmptyState({
  icon: Icon = Inbox,
  title = 'Nothing here yet',
  description,
  action,
  compact = false,
}) {
  return (
    <div
      className={clsx(
        'flex flex-col items-center justify-center px-6 text-center',
        compact ? 'py-10' : 'py-16'
      )}
    >
      <span className="mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-surface-800 text-ink-400">
        <Icon className="h-5 w-5" aria-hidden="true" />
      </span>
      <p className="text-sm font-medium text-ink-100">{title}</p>
      {description && <p className="mt-1 max-w-sm text-sm text-ink-500">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function NoResultsState({ onClear }) {
  return (
    <EmptyState
      icon={SearchX}
      title="No matching records"
      description="No results match the current filters. Try broadening or clearing them."
      action={
        onClear && (
          <Button size="sm" variant="secondary" onClick={onClear}>
            Clear filters
          </Button>
        )
      }
    />
  )
}

export function ErrorState({ error, onRetry, title = 'Could not load this data', compact = false }) {
  return (
    <div
      role="alert"
      className={clsx(
        'flex flex-col items-center justify-center gap-3 px-6 text-center',
        compact ? 'py-10' : 'py-14'
      )}
    >
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400">
        <AlertTriangle className="h-5 w-5" aria-hidden="true" />
      </span>
      <div>
        <p className="text-sm font-semibold text-ink-100">{title}</p>
        <p className="mt-1 max-w-md text-sm text-ink-500">{apiErrorMessage(error)}</p>
      </div>
      {onRetry && (
        <Button size="sm" variant="secondary" icon={RefreshCw} onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  )
}

/**
 * Renders the correct branch for a react-query result so no view can forget
 * one. `skeleton` lets a caller supply a layout-matched placeholder instead
 * of the generic spinner — that is the difference between a page that feels
 * instant and one that feels like it stalls.
 *
 * `isFetching` (as opposed to `isLoading`) drives a subtle top progress bar
 * for background refetches, so a filter change never blanks data that is
 * still on screen.
 */
export function QueryState({
  query,
  empty,
  emptyState,
  emptyMessage = 'Nothing here yet.',
  loadingLabel = 'Loading…',
  skeleton,
  children,
}) {
  if (query.isLoading) {
    return (
      skeleton || (
        <div className="flex items-center justify-center gap-2 py-16 text-ink-400">
          <Spinner /> <span className="text-sm">{loadingLabel}</span>
        </div>
      )
    )
  }

  if (query.isError) {
    return <ErrorState error={query.error} onRetry={() => query.refetch()} />
  }

  const data = query.data
  if (empty ? empty(data) : false) {
    return emptyState || <EmptyState description={emptyMessage} />
  }

  return (
    <div className="relative">
      {query.isFetching && (
        <div
          className="pointer-events-none absolute inset-x-0 top-0 z-10 h-0.5 overflow-hidden"
          aria-hidden="true"
        >
          <div className="h-full w-1/3 animate-[shimmer_1.1s_ease-in-out_infinite] bg-brand-500/70" />
        </div>
      )}
      {children(data)}
    </div>
  )
}
