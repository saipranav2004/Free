import clsx from 'clsx'

/**
 * Semantic data table.
 *
 * The console previously rendered every dataset as <ul><li> with flex rows.
 * That looks acceptable at three columns and falls apart at five: nothing
 * aligns between rows, there is no column header to sort or scan by, and
 * screen readers get a list instead of a grid. Real PAM consoles are
 * table-first, so this is a real <table> with proper scope attributes,
 * a sticky header and horizontal scroll on narrow viewports.
 */
export function Table({ children, className }) {
  return (
    <div className="w-full overflow-x-auto">
      <table className={clsx('w-full border-collapse text-sm', className)}>{children}</table>
    </div>
  )
}

export function THead({ children, sticky = false }) {
  return (
    <thead
      className={clsx(
        'border-b border-surface-700 bg-surface-875',
        sticky && 'sticky top-0 z-10'
      )}
    >
      {children}
    </thead>
  )
}

export function TH({ children, className, align = 'left', width, ...props }) {
  return (
    <th
      scope="col"
      style={width ? { width } : undefined}
      className={clsx(
        'whitespace-nowrap px-4 py-2.5 text-2xs font-semibold uppercase tracking-wider text-ink-400',
        align === 'right' && 'text-right',
        align === 'center' && 'text-center',
        align === 'left' && 'text-left',
        className
      )}
      {...props}
    >
      {children}
    </th>
  )
}

export function TBody({ children }) {
  return <tbody className="divide-y divide-surface-700">{children}</tbody>
}

export function TR({ children, className, interactive = false, onClick, ...props }) {
  return (
    <tr
      onClick={onClick}
      className={clsx(
        'transition-colors',
        (interactive || onClick) && 'cursor-pointer hover:bg-surface-850',
        className
      )}
      {...props}
    >
      {children}
    </tr>
  )
}

export function TD({ children, className, align = 'left', ...props }) {
  return (
    <td
      className={clsx(
        'px-4 py-3 align-middle text-ink-100',
        align === 'right' && 'text-right',
        align === 'center' && 'text-center',
        className
      )}
      {...props}
    >
      {children}
    </td>
  )
}

/** Two-line cell: a strong primary value with quiet metadata underneath.
 *  This is the pattern that carries most of the density in a PAM console. */
export function CellStack({ primary, secondary, icon, className }) {
  return (
    <div className={clsx('flex min-w-0 items-center gap-3', className)}>
      {icon && <span className="flex-none">{icon}</span>}
      <div className="min-w-0">
        <div className="truncate text-sm font-medium text-ink-50">{primary}</div>
        {secondary && <div className="mt-0.5 truncate text-xs text-ink-500">{secondary}</div>}
      </div>
    </div>
  )
}
