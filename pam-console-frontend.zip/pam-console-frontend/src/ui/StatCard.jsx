import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { ArrowUpRight } from 'lucide-react'
import { StatSkeleton } from './States'

/**
 * Metric tile.
 *
 * Fixes over the previous version: the icon used `h-4.5 w-4.5`, which
 * Tailwind never generated (no 4.5 in the default spacing scale), so the
 * icon rendered at its intrinsic SVG size and every tile's icon was subtly
 * the wrong size. The scale now exists in tailwind.config.js and the class
 * resolves.
 *
 * A tile with a `to` becomes a real anchor with a visible affordance
 * instead of a mystery-clickable card.
 */
const TONES = {
  default: 'bg-surface-800 text-ink-300',
  brand: 'bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400',
  amber: 'bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400',
  emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
  red: 'bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400',
  purple: 'bg-purple-50 text-purple-600 dark:bg-purple-500/15 dark:text-purple-400',
}

export function StatCard({ label, value, icon: Icon, tone = 'default', hint, loading, to, attention }) {
  const body = (
    <>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-ink-400">{label}</p>
          {loading ? (
            <div className="mt-2">
              <StatSkeleton />
            </div>
          ) : (
            <p className="mt-1.5 text-2xl font-semibold leading-none tracking-tight tabular-nums text-ink-50">
              {value}
            </p>
          )}
          {hint && !loading && <p className="mt-2 truncate text-xs text-ink-500">{hint}</p>}
        </div>
        {Icon && (
          <span
            className={clsx(
              'flex h-9 w-9 flex-none items-center justify-center rounded-lg',
              TONES[tone] || TONES.default
            )}
          >
            <Icon className="h-4.5 w-4.5" aria-hidden="true" />
          </span>
        )}
      </div>
      {to && (
        <ArrowUpRight
          className="absolute right-3 top-3 h-3.5 w-3.5 text-ink-600 opacity-0 transition-opacity group-hover:opacity-100"
          aria-hidden="true"
        />
      )}
    </>
  )

  const shell = clsx(
    'relative block rounded-card border bg-surface-900 p-4 shadow-card transition-[border-color,box-shadow]',
    attention ? 'border-amber-300 dark:border-amber-500/40' : 'border-surface-700',
    to && 'group hover:border-brand-500/50 hover:shadow-sm'
  )

  if (to) {
    return (
      <Link to={to} className={shell}>
        {body}
      </Link>
    )
  }
  return <div className={shell}>{body}</div>
}
