import clsx from 'clsx'

/** Panel surface — the base container for every section of the console. */
export function Card({ children, className, as: As = 'div', ...props }) {
  return (
    <As
      className={clsx('rounded-card border border-surface-700 bg-surface-900 shadow-card', className)}
      {...props}
    >
      {children}
    </As>
  )
}

export function CardHeader({ title, description, actions, children, className }) {
  if (children) {
    return (
      <div className={clsx('border-b border-surface-700 bg-surface-875 px-4 py-3', className)}>
        {children}
      </div>
    )
  }
  return (
    <div
      className={clsx(
        'flex flex-wrap items-center justify-between gap-3 border-b border-surface-700 bg-surface-875 px-4 py-3',
        className
      )}
    >
      <div className="min-w-0">
        {title && <h3 className="truncate text-sm font-semibold text-ink-50">{title}</h3>}
        {description && <p className="mt-0.5 text-xs text-ink-400">{description}</p>}
      </div>
      {actions && <div className="flex flex-none items-center gap-2">{actions}</div>}
    </div>
  )
}

export function CardBody({ children, className }) {
  return <div className={clsx('p-4', className)}>{children}</div>
}

export function CardFooter({ children, className }) {
  return (
    <div className={clsx('border-t border-surface-700 bg-surface-875 px-4 py-3', className)}>
      {children}
    </div>
  )
}

/** Filter/search strip directly under a CardHeader. */
export function CardToolbar({ children, className }) {
  return (
    <div
      className={clsx('flex flex-wrap items-center gap-2 border-b border-surface-700 px-4 py-2.5', className)}
    >
      {children}
    </div>
  )
}
