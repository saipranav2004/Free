import { useEffect, useRef, useState } from 'react'
import { Check, Copy } from 'lucide-react'
import clsx from 'clsx'

/**
 * Copy-to-clipboard with a real fallback.
 *
 * navigator.clipboard requires a secure context (HTTPS or localhost) and
 * rejects silently in some embedded/iframe contexts. Without a fallback the
 * button appears to do nothing — the classic "I clicked Copy five times"
 * report. This falls back to a hidden textarea + execCommand and, if even
 * that fails, says so out loud through an aria-live region.
 *
 * The width is held stable across idle/copied/failed states so a toolbar
 * does not reflow at the moment of the click.
 */
export function CopyButton({ value, label = 'Copy', size = 'sm', variant = 'secondary', className }) {
  const [state, setState] = useState('idle') // idle | copied | failed
  const timeoutRef = useRef(null)

  useEffect(() => () => clearTimeout(timeoutRef.current), [])

  const copy = async () => {
    clearTimeout(timeoutRef.current)
    let ok = false
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(String(value ?? ''))
        ok = true
      }
    } catch {
      ok = false
    }
    if (!ok) {
      try {
        const ta = document.createElement('textarea')
        ta.value = String(value ?? '')
        ta.setAttribute('readonly', '')
        ta.style.position = 'fixed'
        ta.style.opacity = '0'
        document.body.appendChild(ta)
        ta.select()
        ok = document.execCommand('copy')
        document.body.removeChild(ta)
      } catch {
        ok = false
      }
    }
    setState(ok ? 'copied' : 'failed')
    timeoutRef.current = setTimeout(() => setState('idle'), ok ? 1600 : 2600)
  }

  const styles = {
    secondary:
      'border border-surface-700 bg-surface-900 text-ink-200 hover:bg-surface-850 hover:border-surface-600',
    subtle: 'bg-surface-800 text-ink-200 hover:bg-surface-700',
    ghost: 'text-ink-400 hover:bg-surface-800 hover:text-ink-100',
  }[variant]

  return (
    <>
      <button
        type="button"
        onClick={copy}
        title={state === 'failed' ? 'Copy failed — select the value manually' : label}
        className={clsx(
          'inline-flex flex-none items-center justify-center gap-1.5 rounded-md font-medium transition-colors active:translate-y-px',
          size === 'sm' ? 'h-8 px-2.5 text-xs' : 'h-9 px-3 text-sm',
          styles,
          state === 'failed' && 'border-red-300 text-red-700 dark:border-red-500/50 dark:text-red-400',
          className
        )}
      >
        {state === 'copied' ? (
          <>
            <Check className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
            Copied
          </>
        ) : state === 'failed' ? (
          <>
            <Copy className="h-3.5 w-3.5" aria-hidden="true" />
            Failed
          </>
        ) : (
          <>
            <Copy className="h-3.5 w-3.5" aria-hidden="true" />
            {label}
          </>
        )}
      </button>
      <span className="sr-only" role="status" aria-live="polite">
        {state === 'copied' ? 'Copied to clipboard' : state === 'failed' ? 'Copy failed. Select the value manually.' : ''}
      </span>
    </>
  )
}

/** Monospace value + copy affordance — hosts, IDs, connection strings. */
export function CopyableValue({ value, label, mono = true, className, truncate = true }) {
  if (!value) return <span className="text-ink-500">—</span>
  return (
    <div className={clsx('flex min-w-0 items-center gap-2', className)}>
      <code
        className={clsx(
          'min-w-0 flex-1 rounded-md border border-surface-700 bg-surface-800 px-2.5 py-1.5 text-xs text-ink-100',
          mono && 'font-mono',
          truncate ? 'truncate' : 'break-all'
        )}
        title={String(value)}
      >
        {value}
      </code>
      <CopyButton value={value} label={label || 'Copy'} />
    </div>
  )
}
