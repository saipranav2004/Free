import { forwardRef, useId } from 'react'
import clsx from 'clsx'
import { AlertCircle } from 'lucide-react'

/**
 * Form primitives.
 *
 * `Field` wires label -> control -> error/hint together with real ids and
 * `aria-describedby` / `aria-invalid`, which the previous hand-rolled
 * <label> + <p> pairs did not do: a screen reader user got the label but
 * never heard the validation error.
 */
export function Field({ label, error, hint, required, children, htmlFor, className }) {
  const autoId = useId()
  const id = htmlFor || autoId
  const describedBy = error ? `${id}-error` : hint ? `${id}-hint` : undefined

  return (
    <div className={clsx('min-w-0', className)}>
      {label && (
        <label htmlFor={id} className="mb-1.5 flex items-center gap-1 text-xs font-medium text-ink-300">
          {label}
          {required && (
            <span className="text-red-600 dark:text-red-400" aria-hidden="true">
              *
            </span>
          )}
        </label>
      )}
      {typeof children === 'function'
        ? children({ id, 'aria-describedby': describedBy, 'aria-invalid': error ? true : undefined })
        : children}
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-xs leading-relaxed text-ink-500">
          {hint}
        </p>
      )}
      {error && (
        <p
          id={`${id}-error`}
          role="alert"
          className="mt-1.5 flex items-start gap-1 text-xs font-medium text-red-600 dark:text-red-400"
        >
          <AlertCircle className="mt-0.5 h-3 w-3 flex-none" aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  )
}

const CONTROL_BASE =
  'w-full rounded-md border bg-surface-800 text-sm text-ink-50 shadow-xs transition-[border-color,box-shadow] placeholder:text-ink-500 ' +
  'focus:outline-none focus:ring-2 focus:ring-brand-500/25 ' +
  'disabled:cursor-not-allowed disabled:bg-surface-850 disabled:text-ink-500 read-only:bg-surface-850'

const CONTROL_OK = 'border-surface-700 hover:border-surface-600 focus:border-brand-500'
const CONTROL_ERR = 'border-red-400 dark:border-red-500/70 focus:border-red-500 focus:ring-red-500/25'

export const controlClass = (hasError, extra) =>
  clsx(CONTROL_BASE, hasError ? CONTROL_ERR : CONTROL_OK, extra)

export const Input = forwardRef(function Input({ error, className, size = 'md', ...props }, ref) {
  const h = size === 'sm' ? 'h-8 px-2.5' : 'h-9 px-3'
  return <input ref={ref} className={controlClass(error, [h, className])} {...props} />
})

export const Textarea = forwardRef(function Textarea({ error, className, rows = 3, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      rows={rows}
      className={controlClass(error, ['px-3 py-2 leading-relaxed resize-y', className])}
      {...props}
    />
  )
})

export const Select = forwardRef(function Select(
  { error, className, size = 'md', children, ...props },
  ref
) {
  const h = size === 'sm' ? 'h-8 pl-2.5 pr-8' : 'h-9 pl-3 pr-8'
  return (
    <select
      ref={ref}
      className={controlClass(error, [
        h,
        'appearance-none bg-[length:1rem] bg-[right_0.5rem_center] bg-no-repeat',
        "bg-[url(\"data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke-width='2' stroke='%2394a3b8'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='m19.5 8.25-7.5 7.5-7.5-7.5'/%3E%3C/svg%3E\")]",
        className,
      ])}
      {...props}
    >
      {children}
    </select>
  )
})

export const Checkbox = forwardRef(function Checkbox({ label, hint, className, ...props }, ref) {
  const id = useId()
  return (
    <label
      htmlFor={id}
      className={clsx(
        'flex cursor-pointer items-start gap-2.5 rounded-md p-2 -m-2 transition-colors hover:bg-surface-850',
        className
      )}
    >
      <input
        ref={ref}
        id={id}
        type="checkbox"
        className="mt-0.5 h-4 w-4 flex-none cursor-pointer rounded border-surface-600 bg-surface-800 text-brand-600"
        {...props}
      />
      <span className="min-w-0">
        <span className="block text-sm text-ink-100">{label}</span>
        {hint && <span className="mt-0.5 block text-xs leading-relaxed text-ink-500">{hint}</span>}
      </span>
    </label>
  )
})

export const Radio = forwardRef(function Radio({ label, className, ...props }, ref) {
  const id = useId()
  return (
    <label
      htmlFor={id}
      className={clsx('flex cursor-pointer items-center gap-2 text-sm text-ink-200', className)}
    >
      <input
        ref={ref}
        id={id}
        type="radio"
        className="h-4 w-4 cursor-pointer border-surface-600 bg-surface-800 text-brand-600"
        {...props}
      />
      {label}
    </label>
  )
})

/** Grouped form section with a heading — used inside longer create forms. */
export function FormSection({ title, description, children, className }) {
  return (
    <fieldset className={clsx('min-w-0', className)}>
      {title && (
        <legend className="mb-0.5 text-xs font-semibold uppercase tracking-wider text-ink-400">
          {title}
        </legend>
      )}
      {description && <p className="mb-3 text-xs text-ink-500">{description}</p>}
      <div className={clsx('space-y-4', !description && title && 'mt-3')}>{children}</div>
    </fieldset>
  )
}
