import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'

/** Page title block. Enterprise consoles lead with a breadcrumb so a user
 *  three levels deep always knows where they are and can climb back out. */
export function PageHeader({ title, description, actions, breadcrumbs, meta, className }) {
  return (
    <div className={clsx('mb-6', className)}>
      {breadcrumbs?.length > 0 && <Breadcrumbs items={breadcrumbs} />}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h1 className="flex min-w-0 items-center gap-2.5 text-xl font-semibold tracking-tight text-ink-50">
            {title}
          </h1>
          {description && (
            <p className="mt-1.5 max-w-3xl text-sm leading-relaxed text-ink-400">{description}</p>
          )}
          {meta && <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">{meta}</div>}
        </div>
        {actions && <div className="flex flex-none flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </div>
  )
}

export function Breadcrumbs({ items }) {
  return (
    <nav aria-label="Breadcrumb" className="mb-2.5">
      <ol className="flex flex-wrap items-center gap-1 text-xs text-ink-500">
        {items.map((item, i) => (
          <li key={`${item.label}-${i}`} className="flex items-center gap-1">
            {i > 0 && <ChevronRight className="h-3 w-3 text-ink-600" aria-hidden="true" />}
            {item.to ? (
              <Link
                to={item.to}
                className="rounded px-1 py-0.5 font-medium transition-colors hover:bg-surface-800 hover:text-ink-200"
              >
                {item.label}
              </Link>
            ) : (
              <span className="px-1 py-0.5 font-medium text-ink-300" aria-current="page">
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  )
}

/** Label/value grid — the standard "details" presentation. */
export function DescriptionList({ children, className, cols = '150px 1fr' }) {
  return (
    <dl className={clsx('grid gap-x-4 gap-y-3 text-sm', className)} style={{ gridTemplateColumns: cols }}>
      {children}
    </dl>
  )
}

export function DescriptionItem({ label, children, mono = false }) {
  return (
    <>
      <dt className="text-xs font-medium leading-6 text-ink-500">{label}</dt>
      <dd className={clsx('min-w-0 break-words text-sm leading-6 text-ink-100', mono && 'font-mono text-xs')}>
        {children ?? '—'}
      </dd>
    </>
  )
}

/** Segmented tab control. */
export function Tabs({ tabs, active, onChange, className }) {
  return (
    <div
      role="tablist"
      className={clsx(
        'inline-flex flex-wrap gap-0.5 rounded-lg border border-surface-700 bg-surface-900 p-1 shadow-xs',
        className
      )}
    >
      {tabs.map((t) => {
        const isActive = active === t.key
        return (
          <button
            key={t.key}
            role="tab"
            type="button"
            aria-selected={isActive}
            onClick={() => onChange(t.key)}
            className={clsx(
              'flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors',
              isActive
                ? 'bg-brand-600 text-white shadow-xs'
                : 'text-ink-400 hover:bg-surface-800 hover:text-ink-100'
            )}
          >
            {t.icon && <t.icon className="h-3.5 w-3.5" aria-hidden="true" />}
            {t.label}
            {typeof t.count === 'number' && t.count > 0 && (
              <span
                className={clsx(
                  'ml-0.5 rounded-full px-1.5 py-px text-2xs font-semibold tabular-nums',
                  isActive ? 'bg-white/20 text-white' : 'bg-surface-800 text-ink-400'
                )}
              >
                {t.count}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}

/** Filter bar row that sits above or inside a table card. */
export function Toolbar({ children, className }) {
  return (
    <div className={clsx('flex flex-wrap items-center gap-2', className)}>{children}</div>
  )
}

export function ToolbarSpacer() {
  return <div className="ml-auto" />
}

/** Inline notice — for contextual guidance that is not a transient toast. */
export function Callout({ tone = 'info', icon: Icon, title, children, action, className }) {
  const tones = {
    info: 'border-brand-200 bg-brand-50 text-brand-700 dark:border-brand-500/30 dark:bg-brand-500/10 dark:text-brand-400',
    warning:
      'border-amber-300 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300',
    danger: 'border-red-300 bg-red-50 text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300',
    success:
      'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300',
    neutral: 'border-surface-700 bg-surface-850 text-ink-300',
  }

  return (
    <div className={clsx('rounded-lg border p-3.5', tones[tone] || tones.info, className)}>
      <div className="flex items-start gap-2.5">
        {Icon && <Icon className="mt-0.5 h-4 w-4 flex-none" aria-hidden="true" />}
        <div className="min-w-0 flex-1 text-sm leading-relaxed">
          {title && <p className="font-semibold">{title}</p>}
          {children && <div className={clsx(title && 'mt-1', 'opacity-95')}>{children}</div>}
        </div>
      </div>
      {action && <div className="mt-3 flex flex-wrap gap-2 pl-6.5">{action}</div>}
    </div>
  )
}
