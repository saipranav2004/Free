import { Search, X } from 'lucide-react'
import clsx from 'clsx'

/**
 * Search field with a leading icon and a clear affordance.
 *
 * The clear button matters more than it looks: with debounced search, a
 * user who selects-all-and-deletes still waits the debounce before results
 * come back. An explicit clear gives them a deterministic way out, and the
 * `onClear` callback lets the page reset the offset/page cursor at the same
 * time — which is where stale-pagination bugs come from.
 */
export function SearchInput({
  value,
  onChange,
  onClear,
  placeholder = 'Search…',
  className,
  size = 'md',
  ...props
}) {
  const h = size === 'sm' ? 'h-8 text-xs' : 'h-9 text-sm'
  return (
    <div className={clsx('relative min-w-0', className)}>
      <Search
        className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500"
        aria-hidden="true"
      />
      <input
        type="search"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={clsx(
          'w-full rounded-md border border-surface-700 bg-surface-800 pl-8.5 pr-8 text-ink-50 shadow-xs',
          'placeholder:text-ink-500 hover:border-surface-600',
          'focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/25',
          '[&::-webkit-search-cancel-button]:hidden',
          h
        )}
        style={{ paddingLeft: '2.125rem' }}
        {...props}
      />
      {value && (
        <button
          type="button"
          onClick={() => {
            onChange('')
            onClear?.()
          }}
          aria-label="Clear search"
          className="absolute right-1.5 top-1/2 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded text-ink-500 transition-colors hover:bg-surface-700 hover:text-ink-200"
        >
          <X className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      )}
    </div>
  )
}

/** Compact labelled <select> for toolbar filters. */
export function FilterSelect({ label, value, onChange, options, allLabel = 'All', className }) {
  return (
    <label className={clsx('flex flex-none items-center gap-2', className)}>
      <span className="text-xs font-medium text-ink-400">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-8 rounded-md border border-surface-700 bg-surface-800 pl-2.5 pr-7 text-xs text-ink-100 shadow-xs hover:border-surface-600 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/25"
      >
        <option value="">{allLabel}</option>
        {options.map((o) => {
          const val = typeof o === 'string' ? o : o.value
          const lab = typeof o === 'string' ? o : o.label
          return (
            <option key={val} value={val}>
              {lab}
            </option>
          )
        })}
      </select>
    </label>
  )
}
