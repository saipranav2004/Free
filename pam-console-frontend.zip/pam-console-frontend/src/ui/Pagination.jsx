import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from './Button'

/**
 * Page-number pagination for endpoints returning
 * { page, page_size, total, total_pages }.
 *
 * Deliberate edge cases (each of these was a real stuck-state class of bug):
 *  - total_pages 0 or 1 renders nothing rather than "Page 1 of 0".
 *  - Prev/Next are bounds-checked so a stale page number left over from a
 *    previous filter can never request a page that does not exist.
 *  - The record range is always shown, so an operator auditing a list knows
 *    exactly how much of the set they are looking at.
 */
export function Pagination({ page, pageSize, total, totalPages, onPageChange, className }) {
  if (!totalPages || totalPages <= 1) return null

  const canPrev = page > 1
  const canNext = page < totalPages
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1
  const end = Math.min(page * pageSize, total)

  return (
    <div
      className={
        'flex flex-wrap items-center justify-between gap-3 border-t border-surface-700 bg-surface-875 px-4 py-2.5 text-xs text-ink-400 ' +
        (className || '')
      }
    >
      <span className="tabular-nums">
        <span className="font-medium text-ink-200">{start}</span>–
        <span className="font-medium text-ink-200">{end}</span> of{' '}
        <span className="font-medium text-ink-200">{total}</span>
      </span>
      <div className="flex items-center gap-1.5">
        <Button
          size="xs"
          variant="secondary"
          icon={ChevronLeft}
          disabled={!canPrev}
          onClick={() => canPrev && onPageChange(page - 1)}
        >
          Previous
        </Button>
        <span className="px-2 tabular-nums text-ink-300">
          Page <span className="font-medium text-ink-100">{page}</span> of {totalPages}
        </span>
        <Button
          size="xs"
          variant="secondary"
          iconRight={ChevronRight}
          disabled={!canNext}
          onClick={() => canNext && onPageChange(page + 1)}
        >
          Next
        </Button>
      </div>
    </div>
  )
}

/** Offset/limit variant — the audit search endpoint pages this way. */
export function OffsetPagination({ offset, limit, total, onOffsetChange, className }) {
  const canPrev = offset > 0
  const canNext = offset + limit < total
  if (!canPrev && !canNext) return null

  const start = total === 0 ? 0 : offset + 1
  const end = Math.min(offset + limit, total)

  return (
    <div
      className={
        'flex flex-wrap items-center justify-between gap-3 border-t border-surface-700 bg-surface-875 px-4 py-2.5 text-xs text-ink-400 ' +
        (className || '')
      }
    >
      <span className="tabular-nums">
        <span className="font-medium text-ink-200">{start}</span>–
        <span className="font-medium text-ink-200">{end}</span> of{' '}
        <span className="font-medium text-ink-200">{total}</span>
      </span>
      <div className="flex items-center gap-1.5">
        <Button
          size="xs"
          variant="secondary"
          icon={ChevronLeft}
          disabled={!canPrev}
          onClick={() => canPrev && onOffsetChange(Math.max(0, offset - limit))}
        >
          Previous
        </Button>
        <Button
          size="xs"
          variant="secondary"
          iconRight={ChevronRight}
          disabled={!canNext}
          onClick={() => canNext && onOffsetChange(offset + limit)}
        >
          Next
        </Button>
      </div>
    </div>
  )
}
