import { useEffect, useId, useRef, useCallback } from 'react'
import { createPortal } from 'react-dom'
import clsx from 'clsx'
import { X } from 'lucide-react'
import { IconButton } from './Button'

/**
 * The one dialog primitive.
 *
 * The previous implementation had four separate bugs repeated across nine
 * hand-rolled modals, all fixed here once:
 *
 *  1. Escape did nothing. The handler was `onKeyDown` on a plain <div>,
 *     which never receives key events because the div is not focusable and
 *     focus was still on the page behind it. Now a document-level keydown
 *     listener handles it.
 *  2. Clicking the backdrop did nothing — users had to find the small X.
 *     Now handled, with a mousedown-target guard so a drag that *starts*
 *     inside the panel and ends on the backdrop does not close the dialog
 *     (a real data-loss bug when selecting text in a form).
 *  3. The page behind kept scrolling under the overlay. Now the body is
 *     scroll-locked, with padding compensation so the layout does not jump
 *     sideways as the scrollbar disappears.
 *  4. Focus was never moved into the dialog and never restored on close,
 *     and Tab could walk out of the modal into the page behind it. Now
 *     focus moves in on open, is trapped in a cycle, and returns to the
 *     element that opened the dialog on close.
 *
 * Rendered through a portal so a modal opened from deep inside a card is
 * never clipped by an ancestor's `overflow-hidden`.
 */
const SIZES = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-lg',
  xl: 'max-w-2xl',
  '2xl': 'max-w-4xl',
}

const FOCUSABLE =
  'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),[tabindex]:not([tabindex="-1"])'

export function Modal({
  open,
  onClose,
  title,
  description,
  icon: Icon,
  iconTone = 'brand',
  size = 'md',
  footer,
  children,
  /** Set while a write is in flight — blocks Escape/backdrop so a user
   *  cannot dismiss the dialog mid-request and lose the outcome. */
  busy = false,
  className,
}) {
  const titleId = useId()
  const descId = useId()
  const panelRef = useRef(null)
  const previouslyFocused = useRef(null)
  const pointerDownInside = useRef(false)

  const requestClose = useCallback(() => {
    if (busy) return
    onClose?.()
  }, [busy, onClose])

  // Escape + focus trap, at the document level so it works regardless of
  // where focus currently sits.
  useEffect(() => {
    if (!open) return undefined

    const onKeyDown = (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        requestClose()
        return
      }
      if (e.key !== 'Tab') return
      const panel = panelRef.current
      if (!panel) return
      const nodes = Array.from(panel.querySelectorAll(FOCUSABLE)).filter(
        (n) => n.offsetParent !== null || n === document.activeElement
      )
      if (nodes.length === 0) {
        e.preventDefault()
        return
      }
      const first = nodes[0]
      const last = nodes[nodes.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }

    document.addEventListener('keydown', onKeyDown, true)
    return () => document.removeEventListener('keydown', onKeyDown, true)
  }, [open, requestClose])

  // Scroll lock with scrollbar-width compensation.
  useEffect(() => {
    if (!open) return undefined
    const { body } = document
    const prevOverflow = body.style.overflow
    const prevPadding = body.style.paddingRight
    const scrollbar = window.innerWidth - document.documentElement.clientWidth
    body.style.overflow = 'hidden'
    if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`
    return () => {
      body.style.overflow = prevOverflow
      body.style.paddingRight = prevPadding
    }
  }, [open])

  // Move focus in on open; restore it on close.
  useEffect(() => {
    if (!open) return undefined
    previouslyFocused.current = document.activeElement
    const panel = panelRef.current
    const target =
      panel?.querySelector('[data-autofocus]') ||
      panel?.querySelector(FOCUSABLE) ||
      panel
    // rAF so the element exists and is laid out before we focus it.
    const raf = requestAnimationFrame(() => target?.focus?.())
    return () => {
      cancelAnimationFrame(raf)
      const prev = previouslyFocused.current
      if (prev && typeof prev.focus === 'function') prev.focus()
    }
  }, [open])

  if (!open) return null

  const toneRing = {
    brand: 'bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400',
    danger: 'bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-400',
    warning: 'bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400',
    emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
  }[iconTone]

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-950/50 p-4 backdrop-blur-[2px] animate-fade-in sm:items-center sm:p-6"
      onMouseDown={(e) => {
        pointerDownInside.current = panelRef.current?.contains(e.target) ?? false
      }}
      onMouseUp={(e) => {
        if (e.target === e.currentTarget && !pointerDownInside.current) requestClose()
        pointerDownInside.current = false
      }}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? titleId : undefined}
        aria-describedby={description ? descId : undefined}
        tabIndex={-1}
        className={clsx(
          'my-auto w-full rounded-card border border-surface-700 bg-surface-900 shadow-modal outline-none animate-scale-in',
          SIZES[size] || SIZES.md,
          className
        )}
      >
        {(title || Icon) && (
          <div className="flex items-start gap-3 border-b border-surface-700 px-5 py-4">
            {Icon && (
              <span
                className={clsx(
                  'mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded-lg',
                  toneRing
                )}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
              </span>
            )}
            <div className="min-w-0 flex-1">
              {title && (
                <h2 id={titleId} className="text-sm font-semibold text-ink-50">
                  {title}
                </h2>
              )}
              {description && (
                <p id={descId} className="mt-1 text-sm text-ink-400">
                  {description}
                </p>
              )}
            </div>
            <IconButton
              icon={X}
              label="Close"
              size="sm"
              onClick={requestClose}
              disabled={busy}
              className="-mr-1 -mt-1"
            />
          </div>
        )}

        <div className="max-h-[calc(100vh-16rem)] overflow-y-auto px-5 py-4">{children}</div>

        {footer && (
          <div className="flex flex-wrap items-center justify-end gap-2 rounded-b-card border-t border-surface-700 bg-surface-875 px-5 py-3.5">
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body
  )
}
