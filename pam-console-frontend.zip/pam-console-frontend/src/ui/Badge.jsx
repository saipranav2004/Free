import clsx from 'clsx'

/**
 * Status pill. Every status in the console renders through this so a design
 * change is a one-file edit rather than a grep across twenty pages.
 *
 * `tone` is the preferred API. `className` is still honoured for the
 * status maps in config/constants.js.
 */
const TONES = {
  neutral: 'bg-surface-800 text-ink-300 ring-surface-600',
  brand: 'bg-brand-50 text-brand-700 ring-brand-600/20 dark:bg-brand-500/15 dark:text-brand-400 dark:ring-brand-500/30',
  success:
    'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/15 dark:text-emerald-400 dark:ring-emerald-500/30',
  warning:
    'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/15 dark:text-amber-400 dark:ring-amber-500/30',
  danger: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-400 dark:ring-red-500/30',
  purple:
    'bg-purple-50 text-purple-700 ring-purple-600/20 dark:bg-purple-500/15 dark:text-purple-400 dark:ring-purple-500/30',
}

export function Badge({ children, tone, className, icon: Icon, size = 'sm' }) {
  return (
    <span
      className={clsx(
        'inline-flex flex-none items-center gap-1 rounded-full font-medium ring-1 ring-inset',
        size === 'xs' ? 'px-1.5 py-0.5 text-2xs' : 'px-2 py-0.5 text-xs',
        className || TONES[tone] || TONES.neutral
      )}
    >
      {Icon && <Icon className="h-3 w-3" aria-hidden="true" />}
      {children}
    </span>
  )
}

/** Small coloured dot + label — lighter weight than a full pill, used where
 *  a table row already carries a lot of ink (e.g. live session rows). */
export function StatusDot({ tone = 'neutral', label, pulse = false }) {
  const color = {
    neutral: 'bg-ink-500',
    brand: 'bg-brand-500',
    success: 'bg-emerald-500',
    warning: 'bg-amber-500',
    danger: 'bg-red-500',
  }[tone]

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-ink-200">
      <span className="relative flex h-2 w-2 flex-none">
        {pulse && (
          <span
            className={clsx('absolute inline-flex h-full w-full animate-ping rounded-full opacity-60', color)}
            aria-hidden="true"
          />
        )}
        <span className={clsx('relative inline-flex h-2 w-2 rounded-full', color)} aria-hidden="true" />
      </span>
      {label}
    </span>
  )
}
