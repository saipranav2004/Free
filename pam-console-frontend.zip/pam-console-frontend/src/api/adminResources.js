import { http } from '../lib/http'

// Admin Center resource management (/api/v1/pam/admin/resources/*) —
// registering, deleting and (re)credentialing a resource is admin/root only
// (middleware.RequireAdmin). Ordinary users keep read/browse/connect via
// api/resources.js. Same `http` client, same Bearer token — there is no
// separate service-token trust boundary, only the "roles" claim on the
// caller's own JWT.

export async function createResource(payload) {
  const { data } = await http.post('/api/v1/pam/admin/resources', payload)
  return data.data.resource
}

export async function deleteResource(id) {
  const { data } = await http.delete(`/api/v1/pam/admin/resources/${id}`)
  return data.data
}

/**
 * Store the resource-attached credential.
 * ===========================================================================
 * BUG FIX — this call always failed with:
 *     "AccountName is required", "Credential is required"
 *
 * Those are Go *struct field* names. Gin's validator reports the struct
 * field, not the JSON tag, when a `binding:"required"` rule fails — so an
 * error naming `AccountName` and `Credential` means the handler's request
 * struct is shaped like:
 *
 *     type StoreCredentialRequest struct {
 *         AccountName string `json:"account_name" binding:"required"`
 *         Credential  string `json:"credential"   binding:"required"`
 *         ...
 *     }
 *
 * The form was posting `{ username, secret, credential_type }`. Neither
 * required field was ever present, so the request could not succeed no
 * matter what the operator typed — the two values went out under names the
 * handler does not bind.
 *
 * The payload is normalised here, in one place, rather than in the form, so
 * every future caller gets the right shape.
 *
 * COMPATIBILITY NOTE: the legacy `username` / `secret` keys are still sent
 * alongside the correct ones. Go's encoding/json ignores unknown object
 * members unless the handler explicitly calls DisallowUnknownFields (this
 * one does not — it uses ShouldBindJSON), so carrying both is inert against
 * the current backend and keeps the call working if any deployment is still
 * running the older handler. Drop the aliases once the contract is
 * confirmed in the Go source.
 */
export async function storeResourceCredential(id, { accountName, credential, credentialType }) {
  const payload = {
    account_name: accountName,
    credential,
    credential_type: credentialType || undefined,
    // Legacy aliases — see the compatibility note above.
    username: accountName,
    secret: credential,
  }
  const { data } = await http.post(`/api/v1/pam/admin/resources/${id}/credential`, payload)
  return data.data
}

// Unchanged: this endpoint was already working, so its payload is left
// exactly as it was rather than "fixed" speculatively.
export async function rotateResourceCredential(id, newCredential) {
  const { data } = await http.post(`/api/v1/pam/admin/resources/${id}/rotate`, {
    new_credential: newCredential,
  })
  return data.data
}
