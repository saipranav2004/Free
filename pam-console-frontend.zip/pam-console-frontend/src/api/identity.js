import { http } from '../lib/http'
import { isUsableId } from '../lib/entity'

// Identity Management — the Admin Center's user lifecycle screens
// (/api/v1/pam/admin/identity/*). Admin/root only. PAM owns user accounts
// end to end: full CRUD + lifecycle + RBAC role assignment + PBAC direct
// policy attachment. See identity_handler.go.

/**
 * Guard every id-bearing path.
 *
 * BUG FIX — the console was issuing
 *     GET /api/v1/pam/admin/identity/users/undefined
 *
 * `${user.id}` where `id` is undefined interpolates the *string* "undefined",
 * which is a structurally valid URL segment: the router matched, the detail
 * page mounted, and a request went out for a user literally named
 * "undefined". Throwing here converts a silent 404 loop into an immediate,
 * explicit error the UI can render, and stops the malformed request ever
 * reaching the backend.
 */
function requireId(id, what = 'identifier') {
  if (!isUsableId(id)) {
    const err = new Error(`Missing ${what}.`)
    err.response = {
      status: 400,
      data: {
        error: `This record has no usable ${what}, so it cannot be loaded. Return to the list and try again.`,
        code: 'missing_identifier',
      },
    }
    throw err
  }
  return String(id)
}

export async function listUsers(q, signal) {
  const { data } = await http.get('/api/v1/pam/admin/identity/users', {
    params: q ? { q } : undefined,
    signal,
  })
  return data.data // { users, count }
}

export async function getUser(id, signal) {
  const safeId = requireId(id, 'user id')
  const { data } = await http.get(`/api/v1/pam/admin/identity/users/${safeId}`, { signal })
  return data.data // { user, access: { roles, policies } }
}

export async function createUser(payload) {
  const { data } = await http.post('/api/v1/pam/admin/identity/users', payload)
  return data.data.user
}

export async function updateUser(id, payload) {
  const { data } = await http.patch(`/api/v1/pam/admin/identity/users/${requireId(id, 'user id')}`, payload)
  return data.data.user
}

export async function setUserStatus(id, status) {
  const { data } = await http.post(
    `/api/v1/pam/admin/identity/users/${requireId(id, 'user id')}/status`,
    { status }
  )
  return data.data
}

export async function deleteUser(id) {
  const { data } = await http.delete(`/api/v1/pam/admin/identity/users/${requireId(id, 'user id')}`)
  return data.data
}

export async function resetUserPassword(id, newPassword) {
  const { data } = await http.post(
    `/api/v1/pam/admin/identity/users/${requireId(id, 'user id')}/reset-password`,
    { new_password: newPassword }
  )
  return data.data
}

export async function assignRole(userId, roleName) {
  const { data } = await http.post(
    `/api/v1/pam/admin/identity/users/${requireId(userId, 'user id')}/roles`,
    { role_name: roleName }
  )
  return data.data
}

export async function removeRole(userId, roleName) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${requireId(userId, 'user id')}/roles/${encodeURIComponent(roleName)}`
  )
  return data.data
}

export async function attachPolicy(userId, policyId) {
  const { data } = await http.post(
    `/api/v1/pam/admin/identity/users/${requireId(userId, 'user id')}/policies`,
    { policy_id: requireId(policyId, 'policy id') }
  )
  return data.data
}

export async function detachPolicy(userId, policyId) {
  const { data } = await http.delete(
    `/api/v1/pam/admin/identity/users/${requireId(userId, 'user id')}/policies/${requireId(policyId, 'policy id')}`
  )
  return data.data
}
