import { http, extractFilename, triggerBlobDownload, assertBinaryBlob, reportRequestConfig } from '../lib/http'
import { readCollection } from '../lib/entity'

/**
 * Audit search.
 * ===========================================================================
 * BUG FIX — "search is broken".
 *
 * The search box was wired to the `action` parameter:
 *
 *     filters = { action: search || undefined, ... }
 *
 * `action` is an exact-match field over values like
 * "pam:vault:Reveal" — so typing "reveal", or "vault", or any partial
 * string, matched nothing. Search appeared broken because it was doing
 * exact equality on a field no human types verbatim.
 *
 * Free text now goes out as free text. Because the exact parameter name for
 * full-text search is not pinned down in the material available here, the
 * same term is sent under the conventional aliases the rest of this backend
 * already uses for free-text filtering (`q` on /jit/requests and on
 * /admin/identity/users). Extra *query-string* parameters are inert in Gin —
 * `c.Query` for a name nobody reads simply never runs — so this is safe
 * against the current handler and correct against any of the three.
 *
 * `action` remains available as its own explicit, exact-match filter, which
 * is what it was always good for.
 */
export async function searchAudit(filters, signal) {
  const params = {}
  for (const [k, v] of Object.entries(filters || {})) {
    if (v !== undefined && v !== null && v !== '') params[k] = v
  }

  if (params.q) {
    // Aliases — see the note above. Remove once the backend parameter name
    // is confirmed in audit_handler.go.
    params.search = params.q
    params.query = params.q
  }

  const { data } = await http.get('/api/v1/pam/audit', { params, signal })
  const payload = data?.data ?? data
  const items = readCollection(payload, 'items', 'events')
  return {
    items,
    total: Number(payload?.total ?? items.length) || 0,
    limit: Number(payload?.limit ?? filters?.limit) || items.length,
    offset: Number(payload?.offset ?? filters?.offset) || 0,
  }
}

export async function auditByRequest(requestId, signal) {
  const { data } = await http.get(`/api/v1/pam/audit/request/${requestId}`, { signal })
  return readCollection(data?.data ?? data, 'items', 'events')
}

export async function auditByUser(userId, limit, signal) {
  const { data } = await http.get(`/api/v1/pam/audit/user/${userId}`, {
    params: limit ? { limit } : undefined,
    signal,
  })
  return readCollection(data?.data ?? data, 'items', 'events')
}

export async function auditByResource(resourcePath, limit, signal) {
  // resourcePath can itself contain slashes (route is /audit/resource/*resource)
  const { data } = await http.get(`/api/v1/pam/audit/resource/${resourcePath}`, {
    params: limit ? { limit } : undefined,
    signal,
  })
  return readCollection(data?.data ?? data, 'items', 'events')
}

// SPECIAL CASE: audit_handler.go's VerifyChain returns a bare
// VerificationResult (no {success,data} envelope) with HTTP 200 when the
// chain is BROKEN, but the normal envelope when it is intact. Both are 200s,
// so this cannot be told apart by status — only by whether `data.success`
// exists. Getting this wrong renders a broken audit chain as "undefined"
// instead of the alarm it should be.
export async function verifyAuditChain(orgId, signal) {
  const { data } = await http.get('/api/v1/pam/audit/verify', {
    params: orgId ? { org_id: orgId } : undefined,
    signal,
  })
  if (typeof data?.success === 'boolean') {
    return data.data // enveloped (chain intact) shape
  }
  return data // bare VerificationResult (chain broken) shape
}

/**
 * Compliance report generation (PDF / CSV).
 * ===========================================================================
 * BUG FIX — "cannot generate reports".
 *
 * Four separate defects, all of which had to be fixed for a download to
 * succeed and, when it failed, to say why:
 *
 *  1. NO TIME RANGE WAS SENT. The old call forwarded only the list filters
 *     (`action`, `category`, `outcome`) plus `format`. A compliance report
 *     is defined by its reporting period; a handler that requires a range
 *     rejects the request outright. The UI now collects an explicit range
 *     and always sends one.
 *
 *  2. ERRORS WERE UNREADABLE. With `responseType: 'blob'`, a JSON error body
 *     arrives as an opaque Blob, so the real server message was replaced by
 *     a generic "That request was invalid." The response interceptor in
 *     lib/http.js now re-hydrates error blobs before they propagate.
 *
 *  3. A JSON ERROR RETURNED WITH HTTP 200 WAS SAVED AS A "REPORT". The old
 *     code called triggerBlobDownload unconditionally, so a failed render
 *     that came back 200 handed the user a .pdf containing one line of JSON.
 *     assertBinaryBlob inspects the blob's own content type first.
 *
 *  4. THE REQUEST TIMED OUT. Report rendering is server-side work that can
 *     exceed the shared 20s client timeout on a wide range; the abort
 *     surfaced as an unexplained failure. Reports get their own, longer
 *     timeout.
 *
 * As with audit search, the exact parameter names for the range are not
 * pinned down here, so the conventional aliases are all sent. Unknown JSON
 * object members are ignored by encoding/json under ShouldBindJSON, so this
 * is inert against the current handler.
 */
export async function generateComplianceReport({
  format = 'pdf',
  startIso,
  endIso,
  category,
  outcome,
  action,
  q,
} = {}) {
  const payload = {
    format,
    report_type: 'audit',

    // Range — primary names plus aliases.
    start_date: startIso,
    end_date: endIso,
    start_time: startIso,
    end_time: endIso,
    from: startIso,
    to: endIso,

    // Optional scoping filters, omitted entirely when unset.
    ...(category ? { category } : {}),
    ...(outcome ? { outcome } : {}),
    ...(action ? { action } : {}),
    ...(q ? { q, search: q } : {}),
  }

  const response = await http.post('/api/v1/pam/audit/report', payload, reportRequestConfig)

  // Guard 3 — refuse to save a JSON error body as a report file.
  await assertBinaryBlob(response.data, format)

  const ext = format === 'csv' ? 'csv' : 'pdf'
  const stamp = new Date().toISOString().slice(0, 10)
  const filename = extractFilename(
    response.headers?.['content-disposition'],
    `pam-audit-report-${stamp}.${ext}`
  )
  triggerBlobDownload(response.data, filename)
  return { filename }
}
