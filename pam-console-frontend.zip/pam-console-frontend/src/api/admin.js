import { http } from '../lib/http'
import { readCollection, readPagination } from '../lib/entity'

// Admin Center reads + attributable actions (/api/v1/pam/admin/*), gated
// server-side by middleware.RequireAdmin (the caller's own JWT "roles" claim
// must include "admin" or "root"). Every call uses the SAME `http` client
// and the SAME Bearer token as the rest of the app — the acting admin IS the
// logged-in user (middleware/admin.go's AdminIdentityFromContext).

/**
 * Normalise a paged list response.
 * ===========================================================================
 * BUG FIX — JIT requests were visible on the Admin Overview but the
 * dedicated /admin/jit page showed "No JIT requests found."
 *
 * Both screens call the same endpoint. The two differences were:
 *
 *   a) Overview always sent `status=PENDING`; the JIT page defaulted its
 *      filter to "" and therefore omitted `status` entirely. An endpoint
 *      that treats a missing status as "match nothing" (rather than "match
 *      all") returns an empty page for the unfiltered call.
 *   b) The page read `data.requests` directly. Any other envelope key —
 *      `items`, `results`, or a bare array — rendered as empty with no
 *      error, because an empty list is not an error state.
 *
 * (a) is handled at the call sites, which now always send an explicit
 * status set and default the admin queue to the actionable statuses.
 * (b) is handled here: the collection is resolved from whichever key the
 * handler actually used, so a naming difference can never again present as
 * "there is no data".
 */
function normalizePaged(payload, key) {
  const items = readCollection(payload, key)
  return {
    [key]: items,
    items,
    pagination: readPagination(payload, items.length),
    raw: payload,
  }
}

export async function listJitRequests(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/jit-requests', { params, signal })
  return normalizePaged(data.data, 'requests')
}

export async function getJitRequest(id, signal) {
  const { data } = await http.get(`/api/v1/pam/admin/jit-requests/${id}`, { signal })
  return data.data // { request, grant?, audit_trail? }
}

export async function listGrants(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/grants', { params, signal })
  return normalizePaged(data.data, 'grants')
}

export async function listSessions(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/sessions', { params, signal })
  return normalizePaged(data.data, 'sessions')
}

export async function listRecordings(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/recordings', { params, signal })
  return normalizePaged(data.data, 'recordings')
}

export async function listAudit(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/audit', { params, signal })
  return normalizePaged(data.data, 'events')
}

// Unlike the user-facing /api/v1/pam/audit/verify, this admin route ALWAYS
// wraps its result in the normal envelope (admin_handler.go calls
// response.Success unconditionally, whether res.Valid is true or false), so
// no bare-response special case is needed here.
export async function verifyAudit(orgId, signal) {
  const { data } = await http.get('/api/v1/pam/admin/audit/verify', {
    params: orgId ? { org_id: orgId } : undefined,
    signal,
  })
  return data?.data?.verification ?? data?.data ?? data
}

export async function listBreakglass(params, signal) {
  const { data } = await http.get('/api/v1/pam/admin/breakglass', { params, signal })
  const normalized = normalizePaged(data.data, 'requests')
  return { ...normalized, grants: readCollection(data.data?.grants ? data.data : {}, 'grants') }
}

export async function getBreakglassReport(grantId, signal) {
  const { data } = await http.get(`/api/v1/pam/admin/breakglass/${grantId}/report`, { signal })
  return data?.data?.report ?? data?.data ?? null
}

export async function getStats(signal) {
  const { data } = await http.get('/api/v1/pam/admin/stats', { signal })
  return data.data
}

// ---------------------------------------------------------------------------
// Actions (attributable writes — automatically attributed to the logged-in
// admin/root; no header to forge, no separate identity to propagate)
// ---------------------------------------------------------------------------

// Requires an MFA-verified admin token (RequireMFA on this route) and
// enforces separation of duty (an approver cannot approve their own
// request). Both surface through the normalized message, not a code.
export async function approveJitRequest(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/jit-requests/${id}/approve`, { reason })
  return data.data // { request, grant, expires_at }
}

export async function denyJitRequest(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/jit-requests/${id}/deny`, { reason })
  return data.data
}

export async function revokeGrant(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/grants/${id}/revoke`, { reason })
  return data.data // { grant, sessions_killed }
}

export async function killSession(id, reason) {
  const { data } = await http.post(`/api/v1/pam/admin/actions/sessions/${id}/kill`, { reason })
  return data.data
}
