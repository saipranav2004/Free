import { useEffect, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import {
  ShieldCheck, AlertTriangle, RefreshCw, KeyRound, Smartphone, Info, HelpCircle,
} from 'lucide-react'
import { mfaSetupInitiate, mfaSetupVerify } from '../../api/auth'
import { apiErrorMessage } from '../../lib/apiError'
import { formatEnabledAt } from '../../lib/mfaStatus'
import { CopyButton } from '../common/CopyButton'
import { Card, CardHeader, CardTitle, CardFooter, DetailList } from '../common/Layout'
import { Button } from '../common/Button'
import { OtpInput, isCompleteOtp } from '../common/OtpInput'

// Enrolment: initiate (QR + secret) -> confirm with a six-digit code ->
// acknowledge the backup codes, which the backend shows exactly once
// (auth_handler.go: "Save these backup codes — they will NOT be shown again").
//
// Which state this opens in is driven ENTIRELY by `status`, read from
// /auth/me via lib/mfaStatus — never by local "did you enrol in this tab"
// state, and never inferred from session verification. See mfaStatus.js for
// the two bugs that rule exists to prevent.
export function MfaEnrollment({ status, onEnrolled }) {
  const queryClient = useQueryClient()
  const enabled = status?.enabled === true
  const unknown = status?.unknown === true
  const [step, setStep] = useState('idle') // idle | qr | backup-codes
  const [setupData, setSetupData] = useState(null)
  const [code, setCode] = useState('')
  const [backupCodes, setBackupCodes] = useState(null)
  const [error, setError] = useState(null)

  // /auth/me resolves after first paint. If an in-flight enrolment is not in
  // progress, always follow the server's answer.
  useEffect(() => {
    if (step === 'qr' || step === 'backup-codes') return
    setStep('idle')
  }, [enabled, step])

  const initiate = useMutation({
    mutationFn: mfaSetupInitiate,
    onSuccess: (data) => {
      setSetupData(data)
      setCode('')
      setStep('qr')
      setError(null)
    },
    onError: (err) => setError(apiErrorMessage(err)),
  })

  const verify = useMutation({
    mutationFn: (c) => mfaSetupVerify(setupData.mfa_device_id, c),
    onSuccess: (data) => {
      setBackupCodes(data.backup_codes || [])
      setStep('backup-codes')
      setError(null)
      // Re-read /auth/me so every other MFA surface (profile menu, header
      // chip) flips to the enabled state without a reload.
      queryClient.invalidateQueries({ queryKey: ['me'] })
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      setCode('')
    },
  })

  const submitCode = (c) => {
    if (!isCompleteOtp(c) || verify.isPending) return
    verify.mutate(c)
  }

  // --- enrolment in progress ------------------------------------------------
  if (step === 'qr') {
    return (
      <Card>
        <CardHeader>
          <CardTitle icon={Smartphone}>
            {enabled ? 'Replace authenticator' : 'Set up your authenticator'}
          </CardTitle>
        </CardHeader>
        <div className="px-4 py-4">
          <p className="text-sm leading-relaxed text-ink-400">
            Scan this code with Google Authenticator, 1Password, Microsoft Authenticator or any TOTP
            app
            {enabled ? ' — the new device replaces the current one once you confirm a code.' : '.'}
          </p>
          <div className="mt-4 flex flex-col items-center gap-5 sm:flex-row sm:items-start">
            {setupData?.qr_code_base64 && (
              <img
                // auth_service.go's SetupMFAInitiate returns a full
                // `data:image/png;base64,…` URI already — prepending the
                // prefix again produced an invalid data URI that silently
                // failed to render.
                src={setupData.qr_code_base64}
                alt="MFA enrollment QR code"
                className="h-40 w-40 flex-none rounded-xl border border-surface-700 bg-white p-2"
              />
            )}
            <div className="w-full min-w-0 space-y-2">
              <p className="text-xs font-medium text-ink-300">Or enter this key manually</p>
              <div className="flex items-center gap-2">
                <code className="min-w-0 flex-1 truncate rounded-lg border border-surface-700 bg-surface-800 px-2.5 py-2 font-mono text-xs text-ink-200">
                  {setupData?.secret}
                </code>
                <CopyButton value={setupData?.secret || ''} />
              </div>
              <p className="text-xs leading-relaxed text-ink-500">
                Keep this window open until you have confirmed a code — leaving now cancels the
                enrolment.
              </p>
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault()
              submitCode(code)
            }}
            className="mt-5 border-t border-surface-800 pt-5"
          >
            <p className="mb-2 text-xs font-medium text-ink-300">
              Enter the 6-digit code from your app
            </p>
            <div className="max-w-[22rem]">
              <OtpInput
                value={code}
                onChange={setCode}
                onComplete={submitCode}
                invalid={!!error}
                disabled={verify.isPending}
                autoFocus
                ariaLabel="Confirmation code"
              />
            </div>
            {error && (
              <p className="mt-2.5 text-sm font-medium text-red-600 dark:text-red-400" role="alert">
                {error}
              </p>
            )}
            <div className="mt-4 flex items-center gap-2.5">
              <Button
                type="submit"
                variant="primary"
                loading={verify.isPending}
                disabled={!isCompleteOtp(code)}
              >
                Activate
              </Button>
              <Button
                type="button"
                variant="ghost"
                onClick={() => {
                  setCode('')
                  setError(null)
                  setStep('idle')
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </Card>
    )
  }

  // --- codes shown exactly once --------------------------------------------
  if (step === 'backup-codes') {
    return (
      <Card className="border-emerald-300/70 dark:border-emerald-800/50">
        <CardHeader className="border-emerald-200/70 bg-emerald-50/60 dark:border-emerald-900/40 dark:bg-emerald-950/20">
          <CardTitle icon={KeyRound}>Save your backup codes now</CardTitle>
        </CardHeader>
        <div className="px-4 py-4">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-amber-50 text-amber-600 ring-1 ring-inset ring-amber-600/15 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
              <AlertTriangle className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
            </span>
            <p className="text-sm leading-relaxed text-ink-400">
              MFA is now active. These codes will{' '}
              <strong className="font-semibold text-ink-100">not</strong> be shown again — each can
              be used once if you lose access to your authenticator app.
            </p>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl border border-surface-700 bg-surface-800 p-3 font-mono text-sm text-ink-100 sm:grid-cols-3">
            {(backupCodes || []).map((c) => (
              <span key={c} className="tabular-nums">
                {c}
              </span>
            ))}
          </div>
        </div>
        <CardFooter className="justify-between">
          <CopyButton value={(backupCodes || []).join('\n')} label="Copy all codes" />
          <Button
            variant="primary"
            icon={ShieldCheck}
            onClick={() => {
              setStep('idle')
              onEnrolled?.()
            }}
          >
            I&apos;ve saved these codes
          </Button>
        </CardFooter>
      </Card>
    )
  }

  // --- MFA is ON ------------------------------------------------------------
  if (enabled) {
    const on = formatEnabledAt(status?.enabledAt)
    return (
      <Card>
        <CardHeader>
          <CardTitle icon={ShieldCheck}>Multi-factor authentication</CardTitle>
          <span className="ml-auto flex items-center gap-1.5 rounded-md bg-emerald-50 px-2 py-1 text-2xs font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-hidden="true" />
            MFA enabled
          </span>
        </CardHeader>

        <div className="flex items-start gap-3.5 px-4 py-4">
          <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 ring-1 ring-inset ring-emerald-600/15 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
            <ShieldCheck className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink-100">
              This account is protected by a second factor
            </p>
            <p className="mt-1 text-sm leading-relaxed text-ink-400">
              A code from your authenticator app is required on every new sign-in, and for
              privileged actions such as revealing a vault credential.
            </p>
          </div>
        </div>

        <DetailList
          className="border-t border-surface-800"
          items={[
            {
              label: 'Method',
              value: (
                <span className="flex items-center gap-2">
                  <Smartphone className="h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
                  {status?.method || 'Authenticator app (TOTP)'}
                </span>
              ),
            },
            {
              label: 'Enabled',
              value: on || (
                <span className="text-ink-500">Active — enrolment date not reported by the API</span>
              ),
            },
            {
              label: 'This session',
              value: status?.verifiedThisSession ? (
                <span className="inline-flex items-center rounded-md bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25">
                  Verified
                </span>
              ) : (
                <span className="inline-flex items-center rounded-md bg-surface-800 px-2 py-0.5 text-xs font-medium text-ink-400 ring-1 ring-inset ring-surface-700">
                  Not verified — sign in again to unlock reveals
                </span>
              ),
            },
          ]}
        />

        {error && (
          <p className="border-t border-surface-800 px-4 py-3 text-sm text-red-600 dark:text-red-400">
            {error}
          </p>
        )}

        <CardFooter className="flex-wrap justify-between gap-y-3">
          <Button
            variant="secondary"
            size="sm"
            icon={RefreshCw}
            loading={initiate.isPending}
            onClick={() => initiate.mutate()}
          >
            Manage MFA — replace authenticator
          </Button>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 text-2xs text-ink-500">
              <Info className="h-3.5 w-3.5 flex-none" strokeWidth={1.75} />
              Turning MFA off is not self-service
            </span>
            <Button
              variant="dangerGhost"
              size="sm"
              disabled
              title="No self-service disable endpoint exists — an administrator must reset MFA for this account."
            >
              Disable MFA
            </Button>
          </div>
        </CardFooter>
      </Card>
    )
  }

  // --- status genuinely unknown --------------------------------------------
  // Neither an enabled flag nor a device came back. Offering "Enable MFA"
  // here would be a guess in the same shape as the original bug, so the card
  // says what it knows and still lets the user start enrolment deliberately.
  if (unknown) {
    return (
      <Card>
        <CardHeader>
          <CardTitle icon={ShieldCheck}>Multi-factor authentication</CardTitle>
          <span className="ml-auto text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
            Status unavailable
          </span>
        </CardHeader>
        <div className="flex items-start gap-3.5 px-4 py-4">
          <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl border border-surface-700 bg-surface-850 text-ink-400">
            <HelpCircle className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-ink-100">
              This deployment doesn&apos;t report MFA enrolment
            </p>
            <p className="mt-1 text-sm leading-relaxed text-ink-400">
              The account endpoint returned no enrolment flag and no registered device, so the
              console can&apos;t tell you whether a second factor is already active. Starting
              enrolment below is safe: if one already exists, confirming a new code replaces it.
              {status?.verifiedThisSession && (
                <>
                  {' '}
                  Your current session is marked MFA-verified, but that is a property of the
                  session, not proof of enrolment.
                </>
              )}
            </p>
          </div>
        </div>
        {error && <p className="px-4 pb-1 text-sm text-red-600 dark:text-red-400">{error}</p>}
        <CardFooter>
          <Button
            variant="secondary"
            icon={ShieldCheck}
            loading={initiate.isPending}
            onClick={() => initiate.mutate()}
          >
            Set up an authenticator
          </Button>
        </CardFooter>
      </Card>
    )
  }

  // --- MFA is OFF -----------------------------------------------------------
  return (
    <Card>
      <CardHeader>
        <CardTitle icon={ShieldCheck}>Multi-factor authentication</CardTitle>
        <span className="ml-auto flex items-center gap-1.5 rounded-md bg-amber-50 px-2 py-1 text-2xs font-semibold text-amber-700 ring-1 ring-inset ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
          <span className="h-1.5 w-1.5 rounded-full bg-amber-500" aria-hidden="true" />
          Not enabled
        </span>
      </CardHeader>
      <div className="flex items-start gap-3.5 px-4 py-4">
        <span className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-amber-50 text-amber-600 ring-1 ring-inset ring-amber-600/15 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25">
          <AlertTriangle className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-ink-100">Add a second factor</p>
          <p className="mt-1 text-sm leading-relaxed text-ink-400">
            Without MFA, privileged actions that require a verified session — revealing vault
            credentials, approving break-glass — will be refused.
          </p>
        </div>
      </div>
      {error && <p className="px-4 pb-1 text-sm text-red-600 dark:text-red-400">{error}</p>}
      <CardFooter>
        <Button
          variant="primary"
          icon={ShieldCheck}
          loading={initiate.isPending}
          onClick={() => initiate.mutate()}
        >
          Enable MFA
        </Button>
      </CardFooter>
    </Card>
  )
}
