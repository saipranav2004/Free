import { useMemo } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { ChevronRight, Menu } from 'lucide-react'
import { useThemeStore } from '../../store/themeStore'
import { CRUMB_LABELS } from '../../config/nav'
import { ThemeToggle } from './ThemeToggle'
import { GlobalSearch } from './GlobalSearch'
import { NotificationsMenu } from './NotificationsMenu'
import { UserMenu } from './UserMenu'
import logoWordmark from '../../assets/logo-wordmark.png'
import logoWordmarkDark from '../../assets/logo-wordmark-dark.png'
import logoMark from '../../assets/logo-mark.png'

// ---------------------------------------------------------------------------
// Top navigation bar
// ---------------------------------------------------------------------------
// Fixed to the viewport (position: fixed, top 0, full width, above every
// other layer of chrome) and 64px tall. The shell below it is offset by
// exactly that height, so the sidebar now STARTS UNDER the navbar rather
// than beside it — the navbar is the product-level frame, the sidebar is
// navigation within the product. Nothing in the navbar scrolls, ever.
//
// Left corner is reserved for the company mark and nothing else. Then the
// context block (console identity + breadcrumb), then a spacer, then the
// global-action cluster: jump-to, notifications, appearance, profile.
export const NAVBAR_HEIGHT_CLASS = 'h-16'

function Breadcrumb() {
  const { pathname } = useLocation()
  const crumbs = useMemo(() => {
    const parts = pathname.split('/').filter(Boolean)
    if (parts.length === 0) return []
    const out = []
    let acc = ''
    for (const p of parts) {
      acc += `/${p}`
      const label = CRUMB_LABELS[p]
      // Opaque segments (UUIDs, numeric ids) get a neutral label rather
      // than being printed raw — a 36-character UUID in a breadcrumb is
      // noise, not navigation.
      out.push({ to: acc, label: label || (p.length > 12 ? 'Detail' : p) })
    }
    return out
  }, [pathname])

  return (
    <nav aria-label="Breadcrumb" className="mt-0.5 flex min-w-0 items-center gap-1.5 text-xs">
      <NavLink to="/" className="flex-none text-ink-500 transition-colors hover:text-ink-200">
        Home
      </NavLink>
      {crumbs.map((c, i) => (
        <span key={c.to} className="flex min-w-0 items-center gap-1.5">
          <ChevronRight className="h-3 w-3 flex-none text-ink-600" strokeWidth={2} />
          {i === crumbs.length - 1 ? (
            <span className="truncate font-medium text-ink-300">{c.label}</span>
          ) : (
            <NavLink to={c.to} className="truncate text-ink-500 transition-colors hover:text-ink-200">
              {c.label}
            </NavLink>
          )}
        </span>
      ))}
    </nav>
  )
}

export function TopNavbar({
  consoleTitle,
  isAdmin = false,
  user,
  roles = [],
  meLoading = false,
  mfa,
  onOpenMobileNav,
  onLogout,
}) {
  const isDark = useThemeStore((s) => s.isDark)

  return (
    <header
      className="fixed inset-x-0 top-0 z-50 h-16 border-b border-surface-700/70 bg-surface-900/90 backdrop-blur-xl"
      style={{ boxShadow: 'var(--shadow-card)' }}
    >
      <div className="flex h-full items-center gap-2 pl-3 pr-2.5 sm:gap-3 sm:pl-5 sm:pr-4">
        {/* Company mark — left corner, and the only place it appears. */}
        <NavLink
          to="/"
          aria-label="Deep Algorithms — Dashboard"
          className="flex flex-none items-center rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40"
        >
          <img
            src={isDark ? logoWordmarkDark : logoWordmark}
            alt="Deep Algorithms"
            className="hidden h-[1.7rem] w-auto sm:block"
          />
          <img src={logoMark} alt="Deep Algorithms" className="h-7 w-7 object-contain sm:hidden" />
        </NavLink>

        <button
          type="button"
          onClick={onOpenMobileNav}
          className="flex h-9 w-9 flex-none items-center justify-center rounded-lg text-ink-400 transition-colors duration-150 hover:bg-surface-800 hover:text-ink-50 md:hidden"
          aria-label="Open navigation"
        >
          <Menu className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.5} />
        </button>

        <span className="hidden h-8 w-px flex-none bg-surface-700 md:block" aria-hidden="true" />

        {/* Console identity + where you are. Role-dependent: administrators
            operate the identity control plane, everyone else the privileged
            access console. */}
        <div className="hidden min-w-0 flex-1 md:block">
          <p className="truncate text-[0.9rem] font-semibold leading-tight tracking-[-0.01em] text-ink-50">
            {consoleTitle}
          </p>
          <Breadcrumb />
        </div>

        <p className="min-w-0 flex-1 truncate text-xs font-semibold uppercase tracking-[0.1em] text-ink-200 md:hidden">
          {consoleTitle}
        </p>

        <div className="flex flex-none items-center gap-1.5 sm:gap-2">
          <GlobalSearch isAdmin={isAdmin} />
          <NotificationsMenu isAdmin={isAdmin} />
          <ThemeToggle compact />
          <span className="mx-0.5 hidden h-6 w-px bg-surface-700 sm:block" aria-hidden="true" />
          <UserMenu user={user} roles={roles} onLogout={onLogout} loading={meLoading} mfa={mfa} />
        </div>
      </div>
    </header>
  )
}
