import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  Search, CornerDownLeft, Loader2, Boxes, Vault, Users, ArrowRight, SearchX,
} from 'lucide-react'
import { quickJumpTargets } from '../../config/nav'
import { listResources } from '../../api/resources'
import { listSafes } from '../../api/vault'
import { listUsers } from '../../api/identity'
import { SEARCH_DEBOUNCE_MS } from '../../config/constants'

// ---------------------------------------------------------------------------
// Global search
// ---------------------------------------------------------------------------
// What was wrong before: the topbar control filtered a hardcoded list of page
// names and nothing else. Typing the name of a resource, a safe or a user —
// the only things anyone actually searches a PAM console for — returned "no
// results", which reads as broken rather than as scoped.
//
// What it does now, and why it's honest:
//   · Pages resolve instantly, locally. No request, no spinner.
//   · Resources, safes and (for admins) accounts are searched for real.
//     Those three endpoints return WHOLE collections and take no query
//     param — except identity, which does take `q`. So: the collections are
//     fetched ONCE when the palette first opens, cached for 60s, and matched
//     in the browser. That is genuinely faster than a per-keystroke request
//     and it can't produce a half-typed server round trip.
//   · The typed query is still debounced (SEARCH_DEBOUNCE_MS) before it hits
//     the matcher, so a long list isn't re-scored on every keystroke.
//   · Ranking is deterministic: exact match, then prefix, then word-boundary,
//     then substring — with pages weighted above records, because a page is
//     what "search" means when someone types "audit".
//
// Deliberately not a command palette: page-level ACTIONS still need an action
// registry that doesn't exist. Offering actions we can't run would be worse
// than a search that says exactly what it searches.

const GROUP_META = {
  Console: { icon: null, hint: 'Page' },
  'Admin Center': { icon: null, hint: 'Page' },
  Account: { icon: null, hint: 'Page' },
  Resources: { icon: Boxes, hint: 'Resource' },
  Vault: { icon: Vault, hint: 'Safe' },
  Accounts: { icon: Users, hint: 'User' },
}

const GROUP_ORDER = ['Console', 'Admin Center', 'Account', 'Resources', 'Vault', 'Accounts']

// Higher is better. Returns 0 for "no match" so callers can filter on it.
function score(haystack, needle) {
  if (!haystack) return 0
  const h = String(haystack).toLowerCase()
  if (h === needle) return 100
  if (h.startsWith(needle)) return 80 - Math.min(h.length - needle.length, 20)
  const wordStart = new RegExp(`\\b${needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`)
  if (wordStart.test(h)) return 60
  if (h.includes(needle)) return 40
  return 0
}

function bestScore(fields, needle) {
  let best = 0
  for (const f of fields) {
    const s = score(f, needle)
    if (s > best) best = s
  }
  return best
}

export function GlobalSearch({ isAdmin = false }) {
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [raw, setRaw] = useState('')
  const [query, setQuery] = useState('')
  const [cursor, setCursor] = useState(0)
  const inputRef = useRef(null)
  const listRef = useRef(null)
  // Only start fetching once the palette has been opened at least once —
  // the topbar must not pull three collections on every page load.
  const [primed, setPrimed] = useState(false)

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault()
        setOpen((v) => !v)
      }
      // "/" is the other muscle-memory shortcut for search, but only when
      // the user isn't already typing into something.
      if (e.key === '/' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        const el = document.activeElement
        const typing =
          el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)
        if (!typing) {
          e.preventDefault()
          setOpen(true)
        }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [])

  useEffect(() => {
    if (!open) return undefined
    setPrimed(true)
    setRaw('')
    setQuery('')
    setCursor(0)
    const id = requestAnimationFrame(() => inputRef.current?.focus())
    // Lock the page behind the overlay so the console doesn't scroll under it.
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      cancelAnimationFrame(id)
      document.body.style.overflow = prev
    }
  }, [open])

  // Debounce: the input is immediate, the matcher runs after typing settles.
  useEffect(() => {
    const t = setTimeout(() => setQuery(raw.trim().toLowerCase()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [raw])

  useEffect(() => setCursor(0), [query])

  const common = { enabled: primed, staleTime: 60_000, retry: false }
  const resourcesQuery = useQuery({
    queryKey: ['search', 'resources'],
    queryFn: ({ signal }) => listResources({ signal }),
    ...common,
  })
  const safesQuery = useQuery({
    queryKey: ['search', 'safes'],
    queryFn: ({ signal }) => listSafes(signal),
    ...common,
  })
  const usersQuery = useQuery({
    queryKey: ['search', 'users'],
    queryFn: ({ signal }) => listUsers(undefined, signal),
    ...common,
    enabled: primed && isAdmin,
  })

  const pages = useMemo(() => quickJumpTargets(isAdmin), [isAdmin])

  const records = useMemo(() => {
    const out = []
    for (const r of resourcesQuery.data?.resources || []) {
      out.push({
        id: `resource-${r.id}`,
        group: 'Resources',
        label: r.name || r.id,
        meta: [r.type, r.host].filter(Boolean).join(' · '),
        fields: [r.name, r.type, r.host, r.description],
        to: `/resources/${r.id}`,
      })
    }
    for (const s of safesQuery.data || []) {
      out.push({
        id: `safe-${s.id}`,
        group: 'Vault',
        label: s.name || s.id,
        meta: s.description || 'Safe',
        fields: [s.name, s.description],
        to: `/vault/${s.id}`,
      })
    }
    for (const u of usersQuery.data?.users || []) {
      out.push({
        id: `user-${u.user_id}`,
        group: 'Accounts',
        label: u.username,
        meta: [u.email, u.status].filter(Boolean).join(' · '),
        fields: [u.username, u.email, u.full_name],
        to: `/admin/identity/${u.user_id}`,
      })
    }
    return out
  }, [resourcesQuery.data, safesQuery.data, usersQuery.data])

  const results = useMemo(() => {
    if (!query) {
      // Empty state of a search field is a shortlist, not everything — the
      // console's pages, which is what an empty palette is for.
      return pages.map((p) => ({
        id: `page-${p.to}`,
        group: p.group,
        label: p.label,
        icon: p.icon,
        to: p.to,
        meta: null,
      }))
    }

    const scored = []
    for (const p of pages) {
      const s = score(p.label, query)
      // Pages outrank records at equal relevance: typing "audit" means the
      // Audit page far more often than an audit-named resource.
      if (s) scored.push({ id: `page-${p.to}`, group: p.group, label: p.label, icon: p.icon, to: p.to, meta: null, _s: s + 12 })
    }
    for (const r of records) {
      const s = bestScore(r.fields, query)
      if (s) scored.push({ ...r, _s: s })
    }

    scored.sort((a, b) => b._s - a._s || a.label.localeCompare(b.label))
    return scored.slice(0, 40)
  }, [query, pages, records])

  const loading =
    primed &&
    (resourcesQuery.isLoading || safesQuery.isLoading || (isAdmin && usersQuery.isLoading))

  const go = (to) => {
    setOpen(false)
    navigate(to)
  }

  // Keep the highlighted row inside the scroll viewport when navigating by
  // keyboard through a long result set.
  useEffect(() => {
    const el = listRef.current?.querySelector('[data-active="true"]')
    if (!el || !listRef.current) return
    const box = listRef.current.getBoundingClientRect()
    const row = el.getBoundingClientRect()
    if (row.bottom > box.bottom) listRef.current.scrollTop += row.bottom - box.bottom
    else if (row.top < box.top) listRef.current.scrollTop -= box.top - row.top
  }, [cursor, results])

  const onKeyDown = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault()
      setOpen(false)
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setCursor((c) => (results.length === 0 ? 0 : (c + 1) % results.length))
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      setCursor((c) => (results.length === 0 ? 0 : (c - 1 + results.length) % results.length))
      return
    }
    if (e.key === 'Enter' && results[cursor]) {
      e.preventDefault()
      go(results[cursor].to)
    }
  }

  let lastGroup = null

  return (
    <>
      {/* Trigger. No ⌘K chip inside the field — a keycap sitting in a search
          box reads as a form control and clutters the one piece of navbar
          chrome that should look calm. The shortcut lives in the tooltip and
          in the overlay's own footer. */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        title="Search (⌘K)"
        className="hidden h-9 w-[15rem] items-center gap-2.5 rounded-lg border border-surface-700 bg-surface-800/70 px-3 text-xs text-ink-500 transition-colors duration-150 hover:border-surface-600 hover:bg-surface-800 hover:text-ink-300 focus-visible:ring-2 focus-visible:ring-blue-500/40 lg:flex"
      >
        <Search className="h-3.5 w-3.5 flex-none" strokeWidth={1.75} />
        <span className="flex-1 text-left">Search the console…</span>
      </button>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Search"
        className="flex h-9 w-9 flex-none items-center justify-center rounded-lg text-ink-400 transition-colors duration-150 hover:bg-surface-800 hover:text-ink-50 lg:hidden"
      >
        <Search className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
      </button>

      {open && (
        <div className="fixed inset-0 z-[60] flex items-start justify-center px-4 pt-[10vh]">
          {/* A clean scrim: one flat wash plus a real blur. No gradient, no
              vignette — the panel supplies the depth. */}
          <div
            className="animate-overlay-in absolute inset-0 bg-slate-900/40 backdrop-blur-md dark:bg-slate-950/70"
            onClick={() => setOpen(false)}
            aria-hidden="true"
          />
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Search"
            className="animate-panel-in relative w-full max-w-[38rem] overflow-hidden rounded-2xl border border-surface-700 bg-surface-900 shadow-overlay"
          >
            <div className="flex items-center gap-3 border-b border-surface-800 px-4">
              {loading ? (
                <Loader2 className="h-4 w-4 flex-none animate-spin text-ink-500" strokeWidth={2} />
              ) : (
                <Search className="h-4 w-4 flex-none text-ink-500" strokeWidth={1.75} />
              )}
              <input
                ref={inputRef}
                value={raw}
                onChange={(e) => setRaw(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder="Search pages, resources, safes…"
                aria-label="Search the console"
                className="h-[3.25rem] w-full flex-1 border-0 bg-transparent text-[0.9375rem] text-ink-50 placeholder:text-ink-500 focus:outline-none"
              />
              {raw && (
                <button
                  type="button"
                  onClick={() => setRaw('')}
                  className="flex-none rounded-md px-2 py-1 text-2xs font-medium text-ink-500 transition-colors hover:bg-surface-800 hover:text-ink-200"
                >
                  Clear
                </button>
              )}
            </div>

            <div ref={listRef} className="max-h-[21rem] overflow-y-auto p-1.5">
              {results.length === 0 && (
                <div className="flex flex-col items-center px-6 py-11 text-center">
                  <span className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl border border-surface-700 bg-surface-850 text-ink-400">
                    <SearchX className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.5} />
                  </span>
                  <p className="text-sm font-medium text-ink-100">No matches for “{raw.trim()}”</p>
                  <p className="mt-1.5 max-w-xs text-xs leading-relaxed text-ink-500">
                    Search covers console pages, resources, vault safes
                    {isAdmin ? ' and user accounts' : ''}. Sessions, grants and audit entries are
                    searched on their own pages.
                  </p>
                </div>
              )}

              {results.map((r, i) => {
                const showGroup = r.group !== lastGroup
                lastGroup = r.group
                const active = i === cursor
                const meta = GROUP_META[r.group] || {}
                const Icon = r.icon || meta.icon || Search
                return (
                  <div key={r.id}>
                    {showGroup && (
                      <p className="px-2.5 pb-1 pt-2.5 text-2xs font-semibold uppercase tracking-[0.11em] text-ink-600">
                        {r.group}
                      </p>
                    )}
                    <button
                      type="button"
                      data-active={active}
                      onMouseEnter={() => setCursor(i)}
                      onClick={() => go(r.to)}
                      className={clsx(
                        'flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors duration-100',
                        active ? 'bg-surface-800' : 'hover:bg-surface-850'
                      )}
                    >
                      <span
                        className={clsx(
                          'flex h-7 w-7 flex-none items-center justify-center rounded-lg border transition-colors',
                          active
                            ? 'border-blue-500/40 bg-blue-50 text-blue-600 dark:bg-blue-500/15 dark:text-blue-300'
                            : 'border-surface-700 bg-surface-850 text-ink-500'
                        )}
                      >
                        <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span
                          className={clsx(
                            'block truncate text-sm font-medium',
                            active ? 'text-ink-50' : 'text-ink-100'
                          )}
                        >
                          {r.label}
                        </span>
                        {r.meta && (
                          <span className="mt-0.5 block truncate text-xs text-ink-500">{r.meta}</span>
                        )}
                      </span>
                      {active ? (
                        <CornerDownLeft className="h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
                      ) : (
                        <ArrowRight className="h-3.5 w-3.5 flex-none text-ink-600 opacity-0" strokeWidth={1.75} />
                      )}
                    </button>
                  </div>
                )
              })}
            </div>

            <div className="flex items-center justify-between gap-4 border-t border-surface-800 bg-surface-850/60 px-4 py-2.5 text-2xs text-ink-500">
              <span className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <kbd className="rounded border border-surface-600 bg-surface-900 px-1.5 py-0.5 font-mono">↑↓</kbd>
                  navigate
                </span>
                <span className="flex items-center gap-1.5">
                  <kbd className="rounded border border-surface-600 bg-surface-900 px-1.5 py-0.5 font-mono">↵</kbd>
                  open
                </span>
                <span className="hidden items-center gap-1.5 sm:flex">
                  <kbd className="rounded border border-surface-600 bg-surface-900 px-1.5 py-0.5 font-mono">esc</kbd>
                  close
                </span>
              </span>
              <span className="tabular-nums">
                {query ? `${results.length} result${results.length === 1 ? '' : 's'}` : 'Type to search'}
              </span>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
