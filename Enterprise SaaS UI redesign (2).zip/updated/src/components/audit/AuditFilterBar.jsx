import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { CalendarRange, ChevronDown, SlidersHorizontal } from 'lucide-react'
import { Button } from '../common/Button'
import { SearchField, ActiveFilters, RefreshControl, ExportMenu, DensityToggle } from '../common/TableControls'
import { RANGE_PRESETS, rangeLabel, CATEGORIES, OUTCOMES, SEVERITIES } from './auditFields'
import { todayDateInputValue } from '../../lib/format'
import { SEARCH_DEBOUNCE_MS } from '../../config/constants'

// ---------------------------------------------------------------------------
// Audit filter bar
// ---------------------------------------------------------------------------
// One control strip shared by the self-service Audit page and the Admin
// Center's Audit & Compliance. Both screens investigate the same object, so
// they get the same instrument: free-text search, a real date range, three
// facets, and an advanced row that stays collapsed until asked for — the
// pattern Entra's sign-in logs and Okta's system log both settle on.
//
// State is owned by the PAGE (it belongs in the query key). This component
// is presentational: it renders values and calls setters.

function FacetSelect({ label, value, onChange, options, allLabel = 'All' }) {
  return (
    <label className="flex min-w-0 items-center gap-2">
      <span className="whitespace-nowrap text-xs font-medium text-ink-400">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 min-w-[8rem] cursor-pointer rounded-lg border border-surface-700 bg-surface-900 pl-2.5 pr-7 text-xs font-medium text-ink-100 shadow-sm transition-colors hover:border-surface-600 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
      >
        <option value="">{allLabel}</option>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </label>
  )
}

function RangePicker({ range, onRangeChange, customFrom, customTo, onCustomFrom, onCustomTo }) {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open])

  return (
    <div className="relative flex-none">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={clsx(
          'inline-flex h-9 items-center gap-2 rounded-lg border px-3 text-xs font-medium transition-colors',
          range === 'all'
            ? 'border-surface-700 bg-surface-900 text-ink-200 hover:border-surface-600'
            : 'border-blue-500/40 bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-200'
        )}
      >
        <CalendarRange className="h-3.5 w-3.5 flex-none" strokeWidth={1.75} />
        {range === 'custom' && customFrom
          ? `${customFrom} → ${customTo || 'now'}`
          : rangeLabel(range)}
        <ChevronDown className="h-3 w-3 flex-none opacity-60" strokeWidth={2.5} />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} aria-hidden="true" />
          <div className="animate-menu-in absolute left-0 z-40 mt-1.5 w-64 overflow-hidden rounded-xl border border-surface-700 bg-surface-900 shadow-overlay">
            <div className="p-1.5">
              {RANGE_PRESETS.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => {
                    onRangeChange(p.key)
                    if (p.key !== 'custom') setOpen(false)
                  }}
                  className={clsx(
                    'flex w-full items-center rounded-lg px-2.5 py-1.5 text-left text-sm transition-colors',
                    range === p.key
                      ? 'bg-blue-50 font-medium text-blue-700 dark:bg-blue-500/[0.12] dark:text-blue-100'
                      : 'text-ink-200 hover:bg-surface-800'
                  )}
                >
                  {p.label}
                </button>
              ))}
            </div>
            {range === 'custom' && (
              <div className="grid grid-cols-2 gap-2 border-t border-surface-800 bg-surface-850/60 p-3">
                <label className="flex flex-col gap-1">
                  <span className="text-2xs font-medium uppercase tracking-wide text-ink-500">From</span>
                  <input
                    type="date"
                    value={customFrom}
                    max={customTo || todayDateInputValue()}
                    onChange={(e) => onCustomFrom(e.target.value)}
                    className="h-8 rounded-lg border border-surface-700 bg-surface-900 px-2 text-xs text-ink-100 focus:border-blue-500 focus:outline-none"
                  />
                </label>
                <label className="flex flex-col gap-1">
                  <span className="text-2xs font-medium uppercase tracking-wide text-ink-500">To</span>
                  <input
                    type="date"
                    value={customTo}
                    min={customFrom}
                    max={todayDateInputValue()}
                    onChange={(e) => onCustomTo(e.target.value)}
                    className="h-8 rounded-lg border border-surface-700 bg-surface-900 px-2 text-xs text-ink-100 focus:border-blue-500 focus:outline-none"
                  />
                </label>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}

export function AuditFilterBar({
  filters,
  set,
  reset,
  onRefresh,
  isFetching,
  updatedAt,
  density,
  onDensityChange,
  onExportCsv,
  onExportJson,
  exportCount,
  actions,
}) {
  const [advanced, setAdvanced] = useState(false)
  const [searchInput, setSearchInput] = useState(filters.q)

  // Debounced free text: the field responds on every keystroke, the query key
  // only moves once typing settles.
  useEffect(() => {
    const t = setTimeout(() => {
      if (searchInput.trim() !== filters.q) set('q', searchInput.trim())
    }, SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchInput])

  // Keep the input honest when a filter chip or a drawer action clears the
  // query from outside this component.
  useEffect(() => {
    if (filters.q !== searchInput.trim()) setSearchInput(filters.q)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.q])

  const chips = []
  if (filters.q) chips.push({ key: 'q', label: 'Search', value: filters.q, onClear: () => setSearchInput('') })
  if (filters.range !== 'all') {
    chips.push({ key: 'range', label: 'Range', value: rangeLabel(filters.range), onClear: () => set('range', 'all') })
  }
  if (filters.category) chips.push({ key: 'category', label: 'Category', value: filters.category, onClear: () => set('category', '') })
  if (filters.outcome) chips.push({ key: 'outcome', label: 'Outcome', value: filters.outcome, onClear: () => set('outcome', '') })
  if (filters.severity) chips.push({ key: 'severity', label: 'Severity', value: filters.severity, onClear: () => set('severity', '') })
  if (filters.actor) chips.push({ key: 'actor', label: 'Actor', value: filters.actor, onClear: () => set('actor', '') })
  if (filters.action) chips.push({ key: 'action', label: 'Action', value: filters.action, onClear: () => set('action', '') })

  return (
    <div className="mb-4 space-y-3 rounded-xl border border-surface-700/70 bg-surface-900 px-3 py-3 shadow-card">
      <div className="flex flex-wrap items-center gap-2">
        <SearchField
          value={searchInput}
          onChange={setSearchInput}
          placeholder="Search actions, actors, resources…"
          className="min-w-[15rem] sm:max-w-sm"
        />

        <RangePicker
          range={filters.range}
          onRangeChange={(v) => set('range', v)}
          customFrom={filters.from}
          customTo={filters.to}
          onCustomFrom={(v) => set('from', v)}
          onCustomTo={(v) => set('to', v)}
        />

        <FacetSelect label="Category" value={filters.category} onChange={(v) => set('category', v)} options={CATEGORIES} allLabel="All categories" />
        <FacetSelect label="Outcome" value={filters.outcome} onChange={(v) => set('outcome', v)} options={OUTCOMES} allLabel="All outcomes" />

        <span className="ml-auto flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            variant={advanced ? 'subtle' : 'secondary'}
            icon={SlidersHorizontal}
            onClick={() => setAdvanced((v) => !v)}
            aria-expanded={advanced}
          >
            More
          </Button>
          {onDensityChange && <DensityToggle value={density} onChange={onDensityChange} />}
          {onExportCsv && (
            <ExportMenu
              count={exportCount}
              disabled={!exportCount}
              onExportCsv={onExportCsv}
              onExportJson={onExportJson}
            />
          )}
          {actions}
          <RefreshControl onRefresh={onRefresh} isFetching={isFetching} updatedAt={updatedAt} />
        </span>
      </div>

      {advanced && (
        <div className="flex flex-wrap items-center gap-2 border-t border-surface-800 pt-3">
          <FacetSelect label="Severity" value={filters.severity} onChange={(v) => set('severity', v)} options={SEVERITIES} allLabel="Any severity" />
          <label className="flex items-center gap-2">
            <span className="whitespace-nowrap text-xs font-medium text-ink-400">Actor</span>
            <input
              value={filters.actor}
              onChange={(e) => set('actor', e.target.value)}
              placeholder="username or ID"
              className="h-9 w-44 rounded-lg border border-surface-700 bg-surface-900 px-2.5 text-xs text-ink-100 placeholder:text-ink-500 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
            />
          </label>
          <label className="flex items-center gap-2">
            <span className="whitespace-nowrap text-xs font-medium text-ink-400">Exact action</span>
            <input
              value={filters.action}
              onChange={(e) => set('action', e.target.value)}
              placeholder="pam:vault:Reveal"
              className="h-9 w-52 rounded-lg border border-surface-700 bg-surface-900 px-2.5 font-mono text-xs text-ink-100 placeholder:text-ink-500 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20"
            />
          </label>
          <p className="ml-auto max-w-md text-2xs leading-relaxed text-ink-500">
            Search matches free text across the record. <span className="font-medium text-ink-400">Exact action</span> is
            a whole-string match on the action name — use one or the other, not both.
          </p>
        </div>
      )}

      {chips.length > 0 && (
        <div className="border-t border-surface-800 pt-3">
          <ActiveFilters
            chips={chips}
            onClearAll={() => {
              setSearchInput('')
              reset()
            }}
          />
        </div>
      )}
    </div>
  )
}

// The page owns this so the values sit in the react-query key.
export const EMPTY_AUDIT_FILTERS = {
  q: '',
  range: '7d',
  from: '',
  to: '',
  category: '',
  outcome: '',
  severity: '',
  actor: '',
  action: '',
}
