import clsx from 'clsx'
import { User, Crosshair, Link2, ShieldCheck, FileText, Fingerprint, Filter } from 'lucide-react'
import { Drawer } from '../common/Drawer'
import { Badge } from '../common/Badge'
import { Button } from '../common/Button'
import { CopyButton } from '../common/CopyButton'
import { formatDateTime } from '../../lib/format'
import { eventTime, eventActor, eventTarget, eventId } from './auditFields'
import { AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE } from '../../config/constants'

// ---------------------------------------------------------------------------
// Audit event detail — a drawer, not a modal
// ---------------------------------------------------------------------------
// Reading an audit trail is a scanning task: you open a row, read it, close
// it, open the next. A centred modal blanks the table behind it and loses
// your place in a filtered, paged result set every time. The drawer keeps the
// list visible and the scroll position intact, which is what Okta's system
// log and Entra's sign-in logs both do.
//
// Field names below match models/audit_log.go exactly — this is the "show me
// everything about this one entry" view, so it is precise rather than
// defensive. The row-level readers stay defensive because they also serve the
// admin list endpoint.

function Row({ label, value, mono, copyable }) {
  if (value === null || value === undefined || value === '') return null
  const text = String(value)
  return (
    <div className="grid grid-cols-[minmax(6.5rem,34%)_1fr] items-start gap-3 px-4 py-2">
      <dt className="text-2xs font-medium uppercase tracking-[0.07em] text-ink-500">{label}</dt>
      <dd className="flex min-w-0 items-start gap-2">
        <span className={clsx('min-w-0 flex-1 break-all text-sm text-ink-100', mono && 'font-mono text-xs')}>
          {text}
        </span>
        {copyable && <CopyButton value={text} label="" />}
      </dd>
    </div>
  )
}

function Group({ icon: Icon, title, children }) {
  const kids = Array.isArray(children) ? children.filter(Boolean) : children
  return (
    <section className="border-b border-surface-800 last:border-b-0">
      <h3 className="flex items-center gap-2 bg-surface-850/60 px-4 py-2 text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">
        <Icon className="h-3.5 w-3.5" strokeWidth={1.75} /> {title}
      </h3>
      <dl className="divide-y divide-surface-800/70">{kids}</dl>
    </section>
  )
}

// `details` / `justification` are free-text columns that in practice usually
// carry JSON. Pretty-print when parseable, show raw otherwise — never a wall
// of escaped braces.
function Blob({ label, raw }) {
  if (!raw) return null
  let display = raw
  try {
    display = JSON.stringify(JSON.parse(raw), null, 2)
  } catch {
    /* not JSON */
  }
  return (
    <div className="px-4 py-3">
      <p className="mb-1.5 text-2xs font-medium uppercase tracking-[0.07em] text-ink-500">{label}</p>
      <pre className="max-h-56 overflow-auto rounded-lg border border-surface-700 bg-surface-850 p-2.5 font-mono text-xs leading-relaxed text-ink-300">
        {display}
      </pre>
    </div>
  )
}

export function AuditEventDrawer({ event, onClose, onFilterActor, onFilterAction }) {
  if (!event) return null

  const id = eventId(event)
  const actor = eventActor(event)
  const target = eventTarget(event)
  const chained = event.entry_hash || event.prev_hash || event.sequence_number != null

  return (
    <Drawer
      open={!!event}
      onClose={onClose}
      width="lg"
      icon={<Fingerprint className="h-4 w-4 text-ink-400" strokeWidth={1.75} />}
      title={event.action || 'Audit event'}
      subtitle={formatDateTime(eventTime(event))}
      footer={
        <>
          {onFilterActor && actor && (
            <Button size="sm" variant="secondary" icon={Filter} onClick={() => onFilterActor(actor)}>
              Events by this actor
            </Button>
          )}
          {onFilterAction && event.action && (
            <Button size="sm" variant="secondary" icon={Filter} onClick={() => onFilterAction(event.action)}>
              Same action
            </Button>
          )}
          {id && (
            <span className="ml-auto">
              <CopyButton value={id} label="Copy event ID" />
            </span>
          )}
        </>
      }
    >
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-800 px-4 py-3.5">
        <span className="rounded border border-surface-700 bg-surface-850 px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.07em] text-ink-400">
          {event.category || 'OTHER'}
        </span>
        {event.outcome && (
          <Badge className={AUDIT_OUTCOME_BADGE[event.outcome]}>{event.outcome}</Badge>
        )}
        {event.severity && (
          <Badge className={AUDIT_SEVERITY_BADGE[event.severity]}>{event.severity}</Badge>
        )}
        {event.sequence_number != null && (
          <span className="ml-auto font-mono text-2xs text-ink-500">seq #{event.sequence_number}</span>
        )}
      </div>

      <Group icon={User} title="Actor">
        <Row label="Username" value={actor} />
        <Row label="Email" value={event.email} />
        <Row label="User ID" value={event.user_id} mono copyable />
        <Row label="Actor type" value={event.actor_type} />
        <Row label="Service" value={event.service_name} />
      </Group>

      <Group icon={Crosshair} title="Target">
        <Row label="Resource" value={target} />
        <Row label="Type" value={event.resource_type} />
        <Row label="Resource ID" value={event.resource_id} mono copyable />
      </Group>

      <Group icon={Link2} title="Request context">
        <Row label="Source IP" value={event.source_ip} mono />
        <Row label="Request ID" value={event.request_id} mono copyable />
        <Row label="Session ID" value={event.session_id} mono copyable />
        <Row label="Grant ID" value={event.grant_id} mono copyable />
        <Row label="Authz decision" value={event.authz_decision_id} mono copyable />
        <Row label="User agent" value={event.user_agent} />
      </Group>

      {chained && (
        <Group icon={ShieldCheck} title="Chain integrity">
          <Row label="Sequence" value={event.sequence_number} mono />
          <Row label="Entry hash" value={event.entry_hash} mono copyable />
          <Row label="Previous hash" value={event.prev_hash} mono copyable />
          <Row label="Hash version" value={event.hash_version} />
        </Group>
      )}

      {(event.justification || event.details) && (
        <section>
          <h3 className="flex items-center gap-2 border-b border-surface-800 bg-surface-850/60 px-4 py-2 text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">
            <FileText className="h-3.5 w-3.5" strokeWidth={1.75} /> Recorded detail
          </h3>
          <Blob label="Justification" raw={event.justification} />
          <Blob label="Details" raw={event.details} />
        </section>
      )}
    </Drawer>
  )
}
