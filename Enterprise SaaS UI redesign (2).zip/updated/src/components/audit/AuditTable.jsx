import clsx from 'clsx'
import { ChevronRight, ShieldAlert, SearchX } from 'lucide-react'
import { Badge } from '../common/Badge'
import { Button } from '../common/Button'
import { EmptyState } from '../common/Layout'
import { SkeletonRows } from '../common/Spinner'
import { formatDateTime } from '../../lib/format'
import { eventTime, eventActor, eventTarget, eventIp, isFailure, isCritical } from './auditFields'
import { AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE } from '../../config/constants'

// ---------------------------------------------------------------------------
// Audit table
// ---------------------------------------------------------------------------
// The old screen rendered audit entries as a list of soft two-line cards.
// That is the wrong instrument: an audit trail is columnar data an
// investigator scans down a single axis (time, then outcome, then actor), and
// a card forces them to re-find each field on every row.
//
// So: a real table. Fixed column order, tabular numerals on time and
// sequence, monospace on the action string (it is an identifier, not prose),
// severity and outcome as badges, and a left edge that turns red on a failed
// or critical event so a page of successes never hides the one denial.
//
// Presentational only — rows in, click out. Both audit screens use it, which
// is what stops the self-service and admin views from drifting apart again.

export function AuditTable({
  rows,
  loading,
  density = 'comfortable',
  onSelect,
  emptyTitle = 'No audit entries',
  emptyMessage = 'Nothing matches these filters.',
  onClearFilters,
  showActor = true,
}) {
  if (loading) {
    return (
      <div className="p-4" role="status" aria-label="Loading audit entries">
        <SkeletonRows rows={8} />
      </div>
    )
  }

  if (!rows || rows.length === 0) {
    return (
      <EmptyState
        icon={SearchX}
        title={emptyTitle}
        description={emptyMessage}
        action={
          onClearFilters && (
            <Button variant="secondary" onClick={onClearFilters}>
              Clear filters
            </Button>
          )
        }
      />
    )
  }

  const pad = density === 'compact' ? 'py-1.5' : 'py-2.5'

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[58rem] border-separate border-spacing-0 text-sm">
        <thead>
          <tr>
            {['Time', 'Action', showActor && 'Actor', 'Target', 'Outcome', 'Severity', 'Source IP']
              .filter(Boolean)
              .map((h) => (
                <th
                  key={h}
                  scope="col"
                  className="sticky top-0 z-10 whitespace-nowrap border-b border-surface-800 bg-surface-850 px-4 py-2.5 text-left text-2xs font-semibold uppercase tracking-[0.08em] text-ink-400"
                >
                  {h}
                </th>
              ))}
            <th scope="col" className="sticky top-0 z-10 w-10 border-b border-surface-800 bg-surface-850 px-2 py-2.5">
              <span className="sr-only">Open</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((e, i) => {
            const failed = isFailure(e)
            const critical = isCritical(e)
            return (
              <tr
                key={e?.id ?? e?.sequence_number ?? i}
                onClick={() => onSelect?.(e)}
                className={clsx(
                  'group cursor-pointer transition-colors',
                  failed || critical ? 'hover:bg-red-50/60 dark:hover:bg-red-950/20' : 'hover:bg-surface-850'
                )}
              >
                <td className={clsx('relative whitespace-nowrap border-b border-surface-800 px-4 text-xs tabular-nums text-ink-300', pad)}>
                  {/* Attention rail: a denial in a page of successes must be
                      findable without reading the outcome column. */}
                  <span
                    aria-hidden="true"
                    className={clsx(
                      'absolute inset-y-0 left-0 w-[3px]',
                      critical ? 'bg-red-500' : failed ? 'bg-red-400/70' : 'bg-transparent'
                    )}
                  />
                  {formatDateTime(eventTime(e))}
                  {e?.sequence_number != null && (
                    <span className="ml-2 font-mono text-2xs text-ink-600">#{e.sequence_number}</span>
                  )}
                </td>

                <td className={clsx('border-b border-surface-800 px-4', pad)}>
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="flex-none rounded border border-surface-700 bg-surface-850 px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.06em] text-ink-500">
                      {e?.category || 'OTHER'}
                    </span>
                    <span className="min-w-0 truncate font-mono text-xs font-medium text-ink-100">
                      {e?.action || '—'}
                    </span>
                  </div>
                </td>

                {showActor && (
                  <td className={clsx('max-w-[12rem] border-b border-surface-800 px-4 text-xs text-ink-300', pad)}>
                    <span className="block truncate">{eventActor(e) || '—'}</span>
                  </td>
                )}

                <td className={clsx('max-w-[14rem] border-b border-surface-800 px-4 text-xs text-ink-400', pad)}>
                  <span className="block truncate">{eventTarget(e) || '—'}</span>
                </td>

                <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4', pad)}>
                  {e?.outcome ? (
                    <Badge className={AUDIT_OUTCOME_BADGE[e.outcome]}>{e.outcome}</Badge>
                  ) : (
                    <span className="text-xs text-ink-600">—</span>
                  )}
                </td>

                <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4', pad)}>
                  {e?.severity ? (
                    <Badge className={AUDIT_SEVERITY_BADGE[e.severity]}>
                      {critical && <ShieldAlert className="h-2.5 w-2.5" strokeWidth={2.5} />}
                      {e.severity}
                    </Badge>
                  ) : (
                    <span className="text-xs text-ink-600">—</span>
                  )}
                </td>

                <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 font-mono text-xs text-ink-500', pad)}>
                  {eventIp(e) || '—'}
                </td>

                <td className={clsx('border-b border-surface-800 px-2', pad)}>
                  <span className="flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-colors group-hover:bg-surface-800 group-hover:text-ink-100">
                    <ChevronRight className="h-4 w-4" strokeWidth={2} />
                  </span>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
