import { useMemo, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate, useParams, useSearchParams, Link } from 'react-router-dom'
import {
  ArrowLeft, KeyRound, Trash2, X, ShieldCheck, UserRound, Lock, Ban, CheckCircle2,
  ScrollText, FileKey2, Plus, Eye, EyeOff, Wand2, AlertTriangle, Copy, Check, History,
} from 'lucide-react'
import { toast } from 'sonner'
import clsx from 'clsx'
import {
  getUser, setUserStatus, deleteUser, resetUserPassword,
  assignRole, removeRole, attachPolicy, detachPolicy,
} from '../../api/identity'
import { listPolicies } from '../../api/rbac'
import { auditByUser } from '../../api/audit'
import { PageHeader, Card, CardHeader, CardTitle, CardFooter, DetailList, EmptyState, Section } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { TabBar } from '../../components/common/TabBar'
import { Avatar } from '../../components/common/UserMenu'
import { Field, inputClass, selectClass } from '../../components/common/FormFields'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { AuditTable } from '../../components/audit/AuditTable'
import { AuditEventDrawer } from '../../components/audit/AuditEventDrawer'
import { apiErrorMessage } from '../../lib/apiError'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { passwordStrength, suggestPassword, PASSWORD_MIN } from '../../lib/validators'
import { USER_STATUS_BADGE, ROLE_BADGE, SYSTEM_ROLES } from '../../config/constants'

// ---------------------------------------------------------------------------
// Admin Center — account detail
// ---------------------------------------------------------------------------
// The old page was two columns of unlabelled boxes: profile on the left,
// roles and policies stacked on the right, a bare "Reset password" button
// wired to an inline form, and delete sitting in the header next to nothing.
//
// Rebuilt as an identity record: a header that states who this is and what
// state they're in, then four tabs that match the four questions an
// administrator opens this page to answer —
//
//   Overview  who is this account, when was it made, when was it last used
//   Access    what can it reach (roles, and policies attached directly)
//   Security  password, lifecycle state, and the destructive actions
//   Activity  what has it actually done (its own slice of the audit trail)
//
// Lifecycle actions all route through ConfirmDialog, and the two truly
// destructive ones require a typed reason, because the backend writes that
// reason into the audit record.

const STATUS_TRANSITIONS = [
  { value: 'ACTIVE', label: 'Activate', icon: CheckCircle2, note: 'Restores the ability to sign in.' },
  { value: 'DISABLED', label: 'Disable', icon: Ban, note: 'Keeps the account and its history, denies all access.' },
  { value: 'LOCKED', label: 'Lock', icon: Lock, note: 'Blocks sign-in without changing the account.' },
]

const resetSchema = z.object({
  new_password: z.string().min(PASSWORD_MIN, `At least ${PASSWORD_MIN} characters`),
})

function IdChip({ id }) {
  const [copied, setCopied] = useState(false)
  if (!id) return null
  return (
    <button
      type="button"
      title="Copy user ID"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(id)
          setCopied(true)
          setTimeout(() => setCopied(false), 1500)
        } catch {
          /* clipboard unavailable — the id is still selectable on screen */
        }
      }}
      className="inline-flex items-center gap-1.5 rounded-md border border-surface-700 bg-surface-850 px-2 py-1 font-mono text-2xs text-ink-400 transition-colors hover:border-surface-600 hover:text-ink-200"
    >
      {copied ? (
        <Check className="h-3 w-3 flex-none text-emerald-600 dark:text-emerald-400" strokeWidth={2.5} />
      ) : (
        <Copy className="h-3 w-3 flex-none text-ink-500" strokeWidth={1.75} />
      )}
      {String(id).slice(0, 8)}…
    </button>
  )
}

// --- Security: password ------------------------------------------------------

function ResetPasswordCard({ userId, username }) {
  const [show, setShow] = useState(false)
  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm({ resolver: zodResolver(resetSchema), mode: 'onBlur', defaultValues: { new_password: '' } })

  const pw = watch('new_password') || ''
  const strength = passwordStrength(pw)

  const mutation = useMutation({
    mutationFn: ({ new_password }) => resetUserPassword(userId, new_password),
    onSuccess: () => {
      toast.success(`Password reset for ${username}`)
      reset({ new_password: '' })
      setShow(false)
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle icon={KeyRound}>Password</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate className="space-y-4 p-4">
        <p className="text-sm leading-relaxed text-ink-400">
          Sets a new password immediately. The account is not signed out, and there is no
          email-delivery step on this backend — you hand the new password over yourself.
        </p>

        <Field label="New password" error={errors.new_password?.message} required htmlFor="reset-pw">
          <div className="relative">
            <input
              id="reset-pw"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              spellCheck={false}
              className={clsx(inputClass(!!errors.new_password), 'pr-20 font-mono')}
              {...register('new_password')}
            />
            <div className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center gap-0.5">
              <button
                type="button"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? 'Hide password' : 'Show password'}
                className="flex h-7 w-7 items-center justify-center rounded-md text-ink-500 transition-colors hover:bg-surface-700 hover:text-ink-100"
              >
                {show ? <EyeOff className="h-3.5 w-3.5" strokeWidth={1.75} /> : <Eye className="h-3.5 w-3.5" strokeWidth={1.75} />}
              </button>
              <button
                type="button"
                onClick={() => {
                  setValue('new_password', suggestPassword(20), { shouldValidate: true })
                  setShow(true)
                }}
                aria-label="Generate a strong password"
                title="Generate a strong password"
                className="flex h-7 w-7 items-center justify-center rounded-md text-ink-500 transition-colors hover:bg-surface-700 hover:text-ink-100"
              >
                <Wand2 className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            </div>
          </div>
        </Field>

        {pw && (
          <div className="flex items-center gap-3">
            <div className="flex h-1.5 flex-1 gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <span
                  key={i}
                  className={clsx(
                    'h-full flex-1 rounded-full transition-colors duration-200',
                    i <= strength.score
                      ? strength.tone === 'red'
                        ? 'bg-red-500'
                        : strength.tone === 'amber'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      : 'bg-surface-750'
                  )}
                />
              ))}
            </div>
            <span className="flex-none text-2xs font-medium text-ink-400">{strength.label}</span>
          </div>
        )}

        <div className="flex items-center gap-2">
          <Button type="submit" variant="primary" size="sm" icon={KeyRound} loading={mutation.isPending}>
            Reset password
          </Button>
          <Button type="button" variant="ghost" size="sm" onClick={() => reset({ new_password: '' })} disabled={mutation.isPending}>
            Clear
          </Button>
        </div>
      </form>
    </Card>
  )
}

// --- Activity ----------------------------------------------------------------

function ActivityTab({ userId }) {
  const [selected, setSelected] = useState(null)
  const query = useQuery({
    queryKey: ['admin', 'users', userId, 'audit'],
    queryFn: ({ signal }) => auditByUser(userId, 100, signal),
    retry: false,
  })

  // auditByUser returns a plain array (no pagination envelope) capped by the
  // `limit` we ask for — so this is the last 100 events, said plainly rather
  // than dressed up as a pager that can't page.
  const rows = useMemo(() => (Array.isArray(query.data) ? query.data : []), [query.data])

  return (
    <>
      <Card className="overflow-hidden">
        <CardHeader>
          <CardTitle icon={History}>Recent activity</CardTitle>
          <span className="ml-auto text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
            Last {rows.length} events
          </span>
        </CardHeader>
        <QueryState
          query={query}
          empty={(d) => !d || d.length === 0}
          emptyTitle="No recorded activity"
          emptyMessage="This account has no audit entries yet — it has not signed in or performed any recorded action."
          skeletonRows={6}
        >
          {() => (
            <AuditTable
              rows={rows}
              density="compact"
              onSelect={setSelected}
              showActor={false}
              emptyTitle="No recorded activity"
              emptyMessage="Nothing has been recorded for this account."
            />
          )}
        </QueryState>
        <CardFooter>
          <p className="text-xs leading-relaxed text-ink-500">
            Scoped to this account. The full org-wide trail, with filters and export, lives in{' '}
            <Link to="/admin/audit" className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400">
              Audit &amp; Compliance
            </Link>
            .
          </p>
        </CardFooter>
      </Card>
      <AuditEventDrawer event={selected} onClose={() => setSelected(null)} />
    </>
  )
}

// --- Page --------------------------------------------------------------------

export default function IdentityDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [params, setParams] = useSearchParams()
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [confirmStatus, setConfirmStatus] = useState(null)
  const [newRole, setNewRole] = useState('')
  const [newPolicyId, setNewPolicyId] = useState('')

  const userQuery = useQuery({
    queryKey: ['admin', 'users', id],
    queryFn: ({ signal }) => getUser(id, signal),
  })

  const policiesQuery = useQuery({
    queryKey: ['admin', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'users', id] })

  const statusMutation = useMutation({
    mutationFn: (status) => setUserStatus(id, status),
    onSuccess: (_d, status) => {
      toast.success(`Account set to ${status}`)
      invalidate()
      setConfirmStatus(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setConfirmStatus(null)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteUser(id),
    onSuccess: () => {
      toast.success('Account deleted')
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] })
      navigate('/admin/identity')
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setConfirmDelete(false)
    },
  })

  const assignRoleMutation = useMutation({
    mutationFn: (roleName) => assignRole(id, roleName),
    onSuccess: () => {
      toast.success('Role assigned')
      invalidate()
      setNewRole('')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const removeRoleMutation = useMutation({
    mutationFn: (roleName) => removeRole(id, roleName),
    onSuccess: () => {
      toast.success('Role removed')
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const attachPolicyMutation = useMutation({
    mutationFn: (policyId) => attachPolicy(id, policyId),
    onSuccess: () => {
      toast.success('Policy attached')
      invalidate()
      setNewPolicyId('')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const detachPolicyMutation = useMutation({
    mutationFn: (policyId) => detachPolicy(id, policyId),
    onSuccess: () => {
      toast.success('Policy detached')
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const TABS = [
    { key: 'overview', label: 'Overview', icon: UserRound },
    { key: 'access', label: 'Access', icon: FileKey2 },
    { key: 'security', label: 'Security', icon: ShieldCheck },
    { key: 'activity', label: 'Activity', icon: ScrollText },
  ]
  const requested = params.get('tab')
  const tab = TABS.some((t) => t.key === requested) ? requested : 'overview'
  const setTab = (key) => {
    const next = new URLSearchParams(params)
    if (key === 'overview') next.delete('tab')
    else next.set('tab', key)
    setParams(next, { replace: true })
  }

  return (
    <div>
      <Link
        to="/admin/identity"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 transition-colors hover:text-ink-200"
      >
        <ArrowLeft className="h-3.5 w-3.5" strokeWidth={2} /> Back to Identity
      </Link>

      <QueryState query={userQuery} skeletonRows={5}>
        {(data) => {
          const user = data.user
          // GetEffectiveAccess returns `roles` as full Role objects
          // ({id, name, description, is_system}), not name strings —
          // rendering one directly as a React child crashes with "Objects are
          // not valid as a React child". Every use here wants the plain name,
          // which is also what assignRole/removeRole send over the wire, so
          // map once up front. Likewise the field is `direct_policies`, not
          // `policies`: reading `access.policies` silently yields undefined
          // and renders an empty list rather than crashing — easy to miss
          // without testing against a real account.
          const roles = (data.access?.roles || []).map((r) => (typeof r === 'string' ? r : r?.name)).filter(Boolean)
          const policies = data.access?.direct_policies || []
          const availableRoles = SYSTEM_ROLES.filter((r) => !roles.includes(r))
          const attachedIds = new Set(policies.map((p) => p.id))
          const availablePolicies = (policiesQuery.data || []).filter((p) => !attachedIds.has(p.id))
          const privileged = roles.some((r) => /^(admin|root)$/i.test(r))

          return (
            <>
              <PageHeader
                eyebrow="Identity"
                title={user.username}
                description={user.email}
                meta={
                  <>
                    <Badge className={USER_STATUS_BADGE[user.status] || undefined}>{user.status || 'UNKNOWN'}</Badge>
                    {roles.map((r) => (
                      <Badge key={r} className={ROLE_BADGE[r] || 'bg-surface-800 text-ink-300 ring-surface-700'}>
                        {r}
                      </Badge>
                    ))}
                    {privileged && (
                      <span className="inline-flex items-center gap-1.5 rounded-md border border-red-300/60 bg-red-50 px-2 py-1 text-2xs font-semibold uppercase tracking-[0.06em] text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
                        <ShieldCheck className="h-3 w-3" strokeWidth={2} /> Privileged
                      </span>
                    )}
                    <IdChip id={user.user_id || user.id} />
                  </>
                }
                actions={
                  <>
                    <Button variant="secondary" icon={KeyRound} onClick={() => setTab('security')}>
                      Reset password
                    </Button>
                    <Button variant="dangerGhost" icon={Trash2} onClick={() => setConfirmDelete(true)}>
                      Delete
                    </Button>
                  </>
                }
              />

              {/* Identity card — avatar, name, and the two facts that decide
                  whether this account is a live risk: is it active, and when
                  was it last used. */}
              <Card className="mb-5">
                <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center">
                  <Avatar name={user.username} size="xl" />
                  <div className="min-w-0 flex-1">
                    <h2 className="truncate text-lg font-semibold leading-tight text-ink-50">
                      {user.full_name || user.username}
                    </h2>
                    <p className="mt-1 truncate text-sm text-ink-400">{user.email || '—'}</p>
                  </div>
                  <dl className="grid flex-none grid-cols-2 gap-x-8 gap-y-1 sm:text-right">
                    <dt className="text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">Created</dt>
                    <dt className="text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">Last sign-in</dt>
                    <dd className="text-sm tabular-nums text-ink-100">
                      {user.created_at ? formatDateTime(user.created_at) : '—'}
                    </dd>
                    <dd className={clsx('text-sm tabular-nums', user.last_login_at ? 'text-ink-100' : 'text-amber-600 dark:text-amber-400')}>
                      {user.last_login_at ? formatRelativeToNow(user.last_login_at) : 'Never'}
                    </dd>
                  </dl>
                </div>
              </Card>

              <TabBar tabs={TABS} active={tab} onChange={setTab} className="mb-6" />

              {tab === 'overview' && (
                <div className="grid gap-5 lg:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle icon={UserRound}>Account</CardTitle>
                    </CardHeader>
                    <DetailList
                      items={[
                        { label: 'Username', value: <span className="font-mono text-xs">{user.username}</span> },
                        { label: 'Email', value: user.email || '—' },
                        { label: 'Full name', value: user.full_name || '—' },
                        { label: 'Status', value: <Badge className={USER_STATUS_BADGE[user.status]}>{user.status || 'UNKNOWN'}</Badge> },
                        { label: 'User ID', value: <span className="font-mono text-xs">{user.user_id || user.id}</span> },
                      ]}
                    />
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle icon={ShieldCheck}>Effective access</CardTitle>
                    </CardHeader>
                    <DetailList
                      items={[
                        { label: 'Roles', value: roles.length ? roles.join(', ') : 'None assigned' },
                        { label: 'Direct policies', value: policies.length ? `${policies.length} attached` : 'None attached' },
                        {
                          label: 'Privilege',
                          value: privileged
                            ? 'Administrative — can operate the Admin Center'
                            : 'Standard — self-service only',
                        },
                      ]}
                    />
                    <CardFooter>
                      <Button size="sm" variant="secondary" onClick={() => setTab('access')}>
                        Manage access
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              )}

              {tab === 'access' && (
                <div className="space-y-7">
                  <Section label="Roles">
                    <Card>
                      <CardHeader>
                        <CardTitle icon={ShieldCheck}>Assigned roles</CardTitle>
                        <span className="ml-auto text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
                          RBAC
                        </span>
                      </CardHeader>

                      {roles.length === 0 ? (
                        <EmptyState
                          icon={ShieldCheck}
                          title="No roles assigned"
                          description="Without a role this account can authenticate but reach nothing. Assign one below."
                        />
                      ) : (
                        <ul className="divide-y divide-surface-800">
                          {roles.map((r) => (
                            <li key={r} className="flex items-center justify-between gap-4 px-4 py-3">
                              <div className="flex min-w-0 items-center gap-3">
                                <Badge className={ROLE_BADGE[r] || 'bg-surface-800 text-ink-300 ring-surface-700'}>{r}</Badge>
                                <span className="truncate text-xs text-ink-500">
                                  {r === 'root'
                                    ? 'Full control, including other administrators'
                                    : r === 'admin'
                                      ? 'Runs the Admin Center'
                                      : 'Self-service access only'}
                                </span>
                              </div>
                              <Button
                                size="xs"
                                variant="ghost"
                                icon={X}
                                loading={removeRoleMutation.isPending && removeRoleMutation.variables === r}
                                onClick={() => removeRoleMutation.mutate(r)}
                                aria-label={`Remove ${r} role`}
                              >
                                Remove
                              </Button>
                            </li>
                          ))}
                        </ul>
                      )}

                      {availableRoles.length > 0 && (
                        <CardFooter className="gap-2">
                          <select
                            className={clsx(selectClass(false), 'h-9 w-auto min-w-[10rem] py-0 text-sm')}
                            value={newRole}
                            onChange={(e) => setNewRole(e.target.value)}
                            aria-label="Role to assign"
                          >
                            <option value="">Add a role…</option>
                            {availableRoles.map((r) => (
                              <option key={r} value={r}>
                                {r}
                              </option>
                            ))}
                          </select>
                          <Button
                            size="sm"
                            variant="primary"
                            icon={Plus}
                            disabled={!newRole}
                            loading={assignRoleMutation.isPending}
                            onClick={() => newRole && assignRoleMutation.mutate(newRole)}
                          >
                            Assign
                          </Button>
                          {(newRole === 'admin' || newRole === 'root') && (
                            <span className="flex items-center gap-1.5 text-2xs font-medium text-amber-600 dark:text-amber-400">
                              <AlertTriangle className="h-3.5 w-3.5" strokeWidth={2} />
                              Grants administrative privilege
                            </span>
                          )}
                        </CardFooter>
                      )}
                    </Card>
                  </Section>

                  <Section label="Direct policies">
                    <Card>
                      <CardHeader>
                        <CardTitle icon={FileKey2}>Attached directly to this account</CardTitle>
                        <span className="ml-auto text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
                          PBAC
                        </span>
                      </CardHeader>

                      {policies.length === 0 ? (
                        <EmptyState
                          icon={FileKey2}
                          title="No direct policies"
                          description="This account's permissions come entirely from its roles. Direct policies are for exceptions — grant them sparingly."
                        />
                      ) : (
                        <ul className="divide-y divide-surface-800">
                          {policies.map((p) => (
                            <li key={p.id} className="flex items-center justify-between gap-4 px-4 py-3">
                              <div className="min-w-0">
                                <p className="truncate text-sm font-medium text-ink-100">{p.name}</p>
                                {p.description && (
                                  <p className="mt-0.5 truncate text-xs text-ink-500">{p.description}</p>
                                )}
                              </div>
                              <Button
                                size="xs"
                                variant="ghost"
                                icon={X}
                                loading={detachPolicyMutation.isPending && detachPolicyMutation.variables === p.id}
                                onClick={() => detachPolicyMutation.mutate(p.id)}
                              >
                                Detach
                              </Button>
                            </li>
                          ))}
                        </ul>
                      )}

                      {availablePolicies.length > 0 && (
                        <CardFooter className="gap-2">
                          <select
                            className={clsx(selectClass(false), 'h-9 w-auto min-w-[13rem] py-0 text-sm')}
                            value={newPolicyId}
                            onChange={(e) => setNewPolicyId(e.target.value)}
                            aria-label="Policy to attach"
                          >
                            <option value="">Attach a policy…</option>
                            {availablePolicies.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name}
                              </option>
                            ))}
                          </select>
                          <Button
                            size="sm"
                            variant="primary"
                            icon={Plus}
                            disabled={!newPolicyId}
                            loading={attachPolicyMutation.isPending}
                            onClick={() => newPolicyId && attachPolicyMutation.mutate(newPolicyId)}
                          >
                            Attach
                          </Button>
                        </CardFooter>
                      )}
                    </Card>
                  </Section>
                </div>
              )}

              {tab === 'security' && (
                <div className="space-y-7">
                  <Section label="Credentials">
                    <ResetPasswordCard userId={id} username={user.username} />
                  </Section>

                  <Section label="Lifecycle">
                    <Card>
                      <CardHeader>
                        <CardTitle icon={UserRound}>Account state</CardTitle>
                        <Badge className={clsx('ml-auto', USER_STATUS_BADGE[user.status])}>
                          {user.status || 'UNKNOWN'}
                        </Badge>
                      </CardHeader>
                      <div className="grid gap-2 p-4 sm:grid-cols-3">
                        {STATUS_TRANSITIONS.filter((s) => s.value !== user.status).map((s) => (
                          <button
                            key={s.value}
                            type="button"
                            onClick={() => setConfirmStatus(s.value)}
                            className="flex items-start gap-3 rounded-xl border border-surface-700 bg-surface-850 px-3 py-2.5 text-left transition-colors hover:border-surface-600 hover:bg-surface-800"
                          >
                            <span className="mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-900 text-ink-400">
                              <s.icon className="h-3.5 w-3.5" strokeWidth={1.75} />
                            </span>
                            <span className="min-w-0">
                              <span className="block text-sm font-medium text-ink-100">{s.label}</span>
                              <span className="mt-0.5 block text-2xs leading-relaxed text-ink-500">{s.note}</span>
                            </span>
                          </button>
                        ))}
                      </div>
                      <CardFooter>
                        <p className="text-xs leading-relaxed text-ink-500">
                          Every state change takes effect immediately and is written to the audit log
                          with your name against it.
                        </p>
                      </CardFooter>
                    </Card>
                  </Section>

                  <Section label="Danger zone">
                    <Card className="border-red-300/70 dark:border-red-900/50">
                      <CardHeader className="border-red-200/70 bg-red-50/60 dark:border-red-900/40 dark:bg-red-950/20">
                        <CardTitle icon={Trash2}>Delete this account</CardTitle>
                      </CardHeader>
                      <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
                        <p className="max-w-xl text-sm leading-relaxed text-ink-400">
                          Permanently removes the account. Its audit history remains — the trail is
                          append-only — but the account cannot be restored, and any credentials or
                          grants it held stop working immediately. Disabling is almost always the
                          better answer.
                        </p>
                        <Button variant="danger" icon={Trash2} className="flex-none" onClick={() => setConfirmDelete(true)}>
                          Delete account
                        </Button>
                      </div>
                    </Card>
                  </Section>
                </div>
              )}

              {tab === 'activity' && <ActivityTab userId={id} />}

              <ConfirmDialog
                open={!!confirmStatus}
                title={`Set ${user.username} to ${confirmStatus}?`}
                description="This changes the account's ability to sign in immediately."
                confirmLabel={`Set ${confirmStatus}`}
                destructive={confirmStatus === 'DISABLED' || confirmStatus === 'LOCKED'}
                isLoading={statusMutation.isPending}
                onConfirm={() => statusMutation.mutate(confirmStatus)}
                onCancel={() => setConfirmStatus(null)}
              />

              <ConfirmDialog
                open={confirmDelete}
                title={`Delete “${user.username}” permanently?`}
                description="The account is removed and cannot be restored. Its audit history is retained."
                confirmLabel="Delete account"
                destructive
                requireReason
                reasonLabel="Reason for deletion"
                isLoading={deleteMutation.isPending}
                onConfirm={() => deleteMutation.mutate()}
                onCancel={() => setConfirmDelete(false)}
              />
            </>
          )
        }}
      </QueryState>
    </div>
  )
}
