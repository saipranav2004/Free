import { useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  Plus, ChevronRight, UserPlus, Users, UserCheck, UserX, ShieldAlert, SearchX,
  Download, Lock, Ban, Trash2, ShieldCheck, MoreHorizontal, Copy, KeyRound,
} from 'lucide-react'
import clsx from 'clsx'
import { toast } from 'sonner'
import { listUsers } from '../../api/identity'
import { PageHeader, Card, EmptyState } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { KpiStrip } from '../../components/common/KpiStrip'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { Checkbox } from '../../components/common/Checkbox'
import { Pagination } from '../../components/common/Pagination'
import { BulkActionBar } from '../../components/common/BulkActionBar'
import { SegmentedControl } from '../../components/common/SegmentedControl'
import {
  SearchField, SortHeader, ColumnChooser, DensityToggle, ExportMenu, RefreshControl,
  ActiveFilters, SavedViewsMenu, useSavedViews,
} from '../../components/common/TableControls'
import { CreateUserModal } from '../../components/admin/CreateUserModal'
import { Avatar } from '../../components/common/UserMenu'
import { useTableState } from '../../hooks/useTableState'
import { exportRowsToCsv, exportRowsToJson } from '../../lib/exportRows'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { USER_STATUS_BADGE, ROLE_BADGE, SYSTEM_ROLES, SEARCH_DEBOUNCE_MS } from '../../config/constants'

// ---------------------------------------------------------------------------
// Admin Center — Identity
// ---------------------------------------------------------------------------
// The account inventory, built the way Okta's People list and Entra's Users
// blade are: one dense table with a status facet you can hit in one click, a
// role facet, saved views, column control, density, export and selection.
//
// SEARCH IS SERVER-SIDE and debounced, because listUsers(q) genuinely takes
// that parameter. Everything the endpoint does NOT support — status facet,
// role facet, sort, paging — is applied client-side over the returned
// collection, which is honest and stays correct. useTableState is shaped like
// a server pager so none of this has to be rewritten when paging lands.
//
// No bulk mutation is wired: /admin/identity exposes no batch route. The
// destructive bulk actions render disabled with the reason rather than fanning
// out N requests behind one innocuous click.

const COLUMNS = [
  { key: 'username', label: 'User', required: true },
  { key: 'email', label: 'Email' },
  { key: 'full_name', label: 'Full name' },
  { key: 'roles', label: 'Roles' },
  { key: 'status', label: 'Status' },
  { key: 'created_at', label: 'Created' },
  { key: 'last_login_at', label: 'Last sign-in' },
]

const CSV_COLUMNS = [
  { key: 'username', label: 'Username' },
  { key: 'email', label: 'Email' },
  { key: 'full_name', label: 'Full name' },
  { key: 'status', label: 'Status' },
  { key: 'roles', label: 'Roles', value: (u) => rolesOf(u).join(' | ') },
  { key: 'created_at', label: 'Created' },
  { key: 'last_login_at', label: 'Last sign-in' },
  { key: 'user_id', label: 'User ID' },
]

const NO_BULK_ENDPOINT = 'Requires a backend batch endpoint — not available yet'

function rolesOf(user) {
  if (Array.isArray(user?.roles)) {
    // GetEffectiveAccess returns full Role objects in some responses and
    // plain strings in others — normalise once, here, so nothing downstream
    // ever renders an object as a React child.
    return user.roles.map((r) => (typeof r === 'string' ? r : r?.name)).filter(Boolean)
  }
  if (typeof user?.roles === 'string' && user.roles) return user.roles.split(',').map((r) => r.trim())
  return []
}

function isPrivileged(user) {
  return rolesOf(user).some((r) => /^(admin|root)$/i.test(r))
}

// Row menu — per-row actions that don't need the detail page. Deliberately
// short: everything destructive lives on the account's own page behind a
// confirm, never one click from a list.
function RowMenu({ user }) {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open])

  const item = 'flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm text-ink-200 transition-colors hover:bg-surface-800 hover:text-ink-50'

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={`Actions for ${user.username}`}
        aria-expanded={open}
        className="flex h-7 w-7 items-center justify-center rounded-md text-ink-500 transition-colors hover:bg-surface-800 hover:text-ink-100"
      >
        <MoreHorizontal className="h-4 w-4" strokeWidth={2} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} aria-hidden="true" />
          <div className="animate-menu-in absolute right-0 z-40 mt-1 w-52 overflow-hidden rounded-xl border border-surface-700 bg-surface-900 p-1.5 shadow-overlay">
            <Link to={`/admin/identity/${user.user_id}`} className={item} onClick={() => setOpen(false)}>
              <Users className="h-3.5 w-3.5 text-ink-500" strokeWidth={1.75} /> Open account
            </Link>
            <Link to={`/admin/identity/${user.user_id}?tab=security`} className={item} onClick={() => setOpen(false)}>
              <KeyRound className="h-3.5 w-3.5 text-ink-500" strokeWidth={1.75} /> Reset password
            </Link>
            <button
              type="button"
              className={item}
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(user.user_id)
                  toast.success('User ID copied')
                } catch {
                  toast.error('Clipboard unavailable in this browser')
                }
                setOpen(false)
              }}
            >
              <Copy className="h-3.5 w-3.5 text-ink-500" strokeWidth={1.75} /> Copy user ID
            </button>
          </div>
        </>
      )}
    </div>
  )
}

export default function IdentityListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [focusedId, setFocusedId] = useState(null)

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })

  const users = useMemo(() => usersQuery.data?.users || [], [usersQuery.data])

  const table = useTableState({
    rows: users,
    storageKey: 'identity',
    rowId: (u) => u.user_id,
    initialSort: { key: 'username', dir: 'asc' },
    initialPageSize: 25,
    initialFilters: { status: 'all', role: 'all' },
    filterFn: (u, f) => {
      if (f.status !== 'all' && (u.status || 'UNKNOWN') !== f.status) return false
      if (f.role !== 'all' && !rolesOf(u).some((r) => r.toLowerCase() === f.role)) return false
      return true
    },
    sortAccessor: (u, key) => (key === 'roles' ? rolesOf(u).join(', ') : u[key]),
  })

  const savedViews = useSavedViews('identity')
  const [activeView, setActiveView] = useState(null)

  const counts = useMemo(
    () => ({
      total: users.length,
      active: users.filter((u) => u.status === 'ACTIVE').length,
      disabled: users.filter((u) => u.status === 'DISABLED' || u.status === 'INACTIVE').length,
      locked: users.filter((u) => u.status === 'LOCKED').length,
      privileged: users.filter(isPrivileged).length,
      neverSignedIn: users.filter((u) => !u.last_login_at).length,
    }),
    [users]
  )

  const statusFacets = useMemo(() => {
    const seen = [...new Set(users.map((u) => u.status || 'UNKNOWN'))].sort()
    return [
      { key: 'all', label: 'All', count: users.length },
      ...seen.map((s) => ({
        key: s,
        label: s.charAt(0) + s.slice(1).toLowerCase(),
        count: users.filter((u) => (u.status || 'UNKNOWN') === s).length,
      })),
    ]
  }, [users])

  // j/k row focus and x to select — the keyboard grammar every dense admin
  // table in this class of product uses. Never fires while typing in a field.
  useEffect(() => {
    const onKey = (e) => {
      const el = document.activeElement
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)) return
      if (e.metaKey || e.ctrlKey || e.altKey) return
      const rows = table.pageRows
      if (rows.length === 0) return
      const idx = rows.findIndex((r) => r.user_id === focusedId)
      if (e.key === 'j' || e.key === 'ArrowDown') {
        e.preventDefault()
        setFocusedId(rows[Math.min(idx + 1, rows.length - 1)]?.user_id ?? rows[0].user_id)
      } else if (e.key === 'k' || e.key === 'ArrowUp') {
        e.preventDefault()
        setFocusedId(rows[Math.max(idx - 1, 0)]?.user_id ?? rows[0].user_id)
      } else if (e.key === 'x' && idx >= 0) {
        e.preventDefault()
        table.toggleRow(rows[idx])
      } else if (e.key === 'Escape') {
        setFocusedId(null)
        table.clearSelection()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [focusedId, table])

  const show = (key) => !table.visibleColumns || table.visibleColumns.includes(key)
  const pad = table.density === 'compact' ? 'py-1.5' : 'py-3'

  const chips = []
  if (search) chips.push({ key: 'q', label: 'Search', value: search, onClear: () => setSearchInput('') })
  if (table.filters.status !== 'all') {
    chips.push({ key: 'status', label: 'Status', value: table.filters.status, onClear: () => table.setFilter('status', 'all') })
  }
  if (table.filters.role !== 'all') {
    chips.push({ key: 'role', label: 'Role', value: table.filters.role, onClear: () => table.setFilter('role', 'all') })
  }

  const bulkActions = [
    {
      key: 'export',
      label: 'Export',
      icon: Download,
      onClick: () => {
        exportRowsToCsv(table.selectedRows, CSV_COLUMNS, 'identity-selection')
        toast.success(`Exported ${table.selectedCount} accounts`)
      },
    },
    { key: 'disable', label: 'Disable', icon: Ban, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'unlock', label: 'Unlock', icon: Lock, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'delete', label: 'Delete', icon: Trash2, variant: 'dangerGhost', disabled: true, disabledReason: NO_BULK_ENDPOINT },
  ]

  return (
    <div className="pb-24">
      <PageHeader
        eyebrow="Admin Center"
        title="Identity"
        description="Every account in this PAM install. Create and lifecycle accounts, and manage the roles and policies that decide what each one can reach."
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
            Create user
          </Button>
        }
      />

      <KpiStrip
        className="mb-5"
        loading={usersQuery.isLoading}
        items={[
          { key: 'total', label: 'Total accounts', value: counts.total, icon: Users, description: 'Provisioned in this install' },
          { key: 'active', label: 'Active', value: counts.active, icon: UserCheck, tone: 'emerald', description: 'Able to authenticate' },
          {
            key: 'locked',
            label: 'Locked',
            value: counts.locked,
            icon: ShieldAlert,
            tone: counts.locked > 0 ? 'amber' : 'default',
            description: 'Locked out after failed attempts',
          },
          { key: 'disabled', label: 'Disabled', value: counts.disabled, icon: UserX, description: 'Retained but denied access' },
          {
            key: 'privileged',
            label: 'Privileged',
            value: counts.privileged,
            icon: ShieldCheck,
            tone: counts.privileged > 0 ? 'red' : 'default',
            description: 'Hold an admin or root role',
          },
        ]}
      />

      <div className="mb-4 space-y-3 rounded-xl border border-surface-700/70 bg-surface-900 px-3 py-3 shadow-card">
        <div className="flex flex-wrap items-center gap-2">
          <SearchField
            value={searchInput}
            onChange={setSearchInput}
            placeholder="Search username or email…"
            className="min-w-[15rem] sm:max-w-sm"
          />

          {/* Status as a one-click facet with live counts — the single most
              used filter on an account list, so it doesn't hide in a select. */}
          {statusFacets.length > 1 && (
            <SegmentedControl
              size="sm"
              ariaLabel="Filter by status"
              value={table.filters.status}
              onChange={(v) => table.setFilter('status', v)}
              options={statusFacets}
            />
          )}

          <label className="flex items-center gap-2">
            <span className="whitespace-nowrap text-xs font-medium text-ink-400">Role</span>
            <select
              value={table.filters.role}
              onChange={(e) => table.setFilter('role', e.target.value)}
              className="h-9 cursor-pointer rounded-lg border border-surface-700 bg-surface-900 pl-2.5 pr-7 text-xs font-medium text-ink-100 shadow-sm transition-colors hover:border-surface-600 focus:border-blue-500 focus:outline-none"
            >
              <option value="all">Any</option>
              {SYSTEM_ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </label>

          <span className="ml-auto flex flex-wrap items-center gap-2">
            <SavedViewsMenu
              views={savedViews.views}
              activeName={activeView}
              canSave={table.activeFilterCount > 0 || !!search}
              onApply={(v) => {
                setActiveView(v.name)
                setSearchInput(v.state.search || '')
                table.setFilters(v.state.filters || { status: 'all', role: 'all' })
              }}
              onSave={(name) => {
                savedViews.saveView(name, { search, filters: table.filters })
                setActiveView(name)
                toast.success(`View “${name}” saved`)
              }}
              onRemove={(name) => {
                savedViews.removeView(name)
                if (activeView === name) setActiveView(null)
              }}
            />
            <ColumnChooser columns={COLUMNS} visible={table.visibleColumns} onChange={table.setVisibleColumns} />
            <DensityToggle value={table.density} onChange={table.setDensity} />
            <ExportMenu
              count={table.total}
              disabled={table.total === 0}
              onExportCsv={() => exportRowsToCsv(table.filteredRows, CSV_COLUMNS, 'identity')}
              onExportJson={() => exportRowsToJson(table.filteredRows, CSV_COLUMNS, 'identity')}
            />
            <RefreshControl
              onRefresh={() => usersQuery.refetch()}
              isFetching={usersQuery.isFetching}
              updatedAt={usersQuery.dataUpdatedAt}
            />
          </span>
        </div>

        {chips.length > 0 && (
          <div className="border-t border-surface-800 pt-3">
            <ActiveFilters
              chips={chips}
              onClearAll={() => {
                setSearchInput('')
                table.resetFilters()
                setActiveView(null)
              }}
            />
          </div>
        )}
      </div>

      <QueryState
        query={usersQuery}
        empty={(data) => !data?.users || data.users.length === 0}
        emptyTitle={search ? 'No matching accounts' : 'No user accounts yet'}
        emptyMessage={
          search
            ? 'No account matches that username or email. Try a broader term.'
            : 'Create the first account to start assigning roles and policies.'
        }
        emptyAction={
          !search && (
            <Button variant="primary" icon={UserPlus} onClick={() => setCreateOpen(true)}>
              Create user
            </Button>
          )
        }
      >
        {() =>
          table.total === 0 ? (
            <Card>
              <EmptyState
                icon={SearchX}
                title="No accounts match these filters"
                description="Every returned account was filtered out by the current status or role selection."
                action={
                  <Button variant="secondary" onClick={() => table.resetFilters()}>
                    Clear filters
                  </Button>
                }
              />
            </Card>
          ) : (
            <Card className="overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[54rem] border-separate border-spacing-0 text-sm">
                  <thead>
                    <tr>
                      <th scope="col" className="sticky left-0 top-0 z-20 w-10 border-b border-surface-800 bg-surface-850 px-4 py-2.5">
                        <Checkbox
                          checked={table.allOnPageSelected}
                          indeterminate={table.someOnPageSelected}
                          onChange={table.toggleAllOnPage}
                          srLabel="Select all accounts on this page"
                        />
                      </th>
                      {show('username') && (
                        <SortHeader label="User" columnKey="username" sort={table.sort} onSort={table.toggleSort} className="sticky left-10 z-20 min-w-[14rem]" />
                      )}
                      {show('email') && <SortHeader label="Email" columnKey="email" sort={table.sort} onSort={table.toggleSort} />}
                      {show('full_name') && <SortHeader label="Full name" columnKey="full_name" sort={table.sort} onSort={table.toggleSort} />}
                      {show('roles') && <SortHeader label="Roles" columnKey="roles" sort={table.sort} onSort={table.toggleSort} />}
                      {show('status') && <SortHeader label="Status" columnKey="status" sort={table.sort} onSort={table.toggleSort} />}
                      {show('created_at') && <SortHeader label="Created" columnKey="created_at" sort={table.sort} onSort={table.toggleSort} />}
                      {show('last_login_at') && <SortHeader label="Last sign-in" columnKey="last_login_at" sort={table.sort} onSort={table.toggleSort} />}
                      <SortHeader label="Actions" columnKey="_actions" srOnly className="w-20" />
                    </tr>
                  </thead>
                  <tbody>
                    {table.pageRows.map((u) => {
                      const selected = table.isSelected(u)
                      const roles = rolesOf(u)
                      return (
                        <tr
                          key={u.user_id}
                          className={clsx(
                            'group transition-colors',
                            selected ? 'bg-blue-50/70 dark:bg-blue-500/[0.07]' : 'hover:bg-surface-850',
                            focusedId === u.user_id && 'ring-1 ring-inset ring-blue-500/40'
                          )}
                        >
                          <td className={clsx('sticky left-0 z-10 border-b border-surface-800 bg-inherit px-4', pad)}>
                            <Checkbox checked={selected} onChange={() => table.toggleRow(u)} srLabel={`Select ${u.username}`} />
                          </td>
                          {show('username') && (
                            <td className={clsx('sticky left-10 z-10 border-b border-surface-800 bg-inherit px-4', pad)}>
                              <div className="flex min-w-0 items-center gap-3">
                                <Avatar name={u.username} size="sm" />
                                <span className="min-w-0">
                                  <Link
                                    to={`/admin/identity/${u.user_id}`}
                                    className="block truncate font-medium text-ink-50 transition-colors hover:text-blue-600 dark:hover:text-blue-300"
                                  >
                                    {u.username}
                                  </Link>
                                  {isPrivileged(u) && (
                                    <span className="mt-0.5 flex items-center gap-1 text-2xs font-medium text-red-600 dark:text-red-400">
                                      <ShieldCheck className="h-2.5 w-2.5" strokeWidth={2.5} /> Privileged
                                    </span>
                                  )}
                                </span>
                              </div>
                            </td>
                          )}
                          {show('email') && (
                            <td className={clsx('max-w-[14rem] border-b border-surface-800 px-4 text-ink-300', pad)}>
                              <span className="block truncate">{u.email || '—'}</span>
                            </td>
                          )}
                          {show('full_name') && (
                            <td className={clsx('border-b border-surface-800 px-4 text-ink-400', pad)}>{u.full_name || '—'}</td>
                          )}
                          {show('roles') && (
                            <td className={clsx('border-b border-surface-800 px-4', pad)}>
                              {roles.length === 0 ? (
                                <span className="text-xs text-ink-500">None</span>
                              ) : (
                                <span className="flex flex-wrap gap-1">
                                  {roles.slice(0, 2).map((r) => (
                                    <Badge key={r} className={ROLE_BADGE[r] || 'bg-surface-800 text-ink-300 ring-surface-700'}>
                                      {r}
                                    </Badge>
                                  ))}
                                  {roles.length > 2 && (
                                    <span className="text-2xs font-medium text-ink-500">+{roles.length - 2}</span>
                                  )}
                                </span>
                              )}
                            </td>
                          )}
                          {show('status') && (
                            <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4', pad)}>
                              <Badge className={USER_STATUS_BADGE[u.status] || undefined}>{u.status || 'UNKNOWN'}</Badge>
                            </td>
                          )}
                          {show('created_at') && (
                            <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-xs tabular-nums text-ink-400', pad)}>
                              {u.created_at ? formatDateTime(u.created_at) : '—'}
                            </td>
                          )}
                          {show('last_login_at') && (
                            <td className={clsx('whitespace-nowrap border-b border-surface-800 px-4 text-xs tabular-nums', pad)}>
                              {u.last_login_at ? (
                                <span className="text-ink-400" title={formatDateTime(u.last_login_at)}>
                                  {formatRelativeToNow(u.last_login_at)}
                                </span>
                              ) : (
                                <span className="text-ink-600">Never</span>
                              )}
                            </td>
                          )}
                          <td className={clsx('border-b border-surface-800 px-2', pad)}>
                            <div className="flex items-center justify-end gap-0.5">
                              <RowMenu user={u} />
                              <Link
                                to={`/admin/identity/${u.user_id}`}
                                aria-label={`Open ${u.username}`}
                                className="flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-colors hover:bg-surface-800 hover:text-ink-100"
                              >
                                <ChevronRight className="h-4 w-4" strokeWidth={2} />
                              </Link>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              <Pagination
                page={table.page}
                pageSize={table.pageSize}
                total={table.total}
                totalPages={table.totalPages}
                onPageChange={table.setPage}
                onPageSizeChange={table.setPageSize}
                label="accounts"
              />
            </Card>
          )
        }
      </QueryState>

      <BulkActionBar
        count={table.selectedCount}
        total={table.total}
        noun="account"
        actions={bulkActions}
        allMatchingSelected={table.allMatchingSelected}
        onSelectAllMatching={table.selectAllMatching}
        onClear={table.clearSelection}
      />

      <CreateUserModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
