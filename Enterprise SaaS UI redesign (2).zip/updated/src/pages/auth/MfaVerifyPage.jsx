import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { AlertCircle, ArrowLeft, ShieldCheck } from 'lucide-react'
import { verifyMfa } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { apiErrorMessage } from '../../lib/apiError'
import { Button } from '../../components/common/Button'
import { ThemeToggle } from '../../components/common/ThemeToggle'
import { OtpInput, isCompleteOtp } from '../../components/common/OtpInput'
import logoWordmark from '../../assets/logo-wordmark.png'
import logoWordmarkDark from '../../assets/logo-wordmark-dark.png'

// NOTE ON THE MISSING COUNTDOWN: the previous PAM frontend showed a live
// countdown for the MFA challenge. Verified against THIS backend
// (auth_service.go's verifyChallengeToken): the challenge token has no expiry
// check at all — it's parsed and accepted regardless of age. Rather than show
// a countdown that lies about enforcement that doesn't exist, this screen
// doesn't claim one.
//
// CODE LENGTH: the field is six boxes, exactly six digits, via the shared
// OtpInput. The old input accepted eight characters and enabled its submit
// button at one, so a code that could never be valid was submittable.
export default function MfaVerifyPage() {
  const navigate = useNavigate()
  const challenge = useAuthStore((s) => s.mfaChallenge)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
  const setSession = useAuthStore((s) => s.setSession)
  const clearMfaChallenge = useAuthStore((s) => s.clearMfaChallenge)
  const [code, setCode] = useState('')
  const [error, setError] = useState(null)

  // Guard against reaching this screen with no challenge in memory (deep
  // link, back button, stale bookmark). It must also check isAuthenticated:
  // setSession() clears mfaChallenge in the same update that sets the token,
  // so without that check this fires on the success path too and its
  // navigate('/login') races the success handler's navigate('/').
  useEffect(() => {
    if (!challenge?.challengeToken && !isAuthenticated) {
      navigate('/login', { replace: true })
    }
  }, [challenge, isAuthenticated, navigate])

  const mutation = useMutation({
    mutationFn: (c) => verifyMfa(challenge.challengeToken, c),
    onSuccess: (result) => {
      resetSessionExpiredGuard()
      clearMfaChallenge()
      setSession({
        accessToken: result.access_token,
        expiresAt: result.expires_at,
        user: null,
      })
      navigate('/', { replace: true })
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      // Clear on failure so the user re-types rather than resubmitting the
      // same rejected code — OtpInput returns focus to the first box.
      setCode('')
    },
  })

  const submit = (c) => {
    const value = c ?? code
    if (!isCompleteOtp(value) || mutation.isPending) return
    setError(null)
    mutation.mutate(value)
  }

  if (!challenge?.challengeToken) return null

  return (
    <div className="flex min-h-screen flex-col bg-surface-950 px-4 py-8 sm:px-8">
      <div className="flex items-center justify-between">
        <div>
          <img src={logoWordmark} alt="Deep Algorithms" className="h-6 w-auto object-contain object-left dark:hidden" />
          <img src={logoWordmarkDark} alt="" aria-hidden="true" className="hidden h-6 w-auto object-contain object-left dark:block" />
        </div>
        <ThemeToggle compact />
      </div>

      <div className="flex flex-1 items-center justify-center">
        <div className="w-full max-w-[25rem]">
          <div className="mb-7 text-center">
            <span className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-sky-500 text-white shadow-sm ring-1 ring-inset ring-white/20">
              <ShieldCheck className="h-5 w-5" strokeWidth={1.75} />
            </span>
            <h1 className="text-xl font-semibold tracking-tight text-ink-50">Two-factor verification</h1>
            <p className="mt-1.5 text-sm leading-relaxed text-ink-400">
              Enter the 6-digit code from your authenticator app to finish signing in.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault()
              submit()
            }}
            className="rounded-2xl border border-surface-700/70 bg-surface-900 p-6 shadow-card"
          >
            <OtpInput
              value={code}
              onChange={setCode}
              onComplete={submit}
              invalid={!!error}
              disabled={mutation.isPending}
              autoFocus
              ariaLabel="Six digit verification code"
            />

            {error && (
              <div
                role="alert"
                className="mt-4 flex items-start gap-2.5 rounded-lg border border-red-300/70 bg-red-50 px-3 py-2.5 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
              >
                <AlertCircle className="mt-0.5 h-4 w-4 flex-none" strokeWidth={2} />
                <span className="leading-relaxed">{error}</span>
              </div>
            )}

            <Button
              type="submit"
              variant="primary"
              size="lg"
              block
              className="mt-5"
              loading={mutation.isPending}
              disabled={!isCompleteOtp(code)}
            >
              Verify and continue
            </Button>

            <p className="mt-4 text-center text-xs leading-relaxed text-ink-500">
              Lost your device? Enter one of your saved backup codes in the same field.
            </p>
          </form>

          <div className="mt-6 flex justify-center">
            <Button
              variant="ghost"
              size="sm"
              icon={ArrowLeft}
              onClick={() => {
                clearMfaChallenge()
                navigate('/login', { replace: true })
              }}
            >
              Back to sign in
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
