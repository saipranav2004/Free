# Changed files — navbar, profile menu, Settings (round 2) + earlier: sidebar, login, KPI system, Resources

> **Round 2** adds 12 files (7 new, 5 updated) — top navbar, profile menu, Settings.
> **Round 3** adds 13 files (7 new, 6 updated) — Audit, Audit & Compliance, Identity, plus the modal focus-stealing fix.

Drop these over your `src/` (and `tailwind.config.js`) at the same paths. **38 files: 11 new, 27 updated.**

Every API call, query key, mutation, payload shape and route in the app is unchanged. No endpoint was added, removed or re-parameterised. Where a feature would have needed an endpoint that doesn't exist, it is either derived from data already fetched or shown disabled with the reason — never faked.

---

## Task 1 — Sidebar cleanup

**`src/components/common/AppLayout.jsx`**

| Removed | Added |
|---|---|
| Top branding box (wordmark plate, shield icon, "IAM Console" title, "PRIVILEGED ACCESS" subtitle) | Plain-text console title at the very bottom — no icon, no box, no border, no background |
| Bottom user-profile block (avatar, `das_admin`, `ROOT` badge, logout arrow, entire `SidebarFooter` component) | Collapse control in the sidebar's **top-right corner** |

- **Console title** is role-dependent: `IAM Console` for admin/root, `PAM Console` for everyone else. One `<p>` with `text-xs`, `text-ink-500`, comfortable padding. Hidden when collapsed (it would truncate to nonsense in a 76px rail).
- **Collapse control** moved from the topbar (previously bottom-right area) to the panel's own top-right corner — where Okta, Entra ID and CyberArk put it, because the affordance should sit on the edge that actually moves. Centres itself in the collapsed rail. 32×32 hit area, `PanelLeftClose`/`PanelLeftOpen` at 1.5 stroke, `aria-pressed`, tooltip, unchanged smooth transition.
- **Logout was not lost** — it still lives in the topbar user menu, which was already the primary location.

---

## Task 2 — KPI system (every page with metrics)

**`src/components/common/KpiStrip.jsx`** *(new)* — exports `KpiStrip` and `KpiCell`.

The pattern is taken from **your own Audit Logs screen** (your second reference image), promoted to a shared component: one bordered instrument divided into cells, no gaps — not four floating cards.

```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│ ▣ LABEL      │ ◔ LABEL      │ ⊘ LABEL      │ ⊕ LABEL      │
│ 1,284        │ 46           │ 17           │ 3            │
│ description  │ description  │ description  │ description  │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

Gapped cards make four unrelated objects out of one reading; a divided strip says *these numbers describe the same thing*. Entra ID, Okta and your audit screen all do it this way.

- 28px semibold tabular figures, letterspaced 11px uppercase labels, one description line.
- Six tones. Attention tones (`amber`, `red`) tint the figure itself — a denied count should read red, as it does on your reference.
- `live` adds a pulsing presence dot; `to`/`onClick` makes a cell a drill-through; `loading` renders a shimmer at the figure's size (no layout shift).
- `columns` for hand-composed strips (`<KpiStrip columns={3}><KpiCell …/></KpiStrip>`).

**No trend arrows, deltas, sparklines or "vs. last month" anywhere.** These endpoints return point-in-time counts with no history, so any trend would be invented. The component has no props for them.

Where a figure can only be computed from the current page (server-paged endpoints), the description says "on this page" rather than implying it covers the whole result set.

Applied to: **Dashboard** (Posture, Your access) · **Admin Overview** (approvals, break-glass, chain) · **Identity** · **Resources** (5 cells) · **Vault/Safes** · **Sessions** · **JIT** · **Admin JIT Approvals** · **Audit** · **Admin Audit & Compliance** · **Roles**

---

## Task 2 — Pagination, selection, bulk actions + the rest

### `src/hooks/useTableState.js` *(new)*
Search, faceted filters, sort, pagination and selection in one hook.

**Client-side, by necessity:** `GET /pam/resources/groups` and `GET /admin/identity/users` take no page parameters — they return whole collections. A fake "page 2" request the server ignores would be worse than honest local paging.

**Shaped like a server pager anyway:** returns `{ page, pageSize, total, totalPages, pageRows }` — the same shape your backend's `paged()` helper already produces. When those endpoints grow `page`/`page_size`, pass `serverMode: true` and every consumer keeps working. That's a seam, not a stopgap.

Details worth knowing:
- Sort comparator handles numbers, ISO dates, booleans and strings; nullish always sorts last in both directions. Copies before sorting, so the react-query cache array is never mutated.
- Third click on a column header clears the sort — back to the API's own order.
- Page clamps when a filter shrinks the set (no "Page 9 of 3").
- Selection clears on filter/search change — a selection that survives a filter applies to rows the user can't see.
- `pageSize`, `sort`, `density` and column visibility persist per table in `localStorage`, guarded so a locked-down profile degrades to "prefs don't stick" rather than throwing.

### `src/components/common/Pagination.jsx` *(rewritten)*
`Showing 1–25 of 1,284` · rows-per-page (10/25/50/100, or 12/24/48/96 for the card grid) · first/prev/**windowed page numbers with ellipses**/next/last. The window is a constant width so the control doesn't resize as you walk pages. Renders the count and page-size selector even on a single page — otherwise a filter that narrows to one page removes "how many are there?" from the screen.

### `src/components/common/BulkActionBar.jsx` *(new)*
Floats over content when anything is ticked (wedging a bar above the table pushes rows away from the cursor).

Two deliberate behaviours:
1. **Scope is explicit.** "12 selected" and "all 1,284 matching your filters" are different claims. When a full page is ticked and more rows match, widening is offered as a separate second click. Internally, all-matching mode stores *exclusions*, so "all 1,284 except these two" is expressible.
2. **Unavailable actions are visible, not hidden.** Per your instruction, destructive bulk actions ship **disabled with a lock icon and the reason** — *"Requires a backend batch endpoint — not available yet."* Enable/disable, rotate credentials and delete are all in this state. **Export selection to CSV is live**, because it needs no endpoint.

### `src/components/common/Checkbox.jsx` *(new)*
Native input (keyboard- and SR-correct) with a drawn box over it. Handles the indeterminate DOM property for header "some selected" state.

### `src/components/common/TableControls.jsx` *(new)*
`SearchField` · `SortHeader` (sticky, `aria-sort`) · `DensityToggle` · `ColumnChooser` (with `required` columns that can't be hidden) · `ExportMenu` · `RefreshControl` · `SavedViewsMenu` + `useSavedViews` · `ActiveFilters` chips.

`RefreshControl` shows *when* the data was fetched and re-renders every 30s so "2m ago" doesn't quietly become a lie — in a security console, "no active sessions" and "no active sessions as of nine minutes ago" are different statements.

### `src/components/common/Drawer.jsx` *(new)*
Row peek without losing your place in a filtered, paged, partially-selected table. Escape closes; footer carries "Open full page".

### `src/lib/exportRows.js` *(new)*
CSV + JSON of any filtered view, assembled from rows already on screen (there is no export endpoint, and only the browser knows the view you built).

Two things most CSV exporters get wrong, handled here:
- **Formula-injection guard** — values starting `=`, `+`, `-`, `@` are prefixed with `'`. This app exports attacker-influenced strings (usernames, resource names, audit detail); without this, `=CMD()` executes when the file opens in Excel.
- **UTF-8 BOM** so Excel renders accented and CJK names instead of mojibake.

### Also delivered on the list pages
Saved views · ⌘K-free keyboard row nav (`j`/`k`, `x` to select, `Enter` to peek, `Esc` to clear — all ignored while typing in a field) · sticky header + frozen select/name columns · column chooser · density toggle · skeleton loading · distinct empty states · last-refreshed stamp.

**Empty states are split by cause:** "no resources registered" (→ register one) is a different situation from "no resources match these filters" (→ clear filters). Offering "register a resource" to someone whose filter is too narrow is a dead end.

---

## Task 3 — Resources list + detail + register form

### `src/pages/resources/ResourcesPage.jsx` *(rewritten)*
Same single `listResourceGroups()` call. The nested platform-group response is flattened once, with the group name carried along as a filterable/sortable field.

- **KPI row** (5 cells): total · JIT-gated · standing · with credential · inactive.
- **Card grid** (your pick) as the default view, **plus a table view** with sortable columns, column chooser and density toggle — the same rows, two readings.
- **Advanced filtering:** search across name/host/description/database/group/type, plus type, group, status, access model and credential-presence facets, with removable active-filter chips.
- **Grouping demoted to an option.** Platform grouping was the old page's mandatory structure; it's now a "Group by platform" toggle. Grouping helps when browsing and gets in the way when you're hunting one host among four hundred.
- **Card design:** type glyph, name, `host:port` in mono, status badges (Active/Inactive · JIT-gated/Standing · Recorded), type + group facts, and a footer with credential state and **inline Quick connect**. The selection checkbox appears on hover/focus or once a selection is in progress — a permanently visible checkbox on every card turns a catalogue into a form.
- Quick connect routes to the detail page's connect panel (`#connect`), so JIT gating and credential checks run through exactly one code path.

### `src/pages/resources/ResourceDetailPage.jsx` *(rewritten)* + `ResourceDetailTabs.jsx` *(new)*
Restructured from two side-by-side cards into the object-with-tabs shape every mature PAM console uses:

**Overview · Connect · Credentials · Sessions · Policies · Audit**

- Identity header with type glyph, status badges and a **click-to-copy resource ID**.
- **Summary rail** — type, endpoint, elevation, recording — so you never open a tab to learn whether a resource is gated, recorded or live.
- `#connect` deep-links straight to the Connect tab, so arriving from a card's Quick connect lands where you asked.
- **Credentials tab** keeps the exact payload remap the backend requires (`username` → `account_name`, `secret` → `credential`) and the same store/rotate mutations. Adds a handling panel stating that secrets never reach the browser.
- **Sessions tab** is labelled "your sessions" — `/sessions/mine` is self-service-scoped and takes no resource parameter, so filtering is local and the heading says so rather than implying org-wide visibility.
- **Audit tab** calls `auditByResource` once with `retry: false`. The wildcard route's shape isn't documented for resource records, so on failure it shows a plain notice and points at the Audit page — never an empty list, which would read as "nothing ever happened here".
- **Policies tab** explains the three rules actually stored on the record (JIT, recording, active), and links to Admin → Policies for role/policy grants it doesn't own.

### `src/components/resources/CreateResourceModal.jsx`
Same eleven fields, same zod schema, same single POST — staged into the three decisions an operator makes, with a review step before the write:

**Identity → Connection → Access → Review**

- Per-step validation via `trigger()`, so a bad host can't be carried to the end.
- Default ports per resource type (5432, 27017, 6379…); typing over the suggestion always wins.
- Access step renders the two policy flags as **decision cards with consequences**, tinted when armed — not two unlabelled checkboxes at the bottom of a form.
- Review step shows the full record plus a note that registration is audit-chained and that the resource brokers sessions only once a credential is attached.

Registering a privileged system is consequential; a flat stack of eleven inputs invites tabbing through without reading.

---

## Login page

**`src/pages/auth/LoginPage.jsx`** — rebuilt to your platform login (`nav.cf.adapid.link`).

- Deep navy field (`#0A1729`) with two soft radial washes and a masked grid texture — depth without a gradient sweep.
- Outlined **ENTERPRISE SECURITY PLATFORM** pill with a cyan dot.
- Heavy tight headline, final word in brand cyan (`#29A8E0`); trust row with emerald check glyphs.
- Floating white credential card (24px radius, deep soft shadow), icon-prefixed field labels, 52px rounded inputs, password eye toggle, right-aligned forgot link, full-width cyan→blue gradient **Sign in securely →** button.

**Deliberately theme-independent.** Your sign-in is a fixed brand surface, not a themed console screen, so it uses literal brand values rather than the app's `surface-*`/`ink-*` tokens — it looks identical regardless of the viewer's light/dark preference.

**Auth logic untouched:** same schema, same `react-hook-form` wiring, same mutation, same `access_token` vs `challenge_token` branch (both arrive on HTTP 200 — `ErrMFARequired` is a success response in `auth_handler.go`), same redirect-to-`from`.

Two notes:
- **Copy is PAM-specific** ("Privileged Access Management", brokered sessions / JIT / tamper-evident audit) rather than the reference's CIRMP wording, since this is the PAM console. Say the word and I'll switch it to verbatim CIRMP copy.
- **Forgot password** has no route in this codebase — administrators issue resets through Identity Management. The link says that in a toast instead of navigating to a dead end. Same for tenant onboarding, which is why it isn't rendered.

---

## Decisions I made on your behalf

You left five answers blank. What I chose, and how to change it:

| Question | Choice | To change |
|---|---|---|
| KPI style | **Segmented strip** everywhere — it's your own Audit Logs pattern, so the redesign matches what you already ship | One component: `KpiStrip.jsx` |
| Trend data | **Omitted** — no history endpoint exists | Add a history endpoint and I'll wire trend slots |
| Pagination | **Client-side, server-shaped** | `serverMode: true` once endpoints take page params |
| Login copy | **PAM-specific**, reference visuals | Ask and I'll switch to verbatim |
| Resource detail | **Drawer for peek, full page for depth** | Both exist and share one status vocabulary |
| Bulk actions enabled | **Export CSV only**; the rest disabled with reasons | Remove `disabled` in `ResourcesPage.jsx`'s `bulkActions` once batch endpoints land |

## Not done

- **Command palette (⌘K)** — you picked it, but it wants a route/action registry spanning every page. It's a clean standalone addition; say the word and it's next.
- **Bulk actions on Identity, Sessions, JIT, Audit** — selection UI is wired on Identity; the action sets there are mostly destructive, so they wait on the same batch endpoints.


---

# Round 2 — top navbar, profile menu, Settings

**12 files: 7 new, 5 updated.** Same rule as before: no endpoint invented. Anything the backend can't do yet is either derived from data already fetched, stored locally with that stated on screen, or shown read-only with the reason.

## Task 1 — Top navbar (fixed) + sidebar moved below it

**`src/components/common/TopNavbar.jsx`** *(new)* · **`src/components/common/AppLayout.jsx`** *(rewritten shell)* · **`src/config/nav.js`** *(new)*

| Requirement | How it's done |
|---|---|
| Navbar fixed at the very top, cannot scroll | `position: fixed; inset-x-0; top-0; z-50`, 64px tall. The shell is `h-screen overflow-hidden pt-16`, so only `<main>` scrolls — the document itself never does |
| Company logo in the left corner only | Wordmark (`logo-wordmark.png` / `-dark.png`, swapped by theme) at the far left, mark-only below `sm`. Removed from the sidebar and from the old mobile topbar block |
| Sidebar starts below the navbar | The sidebar is a child of the padded shell, not a sibling of the navbar: `top: 64px` by construction, zero overlap. The mobile drawer also opens at `top-16`, so identity and profile stay reachable while it's open |

Navbar anatomy, left to right: logo · divider · console title + breadcrumb (title is role-dependent — **IAM Console** for admin/root, **PAM Console** otherwise) · spacer · **Jump to… (⌘K)** · notifications · appearance · divider · profile.

- **Jump to…** is real and navigation-only: filter, ↑↓, ↵, esc; ⌘K/Ctrl-K from anywhere. The full command palette still waits on an action registry — a palette listing actions it can't run is worse than one that only jumps.
- **Notifications** (`NotificationsMenu.jsx`, new) is derived from live JIT endpoints, not an invented feed: JIT requests awaiting your approval (admin/root), your own pending requests, and grants expiring within 30 minutes. 60s poll (no server push exists), `retry: false` so a hiccup never becomes a retry storm. Empty state is honest: "Nothing needs you".
- The sidebar's console-title footer is **gone** — the title now lives in the navbar. Keeping both would have printed the same words twice on one screen. Nav arrays moved to `src/config/nav.js` so the sidebar, breadcrumb and ⌘K read one list.

## Task 2 — Profile area

**`src/components/common/UserMenu.jsx`** *(new — also exports `Avatar`)*

- Trigger: initials avatar on the login screen's navy→cyan gradient, username, and the highest-privilege **role badge** (root outranks admin). **No chevron** — the avatar is the affordance; a caret makes identity read as a form control.
- Dropdown: user header (name, email, every role), a session-posture line (**MFA verified this session** — it decides whether vault reveals will succeed), then Profile / Settings, then Sign out on its own tier with the danger treatment. Rounded-2xl, real overlay shadow, 120ms `menu-in` entrance, Escape + click-outside close, `role="menu"` with focus-visible rings throughout. Lucide icons only.

## Task 3 — Settings redesign + MFA fix

**`src/pages/SettingsPage.jsx`** *(rewritten)* · **`src/components/auth/MfaEnrollment.jsx`** *(rewritten)* · **`src/lib/mfaStatus.js`** *(new)* · **`src/components/common/Switch.jsx`** *(new — `Switch` + `SettingRow`)* · **`src/components/common/ThemeToggle.jsx`** + **`src/store/themeStore.js`** *(updated)*

Six tabs on the shared `TabBar`, deep-linkable via `?tab=` (the profile menu's "Profile" item lands on `?tab=account`):

| Tab | Wired to | Notes |
|---|---|---|
| Account | `/auth/me` + session store | Identity card, identity detail list, current-session card (token expiry with time remaining, MFA state) |
| Security | `/auth/me`, MFA setup endpoints | MFA panel (below) + read-only "Policy in force" from the deployment's configured JIT/break-glass defaults |
| Notifications | this browser | Five preference switches; a save bar **appears only when dirty** (Discard / Save preferences) with a notice saying they're local until a preferences endpoint exists |
| Integrations | `/agent/devices` | pam-agent API endpoint with copy, paired-device management, API keys section read-only (no self-service issuance endpoint) |
| Appearance | theme store | Light / Dark segmented control; applies instantly, remembered per browser |
| Organization *(admin only)* | — | Read-only tenant facts + disabled fields, with the reason stated |

**MFA bug — fixed.** The old page decided what to render from local component state ("did you enroll in *this tab*?"), so an enrolled account — including one that had just cleared an MFA challenge to sign in — was shown **Enable MFA** on every visit.

- `src/lib/mfaStatus.js` reads enrolment from the `/auth/me` payload defensively: any of the known enabled flags, or an active entry in an MFA device list, or — always present — `mfa_verified`, which cannot be true unless MFA is enrolled. So the correct state shows even on builds that don't expose an explicit flag.
- `MfaEnrollment` now opens on an **MFA enabled** state: emerald status pill, method, enabled date when the API reports one, whether *this session* is verified, and **Replace authenticator** as the only enrolment action. **Enable MFA** is unreachable while MFA is on.
- **Disable MFA** is rendered but disabled, with the reason: no self-service disable endpoint exists — an administrator must reset it. Same policy as the disabled bulk destructive actions from round 1.
- The backup-codes step still cannot be auto-dismissed (they are shown exactly once).

**Theme control: Light / Dark only.** The retired "system" mode no longer appears anywhere. Persisted `'system'` values resolve to a concrete light/dark value instead of being dropped, and the OS preference is still honoured — but only as the initial value for someone who has never chosen. `cycleTheme()` is kept as an alias so no caller breaks.


---

# Round 3 — Audit, Audit & Compliance, Identity

**10 files: 7 new, 3 updated.** Tasks 1–3 of this round (MFA status, six-digit code input, navbar search, Vault) shipped in the previous drop — this covers Tasks 4 and 5.

## Task 4 — Audit page + Audit & Compliance, rebuilt on one instrument

Five new shared files under `src/components/audit/`, consumed by BOTH screens so they can never drift apart again:

| File | What it is |
|---|---|
| `auditFields.js` | Every defensive field reader (time/actor/target/IP/id), the date-range presets, and `refineRows` — the single client-side pass both pages run |
| `AuditTable.jsx` | The columnar table: Time · Action · Actor · Target · Outcome · Severity · Source IP, tabular numerals, monospace action strings, and a red left rail on any denied/failed/critical row |
| `AuditFilterBar.jsx` | Debounced search, date range (1h → 90d → custom), category + outcome facets, a collapsed **More** row for severity/actor/exact-action, active-filter chips, density, export, refresh |
| `AuditEventDrawer.jsx` | Row detail as a **side drawer**, not a modal — grouped Actor / Target / Request context / Chain integrity / Recorded detail, copy on every identifier, and two pivots: *Events by this actor*, *Same action* |
| `ReportBuilder.jsx` | Compliance report panel, seeded from the range the list is already filtered to, with a live scope summary |

**`src/pages/audit/AuditPage.jsx`** and **`src/pages/admin/AdminAuditPage.jsx`** are rewritten on top of those.

- **Cards → table.** The old screens rendered audit entries as soft two-line cards. An audit trail is columnar data scanned down one axis; a card makes you re-find every field on every row.
- **A real date range**, which neither screen had. It is sent to the server *and* applied client-side — see the honesty note below.
- **Failures are findable.** Denied, error and critical rows carry a red edge rail and a tinted hover, so one denial in a page of successes can't hide.
- **Detail is a drawer.** Reading an audit trail is open-read-close-next; a centred modal blanked the table and lost your place in a filtered, paged result set every time.
- **Admin Center gains a real Chain integrity tab** — verdict plate, plus any sequence/count facts the verification payload actually carries (rendered only when present, never invented).
- **Recordings** becomes a proper table (resource, session, started, duration, size, status) with page-scoped filtering that says it is page-scoped.
- **Report generation** moved out of a cramped header row into a panel that states exactly what it will include.

**The one honesty note.** Filters are sent as query params, but this backend's audit search is only documented for `q`, `category`, `outcome` and `action`. An endpoint that ignores an unknown param returns unfiltered rows — a filter that visibly does nothing. So `refineRows` re-applies date range, severity, actor and exact-action to what comes back. When the server honours them it is a no-op; when it doesn't, the operator still sees only what they asked for, and an amber line under the table says how many rows were hidden and that the server total still counts them.

**Search stays fixed on `q`**, not `action`. `action` is an exact match on strings like `pam:vault:Reveal`, so typing anything else returned zero rows — which is what "search doesn't work" meant. Exact-action matching is still there, as its own labelled field under **More**.

## Task 5 — Identity list, detail page, Create User

**`src/components/admin/CreateUserModal.jsx`** *(rewritten)* — now on the shared `Modal` shell with real fieldsets.

- **Full name: letters and spaces only.** Digits and symbols are dropped *as you type* — typing `3` does nothing — rather than accepted then scolded. Unicode-aware, so *Zoë Ferreira* passes and *user123* doesn't.
- **Username: Instagram-style.** Lowercase letters, digits, `_` and `.`; no spaces; no leading/trailing period; no double periods; 3–30 characters. Uppercase folds to lowercase live. A three-item **live rule checklist** ticks as you type instead of a paragraph of red text after submit.
- Both rules live in `lib/validators.js` and back **both** the sanitizer and the zod schema, so field and submit can't disagree.
- Password field gains show/hide, a generator, and an advisory strength meter that never blocks a submit the server would accept. **Use for username** derives a valid username from the typed name in one click. Privileged roles (admin/root) raise an inline warning.

**`src/pages/admin/IdentityListPage.jsx`** *(updated)* — status as a one-click segmented facet with live counts, a role facet, **saved views**, a per-row action menu (open · reset password · copy user ID), avatars, a *Privileged* marker on any admin/root account, relative last-sign-in with **Never** called out, plus the existing columns/density/export/selection. Search stays server-side and debounced; bulk destructive actions stay disabled with the reason (no batch endpoint).

**`src/pages/admin/IdentityDetailPage.jsx`** *(rewritten)* — was two columns of unlabelled boxes. Now an identity record: header with avatar, status, role badges, privileged marker and copyable ID; an identity card carrying the two facts that decide risk (created, last sign-in — **Never** in amber); then four deep-linkable tabs:

| Tab | Contents |
|---|---|
| Overview | Account facts + effective-access summary |
| Access | Roles and direct policies as real lists with inline add/remove, each role explained in a line; assigning admin/root warns before you do it |
| Security | Password reset with generator + strength, lifecycle state as three explained choices, and a bordered danger zone for deletion |
| Activity | This account's own slice of the audit trail, using the same table and drawer as the Audit pages |

Both destructive actions route through `ConfirmDialog`; deletion requires a typed reason, because the backend writes it into the audit record. The `access.roles`-are-objects and `direct_policies`-not-`policies` traps from the original file are still handled, and now documented in place.


---

## Focus-stealing bug in dialogs — fixed

**`src/components/common/Modal.jsx`**, **`src/components/common/Drawer.jsx`**, **`src/components/resources/CreateResourceModal.jsx`** *(all updated)*

**Symptom:** open a create form (Resource, Safe, Credential, Folder, User, JIT request), start typing in the third field, and the caret jumps back to the first field mid-word.

**Cause.** `Modal`'s open-effect depended on `[open, onClose, busy]`. Every call site passes an inline arrow — `onClose={() => setCreateOpen(false)}` — which is a **new function identity on every parent render**, and the parent re-renders constantly behind the dialog (react-query background refetches, `isFetching` flipping, poll ticks). Each re-run fired the effect, which 20ms later ran `querySelector(…first focusable…)` and focused it. `busy` flipping during a mutation did the same.

Create Resource was the worst case and the one you hit: it calls `watch()` on the whole form (the review step needs live values), so **every keystroke** re-rendered the modal, and its `close` handler — passed straight to `onClose` — was rebuilt each time. Effect re-ran per character; focus snapped to field one every time.

**Fix, three parts in `Modal`:**
1. The effect depends on **`[open]` only** — opening should move focus; a parent re-render should not.
2. `onClose` and `busy` are read through latest-value refs, so handlers stay current without the effect re-subscribing.
3. Focus is moved **only if it isn't already inside the panel** — even a forced re-run can't yank the caret out of what you're typing. The focusable query also now skips disabled controls.

**A second bug fell out of the same cause.** Each re-run captured the body's *current* `overflow` as "the original" — which by then was already `hidden` — so closing the dialog restored `hidden` and left the page unable to scroll. The lock now applies once per open and restores once on close.

**Swept for the same pattern elsewhere:**
- `Drawer` had the identical unstable dependency on its Escape listener (`[open, onClose]`) — same ref treatment applied. It only re-subscribed a listener rather than stealing focus, but it's the same trap for the next edit.
- `CreateResourceModal.close` is now `useCallback`-memoized, so the handler is stable at source too, not just tolerated by the hardened Modal.
- Checked and clean: `OtpInput` (autoFocus effect keyed on a constant, `onComplete` fires once per code transition), `GlobalSearch`/`QuickJump` (focus keyed on `[open]`), the `UserMenu`/`NotificationsMenu`/row menus (listeners keyed on `[open]`), and the `[open, reset]` resets in the vault and user modals (RHF's `reset` is stable).

Every dialog in the console routes through `Modal` — including `ConfirmDialog` — so this fix reaches all of them, not just the ones listed above.
