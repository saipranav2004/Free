# Round 12 — changed files

Drop these into your app at the same paths (they replace the current files).

## Task 1 — Resources
- `src/components/resources/ResourceDetailTabs.jsx`
  - **Audit tab now shows this resource's logs.** It used to rely solely on
    `GET /pam/audit/resource/{uuid}`, which returns nothing on this backend
    because audit rows don't consistently record the resource UUID in that
    field. It now asks that route AND a recent slice of the trail the viewer is
    allowed to read (`/admin/audit` for admins, `/pam/audit` otherwise),
    filters it to rows referencing this resource by id / name / host (including
    ids nested in a details/metadata blob), de-duplicates by event id and sorts
    newest first. The amber "unavailable" notice only appears if BOTH sources
    fail. A footer line states the match basis and sample size.
  - **Overview → Protocol configuration card commented out** (not deleted).
- `src/components/resources/ResourceDrawer.jsx`
  - The drawer's primary footer button is now a real **Open in Desktop** (same
    launch mutation as the detail-page header), replacing the old "Connect"
    link that only navigated. A 409 ("no device paired") closes the drawer and
    sends you to the resource page, which hosts the pairing panel.
- `src/components/resources/ResourceAccess.jsx`
  - `OpenInDesktopButton` accepts a `size` prop (defaults to `md`) so the
    drawer can render it at `sm` alongside "Open full page".

## Task 2 — JIT hidden for admins
- `src/config/nav.js` — new `consoleNav(isAdmin)` drops the self-service
  **JIT Access** entry for admin/root; `quickJumpTargets` (⌘K) uses it too.
- `src/components/common/AppLayout.jsx` — sidebar renders `consoleNav(isAdmin)`.
- `src/App.jsx` — `/jit` and `/jit/requests/:id` redirect admins to
  `/admin/jit` (`SelfServiceOnly` wrapper), so stale links/bookmarks and
  notification deep links still land somewhere useful.

## Task 3 — Dashboard control-plane card
- `src/pages/DashboardPage.jsx`
  - **Verify chain removed from the masthead** (component + mutation kept as a
    commented block; `verifyAudit` import commented). Chain verification still
    exists on Admin Center → Audit & Compliance → Chain, which shows break
    detail properly.
  - **Much less text in the card**: one-line description, KPI captions cut to
    two or three words each. The five posture numbers now use the full width.
  - **Improvement instead**: an "Accounts hitting denials" ranking beside "Most
    active accounts", computed from the same audit sample (no extra request) —
    it answers who is being refused, which is where mis-provisioning shows up.
    Rendered only when the sample contains denials.
  - The Activity section header now links to Audit & Compliance.

## Still open (backend)
- `SetupMFAInitiate` needs `AND status = 'PENDING'` so opening MFA setup
  can't silently delete an active enrolment.
- If `/audit/resource/*` gains a documented id index, the wide scan in the
  Audit tab becomes redundant and can be dropped.
