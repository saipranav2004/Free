package config

import "testing"

func TestValidateSchemaName(t *testing.T) {
	valid := []string{"tenant_a", "nhi_global", "_x", "Tenant1"}
	for _, name := range valid {
		if err := ValidateSchemaName(name); err != nil {
			t.Errorf("ValidateSchemaName(%q) = %v, want nil", name, err)
		}
	}
	invalid := []string{"", " ", "1abc", "tenant-a", `a"; DROP SCHEMA x; --`, "a.b", "a b", "tenant_a;", string(make([]byte, 70))}
	for _, name := range invalid {
		if err := ValidateSchemaName(name); err == nil {
			t.Errorf("ValidateSchemaName(%q) = nil, want error", name)
		}
	}
}

func TestClickHouseTableDefaults(t *testing.T) {
	c := &Config{}
	c.applyDefaults()
	if c.ClickHouse.Table != "cloudtrail_events" {
		t.Fatalf("CloudTrail table default = %q, want cloudtrail_events", c.ClickHouse.Table)
	}
	if c.ClickHouse.GenomeTable != "log_events" {
		t.Fatalf("Genome table default = %q, want log_events", c.ClickHouse.GenomeTable)
	}
}

func TestValidateRejectsInvalidGenomeClickHouseTable(t *testing.T) {
	c := &Config{
		Server:   ServerConfig{Host: "0.0.0.0", Port: 8080},
		Database: DatabaseConfig{Host: "postgres", DatabaseName: "nhi_db", User: "user", Password: "pw", Schema: "nhi_global"},
		JWT:      JWTConfig{Secret: "0123456789012345678901234567890123", AccessTTLMinutes: 60, RefreshTTLHours: 168},
		ClickHouse: ClickHouseConfig{
			Host: "clickhouse", Port: 9000, Database: "monitoring", User: "reader",
			Table: "cloudtrail_events", GenomeTable: "bad.table", TimeoutSeconds: 5, Protocol: "native",
		},
	}
	if err := c.validate(); err == nil {
		t.Fatal("validate() = nil with an invalid Genome ClickHouse table name, want error")
	}
}

func TestValidateRequiresDatabasePassword(t *testing.T) {
	c := &Config{
		Server:   ServerConfig{Host: "0.0.0.0", Port: 8080},
		Database: DatabaseConfig{Host: "h", DatabaseName: "nhi_db", User: "u", Schema: "nhi_global"},
		JWT:      JWTConfig{Secret: "0123456789012345678901234567890123", AccessTTLMinutes: 60, RefreshTTLHours: 168},
	}
	if err := c.validate(); err == nil {
		t.Fatal("validate() = nil with empty database password, want error")
	}
	c.Database.Password = "pw"
	if err := c.validate(); err != nil {
		t.Fatalf("validate() = %v, want nil", err)
	}
}
