package export

import (
	"context"
	"fmt"
	"nhi-backend-api/internal/modules/posture/common"
	"nhi-backend-api/internal/modules/posture/identitylist"
	"nhi-backend-api/internal/platform/scope"
)

type PostureExportRepository struct {
	list *identitylist.IdentitiesListRepository
}

func NewPostureExportRepository() *PostureExportRepository {
	return &PostureExportRepository{list: identitylist.NewIdentitiesListRepository()}
}

// Stream implements GET /posture/export. It walks the filtered identities in
// keyset order, ExportChunkSize rows per query, and hands each chunk to
// emit as soon as it is read, so memory stays flat for any fleet size. emit
// returning an error (for example a closed connection) stops the walk.
func (r *PostureExportRepository) Stream(ctx context.Context, s *scope.DataScope, f identitylist.IdentityFilter, emit func([]ExportRow) error) error {
	if err := common.Need(s); err != nil {
		return err
	}
	if f.Sort == "" {
		f.Sort = identitylist.SortScore
	}
	afterID := ""
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		rows, err := r.list.QueryIdentityPage(ctx, s, f, afterID, ExportChunkSize)
		if err != nil {
			return fmt.Errorf("export chunk: %w", err)
		}
		if len(rows) == 0 {
			return nil
		}
		chunk := make([]ExportRow, 0, len(rows))
		for _, row := range rows {
			chunk = append(chunk, toExport(row))
		}
		if err := emit(chunk); err != nil {
			return err
		}
		if len(rows) < ExportChunkSize {
			return nil
		}
		afterID = rows[len(rows)-1].IdentityID
	}
}

func toExport(row identitylist.IdentityRow) ExportRow {
	account := row.AccountName
	if account == "" {
		account = row.AccountID
	}
	e := ExportRow{
		IdentityID:        row.IdentityID,
		Name:              row.Name,
		Type:              row.Type,
		Account:           account,
		Score:             common.NullFloat(row.Score),
		Band:              row.Band,
		Grade:             row.Grade,
		ChecksFailed:      common.IntVal(row.Failed),
		FailedCritical:    common.IntVal(row.Critical),
		FailedHigh:        common.IntVal(row.High),
		FailedMedium:      common.IntVal(row.Medium),
		FailedLow:         common.IntVal(row.Low),
		CredentialAgeDays: common.NullInt(row.CredAgeDays),
		Change:            common.NullFloat(row.Change),
		OpenAlerts:        common.IntVal(row.OpenAlerts),
	}
	if row.Class.Valid {
		e.FunctionalClass = row.Class.String
	}
	if row.WeakestPillar.Valid {
		e.WeakestPillar = row.WeakestPillar.String
	}
	if row.CredType.Valid {
		e.CredentialType = row.CredType.String
	}
	return e
}
