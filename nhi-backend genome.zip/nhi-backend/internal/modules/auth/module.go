// Package auth serves login, token refresh, logout and the "who am I"
// endpoint, and provides the authentication middleware the other modules sit
// behind.
package auth

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/config"
	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/middleware"
)

// Module wires the auth handler and middleware.
type Module struct {
	handler    *AuthHandler
	middleware *middleware.AuthMiddleware
}

// New builds the module on top of the global (non-tenant) database.
func New(db *database.PostgresDB, jwtCfg config.JWTConfig) *Module {
	users := NewUserRepository(db)
	return &Module{
		handler:    NewAuthHandler(NewAuthService(users, jwtCfg)),
		middleware: middleware.NewAuthMiddleware(jwtCfg, users),
	}
}

// Authenticate is the middleware protecting every non-public route.
func (m *Module) Authenticate(next http.Handler) http.Handler {
	return m.middleware.Authenticate(next)
}

// RegisterPublic mounts the unauthenticated routes on the root router, under
// both /api/v1 and the legacy /api/auth prefixes.
func (m *Module) RegisterPublic(r *mux.Router) {
	for _, prefix := range []string{"/api/v1", "/api/auth"} {
		r.HandleFunc(prefix+"/login", m.handler.Login).Methods(http.MethodPost)
		r.HandleFunc(prefix+"/refresh", m.handler.Refresh).Methods(http.MethodPost)
		r.HandleFunc(prefix+"/logout", m.handler.Logout).Methods(http.MethodPost)
	}
}

// Register mounts the authenticated routes on the /api/v1 router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/me", m.handler.Me).Methods(http.MethodGet)
}

// RegisterLegacy mounts the authenticated routes on the legacy /api router,
// where the same endpoint lives at /auth/me.
func (m *Module) RegisterLegacy(r *mux.Router) {
	r.HandleFunc("/auth/me", m.handler.Me).Methods(http.MethodGet)
}
