// Package credentialexposure serves the secret-scanner findings API:
// findings, allowlist, decisions and deep scans. It is tenant-isolated and
// admin-only.
package credentialexposure

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handlers and registers their routes.
type Module struct {
	findings  *FindingsHandler
	allowlist *AllowlistHandler
	decision  *DecisionHandler
	deepScan  *DeepScanHandler
}

// New builds the module. baseURL and dashboardKey configure the scanner
// service used by deep scans.
func New(resolver *scope.Resolver, baseURL, dashboardKey string) *Module {
	return &Module{
		findings:  NewFindingsHandler(NewFindingsService(NewFindingsRepository(), resolver)),
		allowlist: NewAllowlistHandler(NewAllowlistService(NewAllowlistRepository(), resolver)),
		decision:  NewDecisionHandler(NewDecisionService(NewDecisionRepository(), resolver)),
		deepScan:  NewDeepScanHandler(NewDeepScanService(NewDeepScanRepository(), resolver, baseURL, dashboardKey)),
	}
}

// Register mounts the credential-exposure routes on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/credential-exposure/findings", m.findings.List).Methods(http.MethodGet)
	r.HandleFunc("/credential-exposure/findings/flagged", m.findings.ListFlagged).Methods(http.MethodGet)
	r.HandleFunc("/credential-exposure/findings/summary", m.findings.Summary).Methods(http.MethodGet)

	r.HandleFunc("/credential-exposure/allowlist", m.allowlist.List).Methods(http.MethodGet)
	r.HandleFunc("/credential-exposure/allowlist", m.allowlist.Create).Methods(http.MethodPost)
	r.HandleFunc("/credential-exposure/allowlist", m.allowlist.Delete).Methods(http.MethodDelete)

	r.HandleFunc("/credential-exposure/decisions", m.decision.Save).Methods(http.MethodPost)

	r.HandleFunc("/credential-exposure/deep-scan", m.deepScan.Trigger).Methods(http.MethodPost)
	r.HandleFunc("/credential-exposure/deep-scan/status", m.deepScan.Status).Methods(http.MethodGet)
}
