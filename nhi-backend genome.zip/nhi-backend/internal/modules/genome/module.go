// Package genome serves the NHI Genome monitoring API: dashboard
// summary/activity/drift, the identity fleet list and its sub-resources
// (activity, genome, baseline, timeline, peers, drift, containment) and the
// anomaly endpoints, built from the tenant's discovery/baseline/risk/alert
// tables in PostgreSQL and (where noted) the configured Genome ClickHouse
// events table (default log_events).
//
// Unlike the other modules, every endpoint here answers in its own
// documented envelope (common.Envelope: {data, meta} on success,
// {error} on failure, both carrying a request id) and is mounted under
// /api/v1 only — not the legacy /api — because it is a new API, not a
// port of an existing one.
package genome

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/genome/anomalydetail"
	"nhi-backend-api/internal/modules/genome/anomalydisposition"
	"nhi-backend-api/internal/modules/genome/anomalyevidence"
	"nhi-backend-api/internal/modules/genome/anomalyfeedback"
	"nhi-backend-api/internal/modules/genome/anomalylist"
	"nhi-backend-api/internal/modules/genome/common"
	"nhi-backend-api/internal/modules/genome/containmentfreeze"
	"nhi-backend-api/internal/modules/genome/containmentlist"
	"nhi-backend-api/internal/modules/genome/dashboardactivity"
	"nhi-backend-api/internal/modules/genome/dashboarddrift"
	"nhi-backend-api/internal/modules/genome/dashboardsummary"
	"nhi-backend-api/internal/modules/genome/identityactivity"
	"nhi-backend-api/internal/modules/genome/identitybaseline"
	"nhi-backend-api/internal/modules/genome/identitycontainment"
	"nhi-backend-api/internal/modules/genome/identitydrift"
	"nhi-backend-api/internal/modules/genome/identitygenome"
	"nhi-backend-api/internal/modules/genome/identitylist"
	"nhi-backend-api/internal/modules/genome/identitypeers"
	"nhi-backend-api/internal/modules/genome/identitysummary"
	"nhi-backend-api/internal/modules/genome/identitytimeline"
	"nhi-backend-api/internal/platform/scope"
)

// BasePath is where the genome monitoring API is mounted, below /api/v1
// only. /identities and /identities/{id} already belong to the inventory
// API, so this API lives under its own prefix.
const BasePath = "/genome"

// Module wires the package's handlers and registers their routes.
type Module struct {
	dashboardSummary    *dashboardsummary.Handler
	dashboardActivity   *dashboardactivity.Handler
	dashboardDrift      *dashboarddrift.Handler
	identityDrift       *identitydrift.Handler
	identityList        *identitylist.Handler
	identitySummary     *identitysummary.Handler
	identityActivity    *identityactivity.Handler
	identityGenome      *identitygenome.Handler
	identityBaseline    *identitybaseline.Handler
	identityTimeline    *identitytimeline.Handler
	identityPeers       *identitypeers.Handler
	identityContainment *identitycontainment.Handler
	containmentFreeze   *containmentfreeze.Handler
	anomalyList         *anomalylist.Handler
	anomalyDetail       *anomalydetail.Handler
	anomalyEvidence     *anomalyevidence.Handler
	anomalyFeedback     *anomalyfeedback.Handler
	anomalyDisposition  *anomalydisposition.Handler
	containmentList     *containmentlist.Handler
}

// New builds the module. resolver is the shared tenant scope resolver;
// events is the shared Genome ClickHouse reader and may be nil (the
// monitoring ClickHouse is optional — every endpoint then degrades to
// null/empty event-backed fields instead of failing).
func New(resolver *scope.Resolver, events *common.MonitoringEvents) *Module {
	lookup := common.NewMonitoredIdentityLookup(resolver)

	dashboardSummaryRepo := dashboardsummary.NewRepository()
	dashboardActivityRepo := dashboardactivity.NewRepository()
	dashboardDriftRepo := dashboarddrift.NewRepository()
	identityDriftRepo := identitydrift.NewRepository()
	identityListRepo := identitylist.NewRepository()
	identitySummaryRepo := identitysummary.NewRepository()
	identityBaselineRepo := identitybaseline.NewRepository()
	identityTimelineRepo := identitytimeline.NewRepository()
	identityPeersRepo := identitypeers.NewRepository()
	anomalyListRepo := anomalylist.NewRepository()
	anomalyDetailRepo := anomalydetail.NewRepository()
	anomalyEvidenceRepo := anomalyevidence.NewRepository()
	anomalyFeedbackRepo := anomalyfeedback.NewRepository()

	return &Module{
		dashboardSummary:    dashboardsummary.NewHandler(dashboardsummary.NewService(dashboardSummaryRepo, resolver, events, dashboardDriftRepo)),
		dashboardActivity:   dashboardactivity.NewHandler(dashboardactivity.NewService(lookup, dashboardActivityRepo, events)),
		dashboardDrift:      dashboarddrift.NewHandler(dashboarddrift.NewService(dashboardDriftRepo, resolver)),
		identityDrift:       identitydrift.NewHandler(identitydrift.NewService(lookup, identityDriftRepo)),
		identityList:        identitylist.NewHandler(identitylist.NewService(lookup, identityListRepo, events)),
		identitySummary:     identitysummary.NewHandler(identitysummary.NewService(lookup, identitySummaryRepo, events, identityDriftRepo)),
		identityActivity:    identityactivity.NewHandler(identityactivity.NewService(lookup, events)),
		identityGenome:      identitygenome.NewHandler(identitygenome.NewService(lookup, events)),
		identityBaseline:    identitybaseline.NewHandler(identitybaseline.NewService(lookup, identityBaselineRepo, identityDriftRepo)),
		identityTimeline:    identitytimeline.NewHandler(identitytimeline.NewService(lookup, identityTimelineRepo)),
		identityPeers:       identitypeers.NewHandler(identitypeers.NewService(lookup, identityPeersRepo, events)),
		identityContainment: identitycontainment.NewHandler(identitycontainment.NewService(lookup)),
		containmentFreeze:   containmentfreeze.NewHandler(containmentfreeze.NewService(lookup)),
		anomalyList:         anomalylist.NewHandler(anomalylist.NewService(lookup, anomalyListRepo, events)),
		anomalyDetail:       anomalydetail.NewHandler(anomalydetail.NewService(lookup, anomalyDetailRepo, events)),
		anomalyEvidence:     anomalyevidence.NewHandler(anomalyevidence.NewService(lookup, anomalyEvidenceRepo, events)),
		anomalyFeedback:     anomalyfeedback.NewHandler(anomalyfeedback.NewService(anomalyFeedbackRepo, resolver)),
		anomalyDisposition:  anomalydisposition.NewHandler(anomalydisposition.NewService()),
		containmentList:     containmentlist.NewHandler(containmentlist.NewService()),
	}
}

// V1Only reports that this module must not be mounted on the legacy /api
// router (see internal/routes/routes.go) — it is a new API, not a port of
// an existing one.
func (m *Module) V1Only() bool { return true }

// DashboardDriftHandler and IdentityDriftHandler expose the two v3-only
// routes registered centrally by internal/routes/routes.go.
func (m *Module) DashboardDriftHandler() http.HandlerFunc { return m.dashboardDrift.Get }
func (m *Module) IdentityDriftHandler() http.HandlerFunc  { return m.identityDrift.Get }

// Register mounts the endpoints under BasePath. The identity sub-resource
// routes are registered before the plain identity route, so
// /identities/{source_type}/{identity_name}/activity (etc.) is not read as
// the plain route with identity_name="activity". identity_name uses `.+`
// because it may be an ARN (containing ':' and, URL-encoded, '/').
func (m *Module) Register(r *mux.Router) {
	p := r.PathPrefix(BasePath).Subrouter()
	get := func(path string, h http.HandlerFunc) { p.HandleFunc(path, h).Methods(http.MethodGet) }
	post := func(path string, h http.HandlerFunc) { p.HandleFunc(path, h).Methods(http.MethodPost) }

	get("/dashboard/summary", m.dashboardSummary.Get)
	get("/dashboard/activity", m.dashboardActivity.Get)

	get("/identities", m.identityList.Get)
	get("/identities/{source_type}/{identity_name:.+}/activity", m.identityActivity.Get)
	get("/identities/{source_type}/{identity_name:.+}/genome", m.identityGenome.Get)
	get("/identities/{source_type}/{identity_name:.+}/baseline", m.identityBaseline.Get)
	get("/identities/{source_type}/{identity_name:.+}/timeline", m.identityTimeline.Get)
	get("/identities/{source_type}/{identity_name:.+}/peers", m.identityPeers.Get)
	get("/identities/{source_type}/{identity_name:.+}/containment", m.identityContainment.Get)
	post("/identities/{source_type}/{identity_name:.+}/containment/freeze", m.containmentFreeze.Post)
	get("/identities/{source_type}/{identity_name:.+}", m.identitySummary.Get)

	get("/anomalies", m.anomalyList.Get)
	get("/anomalies/{alert_id}", m.anomalyDetail.Get)
	get("/anomalies/{alert_id}/evidence", m.anomalyEvidence.Get)
	post("/anomalies/{alert_id}/feedback", m.anomalyFeedback.Post)
	post("/anomalies/{alert_id}/disposition", m.anomalyDisposition.Post)

	get("/containment", m.containmentList.Get)
}
