package identityactivity

import (
	"context"
	"encoding/base64"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/modules/genome/common"
)

// Service implements
// GET /api/v1/genome/identities/{source_type}/{identity_name}/activity —
// the Activity tab:
//
//   - volume        uniqExact(event_id) per day/hour bucket  (ClickHouse log_events)
//   - recent_calls  newest events of the window, keyset-paged (ClickHouse log_events, FINAL)
//   - total_calls   uniqExact(event_id) over the window        (ClickHouse log_events)
//
// The identity itself is resolved from the tenant's discovery table first
// (unknown → common.ErrIdentityNotFound). Nothing is invented: while the
// monitoring ClickHouse is not configured or cannot be read the lists are
// empty and total_calls is null (logged server-side).
type Service struct {
	lookup *common.MonitoredIdentityLookup
	events *common.MonitoringEvents // nil when no monitoring ClickHouse is configured
}

// NewService wires the service.
func NewService(lookup *common.MonitoredIdentityLookup, events *common.MonitoringEvents) *Service {
	return &Service{lookup: lookup, events: events}
}

// Volume bucket values of the bucket parameter.
const (
	BucketDay  = "day"
	BucketHour = "hour"
)

// Params are the parsed query parameters.
type Params struct {
	Window       common.TimeWindow // from (inclusive) / to (exclusive)
	Bucket       string            // BucketDay | BucketHour
	RecentLimit  int               // recent_limit (page size of recent_calls: default 25, max 100)
	RecentCursor string            // recent_cursor (opaque, from a previous meta.next_cursor); "" for the first page
}

// GetActivity builds the response and the meta.next_cursor of the
// recent-calls page (nil when the page is the last one).
func (s *Service) GetActivity(ctx context.Context, userID, tenantID, dbName, sourceType, identityName string, p Params) (*Response, *string, error) {
	before, err := decodeRecentCursor(p.RecentCursor)
	if err != nil {
		return nil, nil, err
	}
	res, err := s.lookup.Resolve(ctx, userID, tenantID, dbName, sourceType, identityName)
	if err != nil {
		return nil, nil, err
	}
	key := res.Identity.Key

	out := &Response{
		Volume:      []VolumePoint{},
		RecentCalls: []RecentCall{},
	}

	bucket := common.VolumeBucketDay
	if p.Bucket == BucketHour {
		bucket = common.VolumeBucketHour
	}
	if points, err := s.events.Volume(ctx, key.SourceType, key.IdentityName, p.Window.From, p.Window.To, bucket); common.EventsReadOK("identity activity volume", err) {
		for _, pt := range points {
			out.Volume = append(out.Volume, VolumePoint{Bucket: formatVolumeBucket(pt.Bucket, bucket), Calls: pt.Calls})
		}
	}

	var next *string
	if rows, err := s.events.RecentCalls(ctx, key.SourceType, key.IdentityName, p.Window.From, p.Window.To, before, p.RecentLimit+1); common.EventsReadOK("identity recent calls", err) {
		if len(rows) > p.RecentLimit { // one extra row was requested to detect a next page
			rows = rows[:p.RecentLimit]
			last := rows[len(rows)-1]
			next = encodeRecentCursor(common.RecentCallsCursor{EventTime: last.EventTime, EventID: last.EventID})
		}
		for _, r := range rows {
			out.RecentCalls = append(out.RecentCalls, RecentCall{
				EventID:    r.EventID,
				EventTime:  r.EventTime,
				APICall:    common.APIOperation(r.EventSource, r.EventName),
				Resource:   common.FirstResourceARN(r.ResourceARNs),
				SourceIP:   r.SourceIP,
				Region:     r.Region,
				RiskStatus: r.RiskStatus,
				RiskScore:  r.EventRiskScore,
			})
		}
	}

	if total, err := s.events.TotalCalls(ctx, key.SourceType, key.IdentityName, p.Window.From, p.Window.To); common.EventsReadOK("identity total calls", err) {
		out.TotalCalls = &total
	}
	if err := common.BudgetExceeded(ctx, "identity activity"); err != nil {
		return nil, nil, err
	}
	return out, next, nil
}

// formatVolumeBucket renders a bucket the way the API shows it: the date
// for day buckets ("2026-10-01"), the full UTC timestamp for hour buckets.
func formatVolumeBucket(t time.Time, bucket common.VolumeBucket) string {
	if bucket == common.VolumeBucketHour {
		return t.UTC().Format(time.RFC3339)
	}
	return t.UTC().Format("2006-01-02")
}

// ---- opaque keyset cursor of recent_calls -----------------------------------
//
// The cursor is the (event_time, event_id) of the last row of the page,
// encoded as base64url("<unix milliseconds>|<event_id>"). It carries no
// tenant data and is validated on the way back in.

func encodeRecentCursor(c common.RecentCallsCursor) *string {
	s := base64.RawURLEncoding.EncodeToString([]byte(strconv.FormatInt(c.EventTime.UTC().UnixMilli(), 10) + "|" + c.EventID))
	return &s
}

func decodeRecentCursor(s string) (*common.RecentCallsCursor, error) {
	if s == "" {
		return nil, nil
	}
	raw, err := base64.RawURLEncoding.DecodeString(s)
	if err != nil {
		return nil, common.ErrInvalidCursor
	}
	millis, id, ok := strings.Cut(string(raw), "|")
	if !ok || id == "" {
		return nil, common.ErrInvalidCursor
	}
	ms, err := strconv.ParseInt(millis, 10, 64)
	if err != nil {
		return nil, common.ErrInvalidCursor
	}
	return &common.RecentCallsCursor{EventTime: time.UnixMilli(ms).UTC(), EventID: id}, nil
}
