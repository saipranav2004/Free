package identityactivity

import (
	"errors"
	"net/http"
	"strings"
	"time"

	"nhi-backend-api/internal/modules/genome/common"
)

// Handler serves
// GET /api/v1/genome/identities/{source_type}/{identity_name}/activity
// (call volume and recent calls). It only reads the JWT claims, validates
// the request and shapes the response; the data work is in Service.
type Handler struct {
	service *Service
	now     func() time.Time
}

// NewHandler creates the handler.
func NewHandler(service *Service) *Handler {
	return &Handler{service: service, now: func() time.Time { return time.Now().UTC().Truncate(time.Second) }}
}

// Query parameters.
var allowed = map[string]struct{}{"from": {}, "to": {}, "bucket": {}, "recent_limit": {}, "recent_cursor": {}}

// Get handles GET /api/v1/genome/identities/{source_type}/{identity_name}/activity.
func (h *Handler) Get(w http.ResponseWriter, r *http.Request) {
	rid := common.RequestID(r)
	w.Header().Set("X-Request-ID", rid)
	defer common.Recover(w, r, "identity activity", rid)
	ctx, cancel := common.RequestContext(r)
	defer cancel()

	claims, ok := common.RequireClaims(w, r, rid)
	if !ok {
		return
	}
	sourceType, identityName, err := common.IdentityPath(r)
	if err != nil {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, err.Error(), rid)
		return
	}
	q := r.URL.Query()
	if unknown, bad := common.CheckUnknown(q, allowed); bad {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, common.UnknownParamMessage(q, unknown, allowed), rid)
		return
	}
	if err := common.CheckParamLimits(q); err != nil {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, err.Error(), rid)
		return
	}
	window, err := common.ParseIdentityWindow(q, h.now())
	if err != nil {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, err.Error(), rid)
		return
	}
	bucket := strings.ToLower(strings.TrimSpace(q.Get("bucket")))
	switch bucket {
	case "":
		bucket = BucketDay
	case BucketDay, BucketHour:
	default:
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, "bucket must be day or hour", rid)
		return
	}
	limit, err := common.ParseIdentityLimit(q, "recent_limit")
	if err != nil {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, err.Error(), rid)
		return
	}

	data, next, err := h.service.GetActivity(ctx, claims.UserID, claims.TenantID, claims.DBName, sourceType, identityName,
		Params{Window: window, Bucket: bucket, RecentLimit: limit, RecentCursor: strings.TrimSpace(q.Get("recent_cursor"))})
	if errors.Is(err, common.ErrInvalidCursor) {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, "recent_cursor is invalid", rid)
		return
	}
	if err != nil {
		common.WriteServiceError(w, r, "identity activity", rid, err)
		return
	}
	common.WriteJSON(w, http.StatusOK, common.Envelope{
		Data: data,
		Meta: common.Meta{RequestID: rid, GeneratedAt: h.now(), NextCursor: next},
	})
}
