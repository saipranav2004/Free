package dashboardsummary

import (
	"context"
	"sort"
	"strings"

	"nhi-backend-api/internal/modules/genome/common"
	"nhi-backend-api/internal/modules/genome/dashboarddrift"
)

// Service implements GET /api/v1/genome/dashboard/summary on top of the
// caller's tenant schema in PostgreSQL, resolved through scope.Resolver
// like every other data API.
//
// Flow (two steps):
//  1. read the latest non-deleted discovery snapshot per resource from the
//     tenant's identities table inside the caller's account/region scope;
//  2. normalize every row to the monitoring key (source_type, identity_name,
//     workload_key) with the registry rules — never by joining raw
//     discovery columns in SQL;
//  3. look the keys up in baselines / identity_risk_scores / alerts and
//     aggregate the cards and panels.
//
// Nothing is invented: every value is a query result or null. A card whose
// table cannot be read is null (the failure is logged server-side); ClickHouse
// event-backed cards are null when log_events is unavailable, and drift cards
// are null/unavailable when the pipeline has not produced a fleet snapshot.
type Service struct {
	repo      *Repository
	resolver  common.ScopeResolver
	events    *common.MonitoringEvents
	driftRepo *dashboarddrift.Repository
}

// NewService wires the service with the shared tenant scope, event reader,
// and read-only drift snapshot repository.
func NewService(repo *Repository, resolver common.ScopeResolver, events *common.MonitoringEvents, driftRepo *dashboarddrift.Repository) *Service {
	return &Service{repo: repo, resolver: resolver, events: events, driftRepo: driftRepo}
}

// Params are the parsed query parameters.
type Params struct {
	Charts     common.TimeWindow // departures, anomalies_by_day, peer comparison (default: last 14 days)
	Cards      common.TimeWindow // open-anomaly cards (default: last 24 hours)
	SourceType string            // optional upper-case service family, e.g. ECS
	AccountID  string            // optional
	Region     string            // optional
}

const (
	summaryTopN           = 10 // top 10 / most recent 10
	summaryRecentFeedRows = 50 // raw baseline events read before collapsing to 10 identities
)

// GetSummary builds the dashboard summary for the caller's tenant scope.
func (s *Service) GetSummary(ctx context.Context, userID, tenantID, dbName string, p Params) (*Response, error) {
	sc, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, &common.StoreUnavailableError{Op: "resolve tenant scope", Err: err}
	}
	rows, err := common.LatestIdentities(ctx, sc)
	if err != nil {
		return nil, &common.StoreUnavailableError{Op: "read discovery identities", Err: err}
	}

	// ---- step 2: normalize + filter ----------------------------------------
	var ids []common.MonitoredIdentity
	for _, row := range rows {
		id, ok := common.NormalizeDiscoveryRow(row)
		if !ok {
			continue // deferred (EKS), human/resource-only or unknown type
		}
		if p.SourceType != "" && id.Key.SourceType != p.SourceType {
			continue
		}
		if p.AccountID != "" && id.AccountID != p.AccountID {
			continue
		}
		if p.Region != "" && !strings.EqualFold(id.Region, p.Region) {
			continue
		}
		ids = append(ids, id)
	}
	sort.SliceStable(ids, func(i, j int) bool {
		a, b := strings.ToLower(ids[i].DisplayName), strings.ToLower(ids[j].DisplayName)
		if a != b {
			return a < b
		}
		return ids[i].Key.IdentityName < ids[j].Key.IdentityName
	})
	set := common.NewIdentityIndex(ids)
	keys := set.LookupKeys()

	out := &Response{
		DeparturesByDimension:   []DimensionCount{},
		AnomaliesByDay:          []DayCount{},
		MostAnomalousIdentities: []AnomalousIdentity{},
		PeerGroupOutliers:       []PeerOutlier{},
		RecentlyBaselined:       []RecentlyBaselinedIdentity{},
	}
	out.Cards.WindowHours = int(p.Cards.To.Sub(p.Cards.From).Hours())
	out.Cards.IdentitiesWatched = common.IntPtr(len(ids))

	// ---- baseline cards ----------------------------------------------------
	baselines, err := s.repo.BaselineStates(ctx, sc, keys)
	if common.ReadOK("dashboard summary baselines", err) {
		established := 0
		for _, id := range ids {
			if b, ok := baselineFor(baselines, id); ok && b.Status == "active" {
				established++
			}
		}
		out.Cards.BaselinesEstablished = common.IntPtr(established)
		out.Cards.StillLearning = common.IntPtr(len(ids) - established)
		if len(ids) > 0 { // baselines_established / identities_watched * 100
			out.Cards.BaselineCoveragePercent = common.FloatPtr(common.Round1(float64(established) / float64(len(ids)) * 100))
		}
	}

	// ---- open anomalies (cards window) -------------------------------------
	if n, err := s.repo.CountOpenAlerts(ctx, sc, keys, p.Cards.From, p.Cards.To); common.ReadOK("dashboard summary open alerts", err) {
		out.Cards.OpenAnomalies = common.IntPtr(n)
	}
	// Critical anomalies are dimension-level open alert rows whose current
	// event-level risk is explicitly scored Critical in log_events. alerts.score
	// is not severity and is never used for this card.
	if eventIDs, err := s.repo.OpenAlertEventIDs(ctx, sc, keys, p.Cards.From, p.Cards.To); common.ReadOK("dashboard summary open alert event IDs", err) {
		if events, err := s.events.EventsByID(ctx, eventIDs); common.EventsReadOK("dashboard summary critical anomaly events", err) {
			critical := 0
			for _, eventID := range eventIDs {
				if event, ok := events[eventID]; ok && event.RiskStatus == "scored" && strings.EqualFold(event.EventRiskSeverity, "Critical") {
					critical++
				}
			}
			out.Cards.CriticalAnomalies = common.IntPtr(critical)
		}
	}
	if mean, err := s.events.MeanProvenanceConfidence(ctx, keys, sc.AccountIDs, sc.Regions, p.Charts.From, p.Charts.To); common.EventsReadOK("dashboard summary mean provenance confidence", err) {
		out.Cards.MeanProvenanceConfidence = mean
	}

	// Drift is a separate model-health signal, not event risk. Missing tables
	// or snapshots leave the fields null and availability false.
	if s.driftRepo != nil {
		if snapshots, err := s.driftRepo.LatestBySource(ctx, sc); common.ReadOK("dashboard summary drift snapshots", err) {
			applyDriftCards(&out.Cards, snapshots, p.SourceType)
		}
	}

	// ---- most anomalous identities -----------------------------------------
	risk, err := s.repo.LatestRiskScores(ctx, sc, keys)
	riskOK := common.ReadOK("dashboard summary risk scores", err)
	if riskOK {
		type scored struct {
			idx int
			row IdentityRiskRow
		}
		var list []scored
		for i, id := range ids {
			if rr, ok := riskFor(risk, id); ok && rr.RiskScore != nil {
				list = append(list, scored{i, rr})
			}
		}
		sort.SliceStable(list, func(i, j int) bool {
			a, b := list[i], list[j]
			if *a.row.RiskScore != *b.row.RiskScore {
				return *a.row.RiskScore > *b.row.RiskScore
			}
			if a.row.AnomalousEventCount != b.row.AnomalousEventCount {
				return a.row.AnomalousEventCount > b.row.AnomalousEventCount
			}
			return ids[a.idx].DisplayName < ids[b.idx].DisplayName
		})
		for i, item := range list {
			if i >= summaryTopN {
				break
			}
			id := ids[item.idx]
			out.MostAnomalousIdentities = append(out.MostAnomalousIdentities, AnomalousIdentity{
				DashboardIdentityRef: id.Ref(),
				AccountID:            id.AccountID,
				Region:               id.Region,
				ServiceName:          id.ServiceName,
				WorkloadKey:          id.WorkloadKey,
				RiskScore:            item.row.RiskScore,
				Severity:             item.row.Severity,
				ScoreStatus:          item.row.ScoreStatus,
				EventCount:           item.row.EventCount,
				AnomalousEventCount:  item.row.AnomalousEventCount,
				WindowStart:          item.row.WindowStart.UTC(),
				WindowEnd:            item.row.WindowEnd.UTC(),
				ComputedAt:           item.row.ComputedAt.UTC(),
			})
		}
	}

	// ---- peer-group outliers (charts window) --------------------------------
	if riskOK {
		perIdentity, err := s.repo.OpenAlertCountsByIdentity(ctx, sc, keys, p.Charts.From, p.Charts.To)
		if common.ReadOK("dashboard summary alerts by identity", err) {
			anomalies := make([]int, len(ids))
			for i, id := range ids {
				for _, k := range id.AllKeys() {
					anomalies[i] += perIdentity[k]
				}
			}
			out.PeerGroupOutliers = peerGroupOutliers(ids, risk, anomalies)
		}
	}

	// ---- departures by dimension / anomalies per day (charts window) -------
	dims, err := s.repo.OpenAlertsByDimension(ctx, sc, keys, p.Charts.From, p.Charts.To)
	if common.ReadOK("dashboard summary alerts by dimension", err) {
		for _, d := range dims {
			out.DeparturesByDimension = append(out.DeparturesByDimension, DimensionCount{Dimension: d.Dimension, Count: d.Count})
		}
	}
	days, err := s.repo.AlertsByDay(ctx, sc, keys, p.Charts.From, p.Charts.To)
	if common.ReadOK("dashboard summary alerts by day", err) {
		for _, d := range days {
			out.AnomaliesByDay = append(out.AnomaliesByDay, DayCount{Day: d.Day.Format("2006-01-02"), Count: d.Count})
		}
	}

	// ---- recently baselined ------------------------------------------------
	// The most recent 10 identities where the baseline became active or a
	// new version was published — one row per identity, newest event.
	recent, err := s.repo.RecentlyBaselined(ctx, sc, keys, summaryRecentFeedRows)
	if common.ReadOK("dashboard summary recently baselined", err) {
		seen := map[int]struct{}{}
		for _, ev := range recent {
			idx, known := set.IndexOf(ev.Key)
			if !known {
				continue
			}
			if _, dup := seen[idx]; dup {
				continue
			}
			seen[idx] = struct{}{}
			id := ids[idx]
			out.RecentlyBaselined = append(out.RecentlyBaselined, RecentlyBaselinedIdentity{
				DashboardIdentityRef: id.Ref(), AccountID: id.AccountID, Region: id.Region,
				Event: ev.Event, OccurredAt: ev.OccurredAt, Version: ev.Version,
			})
			if len(out.RecentlyBaselined) >= summaryTopN {
				break
			}
		}
	}
	if err := common.BudgetExceeded(ctx, "dashboard summary"); err != nil {
		return nil, err
	}
	return out, nil
}

// applyDriftCards uses one snapshot for an explicit source filter. For an
// unfiltered fleet view, counts are summed only when every enabled family has
// a snapshot for the same window; a partial or mixed-window rollup would be
// misleading. The contract defines no cross-family weighting for confidence
// or fleet risk, so those fields remain null without a source filter.
func applyDriftCards(cards *Cards, snapshots []dashboarddrift.Snapshot, sourceType string) {
	if strings.TrimSpace(sourceType) != "" {
		for _, snapshot := range snapshots {
			if strings.EqualFold(strings.TrimSpace(snapshot.SourceType), strings.TrimSpace(sourceType)) {
				cards.DriftingBaselinesAvailable = true
				applySnapshotCounts(cards, []dashboarddrift.Snapshot{snapshot})
				cards.MeanConfidencePercent = snapshot.MeanConfidence
				cards.MeanModelConfidencePercent = snapshot.MeanConfidence
				cards.FleetRisk = snapshot.FleetRisk
				return
			}
		}
		return
	}

	supported := common.SupportedSourceTypes()
	if len(supported) == 0 || len(snapshots) != len(supported) {
		return
	}
	missing := make(map[string]struct{}, len(supported))
	for _, source := range supported {
		missing[source] = struct{}{}
	}
	windowEnd := snapshots[0].WindowEnd
	for _, snapshot := range snapshots {
		if _, ok := missing[snapshot.SourceType]; !ok || !snapshot.WindowEnd.Equal(windowEnd) {
			return
		}
		delete(missing, snapshot.SourceType)
	}
	if len(missing) != 0 {
		return
	}

	cards.DriftingBaselinesAvailable = true
	applySnapshotCounts(cards, snapshots)
}

func applySnapshotCounts(cards *Cards, snapshots []dashboarddrift.Snapshot) {
	cards.DriftingBaselines = sumSnapshotCounts(snapshots, func(s dashboarddrift.Snapshot) *int { return s.StaleCount })
	cards.DriftMonitoring = sumSnapshotCounts(snapshots, func(s dashboarddrift.Snapshot) *int { return s.MonitorCount })
	cards.DriftHealthy = sumSnapshotCounts(snapshots, func(s dashboarddrift.Snapshot) *int { return s.HealthyCount })
	cards.DriftInsufficientData = sumSnapshotCounts(snapshots, func(s dashboarddrift.Snapshot) *int { return s.InsufficientCount })
}

func sumSnapshotCounts(snapshots []dashboarddrift.Snapshot, value func(dashboarddrift.Snapshot) *int) *int {
	total := 0
	for _, snapshot := range snapshots {
		n := value(snapshot)
		if n == nil {
			return nil
		}
		total += *n
	}
	return &total
}

// baselineFor/riskFor resolve a key's value, preferring the identity key
// then the shared workload key.
func baselineFor(m map[common.MonitoringKey]BaselineStateRow, id common.MonitoredIdentity) (BaselineStateRow, bool) {
	for _, k := range id.AllKeys() {
		if b, ok := m[k]; ok {
			return b, true
		}
	}
	return BaselineStateRow{}, false
}

func riskFor(m map[common.MonitoringKey]IdentityRiskRow, id common.MonitoredIdentity) (IdentityRiskRow, bool) {
	for _, k := range id.AllKeys() {
		if r, ok := m[k]; ok {
			return r, true
		}
	}
	return IdentityRiskRow{}, false
}

// ---------------------------------------------------------------------------
// Peer-group outliers (MVP derived peer key)
// ---------------------------------------------------------------------------

// peerGroupOutliers groups identities by the derived peer key (source_type
// + account_id + region + service_name + cluster_name + role_type) and
// compares each member's recent anomaly count and latest risk score with
// the group means. A member is reported when either value is above its
// peer mean; a group needs at least two members to compare. Rows are
// ordered by how far above the means they are, top 10.
func peerGroupOutliers(ids []common.MonitoredIdentity, risk map[common.MonitoringKey]IdentityRiskRow, anomalies []int) []PeerOutlier {
	groups := map[string][]int{}
	for i, id := range ids {
		groups[id.PeerKey()] = append(groups[id.PeerKey()], i)
	}
	type candidate struct {
		row  PeerOutlier
		dev  float64
		name string
	}
	var cands []candidate
	for pk, members := range groups {
		if len(members) < 2 {
			continue
		}
		riskSum, riskN, anomalySum := 0.0, 0, 0.0
		for _, m := range members {
			if rr, ok := riskFor(risk, ids[m]); ok && rr.RiskScore != nil {
				riskSum += float64(*rr.RiskScore)
				riskN++
			}
			anomalySum += float64(anomalies[m])
		}
		meanAnomalies := anomalySum / float64(len(members))
		var meanRisk *float64
		if riskN > 0 {
			meanRisk = common.FloatPtr(riskSum / float64(riskN))
		}
		for _, m := range members {
			var score *int
			if rr, ok := riskFor(risk, ids[m]); ok {
				score = rr.RiskScore
			}
			riskDev := 0.0
			if score != nil && meanRisk != nil {
				riskDev = float64(*score) - *meanRisk
			}
			anomalyDev := float64(anomalies[m]) - meanAnomalies
			if riskDev <= 0 && anomalyDev <= 0 {
				continue
			}
			row := PeerOutlier{
				DashboardIdentityRef: ids[m].Ref(), PeerKey: pk, PeerCount: len(members),
				RiskScore: score, AnomalyCount: anomalies[m], PeerMeanAnomalyCount: common.Round1(meanAnomalies),
			}
			if meanRisk != nil {
				row.PeerMeanRiskScore = common.FloatPtr(common.Round1(*meanRisk))
			}
			cands = append(cands, candidate{row: row, dev: riskDev + anomalyDev, name: ids[m].DisplayName})
		}
	}
	sort.SliceStable(cands, func(i, j int) bool {
		if cands[i].dev != cands[j].dev {
			return cands[i].dev > cands[j].dev
		}
		return cands[i].name < cands[j].name
	})
	out := make([]PeerOutlier, 0, summaryTopN)
	for i, c := range cands {
		if i >= summaryTopN {
			break
		}
		out = append(out, c.row)
	}
	return out
}
