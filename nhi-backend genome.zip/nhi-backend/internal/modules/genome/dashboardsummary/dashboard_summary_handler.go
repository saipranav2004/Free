package dashboardsummary

import (
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"nhi-backend-api/internal/modules/genome/common"
)

// Handler serves GET /api/v1/genome/dashboard/summary. Like the other
// genome handlers it only reads the JWT claims, validates the query and
// shapes the response; the data work is in Service.
type Handler struct {
	service *Service
	now     func() time.Time
}

// NewHandler creates the handler.
func NewHandler(service *Service) *Handler {
	return &Handler{service: service, now: func() time.Time { return time.Now().UTC().Truncate(time.Second) }}
}

// Query parameters (nothing else is accepted).
var allowed = map[string]struct{}{
	"from": {}, "to": {}, "source_type": {}, "account_id": {}, "region": {},
}

// Defaults when from/to are omitted: 14 days for charts/panels, 24 hours
// for the open-anomaly cards.
const (
	defaultCharts = 14 * 24 * time.Hour
	defaultCards  = 24 * time.Hour
)

// Get handles GET /api/v1/genome/dashboard/summary.
func (h *Handler) Get(w http.ResponseWriter, r *http.Request) {
	rid := common.RequestID(r)
	w.Header().Set("X-Request-ID", rid)
	defer common.Recover(w, r, "dashboard summary", rid)
	ctx, cancel := common.RequestContext(r)
	defer cancel()

	claims, ok := common.RequireClaims(w, r, rid)
	if !ok {
		return
	}
	q := r.URL.Query()
	if unknown, bad := common.CheckUnknown(q, allowed); bad {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, common.UnknownParamMessage(q, unknown, allowed), rid)
		return
	}
	if err := common.CheckParamLimits(q); err != nil {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, err.Error(), rid)
		return
	}
	charts, cards, err := parseWindows(q, h.now())
	if err != nil {
		common.WriteError(w, http.StatusBadRequest, common.CodeValidation, err.Error(), rid)
		return
	}

	data, err := h.service.GetSummary(ctx, claims.UserID, claims.TenantID, claims.DBName, Params{
		Charts:     charts,
		Cards:      cards,
		SourceType: strings.ToUpper(strings.TrimSpace(q.Get("source_type"))),
		AccountID:  strings.TrimSpace(q.Get("account_id")),
		Region:     strings.TrimSpace(q.Get("region")),
	})
	if err != nil {
		common.WriteServiceError(w, r, "dashboard summary", rid, err)
		return
	}
	common.WriteJSON(w, http.StatusOK, common.Envelope{
		Data: data,
		Meta: common.Meta{RequestID: rid, GeneratedAt: h.now()},
	})
}

// parseWindows applies: with from/to (inclusive/exclusive ISO-8601) both the
// charts and the cards use that window; when both are omitted the charts
// cover the last 14 days and the cards the last 24 hours.
func parseWindows(q url.Values, now time.Time) (charts, cards common.TimeWindow, err error) {
	fromS, toS := strings.TrimSpace(q.Get("from")), strings.TrimSpace(q.Get("to"))
	if fromS == "" && toS == "" {
		charts = common.TimeWindow{From: now.Add(-defaultCharts), To: now}
		cards = common.TimeWindow{From: now.Add(-defaultCards), To: now}
		return charts, cards, nil
	}
	win := common.TimeWindow{To: now}
	if toS != "" {
		if win.To, err = common.ParseTime(toS); err != nil {
			return charts, cards, fmt.Errorf("to: %w", err)
		}
	}
	win.From = win.To.Add(-defaultCharts)
	if fromS != "" {
		if win.From, err = common.ParseTime(fromS); err != nil {
			return charts, cards, fmt.Errorf("from: %w", err)
		}
	}
	if !win.From.Before(win.To) {
		return charts, cards, fmt.Errorf("from must be before to")
	}
	return win, win, nil
}
