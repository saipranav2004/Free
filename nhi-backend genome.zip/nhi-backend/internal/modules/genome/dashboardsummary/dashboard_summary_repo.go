package dashboardsummary

import (
	"context"
	"database/sql"
	"time"

	"nhi-backend-api/internal/modules/genome/common"
	"nhi-backend-api/internal/platform/scope"
)

// Repository reads what the dashboard summary needs from the caller's
// tenant schema: baselines + baseline_versions, identity_risk_scores and
// alerts. The discovery identities themselves come from common.LatestIdentities.
// Every method takes the resolved *scope.DataScope: the pool and the
// schema-qualified table names come from it (resolved.Table), never from
// configuration or constants. Monitoring tables are keyed by the normalized
// (source_type, identity_name) pair, computed by the service. Nothing is
// written.
type Repository struct{}

// NewRepository creates the repository.
func NewRepository() *Repository { return &Repository{} }

// ---------------------------------------------------------------------------
// baselines / baseline_versions
// ---------------------------------------------------------------------------

// BaselineStateRow is the baseline state of one key.
type BaselineStateRow struct {
	Key           common.MonitoringKey
	Status        string // active | inactive
	DaysRemaining int
	ActiveSince   *time.Time
}

// BaselineStates loads the baseline state for every key that has one.
func (r *Repository) BaselineStates(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey) (map[common.MonitoringKey]BaselineStateRow, error) {
	out := map[common.MonitoringKey]BaselineStateRow{}
	if len(keys) == 0 {
		return out, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT b.source_type, b.identity_name, b.status, b.days_remaining, b.active_since
	      FROM ` + resolved.Table("baselines") + ` b` + common.KeyJoin("b")
	rows, err := resolved.DB.QueryContext(ctx, q, types, names)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "baselines", err)
	}
	defer rows.Close()
	for rows.Next() {
		var row BaselineStateRow
		var active sql.NullTime
		if err := rows.Scan(&row.Key.SourceType, &row.Key.IdentityName, &row.Status, &row.DaysRemaining, &active); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "baselines", err)
		}
		if active.Valid {
			t := active.Time.UTC()
			row.ActiveSince = &t
		}
		out[row.Key] = row
	}
	return out, common.WrapMonitoringErr(ctx, "baselines", rows.Err())
}

// BaselineEventRow is one row of the recently-baselined feed.
type BaselineEventRow struct {
	Key        common.MonitoringKey
	Event      string // baseline_established | baseline_version_published
	OccurredAt time.Time
	Version    *int64
}

// RecentlyBaselined merges baselines.active_since and
// baseline_versions.published_at, newest first.
func (r *Repository) RecentlyBaselined(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey, limit int) ([]BaselineEventRow, error) {
	if len(keys) == 0 {
		return nil, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT * FROM (
	        SELECT b.source_type, b.identity_name, 'baseline_established' AS event, b.active_since AS occurred_at, NULL::bigint AS version
	        FROM ` + resolved.Table("baselines") + ` b` + common.KeyJoin("b") + ` WHERE b.active_since IS NOT NULL
	        UNION ALL
	        SELECT v.source_type, v.identity_name, 'baseline_version_published', v.published_at, v.version
	        FROM ` + resolved.Table("baseline_versions") + ` v` + common.KeyJoin("v") + `
	      ) e ORDER BY occurred_at DESC LIMIT $3`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names, limit)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "recently baselined", err)
	}
	defer rows.Close()
	var out []BaselineEventRow
	for rows.Next() {
		var row BaselineEventRow
		var v sql.NullInt64
		if err := rows.Scan(&row.Key.SourceType, &row.Key.IdentityName, &row.Event, &row.OccurredAt, &v); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "recently baselined", err)
		}
		row.OccurredAt = row.OccurredAt.UTC()
		if v.Valid {
			n := v.Int64
			row.Version = &n
		}
		out = append(out, row)
	}
	return out, common.WrapMonitoringErr(ctx, "recently baselined", rows.Err())
}

// ---------------------------------------------------------------------------
// identity_risk_scores
// ---------------------------------------------------------------------------

// IdentityRiskRow is the latest identity_risk_scores row for one key.
type IdentityRiskRow struct {
	Key                 common.MonitoringKey
	RiskScore           *int // NULL until the pipeline scores the identity
	Severity            string
	ScoreStatus         string
	EventCount          int
	AnomalousEventCount int
	WindowStart         time.Time
	WindowEnd           time.Time
	ComputedAt          time.Time
}

// LatestRiskScores returns the newest completed risk snapshot per key.
func (r *Repository) LatestRiskScores(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey) (map[common.MonitoringKey]IdentityRiskRow, error) {
	out := map[common.MonitoringKey]IdentityRiskRow{}
	if len(keys) == 0 {
		return out, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT DISTINCT ON (s.source_type, s.identity_name)
	             s.source_type, s.identity_name, s.risk_score, s.severity, s.score_status,
	             s.event_count, s.anomalous_event_count, s.window_start, s.window_end, s.computed_at
	      FROM ` + resolved.Table("identity_risk_scores") + ` s` + common.KeyJoin("s") + `
	      WHERE s.window_end <= now()
	      ORDER BY s.source_type, s.identity_name, s.window_end DESC, s.computed_at DESC`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "identity risk scores", err)
	}
	defer rows.Close()
	for rows.Next() {
		var row IdentityRiskRow
		var score sql.NullInt64
		if err := rows.Scan(&row.Key.SourceType, &row.Key.IdentityName, &score, &row.Severity, &row.ScoreStatus,
			&row.EventCount, &row.AnomalousEventCount, &row.WindowStart, &row.WindowEnd, &row.ComputedAt); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "identity risk scores", err)
		}
		if score.Valid {
			n := int(score.Int64)
			row.RiskScore = &n
		}
		out[row.Key] = row
	}
	return out, common.WrapMonitoringErr(ctx, "identity risk scores", rows.Err())
}

// ---------------------------------------------------------------------------
// alerts
// ---------------------------------------------------------------------------

// CountOpenAlerts is cards.open_anomalies: COUNT(*) from alerts where
// status = 'open' and created_at is in [from, to), for the keys.
func (r *Repository) CountOpenAlerts(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey, from, to time.Time) (int, error) {
	if len(keys) == 0 {
		return 0, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT COUNT(*) FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      WHERE a.status = 'open' AND a.created_at >= $3 AND a.created_at < $4`
	var n int
	if err := resolved.DB.QueryRowContext(ctx, q, types, names, from, to).Scan(&n); err != nil {
		return 0, common.WrapMonitoringErr(ctx, "count open alerts", err)
	}
	return n, nil
}

// OpenAlertEventIDs returns the event_id for every open alert in the selected
// detection window. Duplicate event IDs are preserved because alerts are
// dimension-level rows and critical_anomalies counts alert rows.
func (r *Repository) OpenAlertEventIDs(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey, from, to time.Time) ([]string, error) {
	if len(keys) == 0 {
		return []string{}, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT a.event_id FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      WHERE a.status = 'open' AND a.created_at >= $3 AND a.created_at < $4
	        AND a.event_id IS NOT NULL`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names, from, to)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "open alert event IDs", err)
	}
	defer rows.Close()
	out := make([]string, 0)
	for rows.Next() {
		var eventID sql.NullString
		if err := rows.Scan(&eventID); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "open alert event IDs", err)
		}
		if eventID.Valid && eventID.String != "" {
			out = append(out, eventID.String)
		}
	}
	return out, common.WrapMonitoringErr(ctx, "open alert event IDs", rows.Err())
}

// OpenAlertCountsByIdentity counts open alerts created in [from, to) per
// key (the "recent anomaly count" compared inside peer groups).
func (r *Repository) OpenAlertCountsByIdentity(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey, from, to time.Time) (map[common.MonitoringKey]int, error) {
	out := map[common.MonitoringKey]int{}
	if len(keys) == 0 {
		return out, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT a.source_type, a.identity_name, COUNT(*) FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      WHERE a.status = 'open' AND a.created_at >= $3 AND a.created_at < $4
	      GROUP BY a.source_type, a.identity_name`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names, from, to)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "open alerts by identity", err)
	}
	defer rows.Close()
	for rows.Next() {
		var k common.MonitoringKey
		var n int
		if err := rows.Scan(&k.SourceType, &k.IdentityName, &n); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "open alerts by identity", err)
		}
		out[k] = n
	}
	return out, common.WrapMonitoringErr(ctx, "open alerts by identity", rows.Err())
}

// DimensionCountRow is one GROUP BY dimension row.
type DimensionCountRow struct {
	Dimension string
	Count     int
}

// OpenAlertsByDimension counts open alerts per stored alerts.dimension in
// [from, to) — restricted to the keys.
func (r *Repository) OpenAlertsByDimension(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey, from, to time.Time) ([]DimensionCountRow, error) {
	if len(keys) == 0 {
		return nil, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT a.dimension, COUNT(*) FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      WHERE a.status = 'open' AND a.created_at >= $3 AND a.created_at < $4
	      GROUP BY a.dimension ORDER BY COUNT(*) DESC, a.dimension`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names, from, to)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "open alerts by dimension", err)
	}
	defer rows.Close()
	var out []DimensionCountRow
	for rows.Next() {
		var row DimensionCountRow
		if err := rows.Scan(&row.Dimension, &row.Count); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "open alerts by dimension", err)
		}
		out = append(out, row)
	}
	return out, common.WrapMonitoringErr(ctx, "open alerts by dimension", rows.Err())
}

// DayCountRow is one alerts-per-UTC-day row.
type DayCountRow struct {
	Day   time.Time
	Count int
}

// AlertsByDay counts alerts (all statuses) created per UTC day in [from, to).
func (r *Repository) AlertsByDay(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey, from, to time.Time) ([]DayCountRow, error) {
	if len(keys) == 0 {
		return nil, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT date_trunc('day', a.created_at AT TIME ZONE 'UTC') AS day, COUNT(*)
	      FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      WHERE a.created_at >= $3 AND a.created_at < $4
	      GROUP BY 1 ORDER BY 1`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names, from, to)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "alerts by day", err)
	}
	defer rows.Close()
	var out []DayCountRow
	for rows.Next() {
		var row DayCountRow
		if err := rows.Scan(&row.Day, &row.Count); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "alerts by day", err)
		}
		row.Day = time.Date(row.Day.Year(), row.Day.Month(), row.Day.Day(), 0, 0, 0, 0, time.UTC)
		out = append(out, row)
	}
	return out, common.WrapMonitoringErr(ctx, "alerts by day", rows.Err())
}
