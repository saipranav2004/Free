// Package identitytimeline serves
// GET /api/v1/genome/identities/{source_type}/{identity_name}/timeline: the
// lifecycle timeline derived from the current tables (there is no immutable
// event-history table — SCHEMA GAP): alerts, baseline_versions and
// baselines.
package identitytimeline

import "time"

// Item types (API constants chosen by source table).
const (
	TypeAnomaly                  = "anomaly"                    // alerts.created_at
	TypeBaselineVersionPublished = "baseline_version_published" // baseline_versions.published_at
	TypeLearningStarted          = "learning_started"           // baselines.first_seen_date
	TypeBaselineEstablished      = "baseline_established"       // baselines.active_since
)

// Response is the data block.
type Response struct {
	Items []Item `json:"items"`
}

// Item is one entry, newest first. Description is omitted for the
// milestone types that carry none; status is only present on anomaly
// items (the stored alerts.status).
type Item struct {
	Type        string    `json:"type"`
	Title       string    `json:"title"`
	Description *string   `json:"description,omitempty"`
	OccurredAt  time.Time `json:"occurred_at"`
	Status      *string   `json:"status,omitempty"`
}
