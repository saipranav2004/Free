package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

type DashboardOverviewService struct {
	repo     *DashboardOverviewRepository
	resolver *scope.Resolver
	activity *identitygraph.ActivityService
}

func NewDashboardOverviewService(repo *DashboardOverviewRepository, resolver *scope.Resolver, activity *identitygraph.ActivityService) *DashboardOverviewService {
	return &DashboardOverviewService{repo: repo, resolver: resolver, activity: activity}
}

func (s *DashboardOverviewService) GetOverview(ctx context.Context, userID, tenantID, dbName string) (*DashboardOverviewResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	result, err := s.repo.GetOverview(ctx, resolved, s.activity.ForRequest(resolved))
	if err != nil {
		return nil, fmt.Errorf("get tenant-scoped dashboard: %w", err)
	}
	return result, nil
}
