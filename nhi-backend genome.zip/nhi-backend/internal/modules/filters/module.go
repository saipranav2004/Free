// Package filters serves the filter options (accounts, regions, types,
// classes, environments, statuses) used by the dashboard UI.
package filters

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handler and registers its route.
type Module struct {
	handler *FilterHandler
}

// New builds the module.
func New(resolver *scope.Resolver) *Module {
	return &Module{handler: NewFilterHandler(NewFilterService(NewFilterRepository(), resolver))}
}

// Register mounts the filters route on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/filters", m.handler.GetFilters).Methods(http.MethodGet)
}
