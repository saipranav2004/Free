// Package permissionsource answers "which policy granted this event" for one
// credential.
package permissionsource

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handler and registers its route.
type Module struct {
	handler *PermissionSourceHandler
}

// New builds the module.
func New(resolver *scope.Resolver) *Module {
	return &Module{handler: NewPermissionSourceHandler(NewPermissionSourceService(NewPermissionSourceRepository(), resolver))}
}

// Register mounts the permission-source route on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/permission-source", m.handler.Get).Methods(http.MethodGet)
}
