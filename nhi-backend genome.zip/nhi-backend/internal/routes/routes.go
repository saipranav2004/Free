package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/auth"
	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/middleware"
)

// Module is a self-contained feature that registers its own routes on an
// authenticated router (paths are relative to /api/v1 or the legacy /api).
type Module interface {
	Register(r *mux.Router)
}

// V1OnlyModule is a Module that must not be mounted on the legacy /api
// router — only on /api/v1. New modules (not a port of an existing /api
// surface) implement this so they don't grow the legacy contract.
type V1OnlyModule interface {
	Module
	V1Only() bool
}

// GenomeV3DriftHandlers exposes the two v3 drift handlers so their literal
// route paths remain centralized in this file.
type GenomeV3DriftHandlers interface {
	DashboardDriftHandler() http.HandlerFunc
	IdentityDriftHandler() http.HandlerFunc
}

type HandlerContainer struct {
	Auth *auth.Module

	// Modules are mounted on both the /api/v1 and legacy /api routers.
	Modules []Module
}

func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()
	r.Use(middleware.RequestLogger)
	r.Use(middleware.Recoverer)

	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if middleware.IsPosturePath(req.URL.Path) {
			middleware.WritePostureError(w, http.StatusNotFound, "not_found", "route not found")
			return
		}
		httpx.WriteJSON(w, http.StatusNotFound, map[string]any{
			"success": false,
			"message": "route not found: " + req.Method + " " + req.URL.Path,
		})
	})
	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if middleware.IsPosturePath(req.URL.Path) {
			middleware.WritePostureError(w, http.StatusMethodNotAllowed, "method_not_allowed", "method not allowed")
			return
		}
		httpx.WriteJSON(w, http.StatusMethodNotAllowed, map[string]any{
			"success": false,
			"message": "method not allowed: " + req.Method + " " + req.URL.Path,
		})
	})

	r.HandleFunc("/health", func(w http.ResponseWriter, req *http.Request) {
		httpx.WriteJSON(w, http.StatusOK, map[string]string{"status": "healthy", "service": "nhi-backend-api"})
	}).Methods(http.MethodGet)

	if h.Auth == nil {
		return r
	}
	h.Auth.RegisterPublic(r)

	v1 := r.PathPrefix("/api/v1").Subrouter()
	v1.Use(h.Auth.Authenticate)
	protected := r.PathPrefix("/api").Subrouter()
	protected.Use(h.Auth.Authenticate)
	h.Auth.Register(v1)
	// The new v3 drift routes are registered here (not in genome.Module) so
	// route literals remain in the central route table. Register them before
	// the module subrouters and identity catch-all routes.
	for _, m := range h.Modules {
		if drift, ok := m.(GenomeV3DriftHandlers); ok {
			v1.HandleFunc("/genome/dashboard/drift", drift.DashboardDriftHandler()).Methods(http.MethodGet)
			v1.HandleFunc("/genome/identities/{source_type}/{identity_name:.+}/drift", drift.IdentityDriftHandler()).Methods(http.MethodGet)
		}
	}
	for _, m := range h.Modules {
		m.Register(v1)
	}
	h.Auth.RegisterLegacy(protected)
	for _, m := range h.Modules {
		if v1only, ok := m.(V1OnlyModule); ok && v1only.V1Only() {
			continue
		}
		m.Register(protected)
	}
	return r
}
