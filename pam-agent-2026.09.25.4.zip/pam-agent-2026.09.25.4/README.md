# pam-agent 2026.09.25.4 — Oracle SQL Developer now logs in automatically

Replace your `backend_upd/agents/` folder with the one in this zip, restart `pam-api`, and re-install the agent from the console (Settings → Devices). No backend or console code changed. This build also keeps every earlier fix, including the Windows pgAdmin one from `2026.09.25.3`.

Check the files: `cd backend_upd/agents && sha256sum -c SHA256SUMS.txt`

---

## 1. Credentials for Qdrant and Metabase (Resource → Credentials tab)

| Resource | Credential type | Account name | Secret |
|---|---|---|---|
| **Qdrant** | **API key** | leave **empty** (optional for this type) | the value of Qdrant's `service.api_key` (or `QDRANT__SERVICE__API_KEY`); a read-only key works too |
| **Metabase** | **Password** | the Metabase **login email** (e.g. `admin@yourcompany.com`) | that user's Metabase password |

How PAM uses them:
- **Qdrant:** PAM adds the key as the `api-key` header on every request. The dashboard opens already authorised, and the key never reaches the browser. Set the resource's console URL to `http://<host>:6333`; PAM opens `/dashboard` itself.
- **Metabase:** PAM signs in server-side with `POST /api/session` using the email and password, and hands the browser only the session. Metabase API keys can't be used for this, because they only work for Metabase's API, not its web UI. Use a real Metabase user; a dedicated "pam-operator" user is best.

In my tests I used throwaway values. For Qdrant: type API key, no account name, secret = the key Qdrant was started with. For Metabase: type password, account `pam-operator@deepalgorithms.test`, secret = that user's password.

---

## 2. Oracle SQL Developer: how the automatic login works

SQL Developer has no command-line option or hook for being handed a password. What it does have is its own saved-connection file: connections created with **"Save Password"** ticked are stored in

- Windows: `%APPDATA%\SQL Developer\system<version>\o.jdeveloper.db.connection\connections.json`
- macOS/Linux: `~/.sqldeveloper/system<version>/o.jdeveloper.db.connection/connections.json`

The password is stored encrypted, with a key made from a random ID that each SQL Developer install creates for itself (`db.system.id`). The agent now writes PAM's connection into that file exactly as SQL Developer's own "Save Password" does. The operator double-clicks **"PAM - <host> (<user>)"** and is connected. When SQL Developer is closed, the agent removes that entry again.

How the format was established:
- Public research ([maaaaz/sqldeveloperpassworddecryptor](https://github.com/maaaaz/sqldeveloperpassworddecryptor) and others) documents the key derivation and the 19.2–23.x format: PBKDF2-HMAC-SHA256 over `db.system.id`, a fixed salt, 5000 rounds, then AES-CBC.
- A real SQL Developer 24.3.1 turned out to store something different. I read its own code (`ReferenceWorker$AESGCMWorker` in `sqldeveloper/lib/dbtools-common.jar`) and found 24.x uses AES-256-GCM, a 12-byte nonce, and AAD `"password"`.
- I confirmed this by decrypting a password SQL Developer 24.3.1 had saved itself; that exact value is now a unit test.
- The agent checks the installed SQL Developer's own jar and writes whichever format that version uses: GCM for 24.x, CBC for older versions.

### Tested against real software, through real console clicks

- Oracle Database 23ai Free and SQL Developer 24.3.1, with the operator's `connections.json` emptied first, so no saved password existed anywhere except what PAM wrote.
- Console → Connect → **Open in Desktop** → SQL Developer opened with **PAM - 127.0.0.1 (pam_ora_test)** → click → **connected with no password dialog** (`proof/03`).
- Oracle `v$session` showed `PAM_ORA_TEST`, program "SQL Developer". A query ran as `PAM_ORA_TEST` on `freepdb1` (`proof/04`).
- Closing SQL Developer ended the session, the 3 m 45 s recording uploaded and plays in Audit → Recordings (`proof/05`), and **PAM's entry was removed** from `connections.json`.
- With SQL Developer already open, PAM's launch opens a second copy (SQL Developer allows that), which connects normally. Closing either copy left no PAM entry behind.
- The operator's own connections are never changed. If `connections.json` can't be read, PAM leaves it alone and falls back to the clipboard.
- Every launch also clears any PAM entry left over by an earlier session, for example if the agent was killed.
- The same release binary was re-tested against pgAdmin afterwards: it still connects with no prompt.

### What operators need to know

- **Open and close SQL Developer once** on a new machine before the first PAM launch. It creates its encryption ID on first close. Until then PAM can't save a password it could read, so it puts the password on the clipboard and says why, instead of failing silently.
- The Oracle resource needs its **service name** in *Database name* (e.g. `FREEPDB1`, `ORCLPDB1`). For a SID-only listener, set `extra_config.sid` instead.
- The agent finds SQL Developer in the usual unzip locations, including Windows "Extract All" folders under Downloads/Desktop (`…\sqldeveloper-<ver>-x64\sqldeveloper\sqldeveloper.exe`) and `C:\app\…\product\…\sqldeveloper`. For anywhere else: `pam-agent locate --tool sqldeveloper`.

### Honest limits

- Live-tested on Linux with SQL Developer 24.3.1. Windows and macOS use the same file format in the per-user folders listed above; the path logic for them is unit-tested but hasn't been run live.
- While the session is open, the password sits in `connections.json`, encrypted the same way the operator's own saved passwords are. It's removed when SQL Developer closes. If the machine loses power mid-session, the next PAM launch clears it.
