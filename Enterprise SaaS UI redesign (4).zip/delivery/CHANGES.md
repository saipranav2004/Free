# PAM Console — Round 11

**12 files.** Drop-in replacements; `src/…` here maps to `src/…` in your project. No new dependencies, no route changes, no API contract changes.

---

## ⚠️ Two backend bugs found while reading `updated_pam_ref 1.txt`

Both are real and both need a server fix. The frontend now behaves correctly around them, but it cannot fix them.

### 1. `SetupMFAInitiate` deletes ACTIVE devices, not just PENDING ones

`internal/services/auth_service.go`:

```go
// Delete any existing PENDING device, then create a new one.
s.db.Unscoped().Where("user_id = ?", userID).Delete(&models.PAMMFA{})
```

**The comment says PENDING. The query has no status filter.** So `POST /auth/mfa/setup/initiate` hard-deletes whatever device the account has — `ACTIVE` included — and replaces it with a fresh `PENDING` row.

`Login` only issues a challenge when `mfa.Status == "ACTIVE"`, so **from the instant that endpoint returns, the account has no second factor**, whether or not the user ever confirms a code.

**This is your MFA status bug.** A user clicks "Manage MFA — replace authenticator", gets distracted, closes the tab — MFA is now genuinely off, sign-in stops challenging, and the console (reading last-login evidence that still says "challenged") keeps showing "MFA enabled". Whichever way you look at it, one of the two is lying.

**Suggested server fix:**
```go
s.db.Unscoped().Where("user_id = ? AND status = ?", userID, "PENDING").Delete(&models.PAMMFA{})
```
…plus a genuine `DELETE /auth/mfa` for disabling. Until then the frontend treats a successful `initiate` as "this account is now unprotected", which is the truth.

### 2. There is no MFA disable endpoint at all

Full MFA route list in `router.go`:

```
POST /auth/login
POST /auth/mfa/verify
POST /auth/mfa/setup/initiate
POST /auth/mfa/setup/verify
```

No disable, no reset, and nothing under `/admin/identity/users/:id` either. See below for what the console does about it.

### 3. `GET /auth/me` does not report enrolment

```go
response.Success(c, gin.H{
    "user_id": userID, "username": username, "email": email,
    "mfa_verified": mfa, "roles": roles,
}, "Identity retrieved")
```

No `mfa_enabled`, no device list, no `activated_at` — even though `models.PAMMFA` has `Status` and `ActivatedAt` sitting right there. **And `mfa_verified` is not a substitute**, because `Login` issues the same verified flag to accounts with no MFA:

```go
// No MFA → issue tokens directly.
return s.issueTokensForUser(user, true, clientIP)
```

Using it as an enrolment signal would tell an operator they are protected when they are not. Adding `mfa_enabled` + `mfa_enabled_at` to `Me()` is a five-line change and would let the console delete its entire evidence fallback — `readMfaStatus` already prefers a real API field the moment one appears.

---

## Task 1 — MFA in Settings

### Status detection

Unchanged in its logic, because it was already right: enrolment comes from the strongest available evidence — an API field if one ever exists, then a device list, then the login-flow fact (`challenge_token` issued ⇒ a device exists; full session issued ⇒ it doesn't). `mfa_verified` is deliberately excluded, for the reason above.

What's **new** is that the console now records the third fact it was missing: **starting enrolment removes the old device**, so status flips to "not enabled" the moment that happens instead of staying stale until the next sign-in. That's the actual fix to "the status is wrong".

### Disable MFA now works

It was a permanently-disabled button reading "Turning MFA off is not self-service". There's no `DELETE` endpoint — but there *is* a supported path that does exactly what disabling means, and it's the deletion in bug #1: call `setup/initiate` and don't complete it. The `ACTIVE` device is destroyed, the replacement stays `PENDING`, and login stops challenging.

So the button is live, behind a typed-`DISABLE` confirmation that spells out all four consequences (device gone, no more sign-in codes, privileged actions start refusing once the session ends, backup codes dead). This is genuinely how Okta and Entra gate a self-service factor removal — visible, explained, and friction-gated, not hidden.

### "Replace authenticator" now warns first

This was the dangerous one. The old button fired the destructive request immediately, with no warning, and the confirmation step came *after* the damage. It now asks first, in the words of what actually happens: *"Your current authenticator stops working immediately — before you scan the new one."* And the enrolment screen itself carries an amber "Unprotected until confirmed" state, so someone mid-flow can see what leaving costs. "Cancel" became "Finish later", because that's what it does.

### The 6-digit code input

Already strict, and verified: `OtpInput` clamps to exactly six, strips non-digits on type and on paste, and exports `isCompleteOtp` — the same `^\d{6}$` test that gates the submit button. There is no path to submit a code of another length. Left as-is.

### Enterprise polish

Method / Enabled / Confirmed-by / This-session as a proper detail list, status chip in the header, and the enabled date shown when it can be known (it can't be, from this API — the row says so honestly rather than inventing one).

---

## Task 2 — Administration shortcuts on the Dashboard

A nav-tile grid was removed from this page two rounds ago, so bringing one back needed a reason. The old one was four hero cards linking to Identity / Roles / Policies / Audit sitting directly under a sidebar containing Identity, Roles, Policies and Audit — same destinations, same words, twice the height, no extra information.

**The difference is that this one leads with the action, not the page.** Each row's hover `+` goes straight to the create form — make a user, define a role, write a policy — which is the verb an administrator arrives wanting. The sidebar can only ever take you to a list. That's exactly the split AWS draws between its service nav and the console home's task shortcuts, and what Salesforce Setup's shortcut rail and Google Cloud's "Quick access" do.

To make those `+` links real rather than decorative, `?new=1` is now wired into **Identity, Roles and Policies** — it opens the create modal and strips the param immediately, so a reload or a back-navigation doesn't reopen a dialog you already dismissed.

**Deliberately no counts.** They'd make the row read like an instrument, and `GET /admin/stats` returns only `pending_approvals`, `active_sessions`, `active_grants`, `active_breakglass_grants`, `active_resources` — no user, role, policy or safe total. Firing four more list requests on dashboard load to decorate a shortcut isn't worth a number nobody asked for.

One dense row of rows under a quiet "Administration" rule — bottom-of-page chrome, weighted like chrome. Admin-only.

---

## Task 3 — JIT lifecycle, fixed and live

Your screenshot showed a green "Approved — access granted" banner sitting directly above a lifecycle reading "Approved — *Awaiting an approver*" and "Access active — *Nothing granted yet*". Two causes, both from my guessing at the API instead of reading it:

**Wrong field names.** The timeline looked for `approved_at`, `denied_at`, `cancelled_at`. `models.JITRequest` has none of them — it records every decision in **one** nullable column:

```go
DecidedAt        *time.Time `json:"decided_at,omitempty"`
ApproverUsername *string    `json:"approver_username,omitempty"`
DecisionReason   string     `json:"decision_reason,omitempty"`
```

Which decision it was is carried by `status`, not by which timestamp is populated. So `approved_at` was always `undefined` and the stage was permanently stuck.

**The grant is not nested.** The old code looked for `request.grant` / `request.grants[0]`. `GET /jit/requests/:id` returns the bare request, whose only link to the grant is `grant_id` — so the grant panel could never populate and the last two stages had nothing to read. The grant is now fetched from `GET /jit/grants` and matched on `grant_id`, falling back to `request_id`.

Also corrected throughout: `request_type` (not `type`) for STANDARD vs BREAKGLASS, `requested_at` as the authoritative raise time, `available_at` for the break-glass cooling-off deadline, `approver_username` / `decided_at` / `decision_reason` for the decision record, and `granted_at` for grants.

### Real-time

Both queries poll while the object can still change, and stop when it can't — the pattern CyberArk's request view, Okta's admin task list and Linear all use for a workflow object that *someone else* advances:

| State | Cadence | Why |
|---|---|---|
| PENDING / WAITING | 10s | Someone else is deciding |
| APPROVED with a live grant | 30s | So it flips to expired on its own |
| DENIED / CANCELLED / EXPIRED | never | It is not going to change |

Plus `refetchOnWindowFocus` — approve in another tab, switch back, it's already right. A small live dot in the header says the page is watching, because invisible polling still makes people reload.

The JIT list page and the approvals queue poll on the same rule (15s, only while something on the page is undecided).

**One more correctness fix:** an APPROVED request whose grant has since expired no longer claims "access granted". The banner follows the grant, not just the status.

---

## Task 4 — Oldest / Newest ordering

Two things were wrong.

**Time was compared as text.** `useTableState`'s comparator fell through to `localeCompare(..., { numeric: true })`, which treats each digit run as a number. Go emits RFC3339 with variable-precision fractional seconds and trailing zeros stripped, so:

```
2026-08-13T15:34:12.123456789Z
2026-08-13T15:34:12.5Z
```

…compares `123456789` against `5` and puts the earlier timestamp last. The comparator now parses date-shaped strings to epoch and compares numerically. That fixes every date column in the console, not just this one — grants by expiry, sessions by start, audit by time.

**The sort key could miss the field.** The queue sorted on `created_at` while the model's semantic raise-time column is `requested_at`. Any deployment or projection populating one and not the other made the accessor return `undefined` for every row — which compares equal for every pair, so the list never moved. That is precisely the "clicking it does nothing" symptom.

Now: the key is `requested_at`, the accessor resolves **both** time keys to the same epoch value (so a stored `created_at` preference from before this change still works), sorting resets to page 1, and ties keep their incoming order. Search, status facets and pagination all compose with it — they always did; the ordering step was the broken one.

Same treatment applied to the Grants tab (`granted_at`), and the "Granted" column header now sorts the field it displays.

---

## Files

| File | Change |
|---|---|
| `src/components/auth/MfaEnrollment.jsx` | Working Disable MFA; replace-warning; unprotected-state banner |
| `src/lib/mfaEvidence.js` | `recordMfaSetupRestarted` — enrolment start means "no longer protected" |
| `src/lib/mfaStatus.js` | Source note for the new evidence kind |
| `src/pages/SettingsPage.jsx` | Your version verbatim + `onDisabled` wiring |
| `src/pages/DashboardPage.jsx` | Administration shortcuts section |
| `src/pages/admin/IdentityListPage.jsx` | `?new=1` opens the create form |
| `src/pages/admin/RolesPage.jsx` | `?new=1` opens the create form |
| `src/pages/admin/PoliciesPage.jsx` | `?new=1` opens the create form |
| `src/pages/jit/JitRequestDetailPage.jsx` | Correct field names, grant lookup, polling |
| `src/pages/jit/JitPage.jsx` | `requested_at`, polling while in-flight |
| `src/pages/admin/AdminJitPage.jsx` | Ordering fix, `raisedAt`/`grantedAt`, queue polling |
| `src/hooks/useTableState.js` | Date-aware comparator |
