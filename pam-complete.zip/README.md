# PAM — complete source, agent binaries and test harness

**This archive is the whole thing, not a diff.** Earlier deliveries in this
session were changed-files archives, which made "which zip has the fix?" a
real question. This one has no such question: the complete `backend_upd`,
`frontend_upd` and `agent/pam-agent` trees, the compiled agent binaries, and
the harness that tested all of it.

`backend_upd/.env` is deliberately absent. It holds live RDS, MinIO, JWT,
audit-HMAC and root-password values; those should be rotated and the file kept
out of version control. Nothing else is withheld.

## What is in here

| path | what it is |
|---|---|
| `backend_upd/` | complete Go API source |
| `backend_upd/agents/` | the five compiled agent binaries, version `2026.09.18.2`, ready to copy into the backend's agent distribution directory |
| `frontend_upd/` | complete React console source (no `node_modules`/`dist` — run `npm ci`) |
| `agent/pam-agent/` | complete Go agent source, including its installers |
| `test-harness/` | every e2e suite, the environment scripts, and the TLS ingress used to reproduce the WebSocket failure |

### The binaries

| file | bytes |
|---|---|
| `pam-agent_linux_amd64` | 8,450,232 |
| `pam-agent_linux_arm64` | 7,995,576 |
| `pam-agent_darwin_amd64` | 8,678,480 |
| `pam-agent_darwin_arm64` | 8,188,882 |
| `pam-agent_windows_amd64.exe` | 8,709,120 |

`SHA256SUMS.txt` sits beside them and is informational only: `agentdist.Store`
hashes each binary itself when it scans the directory, so a missing or stale
sums file cannot make the backend serve an unverified download.

### Verified from THIS archive, not from the working tree

The tree was extracted and built on its own before packaging:

* `backend_upd` — `go build ./...` clean, `go test ./...` 13 packages ok
* `agent/pam-agent` — `go build ./...` clean, `go test ./...` 8 packages ok, cross-builds for darwin/arm64 and windows/amd64
* `frontend_upd` — `npm ci` (476 packages), `npm run lint` clean, `npm run build` clean

## The MinIO WebSocket question

**It connects.** Driven against real MinIO through a real TLS ingress, in the
two shapes that decide the outcome — `test-harness/e2e/wss-ingress.mjs`, which
is new and is the only thing that reproduces the reported failure, because it
is not reproducible on loopback:

| ingress | page + bucket list | `wss://…/ws/objectManager` |
|---|---|---|
| **with** `proxy_http_version 1.1` + `Upgrade` + `Connection` (`:8443`) | loads | **both sockets connected** |
| **without** those three lines (`:9443`) | loads fine, logs in fine | **15 socket errors, retrying** |

That asymmetry is the whole diagnosis. `Sec-WebSocket-Key` is end-to-end and
survives any proxy; `Connection` and `Upgrade` are hop-by-hop and must be
reinstated by every hop. PAM receives a request that wants a WebSocket and is
not marked as an upgrade, which is unanswerable — so the page works and only
the socket dies. PAM now detects that exact shape and logs the nginx lines to
add (`webproxy.upgrade.stripped`), which the broken lane asserts.

On the plain path `e2e/minio-real.mjs` is 17/17: the Object Browser renders,
the operator arrives already authenticated, a bucket created through the
session is listed, and every socket the Console opened was accepted.

## Fixes in this archive

Everything from the earlier deliveries, plus the four items that were still
open when the last one shipped.

### 1. A CLI launch with no display left a phantom session

A CLI launch asks a terminal emulator to run a wrapper; the relay inside that
terminal records the session and reports its end. `xterm -e` with no usable
display exits 1 in milliseconds having opened nothing — the same shape as psql
exiting 1 after an operator quits. The agent read it as "the tool ran and
exited", printed *"This session will close automatically when you exit the
tool"*, reported nothing, and left PAM holding an ACTIVE session with a
PENDING 0-byte recording. That is every SSH login, every container, and any
desktop whose `$DISPLAY` is wrong.

The wrapper now touches a marker file as its first action, before the
credential exports and before anything else that can fail, so the two outcomes
are separated by a fact rather than a timing guess.

| | session | recording | what the operator saw |
|---|---|---|---|
| before | `ACTIVE` forever | `PENDING`, 0 bytes | "this session will close automatically" |
| after | `KILLED`, with the reason | `FAILED`, with the reason | "no X display is set ($DISPLAY is empty) — open this resource in the browser through PAM instead" |

**Fixing it properly exposed a flaw in the first attempt.** Of the emulators
tried, only xterm blocks; gnome-terminal, konsole, xfce4-terminal and macOS's
`open -a Terminal` all return before the wrapper has run. Checking the marker
once would therefore have failed every launch on GNOME, KDE and macOS — and it
would not have shown up in testing, because xterm is first in the list and
does block. Both platforms now wait for the marker (10s, polling every 100ms,
returning the moment it appears). Verified on Linux with a non-blocking
emulator stand-in: a healthy async launch is not failed, and one that returns 0
without running the wrapper is caught.

macOS is wired the same way and is **not verified on hardware** — no Mac was
available — so it is written to fail towards the old behaviour: only the
absence of the marker after a full timeout becomes an error.

### 2. A recording's length was the row's lifetime, not the clip's

`duration_seconds` was computed server-side from "row created" to "artifact
attached", which also counts the launch, the upload, and the idle sweep's lag
on a session the operator never closed. A 10-second desktop clip was listed as
35 seconds and a 57-second brokered session as 103 — the list disagreeing with
the player, which reads the file.

Both cast recorders now track the offset of their last frame, the screen
recorder already knew its own length, and the agent sends it with the upload
(through the spool, so a recording delivered from disk days later still
reports the length it has). The server prefers a reported value and keeps the
old computation as the fallback for agents that do not send one. Live: the
same desktop session that used to record 35s now records **10s**, matching the
agent's own measurement.

The brokered-web path still uses the fallback, and says so in a comment: the
rrweb recorder does not track the span of the events it accumulates, and the
honest fix is to carry the first and last event timestamps through the ingest
rather than guess.

### 3. An empty vaulted secret produced an AUTH failure

`env` credential injection set the variable unconditionally, and `redis-cli`
sends an AUTH command whenever `REDISCLI_AUTH` is *present*, whatever its
value. Reproduced directly against a redis with no `requirepass`:

```
REDISCLI_AUTH="" redis-cli ping
  AUTH failed: ERR AUTH <password> called without any password configured…
redis-cli ping           # variable not set
  PONG
```

An empty password now means "do not authenticate" rather than "authenticate
with nothing" — it connects, and leaves a note in the log, because an empty
vault entry is legitimate (a local dev instance) and is also what an
unfinished one looks like.

Probing it found a reachable sibling: a resource with **no** credential at all
answered `500 Failed to resolve launch`. It now answers 422 with a sentence
the operator can act on — "This resource has no stored credential yet, so PAM
has nothing to sign you in with — ask an administrator to store one for it in
the vault" — which the agent prints verbatim in their terminal.

Left alone deliberately: whitespace-only secrets. Trimming them would mean
silently mangling a password whose trailing space is real.

### 4. Tool discovery is now OS-parameterised and tested for all three

`internal/discovery` decides which binary gets launched and branched on
`runtime.GOOS` in a dozen places, so the Windows and macOS halves of that
decision were only ever exercised by running on Windows and macOS. The one bug
already found there came straight out of that gap: Oracle's SQL Developer ZIP
carries `sqldeveloper.exe` next to `sqldeveloper.sh`, both 0755, `.exe` sorts
first, so on Linux the agent chose the Windows launcher, reported the tool as
available, and the launch died at exec.

`locateOn(goos, …)` and the helpers under it now take the target OS, and eight
new tests pin, from any machine: which glob set each OS reads, Windows
deciding runnability by extension while Unix needs the bit *and* rejects
foreign launchers, the native launcher winning on each platform, `.app`
overrides being bundles only on macOS, and per-platform portable roots. The
exported API is unchanged and the host's own behaviour is asserted too.

What still cannot be done here is **executing** the agent on macOS or Windows.
A registry query or an `/Applications` bundle cannot be conjured on Linux.

### Also

`pam-agent doctor`, the native failure notifications, the Devices panel
inventory, the operator's Connect menu rebuilt on the channel model, the
portalled menu primitive, the web channel requiring a console URL, and the
rrweb heartbeat that made a 57-second session replay as 57 seconds — all
described in the earlier sections of this file, all present here.

## Two test-suite defects fixed on the way

Both reported a broken product when only the test was wrong, which is worse
than a red test:

* `channels.mjs` depended on pgAdmin 4 simply not being installed on whatever
  machine ran it. Once this machine got a pgadmin4 tool-path override, four
  checks failed. It now **creates** its precondition by patching the device's
  capability report for the duration and restoring it in a `finally`.
* `visual.mjs` used `getByText('Mint a token').first()`, which is ambiguous —
  the identities table carries the same words as a status hint. It resolved to
  the menu item only because of DOM order, and once the menu primitive began
  portalling its panel to `document.body`, `.first()` started matching the
  hint. The click landed outside the menu, dismissed it, and the next
  assertion reported a broken product. Now scoped to the open menu, by role.

`harness/up.sh` also starts the stub target the brokered-web suite proxies to;
without it that suite fails in a way that reads exactly like a proxy
regression.

## Still open, honestly

* **macOS and Windows have never run this agent.** Per-OS *decisions* are now
  tested from anywhere; per-OS *execution* is not.
* **Brokered-web replay** rebuilds the DOM but keeps images as URLs on the
  session's subdomain, which is gone at replay time (`ERR_NAME_NOT_RESOLVED`).
  `replay.mjs` is 8/9 on exactly this. The fix is to store the session's assets
  once alongside the recording and rewrite the snapshot's URLs to a PAM-served
  path.
* **Brokered-web recording duration** still uses the server's fallback, as
  above.
* Several desktop applications were exercised through stand-ins because they
  could not be installed in the test container. PAM's launch, capture, upload
  and replay path is genuinely its own in those runs; the real binaries'
  quirks are untested.
