# PAM — complete source, agent binaries and test harness

**This archive is the whole thing, not a diff.** Earlier deliveries in this
session were changed-files archives, which made "which zip has the fix?" a
real question. This one has no such question: the complete `backend_upd`,
`frontend_upd` and `agent/pam-agent` trees, the compiled agent binaries, and
the harness that tested all of it.

`backend_upd/.env` is deliberately absent. It holds live RDS, MinIO, JWT,
audit-HMAC and root-password values; those should be rotated and the file kept
out of version control. Nothing else is withheld.

## What is in here

| path | what it is |
|---|---|
| `backend_upd/` | complete Go API source |
| `backend_upd/agents/` | the five compiled agent binaries, version `2026.09.18.3`, ready to copy into the backend's agent distribution directory |
| `frontend_upd/` | complete React console source (no `node_modules`/`dist` — run `npm ci`) |
| `agent/pam-agent/` | complete Go agent source, including its installers |
| `test-harness/` | every e2e suite, the environment scripts, and the TLS ingress used to reproduce the WebSocket failure |

### The binaries

| file | bytes |
|---|---|
| `pam-agent_linux_amd64` | 8,450,232 |
| `pam-agent_linux_arm64` | 7,995,576 |
| `pam-agent_darwin_amd64` | 8,678,480 |
| `pam-agent_darwin_arm64` | 8,188,882 |
| `pam-agent_windows_amd64.exe` | 8,709,120 |

`SHA256SUMS.txt` sits beside them and is informational only: `agentdist.Store`
hashes each binary itself when it scans the directory, so a missing or stale
sums file cannot make the backend serve an unverified download.

### Verified from THIS archive, not from the working tree

The tree was extracted and built on its own before packaging:

* `backend_upd` — `go build ./...` clean, `go test ./...` 13 packages ok, **420 tests pass**, 4 skip (the live-MinIO suites, which are environment-gated)
* `agent/pam-agent` — `go build ./...` clean, `go test ./...` 8 packages ok, **192 tests pass**, cross-builds for all five targets
* `frontend_upd` — `npm ci`, `npm run lint` clean, `npm run build` clean

### The browser suites

Twenty-five suites against the live stack. Everything green except the one
documented gap:

```
foundations  fonts  visual  ui  channels  lifecycle      ALL CHECKS PASSED
devices-page       18/18      stduser-launch    16/16
paging             24/24      optimistic         9/9
insights           43/43      command-palette    9/9
away-digest        16/16      vault-tree         9/9
standard-user      27/27      service-identity  32/32   (new)
web-recording      11/11      minio-real        17/17
replay-video        8/8       reported-bugs     17/17
fanout              5/5       wss-ingress       11/11
minio-session      live: rrweb COMPLETED, 975,998 B, duration 61s
replay              8/9  — the brokered-web image assets, listed under "Still open"
```

## The MinIO WebSocket question

**It connects.** Driven against real MinIO through a real TLS ingress, in the
two shapes that decide the outcome — `test-harness/e2e/wss-ingress.mjs`, which
is new and is the only thing that reproduces the reported failure, because it
is not reproducible on loopback:

| ingress | page + bucket list | `wss://…/ws/objectManager` |
|---|---|---|
| **with** `proxy_http_version 1.1` + `Upgrade` + `Connection` (`:8443`) | loads | **both sockets connected** |
| **without** those three lines (`:9443`) | loads fine, logs in fine | **15 socket errors, retrying** |

That asymmetry is the whole diagnosis. `Sec-WebSocket-Key` is end-to-end and
survives any proxy; `Connection` and `Upgrade` are hop-by-hop and must be
reinstated by every hop. PAM receives a request that wants a WebSocket and is
not marked as an upgrade, which is unanswerable — so the page works and only
the socket dies. PAM now detects that exact shape and logs the nginx lines to
add (`webproxy.upgrade.stripped`), which the broken lane asserts.

On the plain path `e2e/minio-real.mjs` is 17/17: the Object Browser renders,
the operator arrives already authenticated, a bucket created through the
session is listed, and every socket the Console opened was accepted.

## Fixes in this archive

Everything from the earlier deliveries, plus the vault and service-identity
round below and the four items listed after it.

### 0. The vault and the service identities, gone over end to end

Both features work. Driving them end to end turned up five defects, three of
which were security defects, and all five are fixed here.

`test-harness/e2e/service-identity.mjs` is new and drives the whole thing in
one run — 32/32 — with the admin plane through the console and the data plane
through raw HTTP, because a service token is not something a person holds and
testing it through a browser would be testing the wrong client.

#### 0.1 The vault's master key could silently be the one in the source tree

`NewVaultService` read `PAM_VAULT_ENCRYPTION_KEY` itself and, when the variable
was unset, fell back to a base64 key written **literally into
`internal/services/vault_service.go`**.

Config validation does require `vault.encryption_key` — but viper resolves that
key from a config file (`./config.yaml`, `./configs/config.yaml`,
`/etc/pam/config.yaml`) exactly as readily as from the environment. So a
deployment that put its master key in a config file, which is an ordinary thing
to do, passed validation, started clean, logged nothing unusual, and then
wrapped every credential's data key with a key that ships in this repository.
A database dump or an S3 vault backup, plus a copy of the source, decrypts the
entire vault.

The key is now a parameter taken from the validated config, and there is no
fallback: an empty key is a refusal to start. Verified against the real binary
in both directions —

```
PAM_VAULT_ENCRYPTION_KEY=  →  FATAL config.load.fail
                              vault.encryption_key (PAM_VAULT_ENCRYPTION_KEY) is required

key in configs/config.yaml only, no env var
                           →  starts, and reveals a credential that was stored
                              by the env-var server: same key, same plaintext
```

`internal/services/vault_master_key_test.go` pins it, including a test that
fails if that specific retired key ever becomes live code again.

#### 0.2 `PAM_KMS_PROVIDER` was set and then never read

`main.go` defaulted it to `local-dev` and nothing in the product ever consulted
it — `NewVaultService` calls `crypto.NewLocalKMSProvider` unconditionally, and
the AWS/HSM shapes in `pkg/crypto` are interface skeletons that return "not
configured".

That is worse than not having the setting. An operator who set
`PAM_KMS_PROVIDER=aws` got a server that started cleanly and went on wrapping
DEKs with the local key, believing their keys were in KMS.

It now means what it says: `local-dev` (or unset) is accepted, and any other
value stops the server with the reason.

```
PAM_KMS_PROVIDER=aws  →  FATAL config.kms_provider.unsupported
                         "PAM_KMS_PROVIDER names a provider this build does not
                          implement; DEKs would be wrapped with the local
                          vault.encryption_key regardless."
```

#### 0.3 The machine plane's refusals never reached the audit trail

`ServiceAuth` rejects a request before any handler runs, so the handler-side
audit never saw it. A rejected machine call produced a `zap` line and nothing
else — which meant the two events a SOC most wants from a machine credential
were invisible to every audit view, export and insight card in the product:

* somebody presenting unknown, expired or revoked service tokens, and
* an identity spending its read budget — the shape of a leaked token draining
  the vault.

The second is the worse omission. Measured before the fix, with a 5/min budget:

```
15 rapid reads  →  200 200 200 200 200 429 429 429 429 429 429 429 429 429 429
audit rows      →  5 SUCCESS, then silence
```

The first five reads of a stolen token are audited and everything after the
budget trips is silent, so in the audit trail the attack looks like the service
went *quiet* — quieter than legitimate traffic, not louder.

Both now write to the tamper-evident log, as `pam.service.rate_limited`
(CRITICAL) and `pam.service.auth_denied`. Live, after the fix:

```
pam.service.rate_limited | CRITICAL | {"max_reads_per_minute":5,"token_id":"45cae437…",
                                       "path":"/api/v1/pam/svc/secrets/prod-db/vault-check-3",
                                       "suppressed_since_last":0}
pam.service.auth_denied  | WARN     | {"claimed_token_id":"deadbeefdeadbeef",
                                       "reason":"unknown_expired_or_revoked_token"}
```

**They are coalesced, deliberately.** The audit log is hash-chained, so its
writes serialise; one row per rejected request would hand an unauthenticated
caller a write amplifier pointed at the one table that must not fall over. The
first refusal per subject is recorded immediately, the rest are counted, and
the next row carries `suppressed_since_last`. Seven refusals became one row
that says so; a second window later reported the one attempt swallowed in
between. A distributed flood collapses into a single overflow bucket, so the
worst case is bounded by subject count rather than request rate.

Two things never reach the row: the token's secret half (only the public token
id, length- and alphabet-bounded, since it is attacker-controlled on a
malformed token), and the underlying error text — a database failure can carry
a DSN, and the log is append-only, so failures are classified rather than
echoed.

#### 0.4 Vault writes put the secret in the audit record

`pam:vault:Store` recorded the request body verbatim, so storing a credential
wrote its plaintext into the audit log — the one table that is append-only and
hash-chained, where it cannot be scrubbed without breaking the evidence chain.
`internal/middleware/audit_redact.go` now walks the JSON and redacts on key
name, with a suffix list so metadata like `credential_type` survives intact.

```
before  {"name":"vault-check-db",…,"secret_plaintext":"S3cret-Vault-Check!"}
after   {"name":"vault-check-3", …,"secret_plaintext":"[redacted]",
         "credential_type":"password"}
```

#### 0.5 Every vault route was audited as a write

The classifier matched `/credential` first and returned `pam:vault:Store`
regardless of method, so a *reveal* was recorded as a *store*. An auditor
asking "who read this secret" got the wrong answer, and the insight card
counting secret reads counted none of them. Reveal, rotate, read, update and
delete are now distinguished, most-specific-first and then by method.

#### 0.6 The whole machine plane was filed as category OTHER

Every secret a service read, every service authentication failure and every
grant change derived to `OTHER`. The console's audit page already offers
`VAULT`, `AUTH`, `AUTHZ` and `ADMIN` in its category filter — so those filters
existed and returned nothing for the machine plane, which is where the bulk of
secret access actually happens. Filter by VAULT and you saw the human reveals
and not one machine read.

`pam.secret.*` and the budget refusal now derive to `VAULT`, service auth
failures to `AUTH`, grant changes to `AUTHZ`, identity and token lifecycle to
`ADMIN`. There were also **two** copies of this mapping — one in `models`, one
in `services` — that had already drifted, so a row's category depended on which
write path created it. There is now one, in `models`, and the service delegates
to it.

#### What was already right

Worth stating, since it is the bulk of the feature:

* Secrets are envelope-encrypted at rest with a KMS-wrapped DEK and row-identity
  AAD. Plaintext count in the credential table: 0.
* A grant is a boundary, not a formality: out-of-scope reads are 403, a
  nonexistent path is 404, no token is 401, a human JWT on the machine plane is
  401.
* Revocation is immediate, not next-cache-expiry — revoking a grant, a token,
  or disabling the identity all take effect on the very next call.
* Enabling a disabled identity leaves its tokens revoked, and says so in the
  audit record rather than leaving an auditor to assume the other way.
* A grant's `max_ttl_seconds` clamps the client's cache lifetime, and the
  tightest matching grant wins so a broad grant cannot silently relax a narrow
  one.
* A minted token is returned exactly once and never again; the list endpoint
  carries no secret.
* A grant requires a stated reason — the API refuses one without it.
* The read budget is a real token bucket, enforced in front of the handler.
* Machine-plane reads were already audited correctly against the identity, with
  the grant that allowed them.

### Do you need to add any environment variables?

`backend_upd/.env.example` is new and documents the whole surface. For these
two features specifically:

| variable | when | notes |
|---|---|---|
| `PAM_VAULT_ENCRYPTION_KEY` | **required everywhere** | base64 32 bytes (`openssl rand -base64 32`). The master KEK. Server refuses to start without it. |
| `PAM_VAULT_SERVICE_TOKEN_PEPPER` | **required in production**, 32+ bytes | Service tokens are stored only as HMAC(pepper, secret). Development derives a labelled throwaway; production refuses. **Changing it invalidates every issued service token.** |
| `PAM_AUDIT_HMAC_SECRET` | **required in production**, 32+ bytes | Keys the audit hash chain. Same dev/production rule. |
| `PAM_VAULT_DEFAULT_SECRET_TTL_SEC` | optional, default 300 | Deployment-wide ceiling on machine-side secret caching; per-grant caps clamp it further. |
| `PAM_KMS_PROVIDER` | optional — **leave it unset** | Only `local-dev` is implemented. Any other value now stops the server rather than being ignored. |

So: if you are already setting `PAM_VAULT_ENCRYPTION_KEY`, the only thing to
**add** for production is `PAM_VAULT_SERVICE_TOKEN_PEPPER` (and
`PAM_AUDIT_HMAC_SECRET`, if it is not set yet). Everything else has a working
default.

Each of these can equally live in a config file under its dotted key —
`vault.encryption_key`, `vault.service_token_pepper`, `audit.hmac_secret` —
and after 0.1 above, that now works correctly.

### 1. A CLI launch with no display left a phantom session

A CLI launch asks a terminal emulator to run a wrapper; the relay inside that
terminal records the session and reports its end. `xterm -e` with no usable
display exits 1 in milliseconds having opened nothing — the same shape as psql
exiting 1 after an operator quits. The agent read it as "the tool ran and
exited", printed *"This session will close automatically when you exit the
tool"*, reported nothing, and left PAM holding an ACTIVE session with a
PENDING 0-byte recording. That is every SSH login, every container, and any
desktop whose `$DISPLAY` is wrong.

The wrapper now touches a marker file as its first action, before the
credential exports and before anything else that can fail, so the two outcomes
are separated by a fact rather than a timing guess.

| | session | recording | what the operator saw |
|---|---|---|---|
| before | `ACTIVE` forever | `PENDING`, 0 bytes | "this session will close automatically" |
| after | `KILLED`, with the reason | `FAILED`, with the reason | "no X display is set ($DISPLAY is empty) — open this resource in the browser through PAM instead" |

**Fixing it properly exposed a flaw in the first attempt.** Of the emulators
tried, only xterm blocks; gnome-terminal, konsole, xfce4-terminal and macOS's
`open -a Terminal` all return before the wrapper has run. Checking the marker
once would therefore have failed every launch on GNOME, KDE and macOS — and it
would not have shown up in testing, because xterm is first in the list and
does block. Both platforms now wait for the marker (10s, polling every 100ms,
returning the moment it appears). Verified on Linux with a non-blocking
emulator stand-in: a healthy async launch is not failed, and one that returns 0
without running the wrapper is caught.

macOS is wired the same way and is **not verified on hardware** — no Mac was
available — so it is written to fail towards the old behaviour: only the
absence of the marker after a full timeout becomes an error.

### 2. A recording's length was the row's lifetime, not the clip's

`duration_seconds` was computed server-side from "row created" to "artifact
attached", which also counts the launch, the upload, and the idle sweep's lag
on a session the operator never closed. A 10-second desktop clip was listed as
35 seconds and a 57-second brokered session as 103 — the list disagreeing with
the player, which reads the file.

Both cast recorders now track the offset of their last frame, the screen
recorder already knew its own length, and the agent sends it with the upload
(through the spool, so a recording delivered from disk days later still
reports the length it has). The server prefers a reported value and keeps the
old computation as the fallback for agents that do not send one. Live: the
same desktop session that used to record 35s now records **10s**, matching the
agent's own measurement.

The brokered-web path still uses the fallback, and says so in a comment: the
rrweb recorder does not track the span of the events it accumulates, and the
honest fix is to carry the first and last event timestamps through the ingest
rather than guess.

### 3. An empty vaulted secret produced an AUTH failure

`env` credential injection set the variable unconditionally, and `redis-cli`
sends an AUTH command whenever `REDISCLI_AUTH` is *present*, whatever its
value. Reproduced directly against a redis with no `requirepass`:

```
REDISCLI_AUTH="" redis-cli ping
  AUTH failed: ERR AUTH <password> called without any password configured…
redis-cli ping           # variable not set
  PONG
```

An empty password now means "do not authenticate" rather than "authenticate
with nothing" — it connects, and leaves a note in the log, because an empty
vault entry is legitimate (a local dev instance) and is also what an
unfinished one looks like.

Probing it found a reachable sibling: a resource with **no** credential at all
answered `500 Failed to resolve launch`. It now answers 422 with a sentence
the operator can act on — "This resource has no stored credential yet, so PAM
has nothing to sign you in with — ask an administrator to store one for it in
the vault" — which the agent prints verbatim in their terminal.

Left alone deliberately: whitespace-only secrets. Trimming them would mean
silently mangling a password whose trailing space is real.

### 4. Tool discovery is now OS-parameterised and tested for all three

`internal/discovery` decides which binary gets launched and branched on
`runtime.GOOS` in a dozen places, so the Windows and macOS halves of that
decision were only ever exercised by running on Windows and macOS. The one bug
already found there came straight out of that gap: Oracle's SQL Developer ZIP
carries `sqldeveloper.exe` next to `sqldeveloper.sh`, both 0755, `.exe` sorts
first, so on Linux the agent chose the Windows launcher, reported the tool as
available, and the launch died at exec.

`locateOn(goos, …)` and the helpers under it now take the target OS, and eight
new tests pin, from any machine: which glob set each OS reads, Windows
deciding runnability by extension while Unix needs the bit *and* rejects
foreign launchers, the native launcher winning on each platform, `.app`
overrides being bundles only on macOS, and per-platform portable roots. The
exported API is unchanged and the host's own behaviour is asserted too.

What still cannot be done here is **executing** the agent on macOS or Windows.
A registry query or an `/Applications` bundle cannot be conjured on Linux.

### Also

`pam-agent doctor`, the native failure notifications, the Devices panel
inventory, the operator's Connect menu rebuilt on the channel model, the
portalled menu primitive, the web channel requiring a console URL, and the
rrweb heartbeat that made a 57-second session replay as 57 seconds — all
described in the earlier sections of this file, all present here.

## Two test-suite defects fixed on the way

Both reported a broken product when only the test was wrong, which is worse
than a red test:

* `channels.mjs` depended on pgAdmin 4 simply not being installed on whatever
  machine ran it. Once this machine got a pgadmin4 tool-path override, four
  checks failed. It now **creates** its precondition by patching the device's
  capability report for the duration and restoring it in a `finally`.
* `visual.mjs` used `getByText('Mint a token').first()`, which is ambiguous —
  the identities table carries the same words as a status hint. It resolved to
  the menu item only because of DOM order, and once the menu primitive began
  portalling its panel to `document.body`, `.first()` started matching the
  hint. The click landed outside the menu, dismissed it, and the next
  assertion reported a broken product. Now scoped to the open menu, by role.

* `fanout.mjs` assumed the twelve identities it provisions would be on the
  first page of the table. Identities are never deleted — disabling is the
  strongest thing the API offers, deliberately, because the audit trail has to
  outlive the identity — so each run left twelve more rows behind and the suite
  eventually failed against its own history, at around 200 identities. That is
  an ordinary size for a real estate, so the suite now narrows the table with
  the page's own search field before looking for its row. Re-run at 227
  identities: 5 requests, still flat.

`harness/up.sh` also starts the stub target the brokered-web suite proxies to;
without it that suite fails in a way that reads exactly like a proxy
regression.

## Still open, honestly

* **macOS and Windows have never run this agent.** Per-OS *decisions* are now
  tested from anywhere; per-OS *execution* is not.
* **Brokered-web replay** rebuilds the DOM but keeps images as URLs on the
  session's subdomain, which is gone at replay time (`ERR_NAME_NOT_RESOLVED`).
  `replay.mjs` is 8/9 on exactly this. The fix is to store the session's assets
  once alongside the recording and rewrite the snapshot's URLs to a PAM-served
  path.
* **Brokered-web recording duration** still uses the server's fallback, as
  above.
* Several desktop applications were exercised through stand-ins because they
  could not be installed in the test container. PAM's launch, capture, upload
  and replay path is genuinely its own in those runs; the real binaries'
  quirks are untested.
