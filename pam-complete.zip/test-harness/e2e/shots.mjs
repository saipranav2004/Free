import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
const token = readFileSync('/tmp/tok', 'utf8').trim()
const me = await (await fetch('http://127.0.0.1:8080/api/v1/auth/me', { headers: { Authorization: `Bearer ${token}` } })).json()
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--no-proxy-server'] })
const ctx = await b.newContext({ viewport: { width: 1400, height: 1000 } })
const page = await ctx.newPage()
await page.goto('http://127.0.0.1:4180', { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u })), [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }])
await page.goto('http://127.0.0.1:4180/admin/services', { waitUntil: 'networkidle' })
const row = page.locator('tbody tr', { hasText: 'billing-api-prod' })
await row.first().waitFor({ timeout: 10000 })

// The drawer.
await row.first().locator('button[title="billing-api-prod"]').click()
await page.getByText('What this service can read').waitFor({ timeout: 8000 })
await page.waitForTimeout(600)
await page.screenshot({ path: '/tmp/shot-drawer.png' })
await page.keyboard.press('Escape')
await page.waitForTimeout(400)

// The grant form, mid-decision on a subtree scope.
await row.first().getByRole('button', { name: /Actions for billing-api-prod/ }).click()
await page.getByText('Grant a scope').first().click()
await page.getByText('What this reaches today').waitFor({ timeout: 8000 })
await page.locator('#gs-scope').fill('prod-db/**')
await page.locator('#gs-reason').fill('The billing API reads the writer credential for the invoices database on start-up.')
await page.waitForTimeout(600)
await page.screenshot({ path: '/tmp/shot-grant.png' })
await b.close()
console.log('captured')
