import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The LAUNCH CONTROLS as a standard operator, on a laptop that cannot record.
//
// This is the screen the capability report was built for, and the one whose
// behaviour was only ever checked with a root token on a fully-equipped
// machine — the single combination least likely to show a problem. operator1
// has one resource, standing access to it, and a paired device with no
// ffmpeg; the resource requires recording. The agent WILL refuse that launch,
// so the console has to say so before the operator clicks.
const token = readFileSync('/tmp/tok-user', 'utf8').trim()
const API = 'http://127.0.0.1:8080', APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data

const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok, d }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox','--no-proxy-server'] })
const page = await (await browser.newContext({ viewport: { width: 1500, height: 1100 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()) })
const launches = []
page.on('request', (r) => { if (/\/launch$/.test(r.url()) && r.method() === 'POST') launches.push(r.postData()) })

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t,u]) => sessionStorage.setItem('pam_session', JSON.stringify({accessToken:t,refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:u})), [token,{user_id:me.user_id,username:me.username,roles:me.roles,email:me.email}])
await page.goto(APP + '/resources', { waitUntil: 'networkidle' })
await page.waitForTimeout(2000)

const listBody = await page.locator('main').innerText()
check('the operator sees the resource they were granted', /pg-real/i.test(listBody),
  listBody.replace(/\s+/g,' ').slice(0, 100))

// "Connect" is the operator's way in. Clicking the resource NAME does
// nothing on this screen — the row is not the control, which is worth
// knowing: an admin reaches the same resource through a drawer, so the two
// roles do not arrive at the launch controls the same way.
// Scoped to the row. A page-wide role query picks up the "Connect" card
// heading on other screens, and the row's control is the only one a standard
// user has.
const row = page.locator('tbody tr').filter({ hasText: /pg-real/i }).first()
await row.getByRole('button', { name: /connect/i }).first().click()
await page.waitForTimeout(2500)
console.log('  still on', new URL(page.url()).pathname, '(operators get a row dropdown, not a detail page)')
await page.screenshot({ path: '/tmp/stduser-menu-open.png' })
const body = await page.locator('main').innerText()

// The three channels, and what each one says. Read from the open menu, which
// is the operator's entire resource surface.
const controls = {}
for (const [key, re] of [['cli', /Open in CLI/i], ['desktop', /Open in Desktop/i], ['web', /Open in Web/i]]) {
  const item = page.getByRole('menuitem', { name: re }).first()
  const present = await item.count() > 0
  controls[key] = present
    ? { present, disabled: await item.isDisabled().catch(() => null), title: (await item.getAttribute('title')) || '' }
    : { present: false }
}
console.log('  controls:', JSON.stringify(controls))

// EVERY channel the resource supports is listed, usable or not. The bug this
// replaces showed exactly one item — the only channel that could not work.
check('every channel the server reports is offered', controls.cli.present && controls.desktop.present && controls.web.present,
  Object.entries(controls).map(([k, v]) => `${k}:${v.present ? (v.disabled ? 'shown-disabled' : 'enabled') : 'MISSING'}`).join(' '))
check('the channel that works is enabled', controls.cli.disabled === false,
  `cli disabled=${controls.cli.disabled}`)
check('the channel whose tool is missing is shown but not pressable', controls.desktop.disabled === true,
  `desktop disabled=${controls.desktop.disabled}`)

// THE POINT: this laptop has no pgAdmin 4, so the desktop route cannot work.
// The operator must be told WHICH tool, and how to get it — not left with a
// door that does nothing, and not told to go and ask an administrator about
// something they could fix themselves.
const menuText = await page.locator('[role="menu"]').first().innerText().catch(() => body)
check('the menu names the missing tool', /pgadmin/i.test(menuText),
  (menuText.match(/[^\n]*not on this device[^\n]*/i) || ['not named'])[0].trim().slice(0, 140))
check('it says how to get it', /download|install/i.test(menuText),
  (menuText.match(/[^\n]*(download|install)[^\n]*/i) || ['no remedy'])[0].trim().slice(0, 140))
check('it does not blame policy for a missing tool',
  !/administrator has restricted/i.test(menuText))
check('and it offers the route that DOES work on this machine',
  /Open in CLI/i.test(menuText))

// The web route on THIS resource cannot work either, for a completely
// different reason: pg-real has no console_url, so there is nothing for PAM
// to proxy. Before the fix the server called this channel "available", the
// menu rendered a live control, and clicking it 422'd with nothing on screen.
check('a resource with no web console says so, and does not offer the route',
  controls.web.disabled === true && /no web console configured/i.test(menuText),
  (menuText.match(/[^\n]*web console[^\n]*/i) || ['not explained'])[0].trim().slice(0, 130))
check('it does not tell the operator to install something for a configuration gap',
  !/install[^\n]*console/i.test(menuText))

// ── The clickable ones have to actually work ────────────────────────────
//
// A menu that renders the right three items and errors on two of them is not
// an improvement. Both enabled routes are exercised: Web is brokered entirely
// server-side, and CLI goes through the agent launch endpoint.
console.log('\n=== the routes it says are open ===')

// A resource that CAN be brokered: minio-real has a console_url, so the same
// operator, the same laptop and the same menu must produce a live session.
await page.keyboard.press('Escape')
await page.goto(APP + '/resources', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
await page.locator('tbody tr').filter({ hasText: /minio-real/i }).first()
  .getByRole('button', { name: /connect/i }).first().click()
await page.waitForSelector('[role="menu"]', { state: 'visible' })
const brokerable = await page.locator('[role="menu"]').first().innerText()
console.log('  minio-real menu:', brokerable.replace(/\s+/g, ' ').slice(0, 120))

const webItem = page.getByRole('menuitem', { name: /Open in Web/i }).first()
check('a brokerable resource offers Open in Web as a live control',
  await webItem.count() > 0 && (await webItem.isDisabled()) === false)
await webItem.click()
await page.waitForTimeout(7000)
const afterWeb = await page.locator('body').innerText()
const webSessions = await (await fetch(`${API}/api/v1/pam/web-sessions/mine`, { headers: { Authorization: 'Bearer ' + token } })).json()
const liveWeb = (webSessions.data?.sessions || []).length
check('and it really opens a brokered session for a standard user', liveWeb > 0,
  `${liveWeb} live brokered session(s)`)
check('with nothing failing on screen', !/failed|went wrong/i.test(afterWeb),
  (afterWeb.match(/[^\n]*(failed|went wrong)[^\n]*/i) || ['clean'])[0].slice(0, 90))

// CLI: the agent hand-off. The browser cannot follow pam-agent://, so what is
// asserted is that the console asked the server for the right channel and did
// not report a failure to the operator.
await page.goto(APP + '/resources', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
await page.locator('tbody tr').filter({ hasText: /pg-real/i }).first()
  .getByRole('button', { name: /connect/i }).first().click()
await page.waitForSelector('[role="menu"]', { state: 'visible' })
await page.getByRole('menuitem', { name: /Open in CLI/i }).first().click()
await page.waitForTimeout(5000)
check('Open in CLI asks the server for the cli channel', launches.some((b) => /"channel"\s*:\s*"cli"/.test(b || '')),
  launches.join(' ') || 'no launch request was sent')
const afterCli = await page.locator('body').innerText()
check('the CLI hand-off does not report an error to the operator',
  !/no paired device|failed to|could not/i.test(afterCli),
  (afterCli.match(/[^\n]*(paired|failed|could not)[^\n]*/i) || ['clean'])[0].slice(0, 110))

check('no page errors on the operator\'s own resource screen',
  errors.filter((e) => !/favicon|manifest/i.test(e)).length === 0,
  errors[0] || '')

await page.screenshot({ path: '/tmp/stduser-launch.png', fullPage: true })
await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) { failed.forEach((f) => console.log(`  FAILED: ${f.n} — ${f.d}`)); process.exit(1) }
