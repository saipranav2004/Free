import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// Does the console REPLAY a recording, or only store one?
//
// Every earlier check in this session read the stored artifact: the row
// exists, the format is rrweb, the stream has frames. None of that proves an
// auditor can watch the session back, which is the entire point of recording
// it — and the reference video the customer sent is precisely that: the
// Recordings tab, a scrubber reading 00:01 / 00:04, the MinIO Object Browser
// painted inside the player.
//
// So this drives the player. It asserts the recorded screen actually appears
// (rrweb builds a real DOM inside an iframe, so the target's own markup is
// there to find) and that the transport advances when told to play.

const APP = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()
const who = async (t) => (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + t } })).json()).data

const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok, d }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const page = await (await browser.newContext({ viewport: { width: 1600, height: 1000 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()) })

const me = await who(token)
await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

// The tab the reference video is filmed on.
await page.goto(APP + '/admin/audit?tab=recordings', { waitUntil: 'networkidle' })
await page.waitForTimeout(2500)

const body = await page.locator('main').innerText()
check('the Recordings tab lists recordings', /minio-real|rrweb|recording/i.test(body),
  body.replace(/\s+/g, ' ').slice(0, 120))

// Open a COMPLETED brokered-web recording. Addressed by its own row button
// ("Play recording for <resource>") rather than by clicking the row, and
// filtered to COMPLETED first: a session still in progress opens a viewer
// that correctly says "come back when it is COMPLETED", which reads as a
// broken player rather than as a test aimed at the wrong row.
await page.getByRole('button', { name: /^COMPLETED$/ }).first().click().catch(() => {})
await page.waitForTimeout(1800)
// The LARGEST minio-real recording, not the newest one.
//
// "the first row" is how this suite came to certify an empty stage: any
// brokered session opened and closed without a browser attached leaves a real
// COMPLETED row of about a kilobyte, and being the newest it sorted to the
// top. A suite asking "can an auditor watch a session back" has to open a row
// that HAS a session in it, so the row is chosen by the size the table prints.
const candidates = page.locator('tbody tr').filter({ hasText: /minio-real/i })
const rowCount = await candidates.count()
let row = candidates.first()
let bestKb = -1
for (let i = 0; i < rowCount; i++) {
  const t = (await candidates.nth(i).innerText()).replace(/\s+/g, ' ')
  const m = /([\d.]+)\s*(KB|MB)/i.exec(t)
  const kb = m ? Number(m[1]) * (/mb/i.test(m[2]) ? 1024 : 1) : 0
  if (kb > bestKb) { bestKb = kb; row = candidates.nth(i) }
}
const opened = rowCount > 0
if (opened) console.log(`  (of ${rowCount} minio-real rows, opening the ${bestKb} KB one)`)
check('a brokered-web recording row is present to open', opened)
if (opened) {
  await row.getByRole('button', { name: /play recording/i }).first().click()
  await page.waitForTimeout(8000)
}

// rrweb replays into an IFRAME whose document is the recorded page. That is
// the strongest available evidence: if the target's own markup is inside it,
// the recording really did capture the screen and really did rebuild it.
const frames = page.frames().length
const stage = await page.locator('iframe').count()
check('the player mounted a replay stage', stage > 0, `${stage} iframe(s), ${frames} frame(s)`)

// Read the REPLAY IFRAME specifically, not "the frame with the most text".
//
// The loose version of this check passed while the stage was blank, because
// the longest body on the page is the PAM console's own navigation in the top
// frame. An assertion that a replay rendered must look only where the replay
// is, or it certifies the shell around it.
let inner = ''
const handle = await page.locator('iframe').first().elementHandle().catch(() => null)
const stageFrame = handle ? await handle.contentFrame().catch(() => null) : null
if (stageFrame) {
  inner = await stageFrame.locator('body').innerText().catch(() => '')
}
check('the recorded MinIO screen is rebuilt inside the replay iframe',
  /object browser|bucket|minio/i.test(inner),
  inner.replace(/\s+/g, ' ').slice(0, 140) || '(the stage is empty)')

// Everything below is scoped to the OPEN VIEWER. Querying the page instead
// reaches controls behind the modal, and the modal then (correctly) swallows
// the click — which surfaces as a 30s timeout that says nothing about replay.
const modal = page.locator('.fixed.inset-0').first()

// The transport: a scrubber and a play control, as in the reference video.
// One button, two labels: it reads "Pause" while running and "Play" when
// stopped. Matching only /^play$/ failed on a player that had already started
// — a green transport reported as a missing one.
const playBtn = modal.getByRole('button', { name: /^(play|pause)$/i }).first()
const hasTransport = await playBtn.isVisible().catch(() => false)
check('the player offers a play/pause transport', hasTransport)

const modalText = async () => (await modal.innerText()).replace(/\s+/g, ' ')
let clock = /(\d+:\d{2})\s*\/\s*(\d+:\d{2})/.exec(await modalText())
check('a position / duration clock is shown, as in the reference video',
  !!clock, clock ? clock[0] : 'no clock found')
check('the recording has a non-zero length to play',
  !!clock && clock[2] !== '00:00', clock ? `duration reads ${clock[2]}` : '')

if (hasTransport && clock && clock[2] !== '00:00') {
  // The player autoplays, so a recording shorter than the wait above has
  // already finished and its clock cannot advance again. Rewind first: this
  // check is about whether the transport RUNS, not about where it happens to
  // be sitting when the test arrives.
  if (clock[1] === clock[2]) {
    await modal.getByRole('button', { name: /^restart$/i }).first().click().catch(() => {})
    await page.waitForTimeout(800)
    clock = /(\d+:\d{2})\s*\/\s*(\d+:\d{2})/.exec(await modalText()) || clock
  }
  // Only press it if it is offering to START. Clicking a transport that is
  // already running pauses it, and the clock then (correctly) sits still.
  const label = (await playBtn.getAttribute('aria-label')) || ''
  if (/play/i.test(label)) await playBtn.click()
  await page.waitForTimeout(3500)
  const after = /(\d+:\d{2})\s*\/\s*(\d+:\d{2})/.exec(await modalText())
  check('pressing play advances the clock', !!after && after[1] !== clock[1],
    `${clock[1]} -> ${after ? after[1] : '?'}`)
}

const fatal = errors.filter((e) => !/favicon|manifest|ResizeObserver/i.test(e))
check('no page errors while replaying', fatal.length === 0, fatal[0] || '')

await page.screenshot({ path: '/tmp/replay.png' })
await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) { failed.forEach((f) => console.log(`  FAILED: ${f.n} — ${f.d}`)); process.exit(1) }
