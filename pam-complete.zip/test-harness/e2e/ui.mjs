// The Service Identities screen, driven the way an administrator drives it:
// real Chromium, the real built bundle, the real Go API, the real database.
import { chromium } from 'playwright-core'
import { readFileSync, writeFileSync } from 'node:fs'

const BASE = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()

// Mint this run's service token rather than reading one somebody left in
// /tmp. The fixture's tokens are revoked by any suite that disables the
// identity (collection-routes does exactly that, on purpose), so a cached
// token eventually starts returning a perfectly correct 401 that reads as a
// broken read path. Minting here also makes the "the drawer never shows the
// secret" check below mean something: the token it compares against is one
// that really is in the list on screen.
{
  const res = await fetch(`${API}/api/v1/pam/admin/services/billing-api-prod/tokens`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ ttl_days: 30, description: 'ui.mjs run' }),
  })
  const body = await res.json()
  if (!body?.data?.token) {
    console.error('could not mint a service token for billing-api-prod:', JSON.stringify(body).slice(0, 300))
    process.exit(1)
  }
  writeFileSync('/tmp/mint.json', JSON.stringify(body))
}

let failures = 0
const check = (name, ok, detail = '') => {
  if (!ok) failures++
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  — ${detail}` : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
const page = await ctx.newPage()

const pageProblems = []
page.on('console', (m) => {
  if (m.type() === 'error') pageProblems.push(m.text())
})
page.on('pageerror', (e) => pageProblems.push(`pageerror: ${e.message}`))
const failedRequests = []
page.on('requestfailed', (r) =>
  failedRequests.push(`${r.method()} ${r.url()} -> ${r.failure()?.errorText}`)
)

// Seed the session the way a completed login does — the login flow is not
// what is under test here.
await page.goto(BASE, { waitUntil: 'domcontentloaded' })
const me = await (await fetch('http://127.0.0.1:8080/api/v1/auth/me', {
  headers: { Authorization: `Bearer ${token}` },
})).json()
await page.evaluate(
  ([t, user]) => {
    sessionStorage.setItem(
      'pam_session',
      JSON.stringify({
        accessToken: t,
        refreshToken: null,
        expiresAt: new Date(Date.now() + 3600e3).toISOString(),
        user,
      })
    )
  },
  [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }]
)

// ── 1. the sidebar offers it, and it leads to the page ────────────────────
await page.goto(`${BASE}/`, { waitUntil: 'networkidle' })
const navLink = page.getByRole('link', { name: 'Service Identities' })
check('sidebar shows a Service Identities entry', (await navLink.count()) > 0)
await navLink.first().click()
await page.waitForURL('**/admin/services', { timeout: 10000 })
await page.waitForLoadState('networkidle')
check('navigating to it lands on /admin/services', page.url().endsWith('/admin/services'))
// ── 2. the identity created over the API is listed, with live counts ──────
const row = page.locator('tbody tr', { hasText: 'billing-api-prod' })
await row.first().waitFor({ timeout: 10000 })
const headings = await page.locator('h1').allInnerTexts()
check(
  'the page renders its title as the h1',
  headings.some((h) => h.includes('Service Identities')),
  JSON.stringify(headings)
)
const cells = await row.first().locator('td').allInnerTexts()
check('the identity from the API appears in the table', cells.length > 0, cells.slice(0, 5).join(' | '))
// Posture must resolve to Ready: one live token and one live scope exist.
await page.waitForFunction(
  () => {
    const tr = [...document.querySelectorAll('tbody tr')].find((r) => r.textContent.includes('billing-api-prod'))
    return tr && !tr.textContent.includes('checking')
  },
  { timeout: 10000 }
)
const rowText = await row.first().innerText()
check('posture resolves to Ready (it has a token and a scope)', rowText.includes('Ready'), rowText.replace(/\n/g, ' | '))
// The column used to render a permanent "-" because the list endpoint never
// carried the counts. Asserted as "two numeric cells, neither a dash" rather
// than by looking for the digit 1: the fixture accumulates tokens and scopes
// across runs, and a test that only passes while the count happens to be one
// is testing the fixture, not the column.
const countCells = (await row.first().locator('td').allInnerTexts())
  .map((t) => t.trim())
  .filter((t) => /^\d+$/.test(t))
check(
  'the scope and token counts are shown, not dashes',
  countCells.length >= 2 && countCells.every((c) => Number(c) >= 1) && !rowText.includes('\t-\t'),
  `numeric cells: [${countCells.join(', ')}] in ${rowText.replace(/\n/g, ' | ')}`
)

// ── 3. the drawer answers both questions ─────────────────────────────────
await row.first().locator('button[title="billing-api-prod"]').click()
const drawer = page.locator('[role="dialog"], aside').filter({ hasText: 'billing-api-prod' })
await page.getByText('What this service can read').waitFor({ timeout: 10000 })
check('the drawer opens on the Scopes tab', true)
const scopeVisible = await page.locator('text=prod-db/*').first().isVisible()
check('the granted scope prod-db/* is listed', scopeVisible)
check(
  'the scope is labelled a wildcard, not one secret',
  (await page.getByText('Wildcard', { exact: true }).count()) > 0
)
check(
  "the grant's cache cap is stated",
  (await page.getByText('caches for at most 120s').count()) > 0
)
// Asserted against what the server says rather than a hardcoded number, so
// the check survives being run twice (the run below adds a grant).
const liveGrants = await (await fetch(
  'http://127.0.0.1:8080/api/v1/pam/admin/services/billing-api-prod/grants',
  { headers: { Authorization: `Bearer ${token}` } }
)).json()
const expectedScopes = (liveGrants.data || []).length
const posture = await page.getByText(/It can read \d+ scope/).first().innerText()
check(
  'the drawer states the posture as a sentence matching the server',
  posture.includes(`It can read ${expectedScopes} scope`),
  posture
)

// Tokens tab
await page.getByRole('tab', { name: /Tokens/ }).click()
await page.getByText('What can authenticate as it').waitFor({ timeout: 5000 })
const tokenRow = await page.locator('li', { hasText: 'pamsvc.' }).first().innerText()
check('the token is listed by id only, never its secret', tokenRow.includes('pamsvc.') && !tokenRow.includes(
  JSON.parse(readFileSync('/tmp/mint.json', 'utf8')).data.token.split('.')[2]
), tokenRow.replace(/\n/g, ' | '))
check('the token shows as Active', tokenRow.includes('Active'))
check('a token that has been used says so', /last used|never used/.test(tokenRow))

// ── 4. the scope preview: the feature that makes a grant informed ─────────
await page.keyboard.press('Escape')
await page.getByRole('button', { name: /Actions for billing-api-prod/ }).click()
await page.getByRole('menuitem', { name: 'Grant a scope' }).click().catch(async () => {
  await page.getByText('Grant a scope').first().click()
})
await page.getByText('What this reaches today').waitFor({ timeout: 10000 })
check('the grant form opens with a live preview panel', true)

const scopeInput = page.locator('#gs-scope')
const preview = async (scope) => {
  await scopeInput.fill(scope)
  await page.waitForTimeout(500)
  const text = await page.locator('section', { hasText: 'What this reaches today' }).first().innerText()
  // "34 of 38 secrets" — the count is the claim; the list beneath it is a
  // capped sample (12 rows, then "and N more").
  const m = /(\d+) of (\d+) secrets/.exec(text)
  return { text, count: m ? Number(m[1]) : null }
}

// The property under test is that a single * stops at a folder boundary and **
// crosses it. Asserting it by naming secrets in the preview LIST is fragile:
// the list is capped at 12 rows, so on a vault that has accumulated secrets
// the named ones are simply below the fold and the check fails while the
// feature is correct. So the narrow scope is asserted by name (few enough rows
// that they all render) and the deep one by COUNT, which is the preview's
// actual claim and holds at any vault size.
let p1 = await preview('prod-db/pg-*')
check(
  'a single * reaches the root secrets and stops at the folder boundary',
  p1.text.includes('prod-db/pg-app-writer') &&
    p1.text.includes('prod-db/pg-reader') &&
    !p1.text.includes('prod-db/replicas/pg-replica-reader'),
  p1.text.replace(/\n/g, ' | ').slice(0, 200)
)

const shallow = await preview('prod-db/*')
const deep = await preview('prod-db/**')
check(
  'prod-db/** reaches strictly more than prod-db/* — it crosses the folder',
  shallow.count !== null && deep.count !== null && deep.count > shallow.count,
  `* reaches ${shallow.count}, ** reaches ${deep.count}`
)

const nested = await preview('prod-db/replicas/*')
check(
  'the secret inside the folder is reachable, and only by a scope naming it',
  nested.text.includes('prod-db/replicas/pg-replica-reader') && nested.count === deep.count - shallow.count,
  `replicas/* reaches ${nested.count}; ** - * = ${deep.count - shallow.count}`
)

let previewText = deep.text
check(
  'a subtree scope is called out as covering future secrets',
  previewText.includes('grants a whole subtree'),
  ''
)

await scopeInput.fill('**')
await page.waitForTimeout(400)
previewText = await page.locator('section', { hasText: 'What this reaches today' }).first().innerText()
check(
  '** is called out as granting the entire vault',
  previewText.includes('every secret in the vault'),
  ''
)
const grantBtn = page.getByRole('button', { name: 'Grant scope' })
await page.locator('#gs-reason').fill('deliberate broad grant, for the test')
check(
  'a vault-wide grant stays blocked until it is acknowledged',
  await grantBtn.isDisabled()
)
await page.getByRole('checkbox').filter({ has: page.locator('xpath=.') }).first().check().catch(() => {})
await page.locator('input[type="checkbox"]').last().check()
await page.waitForTimeout(200)
check('acknowledging unblocks it', await grantBtn.isEnabled())

await scopeInput.fill('prod-db/[')
await page.waitForTimeout(300)
check(
  'a malformed pattern is refused rather than previewed as empty',
  (await page.getByText('The server cannot parse that pattern.').count()) > 0
)

// ── 5. grant a real, narrow scope through the UI and verify server-side ───
await scopeInput.fill('prod-db/replicas/**')
await page.locator('#gs-reason').fill('granted through the console during the end-to-end run')
await page.locator('#gs-ttl').fill('60')
await page.waitForTimeout(300)
await page.getByRole('button', { name: 'Grant scope' }).click()
await page.waitForTimeout(1500)

const grants = await (await fetch(
  'http://127.0.0.1:8080/api/v1/pam/admin/services/billing-api-prod/grants',
  { headers: { Authorization: `Bearer ${token}` } }
)).json()
const scopes = (grants.data || []).map((g) => g.scope)
check(
  'the grant made in the browser exists on the server',
  scopes.includes('prod-db/replicas/**'),
  scopes.join(', ')
)
const newGrant = (grants.data || []).find((g) => g.scope === 'prod-db/replicas/**')
check('its cache cap was saved as typed', newGrant?.max_ttl_seconds === 60, String(newGrant?.max_ttl_seconds))

// And the service can now actually read what the console said it could.
const svcToken = JSON.parse(readFileSync('/tmp/mint.json', 'utf8')).data.token
const read = await fetch(
  'http://127.0.0.1:8080/api/v1/pam/svc/secrets/prod-db/replicas/pg-replica-reader?purpose=verify+the+console+grant',
  { headers: { 'X-Service-Token': svcToken } }
)
const readBody = await read.json()
check(
  'the service can read the secret the console just granted',
  read.status === 200 && readBody.data?.secret_value === 'the-replica-password',
  `http ${read.status}`
)

// ── 6. no unhandled errors anywhere in the run ────────────────────────────
if (failedRequests.length) console.log('  (requests that failed:', failedRequests.join(' ; '), ')')
// An aborted fetch is normal: React Query cancels in-flight requests when a
// component unmounts or a key changes, and the test's own static proxy surfaces
// that as a connection reset. Real application errors are what matter.
const real = pageProblems.filter(
  (m) => !/favicon|Failed to load resource.*(404|net::ERR_ABORTED|ERR_CONNECTION_RESET)/i.test(m)
)
check('no application errors or unhandled exceptions', real.length === 0, real.slice(0, 3).join(' // '))

await page.screenshot({ path: '/tmp/svc-identities.png', fullPage: true })
await browser.close()
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
