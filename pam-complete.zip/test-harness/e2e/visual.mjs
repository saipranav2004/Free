// Visual and responsive pass: header truncation, horizontal overflow at phone
// width, and the two modals the main run does not open.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const BASE = 'http://127.0.0.1:4180'
const token = readFileSync('/tmp/tok', 'utf8').trim()
let failures = 0
const check = (n, ok, d = '') => {
  if (!ok) failures++
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? `  — ${d}` : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})

const me = await (await fetch('http://127.0.0.1:8080/api/v1/auth/me', {
  headers: { Authorization: `Bearer ${token}` },
})).json()

async function session(width, height) {
  const ctx = await browser.newContext({ viewport: { width, height } })
  const page = await ctx.newPage()
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await page.evaluate(
    ([t, user]) =>
      sessionStorage.setItem(
        'pam_session',
        JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user })
      ),
    [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }]
  )
  await page.goto(`${BASE}/admin/services`, { waitUntil: 'networkidle' })
  await page.locator('tbody tr').first().waitFor({ timeout: 10000 })
  return { ctx, page }
}

// ── header truncation ────────────────────────────────────────────────────
{
  const { ctx, page } = await session(1440, 900)
  const headers = await page.locator('thead th').allInnerTexts()
  check('no column header is truncated with an ellipsis', !headers.some((h) => h.includes('…')), JSON.stringify(headers))
  // Measured, not eyeballed: a header whose text is wider than its cell is
  // clipped even without a visible ellipsis.
  const clipped = await page.evaluate(() =>
    [...document.querySelectorAll('thead th')]
      .filter((th) => !th.querySelector('.sr-only')) // a visually hidden label is meant to be clipped
      .map((th) => {
        const inner = th.querySelector('span, button') || th
        return { text: th.innerText.trim(), over: inner.scrollWidth - inner.clientWidth }
      })
      .filter((h) => h.over > 1)
  )
  check('no header text overflows its cell', clipped.length === 0, JSON.stringify(clipped))
  await page.screenshot({ path: '/tmp/svc-wide.png', fullPage: true })
  await ctx.close()
}

// ── phone width ──────────────────────────────────────────────────────────
for (const w of [400, 768, 1024]) {
  const { ctx, page } = await session(w, 900)
  const overflow = await page.evaluate(() => {
    const doc = document.documentElement
    const offenders = []
    if (doc.scrollWidth > doc.clientWidth + 1) {
      for (const el of document.querySelectorAll('body *')) {
        const r = el.getBoundingClientRect()
        if (r.width > 0 && r.right > doc.clientWidth + 1) {
          const s = getComputedStyle(el)
          // A table inside its own scroller is allowed to be wider.
          let p = el.parentElement
          let scrollable = s.overflowX === 'auto' || s.overflowX === 'scroll'
          while (p && !scrollable) {
            const ps = getComputedStyle(p)
            if (ps.overflowX === 'auto' || ps.overflowX === 'scroll') scrollable = true
            p = p.parentElement
          }
          if (!scrollable) offenders.push(`${el.tagName}.${el.className}`.slice(0, 70))
        }
      }
    }
    return { pageScrolls: doc.scrollWidth > doc.clientWidth + 1, offenders: offenders.slice(0, 4) }
  })
  check(`no horizontal page overflow at ${w}px`, !overflow.pageScrolls || overflow.offenders.length === 0, JSON.stringify(overflow))
  if (w === 400) await page.screenshot({ path: '/tmp/svc-400.png', fullPage: true })
  await ctx.close()
}

// ── the create flow and the show-once token hand-off ─────────────────────
{
  const { ctx, page } = await session(1440, 960)
  const unique = `e2e-svc-${Date.now().toString(36)}`

  await page.getByRole('button', { name: 'Register identity' }).click()
  await page.locator('#cs-name').waitFor({ timeout: 5000 })

  // A pasted human label should become a usable name rather than an error.
  await page.locator('#cs-name').fill('E2E Svc / Test')
  await page.locator('#cs-desc').click()
  await page.waitForTimeout(200)
  const slugged = await page.locator('#cs-name').inputValue()
  check('a pasted human label is slugified into an addressable name', slugged === 'e2e-svc-test', slugged)

  await page.locator('#cs-name').fill('BAD')
  await page.waitForTimeout(200)
  check(
    'an unaddressable name is reported before submitting',
    (await page.getByText(/Use 3.64 characters/).count()) > 0
  )

  await page.locator('#cs-name').fill(unique)
  await page.locator('#cs-desc').fill('created by the end-to-end run')
  await page.getByRole('button', { name: 'Register identity' }).last().click()
  await page.waitForTimeout(1500)

  // Creating goes straight into granting, because an identity with no scope
  // reads nothing.
  check(
    'creating an identity opens the grant form next',
    (await page.getByText('What this reaches today').count()) > 0
  )
  await page.keyboard.press('Escape')
  await page.waitForTimeout(500)

  const newRow = page.locator('tbody tr', { hasText: unique })
  await newRow.first().waitFor({ timeout: 10000 })
  await page.waitForFunction(
    (n) => {
      const tr = [...document.querySelectorAll('tbody tr')].find((r) => r.textContent.includes(n))
      return tr && !tr.textContent.includes('checking')
    },
    unique,
    { timeout: 10000 }
  )
  const newText = await newRow.first().innerText()
  check(
    'a brand-new identity reads as "Not set up", not "Ready"',
    newText.includes('Not set up'),
    newText.replace(/\n/g, ' | ')
  )

  // Mint a token through the UI and check the hand-off screen.
  await newRow.first().getByRole('button', { name: `Actions for ${unique}` }).click()
  await page.waitForTimeout(400)
  // SCOPED TO THE OPEN MENU, and by role.
  //
  // This used to be page.getByText('Mint a token').first(), which is
  // ambiguous: the identities table also carries the sentence "Has scopes but
  // nothing can authenticate as it. Mint a token." as a status hint. It
  // happened to resolve to the menu item while the menu rendered inside the
  // row; once the menu primitive began portalling its panel to document.body
  // (so a table's overflow can no longer clip it), the panel moved to the end
  // of the DOM and .first() started resolving to the hint instead. The click
  // then landed outside the menu, which dismissed it, and the assertion that
  // followed reported a broken product where only the DOM order had moved.
  const mintItem = page.locator('[role="menu"]').getByRole('menuitem', { name: 'Mint a token' }).first()
  await mintItem.click()
  await page.locator('#it-ttl').waitFor({ timeout: 5000 })
  await page.locator('#it-desc').fill('e2e deployment')
  await page.getByRole('button', { name: 'Mint token' }).last().click()
  await page.getByText('Copy this token now').waitFor({ timeout: 10000 })
  check('the token hand-off screen appears', true)

  const doneBtn = page.getByRole('button', { name: 'Done' })
  check('Done is blocked until the operator says they stored it', await doneBtn.isDisabled())

  const masked = await page.locator('p.break-all.font-mono').first().innerText()
  check('the token is masked by default', masked.includes('•'), masked.slice(0, 40))
  await page.getByRole('button', { name: /Reveal/ }).click()
  await page.waitForTimeout(200)
  const revealed = await page.locator('p.break-all.font-mono').first().innerText()
  check('Reveal shows the whole token', revealed.startsWith('pamsvc.') && !revealed.includes('•'), revealed.slice(0, 24) + '…')

  const snippet = await page.locator('pre').first().innerText()
  check('a ready-to-paste snippet carries the real token', snippet.includes(revealed.trim()))
  check('the snippet names the data-plane URL, not the admin one', snippet.includes('/api/v1/pam/svc'), snippet.split('\n').pop())

  await page.locator('input[type="checkbox"]').last().check()
  await page.waitForTimeout(150)
  check('acknowledging enables Done', await doneBtn.isEnabled())
  await page.screenshot({ path: '/tmp/svc-token.png' })
  await doneBtn.click()
  await page.waitForTimeout(800)

  await page.waitForFunction(
    (n) => {
      const tr = [...document.querySelectorAll('tbody tr')].find((r) => r.textContent.includes(n))
      return tr && !tr.textContent.includes('checking')
    },
    unique,
    { timeout: 10000 }
  )
  const afterMint = await page.locator('tbody tr', { hasText: unique }).first().innerText()
  check(
    'with a token but no scope the row says "No scope", the state that causes silent 403s',
    afterMint.includes('No scope'),
    afterMint.replace(/\n/g, ' | ')
  )
  await ctx.close()
}

await browser.close()
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
