import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// F.1 — the action registry behind ⌘K.
//
// The safety property is the one worth testing hardest: a privileged verb must
// NOT execute from a text box. A search field is a control you use without
// looking; that is the wrong input for "disable identity". Selecting such a
// verb navigates to the screen that owns it, and that screen's own
// confirmation is what performs it.

const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const adminToken = readFileSync('/tmp/tok', 'utf8').trim()
const userToken = readFileSync('/tmp/tok-user', 'utf8').trim()
const who = async (t) => (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + t } })).json()).data

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})

async function session(token) {
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 } })).newPage()
  const errors = []
  const mutations = []
  page.on('pageerror', (e) => errors.push(e.message))
  page.on('request', (r) => {
    const m = r.method()
    if (m === 'POST' || m === 'DELETE' || m === 'PATCH' || m === 'PUT') {
      mutations.push(`${m} ${new URL(r.url()).pathname}`)
    }
  })
  const me = await who(token)
  await page.goto(APP, { waitUntil: 'domcontentloaded' })
  await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
    accessToken: t, refreshToken: null,
    expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
  })), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])
  await page.goto(APP + '/resources', { waitUntil: 'networkidle' })
  await page.waitForTimeout(1200)
  return { page, errors, mutations }
}

const openPalette = async (page, text) => {
  await page.keyboard.press('Meta+k')
  await page.waitForTimeout(400)
  const box = page.getByPlaceholder(/search/i).first()
  await box.fill('')
  await box.type(text, { delay: 30 })
  await page.waitForTimeout(700)
  return (await page.locator('[role="listbox"], [role="option"]').first().isVisible().catch(() => false))
}

// ── As an admin ───────────────────────────────────────────────────────────
console.log('=== admin ===')
{
  const { page, errors, mutations } = await session(adminToken)

  await openPalette(page, 'revoke')
  const opts = await page.getByRole('option').allInnerTexts()
  check('typing a verb surfaces an action', opts.some((o) => /revoke a service token/i.test(o)),
    opts.slice(0, 3).join(' | '))
  check('actions are grouped as Actions',
    /Actions/.test(await page.locator('[role="listbox"]').first().innerText().catch(() => '')))

  // The safety property.
  mutations.length = 0
  await page.getByRole('option').filter({ hasText: /revoke a service token/i }).first().click()
  await page.waitForTimeout(1800)
  check('selecting a destructive verb runs NO mutation', mutations.length === 0,
    mutations.join(', ') || 'none')
  check('it navigates to the screen that owns the action',
    /\/admin\/services/.test(page.url()), page.url().replace(APP, ''))

  // A non-destructive verb still just navigates.
  await openPalette(page, 'pair a device')
  await page.getByRole('option').first().click()
  await page.waitForTimeout(1500)
  check('a safe verb navigates too', /settings/.test(page.url()), page.url().replace(APP, ''))

  check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))
  await page.context().close()
}

// ── As a standard operator ────────────────────────────────────────────────
console.log('\n=== standard operator ===')
{
  const { page, errors } = await session(userToken)
  await openPalette(page, 'revoke')
  const opts = await page.getByRole('option').allInnerTexts()
  check('admin-only verbs are not offered to an operator',
    !opts.some((o) => /revoke a service token|disable a service identity|kill a session/i.test(o)),
    opts.slice(0, 3).join(' | ') || 'no results')

  await openPalette(page, 'vault')
  const own = await page.getByRole('option').allInnerTexts()
  check('verbs they CAN use are still offered', own.some((o) => /browse the vault/i.test(o)),
    own.slice(0, 3).join(' | '))
  check('no page errors as an operator', errors.length === 0, errors.slice(0, 2).join(' | '))
  await page.context().close()
}

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
