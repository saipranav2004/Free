import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080', APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox','--no-proxy-server'] })
const page = await (await browser.newContext({ viewport: { width: 1400, height: 1200 } })).newPage()
await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t,u]) => sessionStorage.setItem('pam_session', JSON.stringify({accessToken:t,refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:u})), [token,{user_id:me.user_id,username:me.username,roles:me.roles,email:me.email}])
await page.goto(APP + '/settings?tab=devices', { waitUntil: 'networkidle' })
await page.waitForTimeout(1800)
const btn = page.getByRole('button', { name: /revoked device/i })
console.log('revoked disclosure present:', await btn.count() > 0, await btn.first().innerText().catch(()=>''))
await btn.first().click()
await page.waitForTimeout(500)
const txt = await page.locator('main').innerText()
console.log('shows the revoked machine:', /old-macbook/.test(txt))
console.log(txt.split('\n').filter(l=>/old-macbook|revoked/i.test(l)).join(' | '))
await page.screenshot({ path: '/tmp/devices-revoked.png', fullPage: true })
await browser.close()
