// Every route the Postman collection targets, resolved against the LIVE
// router. The question is only "does this endpoint still exist and is it
// mounted on the plane the collection assumes" — a 404 from gin's own
// no-route handler is the failure; a 400/401/403 is the endpoint answering.
import { readFileSync } from 'node:fs'

const col = JSON.parse(
  readFileSync(
    '/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/v1/IAM/PAM_Vault_E2E.postman_collection.json',
    'utf8'
  )
)
const token = readFileSync('/tmp/tok', 'utf8').trim()
const svcToken = JSON.parse(readFileSync('/tmp/mint.json', 'utf8')).data.token
const safeId = readFileSync('/tmp/safeid', 'utf8').trim()

// Substitutions so a real path is exercised rather than a literal {{var}}.
const vars = {
  base_url: 'http://127.0.0.1:8080',
  vault_url: 'http://127.0.0.1:8080',
  safe_id: safeId,
  restricted_safe_id: safeId,
  safe_name: 'prod-db',
  restricted_safe_name: 'prod-db',
  service_name: 'billing-api-prod',
  cred_password_id: '1fee2221-7946-4357-ad81-58dc736b8a36',
  cred_apikey_id: '1fee2221-7946-4357-ad81-58dc736b8a36',
  cred_kv_id: '1fee2221-7946-4357-ad81-58dc736b8a36',
  resource_id: '00000000-0000-0000-0000-000000000000',
  grant_id: '00000000-0000-0000-0000-000000000000',
  token_id: '0000000000000000',
  username: 'root',
}

function* walk(items, path = '') {
  for (const it of items) {
    if (it.item) yield* walk(it.item, `${path}/${it.name}`)
    else yield [`${path}/${it.name}`, it]
  }
}

const subst = (s) => s.replace(/\{\{(\w+)\}\}/g, (m, k) => (k in vars ? vars[k] : m))

let missing = 0
let checked = 0
const rows = []

for (const [name, it] of walk(col.item)) {
  const r = it.request || {}
  const rawUrl = typeof r.url === 'string' ? r.url : r.url?.raw
  if (!rawUrl) continue
  const url = subst(rawUrl)
  if (/\{\{/.test(url)) {
    rows.push(['SKIP', '—', name, 'unresolved variable'])
    continue
  }
  // GET/DELETE only for anything destructive-looking is not enough: a real
  // DELETE would mutate state, so those are sent with ids that do not exist.
  const method = r.method || 'GET'
  const headers = { 'Content-Type': 'application/json' }
  const isDataPlane = url.includes('/pam/svc/')
  if (isDataPlane) headers['X-Service-Token'] = svcToken
  else headers.Authorization = `Bearer ${token}`

  let body
  const raw = r.body?.raw
  if (raw && method !== 'GET') {
    try {
      body = JSON.stringify(JSON.parse(subst(raw)))
    } catch {
      body = subst(raw)
    }
  }

  let status
  let text = ''
  try {
    const res = await fetch(url, { method, headers, body })
    status = res.status
    text = (await res.text()).slice(0, 120)
  } catch (e) {
    status = 'ERR'
    text = String(e.message)
  }
  checked++
  // gin's no-route handler is the only thing that means "the endpoint is gone".
  let routeGone = status === 404 && /Not found|no route/i.test(text) && !/secret|credential|identity|token|grant/i.test(text)
  // Some collection entries EXPECT a 404 — they assert that an operation is
  // deliberately unsupported (credential deletion is the one that exists
  // today). Counting those as "the endpoint disappeared" made this suite exit
  // non-zero on a completely healthy router, which trains everyone to ignore
  // its exit code. An entry whose own name says it expects 404/405 is passing
  // when it gets one.
  if (routeGone && /unsupported|-> 404|404\/405/i.test(name)) routeGone = false
  if (routeGone) missing++
  rows.push([routeGone ? 'GONE' : 'OK', status, name, text.replace(/\s+/g, ' ').slice(0, 80)])
}

// Restore the shared fixture this run mutates.
//
// The collection's last step disables billing-api-prod to prove that a disable
// kills every token at once. That is the right thing for it to check and the
// wrong thing to leave behind: billing-api-prod is a seeded fixture that
// ui.mjs reads as a READY identity, so running this suite first made that one
// fail with a "posture is Disabled" that says nothing about either feature.
// A suite that mutates shared state puts it back.
{
  const base = 'http://127.0.0.1:8080/api/v1/pam/admin/services/billing-api-prod'
  const h = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }
  await fetch(`${base}/enable`, { method: 'POST', headers: h })
  // The disable revoked its tokens and enabling does not resurrect them — by
  // design — so the fixture needs a fresh one to read as Ready again.
  await fetch(`${base}/tokens`, {
    method: 'POST', headers: h,
    body: JSON.stringify({ ttl_days: 30, description: 'fixture restored by collection-routes.mjs' }),
  })
  console.log('  restored billing-api-prod (enabled + one fresh token)')
}

for (const [verdict, status, name, note] of rows) {
  console.log(`  ${verdict.padEnd(4)} ${String(status).padEnd(4)} ${name}`)
  if (verdict === 'GONE') console.log(`         ${note}`)
}
console.log(`\n${checked} collection requests resolved against the live router; ${missing} endpoint(s) no longer exist`)
process.exit(missing === 0 ? 0 : 1)
