import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// Group G, driven against the real backend.
//
// The failure this guards against is subtle and was the status quo: a page
// that LOOKS server-paged because it shows a pager, while the search box
// searches the rows it happens to hold and reports "no matches" for a session
// that exists on page 4. So every check here is about whether the work
// actually reached the SERVER — counted requests, not rendered pixels.

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'

const api = async (p) => {
  const r = await fetch(`${API}/api/v1/${p}`, { headers: { Authorization: 'Bearer ' + token } })
  const j = await r.json()
  if (!r.ok) throw new Error(`${p} -> ${r.status} ${JSON.stringify(j).slice(0, 200)}`)
  return j.data
}

const me = await api('auth/me')
const all = await api('pam/sessions/mine?page=1&page_size=1')
const TOTAL = all.pagination.total
console.log(`SERVER: ${TOTAL} sessions for root\n`)

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

// ── The API contract, before any browser is involved ──────────────────────
console.log('=== API: paging, sorting, search ===')
const p1 = await api('pam/sessions/mine?page=1&page_size=10&sort=started_at&order=desc')
const p2 = await api('pam/sessions/mine?page=2&page_size=10&sort=started_at&order=desc')
check('page 1 and page 2 return different rows',
  p1.sessions[0].id !== p2.sessions[0].id)
check('pages do not overlap',
  !p1.sessions.some((a) => p2.sessions.some((b) => b.id === a.id)))
check('total is the whole table, not the page', p1.pagination.total === TOTAL,
  `${p1.pagination.total} vs ${TOTAL}`)

const asc = await api('pam/sessions/mine?page=1&page_size=5&sort=started_at&order=asc')
const desc = await api('pam/sessions/mine?page=1&page_size=5&sort=started_at&order=desc')
check('sort order is honoured server-side',
  asc.sessions[0].id !== desc.sessions[0].id &&
    new Date(asc.sessions[0].started_at) < new Date(desc.sessions[0].started_at))

const byName = await api('pam/sessions/mine?page=1&page_size=5&sort=resource_name&order=asc')
const names = byName.sessions.map((s) => s.resource_name)
check('sorting by a non-default column works',
  JSON.stringify(names) === JSON.stringify([...names].sort()), names.join(','))

// No sort parameter must keep the historical default: newest first.
const dflt = await api('pam/sessions/mine?page=1&page_size=5')
const stamps = dflt.sessions.map((s) => new Date(s.started_at).getTime())
check('no sort parameter still means newest first',
  stamps.every((t, i) => i === 0 || stamps[i - 1] >= t), stamps.join(' '))

const searched = await api('pam/sessions/mine?page=1&page_size=50&q=alpha-db')
check('search reaches the server and narrows the TOTAL',
  searched.pagination.total > 0 && searched.pagination.total < TOTAL,
  `${searched.pagination.total} of ${TOTAL}`)
check('every searched row actually matches',
  searched.sessions.every((s) => `${s.resource_name} ${s.username} ${s.source_ip || ''}`.toLowerCase().includes('alpha-db')))

// A search that matches nothing must be an empty page, not everything.
const none = await api('pam/sessions/mine?page=1&page_size=50&q=zzzznotathing')
check('a search with no matches returns zero, not the unfiltered table',
  none.pagination.total === 0 && none.sessions.length === 0)

// The allowlist: a hostile sort must be ignored, not executed and not a 500.
const hostile = await api('pam/sessions/mine?page=1&page_size=3&sort=' +
  encodeURIComponent('started_at; DROP TABLE pam_connection_sessions'))
check('a hostile sort parameter falls back to the default instead of erroring',
  hostile.sessions.length === 3)
const stillThere = await api('pam/sessions/mine?page=1&page_size=1')
check('the table is still there afterwards', stillThere.pagination.total === TOTAL)

// Paging must be STABLE: walking every page sees each row exactly once.
const seen = new Set()
let dupes = 0
for (let page = 1; page <= Math.ceil(TOTAL / 25); page++) {
  const r = await api(`pam/sessions/mine?page=${page}&page_size=25&sort=status&order=asc`)
  for (const s of r.sessions) {
    if (seen.has(s.id)) dupes++
    seen.add(s.id)
  }
}
check('walking every page sees each row exactly once',
  dupes === 0 && seen.size === TOTAL,
  `${seen.size} distinct, ${dupes} repeats, of ${TOTAL} — a sort with no unique tiebreaker skips and repeats here`)

// ── The browser: does the console actually use any of it ──────────────────
console.log('\n=== Console ===')
const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } })
const page = await ctx.newPage()
const errors = []
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0, 160)) })

const requests = []
page.on('request', (r) => {
  if (r.url().includes('/api/v1/pam/sessions/mine') || r.url().includes('/api/v1/pam/admin/sessions')) {
    requests.push(new URL(r.url()).search)
  }
})

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

await page.goto(APP + '/sessions', { waitUntil: 'networkidle' })
await page.waitForTimeout(1200)
// Turn off "Active only" so the full table is in play.
await page.getByLabel(/active only/i).uncheck().catch(async () => {
  await page.getByText('Active only').first().click().catch(() => {})
})
await page.waitForTimeout(1500)

requests.length = 0
const rowCount = async () => page.locator('tbody tr').count()
const firstRow = async () => (await page.locator('tbody tr').first().innerText()).replace(/\s+/g, ' ').trim()

const initialRows = await rowCount()
check('the page asks for a PAGE, not the whole table',
  initialRows > 0 && initialRows <= 25, `${initialRows} rows rendered`)

// Paging: click next, and confirm a request went out carrying page=2.
const before = await firstRow()
await page.getByRole('button', { name: /next page|next/i }).first().click().catch(() => {})
await page.waitForTimeout(1500)
check('paging sends page=2 to the server',
  requests.some((q) => q.includes('page=2')), requests.slice(-3).join(' | '))
check('paging actually changes the rows', (await firstRow()) !== before)

// Sorting: click a column header, confirm sort travels.
requests.length = 0
// The header button carries aria-label="Sort by <column>", which REPLACES
// its text as the accessible name — so matching on "Resource" finds nothing.
await page.getByRole('button', { name: 'Sort by Resource' }).first().click()
await page.waitForTimeout(1500)
check('sorting sends sort= to the server rather than reordering the page',
  requests.some((q) => q.includes('sort=resource_name')), requests.slice(-3).join(' | '))

// Search: type, confirm ONE request (debounced) carrying q=.
requests.length = 0
const box = page.getByPlaceholder(/search resource, user or protocol/i)
await box.click()
await box.type('alpha-db', { delay: 40 })
await page.waitForTimeout(1600)
const searchReqs = requests.filter((q) => q.includes('q=alpha'))
check('search reaches the server', searchReqs.length > 0, requests.slice(-2).join(' | '))
check('typing 8 characters is debounced into at most 2 requests',
  searchReqs.length <= 2, `${searchReqs.length} requests for 8 keystrokes`)
const searchedRows = await rowCount()
check('the searched list shows only matches',
  searchedRows > 0 && (await page.locator('tbody').innerText()).toLowerCase().includes('alpha-db'))

// A search with no matches must say "no match", not "no sessions".
await box.fill('')
await box.type('zzzznotathing', { delay: 20 })
await page.waitForTimeout(1600)
// Read the table region, not the whole main: the MFA banner at the top of
// every page would otherwise be what this assertion is looking at.
const emptyText = (await page.locator('main').innerText()).toLowerCase()
check('an empty search result says no MATCH, not no sessions',
  emptyText.includes('no session matches') && !emptyText.includes('no sessions are open'),
  emptyText.slice(0, 120).replace(/\n/g, ' '))

// content-visibility is on the rows.
await box.fill('')
await page.waitForTimeout(1500)
const cv = await page.locator('tbody tr').first().evaluate((el) => getComputedStyle(el).contentVisibility)
check('off-screen rows are skippable (content-visibility: auto)', cv === 'auto', `computed: ${cv}`)

// Prefetch on intent: hovering a service identity warms its drawer.
console.log('\n=== prefetch on intent ===')
const idReqs = []
page.on('request', (r) => {
  if (/\/services\/[^/]+\/(grants|tokens)/.test(r.url())) idReqs.push(r.url())
})
await page.goto(APP + '/admin/services', { waitUntil: 'networkidle' })
await page.waitForTimeout(1200)
idReqs.length = 0
const idRow = page.locator('tbody tr').first()
await idRow.hover()
await page.waitForTimeout(600)
check('resting on a row prefetches the drawer it would open',
  idReqs.length >= 2, `${idReqs.length} prefetch requests`)

// And a pointer passing THROUGH must not.
idReqs.length = 0
const rows = page.locator('tbody tr')
const n = Math.min(await rows.count(), 6)
for (let i = 0; i < n; i++) {
  await rows.nth(i).hover()
  await page.waitForTimeout(40) // well under the 150ms intent threshold
}
await page.waitForTimeout(300)
check('a pointer passing across rows does not fire a request per row',
  idReqs.length <= 2, `${idReqs.length} requests for ${n} rows crossed quickly`)

check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
