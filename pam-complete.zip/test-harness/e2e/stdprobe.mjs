import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
const token = readFileSync('/tmp/tok-user','utf8').trim()
const API='http://127.0.0.1:8080', APP='http://127.0.0.1:4180'
const me=(await (await fetch(`${API}/api/v1/auth/me`,{headers:{Authorization:'Bearer '+token}})).json()).data
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox','--no-proxy-server']})
const page=await (await b.newContext({viewport:{width:1500,height:1100}})).newPage()
await page.goto(APP,{waitUntil:'domcontentloaded'})
await page.evaluate(([t,u])=>sessionStorage.setItem('pam_session',JSON.stringify({accessToken:t,refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:u})),[token,{user_id:me.user_id,username:me.username,roles:me.roles,email:me.email}])
await page.goto(APP+'/resources',{waitUntil:'networkidle'})
await page.waitForTimeout(2200)
const row = page.locator('tbody tr').first()
const reqs=[]
page.on('request',r=>{ if(r.url().includes('/pam/')) reqs.push(r.method()+' '+new URL(r.url()).pathname) })
await row.getByRole('button',{name:/connect/i}).first().click()
await page.waitForTimeout(2500)
await page.screenshot({path:'/tmp/std-connect-menu.png', fullPage:true})
console.log('requests after click:', reqs.join(' | ') || 'NONE')
console.log('body text after click:')
console.log((await page.locator('body').innerText()).replace(/\n{2,}/g,'\n').slice(0,900))
await b.close()
