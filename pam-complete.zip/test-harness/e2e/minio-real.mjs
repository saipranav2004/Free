import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The brokered web session against REAL MinIO.
//
// e2e/web-recording.mjs drives a stub shaped like the Object Browser. That
// proves the proxy, the recorder and the storage path, and it proves nothing
// about MinIO itself — its actual CSP, its actual websockets, its actual
// login. The reported bug ("the object list spins forever", a 403 reading
// "websocket: request origin not allowed by Upgrader.CheckOrigin") lived in
// exactly that gap. So this runs the same journey against a MinIO server
// built from source, with its Console UI embedded.

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
// Known only to this test so it can assert the secret never reaches the
// browser. PAM reads it from the vault; the browser must never see it.
const MINIO_PASS = 'pamtest-local-only-123'

const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  const j = await r.json().catch(() => ({}))
  return { ok: r.ok, status: r.status, data: j.data, raw: j }
}

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

// This suite needs a real MinIO listening on 127.0.0.1:9001 (see
// harness/start-minio.sh). Skipped rather than failed when it is absent: a
// missing optional fixture is not a regression, and a suite that goes red on
// a machine without MinIO trains people to ignore it.
const minioUp = await fetch('http://127.0.0.1:9001/', { signal: AbortSignal.timeout(3000) })
  .then((r) => r.ok)
  .catch(() => false)
if (!minioUp) {
  console.log('SKIP — no MinIO on 127.0.0.1:9001. Start one with harness/start-minio.sh.')
  process.exit(0)
}

// ── Open the brokered session ─────────────────────────────────────────────
const open = await api('pam/resources/minio-real/web-session', { method: 'POST', body: '{}' })
check('a brokered session opens against the real MinIO resource (minio-real)', open.ok, `http ${open.status}`)
if (!open.ok) { console.log(JSON.stringify(open.raw).slice(0, 400)); process.exit(1) }
const { launch_url, session_id, auth_strategy } = open.data
// The whole point of brokering: PAM logs in server-side with the vaulted
// credential, so the operator never handles it. That credential is stored in
// ENVELOPE form ({"ciphertext":…,"nonce":…} with a KMS-wrapped data key and
// the row's identity bound in as AAD) — the exact shape that used to fail
// with "illegal base64 data at input byte 0" before ResourceService learned
// to open it. So a successful login here exercises that fix against a real
// target, not a fixture.
check('PAM used its MinIO auto-login strategy, not a passthrough',
  auth_strategy === 'minio_console', `auth_strategy=${auth_strategy}`)
console.log(`  session ${session_id}`)
console.log(`  launch  ${launch_url}`)

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  // The proxy routes by subdomain; map any *.pam.local to loopback so no DNS
  // or /etc/hosts entry is needed.
  //
  // --no-proxy-server is load-bearing, and cost an hour to find. This
  // container exports HTTPS_PROXY for its own outbound access, and NO_PROXY
  // covers 127.0.0.1 but not *.pam.local — so Chromium sent the brokered
  // session's WebSocket UPGRADE to that proxy, which answered 502. Plain HTTP
  // to the same host went through fine, so the page loaded, the login worked,
  // and only the WebSocket failed: an exact imitation of the bug under test,
  // produced entirely by the test environment. Without this flag the suite
  // reports a PAM failure that is not PAM's.
  args: [
    '--no-sandbox',
    '--no-proxy-server',
    '--host-resolver-rules=MAP *.pam.local 127.0.0.1',
  ],
})
const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 } })).newPage()

// Everything that matters is in the network log, so record it all.
const wsEvents = []
const forbidden = []
const replayPosts = []
const pageErrors = []
page.on('websocket', (ws) => {
  // One record per socket, captured by closure. Looking the record up by URL
  // (the first version of this) makes every socket on the same path share one
  // entry, so a failed handshake is silently overwritten by a later success.
  const rec = { url: ws.url(), closed: false, error: null }
  wsEvents.push(rec)
  ws.on('socketerror', (e) => { rec.error = String(e) })
  ws.on('close', () => { rec.closed = true })
})
let loginDone = false
page.on('response', (r) => {
  const u = new URL(r.url())
  // MinIO answers 403 on /api/v1/session before anyone has logged in. That is
  // its way of saying "no session yet", not a refusal by the proxy, so only
  // refusals AFTER login count.
  if (r.status() === 403 && loginDone) forbidden.push(`403 ${u.pathname}`)
  if (u.pathname.includes('/__pam/replay')) replayPosts.push(u.pathname)
})
page.on('request', (r) => {
  if (r.url().includes('/__pam/replay') && r.method() === 'POST') replayPosts.push('POST replay')
})
page.on('pageerror', (e) => pageErrors.push(e.message))

console.log('\n=== the real MinIO Console, through the proxy ===')
await page.goto(launch_url, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(4000)

const title = await page.title()
check('the real MinIO Console renders through the proxy', /minio/i.test(title), `title "${title}"`)

// Its CSP is the strict one the beacon had to be nonced into.
const cspSeen = await page.evaluate(() => {
  const m = document.querySelector('meta[http-equiv="Content-Security-Policy"]')
  return m ? m.content : null
})
const replayScript = await page.locator('script[src*="__pam/replay"], script[nonce]').count()
check('PAM injected its recorder into a page MinIO protects with a CSP',
  replayScript > 0, `${replayScript} injected script tag(s); meta CSP: ${cspSeen || '(header only)'}`)

// ── Already logged in: PAM did it server-side ────────────────────────────
console.log('\n=== the operator arrives already authenticated ===')
loginDone = true
const loginFormShown = await page
  .locator('#accessKey, input[name="accessKey"]')
  .first()
  .isVisible({ timeout: 4000 })
  .catch(() => false)
check('the operator is NOT shown a login form — the credential never reached the browser',
  !loginFormShown)

const loggedIn = await page.locator('text=/Object Browser|Buckets/i').first().isVisible({ timeout: 10000 }).catch(() => false)
check('the session lands inside the Object Browser, authenticated as the vaulted account', loggedIn,
  `url ${new URL(page.url()).pathname}`)

// And the secret really is absent from what the browser was given.
const pageHtml = await page.content()
check('the vaulted secret appears nowhere in the delivered page',
  !pageHtml.includes(MINIO_PASS))

// ── Drive the Object Browser: create a bucket, then list it ──────────────
console.log('\n=== driving the Object Browser ===')
const bucket = `pam-e2e-${Date.now().toString(36)}`
// Created through the Console's own API from inside the page rather than by
// driving its "Create Bucket" dialog: the request then travels the brokered
// session exactly as the UI's would, with the session's cookies, and the test
// does not break when MinIO reshuffles a route.
const made = await page.evaluate(async (name) => {
  const r = await fetch('/api/v1/buckets', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, versioning: { enabled: false }, locking: false }),
  })
  return { status: r.status, body: (await r.text()).slice(0, 200) }
}, bucket)
check('a WRITE through the brokered session reaches MinIO', made.status === 201 || made.status === 200,
  `http ${made.status} ${made.body}`)
await page.goto(new URL('/browser', page.url()).toString(), { waitUntil: 'domcontentloaded' }).catch(() => {})
await page.waitForTimeout(4000)

const bodyText = await page.locator('body').innerText().catch(() => '')
check('the bucket list loads — it does not spin forever', /bucket/i.test(bodyText) && !/loading/i.test(bodyText.slice(0, 200)),
  bodyText.replace(/\s+/g, ' ').slice(0, 140))
check('the bucket created through the brokered session is listed',
  bodyText.includes(bucket), `looking for ${bucket}`)

// ── THE BUG ───────────────────────────────────────────────────────────────
console.log('\n=== the reported failure ===')
check('no 403 anywhere in the session', forbidden.length === 0, forbidden.join(', ') || 'none')
const wsOk = wsEvents.filter((w) => !w.error)
check('every websocket the Console opened was accepted',
  wsEvents.length === 0 || wsEvents.every((w) => !w.error),
  wsEvents.length ? wsEvents.map((w) => `${new URL(w.url).pathname}${w.error ? ' ERR:' + w.error : ' ok'}`).join(', ') : 'the Console opened none on these screens')

check('no page errors inside the brokered session', pageErrors.length === 0, pageErrors[0] || '')

// ── The recording ─────────────────────────────────────────────────────────
console.log('\n=== the recording of a real MinIO session ===')
check('the recorder posted frames back', replayPosts.length > 0, `${replayPosts.length} posts`)
await page.waitForTimeout(2000)
await browser.close()

await api(`pam/web-sessions/${session_id}/end`, { method: 'POST', body: '{}' }).catch(() => {})
await new Promise((r) => setTimeout(r, 2500))

const recs = await api(`pam/admin/recordings?session_id=${session_id}`)
const rows = recs.data?.recordings || recs.data?.items || recs.data || []
const rec = Array.isArray(rows) ? rows.find((r) => r.session_id === session_id) || rows[0] : null
check('a recording row exists for the real MinIO session', !!rec,
  rec ? JSON.stringify({ format: rec.format, status: rec.status, size: rec.size_bytes }) : `${Array.isArray(rows) ? rows.length : 0} rows`)
if (rec) {
  check('it is a VISUAL recording of MinIO, not a transaction log', rec.format === 'rrweb', `format=${rec.format}`)
  check('it has frames in it', (rec.size_bytes || 0) > 1000, `${rec.size_bytes} bytes`)
}

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) { failed.forEach((f) => console.log(`  FAILED: ${f.name} — ${f.detail}`)); process.exit(1) }
