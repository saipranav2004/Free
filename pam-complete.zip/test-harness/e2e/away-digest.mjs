import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'

// F.2 — "while you were away".
//
// Three things have to be true for this to be a feature rather than a banner:
// it appears when there is something to say, dismissing it is a real write
// that survives a reload, and after dismissal it stays gone. The third is the
// one that broke live — the request auditor files a row for the dismissal
// itself, so the card came back reporting its own acknowledgement.

const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const adminToken = readFileSync('/tmp/tok', 'utf8').trim()
const userToken = readFileSync('/tmp/tok-user', 'utf8').trim()

const psql = (sql) =>
  execFileSync('psql', ['-h', '/tmp', '-p', '5433', '-U', 'postgres', '-d', 'postgres', '-tAc', sql], {
    encoding: 'utf8',
  }).trim()

const who = async (t) =>
  (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + t } })).json()).data

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})

async function session(token) {
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 } })).newPage()
  const errors = []
  page.on('pageerror', (e) => errors.push(e.message))
  const me = await who(token)
  await page.goto(APP, { waitUntil: 'domcontentloaded' })
  await page.evaluate(
    ([t, u]) =>
      sessionStorage.setItem(
        'pam_session',
        JSON.stringify({
          accessToken: t,
          refreshToken: null,
          expiresAt: new Date(Date.now() + 36e5).toISOString(),
          user: u,
        })
      ),
    [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }]
  )
  return { page, errors, me }
}

const dash = async (page) => {
  await page.goto(APP + '/', { waitUntil: 'networkidle' })
  await page.waitForTimeout(1500)
}

// ── Admin: a window with real events in it ────────────────────────────────
console.log('=== admin — a digest with something to say ===')
{
  const { page, errors, me } = await session(adminToken)

  // Rewind the anchor rather than seeding fake audit rows: the trail already
  // holds a session's worth of real activity, and a digest tested against
  // invented rows proves nothing about the queries that read the real ones.
  psql(`UPDATE pam.pam_users SET digest_seen_at = now() - interval '6 hours' WHERE user_id = '${me.user_id}'`)

  const digest = await (await fetch(`${API}/api/v1/pam/insights/away`, {
    headers: { Authorization: 'Bearer ' + adminToken },
  })).json()
  const d = digest.data
  check('API answers with a window, not all of history', !d.first_visit && !!d.since, d.since)
  check('the window holds real events', d.total_events > 0, `${d.total_events} events`)

  await dash(page)
  const card = page.getByTestId('away-digest')
  check('the card renders on the dashboard', await card.isVisible())

  const text = await card.innerText().catch(() => '')
  check('it names the window rather than just a count', /since|last 7 days/i.test(text), text.split('\n')[1] || '')
  check('the hero figures are present', /events/.test(text) && /sessions/.test(text), '')
  check('it does not print a bare "3 critical events" count',
    !/\d+\s+critical\b/i.test(text), '')

  // Every figure is a way in, not a dead number.
  const links = await card.locator('a[href]').count()
  check('the figures link through to the screens that own them', links >= 2, `${links} links`)

  check('no page error while rendering the digest', errors.length === 0, errors[0] || '')

  // ── Dismissal ───────────────────────────────────────────────────────────
  const before = psql(`SELECT coalesce(digest_seen_at::text,'') FROM pam.pam_users WHERE user_id = '${me.user_id}'`)
  await page.getByTestId('away-digest-dismiss').click()
  await page.waitForTimeout(2000)
  const after = psql(`SELECT coalesce(digest_seen_at::text,'') FROM pam.pam_users WHERE user_id = '${me.user_id}'`)
  check('dismissing moves the anchor server-side', after !== before && after !== '', after)

  check('the card goes away once acknowledged', !(await card.isVisible().catch(() => false)))

  // The regression. Reading and dismissing the digest are themselves audited
  // requests; if the digest counts them, this reload brings the card straight
  // back reporting the dismissal it just performed.
  await dash(page)
  const backAgain = await page.getByTestId('away-digest').isVisible().catch(() => false)
  const afterJson = await (await fetch(`${API}/api/v1/pam/insights/away`, {
    headers: { Authorization: 'Bearer ' + adminToken },
  })).json()
  check('after a reload it stays gone — the digest does not count its own dismissal',
    !backAgain, `total_events=${afterJson.data.total_events}`)

  await page.context().close()
}

// ── Standard user: scoped, and never told about anyone else ───────────────
console.log('=== operator — scoped to their own activity ===')
{
  const { page, errors, me } = await session(userToken)
  psql(`UPDATE pam.pam_users SET digest_seen_at = NULL WHERE user_id = '${me.user_id}'`)

  const mine = (await (await fetch(`${API}/api/v1/pam/insights/away`, {
    headers: { Authorization: 'Bearer ' + userToken },
  })).json()).data
  // The admin's anchor is cleared too, so both digests cover the SAME window.
  // Comparing a first visit against a just-dismissed digest would compare two
  // different spans of time and prove nothing about scoping.
  psql(`UPDATE pam.pam_users SET digest_seen_at = NULL WHERE username = 'root'`)
  const fleet = (await (await fetch(`${API}/api/v1/pam/insights/away`, {
    headers: { Authorization: 'Bearer ' + adminToken },
  })).json()).data

  check('an operator reaches the endpoint at all (it is not admin-gated)', !!mine, '')
  check('a first visit is bounded, not the whole trail', mine.first_visit === true, mine.since)
  check("an operator's digest is a subset of the fleet's, over the same window",
    mine.total_events < fleet.total_events,
    `mine=${mine.total_events} fleet=${fleet.total_events}`)
  const others = (mine.top_actors || []).filter((a) => a.label !== me.username && a.label !== me.user_id)
  check('it never names another account', others.length === 0, JSON.stringify(others))

  await dash(page)
  check('no page error on the operator dashboard', errors.length === 0, errors[0] || '')
  await page.context().close()
}

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  failed.forEach((f) => console.log(`  FAILED: ${f.name} — ${f.detail}`))
  process.exit(1)
}
