import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// DOES THE BROKERED WEBSOCKET CONNECT OVER wss://, THROUGH A REAL TLS INGRESS?
//
// The reported failure — the MinIO Console loading fine while
// wss://…/ws/objectManager fails and retries forever — is not reproducible on
// loopback, because PAM serves plain HTTP and the whole fault lives in the
// TLS terminator every real deployment puts in front of it. So this drives
// the same brokered session through two ingress shapes that differ by exactly
// three nginx directives:
//
//   :8443  proxy_http_version 1.1 + Upgrade + Connection  → correct
//   :9443  those three lines missing                        → the reported bug
//
// The asymmetry that makes the bug so confusing is asserted here too: on the
// broken lane EVERY HTTP request still succeeds (the page renders, auto-login
// works, buckets list) and only the WebSocket dies. That is why it reads as a
// PAM bug and is not one — `Sec-WebSocket-Key` is an end-to-end header and
// survives any proxy, while `Connection` and `Upgrade` are hop-by-hop and
// must be reinstated by every hop. PAM sees a request that wants a WebSocket
// and is not marked as an upgrade, which is unanswerable.
//
// See internal/webproxy/upgrade_stripped.go: PAM detects that exact shape and
// logs the nginx lines to add, which the broken lane asserts below.
const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  const j = await r.json().catch(() => ({}))
  return { ok: r.ok, status: r.status, data: j.data, raw: j }
}

const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok, d }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }

const minioUp = await fetch('http://127.0.0.1:9001/', { signal: AbortSignal.timeout(3000) }).then((r) => r.ok).catch(() => false)
if (!minioUp) { console.log('SKIP — no MinIO on 127.0.0.1:9001 (harness/start-minio.sh)'); process.exit(0) }

// One lane: open a session, drive it over the given ingress port, report what
// the Console's own websockets did.
async function lane(port, label) {
  console.log(`\n=== ${label} (port ${port}) ===`)
  const open = await api('pam/resources/minio-real/web-session', { method: 'POST', body: '{}' })
  if (!open.ok) { check(`${label}: a session opens`, false, `http ${open.status}`); return null }
  const { launch_url, web_proxy_session_id } = open.data

  // The launch URL is issued for the CORRECT lane's port, so the broken lane
  // is reached by rewriting the port — same host, same token, same server.
  const url = launch_url.replace(/:\d+/, ':' + port)

  const browser = await chromium.launch({
    executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    args: [
      '--no-sandbox',
      // See e2e/minio-real.mjs: this container exports HTTPS_PROXY, and
      // without this Chromium sends the session's WebSocket UPGRADE to that
      // proxy, which answers 502 — an imitation of the bug under test,
      // produced entirely by the test environment.
      '--no-proxy-server',
      '--host-resolver-rules=MAP *.pam.test 127.0.0.1',
      '--ignore-certificate-errors',
    ],
  })
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 }, ignoreHTTPSErrors: true })).newPage()

  const sockets = []
  page.on('websocket', (ws) => {
    // One record per socket, captured by closure — looking it up by URL lets
    // a later success overwrite an earlier failure on the same path.
    const rec = { url: ws.url(), error: null, closed: false, frames: 0 }
    sockets.push(rec)
    ws.on('socketerror', (e) => { rec.error = String(e) })
    ws.on('framereceived', () => { rec.frames++ })
    ws.on('close', () => { rec.closed = true })
  })
  const httpFailures = []
  page.on('response', (r) => { if (r.status() >= 500) httpFailures.push(`${r.status()} ${new URL(r.url()).pathname}`) })

  await page.goto(url, { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(5000)
  const title = await page.title()

  // Make the Console do the thing that needs a socket: the Object Browser
  // opens /ws/objectManager to watch the bucket listing.
  await page.goto(new URL('/browser', page.url()).toString(), { waitUntil: 'domcontentloaded' }).catch(() => {})
  await page.waitForTimeout(6000)
  const body = await page.locator('body').innerText().catch(() => '')

  await browser.close()
  await api(`pam/web-sessions/${web_proxy_session_id}/end`, { method: 'POST', body: '{}' }).catch(() => {})

  const wsOk = sockets.filter((s) => !s.error)
  return { title, body, sockets, wsOk, httpFailures, scheme: new URL(url).protocol }
}

// ── The correct ingress ───────────────────────────────────────────────────
const good = await lane(8443, 'ingress configured correctly')
if (good) {
  check('the session is served over TLS, not loopback http', good.scheme === 'https:', good.scheme)
  check('the MinIO Console renders through the TLS ingress', /minio/i.test(good.title), `title "${good.title}"`)
  check('the bucket list loads', /bucket/i.test(good.body) && !/^loading/i.test(good.body.trim()),
    good.body.replace(/\s+/g, ' ').slice(0, 90))
  check('the Console opened at least one websocket', good.sockets.length > 0,
    good.sockets.map((s) => new URL(s.url).pathname).join(', ') || 'none')
  check('EVERY wss:// websocket connected', good.sockets.length > 0 && good.sockets.every((s) => !s.error),
    good.sockets.map((s) => `${new URL(s.url).pathname} ${s.error ? 'ERR ' + s.error : 'ok'}`).join(', '))
  check('the sockets are wss://, not ws://', good.sockets.every((s) => s.url.startsWith('wss://')),
    good.sockets.map((s) => s.url.split(':')[0]).join(','))
  check('no 5xx anywhere in the session', good.httpFailures.length === 0, good.httpFailures.join(', ') || 'none')
}

// ── The misconfigured ingress: the reported bug ───────────────────────────
const bad = await lane(9443, 'ingress MISSING the three upgrade directives')
if (bad) {
  // The asymmetry. If HTTP broke too, the diagnosis would be easy.
  check('HTTP still works on the broken lane — the page loads and logs in',
    /minio/i.test(bad.title), `title "${bad.title}"`)
  check('the bucket list still loads on the broken lane', /bucket/i.test(bad.body),
    bad.body.replace(/\s+/g, ' ').slice(0, 80))
  check('and ONLY the websocket fails — the reported symptom exactly',
    bad.sockets.length === 0 || bad.sockets.some((s) => s.error || s.closed),
    bad.sockets.map((s) => `${new URL(s.url).pathname} ${s.error ? 'ERR' : s.closed ? 'closed' : 'open'}`).join(', ') || 'no socket completed')
}

// PAM must not fail silently on the broken lane: it detects the stripped
// upgrade and logs the exact nginx lines to add.
const log = readFileSync('/tmp/pam-api-tls.log', 'utf8')
const hinted = /not forwarding WebSocket upgrades/i.test(log)
check('PAM logged the diagnosis with the nginx lines to add', hinted,
  (log.match(/[^\n]*proxy_set_header Upgrade[^\n]*/) || ['not logged'])[0].slice(0, 120))

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) { failed.forEach((f) => console.log(`  FAILED: ${f.n} — ${f.d}`)); process.exit(1) }
