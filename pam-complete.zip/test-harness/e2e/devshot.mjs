import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080', APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox','--no-proxy-server'] })
const page = await (await browser.newContext({ viewport: { width: 1400, height: 1200 } })).newPage()
const errors = []
page.on('pageerror', e => errors.push(e.message))
page.on('console', m => { if (m.type()==='error') errors.push('console: '+m.text()) })
await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t,u]) => sessionStorage.setItem('pam_session', JSON.stringify({accessToken:t,refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:u})), [token,{user_id:me.user_id,username:me.username,roles:me.roles,email:me.email}])
await page.goto(APP + '/settings?tab=devices', { waitUntil: 'networkidle' })
await page.waitForTimeout(2000)
await page.screenshot({ path: '/tmp/devices-collapsed.png', fullPage: true })
// Expand the first device's capability list.
await page.getByRole('button', { name: /Opens \d+ of \d+ resource types/ }).first().click()
await page.waitForTimeout(600)
await page.screenshot({ path: '/tmp/devices-expanded.png', fullPage: true })
// The second device reports missing tools, which is the case worth seeing.
await page.getByRole('button', { name: /Opens \d+ of \d+ resource types/ }).first().click()
await page.getByRole('button', { name: /Opens \d+ of \d+ resource types/ }).nth(1).click()
await page.waitForTimeout(600)
const txt = await page.locator('main').innerText()
console.log('missing lines:', txt.split('\n').filter(l => /is not installed/.test(l)).slice(0, 6))
await page.screenshot({ path: '/tmp/devices-missing.png', fullPage: true })
console.log('errors:', errors.filter(e=>!/favicon|manifest/i.test(e)).slice(0,3))
await browser.close()
