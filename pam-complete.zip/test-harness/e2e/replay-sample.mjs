// Produce a VIEWABLE sample of a brokered-web (MinIO Console) recording being
// replayed in the PAM console — the same thing the customer's reference video
// shows. Playwright films the browser while the rrweb player runs, so the
// output is a screen capture of the real replay, not a synthetic mock.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
import { mkdirSync } from 'node:fs'

const APP = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const OUT = '/tmp/minio-replay-sample'
mkdirSync(OUT, { recursive: true })
mkdirSync(OUT + '/frames', { recursive: true })
const token = readFileSync('/tmp/tok', 'utf8').trim()
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({
  viewport: { width: 1600, height: 950 },
  recordVideo: { dir: OUT, size: { width: 1600, height: 950 } },
})
const page = await ctx.newPage()
await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

await page.goto(APP + '/admin/audit?tab=recordings', { waitUntil: 'networkidle' })
await page.waitForTimeout(2500)
await page.getByRole('button', { name: /^COMPLETED$/ }).first().click().catch(() => {})
await page.waitForTimeout(2000)
await page.screenshot({ path: OUT + '/frames/00-recordings-tab.png' })

// Which recording to film: the session id may be passed in (the row text
// carries it), otherwise the newest minio-real row.
const want = process.argv[2] || ''
let rows = page.locator('tbody tr').filter({ hasText: /minio-real/i })
if (want) rows = rows.filter({ hasText: want })
const n = await rows.count()
console.log(`matching rows: ${n}${want ? ` for ${want}` : ''}`)
const best = n ? rows.first() : null
if (!best) { console.log('NO ROW'); process.exit(1) }
console.log('row:', (await best.innerText()).replace(/\s+/g, ' ').slice(0, 160))
await best.getByRole('button', { name: /play recording/i }).first().click()
await page.waitForTimeout(6000)
await page.screenshot({ path: OUT + '/frames/01-player-open.png' })

const modal = page.locator('.fixed.inset-0').first()
const clockOf = async () => {
  const t = (await modal.innerText()).replace(/\s+/g, ' ')
  const m = /(\d+:\d{2})\s*\/\s*(\d+:\d{2})/.exec(t)
  return m ? m[0] : '(no clock)'
}
console.log('clock before play:', await clockOf())
await modal.getByRole('button', { name: /^play$/i }).first().click().catch(() => {})

// Film the playback, sampling stills so the sample is usable even without a
// video player.
for (let i = 1; i <= 12; i++) {
  await page.waitForTimeout(2000)
  await page.screenshot({ path: `${OUT}/frames/${String(i + 1).padStart(2, '0')}-play-${i * 2}s.png` })
  if (i % 3 === 0) console.log(`  t+${i * 2}s  clock ${await clockOf()}`)
}
console.log('clock after play:', await clockOf())

await ctx.close()
await browser.close()
console.log('video dir:', OUT)
