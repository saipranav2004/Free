import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
const token = readFileSync('/tmp/tok-user','utf8').trim()
const API='http://127.0.0.1:8080', APP='http://127.0.0.1:4180'
const me=(await (await fetch(`${API}/api/v1/auth/me`,{headers:{Authorization:'Bearer '+token}})).json()).data
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox','--no-proxy-server']})
const page=await (await b.newContext({viewport:{width:1280,height:900}})).newPage()
await page.goto(APP,{waitUntil:'domcontentloaded'})
await page.evaluate(([t,u])=>sessionStorage.setItem('pam_session',JSON.stringify({accessToken:t,refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:u})),[token,{user_id:me.user_id,username:me.username,roles:me.roles,email:me.email}])
await page.goto(APP+'/resources',{waitUntil:'networkidle'})
await page.waitForTimeout(2200)
await page.locator('tbody tr').first().getByRole('button',{name:/connect/i}).click()
await page.waitForSelector('[role="menu"]', { state: 'visible' })
await page.waitForTimeout(2500)
const menu = page.locator('[role="menu"]').first()
const box = await menu.boundingBox()
console.log('menu box:', JSON.stringify(box))
// Is any ancestor clipping it? A menu whose install advice is cut off is
// worse than no advice: the operator reads half a sentence.
const clip = await menu.evaluate((el) => {
  const mine = el.getBoundingClientRect()
  let node = el.parentElement
  const clippers = []
  while (node && node !== document.body) {
    const cs = getComputedStyle(node)
    if (/hidden|auto|scroll/.test(cs.overflow + cs.overflowY + cs.overflowX)) {
      const r = node.getBoundingClientRect()
      clippers.push({
        tag: node.tagName.toLowerCase() + '.' + (node.className || '').toString().split(' ').slice(0, 2).join('.'),
        overflow: cs.overflow + '/' + cs.overflowY,
        cutsBottom: Math.round(mine.bottom - r.bottom),
      })
    }
    node = node.parentElement
  }
  return { menu: { top: mine.top, bottom: mine.bottom, height: mine.height }, clippers }
})
console.log('clipping ancestors:', JSON.stringify(clip, null, 1))
// The page region the menu occupies, which is what the operator actually sees.
await page.screenshot({ path: '/tmp/std-menu-region.png', clip: { x: box.x - 30, y: box.y - 30, width: box.width + 60, height: box.height + 60 } })
console.log(await menu.innerText())
await b.close()
