import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// Drives the real built console against the real API and asserts the insight
// strips render REAL FIGURES — not that a component mounted. A card that
// renders 0 because its query failed looks identical to a quiet week, which is
// the whole failure mode these cards have.

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'

const api = async (p) => {
  const r = await fetch(`${API}/api/v1/${p}`, { headers: { Authorization: 'Bearer ' + token } })
  const j = await r.json()
  if (!r.ok) throw new Error(`${p} -> ${r.status} ${JSON.stringify(j).slice(0, 200)}`)
  return j.data
}

const me = await api('auth/me')
const truth = {
  sessions: await api('pam/insights/sessions'),
  audit: await api('pam/insights/audit?days=30'),
  vault: await api('pam/admin/insights/vault'),
  services: await api('pam/admin/insights/services'),
}
console.log('SERVER TRUTH:')
console.log('  sessions.active_now =', truth.sessions.active_now,
  '| recorded', truth.sessions.recorded_share_pct + '% of', truth.sessions.recorded_of,
  '| breakglass', truth.sessions.breakglass_active)
console.log('  audit.total_events =', truth.audit.total_events, '| denied', truth.audit.denied_rate_pct + '%')
console.log('  vault.total_secrets =', truth.vault.total_secrets, '| overdue', truth.vault.rotation_overdue)
console.log('  services.ready_count =', truth.services.ready_count, '/', truth.services.identities)

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1100 } })
const page = await ctx.newPage()
const errors = []
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0, 200)) })
const failedApi = []
page.on('response', (r) => {
  if (r.url().includes('/insights/') && !r.ok()) failedApi.push(`${r.status()} ${r.url()}`)
})

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

// Card labels are UPPERCASED by CSS and innerText honours text-transform, so
// every comparison runs on a case-folded, whitespace-collapsed copy. The hero
// value and its unit are separate flex children ("100" and "%"), which
// innerText separates with a newline — collapsing whitespace is what lets
// "100%" be found at all.
const flat = (s) => s.replace(/\s+/g, ' ').toLowerCase()
const has = (body, text) => body.includes(flat(text))

async function visit(path, shot) {
  await page.goto(APP + path, { waitUntil: 'networkidle' })
  await page.waitForTimeout(1200)
  if (shot) await page.screenshot({ path: shot, fullPage: false })
  return flat(await page.locator('body').innerText())
}

// ── Sessions ──────────────────────────────────────────────────────────────
console.log('\n=== /sessions ===')
let body = await visit('/sessions', '/tmp/shot-sessions.png')
for (const label of ['Active now', 'Under break glass', 'Recorded this week', 'Session length']) {
  check(`sessions strip shows "${label}"`, has(body, label))
}
// FOUR cards, not five: five in a four-column grid leaves an orphan on the
// last row, which is the exact sloppiness this work is meant to remove.
check('"Longest running" is folded into the active card, not a fifth plate',
  !has(body, 'longest running') &&
    (truth.sessions.active_now === 0 || has(body, 'longest has been open')))
check(`recorded % on screen matches the server (${truth.sessions.recorded_share_pct}%)`,
  body.includes(`${truth.sessions.recorded_share_pct} %`) ||
    body.includes(`${truth.sessions.recorded_share_pct}%`))
check(`recording coverage names its denominator (${truth.sessions.recorded_of})`,
  truth.sessions.recorded_of === 0 ||
    has(body, `of ${truth.sessions.recorded_of} sessions carry a recording`))
// Every duration band is drawn, including the empty ones, so a sparse
// distribution is not mistaken for a shorter one.
for (const band of ['< 1m', '1-5m', '5-30m', '30m-2h', '2h+']) {
  check(`duration band "${band}" is drawn even when empty`, has(body, band))
}
// The old client-side bar counted the LOADED rows and silently stopped being
// true past the 200-row cap. It must be gone, not sitting beside the new one.
check('the old client-side counter bar is gone', !body.includes('active now\n') && !has(body, '0 active now'))

// ── Audit ─────────────────────────────────────────────────────────────────
// /audit and /activity both redirect to "/" — the routed audit screen is the
// Admin Center one, and pages/audit/AuditPage.jsx is dead code no route
// reaches. Wiring a strip into that file rendered nothing and looked like a
// passing test until this assertion was added.
console.log('\n=== /admin/audit ===')
await page.goto(APP + '/audit', { waitUntil: 'networkidle' })
check('the routed audit screen is /admin/audit, not /audit',
  new URL(page.url()).pathname !== '/audit',
  `/audit resolved to ${new URL(page.url()).pathname}`)
body = await visit('/admin/audit', '/tmp/shot-audit.png')
for (const label of ['Events', 'Refused', 'Busiest actors']) {
  check(`audit strip shows "${label}"`, has(body, label))
}
// The strip's window follows the filter bar's own preset, so exactly ONE
// window is described on the page. The filter bar defaults to "Last 7 days",
// so a strip hard-coded to 30 would be visibly describing a window nobody
// asked for while the table beneath it showed a different one.
check("the strip labels itself with the filter bar's own words",
  has(body, 'last 7 days'))
// Re-read rather than compared against the figure fetched at startup: this
// counter is LIVE, and every request this script makes is itself an audited
// event, so a fixed expectation drifts before the page even loads.
// Read for the window the page ACTUALLY asks for (7 days, the default), and
// compared with tolerance: this counter is live and every request made while
// driving the page is itself an audited event, so an exact match is a race
// the test loses roughly half the time.
const auditNow = await api('pam/insights/audit?days=7')
const shownTotal = Number(
  (await page.locator('[data-insight="Events"] [data-insight-value]').first().innerText())
    .replace(/[^0-9]/g, '') || 0
)
check(`audit total on screen tracks the server (${shownTotal} vs ${auditNow.total_events})`,
  shownTotal > 0 && Math.abs(shownTotal - auditNow.total_events) <= 50,
  `drift ${Math.abs(shownTotal - auditNow.total_events)}; a real break shows as 0 or a wild number`)
const topActor = truth.audit.top_actors[0]
if (topActor) check(`busiest actor "${topActor.label}" is named`, has(body, topActor.label))
// Two altitudes on one page: the strip is the unfiltered 30-day shape, the
// line under it is the current query. Both must be present and labelled.
// The one plate worth keeping was about the FILTER, not the window.
check('the filtered-result line survives beside the strip',
  has(body, 'events match the current filters'))
// The two plates that said "On this page" counted the LOADED rows and looked
// like answers about the query. Their headline labels must be gone; the same
// facts survive only as a subordinate clause that says whose count it is.
check('the old page-local headline plates are gone',
  !has(body, 'events matched') && !has(body, 'distinct actors 1'),
  'old plate labels: "Events matched", "Distinct actors", "Denied or failed"')
check('page-local counts are demoted to a qualified clause',
  !body.includes('distinct actors on this page') || body.includes('on this page'))

// The coupling itself: change the range in the filter bar and the strip must
// follow. This is the feature — without it the cards describe one window and
// the table another, which is the trap the old plates fell into.
await page.getByRole('button', { name: /last 7 days/i }).first().click().catch(() => {})
await page.waitForTimeout(400)
const switched = await page.getByRole('option', { name: /last 30 days/i }).first().click()
  .then(() => true).catch(() => page.getByText(/^Last 30 days$/).first().click().then(() => true).catch(() => false))
if (switched) {
  await page.waitForTimeout(1500)
  const after = flat(await page.locator('body').innerText())
  check('changing the range moves the strip with it',
    has(after, 'last 30 days') && !has(after, 'events last 7 days'))
} else {
  console.log('  SKIP  range picker could not be driven; coupling asserted at the unit level instead')
}

// ── Vault ─────────────────────────────────────────────────────────────────
console.log('\n=== /vault ===')
body = await visit('/vault', '/tmp/shot-vault.png')
// The cards are what a LIST OF SAFES cannot answer. "Secrets held, by safe"
// is not one of those — it is the table's own Credentials column, and it only
// looked like a card's job while that column was returning nothing.
for (const label of ['Break-glass accounts', 'Rotation overdue', 'Secrets read']) {
  check(`vault strip shows "${label}"`, has(body, label))
}
check('the strip no longer duplicates the table with a "Secrets held" card',
  !has(body, 'secrets held'))

// And the number it used to carry is now in the row, where it belongs. This
// column read "-" for every safe because the endpoint never returned a count.
const safeRow = page.locator('tr').filter({ hasText: truth.vault.by_safe[0]?.label || 'prod-db' }).first()
if ((await safeRow.count()) > 0) {
  const rowText = (await safeRow.innerText()).replace(/\s+/g, ' ')
  const expected = truth.vault.by_safe[0]?.value
  check(`the safe's credential count is in the table row (${expected})`,
    expected != null && rowText.includes(String(expected)) && !/\|\s*-\s*\|/.test(rowText),
    rowText.slice(0, 90))
} else {
  check('the safes table lists a safe to check the count on', false)
}
// The reveal series is read from the audit trail, so a non-zero total proves
// the action names match what the vault actually writes. An invented action
// name would draw a confident flat zero.
const revealTotal = truth.vault.reveals_by_day.reduce((s, b) => s + b.value, 0)
check(`reveal series is fed by real audit actions (${revealTotal} in 30 days)`, revealTotal > 0,
  'zero would mean the action names do not match what the vault writes')

// ── Service identities ────────────────────────────────────────────────────
console.log('\n=== /admin/services ===')
body = await visit('/admin/services', '/tmp/shot-services.png')
for (const label of ['Ready to use', 'Scope reach', 'Token runway']) {
  check(`service strip shows "${label}"`, has(body, label))
}
check(`ready count on screen matches the server (${truth.services.ready_count} / ${truth.services.identities})`,
  body.includes(`/ ${truth.services.identities}`))
// The API's own words are exact/wildcard/subtree/all. None of those tells an
// administrator what the grant can actually reach.
check('scope breadth is named in plain words, not the API enum',
  ['One path', 'One level', 'A subtree', 'Whole vault'].some((w) => has(body, w)))
check('token runway bands are drawn',
  ['expired', '< 7d', '< 30d', '30d+', 'never'].every((b) => has(body, b)))

// ── The donut finally has a consumer ──────────────────────────────────────
console.log('\n=== donut ===')
await page.goto(APP + '/sessions', { waitUntil: 'networkidle' })
await page.waitForTimeout(800)
const donutArcs = await page.locator('svg circle.arc-draw').count()
if (truth.sessions.active_now === 0) {
  // Not a pass. DonutChart was exported and used by exactly zero pages before
  // this work, so "no arcs because nothing is running" proves nothing about
  // whether it can draw at all — seed an active session and re-run.
  check('DonutChart exercised', false,
    'SKIPPED: nothing is running, so the donut had no data. Seed an ACTIVE session to test it.')
} else {
  check(`DonutChart draws one arc per resource type (${truth.sessions.by_channel.length} expected)`,
    donutArcs === truth.sessions.by_channel.length,
    `${donutArcs} arcs for ${truth.sessions.by_channel.length} types`)
  // The arcs animate in. This is the class that was added in the motion work
  // and had no consumer to prove it on.
  const hasArcVars = await page.locator('svg circle.arc-draw').first()
    .evaluate((el) => el.style.getPropertyValue('--arc-length') !== '')
  check('each arc carries the length/offset custom properties it animates from', hasArcVars)
  check('the donut names each resource type in its legend',
    (await Promise.all(truth.sessions.by_channel.map(async (c) =>
      (await page.locator('[data-insight="Active now"]').innerText()).toLowerCase().includes(c.label.slice(0, 5))
    ))).every(Boolean))
  check(`break-glass count is live (${truth.sessions.breakglass_active})`,
    (await page.locator('[data-insight="Under break glass"] [data-insight-value]').innerText()).trim() ===
      String(truth.sessions.breakglass_active))
  check('the longest-running session is reported in the active card',
    truth.sessions.longest_active_seconds === 0 ||
      (await page.locator('[data-insight="Active now"]').innerText()).toLowerCase().includes('longest has been open'))
}

// ── Hygiene ───────────────────────────────────────────────────────────────
console.log('\n=== hygiene ===')
check('no failed insight requests', failedApi.length === 0, failedApi.join('; '))
check('no page errors or unhandled exceptions', errors.length === 0, errors.slice(0, 3).join(' | '))

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
