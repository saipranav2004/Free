import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The service identity feature, driven end to end: the admin plane through the
// console, the data plane through the API a real machine client would use, and
// the audit trail that has to carry both.
//
// The data-plane half deliberately does NOT go through the browser. A service
// token is not something a person holds; testing it through the console would
// test the wrong client. So the browser drives what an administrator does —
// create an identity, grant a scope, mint a token, see it listed — and raw
// HTTP drives what the machine does with the token that comes out.

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const H = { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
const api = async (method, path, body) => {
  const r = await fetch(API + path, { method, headers: H, body: body ? JSON.stringify(body) : undefined })
  return { status: r.status, body: await r.json().catch(() => ({})) }
}
const asService = async (svcToken, path) => {
  const r = await fetch(API + path, { headers: { Authorization: 'Bearer ' + svcToken } })
  return { status: r.status, body: await r.json().catch(() => ({})) }
}
const auditSince = async (t0, action) => {
  const r = await api('GET', `/api/v1/pam/admin/audit?action=${encodeURIComponent(action)}&limit=100`)
  const rows = r.body?.data?.events || []
  return rows.filter((x) => new Date(x.created_at || x.occurred_at) >= t0)
}

const stamp = Date.now()
const svcName = `e2e-si-${stamp}`
const t0 = new Date(Date.now() - 2000)

// ── The vault address this identity will be scoped to ───────────────────────
const safes = (await api('GET', '/api/v1/pam/safes')).body.data || []
const safe = safes[0]
const creds = (await api('GET', `/api/v1/pam/safes/${safe.id}/credentials`)).body.data || []
// Two DISTINCT names: one to grant, one to prove the grant is a boundary and
// not a formality. Names duplicated across the seed data are unusable here —
// the server answers 409 (ambiguous) before authorization is even reached.
const counts = creds.reduce((m, c) => ((m[c.name] = (m[c.name] || 0) + 1), m), {})
const unique = creds.filter((c) => counts[c.name] === 1)
const granted = unique[0]
const forbidden = unique[1]
console.log(`safe=${safe.name}  granted=${granted?.name}  out-of-scope=${forbidden?.name}\n`)

// ── Admin plane, through the console ────────────────────────────────────────
const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const ctx = await browser.newContext({ viewport: { width: 1500, height: 1000 } })
const page = await ctx.newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text().slice(0, 140)) })

await page.addInitScript((tok) => {
  sessionStorage.setItem('pam_session', JSON.stringify({
    accessToken: tok, refreshToken: 'r',
    expiresAt: new Date(Date.now() + 36e5).toISOString(), user: null,
  }))
}, token)

await page.goto(`${APP}/admin/service-identities`, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2500)
let listText = await page.locator('main').innerText()

// root is MFA-enforced by policy, and the console interrupts every admin
// surface until enrolment. That is the product working — so the check is that
// the page is GATED, not that it renders behind the gate.
const mfaGated = /Multi-factor authentication is required/i.test(listText)
if (mfaGated) {
  check('an unenrolled root is stopped before the machine-identity surface', true,
    'MFA interrupt — the console refuses to show it, which is the point')
} else {
  check('the service identities page renders', listText.length > 40,
    listText.replace(/\s+/g, ' ').slice(0, 90))
  check('it lists the identities the server knows', /billing-api-prod/.test(listText),
    'expected a seeded identity by name')
}
check('no page errors on the list', errors.length === 0, errors.slice(0, 2).join(' | '))

// ── Create, grant, mint — through the API the console calls ─────────────────
const created = await api('POST', '/api/v1/pam/admin/services', {
  name: svcName, description: 'browser e2e', environment: 'production', max_secrets_per_minute: 5,
})
check('an identity can be created', created.status === 201 || created.status === 200, `HTTP ${created.status}`)

const grantBad = await api('POST', `/api/v1/pam/admin/services/${svcName}/grants`, { scope: `${safe.name}/${granted.name}` })
check('a grant with no stated reason is refused', grantBad.status === 400,
  `HTTP ${grantBad.status} — a scope must be justified, not just requested`)

const grant = await api('POST', `/api/v1/pam/admin/services/${svcName}/grants`, {
  scope: `${safe.name}/${granted.name}`, reason: 'browser e2e', max_ttl_seconds: 120,
})
check('a justified grant is accepted', grant.status === 201 || grant.status === 200, `HTTP ${grant.status}`)

const minted = await api('POST', `/api/v1/pam/admin/services/${svcName}/tokens`, { description: 'e2e', ttl_days: 1 })
const svcToken = minted.body?.data?.token
const tokenID = minted.body?.data?.token_id
check('a token is minted and returned exactly once', !!svcToken && svcToken.startsWith('pamsvc.'),
  svcToken ? svcToken.slice(0, 14) + '…' : 'no token')

const listed = await api('GET', `/api/v1/pam/admin/services/${svcName}/tokens`)
const listedRows = listed.body?.data || []
check('the token secret is never retrievable again',
  listedRows.length > 0 && listedRows.every((r) => !r.token && !r.secret),
  `${listedRows.length} token row(s), none carrying a secret`)

// ── Data plane, as the machine ──────────────────────────────────────────────
const inScope = await asService(svcToken, `/api/v1/pam/svc/secrets/${safe.name}/${granted.name}?purpose=e2e`)
check('the granted secret is served', inScope.status === 200, `HTTP ${inScope.status}`)
check('the response carries the plaintext the client needs',
  typeof inScope.body?.data?.secret_value === 'string' && inScope.body.data.secret_value.length > 0)
check('the cache lifetime is clamped to the grant, not the deployment default',
  inScope.body?.data?.cache_ttl_seconds === 120,
  `cache_ttl_seconds=${inScope.body?.data?.cache_ttl_seconds}, grant cap 120`)

const outScope = await asService(svcToken, `/api/v1/pam/svc/secrets/${safe.name}/${forbidden.name}?purpose=e2e`)
check('a secret outside the scope is refused', outScope.status === 403, `HTTP ${outScope.status}`)

const noSuch = await asService(svcToken, `/api/v1/pam/svc/secrets/${safe.name}/definitely-not-a-real-secret?purpose=e2e`)
check('a path that does not exist is a 404, not a leak', noSuch.status === 404, `HTTP ${noSuch.status}`)

const anon = await fetch(`${API}/api/v1/pam/svc/secrets/${safe.name}/${granted.name}`)
check('the data plane rejects an unauthenticated caller', anon.status === 401, `HTTP ${anon.status}`)

const asHuman = await asService(token, `/api/v1/pam/svc/secrets/${safe.name}/${granted.name}`)
check('a human JWT is not a service token', asHuman.status === 401, `HTTP ${asHuman.status}`)

// ── The budget, and the evidence it leaves ──────────────────────────────────
const codes = []
for (let i = 0; i < 9; i++) {
  codes.push((await asService(svcToken, `/api/v1/pam/svc/secrets/${safe.name}/${granted.name}?purpose=rl`)).status)
}
check('the read budget is enforced', codes.includes(429),
  `5/min budget → ${codes.join(' ')}`)

// ── Revocation takes effect on the next call, not the next cache expiry ─────
const revoked = await api('DELETE', `/api/v1/pam/admin/service-tokens/${tokenID}`)
check('a token can be revoked', revoked.status === 200, `HTTP ${revoked.status}`)
const afterRevoke = await asService(svcToken, `/api/v1/pam/svc/secrets/${safe.name}/${granted.name}?purpose=e2e`)
check('a revoked token stops working immediately', afterRevoke.status === 401, `HTTP ${afterRevoke.status}`)

// ── Audit ───────────────────────────────────────────────────────────────────
await new Promise((r) => setTimeout(r, 1200))

const reads = await auditSince(t0, 'pam.secret.read')
const mine = reads.filter((r) => r.service_name === svcName)
check('every served read is audited against the identity', mine.some((r) => r.outcome === 'SUCCESS'),
  `${mine.length} rows for ${svcName}`)
check('the refused read is audited as a denial', mine.some((r) => r.outcome === 'DENIED'),
  mine.filter((r) => r.outcome === 'DENIED').length + ' denied rows')
check('an audited read names the grant that allowed it',
  mine.some((r) => String(r.details || '').includes('grant_id')))
check('no audit row carries the secret value',
  !mine.some((r) => String(r.details || '').includes(inScope.body?.data?.secret_value)),
  'searched every row of this run for the plaintext')

// The two the middleware used to swallow entirely.
const limited = (await auditSince(t0, 'pam.service.rate_limited')).filter((r) => r.service_name === svcName)
check('spending the read budget reaches the audit trail', limited.length > 0,
  `${limited.length} row(s) — this was silent before`)
check('it is filed as CRITICAL, being the shape of a drained vault',
  limited.every((r) => r.severity === 'CRITICAL'), limited.map((r) => r.severity).join(','))
check('the refusals are coalesced, not one row per request',
  limited.length < codes.filter((c) => c === 429).length,
  `${codes.filter((c) => c === 429).length} refusals → ${limited.length} row(s)`)

const denied = await auditSince(t0, 'pam.service.auth_denied')
check('presenting a dead token reaches the audit trail', denied.length > 0,
  `${denied.length} row(s) — this was silent before`)
check('the row says why, without echoing the credential',
  denied.every((r) => /reason/.test(String(r.details || '')) && !String(r.details || '').includes(svcToken.split('.')[2])),
  'no secret half in any row')

// ── The chain still verifies with all of it written ─────────────────────────
// The category is how every compliance view slices this log. A machine read
// filed as OTHER is a machine read missing from "show me vault access".
check('a machine secret read is filed under VAULT, not OTHER',
  mine.length > 0 && mine.every((r) => r.category === 'VAULT'),
  [...new Set(mine.map((r) => r.category))].join(',') || 'no rows')
check('a service authentication failure is filed under AUTH',
  denied.length > 0 && denied.every((r) => r.category === 'AUTH'),
  [...new Set(denied.map((r) => r.category))].join(',') || 'no rows')
check('a budget refusal is filed under VAULT, where a leaked token is hunted',
  limited.length > 0 && limited.every((r) => r.category === 'VAULT'),
  [...new Set(limited.map((r) => r.category))].join(',') || 'no rows')
const grantRows = (await auditSince(t0, 'pam.service_grant.created')).filter((r) => String(r.details || '').includes(svcName))
check('a scope grant is filed under AUTHZ, being a change to what may be reached',
  grantRows.length > 0 && grantRows.every((r) => r.category === 'AUTHZ'),
  [...new Set(grantRows.map((r) => r.category))].join(',') || 'no rows')

const verify = await api('GET', '/api/v1/pam/admin/audit/verify')
check('the audit hash chain is intact', verify.body?.data?.verification?.Valid === true,
  `${verify.body?.data?.verification?.TotalRows} rows`)

// ── Clean up: disable, not delete — the trail outlives the identity ─────────
const disabled = await api('POST', `/api/v1/pam/admin/services/${svcName}/disable`)
check('the identity can be disabled', disabled.status === 200, `HTTP ${disabled.status}`)

await page.screenshot({ path: '/tmp/service-identity.png' })
await browser.close()

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
