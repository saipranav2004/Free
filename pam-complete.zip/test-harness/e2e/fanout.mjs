// Count the API requests the Service Identities page actually issues on load.
// The regression this guards: one request per identity per table.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const BASE = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()
let failures = 0
const check = (n, ok, d = '') => { if (!ok) failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? `  — ${d}` : ''}`) }

const admin = (p, init = {}) => fetch(`${API}/api/v1/pam/admin${p}`, {
  ...init, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
})

// Provision enough identities that a per-row fan-out is unmistakable.
const made = []
for (let i = 0; i < 12; i++) {
  const name = `fanout-${i}-${Date.now().toString(36)}`
  await admin('/services', { method: 'POST', body: JSON.stringify({ name, environment: 'staging' }) })
  await admin(`/services/${name}/grants`, { method: 'POST', body: JSON.stringify({ scope: 'prod-db/*', reason: 'fan-out probe' }) })
  await admin(`/services/${name}/tokens`, { method: 'POST', body: JSON.stringify({ ttl_days: 1 }) })
  made.push(name)
}
const total = ((await (await admin('/services')).json()).data || []).length
console.log(`  (${total} identities on the page)`)

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox', '--no-proxy-server'] })
const me = await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: `Bearer ${token}` } })).json()
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
const page = await ctx.newPage()

const calls = []
page.on('request', (r) => { if (r.url().includes('/api/v1/pam/')) calls.push(r.url().replace(API, '')) })

await page.goto(BASE, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u })),
  [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }])

calls.length = 0
await page.goto(`${BASE}/admin/services`, { waitUntil: 'networkidle' })
await page.locator('tbody tr').first().waitFor({ timeout: 10000 })
await page.waitForTimeout(1200)

const perRow = calls.filter((u) => /\/services\/[^/]+\/(tokens|grants)/.test(u))
check('no per-identity token/grant requests on page load', perRow.length === 0, `${perRow.length} such requests; sample: ${perRow.slice(0, 3).join(' ')}`)
check('the identity list is fetched exactly once', calls.filter((u) => u.endsWith('/admin/services')).length === 1)
check(`total PAM requests stays flat, not ~2x${total}`, calls.length < 12, `${calls.length} requests for ${total} identities`)

// The counts must still be correct and rendered, not just absent.
//
// Narrow the table to this run's own row before looking for it. Identities are
// never deleted — disabling is the strongest thing the API offers, deliberately,
// because the audit trail has to outlive the identity — so every run of this
// suite leaves its twelve rows behind and the list only ever grows. Assuming
// made[0] is on the first page made the suite fail against its own history at
// around 200 identities, which is a perfectly ordinary size for a real estate.
await page.getByPlaceholder('Search service identities').fill(made[0])
await page.waitForFunction((name) => {
  const rows = [...document.querySelectorAll('tbody tr')]
  const tr = rows.find((r) => r.textContent.includes(name))
  return tr && !tr.textContent.includes('checking')
}, made[0], { timeout: 10000 })
const row = await page.locator('tbody tr', { hasText: made[0] }).first().innerText()
check('a provisioned row still reads Ready with its counts', row.includes('Ready') && /\b1\b/.test(row), row.replace(/\n/g, ' | '))

// Opening the drawer is where per-identity detail SHOULD be fetched.
calls.length = 0
await page.locator('tbody tr', { hasText: made[0] }).first().locator(`button[title="${made[0]}"]`).click()
await page.getByText('What this service can read').waitFor({ timeout: 8000 })
await page.waitForTimeout(600)
const drawerCalls = calls.filter((u) => /\/services\/[^/]+\/(tokens|grants)/.test(u))
check('the drawer fetches that identity’s detail on demand', drawerCalls.length >= 1, `${drawerCalls.length} requests`)

await browser.close()
// Clean up so later suites see a tidy list.
for (const n of made) await admin(`/services/${n}/disable`, { method: 'POST' })
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
