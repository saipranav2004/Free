#!/bin/bash
export DISPLAY=:99
AGENT=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/backend/backend_upd/agents/pam-agent_linux_amd64
TOK=$(cat /tmp/tok); PG=85b62f4a-41a7-40d5-9152-7a8167702f59
L=$(curl -s --noproxy '*' -X POST "http://127.0.0.1:8080/api/v1/pam/resources/$PG/launch" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{"channel":"cli"}')
echo "$L" | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['launch_id'])" > /tmp/lid
URL=$(echo "$L" | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['launch_url'])")
exec env HOME=/tmp/agenthome "$AGENT" launch "$URL"
