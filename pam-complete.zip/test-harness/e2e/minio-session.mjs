// Drive a REAL, minute-long brokered MinIO session whose activity is spread
// out over time, so the recording it leaves behind is worth replaying.
//
// The earlier drivers finished in ten seconds. That was enough to prove the
// proxy and the recorder, and not enough to see whether a replay's TIMELINE
// tracks the operator: rrweb only emits on change, so a session that paints
// itself and then sits still leaves a four-second recording no matter how
// long the operator was actually in there. This one clicks, waits, clicks
// again — the shape of a person working — and ends by naming the recording it
// produced.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  const j = await r.json().catch(() => ({}))
  return { ok: r.ok, status: r.status, data: j.data, raw: j }
}

const open = await api('pam/resources/minio-real/web-session', { method: 'POST', body: '{}' })
if (!open.ok) { console.log('open failed', open.status, JSON.stringify(open.raw).slice(0, 300)); process.exit(1) }
// web_proxy_session_id, NOT session_id: the end route keys on the PROXY
// session. Passing the connection session id answers 404 ("Brokered web
// session not found"), the session is then left to the idle sweep, and the
// recording's duration picks up the sweep's lag on top of the real session.
const { launch_url, session_id, web_proxy_session_id } = open.data
console.log('session', session_id)

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})
const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage()
let posts = 0
page.on('request', (r) => { if (r.url().includes('/__pam/replay') && r.method() === 'POST') posts++ })

const t0 = Date.now()
const beat = (what) => console.log(`  t+${((Date.now() - t0) / 1000).toFixed(0)}s  ${what}`)

await page.goto(launch_url, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(6000)
beat('landed in the Object Browser')

// Dismiss MinIO's own licence modal so the replay shows the console, not a
// dialog over it.
await page.getByRole('button', { name: /accept|close|ok|agree/i }).first().click({ timeout: 2000 }).catch(() => {})
await page.keyboard.press('Escape').catch(() => {})
await page.waitForTimeout(4000)

for (let i = 1; i <= 3; i++) {
  const bucket = `pam-replay-${Date.now().toString(36)}-${i}`
  const made = await page.evaluate(async (name) => {
    const r = await fetch('/api/v1/buckets', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, versioning: { enabled: false }, locking: false }),
    })
    return r.status
  }, bucket)
  beat(`created ${bucket} (http ${made})`)
  await page.goto(new URL('/browser', page.url()).toString(), { waitUntil: 'domcontentloaded' }).catch(() => {})
  await page.waitForTimeout(3000)
  // Real pointer movement and a real click: rrweb records both, so the replay
  // shows a cursor doing something rather than a screen that merely changes.
  await page.mouse.move(300 + i * 120, 320 + i * 40, { steps: 12 })
  await page.locator('input[placeholder*="ilter" i], input[type="search"]').first()
    .fill(bucket.slice(0, 12)).catch(() => {})
  await page.waitForTimeout(4000)
  await page.locator('input[placeholder*="ilter" i], input[type="search"]').first()
    .fill('').catch(() => {})
  await page.waitForTimeout(4000)
}

beat('idling on the bucket list, as an operator reading a screen does')
await page.waitForTimeout(10000)
beat(`done — ${posts} replay batches posted`)

await page.waitForTimeout(1500)
await browser.close()
const ended = await api(`pam/web-sessions/${web_proxy_session_id}/end`, { method: 'POST', body: '{}' })
console.log(`end: http ${ended.status}`)
await new Promise((r) => setTimeout(r, 3000))

const recs = await api(`pam/admin/recordings?session_id=${session_id}`)
const rows = recs.data?.recordings || recs.data?.items || recs.data || []
const rec = (Array.isArray(rows) ? rows : []).find((r) => r.session_id === session_id) || rows[0]
console.log(rec
  ? `recording ${rec.format} ${rec.status} ${rec.size_bytes} B  duration=${rec.duration_seconds}s`
  : 'NO RECORDING ROW')
