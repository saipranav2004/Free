import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The Devices screen AS A STANDARD OPERATOR. Everything about the rebuilt
// panel was verified with a root token, and root is the one account whose
// view proves least: it has the devices, it has every role, and it is not who
// uses this screen day to day.
const token = readFileSync(process.argv[3] || '/tmp/tok-user', 'utf8').trim()
const API = 'http://127.0.0.1:8080', APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
console.log('acting as', me.username, me.roles)

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox','--no-proxy-server'] })
const page = await (await browser.newContext({ viewport: { width: 1400, height: 1200 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()) })
const denied = []
page.on('response', (r) => { if ([401, 403].includes(r.status())) denied.push(`${r.status()} ${new URL(r.url()).pathname}`) })

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t,u]) => sessionStorage.setItem('pam_session', JSON.stringify({accessToken:t,refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:u})), [token,{user_id:me.user_id,username:me.username,roles:me.roles,email:me.email}])
await page.goto(APP + '/settings?tab=devices', { waitUntil: 'networkidle' })
await page.waitForTimeout(2200)

const body = await page.locator('main').innerText()
console.log('--- reachable:', /device/i.test(body))
console.log('--- summary rows:', await page.getByRole('button', { name: /Opens \d+ of \d+ resource types/ }).count())
console.log('--- revoked disclosure:', await page.getByRole('button', { name: /revoked device/i }).count())
console.log('--- 401/403 while loading:', denied.length ? denied.join(', ') : 'none')
console.log('--- page errors:', errors.filter(e=>!/favicon|manifest/i.test(e)).slice(0,3))
console.log('--- text ---')
console.log(body.replace(/\n{2,}/g,'\n').slice(0, 1500))
await page.screenshot({ path: process.argv[2] || '/tmp/stduser-devices.png', fullPage: true })
await browser.close()
