A TLS-terminating ingress, in the two shapes that decide whether brokered
WebSockets work.

PAM serves plain HTTP (cmd/pam-api/main.go calls ListenAndServe), so every real
deployment puts TLS in front of it. That topology is what the reported MinIO
failure lives in, and it is NOT reproducible on loopback — which is why it
survived two rounds of "it works here".

  :8443  the ingress configured CORRECTLY: proxy_http_version 1.1 plus the
         Upgrade/Connection headers. Brokered WebSockets complete.
  :9443  the SAME ingress with those three lines MISSING. Every HTTP request
         still works — the page loads, auto-login succeeds, buckets list — and
         ONLY the WebSocket dies, with an empty response code, retrying every
         few seconds. That is the reported symptom exactly.

Run it:
  openssl req -x509 -nodes -newkey rsa:2048 -days 30 \
    -keyout key.pem -out cert.pem -subj "/CN=*.pam.test" \
    -addext "subjectAltName=DNS:*.pam.test,DNS:pam.test"
  nginx -c $PWD/nginx-tls-ingress.conf

  PAM_WEBPROXY_BASE_DOMAIN=pam.test \
  PAM_WEBPROXY_SCHEME=https \
  PAM_WEBPROXY_PUBLIC_PORT=8443 pam-api

Chromium needs --host-resolver-rules="MAP *.pam.test 127.0.0.1" and
--ignore-certificate-errors, and --no-proxy-server if HTTPS_PROXY is set in
the environment (see e2e/minio-real.mjs for why that one matters).
