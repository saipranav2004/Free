#!/bin/bash
# Bring the whole test environment back after a container restart.
# Postgres keeps its data in /tmp/pgdata, so nothing is lost — but the
# processes are not, and the access token has a 60-minute TTL.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad

# ── Postgres ──
if ! pg_isready -h /tmp -p 5433 >/dev/null 2>&1; then
  rm -f /tmp/pgdata/postmaster.pid
  chown -R postgres:postgres /tmp/pgdata 2>/dev/null || true
  touch /tmp/pg5433.log && chown postgres:postgres /tmp/pg5433.log
  su postgres -c "/usr/lib/postgresql/16/bin/pg_ctl -D /tmp/pgdata -o '-p 5433 -k /tmp' -l /tmp/pg5433.log start" >/dev/null
  for i in $(seq 1 20); do pg_isready -h /tmp -p 5433 >/dev/null 2>&1 && break; sleep 1; done
fi
echo "postgres: $(pg_isready -h /tmp -p 5433 2>&1)"

# ── API ──
if ! curl -s --noproxy '*' -o /dev/null --max-time 2 http://127.0.0.1:8080/api/v1/pam/insights/sessions 2>/dev/null; then
  pkill -f '^/tmp/pam-api$' 2>/dev/null || true
  sleep 1
  set -a; . $S/harness/api.env; set +a
  nohup /tmp/pam-api > /tmp/pam-api.log 2>&1 &
  for i in $(seq 1 30); do
    [ "$(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:8080/api/v1/pam/insights/sessions 2>/dev/null)" = "401" ] && break
    sleep 2
  done
fi
echo "api: $(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:8080/api/v1/pam/insights/sessions)"

# ── Console (static build on :4180, proxying /api) ──
if ! curl -s --noproxy '*' -o /dev/null --max-time 2 http://127.0.0.1:4180/ 2>/dev/null; then
  pkill -f 'node .*serve.cjs' 2>/dev/null || true
  cd $S && nohup node e2e/serve.cjs > /tmp/serve.log 2>&1 &
  sleep 2
fi
echo "console: $(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:4180/)"

# ── The stub target the brokered-web suite proxies to ──
# matrix-minio's console_url points at 127.0.0.1:9101. Without this the proxy
# has nothing upstream, the page renders PAM's own "Application unreachable"
# and e2e/web-recording.mjs fails in a way that reads exactly like a proxy
# regression. It cost a round of investigation after a container restart, so
# it is started here with everything else.
if ! curl -s --noproxy '*' -o /dev/null --max-time 2 http://127.0.0.1:9101/ 2>/dev/null; then
  cd $S && nohup node e2e/stub/target.cjs 9101 > /tmp/stub-target.log 2>&1 &
  sleep 1
fi
echo "stub target: $(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:9101/)"

# ── Xvfb, for the agent's GUI launches ──
if ! xdpyinfo -display :99 >/dev/null 2>&1; then
  nohup Xvfb :99 -screen 0 1920x1080x24 >/tmp/xvfb.log 2>&1 &
  sleep 2
fi
echo "xvfb: $(xdpyinfo -display :99 >/dev/null 2>&1 && echo up || echo down)"

# ── A fresh token; the access TTL is 60 minutes ──
$S/harness/login.sh
