import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST='/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4184,r)); const BASE='http://127.0.0.1:4184'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})

// Exactly the body AuthHandler.Me builds (auth_handler.go:284-311)
function meBody({enrolled, block}) {
  return {
    user_id:'u-5', username:'mallesh', email:'mallesh@example.com',
    mfa_verified: enrolled, roles:['user'],
    mfa_required: true, mfa_policy_mode: 'enforce',
    mfa_enrolment_required: block,
    mfa_enabled: enrolled,
    mfa_policy_roles: ['user'],
  }
}
async function probe(label, meOverride) {
  const ctx=await b.newContext({viewport:{width:1440,height:950}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  await ctx.route('**localhost:8080/**', r=>{
    const u=new URL(r.request().url())
    const data = u.pathname.includes('/auth/me') ? meOverride : payloadFor(u.pathname,'user')
    r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data})})
  })
  const page=await ctx.newPage()
  await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})
  await page.goto(BASE+'/',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1600)
  const r = await page.evaluate(()=>({
    banner: /Multi-factor authentication is required/i.test(document.body.innerText),
    interrupt: /Set up multi-factor authentication to continue/i.test(document.body.innerText),
    setupNow: /Set up now/i.test(document.body.innerText),
  }))
  console.log(`${label.padEnd(46)} banner=${r.banner}  interrupt=${r.interrupt}  "Set up now"=${r.setupNow}`)
  await ctx.close()
}

console.log('--- exact AuthHandler.Me payload shapes ---')
await probe('enrolled=false, block=true  (should nag)',  meBody({enrolled:false, block:true}))
await probe('enrolled=false, block=false (should nag)',  meBody({enrolled:false, block:false}))
await probe('enrolled=TRUE,  block=false (must be SILENT)', meBody({enrolled:true, block:false}))

console.log('\n--- variants a backend might plausibly send ---')
await probe('mfa_enrolled (not mfa_enabled) = true',
  {user_id:'u-5',username:'mallesh',roles:['user'],mfa_required:true,mfa_policy_mode:'enforce',mfa_enrolment_required:false,mfa_enrolled:true})
await probe('nested mfa:{enrolled:true} block only',
  {user_id:'u-5',username:'mallesh',roles:['user'],mfa_required:true,mfa_policy_mode:'enforce',mfa_enrolment_required:false,mfa:{enrolled:true,required:true}})
await probe('posture omitted entirely (older backend)',
  {user_id:'u-5',username:'mallesh',roles:['user']})
await b.close(); server.close()
