import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4181,r)); const BASE='http://127.0.0.1:4181'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
for (const [role,w] of [['admin',414],['admin',768],['admin',1024],['admin',1440],['user',414],['user',768]]) {
  const ctx=await b.newContext({viewport:{width:w,height:900}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  await ctx.route('**localhost:8080/**', r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname,role)})}))
  const page=await ctx.newPage()
  await page.addInitScript(()=>sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null})))
  await page.goto(BASE+'/resources',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1500)
  const m=await page.evaluate(()=>{
    const main=document.querySelector('#main-content')
    const tbl=document.querySelector('table')
    if(!tbl) return {err:'no table rendered'}
    const wrap=tbl.parentElement
    const cs=getComputedStyle(wrap)
    return {
      mainScroll:main.scrollWidth, mainClient:main.clientWidth,
      wrapClass:wrap.className, wrapMinWidth:cs.minWidth, wrapOverflowX:cs.overflowX,
      wrapClient:wrap.clientWidth, wrapScroll:wrap.scrollWidth,
      wrapRectW:Math.round(wrap.getBoundingClientRect().width),
      tableMinWidth:getComputedStyle(tbl).minWidth, tableW:Math.round(tbl.getBoundingClientRect().width),
      rows: tbl.querySelectorAll('tbody tr').length,
      clipper: (()=>{let a=wrap.parentElement;while(a&&a!==document.body){const st=getComputedStyle(a);if(st.overflowX!=='visible')return a.tagName+'.'+String(a.className).slice(0,60)+' w='+Math.round(a.getBoundingClientRect().width)+' ox='+st.overflowX;a=a.parentElement}return 'none'})(),
      unreachablePx: Math.max(0, Math.round(wrap.getBoundingClientRect().width - (wrap.parentElement?.clientWidth ?? 0))),
    }
  })
  console.log(`\n--- ${role} /resources @${w}px ---`); console.log(JSON.stringify(m,null,1))
  await ctx.close()
}
await b.close(); server.close()
