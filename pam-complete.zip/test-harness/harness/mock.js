// Canned API responses, good enough to render real screens with real rows.
const USERS = Array.from({ length: 12 }, (_, i) => ({
  id: `u-${i}`,
  username: `operator.longname.${i}`,
  email: `operator.longname.${i}@deepalgorithms.example.com`,
  status: i % 4 === 0 ? 'DISABLED' : 'ACTIVE',
  roles: i === 0 ? ['root'] : i < 3 ? ['admin'] : ['user'],
  created_at: '2026-01-0' + ((i % 9) + 1) + 'T10:00:00Z',
  last_login_at: '2026-09-1' + (i % 9) + 'T10:00:00Z',
  mfa_enrolled: i % 2 === 0,
}))

const NAMES = [
  'billing-primary', 'billing-replica', 'analytics-warehouse', 'orders-ledger',
  'cache-eu-west', 'cache-us-east', 'sessions-store', 'reporting-mart',
  'vector-index', 'archive-cold', 'payments-core', 'fraud-signals',
  'identity-store', 'telemetry-raw',
]
const BIG = Array.from({length: 60}, (_, i) => `billing-shard-${String(i).padStart(2,'0')}`)
const RESOURCES = [...NAMES, ...BIG].map((nm, i) => ({
  id: `r-${i}`,
  name: nm,
  type: ['postgresql', 'mongodb', 'redis'][i % 3],
  resource_type: ['postgresql', 'mongodb', 'redis'][i % 3],
  database_name: `db_${nm.replace(/-/g, '_')}`,
  host: `${nm}.internal.deepalgorithms.example.com`,
  port: 5432 + i,
  environment: i % 3 === 0 ? 'PRODUCTION' : 'STAGING',
  requires_jit: i % 2 === 0,
  has_credential: true,
  status: 'ACTIVE',
  description: `Datastore for the ${nm.split('-')[0]} domain.`,
  allowed_methods: ['web_terminal', 'brokered_web', 'desktop_agent'],
  created_at: '2026-02-01T10:00:00Z',
}))

const ROLES = [
  { id: 'role-root', name: 'root', description: 'Full system bypass.', is_system: true, user_count: 1, policy_count: 0, criticality: { score: 100, band: 'CRITICAL' } },
  { id: 'role-admin', name: 'admin', description: 'Administrative access to the PAM Admin Center.', is_system: true, user_count: 2, policy_count: 1, criticality: { score: 82, band: 'HIGH' } },
  { id: 'role-user', name: 'user', description: 'Standard PAM user.', is_system: true, user_count: 9, policy_count: 2, criticality: { score: 24, band: 'LOW' } },
]

const POLICIES = [
  { id: 'p-1', name: 'full-access', description: 'Unrestricted access to every PAM action and resource.', effect: 'allow', actions: ['*'], resources: ['*'], is_system: true },
  { id: 'p-2', name: 'standard-user-access', description: 'Baseline actions available to every standard user.', effect: 'allow', actions: ['pam:vault:List', 'pam:vault:Read', 'pam:jit:Request'], resources: ['*'], is_system: true },
  { id: 'p-3', name: 'resource-access-default-deny', description: 'Documents the deny-by-default three-tier posture.', effect: 'allow', actions: ['pam:resource:List'], resources: [], is_system: true },
]

const JIT = Array.from({ length: 10 }, (_, i) => ({
  id: `j-${i}`,
  request_id: `j-${i}`,
  user_id: `u-${i % 12}`,
  username: `operator.longname.${i % 12}`,
  resource_id: `r-${i % 14}`,
  resource_name: `prod-postgres-cluster-eu-west-${i % 14}`,
  justification: 'Investigating elevated error rates on the billing writer after the 03:14 alert.',
  status: ['PENDING', 'APPROVED', 'DENIED', 'EXPIRED'][i % 4],
  requested_duration_minutes: 60,
  created_at: '2026-09-1' + (i % 9) + 'T08:00:00Z',
  expires_at: '2026-09-1' + (i % 9) + 'T09:00:00Z',
  is_breakglass: i === 3,
}))

const GRANTS = JIT.slice(0, 6).map((r, i) => ({
  id: `g-${i}`, request_id: r.id, user_id: r.user_id, username: r.username,
  resource_id: r.resource_id, resource_name: r.resource_name,
  status: i % 2 ? 'ACTIVE' : 'EXPIRED', granted_at: r.created_at, expires_at: r.expires_at,
}))

const AUDIT = Array.from({ length: 25 }, (_, i) => ({
  id: `a-${i}`, sequence: 1000 + i,
  timestamp: '2026-09-11T0' + (i % 9) + ':12:33Z',
  actor_id: `u-${i % 12}`, actor_username: `operator.longname.${i % 12}`,
  action: ['pam:session:Start', 'pam:vault:Reveal', 'pam:jit:Approve', 'auth:login'][i % 4],
  resource: `pam:resource/r-${i % 14}`,
  outcome: i % 5 === 0 ? 'DENIED' : 'SUCCESS',
  source_ip: '10.14.22.' + (i % 250),
  decision_id: `dec-${i}`, hash: 'a'.repeat(64), prev_hash: 'b'.repeat(64),
}))

const SESSIONS = Array.from({ length: 8 }, (_, i) => ({
  id: `s-${i}`, resource_id: `r-${i}`, resource_name: `prod-postgres-cluster-eu-west-${i}`,
  user_id: `u-${i}`, username: `operator.longname.${i}`, protocol: 'postgresql',
  status: i % 3 === 0 ? 'ACTIVE' : 'ENDED',
  started_at: '2026-09-11T07:00:00Z', ended_at: i % 3 === 0 ? null : '2026-09-11T07:40:00Z',
  has_recording: true, recording_id: `rec-${i}`,
}))

const SAFES = Array.from({ length: 6 }, (_, i) => ({
  id: `safe-${i}`, name: `billing-production-secrets-${i}`,
  description: 'Credentials for the billing domain production estate.',
  credential_count: 3 + i, folder_count: 2, created_at: '2026-03-01T10:00:00Z',
}))

function meFor(role) {
  const roles = role === 'root' ? ['root'] : role === 'admin' ? ['admin'] : ['user']
  return {
    id: role === 'root' ? 'u-0' : role === 'admin' ? 'u-1' : 'u-5',
    username: role === 'root' ? 'root' : role === 'admin' ? 'das.admin' : 'aditi.sharma',
    email: `${role}@deepalgorithms.example.com`,
    roles, status: 'ACTIVE',
    mfa: { required: true, enrolled: true, mode: 'ENFORCE', enrolment_required: false },
    mfa_enrolled: true, mfa_required: true,
    delegation_scoped: false, delegation_scope_size: 0,
  }
}

// path -> payload (data field of the envelope)
// Mirrors handlers.catalogResource exactly (resource_handler.go:56).
function toCatalog(r) {
  return {
    id: r.id, name: r.name, description: r.description,
    resource_type: r.type, host: r.host, database_name: r.database_name,
    requires_jit: r.requires_jit, always_record: false,
    allowed_connect_methods: 'web_terminal,web_proxy,agent',
    connect_mode: 'web_terminal', is_active: true,
  }
}

export function payloadFor(pathname, role) {
  const p = pathname
  const has = (s) => p.includes(s)
  if (has('/auth/me')) return meFor(role)
  if (has('/notifications/unread-count')) return { count: 3 }
  if (has('/notifications')) return { notifications: [], count: 0 }
  if (has('/resources/groups')) return { groups: [
    { name: 'PostgreSQL Databases', icon: '\u{1F418}', resources: RESOURCES.filter(r=>r.type==='postgresql').map(toCatalog) },
    { name: 'MongoDB Databases', icon: '\u{1F343}', resources: RESOURCES.filter(r=>r.type==='mongodb').map(toCatalog) },
    { name: 'Redis Instances', icon: '\u{1F534}', resources: RESOURCES.filter(r=>r.type==='redis').map(toCatalog) },
  ] }
  if (/\/resources\/[^/]+$/.test(p) && !p.endsWith('/resources')) return { resource: RESOURCES[0] }
  if (has('/admin/resources') || has('/pam/resources')) return { resources: RESOURCES, count: RESOURCES.length }
  if (has('/identity/users/') && has('/graph')) return { nodes: [], edges: [] }
  if (/\/identity\/users\/[^/]+$/.test(p)) return { user: USERS[0], access: { roles: ROLES.slice(0, 2), policies: POLICIES.slice(0, 2) } }
  if (has('/identity/users')) return { users: USERS, count: USERS.length }
  if (has('/rbac/criticality')) return { roles: ROLES.map(r => ({ role_id: r.id, role_name: r.name, ...r.criticality })) }
  if (/\/rbac\/roles\/[^/]+$/.test(p)) return { role: ROLES[1], policies: POLICIES.slice(0, 1), members: USERS.slice(0, 3) }
  if (has('/rbac/roles')) return { roles: ROLES, count: ROLES.length }
  if (has('/rbac/policies')) return { policies: POLICIES, count: POLICIES.length }
  if (has('/jit-requests') || has('/jit/requests')) return { requests: JIT, count: JIT.length }
  if (has('/grants')) return { grants: GRANTS, count: GRANTS.length }
  if (has('/breakglass')) return { grants: GRANTS.slice(0, 1), count: 1 }
  if (has('/audit/stats')) return { total: 4820, by_action: [{ action: 'auth:login', count: 1800 }, { action: 'pam:session:Start', count: 1200 }], by_outcome: [{ outcome: 'SUCCESS', count: 4400 }, { outcome: 'DENIED', count: 420 }], by_day: Array.from({ length: 14 }, (_, i) => ({ day: `2026-08-${String(i + 20).padStart(2, '0')}`, count: 200 + i * 13 })) }
  if (has('/audit/verify')) return { valid: true, checked: 4820, broken_at: null }
  if (has('/audit')) return { logs: AUDIT, events: AUDIT, count: AUDIT.length, total: AUDIT.length }
  if (has('/web-sessions')) return { sessions: [], count: 0 }
  if (has('/sessions')) return { sessions: SESSIONS, count: SESSIONS.length }
  if (has('/recordings')) return { recordings: [], count: 0 }
  if (has('/safes')) return { safes: SAFES, count: SAFES.length }
  if (has('/credential-types')) return { types: [{ key: 'password', label: 'Password' }, { key: 'ssh_key', label: 'SSH key' }] }
  if (has('/credentials')) return { credentials: [], count: 0 }
  if (has('/admin/stats')) return { users: 12, resources: 14, active_sessions: 3, pending_requests: 4, active_grants: 3, breakglass_active: 1 }
  if (has('/mfa-policy/compliance')) return { rules: [], users: USERS.map(u => ({ ...u, compliant: u.mfa_enrolled })) }
  if (has('/mfa-policy')) return { rules: [{ role_name: 'admin', mode: 'ENFORCE', grace_days: 0 }, { role_name: 'root', mode: 'ENFORCE', grace_days: 0 }] }
  if (has('/privilege-paths/status')) return { built_at: '2026-09-11T06:00:00Z', age_seconds: 900, node_count: 40, edge_count: 62 }
  if (has('/privilege-paths')) return { paths: [], targets: [], chokepoints: [], summary: {} }
  if (has('/agent/install/targets')) return { enabled: true, targets: [{ os: 'windows', arch: 'amd64', label: 'Windows (64-bit)', filename: 'pam-agent_windows_amd64.exe', size_bytes: 8568320, sha256: 'bf51', version: '2026.09.11' }, { os: 'darwin', arch: 'arm64', label: 'macOS (Apple Silicon)', filename: 'pam-agent_darwin_arm64', size_bytes: 8037634, sha256: '7629', version: '2026.09.11' }, { os: 'linux', arch: 'amd64', label: 'Linux (x86-64)', filename: 'pam-agent_linux_amd64', size_bytes: 8290488, sha256: 'ab01', version: '2026.09.11' }] }
  if (has('/agent/devices')) return { devices: [], count: 0 }
  if (has('/network/allowlist')) return { enabled: false, entries: [], trusted_proxies: 'none' }
  return {}
}

export const MOCK_USER = meFor
