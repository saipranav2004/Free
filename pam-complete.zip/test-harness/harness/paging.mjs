import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST='/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4183,r)); const BASE='http://127.0.0.1:4183'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
const ctx=await b.newContext({viewport:{width:1600,height:1000}})
await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
await ctx.route('**localhost:8080/**', r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname,'user')})}))
const page=await ctx.newPage()
await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})

// Land directly on page 3 via the URL (view state is URL-synced).
await page.goto(BASE+'/resources?page=3',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1800)
const snap = async (label) => {
  const r = await page.evaluate(()=>({
    rows: document.querySelectorAll('table tbody tr').length,
    first: document.querySelector('table tbody tr')?.textContent.trim().slice(0,34) || '(none)',
    url: location.search,
    empty: /No .*(match|result)|Nothing/i.test(document.body.innerText) ,
  }))
  console.log(`${label.padEnd(34)} rows=${String(r.rows).padEnd(3)} first="${r.first}" url=${r.url} emptyState=${r.empty}`)
}
await snap('on page 3, no search:')
const box = page.locator('input[type=search]').first()
await box.type('bi', {delay:60}); await page.waitForTimeout(700)
await snap('typed "bi" (74 matches):')
await box.fill(''); await page.waitForTimeout(300)
await box.type('billing-shard-4', {delay:40}); await page.waitForTimeout(700)
await snap('typed "billing-shard-4" (10):')
await box.fill(''); await page.waitForTimeout(300)
await box.type('fraud', {delay:60}); await page.waitForTimeout(700)
await snap('typed "fraud" (1 match):')
await ctx.close(); await b.close(); server.close()
