import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4190,r)); const BASE='http://127.0.0.1:4190'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
let pass=0, fail=0
const check=(name,ok,detail='')=>{ (ok?pass++:fail++); console.log(`  ${ok?'PASS':'**FAIL**'}  ${name}${detail?'  -- '+detail:''}`) }

async function ctxFor({role='user', handler=null, seedSession=true}={}) {
  const ctx=await b.newContext({viewport:{width:1600,height:1000}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  await ctx.route('**localhost:8080/**', async (r)=>{
    if (handler) { const done = await handler(r); if (done) return }
    const u=new URL(r.request().url())
    r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(u.pathname,role)})})
  })
  const page=await ctx.newPage()
  if (seedSession) await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:null,expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})
  else await page.addInitScript(()=>{sessionStorage.clear();localStorage.clear()})
  return {ctx,page}
}

// ─────────────────────────────────────────────────────────────────────────
console.log('\n[BUG 4] Resources search from a later page')
{
  const {ctx,page}=await ctxFor({role:'user'})
  await page.goto(BASE+'/resources?page=3',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1800)
  const before=await page.evaluate(()=>document.querySelector('table tbody tr')?.textContent.trim().slice(0,26))
  check('starts on page 3', /billing-shard-4/.test(before||''), `first row "${before}"`)
  await page.locator('input[type=search]').first().type('bi',{delay:60}); await page.waitForTimeout(700)
  const r=await page.evaluate(()=>({
    first: document.querySelector('table tbody tr')?.textContent.trim().slice(0,26),
    url: location.search, rows: document.querySelectorAll('table tbody tr').length }))
  check('2-letter search returns to page 1', !/[?&]page=/.test(r.url), `url="${r.url}"`)
  check('top match is now visible', /billing-primary/.test(r.first||''), `first row "${r.first}"`)
  await ctx.close()
}

// ─────────────────────────────────────────────────────────────────────────
console.log('\n[BUG 2] Re-used recovery code must NOT bounce to /login')
{
  let recoverCalls=0
  const handler = async (r) => {
    const u=new URL(r.request().url())
    if (u.pathname.endsWith('/auth/login')) {
      await r.fulfill({status:200,contentType:'application/json',
        body:JSON.stringify({success:true,data:{challenge_token:'chal-123', mfa_required:true}})}); return true
    }
    if (u.pathname.endsWith('/auth/mfa/recover')) {
      recoverCalls++
      await r.fulfill({status:401,contentType:'application/json',
        body:JSON.stringify({success:false,error:{message:'Invalid or already-used backup code'}})}); return true
    }
    return false
  }
  const {ctx,page}=await ctxFor({role:'user', handler, seedSession:false})
  await page.goto(BASE+'/login',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1200)
  await page.fill('#identifier','mallesh'); await page.fill('#password','hunter2hunter2')
  await page.click('button[type=submit]'); await page.waitForTimeout(1400)
  check('login issued an MFA challenge', page.url().includes('/mfa-verify'), page.url().replace(BASE,''))
  await page.getByRole('button',{name:/Recovery code/i}).click(); await page.waitForTimeout(400)
  await page.fill('#recovery-code','ABC123XYZ'); await page.waitForTimeout(200)
  await page.locator('button[type=submit]').first().click()
  await page.waitForTimeout(2000)
  const after = await page.evaluate(()=>({url:location.pathname, body:document.body.innerText}))
  check('stayed on the verification screen', after.url==='/mfa-verify', `landed on ${after.url}`)
  check('showed the rejection inline', /already-used backup code|Invalid/i.test(after.body))
  check('no "session has expired" toast', !/session has expired/i.test(after.body))
  check('recover endpoint called exactly once', recoverCalls===1, `calls=${recoverCalls}`)
  await ctx.close()
}

// ─────────────────────────────────────────────────────────────────────────
console.log('\n[BUG 3] Dashboard must re-poll sessions after an admin kill')
{
  let sessionCalls=0, killed=false
  const handler = async (r) => {
    const u=new URL(r.request().url())
    if (u.pathname.includes('/sessions/mine')) {
      sessionCalls++
      const sessions = killed ? [] : [{id:'s-1',resource_id:'r-0',resource_name:'billing-primary',
        user_id:'u-5',username:'mallesh',protocol:'postgresql',status:'ACTIVE',
        started_at:new Date(Date.now()-6e5).toISOString(),ended_at:null}]
      await r.fulfill({status:200,contentType:'application/json',
        body:JSON.stringify({success:true,data:{sessions,count:sessions.length,pagination:{total:sessions.length}}})}); return true
    }
    return false
  }
  const {ctx,page}=await ctxFor({role:'user', handler})
  await page.goto(BASE+'/',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(2000)
  const initial=sessionCalls
  check('dashboard fetched sessions on load', initial>=1, `calls=${initial}`)
  killed = true                     // the admin kills it server-side
  await page.waitForTimeout(17000)  // one poll interval (15s) + slack
  check('dashboard re-polled without a reload', sessionCalls>initial, `calls ${initial} -> ${sessionCalls}`)
  await ctx.close()
}

// ─────────────────────────────────────────────────────────────────────────
console.log('\n[BUG 1] Enrolled account must not be told to set up MFA')
{
  const shapes = {
    'canonical mfa_enabled:true':      {mfa_enabled:true},
    'mfa_enrolled:true':               {mfa_enrolled:true},
    'nested mfa:{enrolled:true}':      {mfa:{enrolled:true}},
    'nested mfa_status:{enabled:true}':{mfa_status:{enabled:true}},
  }
  for (const [label, extra] of Object.entries(shapes)) {
    const me = {user_id:'u-5',username:'mallesh',roles:['user'],mfa_required:true,
      mfa_policy_mode:'enforce',mfa_enrolment_required:false,mfa_policy_roles:['user'],...extra}
    const handler = async (r) => {
      const u=new URL(r.request().url())
      if (u.pathname.includes('/auth/me')) { await r.fulfill({status:200,contentType:'application/json',
        body:JSON.stringify({success:true,data:me})}); return true }
      return false
    }
    const {ctx,page}=await ctxFor({role:'user', handler})
    await page.goto(BASE+'/',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1600)
    const nagged=await page.evaluate(()=>/Multi-factor authentication is required|Set up multi-factor/i.test(document.body.innerText))
    check(`silent for ${label}`, !nagged)
    await ctx.close()
  }
  // And it must STILL nag when genuinely not enrolled.
  const me={user_id:'u-5',username:'mallesh',roles:['user'],mfa_required:true,
    mfa_policy_mode:'enforce',mfa_enrolment_required:false,mfa_enabled:false,mfa_policy_roles:['user']}
  const handler=async(r)=>{const u=new URL(r.request().url())
    if(u.pathname.includes('/auth/me')){await r.fulfill({status:200,contentType:'application/json',
      body:JSON.stringify({success:true,data:me})});return true} return false}
  const {ctx,page}=await ctxFor({role:'user', handler})
  await page.goto(BASE+'/',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1600)
  const nagged=await page.evaluate(()=>/Multi-factor authentication is required/i.test(document.body.innerText))
  check('still nags when NOT enrolled (no false negative)', nagged)
  await ctx.close()
}

console.log(`\n=============== ${pass} passed, ${fail} failed ===============`)
await b.close(); server.close()
process.exit(fail ? 1 : 0)
