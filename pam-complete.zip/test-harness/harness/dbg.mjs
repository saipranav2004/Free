import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4196,r)); const BASE='http://127.0.0.1:4196'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
const ctx=await b.newContext({viewport:{width:1500,height:950}})
await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
const seen=[]
await ctx.route('**localhost:8080/**', async r=>{
  const p=new URL(r.request().url()).pathname; seen.push(p)
  const json=(d)=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:d})})
  if (p.endsWith('/agent/devices')) return json({devices:[],count:0})
  if (p.includes('/connect-info')) return json({type:'postgresql',host:'db',port:5432,has_credential:true})
  return json(payloadFor(p,'user'))
})
const page=await ctx.newPage()
page.on('pageerror',e=>console.log('PAGEERROR:',e.message.slice(0,200)))
await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})
await page.goto(BASE+'/resources/r-0',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(2200)
console.log('location:', await page.evaluate(()=>location.pathname))
console.log('h1:', await page.evaluate(()=>document.querySelector('h1')?.textContent))
console.log('--- requests seen ---'); console.log([...new Set(seen)].join('\n'))
console.log('--- buttons ---')
console.log(await page.evaluate(()=>[...document.querySelectorAll('button,a')].map(b=>b.textContent.trim()).filter(Boolean).slice(0,25).join(' | ')))
console.log('--- body head ---')
console.log((await page.evaluate(()=>document.body.innerText)).slice(0,500))
await b.close(); server.close()
