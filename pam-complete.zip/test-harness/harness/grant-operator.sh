#!/bin/bash
# Give the STANDARD user standing access to one resource, the way an
# administrator would: by widening the policy their role already carries.
#
# A standard user starts with resource-access-default-deny, whose resource
# list is empty — the actions are allowed, on nothing. That is the product's
# default and it is correct, but it also means every check of the operator's
# own screens sees an empty Resources page unless something grants them
# access first. This is that something.
#
# Usage: grant-operator.sh <resource-id> [username]
set -eu
RES=${1:?resource id}
USER_NAME=${2:-operator1}
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
PSQL="psql -h /tmp -p 5433 -U postgres -d postgres -tAc"

$PSQL "
update pam.pam_policies
set resources_json = (
  select jsonb_agg(distinct x)::text
  from jsonb_array_elements_text(
    coalesce(nullif(resources_json,'')::jsonb, '[]'::jsonb) || to_jsonb(array['pam:resource/'||'$RES'])
  ) as t(x)
),
updated_at = now()
where name = 'resource-access-default-deny';"

echo "granted $USER_NAME standing access to $RES"
$PSQL "select resources_json from pam.pam_policies where name='resource-access-default-deny';"
