#!/bin/bash
# Register one resource with a VAULTED credential, the way every channel needs.
# Usage: seed-app.sh <id> <name> <type> <host> <port> <connect_mode> <console_url> <account> <secret>
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
ID=$1 NAME=$2 TYPE=$3 HOST=$4 PORT=$5 MODE=$6 CONSOLE=$7 ACCT=${8:-admin} SECRET=${9:-local-test-only}
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
RID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "
DELETE FROM pam.pam_credentials WHERE resource_id='$ID';
DELETE FROM pam.pam_resources   WHERE id='$ID';
INSERT INTO pam.pam_resources (id,name,description,resource_type,host,port,connect_mode,console_url,is_active,always_record,created_by,created_at,updated_at)
VALUES ('$ID','$NAME','Channel-matrix fixture (real server)','$TYPE','$HOST',$PORT,'$MODE',NULLIF('$CONSOLE',''),true,true,'$RID',NOW(),NOW());"
T=$(cat /tmp/tok)
SAFE=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT id FROM pam.pam_safes ORDER BY created_at LIMIT 1;")
CID=$(curl -s --noproxy '*' -X POST -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
  -d "{\"name\":\"$ID-cred\",\"account_name\":\"$ACCT\",\"secret_plaintext\":\"$SECRET\",\"credential_type\":\"password\",\"resource_id\":\"$ID\",\"description\":\"matrix fixture\"}" \
  "http://127.0.0.1:8080/api/v1/pam/safes/$SAFE/credentials" \
  | python3 -c "import sys,json;print((json.load(sys.stdin).get('data') or {}).get('id',''))")
[ -z "$CID" ] && { echo "could not vault a credential for $ID (is /tmp/tok fresh?)" >&2; exit 1; }
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "UPDATE pam.pam_resources SET vault_entry_id='$CID' WHERE id='$ID';"
echo "seeded $ID ($TYPE) -> $HOST:$PORT  cred=$CID"
