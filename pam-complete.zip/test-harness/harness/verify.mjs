import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST='/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4180,r)); const BASE='http://127.0.0.1:4180'
const browser=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})

async function open(route, w, role='admin'){
  const ctx=await browser.newContext({viewport:{width:w,height:900}})
  await ctx.route('**://localhost:8080/**', r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname,role)})}))
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  const page=await ctx.newPage()
  await page.addInitScript(()=>sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null})))
  await page.goto(BASE+route,{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1200)
  return {ctx,page}
}

// ---- SETTINGS: is the <nav> the track-sizer? ----
{
  const {ctx,page}=await open('/settings',414)
  const before=await page.evaluate(()=>{
    const m=document.querySelector('#main-content'), n=document.querySelector('nav[aria-label="Settings sections"]')
    const ul=n?.querySelector('ul')
    return {main:[m.scrollWidth,m.clientWidth], nav:Math.round(n.getBoundingClientRect().width), ulScroll:ul?.scrollWidth, ulClient:ul?.clientWidth}
  })
  const after=await page.evaluate(()=>{
    const n=document.querySelector('nav[aria-label="Settings sections"]')
    n.style.minWidth='0'                       // the proposed fix
    const m=document.querySelector('#main-content'); const ul=n.querySelector('ul')
    return {main:[m.scrollWidth,m.clientWidth], nav:Math.round(n.getBoundingClientRect().width), ulScroll:ul.scrollWidth, ulClient:ul.clientWidth}
  })
  console.log('SETTINGS @414  before:',JSON.stringify(before))
  console.log('SETTINGS @414  after min-width:0 on <nav>:',JSON.stringify(after))
  await ctx.close()
}

// ---- DASHBOARD: does flex-wrap + removing flex-none fix it? ----
for (const w of [414,768]) {
  const {ctx,page}=await open('/',w)
  const before=await page.evaluate(()=>{const m=document.querySelector('#main-content');return [m.scrollWidth,m.clientWidth]})
  const after=await page.evaluate(()=>{
    // QuietSection header row: allow wrapping, let the toolbar shrink & scroll
    for(const row of document.querySelectorAll('section > div.mb-3\\.5')){
      row.style.flexWrap='wrap'
      const act=row.lastElementChild
      if(act && act.tagName==='DIV'){ act.style.flex='1 1 100%'; act.style.minWidth='0'; act.style.overflowX='auto' }
    }
    const m=document.querySelector('#main-content'); return [m.scrollWidth,m.clientWidth]
  })
  console.log(`DASHBOARD @${w}  before main ${before[0]}/${before[1]}  ->  after ${after[0]}/${after[1]}`)
  await ctx.close()
}
await browser.close(); server.close()
