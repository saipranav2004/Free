#!/bin/bash
# Drive ONE resource on ONE channel through the agent and report what was
# recorded. The per-app matrix is the same six steps every time — launch,
# watch the candidate the agent picked, let it run, end the session, wait for
# the upload, read the artifact back — so it lives here once rather than in
# nine copies.
#
# Usage: channel-test.sh <resource-id> <cli|desktop> [seconds]
#
# The web channel is NOT here: it does not involve the agent at all (the
# server brokers it and records rrweb), and e2e/minio-real.mjs already drives
# that path against a real target.
set -u
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
RES=${1:?resource id}
CHAN=${2:?cli|desktop}
HOLD=${3:-22}

export HOME=/tmp/agenthome-desktop
bash "$S/harness/login.sh" >/dev/null
T=$(cat /tmp/tok)

L=$(curl -s --noproxy '*' -X POST -H "Authorization: Bearer $T" \
      -H 'Content-Type: application/json' -d "{\"channel\":\"$CHAN\"}" \
      "http://127.0.0.1:8080/api/v1/pam/resources/$RES/launch")
URL=$(printf '%s' "$L" | python3 -c "import sys,json;print((json.load(sys.stdin).get('data') or {}).get('launch_url',''))" 2>/dev/null)
if [ -z "$URL" ]; then
  echo "LAUNCH REFUSED  $RES/$CHAN  ->  $(printf '%s' "$L" | head -c 200)"
  exit 1
fi

LOG=/tmp/ct-$RES-$CHAN.log
: > "$LOG"
# ELECTRON_DISABLE_SANDBOX is a CONTAINER concession, not a product setting:
# Chromium's sandbox needs privileges this test container does not grant. On a
# real desktop the app launches with no such variable.
(DISPLAY=:99 ELECTRON_DISABLE_SANDBOX=1 nohup /tmp/agent-bin launch "$URL" >"$LOG" 2>&1 &)

for _ in $(seq 1 20); do
  grep -q "candidate.selected" "$LOG" 2>/dev/null && break
  sleep 1
done
CAND=$(grep -o "candidate=[a-z0-9-]*" "$LOG" | head -1 | cut -d= -f2)
KIND=$(grep -o "kind=[a-z]*" "$LOG" | head -1 | cut -d= -f2)
SID=$(grep -o "session_id=[0-9a-f-]*" "$LOG" | head -1 | cut -d= -f2)
REC=$(grep -c "screen_recording.start.ok" "$LOG" 2>/dev/null || echo 0)

if [ -z "$SID" ]; then
  echo "NO SESSION  $RES/$CHAN"
  grep -iE "error|fail" "$LOG" | head -3
  exit 1
fi

sleep "$HOLD"

# End it the way an administrator does — which is also the path that proves
# terminate reaches this machine and the artifact gets uploaded.
curl -s --noproxy '*' -X POST -H "Authorization: Bearer $T" \
  -H 'Content-Type: application/json' -d '{}' \
  "http://127.0.0.1:8080/api/v1/pam/sessions/$SID/end" -o /dev/null

for _ in $(seq 1 40); do
  [ "$(pgrep -cf "^/tmp/agent-bin launch" 2>/dev/null || echo 0)" = "0" ] && break
  sleep 1
done
sleep 5

read -r FMT ST SZ DUR <<EOF
$(psql -h /tmp -p 5433 -U postgres -d postgres -tAc \
  "select coalesce(format,'-')||' '||coalesce(status,'-')||' '||coalesce(size_bytes,0)||' '||coalesce(duration_seconds,0) from pam.pam_session_recordings where session_id='$SID';" 2>/dev/null)
EOF

SURV=$(pgrep -cf "^/tmp/agent-bin" 2>/dev/null || echo 0)
printf '%-14s %-8s cand=%-18s kind=%-8s rec=%-9s %-10s %8s B  %3ss  survivors=%s\n' \
  "$RES" "$CHAN" "${CAND:--}" "${KIND:--}" "${FMT:--}" "${ST:--}" "${SZ:-0}" "${DUR:-0}" "$SURV"
