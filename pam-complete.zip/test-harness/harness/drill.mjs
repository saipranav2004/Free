import { chromium } from 'playwright'
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { payloadFor } from './mock.js'

const DIST = '/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const MIME = { '.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml' }
const server = http.createServer((req,res)=>{let p=decodeURIComponent(req.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(res)})
await new Promise(r=>server.listen(4179,r))
const BASE='http://127.0.0.1:4179'
const browser = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] })

const CASES = [
  { role:'admin', route:'/',         w:414 },
  { role:'admin', route:'/settings', w:414 },
  { role:'admin', route:'/',         w:768 },
  { role:'user',  route:'/',         w:414 },
  { role:'admin', route:'/resources',w:414 },
  { role:'admin', route:'/admin/identity', w:414 },
]
for (const c of CASES) {
  const ctx = await browser.newContext({ viewport:{width:c.w,height:900} })
  await ctx.route('**://localhost:8080/**', r => r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname, c.role)})}))
  await ctx.route('**/*', r => r.request().url().startsWith(BASE) ? r.continue() : r.abort())
  const page = await ctx.newPage()
  await page.addInitScript((role)=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}))},c.role)
  await page.goto(BASE+c.route,{waitUntil:'domcontentloaded'})
  await page.waitForTimeout(1200)
  const res = await page.evaluate(()=>{
    const main=document.querySelector('#main-content'); if(!main) return {err:'no main'}
    const limit = main.getBoundingClientRect().left + main.clientWidth
    const out=[]
    for(const el of main.querySelectorAll('*')){
      const r=el.getBoundingClientRect()
      if(r.width===0) continue
      if(r.right>limit+1){
        // culprit = widest element whose PARENT fits
        const pr=el.parentElement?.getBoundingClientRect()
        out.push({tag:el.tagName.toLowerCase(),cls:String(el.className?.baseVal ?? el.className ?? '').slice(0,130),w:Math.round(r.width),right:Math.round(r.right),parentFits: pr? pr.right<=limit+1 : null, txt:(el.textContent||'').trim().slice(0,45)})
      }
    }
    return {limit:Math.round(limit), mainScrollW:main.scrollWidth, mainClientW:main.clientWidth, culprits: out.filter(o=>o.parentFits).slice(0,8), totalOver: out.length}
  })
  console.log(`\n### ${c.role} ${c.route} @${c.w}px  main ${res.mainScrollW}/${res.mainClientW}  (${res.totalOver} elements past edge)`)
  for(const o of res.culprits||[]) console.log(`   <${o.tag}> w=${o.w} right=${o.right} "${o.txt}"\n       class="${o.cls}"`)
  await ctx.close()
}
await browser.close(); server.close()
