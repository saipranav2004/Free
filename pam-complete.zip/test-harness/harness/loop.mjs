// The full loop: the capability report the REAL pam-agent binary produced on
// this machine, fed to the console exactly as the server would hand it back.
import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR
const paired = JSON.parse(fs.readFileSync(new URL('./real-agent-report.json', import.meta.url)))
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4197,r)); const BASE='http://127.0.0.1:4197'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
let pass=0,fail=0
const check=(n,ok,d='')=>{(ok?pass++:fail++);console.log(`  ${ok?'PASS':'**FAIL**'}  ${n}${d?'  -- '+d:''}`)}

// Exactly what the agent sent, under the key ListDevices serves it as.
const device = {
  id:'dev-123', device_name: paired.device_name, status:'ACTIVE',
  os: paired.os, arch: paired.arch, hostname: paired.hostname,
  agent_version: paired.agent_version,
  created_at: new Date(Date.now()-60000).toISOString(),
  capabilities: paired.capabilities,
}

async function tryConnect({resourceType, alwaysRecord=false}) {
  const ctx=await b.newContext({viewport:{width:1500,height:950}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  let launched=false
  await ctx.route('**localhost:8080/**', async r=>{
    const p=new URL(r.request().url()).pathname
    const json=(d)=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:d})})
    if (p.endsWith('/agent/devices')) return json({devices:[device],count:1})
    if (p.endsWith('/launch')) { launched=true; return json({launch_id:'L1',launch_url:'pam-agent://x',expires_in_seconds:60}) }
    if (p.includes('/agent/launch/L1/status')) return json({state:'waiting'})
    if (p.includes('/connect-info')) return json({type:resourceType,host:'h',port:1,has_credential:true,always_record:alwaysRecord})
    if (/\/resources\/[^/]+$/.test(p) && !p.endsWith('/resources'))
      return json({resource:{id:'r-0',name:'fixture',resource_type:resourceType,host:'h',port:1,is_active:true,always_record:alwaysRecord}})
    return json(payloadFor(p,'admin'))
  })
  const page=await ctx.newPage()
  await page.addInitScript(()=>{
    sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}))
    localStorage.clear(); localStorage.setItem('pam_agent_pairing',JSON.stringify({startedAt:Date.now()-120000}))
    Object.defineProperty(navigator,'userAgentData',{get:()=>({platform:'Linux'}),configurable:true})
  })
  await page.goto(BASE+'/resources/r-0',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1700)
  await page.getByRole('button',{name:/^Connect$/}).first().click(); await page.waitForTimeout(1200)
  const body=await page.evaluate(()=>document.body.innerText)
  await ctx.close()
  return {launched, body}
}

console.log('\nUsing the report the real agent produced on this machine:')
console.log(`  os=${paired.os} arch=${paired.arch} host=${paired.hostname} ffmpeg=${paired.capabilities.screen_recorder}`)
console.log('  psql installed here: yes   mongosh installed here: no\n')

let r = await tryConnect({resourceType:'postgresql'})
check('postgresql (psql IS installed) -> hands off', r.launched && /Opening on this device/.test(r.body))

r = await tryConnect({resourceType:'mongodb'})
check('mongodb (mongosh NOT installed) -> names mongosh, no handoff',
      !r.launched && /does not have mongosh/i.test(r.body),
      (r.body.match(/does not have[^\n]*/)||['(no message)'])[0].slice(0,90))

r = await tryConnect({resourceType:'clickhouse'})
check('clickhouse (no client at all) -> refuses with install hint',
      !r.launched && /clickhouse-client/i.test(r.body))

r = await tryConnect({resourceType:'metabase', alwaysRecord:true})
check('metabase, must be recorded, browser-only -> steers to the proxy',
      !r.launched && /browser through PAM/i.test(r.body),
      (r.body.match(/can only be opened[^\n]*/)||['(no message)'])[0].slice(0,100))

r = await tryConnect({resourceType:'metabase', alwaysRecord:false})
check('metabase, no recording obligation -> still allowed', r.launched)

r = await tryConnect({resourceType:'web'})
check('generic web app (the type that had NO template) -> now works', r.launched)

console.log(`\n=============== ${pass} passed, ${fail} failed ===============`)
await b.close(); server.close(); process.exit(fail?1:0)
