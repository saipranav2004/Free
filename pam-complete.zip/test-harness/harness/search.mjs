import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST='/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4182,r)); const BASE='http://127.0.0.1:4182'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})

async function open(route, role='user', w=1440){
  const ctx=await b.newContext({viewport:{width:w,height:1000}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  await ctx.route('**localhost:8080/**', r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname,role)})}))
  const page=await ctx.newPage()
  page.on('pageerror', e=>console.log('  PAGEERROR:',e.message.slice(0,160)))
  await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})
  await page.goto(BASE+route,{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1600)
  return {ctx,page}
}
const rowCount = (page) => page.evaluate(()=>document.querySelectorAll('table tbody tr').length)
const firstNames = (page) => page.evaluate(()=>[...document.querySelectorAll('table tbody tr')].slice(0,4).map(r=>r.textContent.trim().slice(0,42)))

for (const role of ['user','admin']) {
  console.log(`\n================ RESOURCES SEARCH (${role}) ================`)
  const {ctx,page}=await open('/resources',role)
  console.log('baseline rows:', await rowCount(page), await firstNames(page))
  const box = page.locator('input[type=search]').first()
  for (const term of ['b','bi','bil','billing','ca','cache','db_orders','MongoDB','Redis','ARCHIVE','fraud']) {
    await box.fill('')
    await page.waitForTimeout(120)
    await box.type(term, {delay: 45})
    await page.waitForTimeout(450)
    const n = await rowCount(page)
    const url = new URL(page.url())
    console.log(`  "${term}" -> ${n} rows   q=${url.searchParams.get('q')}  page=${url.searchParams.get('page')}`)
  }
  await ctx.close()
}
await b.close(); server.close()
