import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR, TAG=process.env.TAG
const OUT='/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/shots2'
fs.mkdirSync(OUT,{recursive:true})
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4193,r)); const BASE='http://127.0.0.1:4193'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
for (const [name,route,role,w] of [['dashboard','/','admin',414],['settings','/settings','admin',414],['resources','/resources','admin',414]]) {
  const ctx=await b.newContext({viewport:{width:w,height:900}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  await ctx.route('**localhost:8080/**', r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname,role)})}))
  const page=await ctx.newPage()
  await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})
  await page.goto(BASE+route,{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1800)
  await page.screenshot({path:`${OUT}/${TAG}-${name}-414.png`})
  await ctx.close()
}
await b.close(); server.close()
