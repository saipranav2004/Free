import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4195,r)); const BASE='http://127.0.0.1:4195'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
let pass=0,fail=0
const check=(n,ok,d='')=>{(ok?pass++:fail++);console.log(`  ${ok?'PASS':'**FAIL**'}  ${n}${d?'  -- '+d:''}`)}

const PSQL_CAPS = {os:'linux',arch:'amd64',screen_recorder:true,types:[
  {resource_type:'postgresql',kinds:['cli'],tools:['psql'],missing:[]},
  {resource_type:'mongodb',kinds:[],tools:[],missing:[
    {id:'mongosh',kind:'cli',command:'mongosh',install_hint:'Install MongoDB Shell from mongodb.com/try/download/shell.'},
    {id:'mongodb-compass',kind:'gui',command:'mongodb-compass',install_hint:'Install MongoDB Compass.'}]},
]}

// Chromium on Linux reports platform "Linux"; override UA platform per case.
async function run({label, devices, resourceType, platform, launchState='waiting', marker=null, expect}) {
  const ctx=await b.newContext({viewport:{width:1500,height:950}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  let launchCreated=false
  await ctx.route('**localhost:8080/**', async r=>{
    const u=new URL(r.request().url())
    const p=u.pathname
    const json=(d)=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:d})})
    if (p.endsWith('/agent/devices')) return json({devices, count:devices.length})
    if (p.endsWith('/launch')) { launchCreated=true; return json({launch_id:'L1',launch_url:'pam-agent://launch?token=t',expires_in_seconds:60}) }
    if (p.includes('/agent/launch/L1/status')) return json({state:launchState, launch_id:'L1'})
    if (p.includes('/connect-info')) return json({type:resourceType, host:'db.internal', port:5432, has_credential:true})
    // The detail page's header button reads the RESOURCE's own type, so the
    // fixture has to carry the type under test rather than a fixed one.
    if (/\/resources\/[^/]+$/.test(p) && !p.endsWith('/resources'))
      return json({resource:{id:'r-0',name:'fixture',resource_type:resourceType,host:'db.internal',port:5432,is_active:true,requires_jit:false}})
    return json(payloadFor(p,'admin'))
  })
  const page=await ctx.newPage()
  await page.addInitScript(([plat,mk])=>{
    sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}))
    localStorage.clear()
    if (mk) localStorage.setItem('pam_agent_pairing', JSON.stringify({startedAt: mk}))
    Object.defineProperty(navigator,'userAgentData',{get:()=>({platform:plat}),configurable:true})
    Object.defineProperty(navigator,'platform',{get:()=>plat,configurable:true})
    // pam-agent:// navigation must not kill the page in a test
    const origAssign = Object.getOwnPropertyDescriptor(window.Location.prototype,'href')
    window.__navs=[]
  },[platform, marker])
  await page.goto(BASE+'/resources/r-0',{waitUntil:'domcontentloaded'})
  await page.waitForTimeout(1800)
  const btn = page.getByRole('button',{name:/^Connect$/}).first()
  if (await btn.count()===0) { check(label,false,'Connect button not found'); await ctx.close(); return }
  await btn.click()
  await page.waitForTimeout(expect.afterPoll ? 4200 : 1200)
  const body = await page.evaluate(()=>document.body.innerText)
  const ok = expect.text.test(body)
  check(label, ok && (expect.launched===undefined || expect.launched===launchCreated),
        ok ? `launchCreated=${launchCreated}` : `toast not found; saw: ${(body.match(/(Device not paired[^\n]*|does not have[^\n]*|Opening on this device[^\n]*|Handing off[^\n]*)/)||['(none)'])[0]}`)
  await ctx.close()
}

console.log('\n[BUG 1] the paired device is NOT this machine')
await run({label:'paired Windows laptop, browsing from macOS -> refuse, no handoff',
  devices:[{id:'d1',device_name:'DESKTOP-A (windows)',status:'ACTIVE',os:'windows',arch:'amd64',created_at:'2026-09-01T10:00:00Z'}],
  resourceType:'postgresql', platform:'macOS',
  expect:{text:/Device not paired\. Pair this device before opening resources in a desktop app\./, launched:false}})

await run({label:'no paired device at all -> refuse, no handoff',
  devices:[], resourceType:'postgresql', platform:'Windows',
  expect:{text:/Device not paired\./, launched:false}})

await run({label:'device matches this OS and this browser paired it -> hands off',
  devices:[{id:'d1',device_name:'workstation (linux)',status:'ACTIVE',os:'linux',arch:'amd64',
            created_at:new Date(Date.now()-60000).toISOString(),capabilities:PSQL_CAPS}],
  resourceType:'postgresql', platform:'Linux', marker: Date.now()-120000,
  expect:{text:/Opening on this device/, launched:true}})

await run({label:'revoked device does not count as paired -> refuse',
  devices:[{id:'d1',device_name:'old (linux)',status:'REVOKED',os:'linux',created_at:'2026-01-01T10:00:00Z'}],
  resourceType:'postgresql', platform:'Linux',
  expect:{text:/Device not paired\./, launched:false}})

console.log('\n[BUG 1b] ambiguous device: hands off, then self-corrects when nothing redeems it')
await run({label:'plausible device, handoff expires unredeemed -> the same refusal',
  devices:[{id:'d1',device_name:'other-linux-box',status:'ACTIVE',os:'linux',arch:'amd64',
            created_at:'2026-01-01T10:00:00Z',capabilities:PSQL_CAPS}],
  resourceType:'postgresql', platform:'Linux', launchState:'expired',
  expect:{text:/Device not paired\. Pair this device before opening resources in a desktop app\./, launched:true, afterPoll:true}})

console.log('\n[BUG 2] the tool is not installed on that machine')
await run({label:'mongodb with no mongosh/compass -> names the tools, no handoff',
  devices:[{id:'d1',device_name:'workstation (linux)',status:'ACTIVE',os:'linux',arch:'amd64',
            created_at:new Date(Date.now()-60000).toISOString(),capabilities:PSQL_CAPS}],
  resourceType:'mongodb', platform:'Linux', marker: Date.now()-120000,
  expect:{text:/does not have mongosh.*installed/i, launched:false}})

await run({label:'postgresql with psql present -> still hands off (no false refusal)',
  devices:[{id:'d1',device_name:'workstation (linux)',status:'ACTIVE',os:'linux',arch:'amd64',
            created_at:new Date(Date.now()-60000).toISOString(),capabilities:PSQL_CAPS}],
  resourceType:'postgresql', platform:'Linux', marker: Date.now()-120000,
  expect:{text:/Opening on this device/, launched:true}})

await run({label:'agent too old to report capabilities -> does NOT refuse',
  devices:[{id:'d1',device_name:'legacy (linux)',status:'ACTIVE',os:'linux',
            created_at:new Date(Date.now()-60000).toISOString()}],
  resourceType:'mongodb', platform:'Linux', marker: Date.now()-120000,
  expect:{text:/Opening on this device/, launched:true}})

console.log(`\n=============== ${pass} passed, ${fail} failed ===============`)
await b.close(); server.close(); process.exit(fail?1:0)
