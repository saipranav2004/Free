import { chromium } from 'playwright'
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { payloadFor, MOCK_USER } from './mock.js'

const DIST = '/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const OUT = '/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/shots'
fs.mkdirSync(OUT, { recursive: true })

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json' }

// SPA static server
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0])
  let file = path.join(DIST, p)
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, 'index.html')
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' })
  fs.createReadStream(file).pipe(res)
})
await new Promise((r) => server.listen(4178, r))
const BASE = 'http://127.0.0.1:4178'

const WIDTHS = [
  { name: '1920', w: 1920, h: 1080 },
  { name: '1366', w: 1366, h: 768 },
  { name: '1024', w: 1024, h: 768 },
  { name: '768', w: 768, h: 1024 },
  { name: '414', w: 414, h: 896 },
]

// Chrome and Edge are both Chromium; the UA is what a site can branch on.
const UAS = {
  chrome: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
  edge: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0',
}

const ROUTES = {
  user: ['/', '/resources', '/vault', '/sessions', '/jit', '/settings', '/notifications'],
  admin: ['/', '/resources', '/admin/identity', '/admin/roles', '/admin/policies', '/admin/jit', '/admin/audit', '/admin/mfa-policy', '/admin/vault-ops', '/settings'],
  root: ['/', '/admin/identity', '/admin/identity-graph', '/settings'],
}

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
const findings = []
const consoleErrors = []

for (const [uaName, ua] of Object.entries(UAS)) {
  for (const role of Object.keys(ROUTES)) {
    for (const vp of WIDTHS) {
      const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h }, userAgent: ua, deviceScaleFactor: 1 })
      // Registered FIRST so the API handler below (registered last) wins.
      await ctx.route('**/*', async (route) => {
        const u = route.request().url()
        if (u.startsWith('http://127.0.0.1:4178')) return route.continue()
        return route.abort()
      })
      await ctx.route('**localhost:8080/**', async (route) => {
        const u = new URL(route.request().url())
        await route.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': '*' },
          body: JSON.stringify({ success: true, message: 'ok', data: payloadFor(u.pathname, role) }) })
      })
      const page = await ctx.newPage()
      page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(`${uaName}/${role}/${vp.name}: ${m.text().slice(0, 200)}`) })
      await page.addInitScript((r) => {
        sessionStorage.setItem('pam_session', JSON.stringify({
          accessToken: 'mock.' + btoa(JSON.stringify({ sub: 'u', roles: [r] })) + '.sig',
          refreshToken: 'mock-refresh',
          expiresAt: new Date(Date.now() + 36e5).toISOString(),
          user: null,
        }))
      }, role)

      for (const r of ROUTES[role]) {
        await page.goto(BASE + r, { waitUntil: 'domcontentloaded', timeout: 15000 }).catch(() => {})
        await page.waitForTimeout(900)
        const m = await page.evaluate(() => {
          const de = document.documentElement
          const over = []
          const vw = de.clientWidth
          for (const el of document.querySelectorAll('body *')) {
            const rect = el.getBoundingClientRect()
            if (rect.width === 0) continue
            if (rect.right > vw + 1.5) {
              // only report if no scrollable ancestor absorbs it
              let a = el.parentElement, absorbed = false
              while (a && a !== document.body) {
                const st = getComputedStyle(a)
                if (st.overflowX === 'auto' || st.overflowX === 'scroll' || st.overflowX === 'hidden') { absorbed = true; break }
                a = a.parentElement
              }
              if (!absorbed) over.push({ tag: el.tagName.toLowerCase(), cls: (el.className && el.className.baseVal !== undefined ? el.className.baseVal : String(el.className || '')).slice(0, 110), right: Math.round(rect.right), w: Math.round(rect.width) })
            }
          }
          const main = document.querySelector('#main-content')
          return {
            docScrollW: de.scrollWidth, docClientW: de.clientWidth,
            bodyScrollW: document.body.scrollWidth,
            mainScrollW: main ? main.scrollWidth : null, mainClientW: main ? main.clientWidth : null,
            overflowers: over.slice(0, 6),
            title: (document.querySelector('h1')?.textContent || '').slice(0, 60),
            consoleTitle: document.querySelector('aside h2')?.textContent || '',
            navItems: [...document.querySelectorAll('nav[aria-label="Primary"] a')].map(a=>a.textContent.trim()),
            rows: document.querySelectorAll('tbody tr').length,
          }
        })
        const horizontal = m.docScrollW > m.docClientW + 1 || (m.mainScrollW && m.mainScrollW > m.mainClientW + 1)
        if (horizontal || m.overflowers.length) {
          findings.push({ ua: uaName, role, vp: vp.name, route: r, ...m })
        }
        const safe = r.replace(/\//g, '_') || '_root'
        if (uaName === 'chrome') {
          await page.screenshot({ path: `${OUT}/${role}${safe}__${vp.name}.png`, fullPage: false }).catch(() => {})
        }
      }
      await ctx.close()
    }
  }
}
await browser.close()
server.close()

fs.writeFileSync(`${OUT}/findings.json`, JSON.stringify({ findings, consoleErrors: [...new Set(consoleErrors)] }, null, 2))
console.log('=== HORIZONTAL OVERFLOW / UNABSORBED OVERFLOW FINDINGS ===')
for (const f of findings) {
  console.log(`[${f.ua}] ${f.role} @${f.vp} ${f.route}  doc ${f.docScrollW}/${f.docClientW}  main ${f.mainScrollW}/${f.mainClientW}`)
  for (const o of f.overflowers) console.log(`      <${o.tag}> w=${o.w} right=${o.right} .${o.cls}`)
}
console.log(`\ntotal findings: ${findings.length}`)
console.log('=== CONSOLE ERRORS (unique) ===')
console.log([...new Set(consoleErrors)].slice(0, 25).join('\n') || '(none)')
