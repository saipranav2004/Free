import { chromium } from 'playwright'
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'
import { payloadFor } from './mock.js'
const DIST=process.env.DIST_DIR
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png'}
const server=http.createServer((q,s)=>{let p=decodeURIComponent(q.url.split('?')[0]);let f=path.join(DIST,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(DIST,'index.html');s.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(s)})
await new Promise(r=>server.listen(4192,r)); const BASE='http://127.0.0.1:4192'
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']})
for (const [role,w] of [['admin',414],['admin',1024],['user',414]]) {
  const ctx=await b.newContext({viewport:{width:w,height:900}})
  await ctx.route('**/*', r=>r.request().url().startsWith(BASE)?r.continue():r.abort())
  await ctx.route('**localhost:8080/**', r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true,data:payloadFor(new URL(r.request().url()).pathname,role)})}))
  const page=await ctx.newPage()
  await page.addInitScript(()=>{sessionStorage.setItem('pam_session',JSON.stringify({accessToken:'m.m.m',refreshToken:'r',expiresAt:new Date(Date.now()+36e5).toISOString(),user:null}));localStorage.clear()})
  await page.goto(BASE+'/resources',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(1600)
  const r=await page.evaluate(()=>{
    const tbl=document.querySelector('table'); const wrap=tbl.parentElement
    const headers=[...tbl.querySelectorAll('thead th')].map(th=>th.textContent.trim()).filter(Boolean)
    const cardRight=wrap.getBoundingClientRect().right
    wrap.scrollLeft = wrap.scrollWidth        // scroll fully right
    const lastTh = tbl.querySelectorAll('thead th')
    const last = lastTh[lastTh.length-1]
    return {headers, canScroll: wrap.scrollWidth>wrap.clientWidth,
            scrolledTo: wrap.scrollLeft, maxScroll: wrap.scrollWidth-wrap.clientWidth,
            lastHeaderVisibleAfterScroll: last.getBoundingClientRect().right <= cardRight + 2
              && last.getBoundingClientRect().left >= wrap.getBoundingClientRect().left - 2}
  })
  console.log(`${role} @${w}px  cols=[${r.headers.join('|')}]`)
  console.log(`   scrollable=${r.canScroll}  scrolled ${r.scrolledTo}/${r.maxScroll}  last column reachable=${r.lastHeaderVisibleAfterScroll}`)
  await ctx.close()
}
await b.close(); server.close()
