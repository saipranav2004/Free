package handlers

import (
	"os"
	"regexp"
	"strings"
	"testing"
)

// The channel the operator chose has to reach the agent ON THE WIRE.
//
// This is a source-level assertion rather than a request test, and that is
// deliberate: the bug it guards was invisible to every unit test that already
// existed. The agent's candidate selector was correct and tested
// (launcher.TestAskingForDesktopOpensTheDesktopApp passed throughout), the
// launch token stored the channel, and apiclient.ResolvedLaunch had a field
// waiting for it. Only ResolveLaunch's response payload left it out, so the
// agent always received an empty channel, skipped the filter entirely, and
// launched whichever candidate happened to come first.
//
// What that looked like in practice, measured on a machine with both
// installed: clicking "Open in Desktop App" on a redis resource started
// redis-cli in a terminal instead of RedisInsight. The same would hold for
// psql over pgAdmin 4 and sqlplus over SQL Developer — on any machine where a
// CLI tool is present, it wins over the GUI the operator actually asked for.
//
// A request-level test would need the whole launch-token and signing path
// stood up to observe one map key. Reading the payload the handler builds is
// the cheapest thing that fails when the key goes missing again.
func TestResolveLaunchSendsTheChannelToTheAgent(t *testing.T) {
	src, err := os.ReadFile("agent_handler.go")
	if err != nil {
		t.Fatalf("read agent_handler.go: %v", err)
	}
	body := string(src)

	// Locate the payload ResolveLaunch hands back, by an anchor that has to
	// be in it: the session id the agent needs for everything afterwards.
	idx := strings.Index(body, `"session_id":         resolved.SessionID`)
	if idx < 0 {
		// The formatting changed; fall back to a looser anchor so this test
		// reports the real problem rather than its own brittleness.
		idx = strings.Index(body, `"session_id":`)
	}
	if idx < 0 {
		t.Fatal(`could not find the resolve payload (no "session_id" key) — ` +
			"if it moved, point this test at its new home rather than deleting it")
	}

	// A window around the anchor, big enough to hold the whole payload.
	start := idx - 4000
	if start < 0 {
		start = 0
	}
	end := idx + 4000
	if end > len(body) {
		end = len(body)
	}
	payload := body[start:end]

	if !regexp.MustCompile(`"channel":\s*resolved\.Channel`).MatchString(payload) {
		t.Error(`ResolveLaunch does not send "channel": resolved.Channel to the agent.` + "\n" +
			"Without it the agent cannot tell cli from desktop from web, so " +
			`"Open in Desktop App" opens whatever tool is found first — ` +
			"usually the CLI client, because those are the ones people already have.")
	}
}
