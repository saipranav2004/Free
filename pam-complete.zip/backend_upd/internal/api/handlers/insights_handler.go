// pam/internal/api/handlers/insights_handler.go
//
// The figures the console's insight cards render.
//
// Routes:
//
//	GET /api/v1/pam/insights/sessions        → what is running right now
//	GET /api/v1/pam/insights/audit?days=N    → activity, refusals, busiest actors
//	GET /api/v1/pam/admin/insights/vault     → secret inventory and reveal rate
//	GET /api/v1/pam/admin/insights/services  → machine identities and token runway
//
// Split across two planes on purpose. Sessions and audit are things an
// operator legitimately sees about THEMSELVES, so they sit on the normal plane
// and are scoped by callerScope — the same rule the audit listing already
// uses. Vault inventory and service-identity posture are fleet-wide facts with
// no per-user meaning, so they are admin-only rather than scoped: there is no
// honest "your share" of how many break-glass credentials exist.
package handlers

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type InsightsHandler struct {
	svc    *services.InsightsService
	logger *zap.Logger
}

func NewInsightsHandler(svc *services.InsightsService, logger *zap.Logger) *InsightsHandler {
	return &InsightsHandler{svc: svc, logger: logger}
}

// auditWindowDays reads ?days, clamped.
//
// Clamped rather than validated-and-rejected: this feeds a chart above a
// table, and a bad query string should degrade to a sensible chart, not a
// red error box. The ceiling is what stops a stray days=100000 from turning a
// decorative header into a full-table scan.
func auditWindowDays(c *gin.Context) int {
	days, err := strconv.Atoi(c.DefaultQuery("days", "30"))
	if err != nil || days < 1 {
		return 30
	}
	if days > 90 {
		return 90
	}
	return days
}

// Sessions serves GET /api/v1/pam/insights/sessions.
func (h *InsightsHandler) Sessions(c *gin.Context) {
	userID, unrestricted := callerScope(c)
	out, err := h.svc.Sessions(c.Request.Context(), userID, !unrestricted)
	if err != nil {
		h.logger.Error("insights.sessions.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load session insights")
		return
	}
	response.Success(c, out, "Session insights retrieved")
}

// Audit serves GET /api/v1/pam/insights/audit.
func (h *InsightsHandler) Audit(c *gin.Context) {
	userID, unrestricted := callerScope(c)
	scope := userID
	if unrestricted {
		scope = ""
	}
	out, err := h.svc.Audit(c.Request.Context(), auditWindowDays(c), scope)
	if err != nil {
		h.logger.Error("insights.audit.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load audit insights")
		return
	}
	response.Success(c, out, "Audit insights retrieved")
}

// Vault serves GET /api/v1/pam/admin/insights/vault.
func (h *InsightsHandler) Vault(c *gin.Context) {
	out, err := h.svc.Vault(c.Request.Context())
	if err != nil {
		h.logger.Error("insights.vault.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load vault insights")
		return
	}
	response.Success(c, out, "Vault insights retrieved")
}

// Services serves GET /api/v1/pam/admin/insights/services.
func (h *InsightsHandler) Services(c *gin.Context) {
	out, err := h.svc.Services(c.Request.Context())
	if err != nil {
		h.logger.Error("insights.services.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load service insights")
		return
	}
	response.Success(c, out, "Service identity insights retrieved")
}

// Away serves GET /api/v1/pam/insights/away — the "while you were away"
// digest.
//
// Deliberately a READ that does not move the anchor. Rendering the card and
// acknowledging it are two different events: a dashboard that reloads three
// times before the operator looks at it would otherwise blank its own digest.
// The client calls Seen below when the operator actually dismisses it.
func (h *InsightsHandler) Away(c *gin.Context) {
	userID, unrestricted := callerScope(c)
	scope := userID
	if unrestricted {
		scope = ""
	}
	anchor, err := h.svc.DigestAnchor(c.Request.Context(), userID)
	if err != nil {
		h.logger.Error("insights.away.anchor.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load digest")
		return
	}
	out, err := h.svc.Away(c.Request.Context(), userID, anchor, scope)
	if err != nil {
		h.logger.Error("insights.away.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to load digest")
		return
	}
	response.Success(c, out, "Digest retrieved")
}

// Seen serves POST /api/v1/pam/insights/away/seen.
//
// Stamped server-side rather than from a client-supplied timestamp: a client
// clock that runs fast would skip past events nobody read, and the whole
// point of the anchor is that it is never allowed to silently swallow a
// window.
func (h *InsightsHandler) Seen(c *gin.Context) {
	userID, _ := callerScope(c)
	if userID == "" {
		response.Error(c, http.StatusUnauthorized, "Not authenticated")
		return
	}
	if err := h.svc.MarkDigestSeen(c.Request.Context(), userID, time.Now()); err != nil {
		h.logger.Error("insights.away.seen.failed", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to update digest marker")
		return
	}
	response.Success(c, gin.H{"seen": true}, "Digest marked as seen")
}
