package handlers

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// testVaultMasterKey is the throwaway master KEK these tests encrypt under. It is a
// parameter now rather than an environment read, so it is named here.
const testVaultMasterKey = "bG9jYWwtdGVzdC1rZXktMzJieXRlcy1leGFjdGx5ISE="

// The vault's MACHINE data plane, end to end, over real HTTP against a real
// database.
//
// This is the feature an application actually uses: it authenticates as a
// service identity with a service token and READS secrets by canonical path,
// while the human control plane (JWT + MFA) is what creates the identity,
// mints the token and grants the scope.
//
// Driven through the real gin router and the real handlers rather than by
// calling services directly, because the things most likely to be wrong live
// exactly there — the wildcard path param, the mandatory purpose, the
// no-store headers, and which plane each route is mounted on.

// withSearchPath pins a DSN to one schema, handling both libpq key=value and
// URL forms since either is a legitimate value for PAM_TEST_POSTGRES_DSN.
func withSearchPath(dsn, schema string) string {
	if strings.HasPrefix(dsn, "postgres://") || strings.HasPrefix(dsn, "postgresql://") {
		sep := "?"
		if strings.Contains(dsn, "?") {
			sep = "&"
		}
		return dsn + sep + "search_path=" + schema
	}
	return dsn + " search_path=" + schema
}

func svcVaultDB(t *testing.T) *gorm.DB {
	t.Helper()
	dsn := os.Getenv("PAM_TEST_POSTGRES_DSN")
	if dsn == "" {
		t.Skip("set PAM_TEST_POSTGRES_DSN to run the service-vault end-to-end test")
	}
	t.Setenv("PAM_KMS_PROVIDER", "local-dev")
	t.Setenv("PAM_VAULT_ENCRYPTION_KEY", "bG9jYWwtdGVzdC1rZXktMzJieXRlcy1leGFjdGx5ISE=")

	// models.AuditLog qualifies its table with PAM_DATABASE_SCHEMA. Unset, that
	// is a leading dot and Postgres rejects the DDL outright — so the schema
	// has to be named BEFORE AutoMigrate, and named the same thing the
	// search_path points at.
	schema := "svc_e2e"
	t.Setenv("PAM_DATABASE_SCHEMA", schema)

	// A private schema per test, dropped afterwards, so one failure cannot
	// leave rows another test would trip over. Created over a throwaway
	// connection, because the schema has to exist before the pool that will
	// be pinned to it is opened.
	bootstrap, err := gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("open postgres: %v", err)
	}
	if err := bootstrap.Exec(fmt.Sprintf(`DROP SCHEMA IF EXISTS %s CASCADE; CREATE SCHEMA %s;`, schema, schema)).Error; err != nil {
		t.Fatalf("create schema: %v", err)
	}
	if sqlDB, err := bootstrap.DB(); err == nil {
		_ = sqlDB.Close()
	}

	// The search_path belongs in the DSN, not in a `SET` statement: `SET`
	// binds to whichever pooled connection served it, so the first query that
	// lands on a second connection looks in `public` and reports the table
	// missing. Putting it in the DSN applies it to every connection the pool
	// ever opens.
	db, err := gorm.Open(postgres.Open(withSearchPath(dsn, schema)),
		&gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("open postgres: %v", err)
	}
	t.Cleanup(func() {
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
		cleanup, err := gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
		if err != nil {
			return
		}
		cleanup.Exec(fmt.Sprintf(`DROP SCHEMA IF EXISTS %s CASCADE;`, schema))
		if sqlDB, err := cleanup.DB(); err == nil {
			_ = sqlDB.Close()
		}
	})
	if err := db.AutoMigrate(
		&models.Safe{}, &models.Folder{}, &models.Credential{}, &models.CredentialVersion{},
		&models.PasswordPolicy{}, &models.AuditLog{},
		&models.ServiceIdentity{}, &models.ServiceToken{}, &models.ServiceGrant{},
	); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

type svcVaultRig struct {
	db     *gorm.DB
	router *gin.Engine
	vault  *services.VaultService
}

// newSvcVaultRig mounts the two planes exactly as cmd/pam-api/main.go does:
// the admin control plane with a stubbed-in authenticated admin, and the
// machine data plane carrying ServiceAuth and nothing else.
func newSvcVaultRig(t *testing.T) *svcVaultRig {
	t.Helper()
	gin.SetMode(gin.TestMode)
	db := svcVaultDB(t)
	log := zap.NewNop()

	vault, err := services.NewVaultService(db, testVaultMasterKey, log)
	if err != nil {
		t.Fatalf("NewVaultService: %v", err)
	}
	audit := services.NewAuditService(db, []byte("test-audit-hmac-secret-at-least-32-bytes"), "default", log)

	pepper := sha256.Sum256([]byte("service-vault-e2e-pepper"))
	identitySvc, err := services.NewServiceIdentityService(db, pepper[:], audit, log)
	if err != nil {
		t.Fatalf("NewServiceIdentityService: %v", err)
	}
	secretSvc := services.NewSecretAccessService(db, vault.KMS(), identitySvc, audit, 300, log)

	idHandler := NewServiceIdentityHandler(identitySvc, log)
	secretHandler := NewSecretAccessHandler(secretSvc, log)

	r := gin.New()

	// Control plane. In the real server this sits behind PAMAuth + RequireAdmin
	// + RequireMFA; here the identity is stubbed so the test exercises the
	// handlers rather than re-testing the auth chain.
	admin := r.Group("/api/v1/pam/admin")
	admin.Use(func(c *gin.Context) {
		c.Set("user_id", "admin-1")
		c.Set("username", "das.admin")
		c.Next()
	})
	{
		svcGroup := admin.Group("/services")
		svcGroup.POST("", idHandler.CreateIdentity)
		svcGroup.GET("", idHandler.ListIdentities)
		svcGroup.POST("/:service/tokens", idHandler.IssueToken)
		svcGroup.GET("/:service/tokens", idHandler.ListTokens)
		svcGroup.POST("/:service/grants", idHandler.GrantScope)
		svcGroup.GET("/:service/grants", idHandler.ListGrants)
		svcGroup.POST("/:service/disable", idHandler.DisableIdentity)
		svcGroup.POST("/:service/enable", idHandler.EnableIdentity)
		admin.GET("/secret-paths", secretHandler.ListSecretPaths)
		admin.DELETE("/service-tokens/:token_id", idHandler.RevokeToken)
		admin.DELETE("/service-grants/:grant_id", idHandler.RevokeGrant)
	}

	// Data plane: its OWN group, ServiceAuth only, never PAMAuth.
	svc := r.Group("/api/v1/pam/svc")
	svc.Use(middleware.ServiceAuth(identitySvc, audit, log))
	{
		svc.GET("/secrets/*path", secretHandler.GetSecret)
		svc.GET("/resources/:resource_id/secrets", secretHandler.GetResourceSecrets)
	}

	return &svcVaultRig{db: db, router: r, vault: vault}
}

func (rig *svcVaultRig) do(t *testing.T, method, path string, body any, headers map[string]string) (int, map[string]any) {
	t.Helper()
	var buf bytes.Buffer
	if body != nil {
		if err := json.NewEncoder(&buf).Encode(body); err != nil {
			t.Fatalf("encode body: %v", err)
		}
	}
	req := httptest.NewRequest(method, path, &buf)
	req.Header.Set("Content-Type", "application/json")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	w := httptest.NewRecorder()
	rig.router.ServeHTTP(w, req)

	var out map[string]any
	if w.Body.Len() > 0 {
		_ = json.Unmarshal(w.Body.Bytes(), &out)
	}
	return w.Code, out
}

func dataOf(t *testing.T, resp map[string]any) map[string]any {
	t.Helper()
	d, ok := resp["data"].(map[string]any)
	if !ok {
		t.Fatalf("response carried no data object: %v", resp)
	}
	return d
}

// storeSecret puts a credential in the vault through the HUMAN service, the
// way an operator would, so the data plane is reading something real.
func (rig *svcVaultRig) storeSecret(t *testing.T, safeID, name, account, plaintext string) *models.Credential {
	t.Helper()
	cred, err := rig.vault.StoreCredential(context.Background(), services.StoreCredentialRequest{
		SafeID:          safeID,
		Name:            name,
		AccountName:     account,
		CredentialType:  models.CredentialTypePassword,
		SecretPlaintext: plaintext,
		CreatedBy:       "admin-1",
	})
	if err != nil {
		t.Fatalf("StoreCredential(%s): %v", name, err)
	}
	return cred
}

// The grant form previews what a scope reaches, which needs every secret's
// canonical path. Assembling that in the console meant listing safes, then
// folders and credentials per safe — a fan-out that grows with the vault, for
// a preview meant to feel instant. One endpoint, one query.
//
// The paths it returns must be spelled EXACTLY as the data plane addresses
// them, or the preview confidently lies: it would show a secret as in-scope
// that the service then cannot read.
func TestTheSecretPathIndexMatchesWhatTheDataPlaneServes(t *testing.T) {
	rig := newSvcVaultRig(t)
	token := rig.provision(t, "path-index", "prod-db/**")

	code, resp := rig.do(t, http.MethodGet, "/api/v1/pam/admin/secret-paths", nil, nil)
	if code != http.StatusOK {
		t.Fatalf("ListSecretPaths: %d %v", code, resp)
	}
	raw, ok := resp["data"].([]any)
	if !ok || len(raw) == 0 {
		t.Fatalf("the path index came back empty: %v", resp)
	}

	// Every path the index advertises must actually resolve on the data plane
	// for a service granted the whole subtree.
	auth := map[string]string{"X-Service-Token": token}
	checked := 0
	for _, item := range raw {
		row := item.(map[string]any)
		path, _ := row["path"].(string)
		if path == "" {
			t.Fatalf("index row has no path: %v", row)
		}
		if row["secret_value"] != nil || row["credential_enc"] != nil {
			t.Fatalf("the path index leaked secret material: %v", row)
		}
		code, resp := rig.do(t, http.MethodGet,
			"/api/v1/pam/svc/secrets/"+path+"?purpose=path+index+agreement", nil, auth)
		if code != http.StatusOK {
			t.Fatalf("index advertised %q but the data plane answered %d: %v", path, code, resp)
		}
		checked++
	}
	if checked == 0 {
		t.Fatal("no paths were checked")
	}

	// And the index is control-plane only: a service token must not be able to
	// enumerate the address space it was not granted.
	if code, _ := rig.do(t, http.MethodGet, "/api/v1/pam/svc/secrets/admin/secret-paths?purpose=probe", nil, auth); code == http.StatusOK {
		t.Fatal("a service token reached the path index through the data plane")
	}
}

// The list endpoint has to carry the live counts itself. The console shows
// them on every row, so the alternative is one request per identity per table
// — 200 identities meant 400 requests on one page load, which degrades long
// before the row count is itself a problem.
//
// "Live" is the load-bearing word: a row reading "1 token" when that token is
// revoked states the opposite of the truth, so a revoked token and an expired
// grant must both drop out of the count.
func TestTheIdentityListCarriesItsOwnLiveCounts(t *testing.T) {
	rig := newSvcVaultRig(t)
	rig.provision(t, "counted", "prod-db/*")

	// A second identity with nothing, so a zero row is exercised too.
	if code, resp := rig.do(t, http.MethodPost, "/api/v1/pam/admin/services",
		map[string]any{"name": "counted-empty"}, nil); code != http.StatusCreated {
		t.Fatalf("CreateIdentity: %d %v", code, resp)
	}

	rows := rig.identities(t)
	if got := rows["counted"]; got.tokens != 1 || got.grants != 1 {
		t.Fatalf("counted: got %d tokens / %d grants, want 1/1", got.tokens, got.grants)
	}
	if got := rows["counted"]; got.widest != "wildcard" {
		t.Fatalf("counted: widest scope %q, want wildcard for prod-db/*", got.widest)
	}
	if got := rows["counted-empty"]; got.tokens != 0 || got.grants != 0 {
		t.Fatalf("counted-empty: got %d tokens / %d grants, want 0/0", got.tokens, got.grants)
	}
	if got := rows["counted-empty"]; got.widest != "" {
		t.Fatalf("counted-empty: widest scope %q, want empty", got.widest)
	}

	// Widen the scope: the row must follow.
	if code, resp := rig.do(t, http.MethodPost, "/api/v1/pam/admin/services/counted/grants",
		map[string]any{"scope": "**", "reason": "widen"}, nil); code != http.StatusCreated {
		t.Fatalf("GrantScope: %d %v", code, resp)
	}
	if got := rig.identities(t)["counted"]; got.grants != 2 || got.widest != "all" {
		t.Fatalf("after widening: %d grants, widest %q; want 2 and all", got.grants, got.widest)
	}

	// Disable revokes every token. The count must go to zero while the grants,
	// which survive a disable, stay where they are.
	if code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/counted/disable", nil, nil); code != http.StatusOK {
		t.Fatalf("DisableIdentity: %d %v", code, resp)
	}
	got := rig.identities(t)["counted"]
	if got.tokens != 0 {
		t.Fatalf("a revoked token is still counted: %d", got.tokens)
	}
	if got.grants != 2 {
		t.Fatalf("disabling an identity changed its grant count: %d, want 2", got.grants)
	}
}

type identityRow struct {
	tokens int
	grants int
	widest string
}

// identities reads the admin list and indexes it by name.
func (rig *svcVaultRig) identities(t *testing.T) map[string]identityRow {
	t.Helper()
	code, resp := rig.do(t, http.MethodGet, "/api/v1/pam/admin/services", nil, nil)
	if code != http.StatusOK {
		t.Fatalf("ListIdentities: %d %v", code, resp)
	}
	raw, ok := resp["data"].([]any)
	if !ok {
		t.Fatalf("identity list carried no array: %v", resp)
	}
	out := map[string]identityRow{}
	for _, item := range raw {
		row, ok := item.(map[string]any)
		if !ok {
			t.Fatalf("identity row was not an object: %v", item)
		}
		name, _ := row["name"].(string)
		tokens, okT := row["live_tokens"].(float64)
		grants, okG := row["live_grants"].(float64)
		if !okT || !okG {
			t.Fatalf("row %q is missing its counts — the console would fan out per row: %v", name, row)
		}
		widest, _ := row["widest_scope"].(string)
		out[name] = identityRow{tokens: int(tokens), grants: int(grants), widest: widest}
	}
	return out
}

// Disable has to be reversible, and reversible in exactly one way: the
// identity and its grants come back, its revoked tokens do NOT. Without the
// enable half, an incident-response disable that turns out to be a false alarm
// kills the identity permanently — IssueToken refuses a disabled identity —
// and the only recovery is a new identity with every scope re-granted by hand.
func TestADisabledIdentityCanBeBroughtBackButItsOldTokensCannot(t *testing.T) {
	rig := newSvcVaultRig(t)
	oldToken := rig.provision(t, "revivable", "prod-db/*")
	auth := map[string]string{"X-Service-Token": oldToken}

	if code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/revivable/disable", nil, nil); code != http.StatusOK {
		t.Fatalf("DisableIdentity: %d %v", code, resp)
	}
	if code, _ := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=while+disabled", nil, auth); code == http.StatusOK {
		t.Fatalf("a disabled identity still read a secret")
	}
	// The state that made disable a one-way door.
	if code, _ := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/revivable/tokens", map[string]any{"ttl_days": 7}, nil); code == http.StatusCreated {
		t.Fatalf("a disabled identity minted a token; the disable is not effective")
	}

	if code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/revivable/enable", nil, nil); code != http.StatusOK {
		t.Fatalf("EnableIdentity: %d %v", code, resp)
	}

	// The old token stays dead: disabling revoked it because it might have
	// leaked, and undoing an administrative action must not resurrect a
	// possibly-leaked credential.
	if code, _ := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=after+enable+with+old+token", nil, auth); code == http.StatusOK {
		t.Fatalf("a token revoked by the disable came back to life")
	}

	// The grants survived, so recovery is one fresh token and nothing else.
	if grants := rig.grants(t, "revivable", false); len(grants) != 1 {
		t.Fatalf("the grants did not survive the disable/enable cycle: %v", grants)
	}
	code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/revivable/tokens", map[string]any{"ttl_days": 7}, nil)
	if code != http.StatusCreated {
		t.Fatalf("minting after enable: %d %v", code, resp)
	}
	fresh, _ := dataOf(t, resp)["token"].(string)
	code, resp = rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=after+recovery", nil,
		map[string]string{"X-Service-Token": fresh})
	if code != http.StatusOK {
		t.Fatalf("the recovered identity could not read its granted secret: %d %v", code, resp)
	}
	if got := dataOf(t, resp)["secret_value"]; got != "the-app-password" {
		t.Fatalf("wrong plaintext after recovery: %v", got)
	}
}

// Revoking something that is not there is a 404, not a 500. The three
// revocation-shaped routes have to agree on that: an operator retrying a
// DELETE, or a script replaying a run, hits this constantly, and a 500
// carrying a raw database string reads as "the server is broken" rather than
// "that is already gone". RevokeGrant was the one that disagreed.
func TestRevokingSomethingThatDoesNotExistIsNotAServerError(t *testing.T) {
	rig := newSvcVaultRig(t)
	rig.provision(t, "notfound-parity", "prod-db/*")

	for _, tc := range []struct{ what, method, path string }{
		{"a grant", http.MethodDelete, "/api/v1/pam/admin/service-grants/00000000-0000-0000-0000-000000000000"},
		{"a token", http.MethodDelete, "/api/v1/pam/admin/service-tokens/0000000000000000"},
		{"an identity's tokens", http.MethodGet, "/api/v1/pam/admin/services/no-such-service/tokens"},
		{"an identity's grants", http.MethodGet, "/api/v1/pam/admin/services/no-such-service/grants"},
		{"disabling an identity", http.MethodPost, "/api/v1/pam/admin/services/no-such-service/disable"},
	} {
		code, resp := rig.do(t, tc.method, tc.path, nil, nil)
		if code != http.StatusNotFound {
			t.Errorf("%s: got %d, want 404 (%v)", tc.what, code, resp)
		}
		// And the message must not be a leaked database string.
		if body, _ := json.Marshal(resp); strings.Contains(strings.ToLower(string(body)), "record not found") {
			t.Errorf("%s: the response leaks the database error: %s", tc.what, body)
		}
	}
}

// The name is the identity's address on the control plane
// (/admin/services/<name>/tokens) and the subject of its audit records, so a
// name that cannot be one has to be refused at creation — after the row
// exists, the identity is unmanageable through the API that created it.
func TestAnUnaddressableServiceNameIsRefused(t *testing.T) {
	rig := newSvcVaultRig(t)

	for _, name := range []string{
		"billing/api",   // a slash is a second path segment
		"Billing-API",   // upper case: the same name twice, two rows
		"billing api",   // whitespace breaks the URL and the audit string
		"a",             // too short to mean anything
		"-billing",      // leading punctuation
		"billing-",      // trailing punctuation
		"",              // empty
		"billing%2Fapi", // pre-encoded, which would decode back to a slash
	} {
		code, resp := rig.do(t, http.MethodPost, "/api/v1/pam/admin/services",
			map[string]any{"name": name}, nil)
		if code != http.StatusBadRequest {
			t.Errorf("name %q was accepted with %d (%v); expected 400", name, code, resp)
		}
	}

	// And the shape the docs use is still accepted.
	if code, resp := rig.do(t, http.MethodPost, "/api/v1/pam/admin/services",
		map[string]any{"name": "billing-api-prod"}, nil); code != http.StatusCreated {
		t.Fatalf("a well-formed name was refused: %d %v", code, resp)
	}
}

// A revoked grant must disappear from the live list — that list is what
// "what can this service read right now" means — and must still be visible
// with include_inactive, because a scope that was granted and then withdrawn
// is exactly the fact a reviewer opened the screen to find. Getting this
// backwards either hides a withdrawal or implies access that no longer exists.
func TestRevokedGrantsLeaveTheLiveListButStayInTheHistory(t *testing.T) {
	rig := newSvcVaultRig(t)
	token := rig.provision(t, "grant-history", "prod-db/*")
	auth := map[string]string{"X-Service-Token": token}

	grants := rig.grants(t, "grant-history", false)
	if len(grants) != 1 {
		t.Fatalf("expected the one granted scope, got %v", grants)
	}
	grantID, _ := grants[0]["id"].(string)
	if grantID == "" {
		t.Fatalf("grant carried no id: %v", grants[0])
	}

	// It reads today.
	if code, resp := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=before+revocation", nil, auth); code != http.StatusOK {
		t.Fatalf("the granted secret was refused before revocation: %d %v", code, resp)
	}

	if code, resp := rig.do(t, http.MethodDelete,
		"/api/v1/pam/admin/service-grants/"+grantID, nil, nil); code != http.StatusOK {
		t.Fatalf("RevokeGrant: %d %v", code, resp)
	}

	// Revocation is effective immediately, not after a cache expiry.
	if code, _ := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=after+revocation", nil, auth); code == http.StatusOK {
		t.Fatalf("a revoked grant still served the secret")
	}

	if live := rig.grants(t, "grant-history", false); len(live) != 0 {
		t.Fatalf("a revoked grant is still in the live list: %v", live)
	}

	history := rig.grants(t, "grant-history", true)
	if len(history) != 1 {
		t.Fatalf("the revoked grant is missing from the history: %v", history)
	}
	if history[0]["revoked_at"] == nil {
		t.Fatalf("the history row does not say it was revoked: %v", history[0])
	}
}

// grants reads one identity's grants off the admin plane, live or including
// the withdrawn ones, the way the console's two views do.
func (rig *svcVaultRig) grants(t *testing.T, service string, includeInactive bool) []map[string]any {
	t.Helper()
	url := "/api/v1/pam/admin/services/" + service + "/grants"
	if includeInactive {
		url += "?include_inactive=true"
	}
	code, resp := rig.do(t, http.MethodGet, url, nil, nil)
	if code != http.StatusOK {
		t.Fatalf("ListGrants(%s): %d %v", service, code, resp)
	}
	raw, ok := resp["data"].([]any)
	if !ok {
		t.Fatalf("grants response carried no array: %v", resp)
	}
	out := make([]map[string]any, 0, len(raw))
	for _, item := range raw {
		row, ok := item.(map[string]any)
		if !ok {
			t.Fatalf("grant row was not an object: %v", item)
		}
		out = append(out, row)
	}
	return out
}

// The whole happy path: provision an identity, mint a token, grant a scope,
// then read a secret as the application.
func TestServiceIdentityCanReadOnlyWhatItWasGranted(t *testing.T) {
	rig := newSvcVaultRig(t)

	// A safe whose NAME is what the canonical secret path is built from.
	safe := &models.Safe{ID: "safe-prod-db", Name: "prod-db", Description: "production databases"}
	if err := rig.db.Create(safe).Error; err != nil {
		t.Fatalf("create safe: %v", err)
	}
	rig.storeSecret(t, safe.ID, "pg-app-writer", "app_writer", "the-app-password")
	rig.storeSecret(t, safe.ID, "pg-root", "postgres", "the-root-password")

	// ── control plane: create the identity ──
	code, resp := rig.do(t, http.MethodPost, "/api/v1/pam/admin/services", map[string]any{
		"name": "billing-api-prod", "environment": "prod", "description": "billing service",
	}, nil)
	if code != http.StatusCreated {
		t.Fatalf("CreateIdentity: %d %v", code, resp)
	}

	// ── mint a token: the only copy that will ever exist ──
	code, resp = rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/billing-api-prod/tokens",
		map[string]any{"description": "rollout-1", "ttl_days": 30}, nil)
	if code != http.StatusCreated {
		t.Fatalf("IssueToken: %d %v", code, resp)
	}
	d := dataOf(t, resp)
	token, _ := d["token"].(string)
	if token == "" {
		t.Fatalf("no token in the mint response: %v", d)
	}

	// ── grant ONE secret, not the safe ──
	code, resp = rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/billing-api-prod/grants",
		map[string]any{
			"scope": "prod-db/pg-app-writer", "reason": "billing needs its own writer",
			"max_ttl_seconds": 120,
		}, nil)
	if code != http.StatusCreated {
		t.Fatalf("GrantScope: %d %v", code, resp)
	}

	auth := map[string]string{"X-Service-Token": token}

	// ── the read the whole feature exists for ──
	code, resp = rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=open+a+db+connection", nil, auth)
	if code != http.StatusOK {
		t.Fatalf("the granted secret was refused: %d %v", code, resp)
	}
	d = dataOf(t, resp)
	if got := d["secret_value"]; got != "the-app-password" {
		t.Fatalf("wrong plaintext: %v", got)
	}

	// The server is authoritative on lifetime, and must never exceed the
	// grant's own cap — that clamp is what bounds how long a revoked grant
	// stays effective on a client that already holds the plaintext.
	ttl, ok := d["cache_ttl_seconds"].(float64)
	if !ok {
		t.Fatalf("no cache_ttl_seconds in the response: %v", d)
	}
	if ttl <= 0 || ttl > 120 {
		t.Fatalf("cache_ttl_seconds %v is outside the grant's 120s cap", ttl)
	}

	// ── the secret it was NOT granted ──
	code, resp = rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-root?purpose=curiosity", nil, auth)
	if code == http.StatusOK {
		t.Fatalf("a secret outside the grant was served: %v", resp)
	}
	if code != http.StatusForbidden && code != http.StatusNotFound {
		t.Fatalf("expected 403/404 for an ungranted secret, got %d %v", code, resp)
	}
}

// `purpose` is mandatory. It is what makes the audit trail answerable to
// "why did billing-api read the DB root password at 3am".
func TestSecretReadRequiresAPurpose(t *testing.T) {
	rig := newSvcVaultRig(t)
	token := rig.provision(t, "svc-no-purpose", "prod-db/**")

	code, resp := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer", nil,
		map[string]string{"X-Service-Token": token})
	if code != http.StatusBadRequest {
		t.Fatalf("a read with no purpose should be refused, got %d %v", code, resp)
	}
}

// No token, a malformed token, and a revoked token must all be refused — and
// a revoked one must stop working immediately, not at its expiry.
func TestUnauthenticatedAndRevokedTokensAreRefused(t *testing.T) {
	rig := newSvcVaultRig(t)
	token := rig.provision(t, "svc-revoke-me", "prod-db/**")
	path := "/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=test"

	if code, _ := rig.do(t, http.MethodGet, path, nil, nil); code != http.StatusUnauthorized {
		t.Fatalf("no token should be 401, got %d", code)
	}
	if code, _ := rig.do(t, http.MethodGet, path, nil,
		map[string]string{"X-Service-Token": "pamsvc.nope.nope"}); code != http.StatusUnauthorized {
		t.Fatalf("a malformed token should be 401, got %d", code)
	}

	// It works before revocation...
	if code, resp := rig.do(t, http.MethodGet, path, nil,
		map[string]string{"X-Service-Token": token}); code != http.StatusOK {
		t.Fatalf("the token should work before revocation: %d %v", code, resp)
	}

	// ...find its id and revoke it.
	code, resp := rig.do(t, http.MethodGet,
		"/api/v1/pam/admin/services/svc-revoke-me/tokens", nil, nil)
	if code != http.StatusOK {
		t.Fatalf("ListTokens: %d %v", code, resp)
	}
	var tokenID string
	if arr, ok := resp["data"].([]any); ok && len(arr) > 0 {
		if first, ok := arr[0].(map[string]any); ok {
			tokenID, _ = first["token_id"].(string)
		}
	} else if d, ok := resp["data"].(map[string]any); ok {
		if arr, ok := d["tokens"].([]any); ok && len(arr) > 0 {
			if first, ok := arr[0].(map[string]any); ok {
				tokenID, _ = first["token_id"].(string)
			}
		}
	}
	if tokenID == "" {
		t.Fatalf("could not find the token id in %v", resp)
	}
	if code, resp := rig.do(t, http.MethodDelete,
		"/api/v1/pam/admin/service-tokens/"+tokenID, nil, nil); code != http.StatusOK {
		t.Fatalf("RevokeToken: %d %v", code, resp)
	}

	// ...and stops immediately. The 30s principal cache must not outlive a
	// revocation, or an incident response would have a half-minute hole.
	if code, resp := rig.do(t, http.MethodGet, path, nil,
		map[string]string{"X-Service-Token": token}); code == http.StatusOK {
		t.Fatalf("a REVOKED token still served a secret: %v", resp)
	}
}

// Disabling the identity kills every token at once, without enumerating them.
func TestDisablingAnIdentityKillsItsTokens(t *testing.T) {
	rig := newSvcVaultRig(t)
	token := rig.provision(t, "svc-disable-me", "prod-db/**")
	path := "/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=test"

	if code, _ := rig.do(t, http.MethodGet, path, nil,
		map[string]string{"X-Service-Token": token}); code != http.StatusOK {
		t.Fatalf("expected the token to work first, got %d", code)
	}
	if code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/svc-disable-me/disable", nil, nil); code != http.StatusOK {
		t.Fatalf("DisableIdentity: %d %v", code, resp)
	}
	if code, resp := rig.do(t, http.MethodGet, path, nil,
		map[string]string{"X-Service-Token": token}); code == http.StatusOK {
		t.Fatalf("a token of a DISABLED identity still served a secret: %v", resp)
	}
}

// The `*` vs `**` distinction is a real blast-radius difference, not a
// formatting detail: "everything directly in prod-db" and "everything
// anywhere under prod-db" must not be the same grant.
func TestSingleStarDoesNotCrossASeparator(t *testing.T) {
	rig := newSvcVaultRig(t)

	safe := &models.Safe{ID: "safe-star", Name: "starsafe"}
	if err := rig.db.Create(safe).Error; err != nil {
		t.Fatalf("create safe: %v", err)
	}
	folder := &models.Folder{ID: "folder-nested", SafeID: safe.ID, Name: "nested"}
	if err := rig.db.Create(folder).Error; err != nil {
		t.Fatalf("create folder: %v", err)
	}
	rig.storeSecret(t, safe.ID, "top-level", "acct-top", "top-secret")
	deep, err := rig.vault.StoreCredential(context.Background(), services.StoreCredentialRequest{
		SafeID: safe.ID, FolderID: &folder.ID, Name: "deep-one", AccountName: "acct-deep",
		CredentialType: models.CredentialTypePassword, SecretPlaintext: "deep-secret", CreatedBy: "admin-1",
	})
	if err != nil {
		t.Fatalf("store nested credential: %v", err)
	}
	_ = deep

	token := rig.provisionInSafe(t, "svc-star", "starsafe/*")
	auth := map[string]string{"X-Service-Token": token}

	// Direct child: allowed.
	if code, resp := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/starsafe/top-level?purpose=test", nil, auth); code != http.StatusOK {
		t.Fatalf("a direct child should match starsafe/*: %d %v", code, resp)
	}
	// One level deeper: refused, because `*` stops at the separator.
	if code, resp := rig.do(t, http.MethodGet,
		"/api/v1/pam/svc/secrets/starsafe/nested/deep-one?purpose=test", nil, auth); code == http.StatusOK {
		t.Fatalf("starsafe/* must NOT match a nested secret, but it served: %v", resp)
	}
}

// A secret response must never be cacheable by a proxy or a browser.
func TestSecretResponsesAreNoStore(t *testing.T) {
	rig := newSvcVaultRig(t)
	token := rig.provision(t, "svc-nostore", "prod-db/**")

	req := httptest.NewRequest(http.MethodGet,
		"/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=test", nil)
	req.Header.Set("X-Service-Token", token)
	w := httptest.NewRecorder()
	rig.router.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("setup read failed: %d %s", w.Code, w.Body.String())
	}
	if cc := w.Header().Get("Cache-Control"); cc == "" || !bytes.Contains([]byte(cc), []byte("no-store")) {
		t.Fatalf("secret response Cache-Control is %q, must contain no-store", cc)
	}
}

// ── helpers ──────────────────────────────────────────────────────────────

// provision creates the standard prod-db safe with one secret, an identity,
// a token and a grant, and returns the token.
func (rig *svcVaultRig) provision(t *testing.T, name, scope string) string {
	t.Helper()
	var existing models.Safe
	if rig.db.Where("name = ?", "prod-db").First(&existing).Error != nil {
		safe := &models.Safe{ID: "safe-prod-db", Name: "prod-db"}
		if err := rig.db.Create(safe).Error; err != nil {
			t.Fatalf("create safe: %v", err)
		}
		rig.storeSecret(t, safe.ID, "pg-app-writer", "app_writer", "the-app-password")
	}
	return rig.mint(t, name, scope)
}

func (rig *svcVaultRig) provisionInSafe(t *testing.T, name, scope string) string {
	t.Helper()
	return rig.mint(t, name, scope)
}

func (rig *svcVaultRig) mint(t *testing.T, name, scope string) string {
	t.Helper()
	if code, resp := rig.do(t, http.MethodPost, "/api/v1/pam/admin/services",
		map[string]any{"name": name}, nil); code != http.StatusCreated {
		t.Fatalf("CreateIdentity(%s): %d %v", name, code, resp)
	}
	code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/"+name+"/tokens", map[string]any{"ttl_days": 7}, nil)
	if code != http.StatusCreated {
		t.Fatalf("IssueToken(%s): %d %v", name, code, resp)
	}
	token, _ := dataOf(t, resp)["token"].(string)
	if token == "" {
		t.Fatalf("no token minted for %s", name)
	}
	if code, resp := rig.do(t, http.MethodPost,
		"/api/v1/pam/admin/services/"+name+"/grants",
		map[string]any{"scope": scope, "reason": "test"}, nil); code != http.StatusCreated {
		t.Fatalf("GrantScope(%s,%s): %d %v", name, scope, code, resp)
	}
	return token
}
