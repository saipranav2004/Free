package webproxy

import (
	"net/url"
	"strings"
	"testing"
)

// landingPathFor is the decision the handoff makes about where to send the
// operator. Extracted here so the rule can be tested without standing up a
// session, a cookie and a redirect.
func landingPathFor(target *url.URL) string {
	landing := "/"
	if target != nil {
		if p := strings.TrimSpace(target.Path); p != "" && p != "/" {
			landing = "/" + strings.TrimLeft(p, "/")
			if target.RawQuery != "" {
				landing += "?" + target.RawQuery
			}
		}
	}
	return landing
}

// A console_url is routinely a sub-path, and the operator has to land on it.
//
// Redirecting to "/" sent them to whatever the target serves at its root. For
// qdrant that is a JSON version blob: no HTML, so the replay recorder was
// never injected, and the session produced a 1.7 KB request transcript where
// the same code produced 225 KB of visual replay against MinIO. The operator
// saw the wrong page and the auditor got the wrong artifact, from one
// hardcoded slash.
func TestTheHandoffLandsOnTheConsolesOwnPath(t *testing.T) {
	cases := []struct{ name, consoleURL, want string }{
		{"qdrant's dashboard", "http://qdrant.internal:6333/dashboard", "/dashboard"},
		{"ClickHouse's query UI", "http://ch.internal:8123/play", "/play"},
		{"a path with a query string", "http://app.internal/console?tab=main", "/console?tab=main"},
		{"a nested path", "https://appliance.internal/admin/ui", "/admin/ui"},
		// The common case, and the one that must not change: MinIO Console
		// and Metabase are both served at the root.
		{"no path at all", "http://minio.internal:9001", "/"},
		{"an explicit root", "http://minio.internal:9001/", "/"},
		{"a trailing slash on a path", "http://qdrant.internal:6333/dashboard/", "/dashboard/"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			u, err := url.Parse(tc.consoleURL)
			if err != nil {
				t.Fatalf("parse %q: %v", tc.consoleURL, err)
			}
			if got := landingPathFor(u); got != tc.want {
				t.Errorf("landing for %q = %q, want %q", tc.consoleURL, got, tc.want)
			}
		})
	}
}

// A nil target must not panic and must not invent a path.
func TestAnUnresolvableTargetStillLandsSomewhere(t *testing.T) {
	if got := landingPathFor(nil); got != "/" {
		t.Errorf("landing = %q, want / when the target cannot be resolved", got)
	}
}
