package webproxy

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// The header combinations that decide whether a WebSocket handshake can
// possibly succeed. The failing row is not hypothetical: it is byte-for-byte
// what nginx forwards when the three proxy_set_header lines are missing,
// captured from a real request through a real ingress.
func TestAStrippedUpgradeIsRecognisedAndAnIntactOneIsNot(t *testing.T) {
	cases := []struct {
		name    string
		headers map[string]string
		proto   string
		want    bool
	}{
		{
			name: "what a correctly configured ingress forwards",
			headers: map[string]string{
				"Connection": "Upgrade", "Upgrade": "websocket",
				"Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==", "Sec-WebSocket-Version": "13",
			},
			proto: "HTTP/1.1", want: false,
		},
		{
			// Measured through nginx without proxy_http_version 1.1 and the
			// two proxy_set_header lines.
			name: "what an ingress that drops the hop-by-hop pair forwards",
			headers: map[string]string{
				"Connection":        "close",
				"Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==", "Sec-WebSocket-Version": "13",
			},
			proto: "HTTP/1.0", want: true,
		},
		{
			name: "Connection carries other tokens alongside upgrade",
			headers: map[string]string{
				"Connection": "keep-alive, Upgrade", "Upgrade": "WebSocket",
				"Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
			},
			proto: "HTTP/1.1", want: false,
		},
		{
			name: "Upgrade survived but Connection did not — still cannot upgrade",
			headers: map[string]string{
				"Upgrade": "websocket", "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
			},
			proto: "HTTP/1.1", want: true,
		},
		{
			// The guard must not touch ordinary traffic to a WebSocket path:
			// health checks, crawlers and curl all look like this.
			name:    "a plain GET to a websocket path is not a broken handshake",
			headers: map[string]string{},
			proto:   "HTTP/1.1", want: false,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodGet, "/ws/objectManager", nil)
			r.Proto = tc.proto
			for k, v := range tc.headers {
				r.Header.Set(k, v)
			}
			if got := UpgradeWasStripped(r); got != tc.want {
				t.Errorf("UpgradeWasStripped = %v, want %v", got, tc.want)
			}
		})
	}
}

// The remedy has to be actionable on sight. A support engineer reading one log
// line should be able to fix the ingress without asking anyone.
func TestTheRemedyNamesTheDirectivesToAdd(t *testing.T) {
	for _, want := range []string{"proxy_http_version 1.1", "Upgrade", "Connection", "nginx"} {
		if !strings.Contains(UpgradeStrippedHint, want) {
			t.Errorf("the hint does not mention %q:\n%s", want, UpgradeStrippedHint)
		}
	}
}

// A manifest is fetched with credentials omitted, so in a brokered session it
// arrives cookie-less and the proxy answers 401 — a red error in the console
// of a session that is working fine, sitting next to errors that are real.
func TestManifestLinksAreGivenCredentials(t *testing.T) {
	cases := []struct {
		name, in, wantContains string
		unchanged              bool
	}{
		{
			name:         "the plain form MinIO Console serves",
			in:           `<head><link rel="manifest" href="./manifest.json"/></head>`,
			wantContains: `crossorigin="use-credentials"`,
		},
		{
			name:         "unquoted rel and no self-close",
			in:           `<link rel=manifest href="/m.webmanifest">`,
			wantContains: `crossorigin="use-credentials"`,
		},
		{
			name:      "an app that already set crossorigin is left alone",
			in:        `<link rel="manifest" href="/m.json" crossorigin="anonymous">`,
			unchanged: true,
		},
		{
			name:      "a stylesheet link is not a manifest",
			in:        `<link rel="stylesheet" href="/a.css">`,
			unchanged: true,
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := string(credentialManifestLinks([]byte(tc.in)))
			if tc.unchanged {
				if got != tc.in {
					t.Errorf("rewrote a tag it should not have:\n in: %s\nout: %s", tc.in, got)
				}
				return
			}
			if !strings.Contains(got, tc.wantContains) {
				t.Errorf("got %s, want it to contain %s", got, tc.wantContains)
			}
			// Still one well-formed tag, and the href is untouched.
			if strings.Count(got, "<link") != 1 || !strings.Contains(got, "rel=") {
				t.Errorf("rewrite damaged the tag: %s", got)
			}
		})
	}
}
