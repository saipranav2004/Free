// pam/internal/webproxy/upgrade_stripped.go
//
// Detecting an ingress that swallows WebSocket upgrades.
//
// THE FAILURE THIS EXISTS FOR. A brokered MinIO Console loads, logs in and
// lists buckets, and then the object list spins forever. The browser console
// shows nothing but:
//
//	WebSocket connection to 'wss://<session>.<domain>/ws/objectManager' failed:
//	Websocket Disconnected. Attempting Reconnection...
//
// with an EMPTY response code, repeating every few seconds. Nothing appears in
// PAM's logs, because as far as PAM is concerned it forwarded an ordinary GET
// and the target answered it. The operator has no thread to pull.
//
// WHAT IS ACTUALLY WRONG, AND WHY PAM CAN SEE IT. `Connection` and `Upgrade`
// are hop-by-hop headers: every proxy is required to consume them rather than
// forward them. An ingress therefore has to be told to reinstate them, and on
// nginx that is three lines people routinely leave out:
//
//	proxy_http_version 1.1;
//	proxy_set_header Upgrade    $http_upgrade;
//	proxy_set_header Connection $connection_upgrade;
//
// Without them the handshake arrives at PAM as a plain HTTP/1.0 GET. But
// `Sec-WebSocket-Key` and `Sec-WebSocket-Version` are ORDINARY headers, so
// they survive. That asymmetry is the whole diagnosis: a request carrying
// Sec-WebSocket-Key with no Upgrade is a WebSocket handshake that something
// between the browser and PAM has already broken. The browser did ask.
//
// Measured, not reasoned about: the same brokered session over the same TLS
// and the same wildcard host succeeds through an ingress with those three
// lines and fails without them, and on the failing lane PAM receives exactly
// `proto=HTTP/1.0, Connection: close, sec-websocket-key: …,
// sec-websocket-version: 13` and no Upgrade.
//
// WHY THIS REFUSES RATHER THAN FORWARDS. Forwarding is what produced a silent
// failure for two rounds of debugging. A refusal that names the three missing
// directives turns an unexplained spinner into a fixed config.
package webproxy

import (
	"net/http"
	"strings"
)

// UpgradeStrippedHint is the remedy, kept in one place so the log line and the
// response body cannot drift apart.
const UpgradeStrippedHint = "The reverse proxy in front of PAM is not forwarding WebSocket upgrades. " +
	"On nginx add, in the location that proxies to PAM: `proxy_http_version 1.1;`, " +
	"`proxy_set_header Upgrade $http_upgrade;` and `proxy_set_header Connection \"upgrade\";`. " +
	"On an AWS ALB/ELB use a target group with HTTP/1.1. Until then any application that " +
	"uses WebSockets (MinIO Console, Metabase, Langfuse) will load but never finish loading."

// wantsWebSocket reports whether the BROWSER asked for a WebSocket, judged by
// the headers an intermediary has no license to remove.
func wantsWebSocket(r *http.Request) bool {
	return r.Header.Get("Sec-WebSocket-Key") != ""
}

// hasUpgradeHeaders reports whether the hop-by-hop pair actually arrived, so
// Go's ReverseProxy will treat this as an upgrade and hijack the connection.
//
// Connection is a comma-separated list and its tokens are case-insensitive, so
// "keep-alive, Upgrade" has to match as readily as "upgrade".
func hasUpgradeHeaders(r *http.Request) bool {
	if !strings.EqualFold(strings.TrimSpace(r.Header.Get("Upgrade")), "websocket") {
		return false
	}
	for _, tok := range strings.Split(r.Header.Get("Connection"), ",") {
		if strings.EqualFold(strings.TrimSpace(tok), "upgrade") {
			return true
		}
	}
	return false
}

// UpgradeWasStripped is the signature: the browser asked for a WebSocket and
// the headers that make it one are gone.
//
// Deliberately NOT triggered by a missing Sec-WebSocket-Key. A plain GET to a
// WebSocket path is a perfectly ordinary thing — a health check, a crawler, a
// curl — and must keep being proxied as it always was.
func UpgradeWasStripped(r *http.Request) bool {
	return wantsWebSocket(r) && !hasUpgradeHeaders(r)
}
