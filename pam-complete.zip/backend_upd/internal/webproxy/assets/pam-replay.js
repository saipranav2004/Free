/* pam/internal/webproxy/assets/pam-replay.js
 *
 * The PAM half of visual session replay. Concatenated after rrweb.min.js and
 * served as one file from /__pam/replay.js on the proxy origin — same-origin
 * so a target's `script-src 'self'` admits it with no policy change at all,
 * which is what makes this work against apps like MinIO Console that forbid
 * inline script outright.
 *
 * Everything here is wrapped so that a failure records nothing rather than
 * breaking the page the operator is trying to work in: a PAM that makes the
 * target unusable is worse than one whose replay is missing.
 */
(function () {
  try {
    if (!window.rrweb || typeof window.rrweb.record !== "function") return;
    // Guard against a double-inject (e.g. a page that re-injects fragments).
    if (window.__pamReplayStarted) return;
    window.__pamReplayStarted = true;

    var ENDPOINT = "/__pam/replay";
    var FLUSH_MS = 5000;
    var MAX_BATCH = 200;
    // rrweb emits only on CHANGE, so a replay's length is the span of the
    // page's mutations, not the span of the operator's session. A real
    // 57-second MinIO Console session replayed as "00:04 / 00:04": the
    // console painted itself in four seconds and then sat idle, so the last
    // event was four seconds in and the player had nothing to lay a scrubber
    // over. For an audit artifact that is the wrong reading — the length an
    // auditor needs is how long the operator was in there, including the time
    // they spent looking at a screen without touching it.
    //
    // One custom event per second fixes the timeline at negligible cost
    // (~60 tiny events a minute, versus a single DOM snapshot of ~200 KB) and
    // is inert at replay: rrweb-player counts a Custom event towards duration
    // and renders nothing for it.
    var HEARTBEAT_MS = 1000;
    var buffer = [];
    var dropped = false;

    function post(payload, useBeacon) {
      try {
        if (useBeacon && navigator.sendBeacon) {
          // A Blob keeps the Content-Type intact; sendBeacon is the only
          // transport that reliably survives the page being torn down, which
          // is exactly when the final frames matter most.
          navigator.sendBeacon(ENDPOINT, new Blob([payload], { type: "application/json" }));
          return;
        }
        var xhr = new XMLHttpRequest();
        xhr.open("POST", ENDPOINT, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(payload);
      } catch (e) {
        /* a dropped batch costs frames, never the operator's session */
      }
    }

    function flush(useBeacon) {
      if (!buffer.length) return;
      var batch = buffer;
      buffer = [];
      try {
        post(JSON.stringify(batch), useBeacon);
      } catch (e) {
        /* JSON.stringify can throw on a pathological DOM; drop the batch */
      }
    }

    window.rrweb.record({
      emit: function (event) {
        buffer.push(event);
        // Bound memory if the page is a firehose and flushes are failing.
        if (buffer.length >= MAX_BATCH) {
          flush(false);
          if (buffer.length >= MAX_BATCH * 4) {
            buffer.length = 0;
            dropped = true;
          }
        }
      },
      // Passwords are masked even though PAM's whole design means the
      // operator never learns the target credential — an operator typing a
      // secret of their own into the app must not have it land in an audit
      // artifact that a different team can replay.
      maskInputOptions: { password: true },
      // Stylesheets have to travel with the recording: at replay time the
      // proxy subdomain is long gone, so any asset left as a URL is a 404
      // and the replay renders unstyled.
      inlineStylesheet: true,
      // KNOWN GAP, measured and deliberately left off for now.
      //
      // Images are NOT inlined, so the snapshot keeps them as absolute URLs
      // on the brokered session's subdomain. At replay time that subdomain is
      // gone, so on a real MinIO Console replay the stage came back blank
      // with a broken-image glyph and three ERR_NAME_NOT_RESOLVED: MinIO
      // draws its whole shell from images/background.svg plus a Loader.svg
      // spinner, so "images are only decoration" is not true of the consoles
      // PAM brokers.
      //
      // Turning inlineImages on was tried and REVERTED: it makes the first
      // batch — the full snapshot — exceed what the ingest path accepts, and
      // because an over-size batch is answered exactly like a stored one, the
      // entire recording silently collapsed to a few hundred bytes. Raising
      // the cap alone is not the fix either; a snapshot that inlines every
      // image on a data-heavy page has no natural bound.
      //
      // The fix worth building is to store the session's assets ONCE
      // alongside the recording and rewrite the snapshot's URLs to a stable
      // PAM-served path, so replay fidelity stops depending on the target
      // still being reachable and size stays proportional to distinct assets
      // rather than to frames.
      inlineImages: false,
      // Off for the same reason, and more so: canvas capture is per-frame
      // pixel data and a web font is routinely larger than the whole DOM.
      recordCanvas: false,
      collectFonts: false,
      sampling: {
        mousemove: 50,
        scroll: 150,
        input: "last"
      }
    });

    setInterval(function () {
      flush(false);
    }, FLUSH_MS);

    // Keeps the replay timeline in step with wall clock (see HEARTBEAT_MS).
    // Guarded because addCustomEvent is absent on older rrweb builds, and a
    // missing heartbeat must cost the scrubber its length, never the
    // recording.
    if (typeof window.rrweb.record.addCustomEvent === "function") {
      setInterval(function () {
        try {
          window.rrweb.record.addCustomEvent("pam:heartbeat", { t: Date.now() });
        } catch (e) {
          /* never break the target application */
        }
      }, HEARTBEAT_MS);
    }

    // pagehide is the event that actually fires on tab close / navigation
    // across browsers (unload does not, under bfcache), so it is what gets
    // the tail of the session out.
    window.addEventListener("pagehide", function () {
      flush(true);
    });
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "hidden") flush(true);
    });

    window.__pamReplayDroppedFrames = function () {
      return dropped;
    };
  } catch (e) {
    /* never break the target application */
  }
})();
