package services

import "testing"

// The version comparison is where a floor goes wrong, and it goes wrong
// quietly: a bad compare either admits an agent that is too old (the floor
// does nothing, and nobody finds out until an incident) or refuses the whole
// fleet after an upgrade.

func TestAgentVersionOrdering(t *testing.T) {
	cases := []struct {
		a, b string
		want int
	}{
		{"2026.09.11", "2026.09.11", 0},
		{"2026.09.11", "2026.09.12", -1},
		{"2026.09.12", "2026.09.11", 1},
		{"2026.08.30", "2026.09.01", -1},
		{"2025.12.31", "2026.01.01", -1},
		// Zero padding is a formatting choice, not a version. A plain string
		// compare gets this backwards: "2026.9.2" > "2026.09.11" as text.
		{"2026.9.2", "2026.09.11", -1},
		{"2026.10.1", "2026.9.30", 1},
		// Missing components are zeros, so a bare series is comparable.
		{"2026.09", "2026.09.0", 0},
		{"2026.09", "2026.09.1", -1},
		{"3", "3.0.0", 0},
		// A leading v is cosmetic.
		{"v2026.09.11", "2026.09.11", 0},
		// A pre-release is treated as its release: conservative for a floor,
		// since it can only admit an rc of a version already allowed.
		{"2026.09.11-rc1", "2026.09.11", 0},
		{"2026.09.11+build7", "2026.09.11", 0},
	}
	for _, c := range cases {
		if got := CompareAgentVersions(c.a, c.b); got != c.want {
			t.Errorf("CompareAgentVersions(%q, %q) = %d, want %d", c.a, c.b, got, c.want)
		}
		// Antisymmetry, or the ordering is not an ordering.
		if got := CompareAgentVersions(c.b, c.a); got != -c.want {
			t.Errorf("CompareAgentVersions(%q, %q) = %d, want %d (not antisymmetric)", c.b, c.a, got, -c.want)
		}
	}
}

// No floor configured means no behaviour change. A deployment that has not
// opted in must not start refusing its own fleet on upgrade.
func TestNoFloorAllowsEverything(t *testing.T) {
	f := AgentVersionFloor{}
	for _, v := range []string{"", "dev", "2020.01.01", "2026.09.11", "garbage"} {
		if !f.Allows(v) {
			t.Errorf("with no floor set, %q was refused", v)
		}
		if f.RefusalReason(v) != "" {
			t.Errorf("with no floor set, %q produced a refusal reason", v)
		}
	}
}

func TestFloorRefusesOlderAndAdmitsNewer(t *testing.T) {
	f := AgentVersionFloor{Minimum: "2026.09.11"}
	for _, v := range []string{"2026.09.11", "2026.09.12", "2027.01.01"} {
		if !f.Allows(v) {
			t.Errorf("%q should meet the floor %q", v, f.Minimum)
		}
	}
	for _, v := range []string{"2026.09.10", "2025.01.01", "2026.9.2"} {
		if f.Allows(v) {
			t.Errorf("%q should NOT meet the floor %q", v, f.Minimum)
		}
		if f.Status(v) != AgentVersionStale {
			t.Errorf("%q status = %q, want stale", v, f.Status(v))
		}
	}
}

// A floor exists to guarantee a capability is present. "This agent will not
// say what it is" is not a guarantee — including for a local dev build, which
// is exactly the thing that should not be quietly trusted in production.
func TestFloorRefusesWhatItCannotVerify(t *testing.T) {
	f := AgentVersionFloor{Minimum: "2026.09.11"}
	for _, v := range []string{"", "   ", "dev", "unknown", "main"} {
		if f.Allows(v) {
			t.Errorf("%q was admitted by a floor it cannot be checked against", v)
		}
		if f.Status(v) != AgentVersionUnknown {
			t.Errorf("%q status = %q, want unknown", v, f.Status(v))
		}
	}
}

// A refusal that does not say how to clear itself is a support ticket.
func TestRefusalSaysHowToFixIt(t *testing.T) {
	f := AgentVersionFloor{Minimum: "2026.09.11"}
	for _, v := range []string{"2026.01.01", "dev"} {
		r := f.RefusalReason(v)
		if r == "" {
			t.Fatalf("%q produced no reason", v)
		}
		for _, want := range []string{"2026.09.11", "Settings", "Devices"} {
			if !contains(r, want) {
				t.Errorf("reason for %q does not mention %q: %s", v, want, r)
			}
		}
	}
	if f.RefusalReason("2026.09.12") != "" {
		t.Error("an up-to-date agent was given a refusal reason")
	}
}

func contains(s, sub string) bool {
	return len(sub) <= len(s) && (func() bool {
		for i := 0; i+len(sub) <= len(s); i++ {
			if s[i:i+len(sub)] == sub {
				return true
			}
		}
		return false
	})()
}
