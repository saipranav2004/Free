// pam/internal/services/insights_service.go
//
// The numbers the console's insight cards are built from.
//
// Analytics lived on one screen out of eleven, and every other page opened
// straight into a table. The charts existed; what was missing was anything to
// put in them per page. These are those figures — each one answering a
// question an operator would otherwise work out by scanning the table
// underneath it.
//
// Every query here is deliberately cheap and bounded: an insight strip renders
// above the content on a page somebody opens constantly, so it has to cost
// about as much as the listing it sits above, not more.
package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/yourorg/pam/internal/models"
	"gorm.io/gorm"
)

// InsightsService reads aggregate figures for the console's insight cards.
type InsightsService struct {
	db *gorm.DB
}

func NewInsightsService(db *gorm.DB) *InsightsService {
	return &InsightsService{db: db}
}

// LabelledCount is the shape every breakdown comes back in: something named,
// and how many of it there are.
type LabelledCount struct {
	Label string `json:"label"`
	Value int64  `json:"value"`
}

// TimeBucket is one column of a time series.
type TimeBucket struct {
	Label string `json:"label"`
	Value int64  `json:"value"`
	// Denied is drawn as a separate segment on the same column: on an audit
	// chart the ratio of refusals to total is the interesting shape, and
	// splitting it across two charts loses that.
	Denied int64 `json:"denied,omitempty"`
}

// ── Sessions ────────────────────────────────────────────────────────────────

// SessionInsights answers "what is happening right now", which is the question
// the sessions table makes you count rows to answer.
type SessionInsights struct {
	ActiveNow int64           `json:"active_now"`
	ByChannel []LabelledCount `json:"by_channel"`
	// BreakglassActive and LongestActiveSeconds used to be counted in the
	// browser over the rows the sessions table had loaded — and that table is
	// capped at the most recent 200. Past the cap the figures silently stopped
	// being true, which is the worst way for a number to be wrong: it still
	// looks like an answer. Counted here, over everything.
	BreakglassActive     int64        `json:"breakglass_active"`
	LongestActiveSeconds int64        `json:"longest_active_seconds"`
	RecordedShare        int          `json:"recorded_share_pct"`
	RecordedOf           int64        `json:"recorded_of"`
	DurationSpread       []TimeBucket `json:"duration_spread"`
}

func (s *InsightsService) Sessions(ctx context.Context, userID string, scopeToUser bool) (*SessionInsights, error) {
	out := &SessionInsights{}
	base := s.db.WithContext(ctx).Model(&models.ConnectionSession{})
	if scopeToUser {
		base = base.Where("user_id = ?", userID)
	}

	if err := base.Session(&gorm.Session{}).
		Where("status = ?", "ACTIVE").Count(&out.ActiveNow).Error; err != nil {
		return nil, fmt.Errorf("failed to count active sessions: %w", err)
	}

	// Grouped by resource type rather than by channel: the channel a native
	// session used is not stored on the row, and inventing a column to make a
	// chart prettier is the wrong trade. Resource type is what an operator
	// actually recognises anyway.
	var byType []LabelledCount
	if err := base.Session(&gorm.Session{}).
		Select("resource_type AS label, COUNT(*) AS value").
		Where("status = ?", "ACTIVE").
		Group("resource_type").Order("value DESC").Limit(6).
		Scan(&byType).Error; err != nil {
		return nil, fmt.Errorf("failed to group active sessions: %w", err)
	}
	if byType == nil {
		byType = []LabelledCount{}
	}
	out.ByChannel = byType

	if err := base.Session(&gorm.Session{}).
		Where("status = ? AND is_breakglass = ?", "ACTIVE", true).
		Count(&out.BreakglassActive).Error; err != nil {
		return nil, fmt.Errorf("failed to count break-glass sessions: %w", err)
	}

	// Longest RUNNING session, measured from started_at rather than read from
	// duration_seconds: that column is only stamped when a session ends, so on
	// a live row it is zero and "longest running" would always answer 0.
	// sql.NullTime, not *time.Time: MIN() over no rows is NULL, and the driver
	// refuses to store a NULL into a *time.Time — it errors rather than
	// leaving the pointer nil. An install with nothing running is the normal
	// case, not an edge case.
	var oldestStart sql.NullTime
	if err := base.Session(&gorm.Session{}).
		Where("status = ?", "ACTIVE").
		Select("MIN(started_at)").Scan(&oldestStart).Error; err != nil {
		return nil, fmt.Errorf("failed to find the longest running session: %w", err)
	}
	if oldestStart.Valid {
		if elapsed := time.Since(oldestStart.Time); elapsed > 0 {
			out.LongestActiveSeconds = int64(elapsed.Seconds())
		}
	}

	// Recording coverage over the last week. "How much of what we did is
	// actually on tape" is the compliance question, and nothing on screen
	// answered it.
	since := time.Now().UTC().AddDate(0, 0, -7)
	var total, recorded int64
	weekly := base.Session(&gorm.Session{}).Where("started_at >= ?", since)
	if err := weekly.Session(&gorm.Session{}).Count(&total).Error; err != nil {
		return nil, err
	}
	if err := weekly.Session(&gorm.Session{}).
		Where("recording_id IS NOT NULL").Count(&recorded).Error; err != nil {
		return nil, err
	}
	out.RecordedOf = total
	if total > 0 {
		out.RecordedShare = int(recorded * 100 / total)
	}

	// Duration spread, as buckets rather than an average. An average session
	// length hides the thing worth seeing, which is the long tail.
	type bucketRow struct {
		Label string
		Value int64
	}
	var spread []bucketRow
	err := base.Session(&gorm.Session{}).
		Select(`CASE
				WHEN duration_seconds < 60 THEN '< 1m'
				WHEN duration_seconds < 300 THEN '1-5m'
				WHEN duration_seconds < 1800 THEN '5-30m'
				WHEN duration_seconds < 7200 THEN '30m-2h'
				ELSE '2h+'
			END AS label, COUNT(*) AS value`).
		Where("started_at >= ? AND status <> ?", since, "ACTIVE").
		Group("label").Scan(&spread).Error
	if err != nil {
		return nil, fmt.Errorf("failed to bucket session durations: %w", err)
	}
	// Ordered here rather than in SQL: the buckets are ordinal, and sorting
	// them alphabetically would put "1-5m" after "< 1m" but "30m-2h" before
	// "5-30m", which reads as noise.
	order := []string{"< 1m", "1-5m", "5-30m", "30m-2h", "2h+"}
	byLabel := map[string]int64{}
	for _, r := range spread {
		byLabel[r.Label] = r.Value
	}
	for _, label := range order {
		out.DurationSpread = append(out.DurationSpread, TimeBucket{Label: label, Value: byLabel[label]})
	}
	return out, nil
}

// secretReadActions are the audit actions that mean "somebody saw a secret".
// These are the strings the vault path actually writes (secret_access_service),
// not a guess at what they might be called: an insight card fed by an action
// name nothing emits shows a flat zero line forever and looks like a quiet
// week rather than a bug.
// pam:vault:Reveal is the HUMAN plane: an operator clicking reveal in the
// console. The two pam.secret.* actions are the MACHINE plane, written by
// secret_access_service when an application reads through a service token.
// Both are somebody seeing a secret, and leaving the human one out made the
// card answer a narrower question than its title.
//
// The reveal only started carrying its own name when the audit classifier
// was fixed — it used to be filed as pam:vault:Store — so any history from
// before that is not recoverable here.
var secretReadActions = []string{"pam.secret.read", "pam.secret.batch_read", "pam:vault:Reveal"}

// ── Vault ───────────────────────────────────────────────────────────────────

type VaultInsights struct {
	TotalSecrets    int64           `json:"total_secrets"`
	BySafe          []LabelledCount `json:"by_safe"`
	RotationOverdue int64           `json:"rotation_overdue"`
	BreakglassCount int64           `json:"breakglass_count"`
	RevealsByDay    []TimeBucket    `json:"reveals_by_day"`
}

func (s *InsightsService) Vault(ctx context.Context) (*VaultInsights, error) {
	out := &VaultInsights{}
	creds := s.db.WithContext(ctx).Model(&models.Credential{}).Where("status = ?", "active")

	if err := creds.Session(&gorm.Session{}).Count(&out.TotalSecrets).Error; err != nil {
		return nil, fmt.Errorf("failed to count credentials: %w", err)
	}
	if err := creds.Session(&gorm.Session{}).
		Select("COALESCE(pam_safes.name, 'unfiled') AS label, COUNT(*) AS value").
		Joins("LEFT JOIN pam_safes ON pam_safes.id = pam_credentials.safe_id AND pam_safes.deleted_at IS NULL").
		Group("label").Order("value DESC").Limit(6).
		Scan(&out.BySafe).Error; err != nil {
		return nil, fmt.Errorf("failed to group credentials by safe: %w", err)
	}
	if out.BySafe == nil {
		out.BySafe = []LabelledCount{}
	}

	now := time.Now().UTC()
	if err := creds.Session(&gorm.Session{}).
		Where("next_rotation_at IS NOT NULL AND next_rotation_at < ?", now).
		Count(&out.RotationOverdue).Error; err != nil {
		return nil, err
	}
	if err := creds.Session(&gorm.Session{}).
		Where("is_breakglass = ?", true).Count(&out.BreakglassCount).Error; err != nil {
		return nil, err
	}

	// Reveals over 30 days, read from the audit trail rather than a counter:
	// the audit log is the record of what happened, and a second counter
	// would be a second truth to keep in step.
	buckets, err := s.dailyAuditCounts(ctx, 30, secretReadActions, "")
	if err != nil {
		return nil, err
	}
	out.RevealsByDay = buckets
	return out, nil
}

// ── Service identities ──────────────────────────────────────────────────────

type ServiceInsights struct {
	// Identities counts ACTIVE identities only, and Disabled counts the rest.
	// Both are returned because the card sits directly above a table that
	// lists every identity including the disabled ones: reporting "2 / 4"
	// over a list headed "16" reads as the two disagreeing, when they are
	// answering different questions. The card has to be able to say which
	// question it answered.
	Identities int64 `json:"identities"`
	Disabled   int64 `json:"disabled"`
	// ReadyCount is how many active identities can actually authenticate AND
	// read something: a live token and a live grant. An identity with one but
	// not the other is configured, not working, and that gap is invisible in
	// a list that shows every identity as "active".
	ReadyCount     int64           `json:"ready_count"`
	ScopeBreadth   []LabelledCount `json:"scope_breadth"`
	TokensExpiring []TimeBucket    `json:"tokens_expiring"`
	VaultWide      int64           `json:"vault_wide"`
}

func (s *InsightsService) Services(ctx context.Context) (*ServiceInsights, error) {
	out := &ServiceInsights{}
	now := time.Now().UTC()

	if err := s.db.WithContext(ctx).Model(&models.ServiceIdentity{}).
		Where("status = ?", "active").Count(&out.Identities).Error; err != nil {
		return nil, fmt.Errorf("failed to count service identities: %w", err)
	}

	if err := s.db.WithContext(ctx).Model(&models.ServiceIdentity{}).
		Where("status <> ?", "active").Count(&out.Disabled).Error; err != nil {
		return nil, fmt.Errorf("failed to count disabled service identities: %w", err)
	}

	// Two EXISTS rather than two joins: joining live tokens to live grants
	// multiplies the rows and then needs a DISTINCT to undo itself, which is
	// both slower and easier to get subtly wrong.
	if err := s.db.WithContext(ctx).Model(&models.ServiceIdentity{}).
		Where("status = ?", "active").
		Where(`EXISTS (SELECT 1 FROM pam_service_tokens t
			WHERE t.service_id = pam_service_identities.id
			  AND t.revoked_at IS NULL
			  AND (t.expires_at IS NULL OR t.expires_at > ?))`, now).
		Where(`EXISTS (SELECT 1 FROM pam_service_grants g
			WHERE g.service_id = pam_service_identities.id
			  AND g.revoked_at IS NULL
			  AND (g.expires_at IS NULL OR g.expires_at > ?))`, now).
		Count(&out.ReadyCount).Error; err != nil {
		return nil, fmt.Errorf("failed to count ready service identities: %w", err)
	}

	// Scope breadth, classified in Go because the glob dialect is defined
	// there (models.ScopeBreadth) and encoding it in SQL would be a second
	// implementation to keep in step with the matcher.
	var grants []models.ServiceGrant
	if err := s.db.WithContext(ctx).
		Where("revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)", now).
		Find(&grants).Error; err != nil {
		return nil, err
	}
	counts := map[string]int64{}
	for i := range grants {
		b := models.ScopeBreadth(grants[i].Scope)
		counts[b]++
		if b == models.ScopeBreadthAll {
			out.VaultWide++
		}
	}
	for _, b := range []string{models.ScopeBreadthExact, models.ScopeBreadthWildcard, models.ScopeBreadthSubtree, models.ScopeBreadthAll} {
		out.ScopeBreadth = append(out.ScopeBreadth, LabelledCount{Label: b, Value: counts[b]})
	}

	// Token expiry runway. "How much notice do I have" is the operational
	// question, and a list of dates does not answer it at a glance.
	type row struct {
		Label string
		Value int64
	}
	var runway []row
	err := s.db.WithContext(ctx).Model(&models.ServiceToken{}).
		Select(`CASE
				WHEN expires_at IS NULL THEN 'never'
				WHEN expires_at < NOW() THEN 'expired'
				WHEN expires_at < NOW() + INTERVAL '7 days' THEN '< 7d'
				WHEN expires_at < NOW() + INTERVAL '30 days' THEN '< 30d'
				ELSE '30d+'
			END AS label, COUNT(*) AS value`).
		Where("revoked_at IS NULL").
		Group("label").Scan(&runway).Error
	if err != nil {
		return nil, fmt.Errorf("failed to bucket token expiry: %w", err)
	}
	byLabel := map[string]int64{}
	for _, r := range runway {
		byLabel[r.Label] = r.Value
	}
	for _, label := range []string{"expired", "< 7d", "< 30d", "30d+", "never"} {
		out.TokensExpiring = append(out.TokensExpiring, TimeBucket{Label: label, Value: byLabel[label]})
	}
	return out, nil
}

// ── While you were away ─────────────────────────────────────────────────────

// AwayDigest answers the first question an administrator asks on Monday:
// what happened while I was not looking.
//
// There is a bell and a notifications page, and neither answers it — a bell
// tells you about things addressed TO you, which is a different set from
// things that HAPPENED. The audit chain already holds the answer; nothing was
// reading it this way.
type AwayDigest struct {
	// Since is the anchor. Never null in a response: a first visit gets a
	// bounded window rather than the whole history, because "1,400 events
	// since the beginning of time" is not a digest.
	Since       time.Time       `json:"since"`
	FirstVisit  bool            `json:"first_visit"`
	TotalEvents int64           `json:"total_events"`
	Denied      int64           `json:"denied"`
	Breakglass  int64           `json:"breakglass"`
	NewSessions int64           `json:"new_sessions"`
	SecretReads int64           `json:"secret_reads"`
	TopActors   []LabelledCount `json:"top_actors"`
	Critical    []DigestEvent   `json:"critical"`
}

// DigestEvent is one thing worth naming individually rather than counting.
type DigestEvent struct {
	At       time.Time `json:"at"`
	Action   string    `json:"action"`
	Actor    string    `json:"actor"`
	Resource string    `json:"resource,omitempty"`
	Outcome  string    `json:"outcome"`
	Severity string    `json:"severity"`
}

// digestWorthy separates what HAPPENED from who was LOOKING.
//
// This one predicate is the difference between a digest and a hit counter.
// The request auditor files a row for every authenticated API call, so a
// console left open on the sessions page generates hundreds of them: over a
// live six-hour window, 752 of 960 rows were generic request audits and
// another 248 were list/read permission checks the console fired by being
// open. A card reporting "960 events since you were away" is not reporting
// anything — it is reporting that somebody had a browser tab open.
//
// So the rule is: an event belongs in the digest if it CHANGED something or
// was REFUSED. A refusal is an event however read-only the request was — a
// denied read is precisely the thing worth telling somebody about — and a
// secret read is an event because somebody SAW a credential, which is the one
// read this product exists to record. Everything else is navigation.
//
// The three suffixes come from the permission-gate auditor (pam:audit:Read,
// pam:session:List, pam:resource:GET); the two prefixes from the generic
// request auditor (pam:other:GET:/api/...). Both are the shapes this codebase
// actually writes — checked against the live table, not guessed, because an
// exclusion that matches nothing silently leaves the noise in and an
// exclusion that matches everything silently empties the card.
// Built from secretReadActions rather than repeating the two action strings,
// so this predicate cannot drift out of step with the vault card that uses
// the same list.
var digestWorthy = fmt.Sprintf(`(
	outcome = 'DENIED'
	OR action IN ('%s')
	OR (
		action NOT LIKE 'pam:other:GET:%%'
		AND action NOT LIKE 'pam:other:HEAD:%%'
		AND action NOT LIKE '%%:List'
		AND action NOT LIKE '%%:Read'
		AND action NOT LIKE '%%:GET'
	)
)`, strings.Join(secretReadActions, "', '"))

// maxFirstVisitWindow bounds a first-ever digest. Seven days is the span the
// question is actually asked over — "what happened while I was away" is a
// weekend or a holiday, not a quarter.
const maxFirstVisitWindow = 7 * 24 * time.Hour

// Away builds the digest for one account.
//
// scopeUserID carries the same rule as everything else here: empty for an
// administrator, the caller's own id otherwise. An operator's digest is about
// their own activity — telling them who else was busy is the disclosure the
// audit scoping exists to prevent.
func (s *InsightsService) Away(ctx context.Context, userID string, seenAt *time.Time, scopeUserID string) (*AwayDigest, error) {
	now := time.Now().UTC()
	out := &AwayDigest{}

	// A missing or very old marker both resolve to the same bounded window.
	// Clamping rather than erroring means a first visit and a long absence
	// produce the same readable digest instead of one of them producing
	// thousands of rows.
	floor := now.Add(-maxFirstVisitWindow)
	switch {
	case seenAt == nil:
		out.Since, out.FirstVisit = floor, true
	case seenAt.Before(floor):
		out.Since, out.FirstVisit = floor, false
	default:
		out.Since = seenAt.UTC()
	}

	base := s.db.WithContext(ctx).Model(&models.AuditLog{}).
		Where("occurred_at >= ?", out.Since).
		Where(digestWorthy).
		// And the digest must not count ITSELF. The POST that acknowledges
		// the card is a write, so it survives the filter above on its own
		// merits; without this, dismissing the card left "1 event" behind —
		// the dismissal — and the card came straight back. Matched on the
		// resource path because the action string carries the method and
		// would need one exclusion per verb.
		Where("resource IS NULL OR resource NOT LIKE ?", "%/pam/insights/%")
	if scopeUserID != "" {
		base = base.Where("user_id = ?", scopeUserID)
	}

	if err := base.Session(&gorm.Session{}).Count(&out.TotalEvents).Error; err != nil {
		return nil, fmt.Errorf("failed to count events since the last visit: %w", err)
	}
	if err := base.Session(&gorm.Session{}).
		Where("outcome = ?", models.OutcomeDenied).Count(&out.Denied).Error; err != nil {
		return nil, err
	}
	if err := base.Session(&gorm.Session{}).
		Where("action IN ?", secretReadActions).Count(&out.SecretReads).Error; err != nil {
		return nil, err
	}
	if err := base.Session(&gorm.Session{}).
		Select("COALESCE(NULLIF(username, ''), user_id) AS label, COUNT(*) AS value").
		Group("label").Order("value DESC").Limit(5).
		Scan(&out.TopActors).Error; err != nil {
		return nil, fmt.Errorf("failed to find who was busy: %w", err)
	}
	if out.TopActors == nil {
		out.TopActors = []LabelledCount{}
	}

	// Sessions are counted from the session table rather than the audit log:
	// a session is a row with a lifecycle, and counting its start events would
	// double anything that emitted more than one.
	sessions := s.db.WithContext(ctx).Model(&models.ConnectionSession{}).
		Where("started_at >= ?", out.Since)
	if scopeUserID != "" {
		sessions = sessions.Where("user_id = ?", scopeUserID)
	}
	if err := sessions.Session(&gorm.Session{}).Count(&out.NewSessions).Error; err != nil {
		return nil, err
	}
	if err := sessions.Session(&gorm.Session{}).
		Where("is_breakglass = ?", true).Count(&out.Breakglass).Error; err != nil {
		return nil, err
	}

	// CRITICAL events are named individually, not counted. A count of
	// "3 critical events" is the one number nobody can act on — break-glass
	// use and grant revocations are read one at a time or not at all.
	var rows []models.AuditLog
	if err := base.Session(&gorm.Session{}).
		Where("severity = ? OR outcome = ?", "CRITICAL", models.OutcomeDenied).
		Order("occurred_at DESC").Limit(8).Find(&rows).Error; err != nil {
		return nil, fmt.Errorf("failed to read critical events: %w", err)
	}
	out.Critical = make([]DigestEvent, 0, len(rows))
	for _, r := range rows {
		actor := r.Username
		if actor == "" {
			actor = r.UserID
		}
		name := r.ResourceName
		if name == "" {
			name = r.Resource
		}
		out.Critical = append(out.Critical, DigestEvent{
			At: r.OccurredAt, Action: r.Action, Actor: actor,
			Resource: name, Outcome: string(r.Outcome), Severity: r.Severity,
		})
	}
	return out, nil
}

// DigestAnchor reads one account's marker.
//
// Split out from Away so that Away stays a pure function of (anchor, now) and
// can be tested without writing a users row for every case. A missing user is
// not an error here: the caller is authenticated, so the only way to get no
// row is a race with a deletion, and a deleted user's digest is correctly
// "never seen" rather than a 500.
func (s *InsightsService) DigestAnchor(ctx context.Context, userID string) (*time.Time, error) {
	var out struct{ DigestSeenAt *time.Time }
	err := s.db.WithContext(ctx).Model(&models.User{}).
		Select("digest_seen_at").
		Where("user_id = ?", userID).
		Limit(1).
		Scan(&out).Error
	if err != nil {
		return nil, err
	}
	return out.DigestSeenAt, nil
}

// MarkDigestSeen moves the anchor forward. Called when the digest is READ,
// never at login — see models.User.DigestSeenAt for why that distinction is
// the whole feature.
func (s *InsightsService) MarkDigestSeen(ctx context.Context, userID string, at time.Time) error {
	return s.db.WithContext(ctx).Model(&models.User{}).
		Where("user_id = ?", userID).
		Update("digest_seen_at", at.UTC()).Error
}

// ── Shared ──────────────────────────────────────────────────────────────────

// dailyAuditCounts buckets audit events by day, filling empty days with zero
// so a sparse series still reads as a timeline rather than as a few floating
// points.
func (s *InsightsService) dailyAuditCounts(ctx context.Context, days int, actions []string, scopeUserID string) ([]TimeBucket, error) {
	since := time.Now().UTC().AddDate(0, 0, -days).Truncate(24 * time.Hour)

	type row struct {
		Day   time.Time
		Total int64
	}
	var rows []row
	q := s.db.WithContext(ctx).Model(&models.AuditLog{}).
		Select("DATE_TRUNC('day', occurred_at) AS day, COUNT(*) AS total").
		Where("occurred_at >= ?", since)
	if len(actions) > 0 {
		q = q.Where("action IN ?", actions)
	}
	if scopeUserID != "" {
		q = q.Where("user_id = ?", scopeUserID)
	}
	if err := q.Group("day").Order("day").Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("failed to bucket audit events: %w", err)
	}

	byDay := map[string]int64{}
	for _, r := range rows {
		byDay[r.Day.Format("2006-01-02")] = r.Total
	}
	out := make([]TimeBucket, 0, days)
	for i := days - 1; i >= 0; i-- {
		d := time.Now().UTC().AddDate(0, 0, -i).Format("2006-01-02")
		out = append(out, TimeBucket{Label: d, Value: byDay[d]})
	}
	return out, nil
}

// AuditInsights answers the questions the audit table makes you filter for.
type AuditInsights struct {
	EventsByDay []TimeBucket    `json:"events_by_day"`
	TopActors   []LabelledCount `json:"top_actors"`
	DeniedRate  int             `json:"denied_rate_pct"`
	TotalEvents int64           `json:"total_events"`
}

// Audit reads the figures over the caller's own visible slice of the trail.
//
// scopeUserID carries the same rule the audit LISTING already enforces: empty
// for root and admin, the caller's own id for everyone else. An aggregate is
// still a disclosure — "who are the busiest actors in the org" is exactly the
// question a non-admin must not get an answer to, and it would have been
// easier to leak here than in the table underneath, because no row is ever
// shown.
func (s *InsightsService) Audit(ctx context.Context, days int, scopeUserID string) (*AuditInsights, error) {
	out := &AuditInsights{}
	since := time.Now().UTC().AddDate(0, 0, -days)

	buckets, err := s.dailyAuditCounts(ctx, days, nil, scopeUserID)
	if err != nil {
		return nil, err
	}
	out.EventsByDay = buckets

	base := s.db.WithContext(ctx).Model(&models.AuditLog{}).Where("occurred_at >= ?", since)
	if scopeUserID != "" {
		base = base.Where("user_id = ?", scopeUserID)
	}
	if err := base.Session(&gorm.Session{}).Count(&out.TotalEvents).Error; err != nil {
		return nil, err
	}
	if err := base.Session(&gorm.Session{}).
		Select("COALESCE(NULLIF(username, ''), user_id) AS label, COUNT(*) AS value").
		Group("label").Order("value DESC").Limit(6).
		Scan(&out.TopActors).Error; err != nil {
		return nil, fmt.Errorf("failed to find top actors: %w", err)
	}
	if out.TopActors == nil {
		out.TopActors = []LabelledCount{}
	}

	var denied int64
	if err := base.Session(&gorm.Session{}).
		Where("outcome = ?", models.OutcomeDenied).Count(&denied).Error; err != nil {
		return nil, err
	}
	if out.TotalEvents > 0 {
		out.DeniedRate = int(denied * 100 / out.TotalEvents)
	}
	return out, nil
}
