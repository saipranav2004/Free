package services

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
)

// The digest answers "what happened while I was not looking", so every
// assertion here is about the BOUNDARY: what falls inside the window, what
// falls outside it, and what a first visit is allowed to sweep up. A digest
// that quietly includes everything is not a digest, and one that quietly
// includes nothing reads as a calm week.

func seedDigestFixture(t *testing.T, svc *InsightsService) {
	t.Helper()
	now := time.Now().UTC()
	db := svc.db

	rows := []models.AuditLog{
		// Inside a two-hour window.
		{ID: "a1", UserID: "u1", Username: "alice", Action: "pam.secret.read", Resource: "safe/prod", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-30 * time.Minute)},
		{ID: "a2", UserID: "u1", Username: "alice", Action: "pam.secret.read", Resource: "safe/prod", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-40 * time.Minute)},
		{ID: "a3", UserID: "u2", Username: "bob", Action: "pam.resource.connect", Resource: "pg-1", Outcome: models.OutcomeDenied, Severity: "WARNING", OccurredAt: now.Add(-50 * time.Minute)},
		{ID: "a4", UserID: "u2", Username: "bob", Action: "pam.breakglass.use", Resource: "pg-1", Outcome: models.OutcomeSuccess, Severity: "CRITICAL", OccurredAt: now.Add(-55 * time.Minute)},
		// Outside a two-hour window but inside the seven-day first-visit one.
		{ID: "a5", UserID: "u1", Username: "alice", Action: "pam.secret.read", Resource: "safe/dev", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-3 * 24 * time.Hour)},
		// Older than any window this feature will ever show.
		{ID: "a6", UserID: "u1", Username: "alice", Action: "pam.secret.read", Resource: "safe/old", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.AddDate(0, 0, -40)},
	}
	for i := range rows {
		if err := db.Create(&rows[i]).Error; err != nil {
			t.Fatalf("seed audit %s: %v", rows[i].ID, err)
		}
	}

	sessions := []models.ConnectionSession{
		{ID: "d1", UserID: "u1", Username: "alice", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "COMPLETED", StartedAt: now.Add(-20 * time.Minute)},
		{ID: "d2", UserID: "u2", Username: "bob", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "ACTIVE", StartedAt: now.Add(-25 * time.Minute), IsBreakglass: true},
		{ID: "d3", UserID: "u1", Username: "alice", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "COMPLETED", StartedAt: now.AddDate(0, 0, -40)},
	}
	for i := range sessions {
		if err := db.Create(&sessions[i]).Error; err != nil {
			t.Fatalf("seed session %s: %v", sessions[i].ID, err)
		}
	}
}

func TestDigestCountsOnlyWhatHappenedSinceTheAnchor(t *testing.T) {
	svc := NewInsightsService(insightsDB(t))
	seedDigestFixture(t, svc)

	seen := time.Now().UTC().Add(-2 * time.Hour)
	got, err := svc.Away(context.Background(), "u1", &seen, "")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	if got.FirstVisit {
		t.Error("FirstVisit = true with an anchor present")
	}
	// a1..a4 only: the three-day-old and the forty-day-old rows are outside.
	if got.TotalEvents != 4 {
		t.Errorf("TotalEvents = %d, want 4", got.TotalEvents)
	}
	if got.Denied != 1 {
		t.Errorf("Denied = %d, want 1", got.Denied)
	}
	if got.SecretReads != 2 {
		t.Errorf("SecretReads = %d, want 2 (the 3-day-old read is outside the window)", got.SecretReads)
	}
	// Counted from the session table, not from audit rows: d1 and d2 only.
	if got.NewSessions != 2 {
		t.Errorf("NewSessions = %d, want 2", got.NewSessions)
	}
	if got.Breakglass != 1 {
		t.Errorf("Breakglass = %d, want 1", got.Breakglass)
	}
	// Named, not counted: the CRITICAL break-glass row and the DENIED one.
	if len(got.Critical) != 2 {
		t.Fatalf("Critical has %d entries, want 2: %+v", len(got.Critical), got.Critical)
	}
	// Most recent first — a digest is read from the top.
	if !got.Critical[0].At.After(got.Critical[1].At) {
		t.Error("critical events are not newest-first")
	}
	for _, e := range got.Critical {
		if e.Action == "" || e.Actor == "" {
			t.Errorf("critical entry is missing the fields that make it actionable: %+v", e)
		}
	}
	if len(got.TopActors) != 2 {
		t.Errorf("TopActors = %+v, want alice and bob", got.TopActors)
	}
}

func TestAFirstVisitGetsABoundedWindowNotAllOfHistory(t *testing.T) {
	svc := NewInsightsService(insightsDB(t))
	seedDigestFixture(t, svc)

	got, err := svc.Away(context.Background(), "u1", nil, "")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	if !got.FirstVisit {
		t.Error("FirstVisit = false with no anchor")
	}
	// a1..a5: everything but the forty-day-old row. "1,400 events since the
	// beginning of time" is the failure this clamp exists to prevent.
	if got.TotalEvents != 5 {
		t.Errorf("TotalEvents = %d, want 5 — the 40-day-old row must be clamped out", got.TotalEvents)
	}
	if since := time.Since(got.Since); since < maxFirstVisitWindow-time.Minute || since > maxFirstVisitWindow+time.Minute {
		t.Errorf("Since is %v ago, want about %v", since, maxFirstVisitWindow)
	}
}

func TestAVeryOldAnchorIsClampedTheSameWayAsNoAnchor(t *testing.T) {
	svc := NewInsightsService(insightsDB(t))
	seedDigestFixture(t, svc)

	ancient := time.Now().UTC().AddDate(0, 0, -365)
	got, err := svc.Away(context.Background(), "u1", &ancient, "")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	// Clamped, so the count matches the first-visit case...
	if got.TotalEvents != 5 {
		t.Errorf("TotalEvents = %d, want 5", got.TotalEvents)
	}
	// ...but this is NOT a first visit, and the card says different things.
	if got.FirstVisit {
		t.Error("FirstVisit = true for an account that has an anchor, only an old one")
	}
}

func TestAnOperatorsDigestDescribesOnlyTheirOwnActivity(t *testing.T) {
	svc := NewInsightsService(insightsDB(t))
	seedDigestFixture(t, svc)

	seen := time.Now().UTC().Add(-2 * time.Hour)
	got, err := svc.Away(context.Background(), "u1", &seen, "u1")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	// alice's two reads only. bob's denial and break-glass belong to bob.
	if got.TotalEvents != 2 {
		t.Errorf("TotalEvents = %d, want 2", got.TotalEvents)
	}
	if got.Denied != 0 || got.Breakglass != 0 {
		t.Errorf("scoped digest leaked another user's denial/break-glass: denied=%d breakglass=%d", got.Denied, got.Breakglass)
	}
	if len(got.Critical) != 0 {
		t.Errorf("scoped digest named another user's critical events: %+v", got.Critical)
	}
	for _, a := range got.TopActors {
		if a.Label != "alice" {
			t.Errorf("scoped digest names %q — an operator must not learn who else was busy", a.Label)
		}
	}
	if got.NewSessions != 1 {
		t.Errorf("NewSessions = %d, want 1", got.NewSessions)
	}
}

func TestMarkingTheDigestSeenMovesTheAnchorAndEmptiesIt(t *testing.T) {
	db := insightsDB(t)
	if err := db.AutoMigrate(&models.User{}); err != nil {
		t.Fatalf("automigrate users: %v", err)
	}
	svc := NewInsightsService(db)
	seedDigestFixture(t, svc)

	user := models.User{UserID: "u1", Username: "alice", Email: "alice@example.com"}
	if err := db.Create(&user).Error; err != nil {
		t.Fatalf("seed user: %v", err)
	}

	// Never seen → no anchor.
	anchor, err := svc.DigestAnchor(context.Background(), "u1")
	if err != nil {
		t.Fatalf("DigestAnchor: %v", err)
	}
	if anchor != nil {
		t.Fatalf("a fresh account already has an anchor: %v", anchor)
	}

	if err := svc.MarkDigestSeen(context.Background(), "u1", time.Now().UTC()); err != nil {
		t.Fatalf("MarkDigestSeen: %v", err)
	}
	anchor, err = svc.DigestAnchor(context.Background(), "u1")
	if err != nil {
		t.Fatalf("DigestAnchor after mark: %v", err)
	}
	if anchor == nil {
		t.Fatal("the anchor did not persist — the digest would repeat itself forever")
	}

	// Everything seeded is in the past, so the digest is now empty. This is
	// the acknowledgement actually taking effect, which is the one behaviour
	// that distinguishes this from a plain audit filter.
	got, err := svc.Away(context.Background(), "u1", anchor, "")
	if err != nil {
		t.Fatalf("Away after mark: %v", err)
	}
	if got.TotalEvents != 0 || len(got.Critical) != 0 {
		t.Errorf("digest still reports %d events after being dismissed", got.TotalEvents)
	}
	if got.FirstVisit {
		t.Error("FirstVisit = true after the anchor was written")
	}
}

// The bug this pins was found live, not in a test: the generic request
// auditor files a row for every API call, so GET /insights/away and the POST
// that acknowledges it both landed in the trail — and the digest counted
// them. Dismissing the card left "1 event" behind, which was the dismissal,
// so the card came straight back and never went quiet.
func TestTheDigestDoesNotCountItsOwnReads(t *testing.T) {
	svc := NewInsightsService(insightsDB(t))
	now := time.Now().UTC()

	rows := []models.AuditLog{
		{ID: "i1", UserID: "u1", Username: "alice", Action: "pam:other:GET:/api/v1/pam/insights/away", Resource: "/api/v1/pam/insights/away", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-1 * time.Minute)},
		{ID: "i2", UserID: "u1", Username: "alice", Action: "pam:other:POST:/api/v1/pam/insights/away/seen", Resource: "/api/v1/pam/insights/away/seen", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-2 * time.Minute)},
		{ID: "i3", UserID: "u1", Username: "alice", Action: "pam:other:GET:/api/v1/pam/insights/audit", Resource: "/api/v1/pam/insights/audit", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-3 * time.Minute)},
		// A real event, to prove the filter is narrow rather than a mute
		// button on the whole query.
		{ID: "i4", UserID: "u1", Username: "alice", Action: "pam.secret.read", Resource: "/api/v1/pam/vault/secrets/x", Outcome: models.OutcomeSuccess, Severity: "INFO", OccurredAt: now.Add(-4 * time.Minute)},
	}
	for i := range rows {
		if err := svc.db.Create(&rows[i]).Error; err != nil {
			t.Fatalf("seed %s: %v", rows[i].ID, err)
		}
	}

	seen := now.Add(-10 * time.Minute)
	got, err := svc.Away(context.Background(), "u1", &seen, "")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	if got.TotalEvents != 1 {
		t.Errorf("TotalEvents = %d, want 1 — the three /insights/ reads are the console fetching its own cards", got.TotalEvents)
	}
	if got.SecretReads != 1 {
		t.Errorf("SecretReads = %d, want 1 — the filter must not swallow real events", got.SecretReads)
	}

	// And with nothing but its own reads in the window, the digest is empty,
	// which is what lets the card stay dismissed.
	quiet := now.Add(-3*time.Minute - 30*time.Second)
	empty, err := svc.Away(context.Background(), "u1", &quiet, "")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	if empty.TotalEvents != 0 {
		t.Errorf("TotalEvents = %d after dismissal, want 0 — the card would reappear showing its own dismissal", empty.TotalEvents)
	}
}

// The predicate that separates what happened from who was looking.
//
// Both directions matter. Too wide and the card reports that somebody had a
// browser tab open; too narrow and it goes quiet during a real incident. The
// action shapes below are the ones this codebase actually writes — the
// permission gate's `pam:<res>:<verb>` and the request auditor's
// `pam:other:<METHOD>:<path>`.
func TestTheDigestReportsWhatHappenedNotWhoWasLooking(t *testing.T) {
	svc := NewInsightsService(insightsDB(t))
	now := time.Now().UTC()

	noise := []string{
		"pam:other:GET:/api/v1/pam/sessions",
		"pam:other:HEAD:/api/v1/pam/resources",
		"pam:session:List",
		"pam:audit:Read",
		"pam:resource:GET",
	}
	events := []string{
		"pam:resource:POST",
		"pam:vault:Store",
		"SESSION_STARTED",
		"SESSION_ENDED",
		"RECORDING_SAVED",
		"pam:session:Connect",
		"pam.secret.read", // a read, but the one read that IS an event
		"pam:other:POST:/api/v1/pam/jit/requests",
		"pam:other:DELETE:/api/v1/pam/admin/rbac/roles/x",
	}

	rows := []models.AuditLog{}
	for i, a := range append(append([]string{}, noise...), events...) {
		rows = append(rows, models.AuditLog{
			ID: fmt.Sprintf("n%d", i), UserID: "u1", Username: "alice", Action: a,
			Outcome: models.OutcomeSuccess, Severity: "INFO",
			OccurredAt: now.Add(-time.Duration(i+1) * time.Minute),
		})
	}
	// A REFUSED read is an event however read-only the request was.
	rows = append(rows, models.AuditLog{
		ID: "denied-read", UserID: "u1", Username: "alice", Action: "pam:audit:Read",
		Outcome: models.OutcomeDenied, Severity: "WARN", OccurredAt: now.Add(-1 * time.Second),
	})
	for i := range rows {
		if err := svc.db.Create(&rows[i]).Error; err != nil {
			t.Fatalf("seed %s: %v", rows[i].ID, err)
		}
	}

	seen := now.Add(-2 * time.Hour)
	got, err := svc.Away(context.Background(), "u1", &seen, "")
	if err != nil {
		t.Fatalf("Away: %v", err)
	}
	want := int64(len(events) + 1) // the nine events plus the refused read
	if got.TotalEvents != want {
		t.Errorf("TotalEvents = %d, want %d — %d noise rows must be excluded and %d events kept",
			got.TotalEvents, want, len(noise), len(events))
	}
	if got.Denied != 1 {
		t.Errorf("Denied = %d, want 1 — a refused read is an event", got.Denied)
	}
	if got.SecretReads != 1 {
		t.Errorf("SecretReads = %d, want 1 — somebody saw a credential", got.SecretReads)
	}
}
