// pam/internal/services/agent_version.go
//
// The agent version floor.
//
// AgentVersion was reported at pairing and then never used for anything. A
// fleet on mixed versions is a problem you discover during an incident: the
// agent carries the terminate channel, the recording spool and the capability
// probes, so a machine running a build from before any of those is a machine
// where force-terminate silently does nothing and sessions are not recorded —
// and nothing on the server said so.
//
// This refuses a stale agent at LAUNCH, which is the moment where refusing
// actually protects something. Refusing at pairing would be worse: it strands
// a machine at exactly the point where it is trying to get the software it
// needs, and pairing is how a device becomes visible enough to be told it is
// out of date.
package services

import (
	"strconv"
	"strings"
)

// CompareAgentVersions orders two agent versions. It returns -1 if a < b,
// 0 if they are equal, and +1 if a > b.
//
// The scheme in use is date-based — 2026.09.11 — and a plain string compare
// happens to work for that, right up until a component loses its zero padding
// (2026.9.11) or a build suffix appears (2026.09.11-rc1). Both are ordinary
// things to ship and both break lexicographic ordering, so the components are
// compared numerically.
//
// Shorter versions compare as if padded with zeros, so 2026.09 == 2026.09.0.
func CompareAgentVersions(a, b string) int {
	as, bs := versionParts(a), versionParts(b)
	n := len(as)
	if len(bs) > n {
		n = len(bs)
	}
	for i := 0; i < n; i++ {
		var av, bv int
		if i < len(as) {
			av = as[i]
		}
		if i < len(bs) {
			bv = bs[i]
		}
		if av != bv {
			if av < bv {
				return -1
			}
			return 1
		}
	}
	return 0
}

// versionParts splits a version into its numeric components, stopping at the
// first part that is not a number.
//
// A pre-release suffix is DROPPED rather than ordered: 2026.09.11-rc1 is
// treated as 2026.09.11. Ordering pre-releases properly is a real problem with
// a real spec, and getting it half right here would mean an rc sorting above
// its own release. Treating it as the release is the conservative direction
// for a floor — it can only ever admit an rc of a version that is already
// allowed, never admit something older.
func versionParts(v string) []int {
	v = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(v), "v"))
	if v == "" {
		return nil
	}
	// Cut a build/pre-release suffix at the first - or +.
	if i := strings.IndexAny(v, "-+"); i >= 0 {
		v = v[:i]
	}
	out := make([]int, 0, 3)
	for _, part := range strings.Split(v, ".") {
		n, err := strconv.Atoi(part)
		if err != nil {
			break
		}
		out = append(out, n)
	}
	return out
}

// AgentVersionStatus is what the server can say about one device's build.
type AgentVersionStatus string

const (
	// AgentVersionOK means the reported version meets the configured floor,
	// or no floor is configured.
	AgentVersionOK AgentVersionStatus = "ok"
	// AgentVersionStale means the agent reported a version below the floor.
	AgentVersionStale AgentVersionStatus = "stale"
	// AgentVersionUnknown means a floor is set and the agent did not report a
	// version this code can compare — an old build that never sent one, or a
	// local development build.
	AgentVersionUnknown AgentVersionStatus = "unknown"
)

// AgentVersionFloor decides whether a reported version is acceptable.
//
// An empty floor disables the check entirely, so this is opt-in: a deployment
// that has not thought about it is not suddenly refusing its own fleet on
// upgrade.
//
// Once a floor IS set, a version that cannot be parsed is Unknown and treated
// as failing. That is the deliberate direction: the whole point of a floor is
// to guarantee a capability is present, and "this agent will not tell me what
// it is" is not a guarantee. It also means a local `dev` build is refused by a
// deployment with a floor, which is correct — a dev build is exactly the thing
// that should not be quietly trusted in production.
type AgentVersionFloor struct {
	Minimum string
}

func (f AgentVersionFloor) Enabled() bool { return strings.TrimSpace(f.Minimum) != "" }

func (f AgentVersionFloor) Status(reported string) AgentVersionStatus {
	if !f.Enabled() {
		return AgentVersionOK
	}
	if len(versionParts(reported)) == 0 {
		return AgentVersionUnknown
	}
	if CompareAgentVersions(reported, f.Minimum) < 0 {
		return AgentVersionStale
	}
	return AgentVersionOK
}

// Allows reports whether a device on this version may open a session.
func (f AgentVersionFloor) Allows(reported string) bool {
	return f.Status(reported) == AgentVersionOK
}

// RefusalReason is what the operator is told. It names the floor, what they
// are running, and the one action that fixes it — a refusal that does not say
// how to clear itself is a support ticket.
func (f AgentVersionFloor) RefusalReason(reported string) string {
	switch f.Status(reported) {
	case AgentVersionStale:
		return "This machine is running pam-agent " + reported + ", and this deployment requires " +
			f.Minimum + " or newer. Re-run the install command from Settings → Devices to update it."
	case AgentVersionUnknown:
		return "This machine did not report a pam-agent version, and this deployment requires " +
			f.Minimum + " or newer. Re-run the install command from Settings → Devices to update it."
	default:
		return ""
	}
}
