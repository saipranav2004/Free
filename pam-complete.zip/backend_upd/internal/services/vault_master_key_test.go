package services

import (
	"os"
	"strings"
	"testing"

	"go.uber.org/zap"
)

// The regression these tests pin:
//
// NewVaultService used to read PAM_VAULT_ENCRYPTION_KEY itself and, when the
// variable was unset, fall back to a base64 key written literally into
// vault_service.go. Config validation does require vault.encryption_key — but
// viper resolves that key from a config file (./config.yaml, ./configs,
// /etc/pam) just as happily as from the environment. So a deployment that put
// its master key in a config file, which is an ordinary thing to do, passed
// validation, started without a warning, and encrypted its whole vault under
// a key that ships in the source tree. A database dump or an S3 vault backup
// plus a copy of the repository was enough to decrypt every credential.

func TestVaultRefusesToStartWithoutAMasterKey(t *testing.T) {
	// The environment is deliberately populated: if the constructor ever
	// starts reading it again, this test fails rather than silently passing.
	t.Setenv("PAM_VAULT_ENCRYPTION_KEY", testVaultKey)

	for _, empty := range []string{"", "   ", "\t\n"} {
		svc, err := NewVaultService(nil, empty, zap.NewNop())
		if err == nil {
			t.Fatalf("an empty master key must refuse to start, got a working service (%v)", svc)
		}
		if !strings.Contains(err.Error(), "vault.encryption_key") {
			t.Fatalf("the error must name the setting to fix, got %q", err)
		}
	}
}

func TestVaultDoesNotReadTheKeyFromTheEnvironment(t *testing.T) {
	// A deployment whose key lives in a config file reaches the constructor
	// with the key as an argument and nothing in the environment. That must
	// work, and it must use the key it was given.
	if err := os.Unsetenv("PAM_VAULT_ENCRYPTION_KEY"); err != nil {
		t.Fatal(err)
	}
	if _, err := NewVaultService(nil, testVaultKey, zap.NewNop()); err != nil {
		t.Fatalf("a key passed as an argument must be accepted with no env var set: %v", err)
	}
}

func TestNoHardcodedMasterKeyRemainsInTheSource(t *testing.T) {
	// The specific key that used to be the fallback. Named here so that
	// reintroducing it anywhere in this file fails the build's own tests.
	const retired = "TGdISHdR0jyKFvwAeuzgvaWPSLTw40gKeHghDF93S9U="

	src, err := os.ReadFile("vault_service.go")
	if err != nil {
		t.Fatal(err)
	}
	// It is allowed to be *named* in a comment explaining the history; it is
	// not allowed to be a value the code can fall back to. Assign it and the
	// test fails.
	for _, line := range strings.Split(string(src), "\n") {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "//") {
			continue
		}
		if strings.Contains(line, retired) {
			t.Fatalf("the retired fallback master key is live code again: %s", trimmed)
		}
	}
}

func TestAnInvalidMasterKeyIsRejectedRatherThanPaddedOut(t *testing.T) {
	cases := map[string]string{
		"not base64": "this is not base64 at all !!",
		"too short":  "c2hvcnQ=",                                         // 5 bytes
		"too long":   "MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWZmZg==", // 34 bytes
	}
	for name, key := range cases {
		if _, err := NewVaultService(nil, key, zap.NewNop()); err == nil {
			t.Errorf("%s: a %q master key must be rejected", name, key)
		}
	}
}
