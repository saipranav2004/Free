// pam/internal/services/resource_service.go
package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

var (
	ErrResourceNotFound  = errors.New("resource not found")
	ErrVaultNotFound     = errors.New("vault entry not found")
	ErrAlreadyCheckedOut = errors.New("credential is already checked out")
)

// ResourceService manages the resource registry, vault, and connection sessions.
type ResourceService struct {
	db        *gorm.DB
	cryptoKey string
	logger    *zap.Logger

	// kms decrypts vaulted credentials. It is the SAME provider VaultService
	// writes with, and that is the whole point of it being here.
	//
	// THE BUG THIS FIXES. The vault moved to envelope encryption: the stored
	// value became a JSON document, {"ciphertext":...,"nonce":...,...}, with
	// the data key wrapped by the KMS and the row's identity bound in as AAD.
	// This service kept decrypting the column the old way — raw base64
	// AES-GCM — so every read of a credential written by the current vault
	// failed at the first character, "illegal base64 data at input byte 0",
	// because `{` is not base64.
	//
	// That is not a vault bug. The vault was fine. It is a CONSUMER that was
	// never updated, and it sits under everything that injects a credential:
	// brokered web sessions, the native agent launch, the in-browser
	// terminal. Each of those reported its own unrelated-looking failure —
	// "could not open a brokered session", a download that does nothing —
	// which is why it read as several bugs rather than one.
	//
	// Nil is tolerated: a deployment that never moved to envelope encryption
	// still decrypts through the legacy path below.
	kms crypto.KMSProvider

	// liveSessions maps an ACTIVE pam_connection_sessions.id to the cancel
	// function of the goroutine actually holding that connection open (see
	// internal/gateway — the in-browser terminal). This is what makes
	// KillSession/RequireActiveGrant revocation reach a LIVE socket instead
	// of only flipping a database row — previously KillSession's doc comment
	// explicitly flagged this as a gap ("cannot tear down a TCP connection
	// the client already established"); the gateway package closes it.
	//
	// Intentionally in-process, not Redis-backed: PAM runs as a single
	// instance today. If PAM is ever horizontally scaled, this map needs to
	// become a pub/sub-backed registry so a kill issued against instance A
	// can reach a socket held open by instance B — flagged here rather than
	// silently assumed away.
	liveMu       sync.Mutex
	liveSessions map[string]func()
}

func NewResourceService(db *gorm.DB, cryptoKey string, logger *zap.Logger) *ResourceService {
	return &ResourceService{db: db, cryptoKey: cryptoKey, logger: logger, liveSessions: make(map[string]func())}
}

// WithKMS attaches the vault's KMS provider so credentials written with
// envelope encryption can be read back. Wired after construction because
// ResourceService is built before VaultService (it is a dependency of the
// middleware), and neither can take the other in its constructor.
//
// Returns the receiver so it can be chained at the call site, and so that
// forgetting to call it is visible there rather than only at runtime.
func (s *ResourceService) WithKMS(kms crypto.KMSProvider) *ResourceService {
	s.kms = kms
	return s
}

// decryptCredential reads one stored secret, whichever scheme wrote it.
//
// Envelope first, because that is what the current vault writes and what the
// AAD binding protects: the row's safe, account and resource are mixed into
// the decryption, so a ciphertext moved to another row fails to open rather
// than silently decrypting under a different identity.
//
// The legacy raw-AES path stays for rows written before that change. It is a
// fallback, not an equal option — it is tried only when there is no KMS or
// the stored value is plainly not an envelope, and it carries no AAD, so it
// cannot detect a moved ciphertext at all.
func (s *ResourceService) decryptCredential(entry models.Credential) (string, error) {
	looksEnveloped := strings.HasPrefix(strings.TrimSpace(entry.CredentialEnc), "{")

	if s.kms != nil {
		// EnvelopeDecryptor handles both shapes itself, including the legacy
		// one when the provider is local.
		return crypto.EnvelopeDecryptor(context.Background(), s.kms, entry.CredentialEnc, entry.EncryptionAAD())
	}
	if looksEnveloped {
		// Say what is actually wrong. Without this the caller sees a base64
		// error about a value that is not base64 and never was, which is how
		// this went unrecognised: the message described the symptom in terms
		// of the wrong scheme.
		return "", fmt.Errorf("credential is envelope-encrypted but this service has no KMS provider " +
			"(call ResourceService.WithKMS with the vault's provider)")
	}
	return crypto.Decrypt(entry.CredentialEnc, s.cryptoKey)
}

// RegisterLiveSession records the cancel function for a just-opened
// in-browser terminal session, so a later KillSession/grant-revoke can
// force-close it. Call once, right after the session row is created.
func (s *ResourceService) RegisterLiveSession(sessionID string, cancel func()) {
	s.liveMu.Lock()
	defer s.liveMu.Unlock()
	s.liveSessions[sessionID] = cancel
}

// UnregisterLiveSession removes the entry once the socket has closed on its
// own (client disconnected, protocol error, etc.) — safe to call even if the
// session was never registered or was already removed.
func (s *ResourceService) UnregisterLiveSession(sessionID string) {
	s.liveMu.Lock()
	defer s.liveMu.Unlock()
	delete(s.liveSessions, sessionID)
}

// KillLiveSession force-closes a live terminal socket if one is registered
// for this session ID. Returns false (a no-op, not an error) when the
// session was never a web-terminal session in the first place — e.g. it was
// opened via the native agent, or the socket already closed on its own.
func (s *ResourceService) KillLiveSession(sessionID string) bool {
	s.liveMu.Lock()
	cancel, ok := s.liveSessions[sessionID]
	delete(s.liveSessions, sessionID)
	s.liveMu.Unlock()
	if ok && cancel != nil {
		cancel()
	}
	return ok
}

// DB exposes the underlying *gorm.DB for handlers that need raw queries.
func (s *ResourceService) DB() *gorm.DB {
	return s.db
}

// ──────────────────────────────────────────────────────────────────────────
// RESOURCE CRUD
// ──────────────────────────────────────────────────────────────────────────

// CreateResource registers a new target system (database, service, app).
func (s *ResourceService) CreateResource(r *models.PAMResource) error {
	return s.db.Create(r).Error
}

// ValidateExtraConfigJSON rejects a malformed ExtraConfig payload before it
// is ever persisted — the resource-management handlers call this from both
// Create and Update. An empty string is valid (no extra config at all);
// anything non-empty must parse as a JSON object, since ResolveConnection
// unmarshals it straight into map[string]interface{} at connect time. This
// is what keeps a typo in, e.g., a MinIO resource's {"use_ssl": true}
// extra_config from being silently accepted here and only discovered later
// as a hard connect-time failure (see ResolveConnection's doc comment).
func ValidateExtraConfigJSON(raw string) error {
	if raw == "" {
		return nil
	}
	var v map[string]interface{}
	if err := json.Unmarshal([]byte(raw), &v); err != nil {
		return fmt.Errorf("extra_config must be a valid JSON object: %w", err)
	}
	return nil
}

// GetResource fetches a single resource by ID.
func (s *ResourceService) GetResource(id string) (*models.PAMResource, error) {
	var r models.PAMResource
	if err := s.db.Where("id = ?", id).First(&r).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrResourceNotFound
		}
		return nil, err
	}
	return &r, nil
}

// ListResources returns all active resources, optionally filtered by type.
func (s *ResourceService) ListResources(resourceType string) ([]models.PAMResource, error) {
	var resources []models.PAMResource
	query := s.db.Where("is_active = ?", true).Order("resource_type ASC, name ASC")
	if resourceType != "" {
		query = query.Where("resource_type = ?", resourceType)
	}
	err := query.Find(&resources).Error
	return resources, err
}

// ListResourceGroups returns resources grouped by type (for UI display).
func (s *ResourceService) ListResourceGroups() ([]models.ResourceGroup, error) {
	resources, err := s.ListResources("")
	if err != nil {
		return nil, err
	}

	groupMap := make(map[string][]models.PAMResource)
	for _, r := range resources {
		groupMap[r.ResourceType] = append(groupMap[r.ResourceType], r)
	}

	typeInfo := map[string]struct{ Name, Icon string }{
		"postgresql": {"PostgreSQL Databases", "🐘"},
		"mongodb":    {"MongoDB Databases", "🍃"},
		"redis":      {"Redis Instances", "🔴"},
		"clickhouse": {"ClickHouse Databases", "⚡"},
		"minio":      {"MinIO Storage", "📦"},
		"qdrant":     {"Qdrant Vector DB", "🔍"},
		"metabase":   {"Metabase BI", "📊"},
		"langfuse":   {"Langfuse Observability", "🔬"},
		"web":        {"Web Applications", "🌐"},
	}

	var groups []models.ResourceGroup
	for rtype, items := range groupMap {
		info, ok := typeInfo[rtype]
		if !ok {
			info = struct{ Name, Icon string }{rtype, "🔗"}
		}
		groups = append(groups, models.ResourceGroup{
			Name:      info.Name,
			Icon:      info.Icon,
			Resources: items,
		})
	}
	return groups, nil
}

// UpdateResource updates a resource's mutable fields.
func (s *ResourceService) UpdateResource(id string, updates map[string]interface{}) error {
	result := s.db.Model(&models.PAMResource{}).Where("id = ?", id).Updates(updates)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return ErrResourceNotFound
	}
	return nil
}

// DeleteResource soft-deletes a resource.
func (s *ResourceService) DeleteResource(id string) error {
	return s.db.Where("id = ?", id).Delete(&models.PAMResource{}).Error
}

// ──────────────────────────────────────────────────────────────────────────
// VAULT (encrypted credential management)
// ──────────────────────────────────────────────────────────────────────────

// StoreCredential creates a vault entry with an AES-256-GCM encrypted credential.
func (s *ResourceService) StoreCredential(resourceID, accountName, credentialType, plaintext string) (*models.VaultEntry, error) {
	encrypted, err := crypto.Encrypt(plaintext, s.cryptoKey)
	if err != nil {
		return nil, fmt.Errorf("failed to encrypt credential: %w", err)
	}

	entry := &models.VaultEntry{
		ResourceID:     resourceID,
		AccountName:    accountName,
		CredentialType: credentialType,
		CredentialEnc:  encrypted,
	}

	if err := s.db.Create(entry).Error; err != nil {
		return nil, fmt.Errorf("failed to store vault entry: %w", err)
	}

	// Link the vault entry to the resource.
	s.db.Model(&models.PAMResource{}).Where("id = ?", resourceID).
		Update("vault_entry_id", entry.ID)

	s.logger.Info("vault.credential.stored",
		zap.String("resource_id", resourceID),
		zap.String("account", accountName),
	)
	return entry, nil
}

// GetDecryptedCredential retrieves and decrypts THE CURRENT credential for a
// resource. This is called ONLY at connection time — the plaintext is never
// stored or logged.
//
// BUGFIX: this used to do a bare `Where("resource_id = ?", resourceID).
// First(&entry)` with no ORDER BY at all — GORM's First() then falls back to
// ordering by primary key (a random UUID string), NOT insertion order. Store
// a credential more than once for the same resource (re-storing after a
// mistake, or StoreCredential being called again) and this would pick
// whichever row's UUID happened to sort first alphabetically — a coin flip
// between the current and a stale, possibly differently-encrypted-key
// credential, which would then make the in-browser terminal gateway (see
// internal/gateway) intermittently fail to authenticate against the real
// target with no obvious cause. Fixed by resolving through the resource's
// own VaultEntryID pointer (the field StoreCredential already sets and that
// was simply never consulted here), which is authoritative for "the current
// one." Legacy rows created before this fix (VaultEntryID somehow unset)
// fall back to the most recently created entry for that resource, which is
// the closest available approximation of "current."
func (s *ResourceService) GetDecryptedCredential(resourceID string) (accountName, plaintext string, err error) {
	resource, err := s.GetResource(resourceID)
	if err != nil {
		return "", "", err
	}

	var entry models.VaultEntry
	q := s.db.Where("resource_id = ?", resourceID)
	if resource.VaultEntryID != nil && *resource.VaultEntryID != "" {
		q = s.db.Where("id = ?", *resource.VaultEntryID)
	} else {
		q = q.Order("created_at DESC")
	}
	if err := q.First(&entry).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return "", "", ErrVaultNotFound
		}
		return "", "", err
	}

	decrypted, err := s.decryptCredential(entry)
	if err != nil {
		return "", "", fmt.Errorf("failed to decrypt credential: %w", err)
	}

	return entry.AccountName, decrypted, nil
}

// RotateCredential replaces the CURRENT credential (resolved the same way
// GetDecryptedCredential resolves it — via the resource's VaultEntryID
// pointer) with a new one.
//
// BUGFIX: this used to run `Where("resource_id = ?", resourceID).Updates(...)`
// with no row-scoping beyond resource_id — if more than one vault entry ever
// existed for a resource (see GetDecryptedCredential's fix above for how
// that happens), this would silently rewrite ALL of them, re-encrypting
// stale rows nothing was reading anyway and masking the fact that a
// duplicate existed at all.
func (s *ResourceService) RotateCredential(resourceID, newPlaintext string) error {
	resource, err := s.GetResource(resourceID)
	if err != nil {
		return err
	}
	encrypted, err := crypto.Encrypt(newPlaintext, s.cryptoKey)
	if err != nil {
		return err
	}
	now := time.Now()

	q := s.db.Model(&models.VaultEntry{})
	if resource.VaultEntryID != nil && *resource.VaultEntryID != "" {
		q = q.Where("id = ?", *resource.VaultEntryID)
	} else {
		q = q.Where("resource_id = ?", resourceID)
	}
	return q.Updates(map[string]interface{}{
		"credential_enc":  encrypted,
		"last_rotated_at": now,
	}).Error
}

// ──────────────────────────────────────────────────────────────────────────
// CONNECTION SESSIONS
// ──────────────────────────────────────────────────────────────────────────

// StartSession creates a connection session record when a user connects to a resource.
func (s *ResourceService) StartSession(userID, username, resourceID, sourceIP,
	authzDecisionID string) (*models.ConnectionSession, error) {

	resource, err := s.GetResource(resourceID)
	if err != nil {
		return nil, err
	}

	allowed := true
	session := &models.ConnectionSession{
		UserID:          userID,
		Username:        username,
		ResourceID:      resourceID,
		ResourceName:    resource.Name,
		ResourceType:    resource.ResourceType,
		SourceIP:        sourceIP,
		Protocol:        resource.ResourceType,
		Status:          "ACTIVE",
		AuthzDecisionID: &authzDecisionID,
		AuthzAllowed:    &allowed,
	}

	if err := s.db.Create(session).Error; err != nil {
		return nil, fmt.Errorf("failed to create session: %w", err)
	}

	s.logger.Info("session.started",
		zap.String("session_id", session.ID),
		zap.String("user", username),
		zap.String("resource", resource.Name),
		zap.String("type", resource.ResourceType),
	)
	return session, nil
}

// EndSession marks a session as completed.
//
// BUGFIX: duration_seconds was previously computed as
//
//	int(now.Sub(time.Time{}).Seconds())
//
// which measures from the Go zero time (year 1) and stores ~6.4e10 seconds
// on every row. It is now derived in SQL from started_at, which is also
// race-free (no read-modify-write round trip).
func (s *ResourceService) EndSession(sessionID string) error {
	now := time.Now().UTC()
	return s.db.Model(&models.ConnectionSession{}).
		Where("id = ? AND status = 'ACTIVE'", sessionID).
		Updates(map[string]interface{}{
			"status":           "COMPLETED",
			"ended_at":         now,
			"duration_seconds": gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
		}).Error
}

// ListActiveSessions returns all currently-active sessions (for admin monitoring).
func (s *ResourceService) ListActiveSessions() ([]models.ConnectionSession, error) {
	var sessions []models.ConnectionSession
	err := s.db.Where("status = 'ACTIVE'").Order("started_at DESC").Find(&sessions).Error
	return sessions, err
}

// KillSession terminates a session (admin action).
//
// For sessions opened through the in-browser terminal gateway
// (internal/gateway), this force-closes the live socket via KillLiveSession —
// real, physical termination, not just a database status flip.
//
// For sessions opened through the NATIVE AGENT it used to be a status flip and
// nothing more: the row said KILLED while the operator's psql carried on,
// because PAM is not in that data path and had no way to reach a process on
// someone else's machine. It now stamps terminate_requested_at, which the
// agent collects on its next heartbeat (see agent_heartbeat.go) and acts on by
// killing the child process. The gap between the click and the tool closing is
// one heartbeat interval rather than forever.
func (s *ResourceService) KillSession(sessionID, killedBy, reason string) error {
	now := time.Now().UTC()
	err := s.db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.ConnectionSession{}).
			Where("id = ? AND status = 'ACTIVE'", sessionID).
			Updates(map[string]interface{}{
				"status":   "KILLED",
				"ended_at": now,
				// The instruction the agent will collect. Recorded even though
				// the status already says KILLED, because the two answer
				// different questions: the status is what the audit trail
				// says happened, this is what the agent still has to do about
				// it, and a reaper or a report must be able to tell a session
				// that was asked to stop from one that simply ended.
				"terminate_requested_at": now,
				"kill_reason":            reason,
				"killed_by":              killedBy,
				"duration_seconds":       gorm.Expr("GREATEST(0, EXTRACT(EPOCH FROM (? - started_at))::int)", now),
			}).Error; err != nil {
			return err
		}
		// Stamps the recording obligation's ended_at the same way
		// EndTrackedSession/KillSessionsByGrantTx do — without this, a
		// recording killed via this admin action would never get an
		// ended_at at all (see ReconcileOrphanedRecordings' doc comment for
		// why that matters beyond cosmetics). Status is deliberately left
		// alone here for the same reason closeRecordingTx never touches it:
		// gateway.go's finalizeRecording (still running, if this session was
		// opened via the browser terminal) is the only place that should
		// ever mark COMPLETED/FAILED, once the artifact's fate is known.
		return closeRecordingTx(tx, sessionID, now)
	})
	if err != nil {
		return err
	}
	s.KillLiveSession(sessionID)
	return nil
}

// ──────────────────────────────────────────────────────────────────────────
// CONNECTION BROKER — builds the connection details for a resource
// ──────────────────────────────────────────────────────────────────────────

// ConnectionInfo holds everything needed to connect to a resource.
// This is returned to the WebSocket handler which uses it to open the connection.
type ConnectionInfo struct {
	ResourceID   string                 `json:"resource_id"`
	ResourceName string                 `json:"resource_name"`
	ResourceType string                 `json:"resource_type"`
	Host         string                 `json:"host"`
	Port         int                    `json:"port"`
	DatabaseName string                 `json:"database_name,omitempty"`
	AccountName  string                 `json:"account"`
	Password     string                 `json:"-"` // NEVER serialized to JSON
	ExtraConfig  map[string]interface{} `json:"extra_config,omitempty"`
	ConsoleURL   string                 `json:"console_url,omitempty"`
	ConnectMode  string                 `json:"connect_mode"`
}

// ErrNoCredentialConfigured means the resource has no vaulted credential to
// inject — nothing is broken, an administrator has not finished setting it
// up. Its own error because the alternative is what happened before:
// resolve returned a bare error, the launch endpoint's default branch
// turned it into 500 "Failed to resolve launch", and the operator got an
// unactionable server error for a configuration gap. The agent then repeats
// that to them in a terminal, and the actual sentence — "no credential
// configured for resource X" — was only ever in the server's own log.
var ErrNoCredentialConfigured = errors.New("no credential is configured for this resource")

// ResolveConnection retrieves all info needed to connect to a resource,
// including the decrypted credential. Called by the WebSocket handler.
// The plaintext password is in-memory only — never logged or returned to the client.
func (s *ResourceService) ResolveConnection(resourceID string) (*ConnectionInfo, error) {
	resource, err := s.GetResource(resourceID)
	if err != nil {
		return nil, err
	}

	accountName, password, err := s.GetDecryptedCredential(resourceID)
	if err != nil {
		// Wrapped so the sentinel survives errors.Is through every caller,
		// while the message still names the resource and keeps the
		// underlying cause for the log.
		return nil, fmt.Errorf("%w: resource '%s' (%v)", ErrNoCredentialConfigured, resource.Name, err)
	}

	// BUGFIX: this used to call json.Unmarshal and silently discard any
	// error, leaving extraConfig nil on a malformed stored value. For a
	// connector like MinIO/S3 that reads security-relevant fields out of
	// this map (use_ssl, region) with no independent signal of its own, a
	// silently-empty map reads as "use defaults" instead of "this resource's
	// config is broken" — which can downgrade a connection (e.g. an intended
	// TLS endpoint silently dialed over plaintext) instead of failing loud.
	// resource_handler.go's Create/Update already reject invalid JSON before
	// a row is ever saved, so a parse failure here means the stored value
	// was corrupted after the fact — surface it as a hard error rather than
	// connecting with an incomplete/wrong configuration.
	var extraConfig map[string]interface{}
	if resource.ExtraConfig != "" {
		if err := json.Unmarshal([]byte(resource.ExtraConfig), &extraConfig); err != nil {
			return nil, fmt.Errorf("resource '%s' has a corrupted extra_config: %w", resource.Name, err)
		}
	}

	return &ConnectionInfo{
		ResourceID:   resource.ID,
		ResourceName: resource.Name,
		ResourceType: resource.ResourceType,
		Host:         resource.Host,
		Port:         resource.Port,
		DatabaseName: resource.DatabaseName,
		AccountName:  accountName,
		Password:     password,
		ExtraConfig:  extraConfig,
		ConsoleURL:   resource.ConsoleURL,
		ConnectMode:  resource.ConnectMode,
	}, nil
}
