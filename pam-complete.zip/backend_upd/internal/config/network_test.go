package config

import "testing"

// "none" means trust nothing, which gin spells as a nil slice.
func TestTrustedProxyParsing(t *testing.T) {
	cases := []struct {
		in   string
		want []string
	}{
		{"none", nil},
		{"NONE", nil},
		{"  ", nil},
		{"10.0.0.0/8", []string{"10.0.0.0/8"}},
		{"10.0.0.0/8, 172.16.0.0/12", []string{"10.0.0.0/8", "172.16.0.0/12"}},
		{"10.0.0.0/8\n172.16.0.0/12", []string{"10.0.0.0/8", "172.16.0.0/12"}},
	}
	for _, tc := range cases {
		got := NetworkConfig{TrustedProxies: tc.in}.TrustedProxyCIDRs()
		if len(got) != len(tc.want) {
			t.Fatalf("%q -> %v, want %v", tc.in, got, tc.want)
		}
		for i := range got {
			if got[i] != tc.want[i] {
				t.Fatalf("%q -> %v, want %v", tc.in, got, tc.want)
			}
		}
	}
}
