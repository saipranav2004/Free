// pam/internal/middleware/cors.go
//
// CORS for PAM's API hosts.
//
// WHY THIS IS A PACKAGE AND NOT A CLOSURE IN main.go. It used to be an
// anonymous function inline in the route wiring, which meant it could not be
// tested, which meant it was not. It then shipped a bug that took down JIT
// request creation for every cross-origin console: the allow-list named the
// headers someone thought of at the time, the console also sends
// Idempotency-Key on POST /jit/requests, and the preflight refused it. The
// symptom in the browser was a bare "blocked by CORS policy" with no mention
// of the setting responsible.
//
// It is here so cors_test.go can hold that case, and every future one, against
// the real middleware rather than against a description of it.
//
// ── WHY A WILDCARD ORIGIN IS THE DEFAULT, AND WHY THAT IS NOT RECKLESS ──────
//
// PAM's API authenticates with a Bearer token the console keeps in
// sessionStorage. It does NOT use cookie authentication: nothing in the
// console sets withCredentials, and this middleware never sends
// Access-Control-Allow-Credentials.
//
// That combination is what makes "*" safe here. The danger of a wildcard
// origin is a foreign page riding a session the browser attaches
// automatically — which requires cookies. With Bearer auth there is nothing to
// ride: sessionStorage is origin-scoped, so a malicious page cannot read the
// token, and without the token it can only make the unauthenticated calls it
// could already make from a server. The browser also refuses "*" together with
// Allow-Credentials, so the unsafe combination cannot be reached by accident.
//
// The one thing that WOULD change this: if PAM ever moves API authentication
// to cookies, this must become an explicit origin allow-list on the same
// change. Set PAM_SERVER_ALLOWED_ORIGINS to a specific origin and this file
// already does the right thing (including Vary: Origin).
package middleware

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"strings"
)

// baselineAllowHeaders is what PAM always accepts, whether or not a preflight
// asked for it.
//
// Authorization is named EXPLICITLY and that is not redundant next to a
// wildcard: per the Fetch standard "*" matches every header EXCEPT
// Authorization, which must be listed by name or the preflight fails. Every
// browser implements this. The failure mode is deceptive — an unauthenticated
// cross-origin POST (login) succeeds, then every authenticated call after it
// dies in preflight, so the console appears to log in and then break.
//
// Idempotency-Key is named because it is load-bearing, not incidental:
// jit_handler.go honours it so a retried JIT request cannot create a second
// grant.
const baselineAllowHeaders = "Authorization, Content-Type, Accept, Origin, X-Requested-With, Idempotency-Key"

// exposeHeaders are the RESPONSE headers a cross-origin caller may read.
//
// This is the mirror image of the Idempotency-Key bug and bites just as
// quietly. Cross-origin, a browser hides every response header except a short
// safelist (Cache-Control, Content-Language, Content-Length, Content-Type,
// Expires, Last-Modified, Pragma) unless the server names it here.
//
// Content-Disposition is the one that matters: the audit report download reads
// it to recover the server's filename (see the console's api/audit.js). Without
// this the export still downloads but silently loses its name and falls back to
// a generic one — a bug nobody reports as a CORS problem because nothing fails.
const exposeHeaders = "Content-Disposition, Content-Length, X-Request-Id"

// allMethods is deliberately everything PAM routes plus HEAD and OPTIONS, so a
// preflight never fails on a verb this API genuinely serves.
const allMethods = "GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS"

// pamAPIPath reports whether p belongs to PAM's own API surface rather than to
// a brokered third-party application. These are the paths this process serves
// on every hostname (gin matches method+path, not Host), so they must keep
// their CORS headers even on a host the webproxy has misclassified as a
// brokered app — see the CORS doc comment. Kept in sync with the route prefixes
// registered in cmd/pam-api/main.go; the dev-only /test/ login shim is
// deliberately excluded (it only exists in non-production and never on a
// proxy-matching host).
func pamAPIPath(p string) bool {
	return p == "/api/health" || strings.HasPrefix(p, "/api/v1/")

}

// CORS answers preflights and stamps the response headers on API hosts.
//
// allowedOrigins is sent verbatim as Access-Control-Allow-Origin. Empty is
// treated as "*", so a deployment that forgets the variable gets a working
// console rather than a browser-side failure that looks like an outage.
//
// isProxyHost identifies a brokered web-application host. Those responses
// belong to a third-party application and are left strictly alone: stamping
// PAM's permissive CORS headers onto them would both corrupt that app's own
// CORS contract and hand every other origin read access to a privileged,
// already-authenticated session. This exclusion is a security control, not a
// convenience, and must not be removed to "fix CORS" — the console never talks
// to those hosts.
//
// The one carve-out is PAM's own API namespace (see pamAPIPath). Gin routes on
// method+path and never on Host, so /api/health and /api/v1/... are served by
// THIS process on every hostname — including one the webproxy misclassifies as
// a brokered app because PAM_WEBPROXY_BASE_DOMAIN was set broader than the API's
// own host (e.g. base domain "adapid.link" while the API answers on
// "dashboard-dev.adapid.link", so IsProxyHost sees the label "dashboard-dev").
// Without the carve-out every /api/ request on that host — the console's login
// preflight included — loses its Access-Control-Allow-Origin header and its
// OPTIONS is answered by the proxy's "not signed in" page, surfacing in the
// browser as a bare CORS error that names nothing. The carve-out is safe: this
// file's header explains why "*" is not reckless for PAM's Bearer-token API,
// and third-party brokered-app paths (served at the host root, never under
// /api/v1/) are still left untouched.
func CORS(allowedOrigins string, isProxyHost func(host string) bool) gin.HandlerFunc {

	origin := allowedOrigins
	if origin == "" {

		origin = "*"

	}
	return func(c *gin.Context) {
		if isProxyHost != nil && isProxyHost(c.Request.Host) && !pamAPIPath(c.Request.URL.Path) {

			c.Next()
			return

		}

		c.Header("Access-Control-Allow-Origin", origin)

		c.Header("Access-Control-Allow-Methods", allMethods)

		c.Header("Access-Control-Expose-Headers", exposeHeaders)
		// The baseline, plus whatever this preflight actually asked for.
		//
		// Echoing is the fix for the class of bug in this file's header — a
		// fixed list breaks silently, in production, the first time the console
		// sends a header nobody enumerated.
		//
		// It is safe because Allow-Headers is NOT the security boundary.
		// Access-Control-Allow-Origin is: a foreign origin is refused whatever
		// headers it names, and an allowed origin gains nothing by naming a
		// header the browser was already going to send on its behalf. This is
		// exactly what mainstream CORS middleware does for AllowedHeaders:["*"].

		allowHeaders := baselineAllowHeaders
		if requested := c.GetHeader("Access-Control-Request-Headers"); requested != "" {

			allowHeaders = allowHeaders + ", " + requested

		}

		c.Header("Access-Control-Allow-Headers", allowHeaders)
		// Without this the preflight repeats before nearly every request
		// (Chrome caches an un-aged preflight for ~5 seconds), which roughly
		// doubles the request count on a console that is already chatty. Ten
		// minutes is short enough that a CORS change is picked up promptly
		// after a deploy.

		c.Header("Access-Control-Max-Age", "600")
		// Deliberately NO Access-Control-Allow-Credentials. It is invalid
		// alongside "*", PAM's API does not use cookie auth, and setting it
		// would be the one change that makes a wildcard origin genuinely
		// dangerous. See this file's header.
		// The response varies by Origin whenever the allow-list is anything
		// other than "*", so any cache in front of PAM must key on it —
		// otherwise a shared cache can serve one origin's allow header to
		// another.
		if origin != "*" {

			c.Header("Vary", "Origin")

		}
		if c.Request.Method == http.MethodOptions {

			c.AbortWithStatus(http.StatusNoContent)
			return

		}

		c.Next()

	}

}
