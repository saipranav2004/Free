// pam/internal/middleware/audit_redact.go
//
// KEEPING SECRETS OUT OF THE AUDIT TRAIL.
//
// AuditMiddleware records the request body so an auditor can see what was
// asked for. On every route but one that is exactly right, and on the vault
// routes it defeated the vault: storing a credential wrote
//
//	{"name":"prod-db","secret_plaintext":"S3cret-Vault-Check!", …}
//
// into pam_audit_log.details, in cleartext, beside the row whose whole
// purpose is that the same value is sealed with a KMS-wrapped data key. Found
// by storing a credential through the API and then grepping the audit table
// for the plaintext — it was there.
//
// Two things make it worse than an ordinary leak. The audit log is read by
// people who are deliberately NOT secret-holders — compliance, a SOC analyst,
// anyone with the audit role — so it widens who can see every secret ever
// stored. And it is append-only and hash-chained on purpose, so the value
// cannot be quietly scrubbed afterwards without breaking the chain that makes
// it evidence.
//
// The fix is to redact by KEY on the way in. Not by pattern-matching values:
// a secret is any string at all, so there is nothing about "S3cret-Vault-
// Check!" that distinguishes it from a description. What is knowable is the
// field it arrived in.
package middleware

import (
	"encoding/json"
	"strings"
)

// redactedMarker is what replaces a secret. Deliberately visible: an auditor
// should see that a field was present and withheld, not that it was absent.
const redactedMarker = "[redacted]"

// sensitiveKeys are the request fields that carry a secret. Matched
// case-insensitively, and as a SUBSTRING of the key, so "secret_plaintext",
// "new_secret", "aws_secret_key" and "secretPlaintext" are all caught by
// "secret".
//
// Deliberately generous. Over-redacting costs an auditor one field of context
// they can get from the resource itself; under-redacting puts a live
// credential in a table that is designed never to be edited.
var sensitiveKeys = []string{
	"secret", "password", "passwd", "plaintext", "passphrase",
	"private_key", "privatekey", "token", "credential",
	"access_key", "accesskey", "api_key", "apikey",
	"client_secret", "ssh_key", "sshkey", "pem", "otp", "mfa_code",
}

// metadataSuffixes name the FIELD rather than carry its value, so a key
// ending in one of these is describing a secret, not containing it.
//
// Without this the generous substring match above blinds the auditor to the
// very things that make a record useful: "credential_type" contains
// "credential" and so came back as "[redacted]", hiding whether a password or
// an SSH key was stored. "secret_id", "token_count" and "password_updated_at"
// are the same shape. The value of a secret never lives in a field called
// _type, _id, _name or _count.
var metadataSuffixes = []string{
	"_type", "_id", "_ids", "_name", "_names", "_count", "_at",
	"_ttl", "_expires", "_expires_at", "_length", "_version", "_status",
}

func isSensitiveKey(key string) bool {
	k := strings.ToLower(key)
	for _, suffix := range metadataSuffixes {
		if strings.HasSuffix(k, suffix) {
			return false
		}
	}
	for _, s := range sensitiveKeys {
		if strings.Contains(k, s) {
			return true
		}
	}
	return false
}

// redactAuditBody returns the body with every sensitive field replaced.
//
// A body that is not JSON cannot be walked by key, and a form-encoded or raw
// body on a route that carries credentials is exactly where one would hide,
// so those are withheld entirely rather than guessed at. JSON that parses is
// re-serialised, which also normalises it for the reader.
func redactAuditBody(body []byte, path string) string {
	if len(body) == 0 {
		return ""
	}

	var parsed interface{}
	if err := json.Unmarshal(body, &parsed); err != nil {
		if routeCarriesSecrets(path) {
			return "[omitted: unparseable body on a credential route]"
		}
		return string(body)
	}

	cleaned := redactValue(parsed)
	out, err := json.Marshal(cleaned)
	if err != nil {
		// Marshalling what we just unmarshalled should not fail; if it
		// somehow does, withhold rather than fall back to the raw body.
		return "[omitted: body could not be re-encoded for audit]"
	}
	return string(out)
}

// redactValue walks maps and arrays. Nested objects matter: a credential can
// arrive inside a wrapper object, and a rotation request carries the old and
// the new value side by side.
func redactValue(v interface{}) interface{} {
	switch t := v.(type) {
	case map[string]interface{}:
		out := make(map[string]interface{}, len(t))
		for k, val := range t {
			if isSensitiveKey(k) {
				// Only strings are replaced with the marker; a nested object
				// under a sensitive key is walked so its shape survives while
				// its leaves do not.
				if _, isString := val.(string); isString {
					out[k] = redactedMarker
					continue
				}
				out[k] = redactValue(val)
				continue
			}
			out[k] = redactValue(val)
		}
		return out
	case []interface{}:
		out := make([]interface{}, len(t))
		for i, val := range t {
			out[i] = redactValue(val)
		}
		return out
	default:
		return v
	}
}

// routeCarriesSecrets marks the paths where an unparseable body must not be
// stored verbatim.
func routeCarriesSecrets(path string) bool {
	p := strings.ToLower(path)
	for _, marker := range []string{"/credential", "/secret", "/vault", "/rotate", "/auth/", "/token"} {
		if strings.Contains(p, marker) {
			return true
		}
	}
	return false
}
