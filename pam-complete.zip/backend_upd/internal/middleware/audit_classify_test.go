package middleware

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
)

func classifyPath(method, path string) string {
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(method, path, nil)
	_, action := classify(c)
	return action
}

// A REVEAL IS NOT A STORE.
//
// Every path containing "/credential" returned "pam:vault:Store", whatever
// the method and whatever the sub-path — so an operator taking possession of
// a secret was recorded as having written one. Not missing, which somebody
// eventually notices: present and wrong, which nobody does.
func TestRevealingACredentialIsAuditedAsAReveal(t *testing.T) {
	for _, path := range []string{
		"/api/v1/pam/credentials/abc-123/reveal",
		"/api/v1/pam/credentials/abc-123/checkout",
	} {
		if got := classifyPath(http.MethodPost, path); got != "pam:vault:Reveal" {
			t.Errorf("%s classified as %q, want pam:vault:Reveal", path, got)
		}
	}
}

// And rotation had a second, quieter version of the same fault: the "/rotate"
// branch sat AFTER the "/credential" one, so the route that actually rotates
// could never reach it.
func TestRotatingACredentialIsAuditedAsARotation(t *testing.T) {
	if got := classifyPath(http.MethodPost, "/api/v1/pam/credentials/abc-123/rotate"); got != "pam:vault:Rotate" {
		t.Errorf("rotate classified as %q, want pam:vault:Rotate", got)
	}
}

// The rest of the vault surface, by method, so a read is not filed as a write.
func TestTheVaultActionMatchesTheMethod(t *testing.T) {
	cases := []struct{ method, path, want string }{
		{http.MethodPost, "/api/v1/pam/safes/s1/credentials", "pam:vault:Store"},
		{http.MethodGet, "/api/v1/pam/safes/s1/credentials", "pam:vault:Read"},
		{http.MethodGet, "/api/v1/pam/credentials/abc-123", "pam:vault:Read"},
		{http.MethodPut, "/api/v1/pam/credentials/abc-123", "pam:vault:Update"},
		{http.MethodPatch, "/api/v1/pam/credentials/abc-123", "pam:vault:Update"},
		{http.MethodDelete, "/api/v1/pam/credentials/abc-123", "pam:vault:Delete"},
	}
	for _, c := range cases {
		if got := classifyPath(c.method, c.path); got != c.want {
			t.Errorf("%s %s classified as %q, want %q", c.method, c.path, got, c.want)
		}
	}
}

// A GET that returns only metadata must not read as a Reveal either — the
// distinction the whole audit trail turns on is "did a human see the secret".
func TestListingCredentialsIsNotAReveal(t *testing.T) {
	if got := classifyPath(http.MethodGet, "/api/v1/pam/safes/s1/credentials"); got == "pam:vault:Reveal" {
		t.Error("listing credential metadata must not be recorded as revealing a secret")
	}
}
