// pam/internal/middleware/service_auth.go
//
// PEP for the vault's machine data plane.
//
// This must be mounted on its OWN route group. Chaining it after PAMAuth on
// the human group makes every endpoint in that group demand a user JWT AND a
// service token simultaneously, which 401s all human traffic — the two are
// alternative authentication schemes for two different planes, not layers.
package middleware

import (
	"errors"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// Context keys set on success. Handlers read these, never the raw token.
const (
	CtxServicePrincipal = "service_principal"
	CtxServiceID        = "service_id"
	CtxServiceName      = "service_name"
	CtxServiceTokenID   = "service_token_id"
)

// ServiceAuth authenticates a machine caller and applies its read budget.
//
// The token is accepted from `X-Service-Token` or `Authorization: Bearer`.
// Everything expensive (hashing, DB lookup) happens inside the service layer,
// which caches resolved principals for ~30s — so at steady state this
// middleware costs a map lookup and a token-bucket decrement.
func ServiceAuth(identity *services.ServiceIdentityService, audit *services.AuditService, logger *zap.Logger) gin.HandlerFunc {
	// One auditor per mount, so its coalescing state is shared across the
	// whole machine plane rather than per route.
	var auditor *serviceAuthAuditor
	if audit != nil {
		auditor = newServiceAuthAuditor(audit)
	}

	return func(c *gin.Context) {
		token := extractServiceToken(c)
		if token == "" {
			// WWW-Authenticate so a misconfigured client gets a usable hint
			// without us echoing anything about which tokens exist.
			c.Header("WWW-Authenticate", `Bearer realm="pam-vault", error="invalid_request"`)
			auditor.record(c.Request.Context(),
				"auth|"+c.ClientIP()+"|",
				authFailureEntry(reasonMissingToken, c.Request.URL.Path,
					c.ClientIP(), c.Request.UserAgent(), ""))
			response.Error(c, http.StatusUnauthorized, "Service token required")
			c.Abort()
			return
		}

		principal, err := identity.Authenticate(c.Request.Context(), token)
		if err != nil {
			// One indistinguishable answer for malformed / unknown / expired /
			// revoked / wrong-secret. Anything more specific turns this into a
			// token-enumeration oracle.
			status := http.StatusUnauthorized
			msg := "Invalid or expired service token"
			if errors.Is(err, services.ErrServiceDisabled) {
				status, msg = http.StatusForbidden, "Service identity is disabled"
			} else if !errors.Is(err, services.ErrTokenInvalid) && !errors.Is(err, services.ErrTokenMalformed) {
				// Genuine infrastructure failure — fail closed, but say so, so
				// it is distinguishable in monitoring from a credential problem.
				logger.Error("service_auth.backend_error", zap.Error(err))
				status, msg = http.StatusServiceUnavailable, "Service authentication temporarily unavailable"
			}
			logger.Warn("service_auth.denied",
				zap.String("path", c.Request.URL.Path),
				zap.String("source_ip", c.ClientIP()),
				zap.Error(err),
			)
			// The zap line above is operator telemetry; this is the evidence.
			// Coalesced per (source, claimed token) so a guessing run writes a
			// steady trickle of rows rather than one per attempt.
			claimed := claimedTokenID(token)
			auditor.record(c.Request.Context(),
				"auth|"+c.ClientIP()+"|"+claimed,
				authFailureEntry(classifyAuthFailure(err), c.Request.URL.Path,
					c.ClientIP(), c.Request.UserAgent(), claimed))
			response.Error(c, status, msg)
			c.Abort()
			return
		}

		// Rate limit per identity. A leaked token is contained by how fast it
		// can drain the vault, so this is a security control and belongs in
		// front of the handler, not in it.
		if !identity.AllowRead(principal, 1) {
			logger.Warn("service_auth.rate_limited",
				zap.String("service", principal.ServiceName),
				zap.String("token_id", principal.TokenID),
				zap.String("source_ip", c.ClientIP()),
			)
			auditor.record(c.Request.Context(),
				"rate|"+principal.ServiceID+"|"+principal.TokenID,
				rateLimitEntry(principal, c.Request.URL.Path,
					c.ClientIP(), c.Request.UserAgent()))
			c.Header("Retry-After", "1")
			response.Error(c, http.StatusTooManyRequests, "Secret read rate limit exceeded")
			c.Abort()
			return
		}

		identity.TouchToken(principal.TokenID, c.ClientIP())

		c.Set(CtxServicePrincipal, principal)
		c.Set(CtxServiceID, principal.ServiceID)
		c.Set(CtxServiceName, principal.ServiceName)
		c.Set(CtxServiceTokenID, principal.TokenID)
		c.Next()
	}
}

// ServicePrincipalFrom retrieves the authenticated machine caller.
func ServicePrincipalFrom(c *gin.Context) (*services.ServicePrincipal, bool) {
	v, ok := c.Get(CtxServicePrincipal)
	if !ok {
		return nil, false
	}
	p, ok := v.(*services.ServicePrincipal)
	return p, ok
}

func extractServiceToken(c *gin.Context) string {
	if t := strings.TrimSpace(c.GetHeader("X-Service-Token")); t != "" {
		return t
	}
	auth := strings.TrimSpace(c.GetHeader("Authorization"))
	if auth == "" {
		return ""
	}
	// Only strip a real "Bearer " prefix. The previous version called
	// TrimPrefix unconditionally, so a raw `Authorization: <token>` and a
	// `Bearer <token>` were both accepted — harmless, but it also meant a
	// Basic-auth header was passed through to the token lookup verbatim.
	if len(auth) >= 7 && strings.EqualFold(auth[:7], "bearer ") {
		return strings.TrimSpace(auth[7:])
	}
	return ""
}

// claimedTokenID pulls the public id out of a presented wire token
// (pamsvc.<id>.<secret>) for the audit record, so a guessing run can be told
// apart from one decommissioned client retrying the same dead token.
//
// The id half is not a secret — it is the database lookup key, and it is
// returned to the admin who minted it. The third segment is, so it never
// leaves this function. The value is attacker-controlled on a malformed token,
// hence bounded in length and restricted to the alphabet a real id uses;
// anything else is reported as absent rather than stored.
func claimedTokenID(presented string) string {
	parts := strings.Split(strings.TrimSpace(presented), ".")
	if len(parts) != 3 || parts[0] != "pamsvc" {
		return ""
	}
	id := parts[1]
	if id == "" || len(id) > 64 {
		return ""
	}
	for _, r := range id {
		if !(r >= '0' && r <= '9' || r >= 'a' && r <= 'f' || r >= 'A' && r <= 'F' || r == '-') {
			return ""
		}
	}
	return id
}
