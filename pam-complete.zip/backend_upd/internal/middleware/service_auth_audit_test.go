package middleware

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
)

// recordingAppender stands in for AuditService so these tests exercise the
// coalescing rules without a database and its hash chain.
type recordingAppender struct {
	mu      sync.Mutex
	entries []services.AuditEntry
}

func (r *recordingAppender) Append(_ context.Context, e services.AuditEntry) (*models.AuditLog, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.entries = append(r.entries, e)
	return &models.AuditLog{}, nil
}

func (r *recordingAppender) all() []services.AuditEntry {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]services.AuditEntry, len(r.entries))
	copy(out, r.entries)
	return out
}

func (r *recordingAppender) wait(t *testing.T, want int) []services.AuditEntry {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if got := r.all(); len(got) >= want {
			return got
		}
		time.Sleep(5 * time.Millisecond)
	}
	got := r.all()
	if len(got) != want {
		t.Fatalf("wanted %d audit rows, got %d", want, len(got))
	}
	return got
}

func TestRefusalsCoalescePerSubjectWithinTheWindow(t *testing.T) {
	a := newServiceAuthAuditor(&recordingAppender{})
	now := time.Now()

	if rec, sup := a.admit("auth|10.0.0.1|abc", now); !rec || sup != 0 {
		t.Fatalf("first refusal must be recorded immediately, got record=%v suppressed=%d", rec, sup)
	}
	for i := 0; i < 500; i++ {
		if rec, _ := a.admit("auth|10.0.0.1|abc", now.Add(time.Duration(i)*time.Millisecond)); rec {
			t.Fatalf("refusal %d inside the window should have been suppressed", i)
		}
	}

	// The next window reports how many were swallowed, so the volume of the
	// attack is still in the trail even though the rows are not.
	rec, sup := a.admit("auth|10.0.0.1|abc", now.Add(serviceAuditWindow+time.Second))
	if !rec {
		t.Fatal("a refusal after the window must be recorded")
	}
	if sup != 500 {
		t.Fatalf("suppressed count = %d, want 500", sup)
	}
}

func TestDifferentSubjectsDoNotSuppressEachOther(t *testing.T) {
	a := newServiceAuthAuditor(&recordingAppender{})
	now := time.Now()

	for _, key := range []string{"auth|10.0.0.1|abc", "auth|10.0.0.2|abc", "auth|10.0.0.1|def", "rate|svc-1|tok-1"} {
		if rec, _ := a.admit(key, now); !rec {
			t.Fatalf("first refusal for %q must be recorded", key)
		}
	}
}

func TestOverflowBucketBoundsTheRowRateUnderADistributedFlood(t *testing.T) {
	a := newServiceAuthAuditor(&recordingAppender{})
	now := time.Now()

	recorded := 0
	for i := 0; i < serviceAuditMaxSubjects*3; i++ {
		if rec, _ := a.admit(fmt.Sprintf("auth|10.0.%d.%d|x", i/256, i%256), now); rec {
			recorded++
		}
	}
	// Every distinct subject up to the cap gets its own row; everything past
	// it collapses into one, so the worst case stays bounded.
	if recorded != serviceAuditMaxSubjects+1 {
		t.Fatalf("recorded %d rows under a flood of %d subjects, want %d",
			recorded, serviceAuditMaxSubjects*3, serviceAuditMaxSubjects+1)
	}
}

func TestIdleSubjectsArePrunedSoTheMapDoesNotGrowForever(t *testing.T) {
	a := newServiceAuthAuditor(&recordingAppender{})
	now := time.Now()

	for i := 0; i < 100; i++ {
		a.admit(fmt.Sprintf("auth|10.0.0.%d|x", i), now)
	}
	if len(a.buckets) != 100 {
		t.Fatalf("buckets = %d, want 100", len(a.buckets))
	}
	// One live subject a window later; the 100 quiet ones go away.
	a.admit("auth|10.1.1.1|x", now.Add(serviceAuditWindow+time.Second))
	if len(a.buckets) != 1 {
		t.Fatalf("buckets after pruning = %d, want 1", len(a.buckets))
	}
}

func TestASuppressedSubjectIsNotPrunedAndKeepsItsCount(t *testing.T) {
	a := newServiceAuthAuditor(&recordingAppender{})
	now := time.Now()

	a.admit("auth|10.0.0.1|abc", now)
	a.admit("auth|10.0.0.1|abc", now) // suppressed: count is 1

	// Pruning runs on every admit. A subject that is still accumulating
	// suppressed events must survive it, otherwise the count resets and the
	// next row under-reports the attack.
	a.admit("auth|10.9.9.9|other", now.Add(serviceAuditWindow+time.Second))

	rec, sup := a.admit("auth|10.0.0.1|abc", now.Add(serviceAuditWindow+2*time.Second))
	if !rec || sup != 1 {
		t.Fatalf("record=%v suppressed=%d, want true/1 — the pending count was lost", rec, sup)
	}
}

func TestRecordWritesTheEntryWithItsSuppressedCount(t *testing.T) {
	app := &recordingAppender{}
	a := newServiceAuthAuditor(app)

	entry := authFailureEntry(reasonInvalidToken, "/api/v1/pam/svc/secrets/x", "10.0.0.1", "curl/8", "abc123")
	a.record(context.Background(), "auth|10.0.0.1|abc123", entry)

	got := app.wait(t, 1)[0]
	if got.Action != "pam.service.auth_denied" || got.Outcome != models.OutcomeDenied {
		t.Fatalf("action=%q outcome=%q", got.Action, got.Outcome)
	}
	d := got.Details.(map[string]any)
	if d["suppressed_since_last"] != 0 {
		t.Fatalf("suppressed_since_last = %v, want 0", d["suppressed_since_last"])
	}
	if d["reason"] != reasonInvalidToken || d["claimed_token_id"] != "abc123" {
		t.Fatalf("details = %v", d)
	}
}

func TestANilAuditorIsAWorkingNoOp(t *testing.T) {
	// ServiceAuth leaves the auditor nil when no audit service is wired (the
	// unit-test rigs do this), so every call site must tolerate it.
	var a *serviceAuthAuditor
	a.record(context.Background(), "auth|x|y", authFailureEntry(reasonMalformed, "/p", "1.2.3.4", "", ""))
}

func TestAuthFailuresAreClassifiedNotEchoed(t *testing.T) {
	cases := []struct {
		err  error
		want string
	}{
		{services.ErrTokenMalformed, reasonMalformed},
		{services.ErrTokenInvalid, reasonInvalidToken},
		{services.ErrServiceDisabled, reasonDisabled},
		{fmt.Errorf("wrapped: %w", services.ErrTokenInvalid), reasonInvalidToken},
		// A database error can carry the DSN in its text. It must never reach
		// an append-only table, so anything unrecognised is reported coarsely.
		{errors.New(`dial tcp 10.0.0.9:5432: password authentication failed for user "pam"`), reasonBackend},
	}
	for _, tc := range cases {
		if got := classifyAuthFailure(tc.err); got != tc.want {
			t.Errorf("classify(%v) = %q, want %q", tc.err, got, tc.want)
		}
	}
}

func TestBackendFailureTextNeverReachesTheAuditRow(t *testing.T) {
	secret := `password authentication failed for user "pam"`
	entry := authFailureEntry(classifyAuthFailure(errors.New(secret)), "/p", "1.2.3.4", "", "")
	if strings.Contains(fmt.Sprint(entry.Details), "password") {
		t.Fatalf("audit details leaked the backend error text: %v", entry.Details)
	}
}

func TestClaimedTokenIDTakesTheIDHalfAndNeverTheSecret(t *testing.T) {
	cases := []struct{ in, want string }{
		{"pamsvc.b1bd04db4837d22c.s3cr3tv4lue", "b1bd04db4837d22c"},
		{"  pamsvc.abc123.zzz  ", "abc123"},
		{"pamsvc.abc123", ""},              // not a wire token
		{"eyJhbGciOi.pretend.jwt", ""},     // a user JWT sent to the wrong plane
		{"pamsvc..secret", ""},             // empty id
		{"pamsvc.not-hex-$(rm -rf).x", ""}, // attacker-controlled junk
		{"pamsvc." + strings.Repeat("a", 65) + ".x", ""},
		{"", ""},
	}
	for _, tc := range cases {
		if got := claimedTokenID(tc.in); got != tc.want {
			t.Errorf("claimedTokenID(%q) = %q, want %q", tc.in, got, tc.want)
		}
	}
	// The strongest form of the property: whatever the input, the secret half
	// is never what comes back.
	if got := claimedTokenID("pamsvc.abc123.THE-SECRET"); strings.Contains(got, "SECRET") {
		t.Fatalf("the secret half leaked into the audit record: %q", got)
	}
}

func TestRateLimitRowNamesTheIdentityAndIsCritical(t *testing.T) {
	p := &services.ServicePrincipal{
		ServiceID: "svc-1", ServiceName: "billing-api-prod",
		TokenID: "tok-1", Environment: "production", MaxReadsPerMinute: 30,
	}
	e := rateLimitEntry(p, "/api/v1/pam/svc/secrets/prod-db/x", "10.0.0.5", "go-client/1")

	if e.Action != "pam.service.rate_limited" || e.Outcome != models.OutcomeDenied {
		t.Fatalf("action=%q outcome=%q", e.Action, e.Outcome)
	}
	// A service reading faster than its owner declared is the shape of a
	// leaked token draining the vault — it must not be filed as noise.
	if e.Severity != "CRITICAL" {
		t.Fatalf("severity = %q, want CRITICAL", e.Severity)
	}
	if e.ServiceName != "billing-api-prod" || e.ActorType != "SYSTEM" {
		t.Fatalf("actor = %q/%q", e.ActorType, e.ServiceName)
	}
	d := e.Details.(map[string]any)
	if d["max_reads_per_minute"] != 30 || d["token_id"] != "tok-1" {
		t.Fatalf("details = %v", d)
	}
}

func TestUsingADisabledIdentityIsCriticalNotAWarning(t *testing.T) {
	warn := authFailureEntry(reasonInvalidToken, "/p", "1.2.3.4", "", "")
	if warn.Severity != "WARN" {
		t.Fatalf("an unknown token should be WARN, got %q", warn.Severity)
	}
	crit := authFailureEntry(reasonDisabled, "/p", "1.2.3.4", "", "")
	if crit.Severity != "CRITICAL" {
		t.Fatalf("a disabled identity still in use should be CRITICAL, got %q", crit.Severity)
	}
}
