// pam/internal/middleware/service_auth_audit.go
//
// The machine data plane's refusals, written to the tamper-evident audit trail.
//
// Why this exists: ServiceAuth rejects a request before any handler runs, so
// the handler-side audit in SecretAccessService never sees it. Until this file,
// a rejected machine call produced nothing but a zap line — which meant the two
// events a SOC most wants from a machine credential were invisible to every
// audit view, export and insight card in the product:
//
//   - somebody presenting unknown, expired or revoked service tokens (token
//     guessing, or a decommissioned integration still calling in), and
//   - an identity hitting its read budget, which is exactly the shape of a
//     leaked token being used to drain the vault.
//
// The second is the worse omission. The first five reads of a stolen token are
// audited SUCCESS and everything after the budget trips is silent, so in the
// audit trail the attack looks like the service went quiet — quieter than
// legitimate traffic, not louder.
//
// ── Coalescing ───────────────────────────────────────────────────────────────
//
// The audit log is hash-chained, so its writes serialise. Recording one row per
// rejected request would hand an unauthenticated caller a write amplifier
// pointed at the one table that must not fall over. So refusals are coalesced
// per subject: the first one in a window is recorded immediately, the rest are
// counted and reported on the next record as suppressed_since_last. Nothing is
// lost that an auditor needs — the signal is "this subject is being refused,
// and this is how hard" — and the row rate is bounded by subject count, not by
// request rate.
package middleware

import (
	"context"
	"errors"
	"sync"
	"time"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
)

const (
	// serviceAuditWindow is how long one subject's refusals coalesce into a
	// single audit row. Short enough that a live attack shows as a run of
	// rows rather than one, long enough that a flood cannot outpace the chain.
	serviceAuditWindow = 60 * time.Second

	// serviceAuditMaxSubjects bounds the tracking map. A distributed flood
	// arrives from many source IPs, each of which would otherwise be a new
	// key and a new immediate row; past this many, everything collapses into
	// one overflow bucket so the worst case stays one row per window.
	serviceAuditMaxSubjects = 4096

	serviceAuditOverflowKey = "\x00overflow"
)

// Refusal reasons. Deliberately coarse: the underlying error can wrap a
// database failure whose text carries connection detail, and the audit log is
// append-only, so nothing that has not been classified goes into it.
const (
	reasonMissingToken = "missing_token"
	reasonMalformed    = "malformed_token"
	reasonInvalidToken = "unknown_expired_or_revoked_token"
	reasonDisabled     = "identity_disabled"
	reasonBackend      = "authentication_backend_error"
)

// classifyAuthFailure maps an Authenticate error to a reason that is safe to
// store. Anything unrecognised is reported as a backend error rather than
// echoed, which is both the truthful answer and the safe one.
func classifyAuthFailure(err error) string {
	switch {
	case err == nil:
		return ""
	case errors.Is(err, services.ErrTokenMalformed):
		return reasonMalformed
	case errors.Is(err, services.ErrTokenInvalid):
		return reasonInvalidToken
	case errors.Is(err, services.ErrServiceDisabled):
		return reasonDisabled
	default:
		return reasonBackend
	}
}

// serviceAuthAuditor records refusals, coalesced per subject.
type serviceAuthAuditor struct {
	audit  auditAppender
	window time.Duration

	mu      sync.Mutex
	buckets map[string]*refusalBucket
}

// auditAppender is the slice of AuditService this file needs, named so the
// tests can drive it without a database.
type auditAppender interface {
	Append(ctx context.Context, e services.AuditEntry) (*models.AuditLog, error)
}

type refusalBucket struct {
	lastWrite  time.Time
	suppressed int
}

func newServiceAuthAuditor(audit auditAppender) *serviceAuthAuditor {
	return &serviceAuthAuditor{
		audit:   audit,
		window:  serviceAuditWindow,
		buckets: make(map[string]*refusalBucket),
	}
}

// admit reports whether this refusal should be written now, and how many were
// suppressed since the subject's last written row.
func (a *serviceAuthAuditor) admit(key string, now time.Time) (record bool, suppressed int) {
	a.mu.Lock()
	defer a.mu.Unlock()

	for k, b := range a.buckets {
		if now.Sub(b.lastWrite) >= a.window && b.suppressed == 0 {
			delete(a.buckets, k)
		}
	}

	b, ok := a.buckets[key]
	if !ok {
		if len(a.buckets) >= serviceAuditMaxSubjects {
			key = serviceAuditOverflowKey
			b, ok = a.buckets[key]
		}
		if !ok {
			a.buckets[key] = &refusalBucket{lastWrite: now}
			return true, 0
		}
	}

	if now.Sub(b.lastWrite) >= a.window {
		n := b.suppressed
		b.suppressed = 0
		b.lastWrite = now
		return true, n
	}

	b.suppressed++
	return false, 0
}

// record writes one refusal row, if this subject is not already coalescing.
//
// The write is detached and asynchronous for the same reason the handler-side
// audit is: a caller must not be able to suppress its own audit row by hanging
// up mid-request, and an audit write must never be on the critical path of a
// refusal that has already been decided.
func (a *serviceAuthAuditor) record(ctx context.Context, key string, entry services.AuditEntry) {
	if a == nil || a.audit == nil {
		return
	}
	ok, suppressed := a.admit(key, time.Now())
	if !ok {
		return
	}
	if d, isMap := entry.Details.(map[string]any); isMap {
		d["suppressed_since_last"] = suppressed
	}

	writeCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 3*time.Second)
	go func() {
		defer cancel()
		_, _ = a.audit.Append(writeCtx, entry)
	}()
}

// authFailureEntry builds the row for a rejected credential. The identity is
// unknown by definition — that is what the refusal means — so the row is keyed
// on what is actually known: where it came from and which token id was claimed.
func authFailureEntry(reason, path, sourceIP, userAgent, claimedTokenID string) services.AuditEntry {
	severity := "WARN"
	if reason == reasonDisabled {
		// An identity that was deliberately switched off is still being used.
		// That is not a misconfiguration, it is somebody holding a credential
		// they were supposed to have lost.
		severity = "CRITICAL"
	}
	return services.AuditEntry{
		ActorType: "SYSTEM",
		Action:    "pam.service.auth_denied",
		Outcome:   models.OutcomeDenied,
		Severity:  severity,
		Resource:  "pam:service/unknown",
		SourceIP:  sourceIP,
		UserAgent: userAgent,
		Details: map[string]any{
			"reason":           reason,
			"path":             path,
			"claimed_token_id": claimedTokenID,
		},
	}
}

// rateLimitEntry builds the row for an identity that has spent its budget.
// Here the caller IS authenticated, so the row names it.
func rateLimitEntry(p *services.ServicePrincipal, path, sourceIP, userAgent string) services.AuditEntry {
	return services.AuditEntry{
		UserID:      p.ServiceID,
		Username:    p.ServiceName,
		ServiceName: p.ServiceName,
		ActorType:   "SYSTEM",
		Action:      "pam.service.rate_limited",
		Outcome:     models.OutcomeDenied,
		// CRITICAL, not WARN: a service that reads faster than its owner
		// declared it would is the signature of a leaked token draining the
		// vault, and it is the only warning anyone gets before it succeeds.
		Severity: "CRITICAL",
		Resource: "pam:service/" + p.ServiceName,
		SourceIP: sourceIP,
		Details: map[string]any{
			"token_id":             p.TokenID,
			"path":                 path,
			"max_reads_per_minute": p.MaxReadsPerMinute,
			"environment":          p.Environment,
		},
		UserAgent: userAgent,
	}
}
