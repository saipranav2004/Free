package middleware

import (
	"encoding/json"
	"strings"
	"testing"
)

// THE BUG THIS EXISTS FOR, in one line: the vault sealed the secret with a
// KMS-wrapped data key and the audit middleware wrote the same secret beside
// it in cleartext.
func TestTheStoredSecretNeverReachesTheAuditTrail(t *testing.T) {
	body := []byte(`{"name":"prod-db","account_name":"appuser","secret_plaintext":"S3cret-Vault-Check!","credential_type":"password","description":"the primary"}`)

	got := redactAuditBody(body, "/api/v1/pam/safes/abc/credentials")

	if strings.Contains(got, "S3cret-Vault-Check") {
		t.Fatalf("the plaintext secret is still in the audit details: %s", got)
	}
	if !strings.Contains(got, redactedMarker) {
		t.Errorf("the field should be marked redacted, not dropped: %s", got)
	}
	// The rest is what makes the record useful to an auditor and must survive.
	for _, keep := range []string{"prod-db", "appuser", "the primary"} {
		if !strings.Contains(got, keep) {
			t.Errorf("redaction removed context an auditor needs (%q): %s", keep, got)
		}
	}
}

// Every shape a secret arrives in.
func TestSensitiveFieldsAreRedactedWhateverTheyAreCalled(t *testing.T) {
	body := []byte(`{
      "password":"p1","new_password":"p2","secretPlaintext":"p3",
      "aws_secret_key":"p4","api_key":"p5","private_key":"p6",
      "client_secret":"p7","token":"p8","passphrase":"p9","otp":"123456",
      "username":"keep-me","host":"db.internal"
    }`)

	got := redactAuditBody(body, "/api/v1/pam/credentials")

	for _, secret := range []string{"p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "123456"} {
		if strings.Contains(got, `"`+secret+`"`) {
			t.Errorf("secret %q survived redaction: %s", secret, got)
		}
	}
	if !strings.Contains(got, "keep-me") || !strings.Contains(got, "db.internal") {
		t.Errorf("non-secret fields must survive: %s", got)
	}
}

// A credential can arrive wrapped, and a rotation carries two of them.
func TestNestedAndRepeatedSecretsAreRedacted(t *testing.T) {
	body := []byte(`{"rotation":{"old":{"secret":"old-one"},"new":{"secret":"new-one"}},
	                 "targets":[{"password":"a"},{"password":"b"}]}`)

	got := redactAuditBody(body, "/api/v1/pam/credentials/x/rotate")

	for _, secret := range []string{"old-one", "new-one", `"a"`, `"b"`} {
		if strings.Contains(got, secret) {
			t.Errorf("nested secret %q survived: %s", secret, got)
		}
	}
	// The structure is kept so the record still says what was rotated.
	if !strings.Contains(got, "rotation") || !strings.Contains(got, "targets") {
		t.Errorf("the shape of the request should survive: %s", got)
	}
}

// A body that cannot be walked by key is withheld on a credential route
// rather than stored and hoped about — form-encoded is exactly where a secret
// would hide from a JSON-only redactor.
func TestAnUnparseableBodyOnACredentialRouteIsWithheld(t *testing.T) {
	got := redactAuditBody([]byte("secret_plaintext=S3cret&name=prod"), "/api/v1/pam/safes/x/credentials")
	if strings.Contains(got, "S3cret") {
		t.Fatalf("a non-JSON credential body must not be stored verbatim: %s", got)
	}
	if !strings.Contains(got, "omitted") {
		t.Errorf("the record should say something was withheld: %s", got)
	}

	// On an ordinary route there is nothing to hide and the body is useful.
	if got := redactAuditBody([]byte("page=2&sort=name"), "/api/v1/pam/resources"); got != "page=2&sort=name" {
		t.Errorf("an ordinary body should be kept as-is, got %q", got)
	}
}

func TestAnEmptyBodyStaysEmpty(t *testing.T) {
	if got := redactAuditBody(nil, "/api/v1/pam/credentials"); got != "" {
		t.Errorf("no body means no details, got %q", got)
	}
}

// The output has to remain valid JSON: the console and the evidence export
// both parse this field.
func TestRedactedDetailsAreStillValidJSON(t *testing.T) {
	got := redactAuditBody([]byte(`{"a":{"password":"x"},"b":[1,2,{"token":"y"}]}`), "/api/v1/pam/credentials")
	var out interface{}
	if err := json.Unmarshal([]byte(got), &out); err != nil {
		t.Fatalf("redaction produced invalid JSON (%v): %s", err, got)
	}
}

// Redaction must not blind the auditor to WHAT was stored.
//
// The first version of this redacted "credential_type" — it contains
// "credential" — so the record no longer said whether a password or an SSH
// key had been written, which is exactly the sort of context the audit trail
// is for. A field named after a secret is not a field containing one.
func TestMetadataAboutASecretIsNotRedacted(t *testing.T) {
	body := []byte(`{
      "credential_type":"password","secret_id":"cred-7","token_count":3,
      "password_updated_at":"2026-09-18T00:00:00Z","secret_name":"prod-db",
      "api_key_id":"ak-1","credential_version":2,
      "secret_plaintext":"do-not-log-me","password":"nor-me"
    }`)

	got := redactAuditBody(body, "/api/v1/pam/credentials")

	for _, keep := range []string{"password\":\"nor-me", "do-not-log-me"} {
		if strings.Contains(got, keep) {
			t.Fatalf("an actual secret survived: %s", got)
		}
	}
	for _, keep := range []string{"password", "cred-7", "prod-db", "ak-1"} {
		if !strings.Contains(got, keep) {
			t.Errorf("metadata %q was redacted; an auditor needs it: %s", keep, got)
		}
	}
	// And the values that ARE secrets are still gone.
	if strings.Count(got, redactedMarker) != 2 {
		t.Errorf("expected exactly the two real secrets redacted: %s", got)
	}
}
