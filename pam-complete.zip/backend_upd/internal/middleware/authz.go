// pam/internal/middleware/authz.go
//
// RequirePermission is the PEP (Policy Enforcement Point) middleware.
// It used to call an external IAM service's POST /api/v1/authz/check for
// every privileged PAM action. That dependency is gone: PAM now resolves
// the decision itself, in-process, against its own RBAC/PBAC tables via
// services.PolicyEngineService (internal/services/policy_engine_service.go),
// which in turn evaluates through the embedded rule engine in opa/engine.go.
//
// Same fail-closed posture as before: any resolution error or explicit deny
// aborts the request with 403. The only thing that changed is WHO answers
// the question — there is no more network hop, and therefore no more
// "PDP unreachable" failure mode to fail closed against in the first place.
//
// Usage (unchanged from the IAM-backed version — only the constructed value
// passed as the first argument changed, from an *iamclient.Client to a
// *services.PolicyEngineService):
//
//	vault.GET("",
//	    middleware.RequirePermission(policyEngine, "pam:vault:List",
//	        func(c *gin.Context) string { return "pam:*" }, logger),
//	    vaultHandler.List)
package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

// RequirePermission evaluates the given action and a resource pattern built
// from the request context against the caller's resolved RBAC/PBAC
// policies. Denied or any error aborts with 403 (fail-closed).
//
// Parameters:
//   - engine:  the embedded policy engine (*services.PolicyEngineService)
//   - action:  the PAM action string, e.g. "pam:resource:Connect"
//   - resourceBuilder: a function that returns the resource pattern from the
//     Gin context (e.g. func(c) string { return "pam:postgresql/" + c.Param("id") })
//   - log:     zap logger
func RequirePermission(engine *services.PolicyEngineService, action string,
	resourceBuilder func(*gin.Context) string, log *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Get user_id from context (set by PAMAuth middleware).
		userIDRaw, exists := c.Get("user_id")
		if !exists {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Authentication required before authorization check",
			})
			return
		}
		userID := userIDRaw.(string)

		resource := resourceBuilder(c)

		result := engine.Authorize(c.Request.Context(), userID, action, resource)

		if !result.Allowed {
			log.Warn("authz.denied",
				zap.String("user_id", userID),
				zap.String("action", action),
				zap.String("resource", resource),
				zap.String("reason", result.Reason),
			)
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "Permission denied",
				"reason":  result.Reason,
				"action":  action,
			})
			return
		}

		// Allowed — store the decision ID for audit correlation.
		c.Set("authz_decision_id", result.DecisionID)
		c.Set("authz_action", action)
		c.Set("authz_resource", resource)

		log.Info("authz.allowed",
			zap.String("user_id", userID),
			zap.String("action", action),
			zap.String("resource", resource),
			zap.String("decision_id", result.DecisionID),
		)

		c.Next()
	}
}
