// pam/internal/middleware/audit.go
package middleware

import (
	"bytes"
	"context"
	"io"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

func AuditMiddleware(audit *services.AuditService, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		reqID := c.GetHeader("X-Request-ID")
		if reqID == "" {
			reqID = uuid.NewString()
			c.Request.Header.Set("X-Request-ID", reqID)
		}
		c.Writer.Header().Set("X-Request-ID", reqID)
		c.Set("request_id", reqID)

		var bodyBytes []byte
		if c.Request.Body != nil && c.Request.Method != "GET" {
			b, _ := io.ReadAll(c.Request.Body)
			bodyBytes = b
			c.Request.Body = io.NopCloser(bytes.NewReader(b))
		}

		c.Next()

		cat, action := classify(c)
		outcome := models.OutcomeSuccess
		status := c.Writer.Status()
		// BUGFIX: this used to map EVERY 4xx to DENIED, which conflated a real
		// access-control decision (401/403 — the thing a compliance auditor
		// actually cares about when filtering the audit trail for "denied"
		// events) with ordinary business-logic failures like 404 (recording
		// has no artifact yet, resource not found) or 400/409/422 (bad input,
		// conflict). That flooded the DENIED bucket with routine noise and
		// made it useless for its actual purpose — spotting genuine
		// authorization denials. Only 401/403 are DENIED now; other 4xx are
		// FAILURE, matching the AuditOutcome the rest of this codebase
		// already uses for "the request didn't succeed, but not because
		// access was denied" (see e.g. AuditRecordingFailed).
		switch {
		case status == 401 || status == 403:
			outcome = models.OutcomeDenied
		case status >= 400 && status < 500:
			outcome = models.AuditOutcomeFailure
		case status >= 500:
			outcome = models.OutcomeError
		}

		userID, _ := c.Get("user_id")
		username, _ := c.Get("username")
		email, _ := c.Get("email")
		authzDec, _ := c.Get("authz_decision_id")

		uid, _ := userID.(string)
		un, _ := username.(string)
		em, _ := email.(string)
		adi, _ := authzDec.(string)

		entry := services.AuditEntry{
			UserID:   uid,
			Username: un,
			Email:    em,
			Category: cat,
			Action:   action,
			Outcome:  outcome,
			Resource: c.Request.URL.Path,
			// REDACTED BEFORE IT IS STORED, not after: pam_audit_log is
			// append-only and hash-chained, so a secret written here cannot
			// be scrubbed later without breaking the evidence chain. See
			// audit_redact.go.
			Details:         truncate(redactAuditBody(bodyBytes, c.Request.URL.Path), 4096),
			SourceIP:        c.ClientIP(),
			UserAgent:       c.Request.UserAgent(),
			RequestID:       reqID,
			SessionID:       sessID(c),
			AuthzDecisionID: adi,
		}

		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()
			if _, err := audit.Append(ctx, entry); err != nil {
				logger.Error("audit.middleware.write.fail",
					zap.String("request_id", reqID),
					zap.String("action", action),
					zap.Error(err),
				)
			}
		}()

		logger.Debug("audit.middleware",
			zap.String("request_id", reqID),
			zap.String("path", c.Request.URL.Path),
			zap.Int("status", status),
			zap.Duration("latency", time.Since(start)),
		)
	}
}

// classify maps a request to (AuditCategory, action).
// Order matters: more specific checks come first.
func classify(c *gin.Context) (models.AuditCategory, string) {
	path := c.Request.URL.Path
	method := c.Request.Method

	// Auth routes (length 13 covers "/api/v1/auth" exactly)
	if len(path) >= 13 && path[:13] == "/api/v1/auth" {
		switch {
		case path == "/api/v1/auth/login" && method == "POST":
			return models.AuditAuth, "pam:auth:Login"
		case path == "/api/v1/auth/mfa/verify" && method == "POST":
			return models.AuditAuth, "pam:auth:MFAVerify"
		case path == "/api/v1/auth/mfa/setup/initiate":
			return models.AuditAuth, "pam:auth:MFASetupInitiate"
		case path == "/api/v1/auth/mfa/setup/verify":
			return models.AuditAuth, "pam:auth:MFASetupVerify"
		case path == "/api/v1/auth/logout":
			return models.AuditAuth, "pam:auth:Logout"
		case path == "/api/v1/auth/me":
			return models.AuditAuth, "pam:auth:Me"
		}
	}

	// PAM feature routes (length 11 covers "/api/v1/pam" exactly)
	if len(path) >= 11 && path[:11] == "/api/v1/pam" {
		// Vault operations.
		//
		// EVERY path containing "/credential" used to return
		// "pam:vault:Store", whatever the method and whatever the
		// sub-path. So an operator REVEALING a credential — the single
		// most consequential thing anyone does in a vault, the moment a
		// human takes possession of a secret — was recorded in the audit
		// trail as having STORED one. Not missing, which someone would
		// eventually notice: present and wrong, which nobody does.
		// Confirmed by revealing a credential and reading the row back:
		// action pam:vault:Store, details {"reason":"…"}.
		//
		// It also made the "/rotate" branch below unreachable for the
		// route that actually rotates (/credentials/:id/rotate), since
		// that path contains "/credential" and matched first.
		//
		// Most specific first, then by method.
		if contains(path, "/reveal") || contains(path, "/checkout") {
			return models.VaultAccess, "pam:vault:Reveal"
		}
		if contains(path, "/rotate") {
			return models.VaultAccess, "pam:vault:Rotate"
		}
		if contains(path, "/credential") {
			switch method {
			case "GET":
				// Metadata only — the secret itself is never in a GET
				// response, which is why this is not a Reveal.
				return models.VaultAccess, "pam:vault:Read"
			case "DELETE":
				return models.VaultAccess, "pam:vault:Delete"
			case "PUT", "PATCH":
				return models.VaultAccess, "pam:vault:Update"
			default:
				return models.VaultAccess, "pam:vault:Store"
			}
		}
		// Connect-info is a session-style action
		if contains(path, "/connect-info") {
			return models.SessionLifecycle, "pam:session:Connect"
		}
		// Sessions — kill takes precedence over list because /sessions/:id/kill also contains /sessions
		if contains(path, "/sessions") && contains(path, "/kill") {
			return models.SessionLifecycle, "pam:session:Kill"
		}
		if contains(path, "/sessions") {
			return models.SessionLifecycle, "pam:session:List"
		}
		// Resources — vault actions already checked, so this is the resource CRUD path
		if contains(path, "/resources") {
			return models.ResourceLifecycle, "pam:resource:" + method
		}
		// Audit + reports
		if contains(path, "/audit") && contains(path, "/report") {
			return models.ReportExport, "pam:report:Generate"
		}
		if contains(path, "/audit") && contains(path, "/verify") {
			return models.ReportExport, "pam:audit:Verify"
		}
		if contains(path, "/audit") {
			return models.ReportExport, "pam:audit:Read"
		}
	}
	return "OTHER", "pam:other:" + method + ":" + path
}

func sessID(c *gin.Context) string {
	if v, ok := c.Get("session_id"); ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return ""
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}

func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "...[truncated]"
}
