package models

import "testing"

// The regression this pins: the vault's whole MACHINE plane used to derive to
// OTHER. Every secret a service read, every service authentication failure and
// every grant change sat outside the categories the audit page and the
// compliance reports filter on — so "show me vault access" showed the human
// reveals and none of the machine reads, which are the majority of them.

func TestMachinePlaneActionsLandInTheCategoryAnAuditorFiltersOn(t *testing.T) {
	cases := map[string]AuditCategory{
		// A service reading a credential is vault access. This is the one
		// that matters most: it was the bulk of secret access, filed as OTHER.
		"pam.secret.read":       VaultAccess,
		"pam.secret.batch_read": VaultAccess,
		// A read refused by the identity's budget is still vault access, and
		// it is what an investigator chasing a leaked token searches for.
		"pam.service.rate_limited": VaultAccess,
		// A machine credential failing to authenticate is the same question
		// as a failed human login, asked of the other plane.
		"pam.service.auth_denied": AuditAuth,
		// Granting or withdrawing a scope changes what a principal may reach.
		"pam.service_grant.created": AuditAuthz,
		"pam.service_grant.revoked": AuditAuthz,
		// Identity and token lifecycle are administrative acts.
		"pam.service_identity.created":  AdminAction,
		"pam.service_identity.disabled": AdminAction,
		"pam.service_identity.enabled":  AdminAction,
		"pam.service_token.issued":      AdminAction,
		"pam.service_token.revoked":     AdminAction,
	}
	for action, want := range cases {
		if got := DeriveCategory(action); got != want {
			t.Errorf("DeriveCategory(%q) = %q, want %q", action, got, want)
		}
	}
}

func TestTheCategoriesTheLogAlreadyReliedOnAreUnchanged(t *testing.T) {
	cases := map[string]AuditCategory{
		"BREAKGLASS_USED":        BreakGlass,
		"JIT_REQUEST_CREATED":    JITAccess,
		"ACCESS_GRANT_ACTIVATED": JITAccess,
		"SESSION_STARTED":        SessionLifecycle,
		"AUTHZ_DENIED":           AuditAuthz,
		AuditDownloadBlocked:     SessionLifecycle,
		AuditClipboardBlocked:    SessionLifecycle,
		AuditDevToolsDetected:    SessionLifecycle,
		"something.unrecognised": AuditOther,
		"":                       AuditOther,
	}
	for action, want := range cases {
		if got := DeriveCategory(action); got != want {
			t.Errorf("DeriveCategory(%q) = %q, want %q", action, got, want)
		}
	}
}

func TestAnExplicitCategoryStillWins(t *testing.T) {
	// The middleware classifies vault HTTP routes itself and sets Category
	// directly. Derivation must not override a caller that already decided.
	row := &AuditLog{Action: "pam.secret.read", Category: AdminAction}
	if err := row.BeforeCreate(nil); err != nil {
		t.Fatal(err)
	}
	if row.Category != AdminAction {
		t.Fatalf("category = %q, want the explicitly set AdminAction", row.Category)
	}
}
