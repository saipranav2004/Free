import { useQuery } from '@tanstack/react-query'
import { KeyRound, Loader2, Radar, ShieldAlert, Terminal } from 'lucide-react'
import { getConnectInfo } from '../../api/resources'
import { getResourceChannels } from '../../api/agent'
import { normalizeApiError } from '../../lib/apiError'
import { channelBlocker, channelIcon, isUsable, locateCommand, sortChannels, CHANNEL_META } from '../../lib/channels'
import { MenuItem, MenuLabel } from '../ui/menu'
import { cliCommand, useDesktopLaunch, useWebSessionLaunch } from './ResourceAccess'

// ---------------------------------------------------------------------------
// The standard user's way into a resource
// ---------------------------------------------------------------------------
// A standard user has no resource detail page. That is not a gap: the detail
// page is a configuration record (credentials, policy bindings, audit,
// delete) and every control on it is admin-gated, so an operator who reached it
// found a screen whose only working action was the one they had just clicked
// from the row. The console redirected them off it, which is why clicking a
// resource looked like it did nothing at all.
//
// So the row's overflow menu IS the resource surface for them, and it carries
// the only three things they came for: open it on their desktop, open it in a
// browser, or get the command for their own client.
//
// WHY THE MENU IS BUILT FROM A REQUEST, NOT FROM THE ROW. Whether a given way
// in actually works depends on facts the catalogue row does not carry: whether
// a credential is stored, whether this user has paired a device, whether the
// brokered web gateway is switched on, and whether they hold a live grant right
// now.
//
// IT IS BUILT FROM THE CHANNEL MODEL, the same GET
// /pam/resources/:id/channels that the administrator's ChannelControls reads.
// This menu used to render from connect-info's `available_methods` instead,
// and the two answers are not the same shape — which produced, on a real
// standard operator's account, a menu offering ONLY "Open in Desktop" on a
// laptop whose pgAdmin 4 was missing, while hiding the CLI and Web routes the
// server reported as working. Three things were wrong at once and all three
// came from the same place:
//
//   · `available_methods` collapses the two axes into one list, so a channel
//     that is ALLOWED but not AVAILABLE here (the tool is not installed) is
//     indistinguishable from one policy has turned off — and the operator is
//     told to install nothing, or asks an administrator about something they
//     could have fixed themselves in a minute.
//   · `native_agent` in that list means "this account has a paired device",
//     not "that device has the client", so Desktop was offered on a machine
//     the capability report already said could not do it.
//   · Everything the row menu did NOT map was simply absent, with no line of
//     text anywhere saying why, which is the failure this product is supposed
//     to be the answer to.
//
// connect-info is still fetched, for the two things it alone answers: the JIT
// gate, and the command for an operator who has no agent at all.
//
// The rule from ChannelControls applies here too: an unusable channel is
// SHOWN and explains itself. A control that vanishes reads as a broken
// product; one that is present and says "pgAdmin 4 is not on this device"
// reads as a decision.
//
// The request is made when the menu opens, not when the page loads: ui/menu.jsx
// renders its children only while open, so mounting this component IS the
// trigger. A catalogue of forty resources therefore costs zero extra requests
// until somebody actually asks about one of them.
//
// Server-side, the same three actions are behind pam:resource:Connect AND
// middleware.RequireActiveGrant. The menu never becomes the boundary; it only
// stops offering doors that are locked.

function StaticItem({ icon: Icon, children, tone }) {
  return (
    <p
      className={
        'flex items-start gap-2 px-3 py-2 text-xs leading-relaxed ' +
        (tone === 'danger' ? 'text-danger' : 'text-secondary')
      }
    >
      {Icon && <Icon className="mt-0.5 h-3.5 w-3.5 flex-none" strokeWidth={1.9} />}
      <span>{children}</span>
    </p>
  )
}

/**
 * The body of a standard user's row menu.
 *
 * @param resource        the catalogue row
 * @param onRequestAccess opens the JIT request modal for this resource
 * @param onOpenCli       hands the resolved connect-info up so the page can
 *                        show the command; the menu itself is too small to
 *                        hold a copyable block
 */
export function ConnectMenuItems({ resource, onRequestAccess, onOpenCli }) {
  const query = useQuery({
    queryKey: ['resources', resource.id, 'connect-info'],
    queryFn: ({ signal }) => getConnectInfo(resource.id, signal),
    retry: false,
    // Short: an approval landing while the menu is shut must not leave a
    // stale "request access" behind the next time it opens.
    staleTime: 10_000,
  })

  // The same query key ChannelControls uses, so opening this menu and then the
  // detail page costs one request between them rather than two.
  const channelsQuery = useQuery({
    queryKey: ['resource', resource.id, 'channels'],
    queryFn: ({ signal }) => getResourceChannels(resource.id, signal),
    staleTime: 30_000,
  })

  const desktop = useDesktopLaunch(resource.id, {
    resourceType: resource.resource_type,
    recordingRequired: resource.always_record === true || resource.recording_required === true,
  })
  const web = useWebSessionLaunch(resource.id)

  if (!resource.is_active) {
    return <StaticItem icon={ShieldAlert}>This resource is inactive, so there is nothing to open.</StaticItem>
  }

  if (query.isLoading || channelsQuery.isLoading) {
    return <StaticItem icon={Loader2}>Checking what you can open…</StaticItem>
  }

  if (query.isError) {
    const err = normalizeApiError(query.error)
    // The JIT gate is the product working, not a failure, so it gets the one
    // action that resolves it rather than an error line.
    if (err.code === 'jit_grant_required') {
      return (
        <>
          <StaticItem icon={KeyRound}>
            This resource needs time-boxed access and you do not hold a grant right now.
          </StaticItem>
          <MenuItem icon={KeyRound} onClick={() => onRequestAccess(resource)}>
            Request access
          </MenuItem>
        </>
      )
    }
    return (
      <StaticItem icon={ShieldAlert} tone="danger">
        {err.message}
      </StaticItem>
    )
  }

  const info = query.data || {}
  const command = cliCommand(info)
  const channels = sortChannels(channelsQuery.data || [])

  // No credential means PAM has nothing to inject on the operator's behalf,
  // whatever the channels say — so it is stated once here rather than three
  // times, once per channel.
  if (!info.has_credential) {
    return (
      <StaticItem icon={ShieldAlert}>
        No credential is stored for this resource, so there is nothing to broker on your behalf.
      </StaticItem>
    )
  }

  if (channels.length === 0) {
    return (
      <StaticItem icon={Radar}>
        No way to open this resource is configured. An administrator can enable one.
      </StaticItem>
    )
  }

  const pending = desktop.isPending ? desktop.variables : web.isPending ? 'web' : null

  return (
    <>
      <MenuLabel>Connect</MenuLabel>

      {channels.map((entry) => {
        const meta = CHANNEL_META[entry.channel] || {}
        const Icon = channelIcon(entry.channel)
        const blocker = channelBlocker(entry)
        const usable = isUsable(entry)

        return (
          <div key={entry.channel}>
            <MenuItem
              icon={Icon}
              disabled={!usable || pending !== null}
              title={usable ? meta.note : blocker?.title}
              onClick={() => {
                // Web is brokered by the server and needs no agent at all, so
                // it takes a different path entirely. Routing it through the
                // agent launch would demand a paired device for something
                // that does not need one.
                if (entry.channel === 'web') web.mutate()
                else desktop.mutate(entry.channel)
              }}
            >
              {meta.label || entry.channel}
            </MenuItem>

            {/* One line naming the obstacle and one naming the fix — the same
                text the administrator's control shows, so the two surfaces
                cannot tell an operator different stories about the same
                machine. */}
            {!usable && blocker && (
              <StaticItem icon={blocker.kind === 'policy' ? ShieldAlert : Radar}>
                <span className="font-medium text-primary">{blocker.title}.</span> {blocker.detail}
                {blocker.locate && (
                  <>
                    {' '}Already have it? Run{' '}
                    <span className="font-mono text-2xs">{locateCommand(blocker.locate)}</span>.
                  </>
                )}
              </StaticItem>
            )}
          </div>
        )
      })}

      {/* THE CONNECTION DETAILS, for an operator with no agent on this
          machine.
          This item was present, wired end to end — ResourcesPage holds the
          dialog state, ResourceTable threads onOpenCli down to here — and
          commented out, with nothing to say why. So the one route that needs
          no software installed at all was the one a standard user could not
          reach, on exactly the machines where every other route is blocked.
          Offered when the recorded CLI channel is not usable but the server
          says a protocol connector and a credential exist, which is precisely
          the un-paired case. */}
      {command && !channels.some((c) => c.channel === 'cli' && isUsable(c)) && (
        <MenuItem icon={Terminal} onClick={() => onOpenCli({ resource, info, command })}>
          Show connection details
        </MenuItem>
      )}

      {!channels.some(isUsable) && (
        <StaticItem icon={ShieldAlert}>
          There is no way to open this resource from this device right now. Each line above says why.
        </StaticItem>
      )}
    </>
  )
}
