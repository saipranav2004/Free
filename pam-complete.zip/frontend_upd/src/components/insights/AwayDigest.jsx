import { AlertTriangle, Check, KeyRound, Loader2, ShieldAlert, Terminal, X } from 'lucide-react'
import { Link } from 'react-router-dom'
import clsx from 'clsx'
import { useAwayDigest, useMarkDigestSeen } from '../../hooks/useInsights'
import { formatRelativeToNow } from '../../lib/format'

// ---------------------------------------------------------------------------
// "While you were away"
// ---------------------------------------------------------------------------
// The question every operator opens this console with — what happened since I
// last looked — had no answer anywhere in the product. The bell answers a
// different question: a notification is something addressed TO you, which is a
// much smaller set than the things that HAPPENED. The audit chain held the
// answer the whole time and nothing was reading it this way.
//
// Three rules decide the shape of this card:
//
//   IT DISAPPEARS. A banner that is always present is chrome, and chrome is
//     not read. This renders only when there is something to say, and once
//     dismissed it does not come back until something new happens.
//   COUNTS FOR THE ROUTINE, NAMES FOR THE SERIOUS. "4 secrets read" is the
//     right shape for routine work. "3 critical events" is the one number
//     nobody can act on, so break-glass use and refusals are listed one by
//     one, with the actor and the target, and each one is a link.
//   DISMISSING IS A REAL WRITE. It moves an anchor that cannot be moved back,
//     so it is not in the optimistic set: the card stays, with a spinner,
//     until the server confirms. Everything the card showed stays reachable in
//     Audit afterwards — this hides a summary, it never hides an event.

// A first visit sweeps a bounded window rather than all of history, and the
// card has to say which of the two it is showing, or "417 events" reads as a
// catastrophe instead of as a week.
function windowLabel(digest) {
  if (digest.first_visit) return 'in the last 7 days'
  return `since ${formatRelativeToNow(digest.since)}`
}

function Figure({ icon: Icon, value, label, to, tone = 'default' }) {
  const body = (
    <span className="flex items-baseline gap-2">
      <Icon
        className={clsx(
          'size-3.5 shrink-0 self-center',
          tone === 'danger' ? 'text-danger' : 'text-tertiary'
        )}
        aria-hidden="true"
      />
      <span
        className={clsx(
          'font-mono text-lg font-semibold tabular-nums',
          tone === 'danger' ? 'text-danger' : 'text-primary'
        )}
      >
        {value}
      </span>
      <span className="text-xs text-tertiary">{label}</span>
    </span>
  )
  if (!to) return body
  return (
    <Link to={to} className="rounded transition-colors hover:text-accent focus-visible:outline-2">
      {body}
    </Link>
  )
}

// Audit actions are wire identifiers. The Audit table prints them verbatim
// and should — a compliance officer wants the exact string, and a dense
// monospace column is the right place for it. A summary card is not: a line
// reading `pam:other:GET:/api/v1/pam/admin/recordings on
// /api/v1/pam/admin/recordings` prints the same path twice and buries the one
// word that matters, which is that somebody was refused.
//
// So this is presentation only. It never invents a friendlier name for an
// action (the mistake that puts a label on a card which no longer matches
// what the backend emits) — it only strips the prefixes the codebase itself
// composed: `pam:other:<METHOD>:<path>` from the request auditor,
// `pam:<resource>:<Verb>` from the permission gate, and the dotted and
// SCREAMING_CASE forms the domain services write.
export function describeAction(action = '') {
  const generic = /^pam:other:([A-Z]+):(.*)$/.exec(action)
  if (generic) {
    const [, method, path] = generic
    return { verb: method, target: path.replace(/^\/api\/v1\/pam/, '') }
  }
  const gated = /^pam:([a-z_]+):([A-Za-z]+)$/.exec(action)
  if (gated) return { verb: gated[2], target: gated[1] }
  if (/^[A-Z_]+$/.test(action)) {
    const words = action.toLowerCase().replace(/_/g, ' ')
    return { verb: words.charAt(0).toUpperCase() + words.slice(1), target: '' }
  }
  // pam.agent.launch.version_refused → "agent launch version refused"
  return { verb: action.replace(/^pam\./, '').replace(/[._]/g, ' '), target: '' }
}

function CriticalRow({ event }) {
  const denied = event.outcome === 'DENIED'
  const { verb, target } = describeAction(event.action)
  // Not de-duplicated against the "Refused" label: stripping a trailing
  // "refused" turns pam.agent.launch.version_refused into "agent launch
  // version", which drops the word the action name is actually about. A
  // little redundancy beats a truncated event name.
  // The resource is printed only when it adds something. For a generic
  // request row the path IS the action's tail, and showing both is noise.
  const resource = event.resource && !event.action.endsWith(event.resource) ? event.resource : ''
  return (
    <li className="flex items-baseline gap-2 py-1 text-xs">
      {denied ? (
        <ShieldAlert className="size-3.5 shrink-0 self-center text-danger" aria-hidden="true" />
      ) : (
        <AlertTriangle className="size-3.5 shrink-0 self-center text-warn" aria-hidden="true" />
      )}
      {denied ? <span className="font-medium text-danger">Refused</span> : null}
      <span className="font-medium text-primary">{verb}</span>
      {target ? <span className="truncate font-mono text-tertiary">{target}</span> : null}
      <span className="text-tertiary">by</span>
      <span className="truncate text-primary" title={event.actor}>{shortActor(event.actor)}</span>
      {resource ? (
        <>
          <span className="text-tertiary">on</span>
          <span className="truncate text-primary">{resource}</span>
        </>
      ) : null}
      <span
        className="ml-auto whitespace-nowrap text-tertiary"
        title={event.action}
      >
        {formatRelativeToNow(event.at)}
      </span>
    </li>
  )
}

// Some audit rows carry no username — agent-emitted ones carry the account id
// instead. A 36-character UUID mid-sentence destroys the line, so it is
// shortened here and kept in full in the title attribute. Not resolved to a
// name: that would be a per-row lookup on a summary card, which is the fan-out
// this whole pass removed elsewhere.
function shortActor(actor = '') {
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(actor)) return actor.slice(0, 8) + '…'
  return actor
}

export function AwayDigestCard() {
  const { data, isLoading, isError } = useAwayDigest()
  const seen = useMarkDigestSeen()

  // Quiet on every failure path. This sits above the dashboard somebody came
  // to read; a digest that cannot load is not worth an error box, and a
  // digest with nothing in it is not worth a card at all.
  if (isLoading || isError || !data) return null

  const total = data.total_events || 0
  const critical = data.critical || []
  if (total === 0 && critical.length === 0 && !(data.new_sessions > 0)) return null

  return (
    <section
      aria-label="While you were away"
      data-testid="away-digest"
      className="rounded-xl border border-line bg-surface px-4 py-3"
    >
      <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <h2 className="text-sm font-semibold text-primary">While you were away</h2>
        <span className="text-xs text-tertiary">{windowLabel(data)}</span>
        <button
          type="button"
          onClick={() => seen.mutate()}
          disabled={seen.isPending}
          data-testid="away-digest-dismiss"
          className="ml-auto inline-flex items-center gap-1.5 rounded px-2 py-1 text-xs text-tertiary transition-colors hover:bg-hover hover:text-primary focus-visible:outline-2 disabled:opacity-60"
        >
          {seen.isPending ? (
            <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
          ) : (
            <X className="size-3.5" aria-hidden="true" />
          )}
          {seen.isPending ? 'Marking read' : 'Mark as read'}
        </button>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-8 gap-y-3">
        <Figure icon={Check} value={total} label="events" to="/admin/audit" />
        <Figure icon={Terminal} value={data.new_sessions || 0} label="sessions" to="/sessions" />
        <Figure icon={KeyRound} value={data.secret_reads || 0} label="secrets read" to="/vault" />
        {data.denied > 0 ? (
          <Figure icon={ShieldAlert} value={data.denied} label="refused" tone="danger" to="/admin/audit?outcome=DENIED" />
        ) : null}
        {data.breakglass > 0 ? (
          <Figure icon={AlertTriangle} value={data.breakglass} label="break-glass" tone="danger" to="/sessions" />
        ) : null}
      </div>

      {critical.length > 0 ? (
        <ul className="mt-3 divide-y divide-line-soft border-t border-line-soft pt-1">
          {critical.map((e, i) => (
            <CriticalRow key={`${e.at}-${e.action}-${i}`} event={e} />
          ))}
        </ul>
      ) : null}

      {data.top_actors?.length > 1 ? (
        <p className="mt-2 text-xs text-tertiary">
          Busiest:{' '}
          {data.top_actors.slice(0, 3).map((a, i) => (
            <span key={a.label}>
              {i > 0 ? ', ' : ''}
              <span className="text-primary" title={a.label}>{shortActor(a.label)}</span> ({a.value})
            </span>
          ))}
        </p>
      ) : null}
    </section>
  )
}

export default AwayDigestCard
