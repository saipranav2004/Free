import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import clsx from 'clsx'
import { Check, ChevronDown, MoreHorizontal } from 'lucide-react'

// ---------------------------------------------------------------------------
// One popover primitive for every dropdown in the console
// ---------------------------------------------------------------------------
// Toolbar menus, the column chooser, export, saved views, and the per row
// overflow. Closes on outside click and on Escape, and anchors right by
// default because almost all of them sit at a row or toolbar's right edge.
//
// MenuItem closes its own menu on activation unless it is a multi select
// item. Without that, opening a dialog from a row menu left the menu hanging
// open behind the dialog it had just opened.
const MenuCloseCtx = createContext(() => {})

// THE PANEL IS PORTALLED TO document.body, not absolutely positioned inside
// the trigger's wrapper.
//
// It used to be `absolute top-full` in a `relative` parent, which means every
// ancestor with an overflow is free to cut it off — and in a table there are
// always two: the horizontal scroller that lets wide tables scroll, and the
// rounded card that clips its own corners. Measured on the resources table,
// those two clipped a 183px row menu to about 66: an operator saw "Open in
// CLI", half of "Open in Desktop", and nothing else. The install advice and
// the whole third channel were inside the DOM, inside the accessibility tree,
// and under the edge of the card.
//
// That made it a silent failure of the worst kind. A menu that renders
// nothing looks broken and gets reported; a menu that renders its first item
// and swallows the rest looks finished, and the operator concludes the
// product only offers what they can see. Every check that read the menu's
// text passed throughout, because innerText does not care what is visible.
//
// Fixed positioning against the trigger's own rect, in a portal, cannot be
// clipped by anything. The panel then has to track the trigger while it is
// open (scroll and resize), and flip above the trigger when there is not room
// below — a row near the bottom of a long table is exactly where a tall menu
// opens.
const VIEWPORT_MARGIN = 8

export function Menu({ trigger, children, align = 'right', width = 'w-56', label }) {
  const [open, setOpen] = useState(false)
  const wrapRef = useRef(null)
  const panelRef = useRef(null)
  const [pos, setPos] = useState(null)

  const place = useCallback(() => {
    const trig = wrapRef.current?.getBoundingClientRect()
    if (!trig) return
    const panelHeight = panelRef.current?.offsetHeight || 0
    const below = window.innerHeight - trig.bottom - VIEWPORT_MARGIN
    // Flip up only when there is genuinely more room there, so a menu near
    // the bottom of the viewport opens upward instead of off-screen.
    const flip = panelHeight > below && trig.top - VIEWPORT_MARGIN > below

    setPos({
      top: flip ? Math.max(VIEWPORT_MARGIN, trig.top - panelHeight - 4) : trig.bottom + 4,
      left: Math.max(VIEWPORT_MARGIN, trig.left),
      right: Math.max(VIEWPORT_MARGIN, window.innerWidth - trig.right),
      maxHeight: Math.max(160, (flip ? trig.top : window.innerHeight - trig.bottom) - VIEWPORT_MARGIN * 2),
    })
  }, [])

  // Before paint, so the panel never appears at the wrong place for a frame.
  useLayoutEffect(() => {
    if (open) place()
  }, [open, place])

  useEffect(() => {
    if (!open) return undefined
    // The panel lives outside the wrapper now, so an outside click has to
    // check both — otherwise clicking anything IN the menu closes it before
    // the item's own handler runs.
    const onDown = (e) => {
      if (!wrapRef.current?.contains(e.target) && !panelRef.current?.contains(e.target)) setOpen(false)
    }
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    // Capture, so scrolling INSIDE the table (not just the window) keeps the
    // panel attached to its row.
    const onScroll = () => place()
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    window.addEventListener('scroll', onScroll, true)
    window.addEventListener('resize', onScroll)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
      window.removeEventListener('scroll', onScroll, true)
      window.removeEventListener('resize', onScroll)
    }
  }, [open, place])

  return (
    <div ref={wrapRef} className="relative flex-none">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={label}
        onClick={() => setOpen((v) => !v)}
        className="block"
      >
        {typeof trigger === 'function' ? trigger(open) : trigger}
      </button>
      {open &&
        createPortal(
          <MenuCloseCtx.Provider value={() => setOpen(false)}>
            <div
              ref={panelRef}
              role="menu"
              aria-label={label}
              style={{
                top: pos?.top ?? -9999,
                maxHeight: pos?.maxHeight,
                ...(align === 'right' ? { right: pos?.right } : { left: pos?.left }),
              }}
              className={clsx(
                // overflow-y-auto rather than overflow-hidden: a menu taller
                // than the viewport must be scrollable, not truncated. That
                // is the whole bug, one level up.
                'animate-menu-in fixed z-50 overflow-y-auto rounded-lg border border-line bg-surface py-1 shadow-overlay',
                width
              )}
            >
              {children}
            </div>
          </MenuCloseCtx.Provider>,
          document.body
        )}
    </div>
  )
}

export function MenuItem({
  icon: Icon,
  children,
  onClick,
  danger = false,
  checked,
  hint,
  keepOpen = false,
  disabled = false,
  className,
}) {
  const closeMenu = useContext(MenuCloseCtx)
  return (
    <button
      type="button"
      role="menuitem"
      disabled={disabled}
      onClick={(e) => {
        onClick?.(e)
        if (!keepOpen && checked === undefined) closeMenu()
      }}
      className={clsx(
        'flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition-colors duration-100',
        'disabled:pointer-events-none disabled:opacity-45',
        danger ? 'text-danger hover:bg-danger-soft' : 'text-primary hover:bg-hover',
        className
      )}
    >
      {checked !== undefined ? (
        <span
          className={clsx(
            'flex h-4 w-4 flex-none items-center justify-center rounded-sm border',
            checked ? 'border-accent bg-accent text-accent-on' : 'border-line-strong'
          )}
        >
          {checked && <Check className="h-3 w-3" strokeWidth={3} />}
        </span>
      ) : (
        Icon && <Icon className="h-4 w-4 flex-none text-tertiary" strokeWidth={1.75} />
      )}
      <span className="min-w-0 flex-1 truncate">{children}</span>
      {hint && <span className="flex-none text-xs text-tertiary">{hint}</span>}
    </button>
  )
}

export function MenuLabel({ children }) {
  return <p className="px-3 pb-1 pt-2 text-micro font-semibold uppercase text-tertiary">{children}</p>
}

export function MenuNote({ children }) {
  return <p className="px-3 pb-2 pt-1 text-xs leading-relaxed text-tertiary">{children}</p>
}

export function MenuDivider() {
  return <div className="my-1 h-px bg-line" aria-hidden="true" />
}

// A dropdown trigger that reads as a secondary button. Extracted because six
// toolbar controls share it and they must not drift apart. It is a <span>
// because Menu already renders the <button> around it.
export function MenuButton({ icon: Icon, children, open, count, className }) {
  return (
    <span
      className={clsx(
        'inline-flex h-8 flex-none cursor-pointer select-none items-center gap-2 rounded border px-3 text-sm font-medium transition-colors duration-100',
        open
          ? 'border-line-strong bg-hover text-primary'
          : 'border-line bg-surface text-primary hover:bg-hover',
        className
      )}
    >
      {Icon && <Icon className="h-4 w-4 flex-none" strokeWidth={1.75} />}
      {children}
      {count != null && <span className="tabular text-tertiary">{count}</span>}
      <ChevronDown className="h-3.5 w-3.5 flex-none text-tertiary" strokeWidth={1.75} />
    </span>
  )
}

// The per row overflow. Destructive row actions live in here, never on the
// row itself.
export function RowMenu({ children, label = 'Row actions' }) {
  return (
    <Menu
      label={label}
      width="w-56"
      trigger={(open) => (
        <span
          className={clsx(
            'flex h-6 w-6 items-center justify-center rounded transition-colors',
            open ? 'bg-hover text-primary' : 'text-tertiary hover:bg-hover hover:text-primary'
          )}
        >
          <MoreHorizontal className="h-4 w-4" strokeWidth={2} />
        </span>
      )}
    >
      {children}
    </Menu>
  )
}
