import { useMemo } from 'react'
import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Timeline — the archetype for live activity over time
// ---------------------------------------------------------------------------
// A session list sorted by start time tells you WHEN each one began. It does
// not show overlap, and overlap is the question somebody opens this page with:
// who else was in production while that change was made, did these two
// sessions run at the same time, has this one been open far longer than the
// rest.
//
// Rows on a shared time axis answer all three at a glance, and a table cannot
// answer any of them without the reader doing arithmetic across two columns.
//
// SCOPED TO WHAT IS RUNNING. This draws live sessions only. A timeline over
// all history is a different chart with a different axis, and stacking the two
// would mean one of them is always at the wrong zoom.

export function SessionTimeline({ sessions, now = Date.now(), onSelect, className }) {
  const model = useMemo(() => {
    const rows = (sessions || [])
      .map((s) => ({ session: s, start: new Date(s.started_at).getTime() }))
      .filter((r) => Number.isFinite(r.start))
      .sort((a, b) => a.start - b.start)
    if (!rows.length) return null

    // The window starts at the oldest live session, not at a fixed span: the
    // point is to compare these sessions with each other, and a fixed window
    // either crushes them into the right-hand edge or leaves most of the axis
    // empty.
    const earliest = rows[0].start
    // A floor on the span, so a single one-minute session does not stretch to
    // fill the whole width and read as if it had been open for hours.
    const span = Math.max(now - earliest, 5 * 60 * 1000)
    return { rows, earliest, span }
  }, [sessions, now])

  if (!model) return null
  const { rows, earliest, span } = model

  // Ticks at the quarter points, labelled as an age rather than a clock time:
  // "2h ago" is the thing being compared, and a wall-clock axis makes the
  // reader do the subtraction.
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => ({
    pct: f * 100,
    label: f === 1 ? 'now' : humanAge(span * (1 - f)),
  }))

  return (
    <div className={clsx('min-w-0', className)}>
      <div className="relative mb-1 h-4">
        {ticks.map((t) => (
          <span
            key={t.pct}
            className="absolute -translate-x-1/2 text-2xs tabular text-tertiary"
            style={{ left: `${t.pct}%` }}
          >
            {t.label}
          </span>
        ))}
      </div>

      <ul className="flex flex-col gap-1">
        {rows.map(({ session, start }) => {
          const offset = ((start - earliest) / span) * 100
          const width = Math.max(((now - start) / span) * 100 - offset, 1.5)
          // A short session in a long window is legitimately a sliver — a
          // five-minute session next to a two-hour one IS four percent of the
          // width, and squashing it would misreport the very thing this chart
          // exists to show. But a label inside a 4% bar is clipped to nothing,
          // and a row with no visible label reads as an empty row: the first
          // draft of this drew four sessions and looked like one.
          //
          // So the bar keeps its true width and the label moves OUTSIDE it
          // when it cannot fit. Below ~24% there is no room for a name and a
          // username; on the right-hand edge it flips to the left so it does
          // not run off the end.
          const labelInside = width >= 24
          const labelOnLeft = !labelInside && offset > 70
          const Row = onSelect ? 'button' : 'div'
          const label = (
            <>
              <span
                aria-hidden="true"
                className={clsx(
                  'h-1.5 w-1.5 flex-none rounded-full',
                  session.is_breakglass ? 'bg-danger' : 'bg-accent'
                )}
              />
              <span className="truncate text-2xs font-medium text-primary">
                {session.resource_name}
              </span>
              <span className="truncate text-2xs text-tertiary">{session.username}</span>
            </>
          )
          return (
            <li key={session.id} className="relative">
              <Row
                {...(onSelect
                  ? { type: 'button', onClick: () => onSelect(session), className: 'block w-full text-left' }
                  : {})}
              >
                <div className="relative h-6 w-full rounded bg-subtle">
                  <span
                    className={clsx(
                      'absolute inset-y-0 rounded',
                      labelInside && 'flex items-center gap-1.5 overflow-hidden px-2',
                      session.is_breakglass ? 'bg-danger/20' : 'bg-accent/20'
                    )}
                    style={{ left: `${offset}%`, width: `${width}%` }}
                    title={`${session.resource_name} · ${session.username}`}
                  >
                    {labelInside && label}
                  </span>
                  {!labelInside && (
                    <span
                      className={clsx(
                        'absolute inset-y-0 flex max-w-[45%] items-center gap-1.5 overflow-hidden',
                        labelOnLeft ? 'justify-end pr-1.5' : 'pl-1.5'
                      )}
                      style={
                        labelOnLeft
                          ? { right: `${100 - offset}%` }
                          : { left: `${Math.min(offset + width, 99)}%` }
                      }
                    >
                      {label}
                    </span>
                  )}
                </div>
              </Row>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

function humanAge(ms) {
  const m = Math.round(ms / 60000)
  if (m < 1) return 'now'
  if (m < 60) return `${m}m`
  const h = Math.round(m / 60)
  if (h < 24) return `${h}h`
  return `${Math.round(h / 24)}d`
}
