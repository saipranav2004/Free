import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Laptop, Trash2, ChevronDown, ChevronRight } from 'lucide-react'
import { listAgentDevices, revokeAgentDevice } from '../../api/agent'
import { apiErrorMessage } from '../../lib/apiError'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'
import { QueryState } from '../common/QueryState'
import { Spinner } from '../common/Spinner'
import { Badge, MetaTag, StatusIndicator } from '../common/Badge'
import { PairAgentPanel } from './PairAgentPanel'
import { DeviceCapabilities } from './DeviceCapabilities'

// The shared relative-time helper rather than a local one: this screen used
// its own, which fell back to toLocaleDateString() past a day and so printed
// a bare date in the browser's locale while every other timestamp in the
// console honoured the viewer's configured timezone.
function lastSeenLabel(iso) {
  return iso ? formatRelativeToNow(iso) : 'never'
}

// What the server says about this device's build.
//
// version_status has been on the wire since the version floor was added and
// nothing rendered it. A deployment that sets a floor is saying "an agent
// below this is missing something I depend on" — and the machine that is
// below it is exactly the machine whose launches will fail, so it is worth a
// badge rather than a silent grey line.
function VersionState({ device }) {
  const status = device.version_status
  const version = device.agent_version

  if (!version) {
    return <MetaTag mono>version unknown</MetaTag>
  }
  if (status === 'stale') {
    return (
      <Badge className="bg-amber-500/10 text-amber-700 ring-amber-500/30 dark:text-amber-300" dot>
        {version} — upgrade needed
      </Badge>
    )
  }
  if (status === 'unknown') {
    // A local `dev` build, or one too old to report a comparable version,
    // against a deployment that has set a floor. Named as such, because
    // "unknown" against a floor means refused, not merely unrecognised.
    return (
      <Badge className="bg-amber-500/10 text-amber-700 ring-amber-500/30 dark:text-amber-300">
        {version} — not comparable to the required minimum
      </Badge>
    )
  }
  return <MetaTag mono>{version}</MetaTag>
}

// ACTIVE is the default for a device row that predates the status column, so
// an absent status must not read as revoked.
const isActive = (d) => String(d?.status || 'ACTIVE').toUpperCase() === 'ACTIVE'

// One paired machine.
//
// What this row is FOR: answering, without anyone having to run anything on
// the machine, "is this the laptop I think it is, is its agent current, and
// what can it actually open?" Everything shown here was already on the wire —
// os, arch, hostname, agent_version, version_status, capabilities,
// capabilities_at — and none of it was rendered.
function DeviceRow({ device, onRevoke, revoking }) {
  return (
    <li className="rounded-xl border border-surface-700/70 bg-surface-950/30 px-4 py-3">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
            <Laptop className="h-4 w-4 flex-none text-ink-500" aria-hidden="true" />
            <p className="truncate text-sm text-ink-100">{device.device_name}</p>
            <StatusIndicator tone="emerald">Active</StatusIndicator>
            {device.os && (
              <MetaTag>
                {device.os}
                {device.arch ? `/${device.arch}` : ''}
              </MetaTag>
            )}
            <VersionState device={device} />
          </div>
          <p className="mt-1 text-2xs text-ink-500">
            {device.hostname ? <>host {device.hostname} · </> : null}
            last seen {lastSeenLabel(device.last_seen_at)}
            {device.created_at ? (
              <span title={device.created_at}> · paired {formatDateTime(device.created_at)}</span>
            ) : null}
          </p>
        </div>

        <button
          onClick={onRevoke}
          disabled={revoking}
          className="flex flex-none items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30 disabled:opacity-60"
        >
          {revoking ? <Spinner size="h-3.5 w-3.5" /> : <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />}
          Revoke
        </button>
      </div>

      <DeviceCapabilities device={device} />
    </li>
  )
}

// Settings-page section: the full device-management view (list + revoke +
// pair-a-new-one). ConnectPanel embeds only PairAgentPanel inline for the
// "no device yet" case, this is the fuller picture for someone managing
// multiple machines over time.
export function AgentDevicesPanel() {
  const queryClient = useQueryClient()
  const [showPairing, setShowPairing] = useState(false)
  const [showRevoked, setShowRevoked] = useState(false)

  const devicesQuery = useQuery({
    queryKey: ['agent', 'devices'],
    queryFn: ({ signal }) => listAgentDevices(signal),
  })
  // The endpoint returns { devices, count } — reading .length off the
  // object gives undefined rather than 0, which renders as the literal
  // word "undefined" in a sentence.
  //
  // ACTIVE ONLY, so the sentence matches the list under it. Counting every
  // row meant an account with one laptop and two revoked ones read "3
  // machines paired to this account" above a list showing one — and since
  // revoked devices were not rendered at all, there was nothing on the screen
  // to explain the other two. This is the first line a standard operator
  // reads on this screen.
  const allDevices = devicesQuery.data?.devices || []
  const pairedCount = allDevices.filter(isActive).length

  const revokeMutation = useMutation({
    mutationFn: (deviceId) => revokeAgentDevice(deviceId),
    onSuccess: () => {
      toast.success('Device revoked')
      queryClient.invalidateQueries({ queryKey: ['agent', 'devices'] })
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    // NO HEADING HERE. The Group this sits inside already says "Paired
    // devices" and explains what they are; repeating both produced two
    // titles and two descriptions of the same thing, one above the other,
    // which is what made this screen read as unfinished.
    <div className="rounded-xl border border-surface-700/70 bg-surface-900 p-5">
      <div className="flex items-center justify-between gap-4">
        <p className="min-w-0 text-xs text-ink-400">
          {devicesQuery.isLoading
            ? 'Checking which machines are paired…'
            : pairedCount === 0
              ? 'No machine is paired yet. Install the agent above, or pair one you already have.'
              : `${pairedCount} machine${pairedCount === 1 ? '' : 's'} paired to this account.`}
        </p>
        <button
          onClick={() => setShowPairing((s) => !s)}
          className="flex-none rounded-lg bg-surface-800 transition-colors px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700"
        >
          {showPairing ? 'Hide' : 'Pair a device'}
        </button>
      </div>

      {showPairing && (
        <div className="mt-4">
          {/* ONE pairing panel, not two.
              This used to render PairAgentPanel directly AND again inside the
              disclosure below it — two panels, each minting its own one-time
              code against the same account, one of them hidden. Whichever
              code you read, the other panel had already issued a second, and
              a code is single-use: the visible one could be the dead one.
              That is the repeated control on this screen, and it was not
              only clutter. */}
          <div className="rounded-xl border border-surface-700/70 bg-surface-900 px-5 py-4">
            <p className="text-2xs leading-relaxed text-ink-500">
              For a machine that already has <code className="text-ink-400">pam-agent</code>{' '}
              installed, or one that cannot download from this server. Everything else is
              faster through the one-command install above.
            </p>
            <div className="mt-3">
              <PairAgentPanel
                onPaired={() => {
                  setShowPairing(false)
                  queryClient.invalidateQueries({ queryKey: ['agent', 'devices'] })
                  toast.success('Agent paired')
                }}
              />
            </div>
          </div>
        </div>
      )}

      <div className="mt-4">
        {/* NO `empty` BRANCH HERE, deliberately.
            The sentence at the top of this panel is already the empty state,
            and a better one: it points at the install command above and at
            the Pair button beside it. QueryState's own empty block added
            "Nothing to show / No agent devices paired yet." underneath it, so
            an operator with no device — which is every operator on their
            first visit, and the only thing they see on this screen — was told
            the same thing twice in two different voices. QueryState is still
            what handles loading, 403 and network failure, which is why it
            stays. */}
        <QueryState query={devicesQuery}>
          {(data) => {
            const all = data.devices || []
            const active = all.filter(isActive)
            if (all.length === 0) return null
            const revoked = all.filter((d) => !isActive(d))
            return (
              <>
                <ul className="space-y-2">
                  {active.map((d) => (
                    <DeviceRow
                      key={d.id}
                      device={d}
                      onRevoke={() => revokeMutation.mutate(d.id)}
                      revoking={revokeMutation.isPending && revokeMutation.variables === d.id}
                    />
                  ))}
                </ul>

                {/* REVOKED DEVICES WERE FILTERED OUT ENTIRELY, which made a
                    revoke look like a delete: the row vanished, and there
                    was no way to see that a machine had ever been paired to
                    this account. For a privileged-access product that is the
                    wrong shape — revoking a laptop is a security event
                    someone may need to confirm happened, and confirm it is
                    still revoked. Collapsed, because on a healthy account it
                    is the uninteresting half of the list. */}
                {revoked.length > 0 && (
                  <div className="mt-4 border-t border-surface-800 pt-3">
                    <button
                      type="button"
                      onClick={() => setShowRevoked((v) => !v)}
                      aria-expanded={showRevoked}
                      className="flex items-center gap-1 text-2xs font-medium text-ink-400 transition-colors hover:text-ink-200"
                    >
                      {showRevoked ? (
                        <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
                      ) : (
                        <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                      {revoked.length} revoked device{revoked.length === 1 ? '' : 's'}
                    </button>
                    {showRevoked && (
                      <ul className="mt-2 space-y-1.5">
                        {revoked.map((d) => (
                          <li
                            key={d.id}
                            className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-surface-800 bg-surface-950/40 px-3 py-2"
                          >
                            <Laptop className="h-3.5 w-3.5 flex-none text-ink-600" aria-hidden="true" />
                            <span className="text-xs text-ink-400">{d.device_name}</span>
                            <StatusIndicator tone="red">Revoked</StatusIndicator>
                            <span className="text-2xs text-ink-600">
                              last seen {lastSeenLabel(d.last_seen_at)}
                            </span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </>
            )
          }}
        </QueryState>
      </div>
    </div>
  )
}
