import { useState } from 'react'
import clsx from 'clsx'
import { ChevronDown, ChevronRight, Terminal, Laptop, Globe, Video, VideoOff } from 'lucide-react'
import { StatusIndicator } from '../common/Badge'
import { formatRelativeToNow } from '../../lib/format'

// ---------------------------------------------------------------------------
// WHAT THIS MACHINE CAN OPEN
// ---------------------------------------------------------------------------
// The agent has reported this since pairing — one entry per resource type,
// naming the tools it found and every tool it looked for and did not find,
// with the install hint from the launch template. The console has been using
// it to decide whether to grey out a button (see lib/agentDevice.js), and
// throwing the rest away: the device list showed a name, a last-seen time and
// a Revoke button, which is everything except the answer to the only question
// anyone asks about a paired machine — "why can't I open this from here?"
//
// So it is shown. An operator reads their own row to find out what to
// install; an administrator reads someone else's to answer the support
// question without asking them to run anything.
//
// STALE IN THE SAFE DIRECTION, and said out loud. The report is a snapshot
// taken when the agent last ran, not a live query — the agent is not
// resident, so there is nothing to ask at the moment this renders. A tool
// installed five minutes ago is not in here until the next launch. The
// timestamp is therefore part of the data, not decoration.

// The agent reports discovery KINDS (cli/gui/browser); the console speaks in
// CHANNELS (cli/desktop/web). Same three things, two vocabularies, and the
// mapping lives in exactly one place so a rename cannot make the two screens
// disagree.
const KIND_CHANNEL = {
  cli: { short: 'CLI', icon: Terminal },
  gui: { short: 'Desktop', icon: Laptop },
  browser: { short: 'Web', icon: Globe },
}

const KIND_ORDER = ['cli', 'gui', 'browser']

function ChannelChip({ kind, present }) {
  const meta = KIND_CHANNEL[kind]
  if (!meta) return null
  const Icon = meta.icon
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-2xs font-medium',
        present
          ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
          : // Not a warning colour. A channel this machine does not have is
            // ordinary — most machines have one or two — and colouring every
            // absence amber makes a healthy laptop look broken.
            'border-surface-700 bg-surface-850 text-ink-500'
      )}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {meta.short}
    </span>
  )
}

// One resource type: which channels this machine has, and what it would take
// to have the others.
function TypeRow({ type }) {
  const kinds = Array.isArray(type.kinds) ? type.kinds : []
  const tools = Array.isArray(type.tools) ? type.tools : []
  // A browser candidate is never "missing" — opening a URL needs nothing
  // installed — so it must not be listed as something to go and install.
  const missing = (Array.isArray(type.missing) ? type.missing : []).filter((m) => m?.kind !== 'browser')

  return (
    <div className="py-2">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
        <span className="min-w-[7rem] font-mono text-xs text-ink-200">{type.resource_type}</span>
        <span className="flex flex-wrap items-center gap-1">
          {KIND_ORDER.filter((k) => kinds.includes(k) || missing.some((m) => m.kind === k)).map((k) => (
            <ChannelChip key={k} kind={k} present={kinds.includes(k)} />
          ))}
        </span>
        {tools.length > 0 && (
          <span className="text-2xs text-ink-500">
            found <span className="font-mono text-ink-400">{tools.join(', ')}</span>
          </span>
        )}
      </div>
      {missing.length > 0 && (
        <ul className="mt-1 space-y-0.5 pl-[7rem]">
          {missing.map((m) => (
            <li key={m.id} className="text-2xs leading-relaxed text-ink-500">
              <span className="font-mono text-ink-400">{m.command || m.id}</span> is not installed
              {m.install_hint ? <> — {m.install_hint}</> : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export function DeviceCapabilities({ device }) {
  const [open, setOpen] = useState(false)
  const caps = device?.capabilities
  const types = Array.isArray(caps?.types) ? caps.types : null

  // An agent too old to report capabilities, or one that has not run since
  // the field was added. Saying nothing here would read as "this machine can
  // open nothing", which is the opposite of what is known.
  if (!types) {
    return (
      <p className="mt-2 text-2xs leading-relaxed text-ink-500">
        This device has not reported what it can open. That is what an agent older than the
        capability report does; it will report on its next launch.
      </p>
    )
  }

  const openable = types.filter((t) => Array.isArray(t.kinds) && t.kinds.length > 0).length
  const canRecordDesktop = caps.screen_recorder === true
  const Chevron = open ? ChevronDown : ChevronRight

  return (
    <div className="mt-2">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          className="flex items-center gap-1 text-2xs font-medium text-ink-300 transition-colors hover:text-ink-100"
        >
          <Chevron className="h-3.5 w-3.5" aria-hidden="true" />
          Opens {openable} of {types.length} resource types
        </button>

        {/* ffmpeg is not a detail. It is the single thing that decides
            whether a desktop session on a record-required resource can be
            opened at all — the agent refuses such a launch without it, so a
            machine missing it looks like a machine with a broken button. */}
        <StatusIndicator tone={canRecordDesktop ? 'emerald' : 'amber'}>
          {canRecordDesktop ? (
            <>
              <Video className="h-3 w-3" aria-hidden="true" /> Can record desktop sessions
            </>
          ) : (
            <>
              <VideoOff className="h-3 w-3" aria-hidden="true" /> No ffmpeg — desktop sessions that must be
              recorded will be refused
            </>
          )}
        </StatusIndicator>

        {device.capabilities_at && (
          <span className="text-2xs text-ink-500" title={device.capabilities_at}>
            reported {formatRelativeToNow(device.capabilities_at)}
          </span>
        )}
      </div>

      {open && (
        <div className="mt-2 divide-y divide-surface-800 rounded-lg border border-surface-700/70 bg-surface-950/40 px-3 py-1">
          {[...types]
            .sort((a, b) => String(a.resource_type).localeCompare(String(b.resource_type)))
            .map((t) => (
              <TypeRow key={t.resource_type} type={t} />
            ))}
          <p className="py-2 text-2xs leading-relaxed text-ink-500">
            A snapshot from when the agent last ran, not a live query. Something installed since
            then appears here after the next launch.
          </p>
        </div>
      )}
    </div>
  )
}
