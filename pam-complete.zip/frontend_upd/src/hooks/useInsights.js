import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  getAwayDigest,
  markDigestSeen,
  getAuditInsights,
  getServiceInsights,
  getSessionInsights,
  getVaultInsights,
} from '../api/insights'

// ---------------------------------------------------------------------------
// Insight queries
// ---------------------------------------------------------------------------
// A strip of cards sits ABOVE the listing somebody came to the page to read.
// That ordering decides everything about how these are configured:
//
//   NEVER BLOCKING. The table renders on its own schedule; a slow aggregate
//     must not hold it up, so nothing here is awaited before the list.
//   NEVER LOUD ON FAILURE. If the figures do not load, the cards say so in
//     their own frame and the page still works. `retry: 1` rather than the
//     default three, because a decorative header retrying for half a minute
//     is a worse trade than showing "unavailable" quickly.
//   STALE IS FINE. These are counts over days and weeks. Re-fetching on every
//     window focus would cost a query per tab-switch to move a number that
//     has not changed.

const SHARED = {
  staleTime: 60_000,
  refetchOnWindowFocus: false,
  retry: 1,
}

export function useSessionInsights(enabled = true) {
  return useQuery({
    queryKey: ['insights', 'sessions'],
    queryFn: ({ signal }) => getSessionInsights(signal),
    enabled,
    ...SHARED,
    // Sessions are the one figure that is genuinely live — "what is running
    // right now" is stale the moment it is read — so this one refreshes on
    // its own, at the same cadence as the sessions listing beneath it.
    staleTime: 15_000,
    refetchInterval: 30_000,
  })
}

export function useAuditInsights(days = 30, enabled = true) {
  return useQuery({
    queryKey: ['insights', 'audit', days],
    queryFn: ({ signal }) => getAuditInsights(days, signal),
    enabled,
    ...SHARED,
  })
}

// The away digest is the one query here that is NOT decorative, so it does
// not share the settings above. It is answered once per visit and then
// dismissed: refetching it on an interval would make a card the operator has
// read reappear mid-scroll, and keeping it fresh has no value once it has
// been acknowledged.
export function useAwayDigest(enabled = true) {
  return useQuery({
    queryKey: ['insights', 'away'],
    queryFn: ({ signal }) => getAwayDigest(signal),
    enabled,
    staleTime: Infinity,
    refetchOnWindowFocus: false,
    retry: 1,
  })
}

// Dismissal is a real write with a real consequence — it moves an anchor that
// cannot be moved back — so it is NOT in the optimistic set (see
// lib/mutationPolicy.js). The card stays until the server confirms.
export function useMarkDigestSeen() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: markDigestSeen,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['insights', 'away'] })
    },
  })
}

export function useVaultInsights(enabled = true) {
  return useQuery({
    queryKey: ['insights', 'vault'],
    queryFn: ({ signal }) => getVaultInsights(signal),
    enabled,
    ...SHARED,
  })
}

export function useServiceInsights(enabled = true) {
  return useQuery({
    queryKey: ['insights', 'services'],
    queryFn: ({ signal }) => getServiceInsights(signal),
    enabled,
    ...SHARED,
  })
}
