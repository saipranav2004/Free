package apiclient

import (
	"crypto/ed25519"
	"errors"
	"fmt"
	"net"
	"strings"
	"time"

	"github.com/yourorg/pam-agent/internal/recorder"
)

// ── Retrying uploads ────────────────────────────────────────────────────────
//
// The upload used to be a single POST. One failure and the recording was gone
// permanently, which for the artefact an auditor asks for is not acceptable.
//
// Two rules make this worth having rather than just slower:
//
//	Retry only what could succeed later. A network error or a 5xx is worth
//	repeating; a 400 or a 401 is the server saying this request is wrong, and
//	repeating it wastes the operator's battery to arrive at the same answer.
//
//	Bound the wait. The agent may be holding a terminal window open while this
//	runs, so a few quick attempts, then hand the recording to the spool, which
//	will finish the job on the next agent start.

const (
	uploadAttempts    = 4
	uploadBaseBackoff = 750 * time.Millisecond
)

// UploadRecordingWithRetry is UploadRecordingArtifact with bounded retries.
func (c *Client) UploadRecordingWithRetry(sessionID, agentDeviceID string, privateKey ed25519.PrivateKey,
	blob []byte, format, mediaType, status, failureReason string, commands []recorder.Command,
	durationSeconds int) error {

	var lastErr error
	backoff := uploadBaseBackoff

	for attempt := 1; attempt <= uploadAttempts; attempt++ {
		err := c.uploadRecording(sessionID, agentDeviceID, privateKey, blob,
			format, mediaType, status, failureReason, commands, durationSeconds)
		if err == nil {
			return nil
		}
		lastErr = err

		if !uploadWorthRetrying(err) {
			return fmt.Errorf("upload refused by the server (not retried): %w", err)
		}
		if attempt == uploadAttempts {
			break
		}
		time.Sleep(backoff)
		backoff *= 2
	}
	return lastErr
}

// uploadWorthRetrying distinguishes "the network was unlucky" from "the server
// has read this and does not want it".
//
// Conservative on purpose: anything it cannot classify is treated as
// retryable, because spending four attempts on a request that was never going
// to work costs a few seconds, while giving up on one that would have worked
// costs the recording.
func uploadWorthRetrying(err error) bool {
	if err == nil {
		return false
	}
	var netErr net.Error
	if errors.As(err, &netErr) {
		return true
	}
	msg := err.Error()
	// doJSON and uploadRecording report a non-2xx as text carrying the code.
	for _, permanent := range []string{"400", "401", "403", "404", "409", "413", "422"} {
		if strings.Contains(msg, "status "+permanent) || strings.Contains(msg, "HTTP "+permanent) {
			return false
		}
	}
	return true
}
