//go:build linux || darwin

package launcher

import (
	"os"
	"os/exec"
	"testing"
	"time"
)

// A DESKTOP session must obey an administrator's force-terminate.
//
// This is the regression that matters most in this package, because every
// symptom of it pointed somewhere else. The heartbeat arrived, the agent
// logged "terminated_by_server", and the session row went COMPLETED — so from
// the console it looked done. On the operator's machine the application was
// still open with live database access, the screen capture was still running,
// and the recording was never uploaded, because the artifact is only written
// when this Wait returns. An ended session that is still running AND has no
// evidence is the worst of the three outcomes.
//
// The CLI path had honoured terminate since the heartbeat existed. The GUI
// path simply never called watchTerminate.
func TestADesktopLaunchIsKilledWhenTheServerSaysTerminate(t *testing.T) {
	// A stand-in for a desktop application: it would sit there for a very
	// long time, exactly like a GUI client waiting on its window.
	sleep, err := exec.LookPath("sleep")
	if err != nil {
		t.Skip("no sleep binary to stand in for a desktop app")
	}

	terminate := make(chan struct{})
	pc := &PreparedCommand{
		Exec:      sleep,
		Args:      []string{"120"},
		Env:       os.Environ(),
		Terminate: terminate,
	}

	done := make(chan struct{})
	go func() {
		_, _, _ = spawnGUIAndWait(pc)
		close(done)
	}()

	// Let it actually start before the instruction arrives, so this exercises
	// killing a RUNNING app rather than a race at startup.
	time.Sleep(300 * time.Millisecond)
	close(terminate)

	select {
	case <-done:
		// spawnGUIAndWait returned, which is what lets the caller stop the
		// screen capture, report the session and upload the recording.
	case <-time.After(10 * time.Second):
		t.Fatal("the desktop app outlived the terminate instruction: " +
			"spawnGUIAndWait never returned, so the session would stay open " +
			"with no recording uploaded")
	}
}

// And a launch with no heartbeat must still work. watchTerminate takes a nil
// channel for exactly this case, and a nil channel never fires — so a desktop
// app whose session has no terminate source must run to its own completion
// rather than being killed immediately.
func TestADesktopLaunchWithNoTerminateChannelRunsNormally(t *testing.T) {
	trueBin, err := exec.LookPath("true")
	if err != nil {
		t.Skip("no true binary")
	}
	pc := &PreparedCommand{Exec: trueBin, Env: os.Environ(), Terminate: nil}

	done := make(chan struct{})
	go func() {
		waited, _, spawnErr := spawnGUIAndWait(pc)
		if !waited {
			t.Errorf("waited = false for an app that started and exited cleanly")
		}
		if spawnErr != nil {
			t.Errorf("spawnGUIAndWait: %v", spawnErr)
		}
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(10 * time.Second):
		t.Fatal("a launch with no terminate channel hung")
	}
}
