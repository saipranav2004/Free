//go:build darwin || linux

// pam-agent/internal/launcher/wrapper.go
//
// The wrapper script that carries a CLI launch on macOS and Linux, and reports
// the session's end when the tool exits.
//
// WHY A WRAPPER AT ALL. Neither platform lets the agent wait for the session.
// macOS asks Terminal.app to run something via osascript, which returns the
// moment the AppleScript is delivered; most Linux terminal emulators
// (gnome-terminal, konsole, xfce4-terminal) are client/server and their CLI
// invocation returns immediately too. Only xterm genuinely blocks. So the
// agent process is usually gone long before the operator closes the window,
// and PAM was left holding a session marked ACTIVE forever — an admin had to
// end it by hand, and any recording obligation on it was never resolved.
//
// The fix inverts who reports. Instead of the agent waiting, the wrapper runs
// INSIDE the terminal, so it is still alive exactly as long as the session is.
// When the tool exits, the next line of the script runs, and that line tells
// PAM the session is over. It works with any terminal emulator on either
// platform, because it does not depend on the emulator's behaviour at all.
//
// IT ALSO KEEPS THE CREDENTIAL OUT OF ARGV. Environment for the tool is
// written as `export` lines inside a 0700 file rather than passed on a command
// line every process on the machine can read from `ps`. macOS already did this
// for that reason; routing Linux through the same wrapper extends it there.
//
// WHAT IT RUNS. Not the tool directly — `pam-agent relay -- <tool> <args>`.
// The wrapper alone fixes the lifecycle but not the evidence: recording and
// the clipboard/command controls need the agent IN the data path, and a shell
// that merely launches a tool and waits is not in it. The relay is: it holds a
// pseudo-terminal with the tool inside and passes every byte through itself,
// which is the same position the ConPTY relay occupies on Windows. See
// internal/launcher/relay_unix.go.
//
// The wrapper is still what makes that reachable, for the same reason it was
// written: it is the one thing guaranteed to be running inside the terminal
// the emulator opened, whatever that emulator does with its own process.
package launcher

import (
	"fmt"
	"os"
	"strings"
)

// EndReport is what the wrapper needs to hand the session to the relay.
//
// Empty SessionID means there is nothing to relay or report — a GUI launch has
// no terminal and no session to end, and runs the tool directly.
type EndReport struct {
	AgentPath string
	ServerURL string
	SessionID string

	// PolicyJSON is the data-protection policy, forwarded to the relay as-is.
	// Serialised by the caller so the wrapper never has to understand it.
	PolicyJSON string

	// Record asks the relay to capture and upload a session recording.
	Record bool

	// StartedMarker is a path the wrapper touches as its FIRST action, before
	// anything else can fail.
	//
	// It exists to tell two outcomes apart that are otherwise identical to
	// the caller: a terminal emulator that opened, ran the session and
	// returned the tool's exit status, and one that never opened at all and
	// returned its OWN. `xterm -e` with no usable DISPLAY is the second: it
	// exits non-zero in milliseconds, and the agent read that as "psql ran
	// and exited", printed "this session will close automatically when you
	// exit the tool", reported nothing, and left PAM holding an ACTIVE
	// session with a PENDING 0-byte recording — on every machine with no
	// display, which is every SSH login, every container, and any desktop
	// whose $DISPLAY is wrong.
	//
	// The marker is a FACT rather than a heuristic: either the wrapper got
	// far enough to touch a file inside the terminal, or no session ever
	// existed. Timing guesses ("it exited too fast to be real") would
	// misjudge both a slow display and an operator who closes the window
	// immediately.
	StartedMarker string

	// RelayRequired means this session carries an obligation the relay is the
	// only thing that can meet — a recording, or an active data-protection
	// policy. It decides what happens if the agent binary cannot be found at
	// launch time: a session with an obligation is refused, one without falls
	// back to running the tool directly.
	RelayRequired bool
}

func (r EndReport) usable() bool {
	return r.AgentPath != "" && r.ServerURL != "" && r.SessionID != ""
}

// writeSessionWrapper writes the 0700 launch script and returns its path.
//
// The caller is responsible for adding the path to pc.CleanupFiles — the file
// holds the session's credential in its environment block and must not be left
// behind.
func writeSessionWrapper(pc *PreparedCommand, report EndReport) (string, error) {
	var sb strings.Builder
	sb.WriteString("#!/bin/bash\n")

	// FIRST, before the credential exports and before anything that can
	// fail: proof that this script is running inside a terminal. See
	// EndReport.StartedMarker.
	if report.StartedMarker != "" {
		sb.WriteString(": > " + shellQuote(report.StartedMarker) + " 2>/dev/null || true\n")
	}

	for _, kv := range pc.Env {
		parts := strings.SplitN(kv, "=", 2)
		if len(parts) != 2 {
			continue
		}
		sb.WriteString(fmt.Sprintf("export %s=%s\n", parts[0], shellQuote(parts[1])))
	}

	command := shellQuote(pc.Exec)
	for _, a := range pc.Args {
		command += " " + shellQuote(a)
	}

	if !report.usable() {
		// A GUI launch: no terminal to relay through and no session to close,
		// so run the tool directly. `exec` replaces this shell rather than
		// leaving it hanging around for the life of the app.
		sb.WriteString("exec " + command + "\n")
	} else {
		// Hand the session to the relay rather than running the tool directly.
		//
		// The relay owns a pseudo-terminal with the tool inside it, which is
		// what gives macOS and Linux the three things a bare wrapper cannot:
		// an exact session end (it waits on the child), a recording (every
		// byte passes through it), and the clipboard and command controls.
		// It also reports the session end and uploads the recording itself,
		// because by then `launch` is long gone.
		//
		// `exec` IS correct here: the relay is the session for its whole
		// duration and does its own reporting afterwards, so there is nothing
		// for this shell to do once it has started — and one less process
		// sitting in the operator's terminal.
		agent := shellQuote(report.AgentPath)
		relay := agent + " relay" +
			" --session " + shellQuote(report.SessionID) +
			" --server " + shellQuote(report.ServerURL)
		if report.PolicyJSON != "" {
			relay += " --policy " + shellQuote(report.PolicyJSON)
		}
		if report.Record {
			relay += " --record"
		}

		// If the agent is not where it was when this script was written — moved,
		// upgraded, or on a disk that is no longer mounted — `exec` would fail
		// and bash would close the window instantly. The operator would see a
		// terminal flash and vanish, with no tool and no explanation. So the
		// path is checked first, and the failure is made legible.
		sb.WriteString("if [ ! -x " + agent + " ]; then\n")
		sb.WriteString("  echo 'PAM: the local agent is missing or not executable at' " + agent + " >&2\n")
		if report.RelayRequired {
			// This session is recorded or restricted, and the relay is the only
			// thing that can deliver either. Opening the tool anyway would hand
			// over a session that looks supervised and is not, which is worse
			// than not opening it: the operator, and the audit trail, would both
			// believe the controls were in force.
			sb.WriteString("  echo 'PAM: this session must be recorded or restricted, so it cannot be opened without the agent.' >&2\n")
			sb.WriteString("  echo 'PAM: reinstall the local agent from Settings and start the session again.' >&2\n")
			// Without the pause the window closes on the same instant it opens
			// and none of the above is ever read.
			sb.WriteString("  printf 'Press Enter to close... ' >&2\n")
			sb.WriteString("  read -r _ || true\n")
			sb.WriteString("  exit 1\n")
		} else {
			// Nothing to record and nothing to restrict, so the operator gets
			// their session. Only the lifecycle is at stake, and the older
			// report-end path still covers that.
			sb.WriteString("  echo 'PAM: opening the tool directly; session tracking may be delayed.' >&2\n")
			sb.WriteString("  " + command + "\n")
			sb.WriteString("  __pam_rc=$?\n")
			sb.WriteString(fmt.Sprintf(
				"  %s report-end --session %s --server %s --exit \"$__pam_rc\" >/dev/null 2>&1 || true\n",
				agent, shellQuote(report.SessionID), shellQuote(report.ServerURL)))
			sb.WriteString("  exit \"$__pam_rc\"\n")
		}
		sb.WriteString("fi\n")

		sb.WriteString("exec " + relay + " -- " + command + "\n")
	}

	f, err := os.CreateTemp("", "pam-agent-*.sh")
	if err != nil {
		return "", fmt.Errorf("failed to create wrapper script: %w", err)
	}
	defer f.Close()
	// Chmod before writing: the file must never exist, even briefly, with the
	// credential in it and permissions another user could read.
	if err := f.Chmod(0o700); err != nil {
		return "", fmt.Errorf("failed to set permissions on wrapper script: %w", err)
	}
	if _, err := f.WriteString(sb.String()); err != nil {
		return "", fmt.Errorf("failed to write wrapper script: %w", err)
	}
	return f.Name(), nil
}

// shellQuote wraps a value in single quotes for bash, escaping any single
// quote it contains. Every value interpolated into the wrapper goes through
// this — the script carries a live credential and is executed with the
// operator's own privileges, so an unquoted value with a space or a semicolon
// in it is a command injection into their shell.
func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}
