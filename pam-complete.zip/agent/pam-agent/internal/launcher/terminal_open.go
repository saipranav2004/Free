// pam-agent/internal/launcher/terminal_open.go
//
// DID THE TERMINAL ACTUALLY OPEN?
//
// A CLI launch on Unix does not run the tool directly: it writes a wrapper
// script and asks a terminal emulator to run it, and the relay inside that
// terminal is what records the session and reports its end. So the emulator
// starting is the whole session, and an emulator that fails to start looks,
// from the outside, exactly like one that opened and was closed again — both
// are "the process I ran returned a non-zero status".
//
// Getting that wrong is expensive in a way a launch failure is not: the agent
// believes a relay is out there and stays quiet, so PAM keeps an ACTIVE
// session with a PENDING recording that nothing will ever fill, and the
// operator is told the session will close itself. Nobody is told anything
// true.
package launcher

import (
	"fmt"
	"os"
	"time"
)

// wrapperStartTimeout bounds the wait for a terminal that was launched
// ASYNCHRONOUSLY.
//
// Most terminal emulators are client/server and return the instant the
// window is requested — every one on Linux except xterm, and macOS's
// `open -a Terminal` always. So "is the marker there?" cannot be asked the
// moment the command returns; at that point the window has not opened yet
// even on a healthy machine, and answering no would fail every launch on
// GNOME, KDE and macOS. It has to be WAITED for.
//
// Ten seconds because the cost is asymmetric. Waiting slightly too long on
// a machine that is genuinely broken delays an error message; giving up too
// early on a cold-starting Terminal.app turns a working session into a
// reported failure, which is far worse than the bug being fixed. The normal
// case does not pay it: the poll returns as soon as the marker appears,
// which is well under a second.
const wrapperStartTimeout = 10 * time.Second

// wrapperStarted reports whether the session wrapper ran far enough to touch
// its marker — i.e. whether a terminal really opened.
//
// For a command that has already exited (xterm, which blocks for the life
// of the window): if the marker is not there now, it never will be.
func wrapperStarted(markerPath string) bool {
	if markerPath == "" {
		// No marker was asked for, so nothing can be concluded. Treated as
		// started, which preserves the previous behaviour rather than turning
		// every launch into a failure on a platform that has not adopted it.
		return true
	}
	_, err := os.Stat(markerPath)
	return err == nil
}

// waitForWrapperStart is wrapperStarted for a terminal launched
// asynchronously: it polls until the marker appears or the timeout expires.
func waitForWrapperStart(markerPath string, timeout time.Duration) bool {
	if markerPath == "" {
		return true
	}
	deadline := time.Now().Add(timeout)
	for {
		if wrapperStarted(markerPath) {
			return true
		}
		if time.Now().After(deadline) {
			return false
		}
		time.Sleep(wrapperStartPollInterval)
	}
}

// wrapperStartPollInterval is short enough that the success path is not
// noticeably delayed and long enough not to spin.
const wrapperStartPollInterval = 100 * time.Millisecond

// TerminalNeverOpenedError is a launch that failed before the session began.
//
// Distinct from ToolExitError, which is a session that HAPPENED and finished.
// The caller reports this one FAILED and tells the operator; it reports a
// tool exit as COMPLETED with the status as context.
type TerminalNeverOpenedError struct {
	// Emulator is what was tried, e.g. "xterm".
	Emulator string
	// ExitCode is its exit status, when it had one. Named ExitCode rather
	// than Code because Code() is the method cmd/pam-agent's
	// describedFailure interface requires, and a field and a method cannot
	// share a name.
	ExitCode int
	// Display is $DISPLAY as the agent saw it — empty is the common cause and
	// naming it saves the operator guessing.
	Display string
}

func (e *TerminalNeverOpenedError) Error() string {
	if e.Display == "" {
		return fmt.Sprintf("%s could not open a terminal window: no X display is set ($DISPLAY is empty)", e.Emulator)
	}
	// A client/server emulator reports SUCCESS and returns the instant it
	// has handed the script to its daemon, so a zero status here means the
	// hand-off was accepted and the session still never started —
	// "(exit status 0)" on a failure message reads like a contradiction and
	// sends the reader looking for the wrong thing.
	if e.ExitCode == 0 {
		return fmt.Sprintf(
			"%s reported success on display %s but no terminal window ever ran the session",
			e.Emulator, e.Display)
	}
	return fmt.Sprintf("%s could not open a terminal window on display %s (exit status %d)", e.Emulator, e.Display, e.ExitCode)
}

// Reason, Hint and Code make this legible in the console, through
// cmd/pam-agent's describedFailure interface.
func (e *TerminalNeverOpenedError) Reason() string {
	if e.Display == "" {
		return "This session opens in a terminal window, and there is no graphical display on this machine to open one in " +
			"($DISPLAY is not set — which is normal over SSH, in a container, or on a server)."
	}
	return fmt.Sprintf("This session opens in a terminal window, and %s could not open one on display %s.", e.Emulator, e.Display)
}

func (e *TerminalNeverOpenedError) Hint() string {
	return "Open this resource in the browser through PAM instead, which needs nothing installed — " +
		"or run this from a desktop session where a terminal can open."
}

func (e *TerminalNeverOpenedError) Code() string { return "terminal_never_opened" }
