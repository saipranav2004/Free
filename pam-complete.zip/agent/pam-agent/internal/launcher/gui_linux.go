//go:build linux

// pam-agent/internal/launcher/gui_linux.go
package launcher

import (
	"os"
	"os/exec"
)

// spawnGUIAndWait opens a desktop application and blocks until it exits, so
// the caller can report the session's real end.
//
// See gui_darwin.go for the reasoning; it applies identically here. Linux
// needs no `open`-style indirection: the template names the executable, this
// process starts it, and waiting on that child is exactly right.
//
// KNOWN LIMIT, same shape as macOS: an application that is really a shell
// script or launcher which re-execs and exits (some vendor-packaged Java
// tools do this) is observed as finishing immediately. The session then ends
// early rather than late. Where that matters, point the template at the real
// binary rather than the launcher; discovery.Spec already supports naming an
// exact path.
func spawnGUIAndWait(pc *PreparedCommand) (waited bool, enforcement Summary, err error) {
	c := exec.Command(pc.Exec, pc.Args...)
	c.Env = append(os.Environ(), pc.Env...)
	if startErr := c.Start(); startErr != nil {
		return false, enforcement, startErr
	}
	// An administrator's force-terminate has to reach a DESKTOP session too.
	//
	// The CLI path has done this since the heartbeat existed (see
	// spawn_linux.go); the GUI path never called it, and the gap was invisible
	// because everything else looked right: the heartbeat arrived, the agent
	// logged "terminated_by_server", and the row went COMPLETED. Measured on
	// a real RedisInsight session — the window stayed open, the operator kept
	// their database access, ffmpeg kept recording, and because the artifact
	// is only uploaded when this Wait returns, the recording stayed PENDING
	// at 0 bytes. An ended session that is still running and has no evidence
	// is the worst of the three possible outcomes.
	//
	// Killing the process unblocks the Wait below, so the ordinary
	// end-of-session path runs unchanged: stop the screen capture, report the
	// session, upload what was captured.
	stopKiller := watchTerminate(pc.Terminate, c)
	defer stopKiller()

	// The tool's own exit status is not a launch failure — the session
	// happened and has to be closed. Discarded for the same reason the cli
	// path does not treat a non-zero psql as a failed launch.
	_ = c.Wait()
	return true, enforcement, nil
}
