package launcher

import (
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/discovery"
)

// AN EMPTY PASSWORD MEANS "DO NOT AUTHENTICATE", NOT "AUTHENTICATE WITH
// NOTHING".
//
// redis-cli sends an AUTH command whenever REDISCLI_AUTH is PRESENT, whatever
// its value, so setting it to "" made a redis with no requirepass answer
// "Client sent AUTH, but no password is set". The operator saw an
// authentication error against a server that needs no authentication, which
// reads as PAM holding the wrong credential rather than none.
func TestAnEmptyPasswordDoesNotSetTheCredentialEnvVar(t *testing.T) {
	cand := Candidate{
		ID: "redis-cli", Kind: "cli", Command: "redis-cli",
		Args:                []string{"-h", "{{.Host}}", "-p", "{{.Port}}"},
		CredentialInjection: "env",
		CredentialEnvVar:    "REDISCLI_AUTH",
	}
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "redis", Host: "127.0.0.1", Port: 6379,
		AccountName: "default", Password: "",
	}

	cmd, err := buildCommand(resolved, &cand, discovery.Result{Path: "/usr/bin/redis-cli"}, t.TempDir())
	if err != nil {
		t.Fatalf("buildCommand: %v", err)
	}

	for _, kv := range cmd.Env {
		if strings.HasPrefix(kv, "REDISCLI_AUTH") {
			t.Errorf("REDISCLI_AUTH must not be set at all when there is no password, got %q", kv)
		}
	}
	// And the operator is not left guessing why: an empty vaulted password is
	// legitimate AND is what an unfinished vault entry looks like.
	if len(cmd.Notes) == 0 {
		t.Error("an empty credential should leave a note explaining what was skipped")
	}
	joined := strings.Join(cmd.Notes, " ")
	if !strings.Contains(joined, "REDISCLI_AUTH") || !strings.Contains(joined, "without authenticating") {
		t.Errorf("the note should name the variable and what will happen: %q", joined)
	}
}

// The normal case must be untouched.
func TestARealPasswordStillSetsTheCredentialEnvVar(t *testing.T) {
	cand := Candidate{
		ID: "redis-cli", Kind: "cli", Command: "redis-cli",
		CredentialInjection: "env", CredentialEnvVar: "REDISCLI_AUTH",
	}
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "redis", Host: "127.0.0.1", Port: 6379, Password: "s3cret",
	}

	cmd, err := buildCommand(resolved, &cand, discovery.Result{Path: "/usr/bin/redis-cli"}, t.TempDir())
	if err != nil {
		t.Fatalf("buildCommand: %v", err)
	}
	var found bool
	for _, kv := range cmd.Env {
		if kv == "REDISCLI_AUTH=s3cret" {
			found = true
		}
	}
	if !found {
		t.Errorf("a real password must still be injected, got env %v", cmd.Env)
	}
	if len(cmd.Notes) != 0 {
		t.Errorf("the normal path should leave no notes, got %v", cmd.Notes)
	}
}

// The credential must never reach argv, empty or not — an empty password is
// not a reason to fall back to a command line.
func TestAnEmptyPasswordNeverReachesArgv(t *testing.T) {
	cand := Candidate{
		ID: "redis-cli", Kind: "cli", Command: "redis-cli",
		Args:                []string{"-h", "{{.Host}}"},
		CredentialInjection: "env", CredentialEnvVar: "REDISCLI_AUTH",
	}
	resolved := &apiclient.ResolvedLaunch{ResourceType: "redis", Host: "127.0.0.1", Port: 6379}
	cmd, err := buildCommand(resolved, &cand, discovery.Result{Path: "/usr/bin/redis-cli"}, t.TempDir())
	if err != nil {
		t.Fatalf("buildCommand: %v", err)
	}
	for _, a := range cmd.Args {
		if strings.Contains(strings.ToLower(a), "auth") || a == "-a" {
			t.Errorf("no auth flag should appear in argv, got %v", cmd.Args)
		}
	}
}
