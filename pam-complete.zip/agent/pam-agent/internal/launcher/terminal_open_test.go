package launcher

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// The discriminator itself. Everything else in this file depends on it being
// a FACT about whether a terminal ran, not a guess.
func TestWrapperStartedIsAFactNotAGuess(t *testing.T) {
	dir := t.TempDir()
	marker := filepath.Join(dir, "started")

	if wrapperStarted(marker) {
		t.Error("nothing has run, so the wrapper cannot have started")
	}
	if err := os.WriteFile(marker, nil, 0o600); err != nil {
		t.Fatal(err)
	}
	if !wrapperStarted(marker) {
		t.Error("the marker exists, so the wrapper ran")
	}

	// A platform that has not adopted the marker must keep its old behaviour
	// rather than reporting every launch as a failure.
	if !wrapperStarted("") {
		t.Error("with no marker asked for, nothing can be concluded and the launch must not be failed")
	}
}

// The wrapper has to touch the marker BEFORE anything that can fail —
// including the credential exports, which is where a bad value would abort
// the script.
func TestWrapperTouchesItsMarkerFirst(t *testing.T) {
	pc := &PreparedCommand{
		Exec:      "/usr/bin/psql",
		Args:      []string{"-h", "127.0.0.1"},
		Env:       []string{"PGPASSWORD=secret-value"},
		AgentPath: "/usr/local/bin/pam-agent",
		ServerURL: "https://pam.example.com",
		SessionID: "sess-1",
	}
	path, err := writeSessionWrapper(pc, EndReport{
		AgentPath: pc.AgentPath, ServerURL: pc.ServerURL, SessionID: pc.SessionID,
		StartedMarker: "/tmp/pam-agent-started-sess-1",
	})
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(path)

	body, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	script := string(body)

	markerAt := strings.Index(script, "pam-agent-started-sess-1")
	if markerAt < 0 {
		t.Fatal("the wrapper does not touch its marker at all")
	}
	if exportAt := strings.Index(script, "export PGPASSWORD"); exportAt >= 0 && markerAt > exportAt {
		t.Error("the marker must be touched before the credential exports, which can themselves fail")
	}
	// The shebang is the only thing allowed to come first.
	firstLine := strings.SplitN(script, "\n", 2)[0]
	if !strings.HasPrefix(firstLine, "#!") {
		t.Errorf("unexpected first line %q", firstLine)
	}
}

// A wrapper asked for no marker must not have one, so the script stays
// byte-identical on a platform that has not adopted this.
func TestWrapperWithoutAMarkerIsUnchanged(t *testing.T) {
	pc := &PreparedCommand{
		Exec: "/usr/bin/psql", AgentPath: "/usr/local/bin/pam-agent",
		ServerURL: "https://pam.example.com", SessionID: "sess-2",
	}
	path, err := writeSessionWrapper(pc, EndReport{
		AgentPath: pc.AgentPath, ServerURL: pc.ServerURL, SessionID: pc.SessionID,
	})
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(path)
	body, _ := os.ReadFile(path)
	if strings.Contains(string(body), "pam-agent-started-") {
		t.Error("no marker was asked for, so none should be written")
	}
}

// What the operator is told. This error exists because the previous message
// was "psql exited with code 1" — which sends them to look at psql.
func TestTerminalNeverOpenedExplainsItself(t *testing.T) {
	noDisplay := &TerminalNeverOpenedError{Emulator: "xterm", ExitCode: 1, Display: ""}
	if !strings.Contains(noDisplay.Error(), "no X display") {
		t.Errorf("the empty-display case must name the cause: %v", noDisplay)
	}
	if !strings.Contains(noDisplay.Reason(), "$DISPLAY") {
		t.Errorf("the reason should name the variable an operator can check: %q", noDisplay.Reason())
	}
	// SSH and containers are the common cases and saying so stops the
	// operator hunting for a broken install.
	if !strings.Contains(noDisplay.Reason(), "SSH") {
		t.Errorf("the reason should say where this normally happens: %q", noDisplay.Reason())
	}
	// The hint has to offer the route that DOES work, not just describe the
	// obstacle.
	if !strings.Contains(strings.ToLower(noDisplay.Hint()), "browser") {
		t.Errorf("the hint should point at the brokered browser route: %q", noDisplay.Hint())
	}
	if noDisplay.Code() != "terminal_never_opened" {
		t.Errorf("code = %q", noDisplay.Code())
	}

	// A display that exists but could not be opened is a different sentence.
	broken := &TerminalNeverOpenedError{Emulator: "gnome-terminal", ExitCode: 3, Display: ":1"}
	if !strings.Contains(broken.Error(), ":1") || !strings.Contains(broken.Error(), "gnome-terminal") {
		t.Errorf("the message should name the display and the emulator: %v", broken)
	}
}

// It must be recognised by the interface cmd/pam-agent reports through, or
// the console gets a generic "launch_failed" and none of the above text.
func TestTerminalNeverOpenedSatisfiesTheDescribedFailureShape(t *testing.T) {
	var e interface {
		Reason() string
		Hint() string
		Code() string
	} = &TerminalNeverOpenedError{Emulator: "xterm"}
	if e.Code() == "" || e.Reason() == "" || e.Hint() == "" {
		t.Error("all three must be populated for the console to render the failure")
	}
}

// ── The asynchronous case, which the first version of this got wrong ──────
//
// Of the emulators the Linux path tries, only xterm blocks; gnome-terminal,
// konsole and xfce4-terminal all return as soon as the window is requested,
// and macOS's `open -a Terminal` always does. So the marker cannot be checked
// the instant the command returns — at that point the wrapper has not run yet
// even on a healthy machine, and a single check would report every launch on
// GNOME, KDE and macOS as a failure.
//
// That bug was in the first version of this file and was invisible in testing
// because xterm is first in the candidate list and does block.

func TestWaitForWrapperStartReturnsAsSoonAsTheMarkerAppears(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "started")

	// A terminal that takes a moment to come up, as a cold Terminal.app does.
	go func() {
		time.Sleep(150 * time.Millisecond)
		_ = os.WriteFile(marker, nil, 0o600)
	}()

	start := time.Now()
	if !waitForWrapperStart(marker, 5*time.Second) {
		t.Fatal("a terminal that started 150ms later must still count as started")
	}
	elapsed := time.Since(start)
	if elapsed > 2*time.Second {
		t.Errorf("the wait should return as soon as the marker appears, took %v", elapsed)
	}
	if elapsed < 100*time.Millisecond {
		t.Errorf("it returned before the marker could exist (%v) — is it checking at all?", elapsed)
	}
}

func TestWaitForWrapperStartGivesUpOnlyAfterTheTimeout(t *testing.T) {
	marker := filepath.Join(t.TempDir(), "never")
	start := time.Now()
	if waitForWrapperStart(marker, 300*time.Millisecond) {
		t.Fatal("no terminal ever ran, so this must not report started")
	}
	if elapsed := time.Since(start); elapsed < 250*time.Millisecond {
		t.Errorf("it gave up after %v, before the timeout — a slow terminal would be failed", elapsed)
	}
}

// A platform that has not adopted the marker must not be made to wait, and
// must not be failed.
func TestWaitForWrapperStartIsANoOpWithoutAMarker(t *testing.T) {
	start := time.Now()
	if !waitForWrapperStart("", 5*time.Second) {
		t.Error("with no marker asked for, nothing can be concluded")
	}
	if time.Since(start) > time.Second {
		t.Error("it should not wait when there is no marker to wait for")
	}
}

// A client/server emulator that reports success and runs nothing must not be
// described as "(exit status 0)" — on a failure message that reads as a
// contradiction and sends the reader looking for the wrong thing.
func TestASuccessfulEmulatorThatRanNothingIsDescribedHonestly(t *testing.T) {
	e := &TerminalNeverOpenedError{Emulator: "gnome-terminal", ExitCode: 0, Display: ":0"}
	msg := e.Error()
	if strings.Contains(msg, "exit status 0") {
		t.Errorf("a zero status must not be reported as the failure: %q", msg)
	}
	if !strings.Contains(msg, "no terminal window ever ran the session") {
		t.Errorf("the message should say what actually did not happen: %q", msg)
	}
	// A genuine non-zero status still carries it, because that is a real clue.
	nonZero := &TerminalNeverOpenedError{Emulator: "xterm", ExitCode: 1, Display: ":0"}
	if !strings.Contains(nonZero.Error(), "exit status 1") {
		t.Errorf("a real status should be reported: %q", nonZero.Error())
	}
}
