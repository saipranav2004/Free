// pam-agent/internal/notify.go
//
// SAYING SOMETHING ON THE MACHINE ITSELF when a launch fails.
//
// The operating system starts `pam-agent launch` from a pam-agent:// URL with
// no terminal attached, so everything the agent writes to stderr goes
// nowhere. cmd/pam-agent/failure.go solves half of that by putting the
// explanation on the session-end report, where the console can render it —
// but the operator is not looking at the console's audit trail. They are
// looking at the desktop where they just clicked a button, and from there a
// failed launch and a slow launch are the same thing: nothing.
//
// This is the other half: one native desktop notification, on the machine,
// naming what went wrong. It does not replace the server-side report (which
// is the durable, auditable record); it is what makes the operator stop
// waiting.
//
// THREE RULES, because a diagnostic that misbehaves is worse than none:
//
//  1. Best-effort, always. Every failure to notify is swallowed. A machine
//     with no notification daemon, a locked screen, a headless box — none of
//     it may turn a reported launch failure into a crash, and none of it may
//     delay the process exiting.
//  2. Nothing is ever passed through a shell. The commands are built as argv
//     and the text is escaped for the two scripting languages that
//     unavoidably receive it as source (AppleScript via osascript, PowerShell
//     via -Command). Some of this text comes from the SERVER — a policy
//     reason, an install hint — so it is treated as untrusted input, not as
//     something the agent authored.
//  3. Silence where there is nobody to tell. On Linux, no DISPLAY and no
//     WAYLAND_DISPLAY means no desktop session, and a notification would at
//     best be queued for a future one.
package notify

import (
	"context"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"
	"unicode"
)

// timeout bounds the notifier. A notification tool that hangs must not hold a
// launch process open: the session is already over by the time this runs.
const timeout = 5 * time.Second

// maxTextRunes clamps what is displayed. Notification daemons truncate
// differently and a wall of text in a toast is unreadable anyway; the full
// explanation is in the console and in the agent log.
const maxTextRunes = 300

// Alert shows one notification, best-effort.
//
// title is the short summary the notifier renders first ("PAM could not open
// this session"); body is the sentence that tells the operator what happened
// and what to do next. Used for a launch that failed and for a session an
// administrator ended — both are moments where the desktop, on its own, tells
// the operator nothing at all.
func Alert(title, body string) {
	argv, ok := commandFor(runtime.GOOS, os.Getenv, exec.LookPath, title, body)
	if !ok {
		return
	}
	run(argv)
}

func run(argv []string) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	// Detached from this process's own streams: a notifier that writes to
	// stdout would interleave with a CLI session's own output.
	cmd.Stdout, cmd.Stderr, cmd.Stdin = nil, nil, nil
	_ = cmd.Run()
}

// commandFor builds the notifier invocation for one OS.
//
// The OS, the environment and the PATH lookup are all parameters so that
// every platform's command — and the choice between the several Linux
// notifiers — can be asserted from any machine. The alternative is what the
// rest of this agent had to learn the hard way: per-OS code that only its own
// platform can ever execute is per-OS code nothing verifies.
//
// Returns ok=false when there is nothing to notify with, or nobody to notify.
func commandFor(goos string, env func(string) string, look func(string) (string, error), title, body string) ([]string, bool) {
	title = sanitize(title)
	body = sanitize(body)
	if title == "" && body == "" {
		return nil, false
	}

	switch goos {
	case "linux":
		// No display server means no desktop session to show this in.
		if env("DISPLAY") == "" && env("WAYLAND_DISPLAY") == "" {
			return nil, false
		}
		// In preference order: the freedesktop notification tool, then the
		// two desktop-environment dialog tools, then X's own last resort.
		// notify-send first because it is the only one that does NOT steal
		// focus from whatever the operator is doing.
		if _, err := look("notify-send"); err == nil {
			return []string{
				"notify-send",
				"--app-name=PAM",
				// Normal, not critical: a critical notification on GNOME
				// stays on screen until dismissed, which is the wrong weight
				// for "the tool you wanted is not installed".
				"--urgency=normal",
				"--icon=dialog-error",
				title,
				body,
			}, true
		}
		if _, err := look("zenity"); err == nil {
			return []string{"zenity", "--error", "--title=PAM", "--no-markup", "--text=" + joinText(title, body)}, true
		}
		if _, err := look("kdialog"); err == nil {
			return []string{"kdialog", "--title", "PAM", "--error", joinText(title, body)}, true
		}
		if _, err := look("xmessage"); err == nil {
			return []string{"xmessage", "-center", "-timeout", "30", joinText(title, body)}, true
		}
		return nil, false

	case "darwin":
		// `display notification`, not `display dialog`: a dialog is modal,
		// blocks until someone dismisses it, and would hold this process open
		// for as long as the operator is away from the machine. A
		// notification can be suppressed by a Focus mode, which is the
		// accepted cost — the console still has the full report.
		script := "display notification " + appleScriptString(body) +
			" with title " + appleScriptString("PAM") +
			" subtitle " + appleScriptString(title)
		return []string{"osascript", "-e", script}, true

	case "windows":
		// A MessageBox rather than a toast. A Windows toast has to be posted
		// by an application with a registered AppUserModelID; pam-agent is
		// launched transiently by the shell as a URL handler and has none, so
		// a toast either does not appear or appears attributed to PowerShell.
		// System.Windows.Forms is present on every desktop Windows.
		//
		// -NoProfile so a user's PowerShell profile cannot slow this down or
		// interfere; -WindowStyle Hidden so no console flashes up behind it.
		script := "Add-Type -AssemblyName System.Windows.Forms; " +
			"[void][System.Windows.Forms.MessageBox]::Show(" +
			powerShellString(joinText(title, body)) + "," +
			powerShellString("PAM") + ",'OK','Error')"
		return []string{"powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", script}, true

	default:
		return nil, false
	}
}

func joinText(title, body string) string {
	switch {
	case title == "":
		return body
	case body == "":
		return title
	default:
		return title + "\n\n" + body
	}
}

// sanitize strips what must never reach a notifier and bounds the length.
//
// Control characters go first: they are what a crafted "reason" string would
// use to break out of a quoted script literal or to forge extra lines in a
// dialog. Newlines are kept as spaces — a notification is one or two lines,
// and a body containing a literal newline renders inconsistently across
// daemons.
func sanitize(s string) string {
	s = strings.TrimSpace(s)
	var b strings.Builder
	runes := 0
	for _, r := range s {
		if runes >= maxTextRunes {
			b.WriteString("…")
			break
		}
		switch {
		case r == '\n' || r == '\r' || r == '\t':
			b.WriteRune(' ')
		case unicode.IsControl(r):
			// Dropped entirely, including the escape character.
			continue
		default:
			b.WriteRune(r)
		}
		runes++
	}
	// Collapse the runs of spaces the substitutions above can create.
	return strings.Join(strings.Fields(b.String()), " ")
}

// appleScriptString renders a Go string as an AppleScript string literal.
// AppleScript has exactly two escapes inside a double-quoted literal:
// backslash and double quote. Backslash is replaced first, or the escape
// inserted for a quote would itself be escaped.
func appleScriptString(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	return `"` + s + `"`
}

// powerShellString renders a Go string as a PowerShell SINGLE-quoted literal.
//
// Single quotes, not double: PowerShell performs no expansion inside a
// single-quoted string, so `$(...)`, `$env:…` and backticks in the text are
// inert. The only escape needed is a single quote, written by doubling it.
// A double-quoted literal would make every one of those an execution vector
// for text that can come from the server.
func powerShellString(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "''") + "'"
}
