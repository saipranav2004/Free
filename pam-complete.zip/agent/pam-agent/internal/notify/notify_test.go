package notify

import (
	"errors"
	"strings"
	"testing"
)

// Fake PATH lookups, so the Linux preference order can be exercised without
// installing four notification tools.
func have(names ...string) func(string) (string, error) {
	set := map[string]bool{}
	for _, n := range names {
		set[n] = true
	}
	return func(name string) (string, error) {
		if set[name] {
			return "/usr/bin/" + name, nil
		}
		return "", errors.New("not found")
	}
}

func envWith(pairs map[string]string) func(string) string {
	return func(k string) string { return pairs[k] }
}

var onX = envWith(map[string]string{"DISPLAY": ":0"})

func TestLinuxPrefersNotifySend(t *testing.T) {
	argv, ok := commandFor("linux", onX, have("notify-send", "zenity", "kdialog", "xmessage"),
		"psql is not installed", "Install the PostgreSQL client, or open this resource in the browser instead.")
	if !ok {
		t.Fatal("expected a command")
	}
	if argv[0] != "notify-send" {
		t.Fatalf("notify-send must win when present, got %q", argv[0])
	}
	// The title and body are separate arguments, in that order — notify-send
	// renders the first as the summary and the second as the body.
	if argv[len(argv)-2] != "psql is not installed" {
		t.Errorf("title argument = %q", argv[len(argv)-2])
	}
	if !strings.Contains(argv[len(argv)-1], "PostgreSQL client") {
		t.Errorf("body argument = %q", argv[len(argv)-1])
	}
	joined := strings.Join(argv, " ")
	if !strings.Contains(joined, "--app-name=PAM") {
		t.Error("the notification must be attributed to PAM")
	}
	// Critical urgency would stay on screen until dismissed on GNOME.
	if strings.Contains(joined, "critical") {
		t.Error("urgency must not be critical")
	}
}

func TestLinuxFallsBackThroughTheDialogTools(t *testing.T) {
	for _, c := range []struct {
		installed []string
		want      string
	}{
		{[]string{"zenity", "kdialog", "xmessage"}, "zenity"},
		{[]string{"kdialog", "xmessage"}, "kdialog"},
		{[]string{"xmessage"}, "xmessage"},
	} {
		argv, ok := commandFor("linux", onX, have(c.installed...), "title", "body")
		if !ok {
			t.Fatalf("with %v installed, expected a command", c.installed)
		}
		if argv[0] != c.want {
			t.Errorf("with %v installed, chose %q, want %q", c.installed, argv[0], c.want)
		}
		// The fallbacks take ONE text argument, so the title must not be
		// silently dropped on the way.
		if !strings.Contains(strings.Join(argv, " "), "title") {
			t.Errorf("%s: the title was lost: %v", c.want, argv)
		}
	}
}

func TestLinuxWithNoNotifierAtAll(t *testing.T) {
	if _, ok := commandFor("linux", onX, have(), "title", "body"); ok {
		t.Error("with no notifier installed there is nothing to run")
	}
}

// A headless machine has nobody to notify. Attempting it anyway would queue a
// notification for whoever logs in next, which is both useless and a small
// information leak onto a shared machine.
func TestLinuxHeadlessIsSilent(t *testing.T) {
	if _, ok := commandFor("linux", envWith(nil), have("notify-send"), "title", "body"); ok {
		t.Error("no DISPLAY and no WAYLAND_DISPLAY must mean no notification")
	}
	if _, ok := commandFor("linux", envWith(map[string]string{"WAYLAND_DISPLAY": "wayland-0"}), have("notify-send"), "t", "b"); !ok {
		t.Error("a Wayland session must still be notified")
	}
}

func TestMacOSUsesANotificationNotADialog(t *testing.T) {
	argv, ok := commandFor("darwin", envWith(nil), have(), "sqlplus could not start", "Oracle Instant Client is missing.")
	if !ok {
		t.Fatal("expected a command")
	}
	if argv[0] != "osascript" || argv[1] != "-e" {
		t.Fatalf("expected osascript -e, got %v", argv[:2])
	}
	script := argv[2]
	if !strings.HasPrefix(script, "display notification ") {
		t.Errorf("must use display notification, got %q", script)
	}
	// `display dialog` blocks until dismissed and would hold the process
	// open for as long as the operator is away from the machine.
	if strings.Contains(script, "display dialog") {
		t.Error("must never use a modal dialog")
	}
	if !strings.Contains(script, `with title "PAM"`) {
		t.Errorf("the notification must be titled PAM, got %q", script)
	}
	if !strings.Contains(script, "Oracle Instant Client is missing.") {
		t.Errorf("the body was lost: %q", script)
	}
}

func TestWindowsUsesAMessageBoxWithNoProfile(t *testing.T) {
	argv, ok := commandFor("windows", envWith(nil), have(), "mongosh is not installed", "Install MongoDB Shell.")
	if !ok {
		t.Fatal("expected a command")
	}
	if argv[0] != "powershell" {
		t.Fatalf("expected powershell, got %q", argv[0])
	}
	joined := strings.Join(argv, " ")
	for _, want := range []string{"-NoProfile", "-NonInteractive", "-WindowStyle Hidden", "MessageBox", "mongosh is not installed"} {
		if !strings.Contains(joined, want) {
			t.Errorf("missing %q in %v", want, argv)
		}
	}
}

func TestUnsupportedPlatformIsSilent(t *testing.T) {
	if _, ok := commandFor("plan9", envWith(nil), have("notify-send"), "t", "b"); ok {
		t.Error("an unsupported platform must produce no command")
	}
}

// ── The escaping, which is the part that matters ──────────────────────────
//
// Some of this text comes from the SERVER: a policy reason on a terminated
// session, an install hint from a launch template. It reaches AppleScript and
// PowerShell as SOURCE, so it is treated as untrusted input.

func TestAppleScriptTextCannotBreakOutOfItsLiteral(t *testing.T) {
	// A quote would close the literal; a backslash would escape the closing
	// quote. Both are the classic way out.
	argv, _ := commandFor("darwin", envWith(nil), have(),
		`he said "hi"`, `a back\slash and "a quote"`)
	script := argv[2]
	if strings.Contains(script, `"hi"`) {
		t.Errorf("an unescaped quote survived into the script: %q", script)
	}
	if !strings.Contains(script, `\"hi\"`) {
		t.Errorf("the quote should be escaped, got %q", script)
	}
	if !strings.Contains(script, `back\\slash`) {
		t.Errorf("the backslash should be doubled, got %q", script)
	}
	// The literal count is the real invariant: three balanced literals
	// (body, title, subtitle) and nothing else.
	if n := strings.Count(script, `"`) - strings.Count(script, `\"`); n != 6 {
		t.Errorf("expected 6 unescaped quotes (3 balanced literals), got %d in %q", n, script)
	}
}

func TestPowerShellTextIsInert(t *testing.T) {
	// Every one of these executes inside a DOUBLE-quoted PowerShell string.
	// Inside a single-quoted one they are literal text, which is why the
	// implementation uses single quotes.
	argv, _ := commandFor("windows", envWith(nil), have(),
		"it's broken", `$(Remove-Item C:\) $env:USERNAME and a `+"`"+`backtick`)
	script := argv[len(argv)-1]
	if !strings.Contains(script, "it''s broken") {
		t.Errorf("a single quote must be doubled, got %q", script)
	}
	// No double-quoted literal anywhere: that is what keeps $(...) inert.
	if strings.Contains(script, `"`) {
		t.Errorf("no double-quoted literals may be emitted, got %q", script)
	}
}

func TestControlCharactersAreStripped(t *testing.T) {
	// ESC is what would be used to forge terminal output or, in a dialog,
	// to inject a second line that looks like it came from PAM.
	got := sanitize("before\x1b[31m after\x00\x07 end")
	if strings.ContainsAny(got, "\x1b\x00\x07") {
		t.Errorf("control characters survived: %q", got)
	}
	if got != "before[31m after end" {
		t.Errorf("sanitize = %q", got)
	}
}

func TestNewlinesBecomeSpacesAndTextIsBounded(t *testing.T) {
	if got := sanitize("line one\nline two\ttabbed"); got != "line one line two tabbed" {
		t.Errorf("sanitize = %q", got)
	}
	long := sanitize(strings.Repeat("x", 5000))
	if len([]rune(long)) > maxTextRunes+1 {
		t.Errorf("text was not bounded: %d runes", len([]rune(long)))
	}
	if !strings.HasSuffix(long, "…") {
		t.Error("truncation should be visible")
	}
}

func TestNothingToSayMeansNoCommand(t *testing.T) {
	if _, ok := commandFor("linux", onX, have("notify-send"), "   ", "\n\t"); ok {
		t.Error("empty text must produce no command")
	}
}
