package discovery

import (
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

// A cross-platform archive is the normal case, not an edge case, and on Unix
// the execute bit does not tell you which platform a launcher is for.
//
// Oracle's own SQL Developer ZIP is the example that produced this test:
// extracted on Linux it contains sqldeveloper.exe AND sqldeveloper.sh, both
// with mode 0755 because the archive said so. The old rule — "executable bit
// set, then alphabetical" — chose the .exe, because 'e' sorts before 's'. The
// agent then reported SQL Developer as AVAILABLE and the launch failed at
// exec, which is strictly worse than reporting it missing: the console offers
// the button rather than a disabled control with an install hint.
func TestAWindowsLauncherIsNeverChosenOnUnix(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("the inverse rule applies on Windows; see TestAShellScriptIsNeverChosenOnWindows")
	}
	dir := t.TempDir()
	// Exactly the shape Oracle ships, permissions included.
	for _, name := range []string{"sqldeveloper.exe", "sqldeveloper.sh"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("#!/bin/sh\n"), 0o755); err != nil {
			t.Fatalf("write %s: %v", name, err)
		}
	}

	got, ok := executableInDirOn(runtime.GOOS, dir)
	if !ok {
		t.Fatal("found nothing runnable in a directory holding a .sh launcher")
	}
	if filepath.Base(got) != "sqldeveloper.sh" {
		t.Errorf("chose %q, want sqldeveloper.sh — a Windows launcher cannot run here", filepath.Base(got))
	}

	// And the primitive underneath must agree, since other call sites use it.
	if isExecutableFileOn(runtime.GOOS, filepath.Join(dir, "sqldeveloper.exe")) {
		t.Error("isExecutableFileOn says a .exe is runnable on this OS")
	}
	if !isExecutableFileOn(runtime.GOOS, filepath.Join(dir, "sqldeveloper.sh")) {
		t.Error("isExecutableFileOn rejected an executable .sh")
	}
}

// The other Windows-only shapes travel in the same archives.
func TestOtherForeignExtensionsAreRejectedOnUnix(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("these are native on Windows")
	}
	dir := t.TempDir()
	for _, name := range []string{"install.msi", "run.bat", "run.cmd", "setup.ps1", "lib.dll"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("x"), 0o755); err != nil {
			t.Fatal(err)
		}
	}
	if _, ok := executableInDirOn(runtime.GOOS, dir); ok {
		t.Error("picked a Windows-only file as a runnable launcher on Unix")
	}
}

// A native launcher must still win over an extensionless file that merely
// carries an execute bit — a README or a data blob out of an archive.
func TestTheNativeLauncherOutranksAnExtensionlessFile(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("ranking differs on Windows")
	}
	dir := t.TempDir()
	// "aaa" sorts first alphabetically, so only the ranking can save this.
	for _, name := range []string{"aaa", "start.sh"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("#!/bin/sh\n"), 0o755); err != nil {
			t.Fatal(err)
		}
	}
	got, ok := executableInDirOn(runtime.GOOS, dir)
	if !ok {
		t.Fatal("found nothing runnable")
	}
	if filepath.Base(got) != "start.sh" {
		t.Errorf("chose %q, want start.sh", filepath.Base(got))
	}
}
