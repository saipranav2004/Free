package discovery

import (
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

// WINDOWS AND macOS DISCOVERY, ASSERTED FROM ANY MACHINE.
//
// This package decides which binary gets launched, and it branched on
// runtime.GOOS in a dozen places — so the Windows and macOS halves of that
// decision were only ever exercised by running on Windows and macOS, which
// neither this project's CI nor a Linux container can do. The one bug already
// found here came straight out of that blind spot: Oracle's SQL Developer ZIP
// carries sqldeveloper.exe next to sqldeveloper.sh, both 0755, ".exe" sorts
// first, and on Linux the agent chose the Windows launcher, reported the tool
// as available, and the launch died at exec.
//
// The host's filesystem is still the host's — no test can conjure a Windows
// registry on Linux. What these pin is the part that is pure decision: which
// glob set an OS reads, how each OS decides a file is runnable, which
// launcher wins when several are present, and where portable archives are
// looked for.

// writePlatformExecutable creates a runnable file, making parents as needed.
// Named apart from the package's other helper so the two cannot drift.
func writePlatformExecutable(t *testing.T, path string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte("#!/bin/sh\nexit 0\n"), 0o755); err != nil {
		t.Fatal(err)
	}
}

// The glob set is chosen by the TARGET OS. Reading the host's instead would
// make every cross-OS test silently exercise Linux — and would mean a Windows
// agent consulting Linux paths.
func TestAbsolutePathGlobsAreReadForTheTargetOS(t *testing.T) {
	dir := t.TempDir()
	winTool := filepath.Join(dir, "win", "tool.bat")
	macTool := filepath.Join(dir, "mac", "tool")
	linTool := filepath.Join(dir, "lin", "tool")
	writePlatformExecutable(t, winTool)
	writePlatformExecutable(t, macTool)
	writePlatformExecutable(t, linTool)

	spec := Spec{
		// No BinaryNames, so PATH cannot answer and the globs are reached.
		AbsolutePathGlobs: map[string][]string{
			"windows": {filepath.Join(dir, "win", "*.bat")},
			"darwin":  {filepath.Join(dir, "mac", "tool")},
			"linux":   {filepath.Join(dir, "lin", "tool")},
		},
	}

	for goos, want := range map[string]string{
		"windows": winTool,
		"darwin":  macTool,
		"linux":   linTool,
	} {
		got := locateOn(goos, spec, "")
		if got.Path != want {
			t.Errorf("locateOn(%s) found %q, want %q", goos, got.Path, want)
		}
	}

	// An OS with no globs of its own must not borrow another's.
	if got := locateOn("plan9", spec, ""); got.Found() {
		t.Errorf("an OS with no globs must find nothing, got %+v", got)
	}
}

// Windows decides "runnable" purely by extension — there is no execute bit —
// and every other platform must not.
func TestWindowsDecidesRunnableByExtension(t *testing.T) {
	dir := t.TempDir()
	// Written WITHOUT an execute bit, which is the normal state of a file on
	// a Windows filesystem checked out on Unix.
	for _, name := range []string{"tool.exe", "tool.bat", "tool.cmd", "tool.com", "tool.txt", "readme"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("x"), 0o644); err != nil {
			t.Fatal(err)
		}
	}

	for name, want := range map[string]bool{
		"tool.exe": true, "tool.bat": true, "tool.cmd": true, "tool.com": true,
		"tool.txt": false, "readme": false,
	} {
		if got := isExecutableFileOn("windows", filepath.Join(dir, name)); got != want {
			t.Errorf("windows: %s runnable = %v, want %v", name, got, want)
		}
	}

	// On Unix the same unexecutable files are not runnable whatever they are
	// called — and a .exe is never runnable even WITH the bit set, which is
	// the SQL Developer bug.
	for _, goos := range []string{"linux", "darwin"} {
		for _, name := range []string{"tool.exe", "tool.bat", "readme"} {
			if isExecutableFileOn(goos, filepath.Join(dir, name)) {
				t.Errorf("%s: %s must not be runnable without an execute bit", goos, name)
			}
		}
	}
}

// The SQL Developer case, now asserted for every platform rather than only
// the host's.
func TestTheNativeLauncherWinsOnEveryPlatform(t *testing.T) {
	dir := t.TempDir()
	writePlatformExecutable(t, filepath.Join(dir, "sqldeveloper.sh"))
	writePlatformExecutable(t, filepath.Join(dir, "sqldeveloper.exe"))
	writePlatformExecutable(t, filepath.Join(dir, "sqldeveloper.bat"))

	// Unix: the .sh, never the .exe — which sorts first alphabetically and is
	// mode 0755 here, so nothing but the platform rule separates them.
	for _, goos := range []string{"linux", "darwin"} {
		got, ok := executableInDirOn(goos, dir)
		if !ok {
			t.Fatalf("%s: nothing found in a directory with three launchers", goos)
		}
		if filepath.Base(got) != "sqldeveloper.sh" {
			t.Errorf("%s: chose %s, want sqldeveloper.sh", goos, filepath.Base(got))
		}
	}

	// Windows: the .exe, ahead of the .bat.
	got, ok := executableInDirOn("windows", dir)
	if !ok {
		t.Fatal("windows: nothing found")
	}
	if filepath.Base(got) != "sqldeveloper.exe" {
		t.Errorf("windows: chose %s, want sqldeveloper.exe", filepath.Base(got))
	}
}

func TestForeignExecutableIsPerPlatform(t *testing.T) {
	for _, ext := range []string{".exe", ".bat", ".cmd", ".com", ".msi", ".ps1", ".dll"} {
		if !isForeignExecutableOn("linux", "/opt/tool"+ext) {
			t.Errorf("linux: %s should be recognised as another platform's launcher", ext)
		}
		if !isForeignExecutableOn("darwin", "/opt/tool"+ext) {
			t.Errorf("darwin: %s should be recognised as another platform's launcher", ext)
		}
		// On Windows these are the NATIVE ones, so nothing is foreign.
		if isForeignExecutableOn("windows", `C:\tool`+ext) {
			t.Errorf("windows: %s is native and must not be rejected", ext)
		}
	}
	// A native Unix launcher is never foreign.
	for _, p := range []string{"/opt/tool.sh", "/opt/tool", "/opt/tool.AppImage"} {
		if isForeignExecutableOn("linux", p) {
			t.Errorf("linux: %s is not foreign", p)
		}
	}
}

// A macOS .app is a DIRECTORY. Pointed at on macOS it is a bundle, to be
// launched with `open`; the same directory on Linux is not, and must fall
// through to looking for something runnable inside it.
func TestAppBundleOverrideIsOnlyABundleOnMacOS(t *testing.T) {
	dir := t.TempDir()
	bundle := filepath.Join(dir, "Compass.app")
	if err := os.MkdirAll(bundle, 0o755); err != nil {
		t.Fatal(err)
	}

	got, ok := usableOverrideOn("darwin", bundle)
	if !ok || got.AppBundle != bundle {
		t.Errorf("darwin: a .app override should come back as a bundle, got %+v ok=%v", got, ok)
	}
	if got.Path != "" {
		t.Errorf("darwin: a bundle has no direct exec path, got %q", got.Path)
	}

	// On Linux the directory holds nothing runnable, so the override is not
	// usable — and must not be reported as a bundle.
	if got, ok := usableOverrideOn("linux", bundle); ok || got.AppBundle != "" {
		t.Errorf("linux: a .app directory is not a bundle, got %+v ok=%v", got, ok)
	}

	// With something runnable inside it, Linux picks that up.
	writePlatformExecutable(t, filepath.Join(bundle, "Compass"))
	if got, ok := usableOverrideOn("linux", bundle); !ok || filepath.Base(got.Path) != "Compass" {
		t.Errorf("linux: should find the executable inside the folder, got %+v ok=%v", got, ok)
	}
}

// Where an extracted archive is looked for differs per platform, and the
// operator's own roots always come first.
func TestPortableSearchRootsArePerPlatform(t *testing.T) {
	spec := Spec{PortableRoots: []string{"/operator/choice"}}

	has := func(roots []string, want string) bool {
		for _, r := range roots {
			if r == want {
				return true
			}
		}
		return false
	}

	for goos, want := range map[string]string{
		"linux":   "/opt",
		"darwin":  "/Applications",
		"windows": `C:\`,
	} {
		roots := portableSearchRootsOn(goos, spec)
		if !has(roots, want) {
			t.Errorf("%s roots missing %q: %v", goos, want, roots)
		}
		if roots[0] != "/operator/choice" {
			t.Errorf("%s: the operator's own root must be tried first, got %q", goos, roots[0])
		}
	}

	// Windows must not be sent looking in /opt, and Linux not in /Applications.
	if has(portableSearchRootsOn("windows", spec), "/opt") {
		t.Error("windows should not search /opt")
	}
	if has(portableSearchRootsOn("linux", spec), "/Applications") {
		t.Error("linux should not search /Applications")
	}
}

// An operator-supplied path wins over everything, on every platform — it is
// the only reliable source of truth for a portable archive.
func TestTheOverrideWinsOnEveryPlatform(t *testing.T) {
	dir := t.TempDir()
	override := filepath.Join(dir, "chosen.sh")
	onPath := filepath.Join(dir, "globbed.sh")
	writePlatformExecutable(t, override)
	writePlatformExecutable(t, onPath)

	spec := Spec{AbsolutePathGlobs: map[string][]string{
		"linux": {onPath}, "darwin": {onPath}, "windows": {onPath},
	}}

	for _, goos := range []string{"linux", "darwin", "windows"} {
		// windows decides runnability by extension, so use a .bat there.
		o := override
		if goos == "windows" {
			o = filepath.Join(dir, "chosen.bat")
			writePlatformExecutable(t, o)
		}
		if got := locateOn(goos, spec, o); got.Path != o {
			t.Errorf("%s: the override should win, got %q want %q", goos, got.Path, o)
		}
	}
}

// And the host's own behaviour still has to be right, which is what the rest
// of this package's tests cover — this one just proves the delegation is
// wired to the real OS rather than a constant.
func TestExportedLocateUsesTheHostOS(t *testing.T) {
	dir := t.TempDir()
	hostTool := filepath.Join(dir, "hosttool")
	writePlatformExecutable(t, hostTool)

	spec := Spec{AbsolutePathGlobs: map[string][]string{runtime.GOOS: {hostTool}}}
	if got := Locate(spec); got.Path != hostTool {
		t.Errorf("Locate should read the host's globs (%s), got %+v", runtime.GOOS, got)
	}

	// A spec that only knows about a DIFFERENT OS finds nothing here.
	other := "windows"
	if runtime.GOOS == "windows" {
		other = "linux"
	}
	spec2 := Spec{AbsolutePathGlobs: map[string][]string{other: {hostTool}}}
	if got := Locate(spec2); got.Found() {
		t.Errorf("Locate must not read another OS's globs, got %+v", got)
	}
}
