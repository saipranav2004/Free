// Package spool makes a recording survive the network.
//
// Recordings used to be uploaded once, at session end, in a single POST with
// no retry, no backoff and nothing written to disk. If that request failed —
// VPN drop, laptop lid, server restart, a proxy having a bad minute — the
// recording was gone permanently. For a privileged-access product the
// recording IS the compliance artefact, so that is a durability bug wearing a
// network-flake costume.
//
// The fix is the ordinary one: write it down first, upload from what was
// written, and only delete once the server has it. Anything still on disk at
// the next agent start is retried, so a laptop that was closed mid-upload
// delivers its recording when it comes back rather than losing it.
package spool

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const dirName = "pending-recordings"

// Entry is one spooled recording: the bytes, plus everything the upload call
// needs to be repeated later by a process that has no memory of the session.
type Entry struct {
	SessionID     string          `json:"session_id"`
	AgentDeviceID string          `json:"agent_device_id"`
	Format        string          `json:"format"`
	MediaType     string          `json:"media_type"`
	Status        string          `json:"status"`
	FailureReason string          `json:"failure_reason,omitempty"`
	Commands      json.RawMessage `json:"commands,omitempty"`

	// DurationSeconds is the recorded artifact's OWN length, as the agent
	// measured it. Carried through the spool because a recording uploaded
	// from disk days later must not have its length recomputed from when
	// the upload happened to succeed.
	DurationSeconds int               `json:"duration_seconds,omitempty"`
	Meta            map[string]string `json:"meta,omitempty"`

	// SpooledAt is used to give up on something truly ancient rather than
	// retrying it forever against a server that will never accept it.
	SpooledAt time.Time `json:"spooled_at"`

	// blobPath is where the payload sits. Not serialised: it is derived from
	// the manifest's own location, so a spool directory stays movable.
	blobPath string `json:"-"`
	metaPath string `json:"-"`
}

// Blob reads the recording bytes back.
func (e *Entry) Blob() ([]byte, error) { return os.ReadFile(e.blobPath) }

// Age says how long this has been waiting.
func (e *Entry) Age() time.Duration { return time.Since(e.SpooledAt) }

// Store is a spool directory.
type Store struct{ dir string }

// Open prepares the spool under an agent config directory.
func Open(configDir string) (*Store, error) {
	dir := filepath.Join(configDir, dirName)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, fmt.Errorf("could not create the recording spool: %w", err)
	}
	return &Store{dir: dir}, nil
}

// Add writes a recording to disk BEFORE any upload is attempted.
//
// The blob is written first and the manifest second, deliberately: a manifest
// is what makes an entry visible to Pending, so a crash between the two leaves
// an orphaned blob (harmless, cleaned on the next sweep) rather than a
// manifest pointing at a file that does not exist.
func (s *Store) Add(entry Entry, blob []byte) (*Entry, error) {
	if entry.SessionID == "" {
		return nil, fmt.Errorf("a spooled recording needs a session id")
	}
	entry.SpooledAt = time.Now().UTC()

	stamp := time.Now().UTC().Format("20060102T150405.000000000")
	base := filepath.Join(s.dir, sanitise(entry.SessionID)+"."+stamp)
	entry.blobPath = base + ".blob"
	entry.metaPath = base + ".json"

	if err := writeFileAtomic(entry.blobPath, blob); err != nil {
		return nil, fmt.Errorf("could not spool the recording: %w", err)
	}
	encoded, err := json.MarshalIndent(entry, "", "  ")
	if err != nil {
		os.Remove(entry.blobPath)
		return nil, err
	}
	if err := writeFileAtomic(entry.metaPath, encoded); err != nil {
		os.Remove(entry.blobPath)
		return nil, fmt.Errorf("could not spool the recording manifest: %w", err)
	}
	return &entry, nil
}

// Done removes a delivered recording. Called only after the server has
// accepted it — that ordering is the entire guarantee.
func (s *Store) Done(entry *Entry) {
	if entry == nil {
		return
	}
	os.Remove(entry.metaPath)
	os.Remove(entry.blobPath)
}

// Pending lists everything still waiting, oldest first, so a backlog drains in
// the order it was recorded.
func (s *Store) Pending() ([]*Entry, error) {
	names, err := filepath.Glob(filepath.Join(s.dir, "*.json"))
	if err != nil {
		return nil, err
	}
	sort.Strings(names)

	out := make([]*Entry, 0, len(names))
	for _, metaPath := range names {
		raw, err := os.ReadFile(metaPath)
		if err != nil {
			continue
		}
		var e Entry
		if err := json.Unmarshal(raw, &e); err != nil {
			// A manifest we cannot read is never going to become readable.
			// Drop it rather than retrying it on every start forever.
			os.Remove(metaPath)
			continue
		}
		e.metaPath = metaPath
		e.blobPath = strings.TrimSuffix(metaPath, ".json") + ".blob"
		if _, err := os.Stat(e.blobPath); err != nil {
			os.Remove(metaPath)
			continue
		}
		out = append(out, &e)
	}
	return out, nil
}

// Sweep discards blobs with no manifest (a crash between the two writes) and
// entries older than maxAge.
//
// maxAge exists so a recording the server will never accept — a session it has
// long since reconciled — does not sit in the spool being retried on every
// agent start for the life of the machine.
func (s *Store) Sweep(maxAge time.Duration) (removed int) {
	blobs, _ := filepath.Glob(filepath.Join(s.dir, "*.blob"))
	for _, blob := range blobs {
		meta := strings.TrimSuffix(blob, ".blob") + ".json"
		if _, err := os.Stat(meta); err != nil {
			os.Remove(blob)
			removed++
		}
	}
	entries, _ := s.Pending()
	for _, e := range entries {
		if maxAge > 0 && e.Age() > maxAge {
			s.Done(e)
			removed++
		}
	}
	return removed
}

func sanitise(s string) string {
	return strings.Map(func(r rune) rune {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9', r == '-', r == '_':
			return r
		default:
			return '_'
		}
	}, s)
}

// writeFileAtomic writes through a temporary file and renames, so an
// interrupted write cannot leave a truncated recording that would later be
// uploaded as if it were whole.
func writeFileAtomic(path string, data []byte) error {
	dir := filepath.Dir(path)
	tmp, err := os.CreateTemp(dir, filepath.Base(path)+".*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)

	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Chmod(tmpName, 0o600); err != nil {
		return err
	}
	return os.Rename(tmpName, path)
}
