package register

import "testing"

// Every platform's handler format, parsed on whatever machine runs the
// tests. The three Status() implementations are build-tagged and only one of
// them compiles here; the parsing they depend on is not, which is why it was
// separated out.

func TestParseDesktopExec(t *testing.T) {
	cases := []struct{ name, contents, want string }{
		{
			"what pam-agent install writes",
			"[Desktop Entry]\nType=Application\nName=PAM Agent\nExec=/usr/local/bin/pam-agent launch %u\nTerminal=false\n",
			"/usr/local/bin/pam-agent",
		},
		{
			// A home directory with a space in it is legal on Linux and does
			// happen; an unquoted split on whitespace truncates the path and
			// reports the wrong target.
			"a quoted path containing a space",
			`Exec="/home/some one/bin/pam-agent" launch %u`,
			"/home/some one/bin/pam-agent",
		},
		{"no Exec line at all", "[Desktop Entry]\nName=PAM Agent\n", ""},
		{"empty file", "", ""},
		{
			"Exec with no field code",
			"Exec=/opt/pam/pam-agent\n",
			"/opt/pam/pam-agent",
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := parseDesktopExec(c.contents); got != c.want {
				t.Errorf("parseDesktopExec = %q, want %q", got, c.want)
			}
		})
	}
}

func TestParseRegCommandOutput(t *testing.T) {
	// Real reg.exe output shape: header line, blank line, then the value row
	// with tab separators.
	const real = "\r\nHKEY_CURRENT_USER\\Software\\Classes\\pam-agent\\shell\\open\\command\r\n" +
		"    (Default)    REG_SZ    \"C:\\Program Files\\PAM\\pam-agent.exe\" launch \"%1\"\r\n\r\n"
	if got, want := parseRegCommandOutput(real), `C:\Program Files\PAM\pam-agent.exe`; got != want {
		t.Errorf("parseRegCommandOutput = %q, want %q", got, want)
	}

	const expand = "    (Default)    REG_EXPAND_SZ    \"%LOCALAPPDATA%\\PAM\\pam-agent.exe\" launch \"%1\"\r\n"
	if got, want := parseRegCommandOutput(expand), `%LOCALAPPDATA%\PAM\pam-agent.exe`; got != want {
		t.Errorf("REG_EXPAND_SZ: got %q, want %q", got, want)
	}

	if got := parseRegCommandOutput("ERROR: The system was unable to find the specified registry key\r\n"); got != "" {
		t.Errorf("a missing key must parse to no target, got %q", got)
	}
}

func TestPlistDeclaresScheme(t *testing.T) {
	const declared = `<plist version="1.0"><dict>
  <key>CFBundleURLTypes</key><array><dict>
    <key>CFBundleURLSchemes</key><array><string>pam-agent</string></array>
  </dict></array>
</dict></plist>`
	if !plistDeclaresScheme(declared, "pam-agent") {
		t.Error("a plist declaring the scheme must be recognised")
	}
	// osacompile's own plist, before pam-agent install adds the URL types.
	const bare = `<plist version="1.0"><dict><key>CFBundleName</key><string>PAM Agent</string></dict></plist>`
	if plistDeclaresScheme(bare, "pam-agent") {
		t.Error("a plist with no CFBundleURLSchemes must not be reported as declaring the scheme")
	}
	// The scheme name appearing somewhere unrelated is not a declaration.
	const elsewhere = `<plist><dict><key>CFBundleIdentifier</key><string>com.yourorg.pam-agent</string></dict></plist>`
	if plistDeclaresScheme(elsewhere, "pam-agent") {
		t.Error("the bundle identifier is not a URL-scheme declaration")
	}
}

func TestFirstToken(t *testing.T) {
	for in, want := range map[string]string{
		`/usr/bin/pam-agent launch %u`:   "/usr/bin/pam-agent",
		`"/with space/pam-agent" launch`: "/with space/pam-agent",
		`/only-one-token`:                "/only-one-token",
		``:                               "",
		`"unterminated quote`:            "unterminated quote",
	} {
		if got := firstToken(in); got != want {
			t.Errorf("firstToken(%q) = %q, want %q", in, got, want)
		}
	}
}
