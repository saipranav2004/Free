// pam-agent/internal/register/status.go
//
// IS THE pam-agent:// HANDLER ACTUALLY REGISTERED? — asked from the machine
// itself, without clicking a button in a browser to find out.
//
// `pam-agent install` reports whether registration SUCCEEDED, once, at the
// moment it ran. Nothing has been able to answer the question afterwards, and
// afterwards is when it matters: an OS upgrade rewrites Launch Services, a
// user's profile is migrated, a second copy of the binary registers itself
// and wins, the agent is moved to a different folder. In every one of those
// cases "Open in Desktop App" silently does nothing — the same symptom as a
// missing tool, a revoked device or an expired token, with nothing to
// distinguish it. This is what `pam-agent doctor` uses to distinguish it.
//
// The three OS implementations live in status_<goos>.go. The PARSING they
// each need lives here, without a build tag, so every platform's handler
// format can be asserted from any machine — the same reason the recorder's
// capture arguments take the OS as a parameter.
package register

import (
	"strings"
)

// Registration is what the OS currently believes about pam-agent:// links.
type Registration struct {
	// Registered is true only when the OS will route a pam-agent:// link to
	// a pam-agent binary. "The file we wrote is still there" is not enough:
	// on Linux the .desktop file can exist while xdg-mime points the scheme
	// somewhere else entirely.
	Registered bool `json:"registered"`

	// Handler is where the registration lives — the .desktop path, the app
	// bundle, or the registry key — so a person can go and look at it.
	Handler string `json:"handler,omitempty"`

	// Target is the binary the OS will actually run. Compared against this
	// process's own path by doctor: a handler pointing at a DIFFERENT copy of
	// pam-agent is registered, works, and is still worth saying out loud,
	// because the copy being upgraded is then not the copy being launched.
	Target string `json:"target,omitempty"`

	// Detail explains anything the two booleans cannot: why it is not
	// registered, or which part of the OS could not be asked.
	Detail string `json:"detail,omitempty"`
}

// parseDesktopExec pulls the Exec= command out of a freedesktop .desktop
// file and returns the binary it names.
//
// The value is a command line with field codes (%u for the URL), so the
// binary is its first token. Quoted paths are handled because a path with a
// space in it — "/home/some one/bin/pam-agent" — is legal and common enough
// on Linux to matter.
func parseDesktopExec(contents string) string {
	for _, line := range strings.Split(contents, "\n") {
		line = strings.TrimSpace(line)
		if !strings.HasPrefix(line, "Exec=") {
			continue
		}
		return firstToken(strings.TrimPrefix(line, "Exec="))
	}
	return ""
}

// parseRegCommandOutput reads the default value out of `reg query` output for
// HKCU\Software\Classes\pam-agent\shell\open\command and returns the binary
// it invokes.
//
// reg.exe prints a header, a blank line, then rows of
// "    (Default)    REG_SZ    "C:\path\pam-agent.exe" launch "%1"". The value
// itself contains quotes and tabs, so this looks for the type marker and
// takes what follows.
func parseRegCommandOutput(out string) string {
	for _, line := range strings.Split(out, "\n") {
		idx := strings.Index(line, "REG_SZ")
		if idx < 0 {
			idx = strings.Index(line, "REG_EXPAND_SZ")
			if idx < 0 {
				continue
			}
			idx += len("REG_EXPAND_SZ")
		} else {
			idx += len("REG_SZ")
		}
		return firstToken(strings.TrimSpace(line[idx:]))
	}
	return ""
}

// plistDeclaresScheme reports whether an Info.plist declares the pam-agent
// URL scheme. Text-matched rather than parsed: the agent is stdlib-only, a
// plist may be XML or binary, and the question being asked is narrow enough
// that the presence of the scheme string inside a CFBundleURLSchemes array
// answers it.
func plistDeclaresScheme(contents, scheme string) bool {
	if !strings.Contains(contents, "CFBundleURLSchemes") {
		return false
	}
	return strings.Contains(contents, "<string>"+scheme+"</string>") ||
		strings.Contains(contents, "\""+scheme+"\"")
}

// firstToken returns the first whitespace-separated token of a command line,
// honouring double quotes so a quoted path with spaces survives intact.
func firstToken(cmd string) string {
	cmd = strings.TrimSpace(cmd)
	if cmd == "" {
		return ""
	}
	if cmd[0] == '"' {
		if end := strings.Index(cmd[1:], `"`); end >= 0 {
			return cmd[1 : 1+end]
		}
		return strings.TrimPrefix(cmd, `"`)
	}
	if i := strings.IndexAny(cmd, " \t"); i >= 0 {
		return cmd[:i]
	}
	return cmd
}
