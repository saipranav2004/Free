//go:build linux

// pam-agent/internal/register/status_linux.go
package register

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// Status asks the two questions that together decide whether a pam-agent://
// link opens anything on this machine: does our .desktop file still exist,
// and does xdg-mime still point the scheme at it?
//
// BOTH, not either. The .desktop file surviving is the part an operator can
// see, and it is the weaker half: installing a second copy of the agent, or
// any application that claims x-scheme-handler/pam-agent, re-points the
// scheme while leaving our file untouched. The link then opens the other
// binary — or nothing — with our registration apparently intact.
func Status() Registration {
	home, err := os.UserHomeDir()
	if err != nil {
		return Registration{Detail: fmt.Sprintf("could not determine home directory: %v", err)}
	}
	desktopPath := filepath.Join(home, ".local", "share", "applications", desktopFileName)
	reg := Registration{Handler: desktopPath}

	contents, err := os.ReadFile(desktopPath)
	if err != nil {
		reg.Detail = "no .desktop file for pam-agent — run: pam-agent install"
		return reg
	}
	reg.Target = parseDesktopExec(string(contents))

	// xdg-mime is what actually routes the scheme. Absent on minimal
	// installs, in which case the honest answer is "the file is there and I
	// cannot confirm the routing", not a claim either way.
	if _, err := exec.LookPath("xdg-mime"); err != nil {
		reg.Detail = "xdg-mime is not installed, so the scheme routing cannot be confirmed from here (the handler file is in place)"
		return reg
	}
	out, err := exec.Command("xdg-mime", "query", "default", "x-scheme-handler/pam-agent").CombinedOutput()
	if err != nil {
		reg.Detail = fmt.Sprintf("xdg-mime query failed: %v", err)
		return reg
	}
	def := strings.TrimSpace(string(out))
	if def == desktopFileName {
		reg.Registered = true
		return reg
	}
	if def == "" {
		reg.Detail = "no application is registered for pam-agent:// links — run: pam-agent install"
		return reg
	}
	reg.Detail = fmt.Sprintf("pam-agent:// links are routed to %s, not to pam-agent — run: pam-agent install", def)
	return reg
}
