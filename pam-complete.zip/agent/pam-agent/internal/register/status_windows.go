//go:build windows

// pam-agent/internal/register/status_windows.go
package register

import (
	"fmt"
	"os"
	"os/exec"
)

const schemeKey = `HKCU\Software\Classes\pam-agent`

// Status reads back the per-user registry association `pam-agent install`
// writes, and checks that the binary it names is still on disk.
//
// A registry key pointing at a binary that has been moved, renamed or
// uninstalled is the Windows shape of "the button does nothing": the shell
// resolves the scheme, fails to start the command, and shows the operator
// nothing at all.
func Status() Registration {
	reg := Registration{Handler: schemeKey + `\shell\open\command`}

	out, err := exec.Command("reg", "query", schemeKey+`\shell\open\command`, "/ve").CombinedOutput()
	if err != nil {
		reg.Detail = "pam-agent:// is not registered for this user — run: pam-agent install"
		return reg
	}
	target := parseRegCommandOutput(string(out))
	if target == "" {
		reg.Detail = "the pam-agent:// registry key exists but names no command — run: pam-agent install"
		return reg
	}
	reg.Target = target

	if _, err := os.Stat(target); err != nil {
		reg.Detail = fmt.Sprintf("pam-agent:// is registered but %s is not there any more — run: pam-agent install", target)
		return reg
	}

	reg.Registered = true
	return reg
}
