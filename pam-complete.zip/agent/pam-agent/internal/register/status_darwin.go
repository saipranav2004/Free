//go:build darwin

// pam-agent/internal/register/status_darwin.go
package register

import (
	"fmt"
	"os"
	"path/filepath"
)

// Status checks the handler app bundle `pam-agent install` builds: that it is
// still there, that it still declares the pam-agent:// scheme, and that the
// agent binary it forwards to still exists.
//
// It does NOT ask Launch Services which bundle currently owns the scheme.
// That answer lives behind LSCopyDefaultApplicationURLForURL, a CoreServices
// call needing cgo and a macOS SDK — and this agent is built by pure
// cross-compilation with CGO_ENABLED=0 (see install/macos/build-pkg.sh), so
// linking it would change how the whole product is shipped in order to
// improve one diagnostic line. What is checked here is what actually breaks
// in practice: the bundle removed by a cleanup tool, or a bundle left
// pointing at an agent binary that has since been moved or upgraded in
// place. A bundle that is intact but out-competed by another application is
// the case this cannot see, and Detail says so rather than implying
// certainty.
func Status() Registration {
	home, err := os.UserHomeDir()
	if err != nil {
		return Registration{Detail: fmt.Sprintf("could not determine home directory: %v", err)}
	}
	bundlePath := filepath.Join(home, "Applications", bundleName)
	reg := Registration{Handler: bundlePath}

	if _, err := os.Stat(bundlePath); err != nil {
		reg.Detail = "no PAMAgent.app URL-handler bundle — run: pam-agent install"
		return reg
	}

	plist, err := os.ReadFile(filepath.Join(bundlePath, "Contents", "Info.plist"))
	if err != nil {
		reg.Detail = fmt.Sprintf("the handler bundle exists but its Info.plist could not be read: %v", err)
		return reg
	}
	if !plistDeclaresScheme(string(plist), "pam-agent") {
		reg.Detail = "the handler bundle does not declare the pam-agent:// scheme — run: pam-agent install"
		return reg
	}

	// The applet forwards to a copy of the agent inside its own Resources.
	// Losing that copy is the failure mode where the scheme resolves, the
	// applet runs, and nothing happens.
	target := filepath.Join(bundlePath, "Contents", "Resources", "pam-agent")
	reg.Target = target
	if _, err := os.Stat(target); err != nil {
		reg.Detail = "the handler bundle no longer contains an agent binary to forward to — run: pam-agent install"
		return reg
	}

	reg.Registered = true
	reg.Detail = "the bundle is registered and complete; whether Launch Services still prefers it over another application cannot be read without CoreServices"
	return reg
}
