package recorder

import (
	"strings"
	"testing"
)

// The exact ffmpeg invocation on each platform, asserted from any host.
//
// These three branches used to be unreachable from a test: screenCaptureArgs
// read runtime.GOOS, so the macOS and Windows invocations were only ever
// exercised by running on macOS and Windows. Neither this project's CI nor a
// Linux container can do that, which left the two least familiar device
// syntaxes — avfoundation's "1:none" and gdigrab's "desktop" — as the only
// two nothing verified. A typo in either fails on a customer's machine at the
// exact moment a privileged session is supposed to be being recorded, and
// leaves no recording of it.
//
// Written as the whole argument list rather than "contains x11grab": the
// order matters to ffmpeg (input flags before -i, output flags after), and a
// substring check passes just as happily when an argument has moved to the
// wrong side of the input.
func TestCaptureArgsPerPlatform(t *testing.T) {
	opts := ScreenOptions{}.withDefaults()
	opts.Display = ":99" // so the linux branch does not depend on the host's $DISPLAY

	cases := []struct {
		goos  string
		input []string
	}{
		{"linux", []string{"-f", "x11grab", "-framerate", "5", "-i", ":99"}},
		{"darwin", []string{"-f", "avfoundation", "-framerate", "5", "-capture_cursor", "1", "-i", "1:none"}},
		{"windows", []string{"-f", "gdigrab", "-framerate", "5", "-i", "desktop"}},
	}

	for _, c := range cases {
		t.Run(c.goos, func(t *testing.T) {
			args, err := screenCaptureArgsFor(c.goos, opts, vp9WebM, "/tmp/session.webm")
			if err != nil {
				t.Fatalf("screenCaptureArgsFor(%s): %v", c.goos, err)
			}
			joined := strings.Join(args, " ")

			// The input block, in order, immediately after the banner flags.
			want := "-hide_banner -loglevel error " + strings.Join(c.input, " ")
			if !strings.HasPrefix(joined, want) {
				t.Errorf("%s input block\n want prefix: %s\n got:         %s", c.goos, want, joined)
			}

			// Everything after the input is platform-independent by design —
			// one codec and one pixel format so the console has exactly one
			// kind of file to play back.
			for _, must := range []string{
				"-t 14400", // the four-hour bound on one recording
				"-c:v libvpx-vp9",
				"-pix_fmt yuv420p",
				"-vf pad=ceil(iw/2)*2:ceil(ih/2)*2",
				"/tmp/session.webm",
			} {
				if !strings.Contains(joined, must) {
					t.Errorf("%s: missing %q in %s", c.goos, must, joined)
				}
			}

			// Audio is never captured, on any platform: it would pick up
			// whatever else is happening on the operator's machine, which is
			// beyond what a session recording is entitled to.
			if strings.Contains(joined, "-f pulse") || strings.Contains(joined, "-i default") ||
				strings.Contains(joined, "-c:a") {
				t.Errorf("%s: audio must never be captured: %s", c.goos, joined)
			}
		})
	}
}

// A platform with no capture backend must be refused with a sentence naming
// it, not left to ffmpeg to fail on a device it cannot open.
func TestCaptureArgsUnsupportedPlatform(t *testing.T) {
	_, err := screenCaptureArgsFor("plan9", ScreenOptions{}.withDefaults(), vp9WebM, "/tmp/out.webm")
	if err == nil {
		t.Fatal("expected an error for an unsupported platform")
	}
	if !strings.Contains(err.Error(), "plan9") {
		t.Errorf("the error should name the platform, got: %v", err)
	}
}

// Linux with no display at all: the operator gets the reason, not an ffmpeg
// device error.
func TestCaptureArgsLinuxNeedsADisplay(t *testing.T) {
	t.Setenv("DISPLAY", "")
	_, err := screenCaptureArgsFor("linux", ScreenOptions{}.withDefaults(), vp9WebM, "/tmp/out.webm")
	if err == nil {
		t.Fatal("expected an error when no X display is set")
	}
	if !strings.Contains(err.Error(), "display") {
		t.Errorf("the error should mention the display, got: %v", err)
	}
}

func TestCaptureBackendNames(t *testing.T) {
	for goos, want := range map[string]string{
		"linux": "x11grab", "darwin": "avfoundation", "windows": "gdigrab", "plan9": "",
	} {
		if got := CaptureBackend(goos); got != want {
			t.Errorf("CaptureBackend(%s) = %q, want %q", goos, got, want)
		}
	}
}
