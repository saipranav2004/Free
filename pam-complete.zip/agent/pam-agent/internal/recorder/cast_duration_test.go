package recorder

import (
	"testing"
	"time"
)

// A recording's length is the span of what it CAPTURED.
//
// It used to be computed on the server from "row created" to "artifact
// attached", which also counts the launch, the upload, and — when a session
// is closed by the idle sweep rather than by the operator — the sweep's lag.
// A 10-second clip was listed as 35 seconds while the player, reading the
// file, said 10.
func TestCastDurationIsTheSpanOfItsFrames(t *testing.T) {
	c := NewCast(80, 24, "test")

	// Nothing recorded yet: no length to claim.
	if d := c.Duration(); d != 0 {
		t.Errorf("an empty recording has no duration, got %v", d)
	}

	c.Output([]byte("psql (16.0)\n"))
	first := c.Duration()
	if first <= 0 {
		t.Fatal("after a frame there is a span")
	}

	time.Sleep(60 * time.Millisecond)
	c.Input([]byte("select 1;\n"))
	second := c.Duration()
	if second <= first {
		t.Errorf("a later frame must extend the span: %v then %v", first, second)
	}
	if second < 50*time.Millisecond {
		t.Errorf("the span should cover the gap between frames, got %v", second)
	}

	// Idling after the last frame must NOT extend it — that is exactly the
	// wall-clock behaviour being replaced.
	time.Sleep(80 * time.Millisecond)
	if c.Duration() != second {
		t.Errorf("idling extended the recording's length: %v -> %v", second, c.Duration())
	}
}

// Empty writes are dropped by record(), so they must not move the length
// either.
func TestCastDurationIgnoresEmptyWrites(t *testing.T) {
	c := NewCast(80, 24, "test")
	c.Output([]byte("x"))
	d := c.Duration()
	time.Sleep(20 * time.Millisecond)
	c.Output(nil)
	c.Input([]byte{})
	if c.Duration() != d {
		t.Errorf("an empty write changed the duration: %v -> %v", d, c.Duration())
	}
}
