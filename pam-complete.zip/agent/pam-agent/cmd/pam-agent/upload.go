package main

import (
	"crypto/ed25519"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"time"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/recorder"
	"github.com/yourorg/pam-agent/internal/spool"
)

// spooledMaxAge is how long a recording keeps being retried before it is given
// up on. Long enough to cover a laptop left shut over a long weekend; short
// enough that a recording the server will never accept does not sit in the
// spool for the life of the machine.
const spooledMaxAge = 14 * 24 * time.Hour

// deliverRecording spools a recording to disk, then tries to deliver it.
//
// SPOOL FIRST, ALWAYS. The upload used to be a single POST with no retry and
// nothing written down: one failure — a VPN drop, a closing lid, a server
// restart — and the recording was gone permanently. For a privileged-access
// product the recording is the compliance artefact, so losing it to a bad
// minute of network is a durability bug, not a networking inconvenience.
//
// The file is removed only once the server has accepted it. Anything still
// there at the next agent start is retried by drainSpooledRecordings.
func deliverRecording(
	client *apiclient.Client,
	configDir string,
	sessionID, agentDeviceID string,
	privateKey ed25519.PrivateKey,
	blob []byte,
	format, mediaType, status, failureReason string,
	commands []recorder.Command,
	// durationSeconds is the artifact's own length. Zero means "not known",
	// which leaves the server on its fallback rather than claiming a length.
	durationSeconds int,
	log *slog.Logger,
) {
	store, err := spool.Open(configDir)
	if err != nil {
		// No spool available (no config dir, read-only disk). Falling back to
		// a direct upload is strictly better than not trying at all.
		log.Warn("recording.spool.unavailable", "error", err.Error())
		if upErr := client.UploadRecordingWithRetry(sessionID, agentDeviceID, privateKey,
			blob, format, mediaType, status, failureReason, commands, durationSeconds); upErr != nil {
			log.Error("recording.upload.fail", "session_id", sessionID, "error", upErr.Error())
			fmt.Fprintf(os.Stderr, "warning: failed to upload the session recording: %v\n", upErr)
		}
		return
	}

	encodedCommands, _ := json.Marshal(commands)
	entry, err := store.Add(spool.Entry{
		SessionID:     sessionID,
		AgentDeviceID: agentDeviceID,
		Format:        format,
		MediaType:     mediaType,
		Status:        status,
		FailureReason: failureReason,
		Commands:      encodedCommands,
		// Stored with the entry so a recording delivered from disk days later
		// still reports the length it actually has.
		DurationSeconds: durationSeconds,
	}, blob)
	if err != nil {
		log.Error("recording.spool.write.fail", "session_id", sessionID, "error", err.Error())
		return
	}

	if upErr := client.UploadRecordingWithRetry(sessionID, agentDeviceID, privateKey,
		blob, format, mediaType, status, failureReason, commands, durationSeconds); upErr != nil {
		// Left on disk on purpose. The next agent start picks it up, so a
		// session recorded on a train is delivered when the laptop is opened
		// at a desk.
		log.Warn("recording.upload.deferred", "session_id", sessionID, "error", upErr.Error())
		fmt.Fprintln(os.Stderr,
			"note: the session recording could not be uploaded yet and is saved locally; "+
				"it will be sent the next time the agent runs.")
		return
	}

	store.Done(entry)
	log.Info("recording.upload.ok", "session_id", sessionID, "status", status, "format", format)
}

// drainSpooledRecordings delivers anything left over from a previous run.
//
// Called on every launch, before the session starts, because that is the
// moment the agent is known to have both a network and credentials — and it
// costs nothing when the spool is empty, which is the normal case.
func drainSpooledRecordings(client *apiclient.Client, configDir, agentDeviceID string,
	privateKey ed25519.PrivateKey, log *slog.Logger) {

	store, err := spool.Open(configDir)
	if err != nil {
		return
	}
	if removed := store.Sweep(spooledMaxAge); removed > 0 {
		log.Info("recording.spool.swept", "removed", removed)
	}

	pending, err := store.Pending()
	if err != nil || len(pending) == 0 {
		return
	}
	log.Info("recording.spool.draining", "count", len(pending))

	for _, entry := range pending {
		blob, err := entry.Blob()
		if err != nil {
			store.Done(entry)
			continue
		}
		var commands []recorder.Command
		if len(entry.Commands) > 0 {
			_ = json.Unmarshal(entry.Commands, &commands)
		}
		// The device that recorded it is the device that must sign for it. A
		// recording spooled on this machine is always this machine's, so the
		// stored id and the current one agree; using the stored one keeps that
		// explicit rather than assumed.
		deviceID := entry.AgentDeviceID
		if deviceID == "" {
			deviceID = agentDeviceID
		}
		if upErr := client.UploadRecordingWithRetry(entry.SessionID, deviceID, privateKey,
			blob, entry.Format, entry.MediaType, entry.Status, entry.FailureReason, commands,
			entry.DurationSeconds); upErr != nil {
			log.Warn("recording.spool.retry.fail",
				"session_id", entry.SessionID, "age", entry.Age().Round(time.Second).String(),
				"error", upErr.Error())
			continue
		}
		store.Done(entry)
		log.Info("recording.spool.delivered",
			"session_id", entry.SessionID, "waited", entry.Age().Round(time.Second).String())
	}
}
