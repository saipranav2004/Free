# backend_upd — complete working tree

The whole backend, not a patch. Drop it in as `backend_upd/` and build.

## Why a full tree this time

The `undefined: MetabaseAuthenticator` you hit was a packaging fault on my
side, not a problem in your checkout. The last archive shipped
`internal/webproxy/authenticator.go` — which registers both the Metabase and
Qdrant strategies — but only `authenticator_qdrant.go` beside it, because
`authenticator_metabase.go` had gone out in the round before. Applied on a
tree that never received that earlier round, the registry referenced a type
nothing defined:

```
internal/webproxy/authenticator.go:111:4: undefined: MetabaseAuthenticator
internal/webproxy/authenticator.go:147:23: undefined: strategyMetabase
```

I reproduced that exact pair of errors here by deleting the one file, and
they disappear when it is present. A complete tree has no apply order to get
wrong, which is why this one is complete.

## What is in it

Everything from every round of this work, already applied:

- **Vault / credentials** — `account_name` required only for credential types
  that authenticate *as* an account, enforced once in
  `models.AccountNameRequiredFor` and applied in `VaultService.StoreCredential`
  so both the Vault route and the admin resource route agree. Includes the
  envelope-encryption fix: `account_name` is normalised in `EncryptionAAD`
  the way `safe_id` already was, so a credential stored without one (an API
  key) can still be decrypted.
- **Web auth strategies** — `authenticator_metabase.go` (Metabase session
  login) and `authenticator_qdrant.go` (Qdrant `api-key` header), both
  inferred from the resource type so neither needs configuring.
- **WebSocket upgrade visibility** — a stripped `Upgrade`/`Connection` header
  is audited and surfaced on the affected session instead of failing silently.
- **Service identity / machine plane** — coalesced refusal auditing, vault
  master key as a required parameter with no hardcoded fallback.

## agents/

Rebuilt from the current agent source, today's build:

```
pam-agent_windows_amd64.exe   Windows (64-bit)
pam-agent_darwin_arm64        macOS (Apple Silicon)
pam-agent_darwin_amd64        macOS (Intel)
pam-agent_linux_amd64         Linux (x86-64)
pam-agent_linux_arm64         Linux (ARM64)
VERSION                       2026.09.25
SHA256SUMS.txt                standard sha256sum format
```

Verify them with:

```
cd backend_upd/agents && sha256sum -c SHA256SUMS.txt
```

**The ones that were in here before were built 2026.09.17** — before the
ffmpeg resolution fix, the pgAdmin password-command support and the
RedisInsight pre-setup support. These replace them.

The filenames are a contract with `internal/agentdist/store.go`, which parses
`pam-agent_<os>_<arch>[.exe]` to build the console's download list. Rename one
and that platform silently vanishes from the picker.

`SHA256SUMS.txt` is for you, not for the server: the server hashes each file
itself at scan time and the generated install scripts verify *that* digest, so
there is no checksum file to keep in step if you rebuild.

### Pointing the API at it

```
PAM_AGENT_BINARY_DIR=/absolute/path/to/backend_upd/agents
```

Use an absolute path. A relative one resolves against the process's working
directory, and if you start the API the way you did — `go run .` from
`cmd/pam-api` — a relative `./agents` looks inside `cmd/pam-api`, finds
nothing, and the console shows no download buttons with no error. Leaving the
variable unset disables agent distribution entirely, which is the default.

The `Dockerfile` already copies `agents/` to `/app/agents`.

## Not included

`.env` — deliberately. `.env.example` is there with every key and no values.
The live secrets in your `.env` (RDS password, MinIO keys, `PAM_JWT_SECRET_KEY`,
`PAM_AUDIT_HMAC_SECRET`, `PAM_ROOT_PASSWORD`) still need rotating, since they
were in a file under version control.

## Verified before packing

- `go build ./...` and `go vet ./...` — clean
- `go test ./...` — **13 packages, all pass** (vault AAD tests against real
  PostgreSQL)
- the API built from this tree, started against this tree's own `agents/`:
  `agentdist.scanned targets=5 version=2026.09.25`, and
  `/agent/install/targets` returned all five with digests matching
  `SHA256SUMS.txt`
- the archive was then unzipped into an empty directory and built there from
  scratch — the check that would have caught the missing Metabase file
