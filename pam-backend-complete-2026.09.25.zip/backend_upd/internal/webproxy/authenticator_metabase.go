// pam/internal/webproxy/authenticator_metabase.go
//
// Metabase's session login, so a brokered Metabase session arrives already
// signed in rather than on Metabase's own login form.
//
// WHY A TYPE OF ITS OWN rather than configuration. The generic
// JSONPostAuthenticator can already speak this protocol — an operator who
// sets web_auth_strategy=json_post, web_login_path=/api/session on the
// resource gets the same result today. But nothing INFERRED that for a
// resource whose type is "metabase", so the out-of-the-box behaviour was
// strategyNone: the proxy worked, the session was audited and recorded, and
// the operator still had to know a Metabase password — which is the one thing
// a privileged access product exists to avoid. MinIO already has its own
// type for exactly this reason; this is the same argument.
//
// THE PROTOCOL, from Metabase's documented API:
//
//	POST /api/session  {"username": "...", "password": "..."}
//	  200 {"id":"<session-uuid>"} and Set-Cookie: metabase.SESSION=<uuid>
//
// Recent Metabase sets the cookie itself, which is all the proxy needs. Older
// builds answer with the id in the body only, so the id is promoted to that
// same cookie when no Set-Cookie arrives — the header name and the cookie
// name are the same session token either way.
package webproxy

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
)

const strategyMetabase = "metabase_session"

// metabaseSessionCookie is the cookie Metabase carries its session in.
const metabaseSessionCookie = "metabase.SESSION"

type MetabaseAuthenticator struct{}

func (a *MetabaseAuthenticator) Name() string { return strategyMetabase }

func (a *MetabaseAuthenticator) Login(ctx context.Context, client *http.Client, target Target) (*UpstreamState, error) {
	body, err := json.Marshal(map[string]string{
		"username": target.Username,
		"password": target.Password,
	})
	if err != nil {
		return nil, fmt.Errorf("encode metabase login body: %w", err)
	}

	loginURL := strings.TrimRight(target.BaseURL, "/") + "/api/session"
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, loginURL, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("build metabase login request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("metabase login request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusCreated {
		// Same split as the MinIO authenticator, for the same reason: only
		// an auth status means the stored credential is wrong. Anything else
		// is far more likely to be a console_url pointing somewhere that is
		// not Metabase, and blaming the vault for that sends an
		// administrator off rotating a credential that was never the problem.
		switch resp.StatusCode {
		case http.StatusUnauthorized, http.StatusForbidden:
			return nil, fmt.Errorf("metabase rejected the stored credential (status %d) — "+
				"check the resource's username/password in the vault", resp.StatusCode)
		case http.StatusBadRequest:
			// Metabase answers 400 with a field-level complaint when the body
			// is shaped wrong for the version in front of it.
			detail, _ := io.ReadAll(io.LimitReader(resp.Body, 512))
			return nil, fmt.Errorf("metabase did not accept the login body (status 400): %s — "+
				"check console_url points at Metabase itself", strings.TrimSpace(string(detail)))
		default:
			return nil, fmt.Errorf("%s did not answer Metabase's session API (status %d) — "+
				"check the resource's console_url points at the Metabase server",
				loginURL, resp.StatusCode)
		}
	}

	state := &UpstreamState{}
	for _, ck := range resp.Cookies() {
		state.setCookie(ck.Name, ck.Value)
	}
	if len(state.Cookies) > 0 {
		return state, nil
	}

	// No Set-Cookie: an older Metabase that returns the session id in the
	// body and expects the caller to carry it. Same token, same cookie name.
	var payload struct {
		ID string `json:"id"`
	}
	raw, err := io.ReadAll(io.LimitReader(resp.Body, 4096))
	if err != nil {
		return nil, fmt.Errorf("read metabase login response: %w", err)
	}
	if err := json.Unmarshal(raw, &payload); err != nil || strings.TrimSpace(payload.ID) == "" {
		return nil, fmt.Errorf("metabase login returned neither a session cookie nor a session id (status %d) — "+
			"the server may be running a version with a different login API", resp.StatusCode)
	}
	state.setCookie(metabaseSessionCookie, payload.ID)
	return state, nil
}
