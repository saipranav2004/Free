package webproxy

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// A stand-in for Metabase's session API, in both the shapes real deployments
// answer with: modern builds set the cookie themselves, older ones return the
// session id in the body and expect the caller to carry it.
func metabaseServer(t *testing.T, setCookie bool, user, pass string) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/session" || r.Method != http.MethodPost {
			w.WriteHeader(http.StatusNotFound)
			return
		}
		if ct := r.Header.Get("Content-Type"); !strings.HasPrefix(ct, "application/json") {
			w.WriteHeader(http.StatusBadRequest)
			_, _ = w.Write([]byte(`{"errors":{"_body":"expected json"}}`))
			return
		}
		var body struct{ Username, Password string }
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			w.WriteHeader(http.StatusBadRequest)
			return
		}
		if body.Username != user || body.Password != pass {
			w.WriteHeader(http.StatusUnauthorized)
			_, _ = w.Write([]byte(`{"errors":{"password":"did not match stored password"}}`))
			return
		}
		if setCookie {
			http.SetCookie(w, &http.Cookie{Name: metabaseSessionCookie, Value: "sess-abc-123", Path: "/", HttpOnly: true})
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"id":"sess-abc-123"}`))
	}))
}

func TestMetabaseLoginCarriesTheSessionCookie(t *testing.T) {
	srv := metabaseServer(t, true, "analyst@example.com", "s3cret")
	defer srv.Close()

	state, err := (&MetabaseAuthenticator{}).Login(context.Background(), srv.Client(), Target{
		BaseURL: srv.URL, Username: "analyst@example.com", Password: "s3cret",
	})
	if err != nil {
		t.Fatalf("login failed against a Metabase-shaped server: %v", err)
	}
	if state.Cookies[metabaseSessionCookie] != "sess-abc-123" {
		t.Fatalf("session cookie = %q, want the token Metabase issued", state.Cookies[metabaseSessionCookie])
	}
}

func TestMetabaseLoginWorksOnABuildThatOnlyReturnsTheIdInTheBody(t *testing.T) {
	// Older Metabase does not Set-Cookie; the id in the body IS the session.
	// Without this branch the operator would land on the login form with no
	// error anywhere, which is the worst of both outcomes.
	srv := metabaseServer(t, false, "analyst@example.com", "s3cret")
	defer srv.Close()

	state, err := (&MetabaseAuthenticator{}).Login(context.Background(), srv.Client(), Target{
		BaseURL: srv.URL, Username: "analyst@example.com", Password: "s3cret",
	})
	if err != nil {
		t.Fatalf("login failed on a cookie-less build: %v", err)
	}
	if state.Cookies[metabaseSessionCookie] != "sess-abc-123" {
		t.Fatalf("session cookie = %q, want the id promoted from the body", state.Cookies[metabaseSessionCookie])
	}
}

func TestMetabaseBlamesTheCredentialOnlyWhenMetabaseDid(t *testing.T) {
	srv := metabaseServer(t, true, "analyst@example.com", "s3cret")
	defer srv.Close()

	_, err := (&MetabaseAuthenticator{}).Login(context.Background(), srv.Client(), Target{
		BaseURL: srv.URL, Username: "analyst@example.com", Password: "wrong",
	})
	if err == nil {
		t.Fatal("a wrong password must not produce a session")
	}
	if !strings.Contains(err.Error(), "vault") {
		t.Fatalf("a 401 should point at the stored credential, got %q", err)
	}
}

func TestMetabasePointsAtConsoleURLWhenTheTargetIsNotMetabase(t *testing.T) {
	// console_url aimed at something that is not Metabase at all. Blaming the
	// vault here sends an admin off rotating a perfectly good credential.
	other := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))
	defer other.Close()

	_, err := (&MetabaseAuthenticator{}).Login(context.Background(), other.Client(), Target{
		BaseURL: other.URL, Username: "u", Password: "p",
	})
	if err == nil {
		t.Fatal("expected an error")
	}
	if !strings.Contains(err.Error(), "console_url") {
		t.Fatalf("error should name console_url, got %q", err)
	}
	if strings.Contains(err.Error(), "vault") {
		t.Fatalf("a non-Metabase target must not be reported as a credential problem: %q", err)
	}
}

// The gap this whole file closes: a metabase resource used to infer
// strategyNone, so the operator had to know a Metabase password — the one
// thing PAM exists to avoid.
func TestAMetabaseResourceNowInfersItsOwnLoginStrategy(t *testing.T) {
	got, err := NewRegistry().Get("metabase", nil)
	if err != nil {
		t.Fatal(err)
	}
	if got.Name() != strategyMetabase {
		t.Fatalf("metabase inferred %q, want %q", got.Name(), strategyMetabase)
	}
}

func TestCaseIsNotSignificantForTheResourceType(t *testing.T) {
	got, _ := NewRegistry().Get("Metabase", nil)
	if got.Name() != strategyMetabase {
		t.Fatalf("Metabase inferred %q, want %q", got.Name(), strategyMetabase)
	}
}

func TestAnExplicitStrategyStillOverridesTheInference(t *testing.T) {
	// An operator whose Metabase sits behind SSO must still be able to turn
	// the automatic login off.
	got, err := NewRegistry().Get("metabase", map[string]interface{}{"web_auth_strategy": "none"})
	if err != nil {
		t.Fatal(err)
	}
	if got.Name() != strategyNone {
		t.Fatalf("explicit override lost: got %q", got.Name())
	}
}
