// package identitycredentials

// // GET /identities/{id}/credentials — the Credentials tab.
// //
// // Access keys carry usage fields; roles carry privilege fields. Fields that do
// // not apply to a credential are left out.

// type IdentityCredential struct {
// 	CredentialARN      string `json:"credential_arn"`
// 	Type               string `json:"type"`
// 	Binding            string `json:"binding,omitempty"`
// 	Status             string `json:"status,omitempty"`
// 	AgeDays            *int   `json:"age_days,omitempty"`
// 	LastUsedDays       *int   `json:"last_used_days,omitempty"`
// 	UsageState         string `json:"usage_state,omitempty"`
// 	Privileged         *bool  `json:"privileged,omitempty"`
// 	HasBoundary        *bool  `json:"has_boundary,omitempty"`
// 	MaxSessionDuration *int   `json:"max_session_duration,omitempty"`
// 	OpenFindings       int    `json:"open_findings"`
// }














package identitycredentials

import "encoding/json"

// GET /identities/{id}/credentials — the Credentials tab.
//
// Access keys carry usage fields; roles carry privilege fields.

type IdentityCredential struct {
 CredentialARN      string `json:"credential_arn"`
 Type               string `json:"type"`
 Binding            string `json:"binding,omitempty"`
 Status             string `json:"status,omitempty"`
 AgeDays            *int   `json:"age_days,omitempty"`
 LastUsedDays       *int   `json:"last_used_days,omitempty"`
 UsageState         string `json:"usage_state,omitempty"`
 Privileged         *bool  `json:"privileged,omitempty"`
 HasBoundary        *bool  `json:"has_boundary,omitempty"`
 MaxSessionDuration *int   `json:"max_session_duration,omitempty"`
 OpenFindings       int    `json:"open_findings"`

 isRole bool // IAM role: privilege fields apply; otherwise usage fields apply
}

// MarshalJSON always writes every field that applies to the credential kind
// (null when the value is unknown), so the Credentials tab never loses a key.
func (c IdentityCredential) MarshalJSON() ([]byte, error) {
 out := map[string]any{
  "credential_arn": c.CredentialARN,
  "type":           c.Type,
  "binding":        c.Binding,
  "open_findings":  c.OpenFindings,
 }
 if c.isRole {
  out["privileged"] = c.Privileged
  out["has_boundary"] = c.HasBoundary
  out["max_session_duration"] = c.MaxSessionDuration
 } else {
  var status any
  if c.Status != "" {
   status = c.Status
  }
  var usage any
  if c.UsageState != "" {
   usage = c.UsageState
  }
  out["status"] = status
  out["age_days"] = c.AgeDays
  out["last_used_days"] = c.LastUsedDays
  out["usage_state"] = usage
 }
 return json.Marshal(out)
}