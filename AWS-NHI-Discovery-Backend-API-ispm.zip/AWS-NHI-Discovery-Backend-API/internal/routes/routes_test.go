package routes

import (
	"flag"
	"net/http"
	"os"
	"sort"
	"strings"
	"testing"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/auth"
	"nhi-backend-api/internal/modules/credentialexposure"
	"nhi-backend-api/internal/modules/credentials"
	"nhi-backend-api/internal/modules/dashboard"
	"nhi-backend-api/internal/modules/filters"
	"nhi-backend-api/internal/modules/identities"
	"nhi-backend-api/internal/modules/identityevents"
	"nhi-backend-api/internal/modules/permissionsource"
	"nhi-backend-api/internal/modules/posture"
	"nhi-backend-api/internal/modules/settings"
	"nhi-backend-api/internal/platform/config"
)

var update = flag.Bool("update", false, "rewrite testdata/routes.golden")

// fullContainer wires every handler as a zero value. Routes are registered by
// pointer, so no dependencies are needed to enumerate the route table.
func fullContainer() HandlerContainer {
	return HandlerContainer{
		Auth: auth.New(nil, config.JWTConfig{}),

		Modules: []Module{credentialexposure.New(nil, "", ""), settings.New(nil, nil), dashboard.New(nil, nil), filters.New(nil), identities.New(nil, nil), identityevents.New(nil, nil), credentials.New(nil, nil), permissionsource.New(nil), posture.New(nil, nil)},
	}
}

// TestRouteTableGolden fails when any method+path pair is added, removed or
// renamed, so refactors cannot silently change the public API surface.
func TestRouteTableGolden(t *testing.T) {
	r := SetupRoutes(fullContainer())
	var got []string
	err := r.Walk(func(route *mux.Route, _ *mux.Router, _ []*mux.Route) error {
		path, perr := route.GetPathTemplate()
		if perr != nil {
			return nil // prefix-only subrouter node
		}
		methods, merr := route.GetMethods()
		if merr != nil {
			return nil
		}
		for _, m := range methods {
			got = append(got, m+" "+path)
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	sort.Strings(got)
	body := strings.Join(got, "\n") + "\n"

	const golden = "testdata/routes.golden"
	if *update {
		if err := os.WriteFile(golden, []byte(body), 0o644); err != nil {
			t.Fatal(err)
		}
		return
	}
	want, err := os.ReadFile(golden)
	if err != nil {
		t.Fatalf("read golden (run with -update to create): %v", err)
	}
	if string(want) != body {
		t.Fatalf("route table changed.\n--- want\n%s--- got\n%s", want, body)
	}
	_ = http.MethodGet
}
