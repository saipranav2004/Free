package main

import (
	"fmt"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/launcher"
)

// The whole point of the failure path: a missing tool becomes a code, a
// sentence and an install hint that PAM can store and the console can render.
func TestDescribeLaunchFailureCarriesTheToolDetail(t *testing.T) {
	err := &launcher.ToolNotFoundError{
		ResourceType: "mongodb",
		Tried: []launcher.MissingTool{
			{ID: "mongosh", Command: "mongosh", InstallHint: "macOS 'brew install mongosh'."},
			{ID: "mongodb-compass", Command: "mongodb-compass", InstallHint: "Download Compass from mongodb.com."},
		},
	}

	got := describeLaunchFailure(err)
	if got == nil {
		t.Fatal("describeLaunchFailure returned nil for a real failure")
	}
	if got.Code != "tool_not_installed" {
		t.Fatalf("code = %q", got.Code)
	}
	if !strings.Contains(got.Reason, "mongosh") {
		t.Fatalf("reason = %q, want it to name the tool", got.Reason)
	}
	if !strings.Contains(got.Hint, "brew install mongosh") {
		t.Fatalf("hint = %q, want the install guidance", got.Hint)
	}
}

// The error is wrapped by the time it reaches the reporting call in some
// paths. errors.As has to see through that, or a wrapped ToolNotFoundError
// silently degrades to a generic "launch failed" and the operator loses the
// only sentence that would have helped them.
func TestDescribeLaunchFailureSeesThroughWrapping(t *testing.T) {
	inner := &launcher.ToolNotFoundError{
		ResourceType: "oracle",
		Tried:        []launcher.MissingTool{{ID: "sqlplus", Command: "sqlplus", InstallHint: "Install Oracle Instant Client."}},
	}
	got := describeLaunchFailure(fmt.Errorf("preparing the launch: %w", inner))
	if got.Code != "tool_not_installed" {
		t.Fatalf("code = %q, want the wrapped error's own code", got.Code)
	}
	if !strings.Contains(got.Hint, "Instant Client") {
		t.Fatalf("hint = %q, want the wrapped error's hint", got.Hint)
	}
}

// Anything the agent could not classify still has to reach the operator. A
// silent failure is the bug this whole path exists to remove.
func TestDescribeLaunchFailureAlwaysSaysSomething(t *testing.T) {
	got := describeLaunchFailure(fmt.Errorf("could not open Terminal for the session"))
	if got == nil || got.Reason == "" {
		t.Fatalf("an unclassified error produced %#v, want a reason", got)
	}
	if got.Code != "launch_failed" {
		t.Fatalf("code = %q, want the generic code", got.Code)
	}
	if describeLaunchFailure(nil) != nil {
		t.Fatal("a nil error must not produce a failure report")
	}
}

// A tool that ran and exited non-zero is not a launch failure: the session
// happened. It is still worth reporting, but as a different thing.
func TestReportEndFailureOnlyForANonZeroExit(t *testing.T) {
	if got := reportEndFailure(0); got != nil {
		t.Fatalf("a clean exit produced a failure report: %#v", got)
	}
	got := reportEndFailure(2)
	if got == nil || got.Code != "tool_exited_nonzero" {
		t.Fatalf("got %#v, want a tool_exited_nonzero report", got)
	}
	if !strings.Contains(got.Reason, "2") {
		t.Fatalf("reason = %q, want it to carry the exit status", got.Reason)
	}
}

// A recording obligation must never be quietly dropped. The agent records by
// owning the pseudo-terminal the tool runs in, so a desktop application or a
// browser tab cannot be recorded — and opening one anyway would leave PAM
// holding a session its own policy says is recorded, with no evidence coming.
func TestRecordingObligationIsOnlyMetByACLILaunch(t *testing.T) {
	for _, tc := range []struct {
		mode     string
		required bool
		unmet    bool
	}{
		{mode: "cli", required: true, unmet: false},
		{mode: "gui", required: true, unmet: true},
		{mode: "browser", required: true, unmet: true},
		{mode: "gui", required: false, unmet: false},
		{mode: "browser", required: false, unmet: false},
		{mode: "cli", required: false, unmet: false},
	} {
		pc := &launcher.PreparedCommand{Mode: tc.mode}
		if got := recordingObligationUnmet(tc.required, pc); got != tc.unmet {
			t.Errorf("mode=%s recordingRequired=%v: unmet=%v, want %v", tc.mode, tc.required, got, tc.unmet)
		}
	}
	if recordingObligationUnmet(true, nil) {
		t.Error("a nil command cannot have an unmet obligation; there is no launch to refuse")
	}
}

// The refusal has to explain itself in the same shape as every other failure,
// so the console renders it identically.
func TestUnrecordableLaunchExplainsItself(t *testing.T) {
	got := describeLaunchFailure(&unrecordableLaunchError{
		ResourceType: "mongodb", CandidateID: "mongodb-compass", Mode: "gui",
	})
	if got.Code != "recording_not_possible" {
		t.Fatalf("code = %q", got.Code)
	}
	if !strings.Contains(got.Reason, "mongodb-compass") {
		t.Fatalf("reason = %q, want it to name the application that cannot be recorded", got.Reason)
	}
	if !strings.Contains(got.Hint, "command line client") {
		t.Fatalf("hint = %q, want the way out", got.Hint)
	}
}

// These strings are stored server-side and rendered in a panel, so a runaway
// error from someone's laptop must not arrive unbounded or full of newlines.
func TestFailureTextIsClampedAndFlattened(t *testing.T) {
	got := describeLaunchFailure(fmt.Errorf("line one\nline two\t\tspaced   out %s", strings.Repeat("x", 5000)))
	if strings.ContainsAny(got.Reason, "\n\t") {
		t.Fatalf("reason kept raw whitespace: %q", got.Reason)
	}
	if len(got.Reason) > 400 {
		t.Fatalf("reason length %d exceeds the 400 bound", len(got.Reason))
	}
	if !strings.Contains(got.Reason, "line one line two spaced out") {
		t.Fatalf("reason = %q, want the whitespace collapsed rather than the text mangled", got.Reason[:60])
	}
}
