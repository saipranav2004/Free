/**
 * IdpOverviewPage — every adopted IDP tenant.
 *
 * Port of `templates/overview.html` + `static/tenant_cards.js`. The card itself
 * lives in components/idp/TenantConfigCard.jsx because the adopt wizard renders
 * the same card on its final step — exactly as the original shared one script
 * between both pages.
 *
 * Page anatomy follows the rest of the console: header → summary tiles →
 * toolbar → list. Tiles double as filters, and each tile is derived from the
 * loaded rows so it moves with every refresh.
 *
 * All requests go through lib/api/idp.js, which targets VITE_IDP_API_BASE_URL —
 * a separate service from the IAM backend.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cloud, RefreshCw, Plus, Network, ShieldCheck, AlertTriangle } from 'lucide-react';
import {
  listTenants, getMfaMethods, MFA_METHOD_FALLBACK, IDP_BASE,
} from '../../lib/api/idp.js';
import { useResource } from '../../hooks/useResource.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, EmptyState, Toolbar, SearchInput, StatCard, SegmentedControl,
} from '../../components/ui/primitives.jsx';
import { TenantConfigCard } from '../../components/idp/TenantConfigCard.jsx';

const PLATFORM_FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'entra', label: 'Entra' },
  { value: 'google', label: 'Google' },
];

const isGoogle = (t) => String(t?.platform || '').toLowerCase() === 'google';
const isDeprecated = (t) => !!t?.deprecated || t?.consent_state === 'deprecated';

export default function IdpOverviewPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');

  const tenants = useResource(() => listTenants(), []);
  const mfa = useResource(() => getMfaMethods().catch(() => MFA_METHOD_FALLBACK), []);

  const rows = Array.isArray(tenants.data) ? tenants.data : [];
  const methods = mfa.data || MFA_METHOD_FALLBACK;

  const stats = useMemo(
    () => ({
      total: rows.length,
      entra: rows.filter((t) => !isGoogle(t) && !isDeprecated(t)).length,
      google: rows.filter((t) => isGoogle(t) && !isDeprecated(t)).length,
      deprecated: rows.filter(isDeprecated).length,
    }),
    [rows]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((t) => {
      if (platformFilter === 'entra' && isGoogle(t)) return false;
      if (platformFilter === 'google' && !isGoogle(t)) return false;
      if (!q) return true;
      return (
        String(t.display_name || '').toLowerCase().includes(q) ||
        String(t.verified_domain || '').toLowerCase().includes(q) ||
        String(t.tenant_id || '').toLowerCase().includes(q) ||
        String(t.schema_name || '').toLowerCase().includes(q) ||
        String(t.platform || '').toLowerCase().includes(q)
      );
    });
  }, [rows, search, platformFilter]);

  // A mutation inside a card (sync, federation, policy) can change what the
  // list reports, so the page re-reads rather than trusting local state.
  const reload = useCallback(() => {
    tenants.reload();
  }, [tenants]);

  // Keep the browser tab honest about which service is being administered.
  useEffect(() => {
    document.title = 'IDP · Federation overview';
  }, []);

  return (
    <div>
      <PageHeader
        title="Federation overview"
        description="Every adopted identity-provider tenant, with directory sync, federation state and MFA policy."
        icon={<Network className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Identity provider' }, { label: 'Overview' }]}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={reload} loading={tenants.loading}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button onClick={() => navigate('/idp/tenants')}>
              <Plus className="h-4 w-4" /> Adopt tenant
            </Button>
          </div>
        }
      />

      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            label="Adopted tenants"
            value={stats.total}
            icon={Cloud}
            tone="brand"
            loading={tenants.loading}
            hint="Federated through this IdP"
            onClick={() => setPlatformFilter('all')}
          />
          <StatCard
            label="Microsoft Entra"
            value={stats.entra}
            icon={ShieldCheck}
            tone="sky"
            loading={tenants.loading}
            hint="Graph sync + federation"
            onClick={() => setPlatformFilter('entra')}
          />
          <StatCard
            label="Google Workspace"
            value={stats.google}
            icon={ShieldCheck}
            tone="green"
            loading={tenants.loading}
            hint="SAML metadata consumers"
            onClick={() => setPlatformFilter('google')}
          />
          <StatCard
            label="Deprecated"
            value={stats.deprecated}
            icon={AlertTriangle}
            tone={stats.deprecated ? 'amber' : 'slate'}
            loading={tenants.loading}
            hint="Endpoints published, changes locked"
          />
        </div>

        <Toolbar
          right={
            <div className="flex items-center gap-2">
              <SegmentedControl
                size="sm"
                ariaLabel="Filter by platform"
                value={platformFilter}
                onChange={setPlatformFilter}
                options={PLATFORM_FILTERS}
              />
              <span className="text-2xs text-slate-500 tabular">
                {filtered.length} of {stats.total} tenant{stats.total === 1 ? '' : 's'}
              </span>
            </div>
          }
        >
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search domain, display name, tenant id or schema…"
          />
        </Toolbar>

        {/* A failed load must never read as "no tenants" — the IDP service is a
            separate host, so an unreachable base URL is the likeliest cause. */}
        {tenants.error && !tenants.loading ? (
          <EmptyState
            icon={AlertTriangle}
            title="Could not reach the IDP service"
            description={tenants.error}
            action={
              <div className="flex items-center justify-center gap-2">
                <Button onClick={reload}>Retry</Button>
              </div>
            }
          />
        ) : tenants.loading ? (
          <EmptyState icon={Cloud} title="Loading tenants…" description={`Reading ${IDP_BASE}`} />
        ) : rows.length === 0 ? (
          <EmptyState
            icon={Cloud}
            title="No tenants adopted yet"
            description="Adopt a verified domain to start federating identities through this IdP."
            action={<Button onClick={() => navigate('/idp/tenants')}>Adopt your first tenant</Button>}
          />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={Cloud}
            title={search ? `No tenants match “${search}”` : 'No tenants in this view'}
            description="Adjust the search or platform filter to see more."
            action={
              <Button
                variant="secondary"
                onClick={() => {
                  setSearch('');
                  setPlatformFilter('all');
                }}
              >
                Clear filters
              </Button>
            }
          />
        ) : (
          <div className="space-y-3">
            {filtered.map((t) => (
              <TenantConfigCard
                key={t.tenant_id}
                tenant={t}
                mfaMethods={methods}
                onChanged={reload}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
