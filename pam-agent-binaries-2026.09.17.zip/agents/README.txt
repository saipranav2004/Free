pam-agent binaries — version 2026.09.17
=======================================

Built from the pam-agent source in this delivery with install/build-release.sh
(CGO_ENABLED=0, -trimpath, -ldflags "-s -w -X main.version=2026.09.17"). Pure
Go, statically linked, no runtime dependencies.

HOW TO INSTALL
--------------
Copy the five pam-agent_* files plus VERSION into your backend's agent
directory — the one PAM_AGENT_BINARY_DIR points at, which in this tree is:

    backend_upd/agents/

Then restart pam-api. It re-scans the directory on start and logs:

    agentdist.scanned  {"targets": 5, "version": "2026.09.17"}

On Linux/macOS make sure the files keep their executable bit (chmod 755) if
your copy method drops it. Windows needs nothing special.

WHAT IS IN HERE
---------------
    pam-agent_windows_amd64.exe    Windows 64-bit
    pam-agent_darwin_arm64         macOS Apple Silicon
    pam-agent_darwin_amd64         macOS Intel
    pam-agent_linux_amd64          Linux x86-64
    pam-agent_linux_arm64          Linux ARM64
    VERSION                        read by the server, shown in the console
    SHA256SUMS.txt                 for your own verification

A platform whose file is missing simply disappears from the console's
enrolment picker — that is deliberate, so an operator is never offered a
download that would 404.

VERIFYING
---------
    sha256sum -c SHA256SUMS.txt

Note that the server does NOT read SHA256SUMS.txt. It hashes each file itself
at scan time and publishes that hash through /pam/agent/install/targets, so a
tampered file shows a different hash in the console rather than a matching
line in a text file an attacker could also edit. SHA256SUMS.txt is here for
your own out-of-band check.

VERSION FLOOR
-------------
If you set agent.min_version (PAM_AGENT_MIN_VERSION), the server refuses a
launch from any agent below it — before the launch token is consumed, so a
refused attempt does not burn a single-use token. An agent that reports no
version at all is treated as "unknown" and refused too: the floor refuses what
it cannot verify. Leave it empty to disable the check.
