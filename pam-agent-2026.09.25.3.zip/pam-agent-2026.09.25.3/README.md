# pam-agent 2026.09.25.3 — fixes pgAdmin still asking for the password on Windows

Replace your `backend_upd/agents/` folder with the one in this zip, restart `pam-api`, then re-install the agent on the Windows machine from the console (Settings → Devices). Nothing else changed; the backend and console code are the same as in the round-8 zip.

Check the files: `cd backend_upd/agents && sha256sum -c SHA256SUMS.txt`
(PowerShell: `Get-FileHash .\pam-agent_windows_amd64.exe` and compare it with the line in `SHA256SUMS.txt`.)

## Why pgAdmin still asked for the password

Your log shows it:

    launch.pgadmin_preseed.fail … ImportError: no pq wrapper available.
      - couldn't import psycopg 'c' implementation: DLL load failed …
      - couldn't import psycopg 'python' implementation: libpq library not found

Before pgAdmin opens, the agent registers PAM's server in pgAdmin, using pgAdmin's own Python. On Windows, pgAdmin keeps `libpq.dll` and the OpenSSL DLLs in `C:\Program Files\PostgreSQL\18\pgAdmin 4\runtime\`, beside `pgAdmin4.exe`, not beside `python.exe`. pgAdmin's launcher adds that folder to `PATH` before it starts Python; this is in pgAdmin's `runtime/src/js/pgadmin.js`. The agent didn't, so Python couldn't load `libpq`. As a result the PAM server was never added: your tree shows only "PostgreSQL 18", with no "PAM" group. The prompt you saw belongs to your own "PostgreSQL 18" entry.

## What changed

- The agent now puts `<pgAdmin install>\runtime` first on `PATH`, the same way pgAdmin's launcher does. It also registers that folder as a DLL directory, which is how Python 3.8+ finds an extension module's DLLs.
- If registering the server in pgAdmin ever fails again, the operator gets a desktop notification with the one-line reason, instead of a silent password prompt.

## What you should see after updating

1. Click **Open in Desktop** on the PostgreSQL resource.
2. pgAdmin opens with a **PAM** group containing **PAM - psql-database-1…**.
3. Expand it. It connects with no password dialog. Your own "PostgreSQL 18" entry is untouched and still uses its own password.
4. The agent log shows `launch.pgadmin_preseed.ok` instead of `…fail`.

Tested: new unit tests pin the exact Windows `PATH` for your install path (`C:\Program Files\PostgreSQL\18\pgAdmin 4\...`). The full agent test suite passes, and so do the Windows/macOS builds. The live pgAdmin click test was re-run with this exact release build (on Linux): no prompt, and the connection shows in `pg_stat_activity`. I have no Windows machine here, so your next launch is the first live Windows run of this fix. If it still fails, send the `launch.pgadmin_preseed…` line from the log again.
