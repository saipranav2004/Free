// pam-agent/internal/launcher/templates.go
package launcher

import (
	_ "embed"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"text/template"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/discovery"
)

//go:embed launch-templates.default.json
var defaultTemplatesJSON []byte

// LoadTemplates reads launch-templates.json from configDir, writing the
// built-in defaults there first if no file exists yet — so `pam-agent` works
// out of the box, but an admin can edit that file afterward (add more
// resource types or candidates, point at a differently-installed binary,
// change discovery paths, change args) without recompiling anything.
//
// Each resource type maps to an ORDERED LIST of candidates — e.g. Postgres
// tries "psql" first and falls back to "pgAdmin4" if psql isn't installed —
// rather than a single fixed tool, so a machine that only has the GUI
// client still works.
func LoadTemplates(configDir string) (map[string][]Candidate, error) {
	path := filepath.Join(configDir, "launch-templates.json")

	if _, err := os.Stat(path); os.IsNotExist(err) {
		if err := os.WriteFile(path, defaultTemplatesJSON, 0o644); err != nil {
			return nil, fmt.Errorf("failed to write default launch-templates.json: %w", err)
		}
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read %s: %w", path, err)
	}

	var templates map[string][]Candidate
	if err := json.Unmarshal(raw, &templates); err != nil {
		return nil, fmt.Errorf("failed to parse %s: %w", path, err)
	}
	return templates, nil
}

// templateData is what {{.Host}}-style placeholders in a Candidate's Args
// (or a "browser" Candidate's Command) resolve against. Password is
// deliberately NOT exposed here — every injection strategy in credential.go
// handles the credential explicitly and separately, so a plain
// arg-templating mistake can never leak it into a process's command line.
type templateData struct {
	Host         string
	Port         string
	DatabaseName string
	AccountName  string
	ConsoleURL   string
}

// SelectAndBuildCommand walks a resource type's candidate list in order —
// reordered first by any "preferred_tool" hint in the resource's
// ExtraConfig (set by an admin on the PAM backend; see reorderByPreferred)
// — and builds a PreparedCommand from the first one that's actually usable
// on this machine:
//   - a "browser" candidate is always usable (no discovery needed)
//   - any other candidate is usable only if discovery.Locate finds its tool
//
// Returns the Candidate actually chosen (for logging) alongside the
// command, or an error listing every candidate ID that was tried and not
// found if none of them are usable.
func SelectAndBuildCommand(resolved *apiclient.ResolvedLaunch, candidates []Candidate, tempDir string, log *slog.Logger) (*PreparedCommand, *Candidate, error) {
	ordered := reorderByPreferred(candidates, resolved.ExtraConfig)

	var tried []string
	for i := range ordered {
		cand := &ordered[i]

		if cand.Kind == "browser" {
			cmd, err := buildBrowserCommand(resolved, cand)
			if err != nil {
				return nil, cand, err
			}
			log.Info("launch.candidate.selected", "resource_type", resolved.ResourceType, "candidate", cand.ID, "kind", "browser")
			return cmd, cand, nil
		}

		result := discovery.Locate(cand.Discovery)
		if !result.Found() {
			tried = append(tried, cand.ID)
			log.Debug("launch.candidate.not_found", "resource_type", resolved.ResourceType, "candidate", cand.ID)
			continue
		}

		cmd, err := buildCommand(resolved, cand, result, tempDir)
		if err != nil {
			return nil, cand, err
		}
		log.Info("launch.candidate.selected", "resource_type", resolved.ResourceType, "candidate", cand.ID, "kind", cand.Kind,
			"path", result.Path, "app_bundle", result.AppBundle)
		return cmd, cand, nil
	}

	if len(ordered) == 0 {
		return nil, nil, fmt.Errorf("no launch candidates configured for resource type %q", resolved.ResourceType)
	}
	return nil, nil, fmt.Errorf(
		"no installed tool found for resource type %q — tried: %s (none were on PATH or in their usual install location). "+
			"Install one of these, or edit launch-templates.json to point at where it's actually installed on this machine",
		resolved.ResourceType, strings.Join(tried, ", "))
}

// reorderByPreferred moves the candidate whose ID matches
// extraConfig["preferred_tool"] to the front of the list, leaving the rest
// of the fallback order intact. This is the ONLY way the PAM backend can
// influence which local tool gets used — it names a candidate ID already
// baked into this machine's launch-templates.json, never an arbitrary path
// or command. A backend that wants "always use pgAdmin4 for this resource"
// sets extra_config: {"preferred_tool": "pgadmin4"} on the resource; a
// backend trying to make the agent run something unexpected has no lever
// to pull here at all — deliberately.
func reorderByPreferred(candidates []Candidate, extraConfig map[string]interface{}) []Candidate {
	preferred, _ := extraConfig["preferred_tool"].(string)
	if preferred == "" {
		return candidates
	}
	idx := -1
	for i, c := range candidates {
		if c.ID == preferred {
			idx = i
			break
		}
	}
	if idx <= 0 {
		return candidates
	}
	out := make([]Candidate, 0, len(candidates))
	out = append(out, candidates[idx])
	out = append(out, candidates[:idx]...)
	out = append(out, candidates[idx+1:]...)
	return out
}

func buildCommand(resolved *apiclient.ResolvedLaunch, cand *Candidate, located discovery.Result, tempDir string) (*PreparedCommand, error) {
	dbName := resolved.DatabaseName
	if dbName == "" && resolved.ResourceType == "postgresql" {
		dbName = "postgres" // matches the browser session gateway's own default
	}

	data := templateData{
		Host:         resolved.Host,
		Port:         strconv.Itoa(resolved.Port),
		DatabaseName: dbName,
		AccountName:  resolved.AccountName,
		ConsoleURL:   resolved.ConsoleURL,
	}

	args, err := renderArgs(cand.Args, data)
	if err != nil {
		return nil, fmt.Errorf("failed to render command arguments for candidate %s: %w", cand.ID, err)
	}

	execPath := located.Path
	if execPath == "" {
		// macOS app-bundle-only hit (no direct binary path) — Exec carries
		// the bundle name for logging/Title purposes; the darwin Spawn
		// implementation launches AppBundle via `open -a`, not Exec.
		execPath = cand.Command
	}

	cmd := &PreparedCommand{
		Exec:      execPath,
		Args:      args,
		Mode:      cand.Kind,
		Title:     fmt.Sprintf("PAM — %s (%s)", resolved.ResourceType, cand.ID),
		AppBundle: located.AppBundle,
	}

	switch cand.CredentialInjection {
	case "", "none":
		// nothing to inject
	case "env":
		if cand.CredentialEnvVar == "" {
			return nil, fmt.Errorf("candidate %s uses env credential injection but has no credential_env_var set", cand.ID)
		}
		cmd.Env = append(cmd.Env, cand.CredentialEnvVar+"="+resolved.Password)
	case "pgpass":
		pgpassPath, err := writePgpassFile(tempDir, data.Host, data.Port, dbName, resolved.AccountName, resolved.Password)
		if err != nil {
			return nil, err
		}
		cmd.Env = append(cmd.Env, "PGPASSFILE="+pgpassPath)
		cmd.CleanupFiles = append(cmd.CleanupFiles, pgpassPath)
	case "mongo_init_file":
		initPath, err := writeMongoInitFile(tempDir, resolved)
		if err != nil {
			return nil, err
		}
		cmd.Args = append(cmd.Args, "--shell", initPath)
		cmd.CleanupFiles = append(cmd.CleanupFiles, initPath)
	case "clickhouse_config_file":
		configPath, err := writeClickhouseConfigFile(tempDir, resolved)
		if err != nil {
			return nil, err
		}
		cmd.Args = append(cmd.Args, "--config-file", configPath)
		cmd.CleanupFiles = append(cmd.CleanupFiles, configPath)
	case "connection_string_arg":
		// Best-effort GUI path (e.g. MongoDB Compass, which accepts a
		// connection string as its first CLI argument). This is the one
		// injection mode where the credential IS present in the argument
		// list, and therefore briefly visible to other processes/tools that
		// can read this process's command line (ps, Task Manager, etc.) —
		// documented in the README as a real, known tradeoff of this mode,
		// not hidden. Prefer "env"/"pgpass"/"mongo_init_file" wherever the
		// target tool supports it.
		cmd.Args = append(cmd.Args, buildConnectionString(resolved, dbName))
	case "oracle_connect_string":
		// sqlplus/SQLcl's own EZCONNECT logon syntax — see
		// buildOracleConnectString for why this isn't just another branch
		// of buildConnectionString above.
		connStr, err := buildOracleConnectString(resolved, dbName)
		if err != nil {
			return nil, err
		}
		cmd.Args = append(cmd.Args, connStr)
	case "minio_mc_shell":
		// mc was confirmed installed by discovery above (that's what
		// execPath/located.Path just resolved), but mc itself has no
		// interactive REPL to exec directly — see resolveInteractiveShell's
		// doc comment. So this candidate's real payload is the operator's
		// own shell, with MC_HOST_pam already exported: every `mc ls
		// pam/...`, `mc cp ...`, etc. they type from that shell is already
		// authenticated, with nothing ever written to argv or to this
		// machine's own ~/.mc/config.json.
		shellPath, err := resolveInteractiveShell()
		if err != nil {
			return nil, fmt.Errorf("found mc, but %w — install one, or edit launch-templates.json to use a different minio candidate", err)
		}

		// mc's OWN DIRECTORY GOES ON PATH, not just the credential.
		//
		// This candidate is the one that hands the operator a shell instead
		// of running the tool, so "discovery found mc" is not enough on its
		// own: the shell has to be able to resolve `mc` too. Discovery
		// locates it by absolute path (C:\mc\mc.exe, /usr/local/bin/mc, an
		// absolute_path_globs hit) just as readily as it finds it on PATH,
		// and in the absolute-path case the shell inherits no knowledge of
		// where it went.
		//
		// Confirmed live on Windows with mc at C:\mc\mc.exe: the session
		// opened, MC_HOST_pam was set correctly, and the very first command
		// the operator was told to type answered "'mc' is not recognized as
		// an internal or external command" — an authenticated session in
		// which nothing could be run. Prepending, so a copy already on PATH
		// still wins for anything else the operator does in that shell.
		if mcDir := filepath.Dir(execPath); mcDir != "" && mcDir != "." {
			cmd.Env = append(cmd.Env, "PATH="+mcDir+string(os.PathListSeparator)+os.Getenv("PATH"))
		}

		cmd.Exec = shellPath
		cmd.Args = nil
		cmd.Title = fmt.Sprintf("PAM — %s (mc alias %q ready)", resolved.ResourceType, "pam")
		cmd.Env = append(cmd.Env, buildMinIOAliasEnv(resolved))
	case "pgadmin_preseed":
		// Best-effort: registers host/port/username (NEVER the password)
		// into pgAdmin4's own server tree via its documented --load-servers
		// mechanism, run as a separate pre-step before the GUI itself
		// launches. See pgadmin_preseed.go — failure here is logged and
		// swallowed, not fatal, since pgAdmin4 still opens fine without it
		// and this mechanism is known to vary across pgAdmin4 install types.
		preseedPath, err := writePgAdminServersFile(tempDir, resolved, dbName)
		if err != nil {
			return nil, err
		}
		cmd.CleanupFiles = append(cmd.CleanupFiles, preseedPath)
		cmd.PreseedLoadServersPath = preseedPath

		// CONFIRMED LIVE: setting PGPASSFILE here (the same libpq mechanism
		// psql's own "pgpass" case relies on) does NOT suppress pgAdmin4's
		// password prompt — its "Connect to Server" dialog is pgAdmin4's own
		// UI-level gate, shown unconditionally on first connect BEFORE it
		// ever attempts a real libpq/psycopg2 connection, so PGPASSFILE is
		// never consulted at all. This is a hard limit of pgAdmin4 itself,
		// not something fixable from the agent side — do not re-attempt a
		// PGPASSFILE/env-based approach here without first confirming
		// pgAdmin4 has changed this behavior. Clipboard is the closest thing
		// left to "already logged in" for this specific GUI tool; psql (this
		// resource type's preferred candidate) remains the fully headless
		// path — see CopyPasswordToClipboard's doc comment.
		cmd.CopyPasswordToClipboard = true
	default:
		return nil, fmt.Errorf("unknown credential_injection %q for candidate %s", cand.CredentialInjection, cand.ID)
	}

	return cmd, nil
}

// buildBrowserCommand renders a "browser" candidate's Command as the URL to
// open. Most "browser" resources (Langfuse, Metabase, Qdrant's dashboard)
// have no credential involved at all — the operator authenticates in the
// browser itself, same as if they'd typed the URL in by hand.
//
// "clipboard" is the one exception: a resource whose web console has no
// auto-login mechanism this agent can drive from outside the browser (see
// MinIO's entry in launch-templates.default.json — its console API rejects
// both a plain HTML form POST, wrong content-type, and a cross-origin
// fetch/XHR, no CORS preflight support at all) still gets the password onto
// the clipboard, so logging in is one paste instead of retyping/copying it
// out of PAM's own UI separately.
func buildBrowserCommand(resolved *apiclient.ResolvedLaunch, cand *Candidate) (*PreparedCommand, error) {
	if resolved.ConsoleURL == "" {
		return nil, fmt.Errorf(
			"resource type %q is configured to open in a browser, but this resource has no console_url set — "+
				"an admin needs to set console_url on the PAM resource", resolved.ResourceType)
	}

	data := templateData{
		Host: resolved.Host, Port: strconv.Itoa(resolved.Port),
		DatabaseName: resolved.DatabaseName, AccountName: resolved.AccountName,
		ConsoleURL: resolved.ConsoleURL,
	}
	rendered, err := renderArgs([]string{cand.Command}, data)
	if err != nil {
		return nil, fmt.Errorf("failed to render browser URL for candidate %s: %w", cand.ID, err)
	}

	cmd := &PreparedCommand{
		Exec:  rendered[0],
		Mode:  "browser",
		Title: fmt.Sprintf("PAM — %s (%s)", resolved.ResourceType, cand.ID),
	}
	if cand.CredentialInjection == "clipboard" {
		cmd.CopyPasswordToClipboard = true
	}
	return cmd, nil
}

func renderArgs(argTemplates []string, data templateData) ([]string, error) {
	rendered := make([]string, len(argTemplates))
	for i, a := range argTemplates {
		tmpl, err := template.New("arg").Parse(a)
		if err != nil {
			return nil, fmt.Errorf("invalid template %q: %w", a, err)
		}
		var sb strings.Builder
		if err := tmpl.Execute(&sb, data); err != nil {
			return nil, fmt.Errorf("failed to render %q: %w", a, err)
		}
		rendered[i] = sb.String()
	}
	return rendered, nil
}
