# Architecture

The code is organised **by feature**. Each feature is one package under
`internal/modules/`, and shared plumbing lives in `internal/platform/`.

```
cmd/api-server/        main: load config, build dependencies, list modules
internal/
  routes/              builds the router; mounts every module (see below)
  modules/             one package per feature, each with handler + service + repo + dto
    auth/              login, refresh, logout, /me, auth middleware
    settings/          per-user dashboard settings
    credentialexposure/ secret-scanner findings, allowlist, decisions, deep scan
    credentials/       credential list and credential detail
    identities/        identity list and identity detail
    identityevents/    identity events (timeline, sessions, errors, heatmap, ...)
    dashboard/         dashboard overview
    filters/           filter options
    permissionsource/  which policy granted an event
    posture/           ISPM posture dashboard API (16 endpoints under /ispm, own envelope; see ISPM_Dashboard_API_v2.md).
                        One sub-folder per endpoint (overview, quickwins, export, identitylist, facets, ...),
                        each with its own handler, service, repo and dto; shared code is in posture/common
    _template/         copy this to start a new module (not compiled)
  identitygraph/       shared engine behind credentials/identities/dashboard (not routed):
                       activity service, relationship graph, trust-policy parser,
                       the credential/identity detail queries and their DTOs
    eventstore/        ClickHouse queries
  integration/         end-to-end tests that need a real database (skip without NHI_TEST_*)
  platform/            shared infrastructure, no business logic
    config/ database/ clickhouse/ jwt/ middleware/ scope/ httpx/
migrations/            global/ (auth, tenant registry) and tenant/ (per-tenant schema)
configs/  docs/  scripts/
```

## Layers inside a module

A request goes through the same three layers in every module:

| File | Layer | Does | Must not |
|---|---|---|---|
| `handler.go` | HTTP | read and validate the request, call the service, write the response | contain SQL or business rules |
| `service.go` | business | resolve the caller's scope, apply rules, call the repo | import `net/http` |
| `repo.go` | data | run SQL / ClickHouse queries bound to the scope | decide anything about HTTP |
| `dto.go` | shapes | JSON request and response structs | |
| `module.go` | wiring | `New(...)` builds the pieces, `Register(r)` mounts routes | |

Modules with several endpoints (like `identities`) keep one
`<name>_handler.go`, `<name>_service.go`, `<name>_repo.go`, `<name>_dto.go` set
per endpoint.

## Rules

1. A module imports `platform/*` and, for the identity/credential features,
   `identitygraph`. It never imports another module. If two modules need the
   same code, move that code into `identitygraph` (identity/credential graph
   logic) or `platform/` (generic plumbing). The credentials and identities
   detail queries are shared because the identity detail view reuses the
   credential detail graph traversal.
2. Tenant isolation always goes through `platform/scope`. Resolve the caller's
   scope in the service and bind every query to it. Never trust an account or
   region from the client.
3. Use `platform/httpx` for responses (`APIResponse`, `WriteJSON`,
   `WriteError`) and query validation (`RejectUnknownQuery`, `IsValidDate`).
   Do not write new copies of these helpers.
4. Never return `err.Error()` to the client. Log the cause, return a fixed
   message and an error code.
5. Routes are relative (`/identities`). The router mounts them under `/api/v1`
   and, for backward compatibility, under the legacy `/api`.

## Adding an API

*Extending an existing module* (for example a new identities endpoint): add
`<name>_handler.go`, `_service.go`, `_repo.go`, `_dto.go` next to the others,
add the handler to `Module` and its route to `Register` in `module.go`.

*A new feature*: copy `internal/modules/_template/` (see its README), then:

1. Rename the files and the package.
2. Add `<feature>.New(...)` to the `Modules` list in `cmd/api-server/main.go`.
3. Regenerate the route snapshot and review the diff:
   `go test ./internal/routes -update`
4. Add a request to `docs/postman`.

## Guard rails

- `internal/routes/routes_test.go` compares every registered method+path with
  `internal/routes/testdata/routes.golden`. A route cannot be added, removed
  or renamed without updating that file in the same change.
- `go build ./... && go vet ./... && go test ./...` must pass. The ClickHouse
  and tenant-database integration tests skip themselves unless the
  `NHI_TEST_*` variables are set.
