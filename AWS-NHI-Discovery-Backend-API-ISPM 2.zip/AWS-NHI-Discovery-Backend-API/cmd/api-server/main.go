// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"
// 	"net/http"
// 	"os"
// 	"os/signal"
// 	"syscall"
// 	"time"

// 	"github.com/joho/godotenv"

// 	"nhi-backend-api/internal/identitygraph"
// 	"nhi-backend-api/internal/identitygraph/eventstore"
// 	"nhi-backend-api/internal/modules/auth"
// 	"nhi-backend-api/internal/modules/credentialexposure"
// 	"nhi-backend-api/internal/modules/credentials"
// 	"nhi-backend-api/internal/modules/dashboard"
// 	"nhi-backend-api/internal/modules/filters"
// 	"nhi-backend-api/internal/modules/identities"
// 	"nhi-backend-api/internal/modules/identityevents"
// 	"nhi-backend-api/internal/modules/permissionsource"
// 	"nhi-backend-api/internal/modules/posture"
// 	"nhi-backend-api/internal/modules/settings"
// 	"nhi-backend-api/internal/platform/clickhouse"
// 	"nhi-backend-api/internal/platform/config"
// 	"nhi-backend-api/internal/platform/database"
// 	"nhi-backend-api/internal/platform/middleware"
// 	"nhi-backend-api/internal/platform/scope"
// 	"nhi-backend-api/internal/routes"
// )

// func main() {
// 	// Optional .env for local runs; variables already in the environment win.
// 	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
// 		log.Fatalf("load .env: %v", err)
// 	}

// 	cfg, err := config.Load()
// 	if err != nil {
// 		log.Fatalf("load configuration: %v", err)
// 	}

// 	// DB is the global authentication/tenant registry pool. Tenant pools are
// 	// opened only through the registry-validated db_name in a signed token.
// 	db, err := database.NewPostgresDB(cfg)
// 	if err != nil {
// 		log.Fatalf("connect to global database: %v", err)
// 	}
// 	defer func() {
// 		if err := db.Close(); err != nil {
// 			log.Printf("close database pools: %v", err)
// 		}
// 	}()

// 	// ClickHouse (CloudTrail events) is optional. If it is unconfigured or
// 	// unreachable the API keeps serving Postgres data; chClient is then nil.
// 	chCtx, chCancel := context.WithTimeout(context.Background(), 10*time.Second)
// 	chClient, err := clickhouse.New(chCtx, cfg.ClickHouse)
// 	chCancel()
// 	switch {
// 	case err != nil:
// 		log.Printf("WARNING: clickhouse unavailable, activity data disabled: %v", err)
// 	case chClient == nil:
// 		log.Printf("clickhouse not configured; activity data disabled")
// 	default:
// 		log.Printf("clickhouse connected (%s:%d/%s)", cfg.ClickHouse.Host, cfg.ClickHouse.Port, cfg.ClickHouse.Database)
// 	}
// 	defer func() {
// 		if err := chClient.Close(); err != nil {
// 			log.Printf("close clickhouse: %v", err)
// 		}
// 	}()

// 	resolver := scope.NewResolver(db)
// 	// One activity service (ClickHouse events + identity lookup) is shared by
// 	// every identity/credential module.
// 	events := eventstore.New(chClient)
// 	activity := identitygraph.NewActivityService(events, identitygraph.NewIdentityLookupRepository())

// 	router := routes.SetupRoutes(routes.HandlerContainer{
// 		Auth: auth.New(db, cfg.JWT),

// 		Modules: []routes.Module{
// 			credentialexposure.New(resolver, cfg.Scanner.BaseURL, cfg.Scanner.DashboardKey),
// 			settings.New(db, resolver),
// 			dashboard.New(resolver, activity),
// 			filters.New(resolver),
// 			identities.New(resolver, activity),
// 			identityevents.New(resolver, activity),
// 			credentials.New(resolver, activity),
// 			permissionsource.New(resolver),
// 			posture.New(resolver, events),
// 		},
// 	})

// 	server := &http.Server{
// 		Addr:         fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port),
// 		Handler:      middleware.SetupCORS(cfg.CORS)(router),
// 		ReadTimeout:  15 * time.Second,
// 		WriteTimeout: 15 * time.Second,
// 		IdleTimeout:  60 * time.Second,
// 	}
// 	// Drain in-flight requests on SIGINT/SIGTERM so deferred cleanup (pool
// 	// close) runs instead of the process being killed mid-request.
// 	sigCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
// 	defer stop()
// 	serveErr := make(chan error, 1)
// 	go func() { serveErr <- server.ListenAndServe() }()
// 	log.Printf("NHI API server listening on %s", server.Addr)

// 	select {
// 	case err := <-serveErr:
// 		if err != nil && err != http.ErrServerClosed {
// 			// Keep the original non-zero exit; close pools first since Fatalf skips defers.
// 			_ = db.Close()
// 			log.Fatalf("API server: %v", err)
// 		}
// 	case <-sigCtx.Done():
// 		log.Printf("shutdown signal received, draining requests")
// 		shutdownCtx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
// 		defer cancel()
// 		if err := server.Shutdown(shutdownCtx); err != nil {
// 			log.Printf("graceful shutdown: %v", err)
// 		}
// 	}
// }





























// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"
// 	"net/http"
// 	"os"
// 	"os/signal"
// 	"syscall"
// 	"time"

// 	"github.com/joho/godotenv"

// 	"nhi-backend-api/internal/identitygraph"
// 	"nhi-backend-api/internal/identitygraph/eventstore"
// 	"nhi-backend-api/internal/modules/auth"
// 	"nhi-backend-api/internal/modules/credentialexposure"
// 	"nhi-backend-api/internal/modules/credentials"
// 	"nhi-backend-api/internal/modules/dashboard"
// 	"nhi-backend-api/internal/modules/filters"
// 	"nhi-backend-api/internal/modules/identities"
// 	"nhi-backend-api/internal/modules/identityevents"
// 	"nhi-backend-api/internal/modules/permissionsource"
// 	"nhi-backend-api/internal/modules/posture"
// 	"nhi-backend-api/internal/modules/posture/scan"
// 	"nhi-backend-api/internal/modules/settings"
// 	"nhi-backend-api/internal/platform/clickhouse"
// 	"nhi-backend-api/internal/platform/config"
// 	"nhi-backend-api/internal/platform/database"
// 	"nhi-backend-api/internal/platform/middleware"
// 	"nhi-backend-api/internal/platform/scope"
// 	"nhi-backend-api/internal/routes"
// )

// func main() {
// 	// Optional .env for local runs; variables already in the environment win.
// 	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
// 		log.Fatalf("load .env: %v", err)
// 	}

// 	cfg, err := config.Load()
// 	if err != nil {
// 		log.Fatalf("load configuration: %v", err)
// 	}

// 	// DB is the global authentication/tenant registry pool. Tenant pools are
// 	// opened only through the registry-validated db_name in a signed token.
// 	db, err := database.NewPostgresDB(cfg)
// 	if err != nil {
// 		log.Fatalf("connect to global database: %v", err)
// 	}
// 	defer func() {
// 		if err := db.Close(); err != nil {
// 			log.Printf("close database pools: %v", err)
// 		}
// 	}()

// 	// ClickHouse (CloudTrail events) is optional. If it is unconfigured or
// 	// unreachable the API keeps serving Postgres data; chClient is then nil.
// 	chCtx, chCancel := context.WithTimeout(context.Background(), 10*time.Second)
// 	chClient, err := clickhouse.New(chCtx, cfg.ClickHouse)
// 	chCancel()
// 	switch {
// 	case err != nil:
// 		log.Printf("WARNING: clickhouse unavailable, activity data disabled: %v", err)
// 	case chClient == nil:
// 		log.Printf("clickhouse not configured; activity data disabled")
// 	default:
// 		log.Printf("clickhouse connected (%s:%d/%s)", cfg.ClickHouse.Host, cfg.ClickHouse.Port, cfg.ClickHouse.Database)
// 	}
// 	defer func() {
// 		if err := chClient.Close(); err != nil {
// 			log.Printf("close clickhouse: %v", err)
// 		}
// 	}()

// 	resolver := scope.NewResolver(db)
// 	// One activity service (ClickHouse events + identity lookup) is shared by
// 	// every identity/credential module.
// 	events := eventstore.New(chClient)
// 	activity := identitygraph.NewActivityService(events, identitygraph.NewIdentityLookupRepository())

// 	router := routes.SetupRoutes(routes.HandlerContainer{
// 		Auth: auth.New(db, cfg.JWT),

// 		Modules: []routes.Module{
// 			credentialexposure.New(resolver, cfg.Scanner.BaseURL, cfg.Scanner.DashboardKey),
// 			settings.New(db, resolver),
// 			dashboard.New(resolver, activity),
// 			filters.New(resolver),
// 			identities.New(resolver, activity),
// 			identityevents.New(resolver, activity),
// 			credentials.New(resolver, activity),
// 			permissionsource.New(resolver),
// 			posture.New(resolver, events, scan.WorkerConfig{
// 				BaseURL: cfg.Worker.BaseURL,
// 				Token:   cfg.Worker.ScanToken,
// 				Timeout: time.Duration(cfg.Worker.TimeoutSeconds) * time.Second,
// 			}),
// 		},
// 	})

// 	server := &http.Server{
// 		Addr:         fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port),
// 		Handler:      middleware.SetupCORS(cfg.CORS)(router),
// 		ReadTimeout:  15 * time.Second,
// 		WriteTimeout: 15 * time.Second,
// 		IdleTimeout:  60 * time.Second,
// 	}
// 	// Drain in-flight requests on SIGINT/SIGTERM so deferred cleanup (pool
// 	// close) runs instead of the process being killed mid-request.
// 	sigCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
// 	defer stop()
// 	serveErr := make(chan error, 1)
// 	go func() { serveErr <- server.ListenAndServe() }()
// 	log.Printf("NHI API server listening on %s", server.Addr)

// 	select {
// 	case err := <-serveErr:
// 		if err != nil && err != http.ErrServerClosed {
// 			// Keep the original non-zero exit; close pools first since Fatalf skips defers.
// 			_ = db.Close()
// 			log.Fatalf("API server: %v", err)
// 		}
// 	case <-sigCtx.Done():
// 		log.Printf("shutdown signal received, draining requests")
// 		shutdownCtx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
// 		defer cancel()
// 		if err := server.Shutdown(shutdownCtx); err != nil {
// 			log.Printf("graceful shutdown: %v", err)
// 		}
// 	}
// }























package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/identitygraph/eventstore"
	"nhi-backend-api/internal/modules/auth"
	"nhi-backend-api/internal/modules/credentialexposure"
	"nhi-backend-api/internal/modules/credentials"
	"nhi-backend-api/internal/modules/dashboard"
	"nhi-backend-api/internal/modules/filters"
	"nhi-backend-api/internal/modules/identities"
	"nhi-backend-api/internal/modules/identityevents"
	"nhi-backend-api/internal/modules/permissionsource"
	"nhi-backend-api/internal/modules/posture"
	"nhi-backend-api/internal/modules/posture/scan"
	"nhi-backend-api/internal/modules/settings"
	"nhi-backend-api/internal/platform/clickhouse"
	"nhi-backend-api/internal/platform/config"
	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/middleware"
	"nhi-backend-api/internal/platform/scope"
	"nhi-backend-api/internal/routes"
)

func main() {
	// Optional .env for local runs; variables already in the environment win.
	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
		log.Fatalf("load .env: %v", err)
	}

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("load configuration: %v", err)
	}

	// DB is the global authentication/tenant registry pool. Tenant pools are
	// opened only through the registry-validated db_name in a signed token.
	db, err := database.NewPostgresDB(cfg)
	if err != nil {
		log.Fatalf("connect to global database: %v", err)
	}
	defer func() {
		if err := db.Close(); err != nil {
			log.Printf("close database pools: %v", err)
		}
	}()

	// ClickHouse (CloudTrail events) is optional. If it is unconfigured or
	// unreachable the API keeps serving Postgres data; chClient is then nil.
	chCtx, chCancel := context.WithTimeout(context.Background(), 10*time.Second)
	chClient, err := clickhouse.New(chCtx, cfg.ClickHouse)
	chCancel()
	switch {
	case err != nil:
		log.Printf("WARNING: clickhouse unavailable, activity data disabled: %v", err)
	case chClient == nil:
		log.Printf("clickhouse not configured; activity data disabled")
	default:
		log.Printf("clickhouse connected (%s:%d/%s)", cfg.ClickHouse.Host, cfg.ClickHouse.Port, cfg.ClickHouse.Database)
	}
	defer func() {
		if err := chClient.Close(); err != nil {
			log.Printf("close clickhouse: %v", err)
		}
	}()

	resolver := scope.NewResolver(db)
	// One activity service (ClickHouse events + identity lookup) is shared by
	// every identity/credential module.
	events := eventstore.New(chClient)
	activity := identitygraph.NewActivityService(events, identitygraph.NewIdentityLookupRepository())

	workerCfg := scan.WorkerConfig{
		BaseURL: cfg.Worker.BaseURL,
		Token:   cfg.Worker.ScanToken, // only the login-based Sync route uses it
		Timeout: time.Duration(cfg.Worker.TimeoutSeconds) * time.Second,
	}
	router := routes.SetupRoutes(routes.HandlerContainer{
		Auth: auth.New(db, cfg.JWT),

		Modules: []routes.Module{
			credentialexposure.New(resolver, cfg.Scanner.BaseURL, cfg.Scanner.DashboardKey),
			settings.New(db, resolver),
			dashboard.New(resolver, activity),
			filters.New(resolver),
			identities.New(resolver, activity),
			identityevents.New(resolver, activity),
			credentials.New(resolver, activity),
			permissionsource.New(resolver),
			posture.New(resolver, events, workerCfg),
		},
		// No login (JWT): the caller sends tenant_id + the worker's API key, the
		// ispm-worker validates the key and answers with the job id.
		PublicModules: []routes.Module{scan.NewPublicModule(workerCfg)},
	})

	server := &http.Server{
		Addr:         fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port),
		Handler:      middleware.SetupCORS(cfg.CORS)(router),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}
	// Drain in-flight requests on SIGINT/SIGTERM so deferred cleanup (pool
	// close) runs instead of the process being killed mid-request.
	sigCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	serveErr := make(chan error, 1)
	go func() { serveErr <- server.ListenAndServe() }()
	log.Printf("NHI API server listening on %s", server.Addr)

	select {
	case err := <-serveErr:
		if err != nil && err != http.ErrServerClosed {
			// Keep the original non-zero exit; close pools first since Fatalf skips defers.
			_ = db.Close()
			log.Fatalf("API server: %v", err)
		}
	case <-sigCtx.Done():
		log.Printf("shutdown signal received, draining requests")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		if err := server.Shutdown(shutdownCtx); err != nil {
			log.Printf("graceful shutdown: %v", err)
		}
	}
}
