package scan

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"nhi-backend-api/internal/modules/posture/common"
	"nhi-backend-api/internal/platform/scope"
)

type Service struct {
	common.Base
	client *Client
	// check validates the caller's tenant scope before anything leaves the
	// backend. It is a field so tests can run without a database.
	check func(ctx context.Context, c common.Caller) error
}

func NewService(client *Client, resolver *scope.Resolver) *Service {
	s := &Service{Base: common.NewBase(resolver), client: client}
	s.check = func(ctx context.Context, c common.Caller) error {
		_, err := s.Tenant(ctx, c)
		return err
	}
	return s
}

// Start launches a scan of the caller's own tenant. Only analyst / manager /
// admin may do it. The tenant id and the requester come from the JWT.
func (s *Service) Start(ctx context.Context, c common.Caller) (*StartResult, error) {
	if !c.CanWrite() {
		return nil, common.ErrForbidden
	}
	if !s.client.Enabled() {
		return nil, ErrWorkerNotConfigured
	}
	if err := s.check(ctx, c); err != nil { // fail closed on scope
		return nil, fmt.Errorf("resolve tenant: %w", err)
	}
	return s.client.Start(ctx, c.TenantID, c.UserID)
}

// Job returns the state of one scan job. Any signed-in user of the tenant may
// poll it. A job that belongs to another tenant answers as "not found".
func (s *Service) Job(ctx context.Context, c common.Caller, jobID string) (map[string]any, error) {
	if !s.client.Enabled() {
		return nil, ErrWorkerNotConfigured
	}
	if err := s.check(ctx, c); err != nil {
		return nil, fmt.Errorf("resolve tenant: %w", err)
	}
	job, err := s.client.Job(ctx, jobID)
	if err != nil {
		if errors.Is(err, ErrJobNotFound) {
			return nil, common.ErrNotFound
		}
		return nil, err
	}
	// The worker looks jobs up by id only. The job lists its tenants (or, in a
	// flat answer, one tenant_id). Every tenant it names must be the caller's;
	// never reveal another tenant's job.
	if !jobBelongsTo(job, c.TenantID) {
		return nil, common.ErrNotFound
	}
	return job, nil
}

func jobBelongsTo(job map[string]any, tenantID string) bool {
	same := func(v any) bool {
		id, _ := v.(string)
		return strings.EqualFold(strings.TrimSpace(id), tenantID)
	}
	if v, ok := job["tenant_id"]; ok && !same(v) {
		return false
	}
	if list, ok := job["tenants"].([]any); ok {
		for _, t := range list {
			if m, ok := t.(map[string]any); ok {
				if v, ok := m["tenant_id"]; ok && !same(v) {
					return false
				}
			}
		}
	}
	return true
}
