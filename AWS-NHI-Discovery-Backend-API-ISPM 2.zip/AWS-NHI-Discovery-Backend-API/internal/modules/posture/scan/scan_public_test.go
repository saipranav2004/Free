package scan

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/gorilla/mux"
)

const (
	pubKey    = "e2fa7ae5da5cb6aecae51fc41444c19951e583b9ad55b116b03329ed509db33c"
	pubTenant = "de300000-0000-4000-8000-000000000001"
)

// pubWorker is a stand-in for the ispm-worker: it answers like the real one
// (401 for a key other than pubKey) and records what it received.
type pubWorker struct {
	srv   *httptest.Server
	calls atomic.Int32
	auth  string
	path  string
	body  map[string]string
}

func newPubWorker(t *testing.T, status int, reply string) *pubWorker {
	t.Helper()
	pw := &pubWorker{}
	pw.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		pw.calls.Add(1)
		pw.auth, pw.path = r.Header.Get("Authorization"), r.URL.Path
		raw, _ := io.ReadAll(r.Body)
		pw.body = nil
		_ = json.Unmarshal(raw, &pw.body)
		w.Header().Set("Content-Type", "application/json")
		if pw.auth != "Bearer "+pubKey {
			w.WriteHeader(401)
			_, _ = w.Write([]byte(`{"error":{"code":"unauthorized","message":"missing or wrong bearer token"}}`))
			return
		}
		w.WriteHeader(status)
		_, _ = w.Write([]byte(reply))
	}))
	t.Cleanup(pw.srv.Close)
	return pw
}

func pubHandler(url string) *PublicHandler {
	return NewPublicHandler(NewClient(WorkerConfig{BaseURL: url})) // note: no token configured
}

func pubDo(h http.HandlerFunc, method, target, body string, hdr map[string]string, vars map[string]string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, target, strings.NewReader(body))
	req.RemoteAddr = "203.0.113.7:5555"
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	if vars != nil {
		req = mux.SetURLVars(req, vars)
	}
	rec := httptest.NewRecorder()
	h(rec, req)
	return rec
}

type pubErr struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
		Field   string `json:"field"`
	} `json:"error"`
}

func pubDecode(t *testing.T, rec *httptest.ResponseRecorder) pubErr {
	t.Helper()
	var e pubErr
	if err := json.Unmarshal(rec.Body.Bytes(), &e); err != nil {
		t.Fatalf("not an error body: %q", rec.Body.String())
	}
	return e
}

const startReply = `{"data":{"job_id":"1e86dec7-aaaa-4bbb-8ccc-123456789012","status":"QUEUED"},"status_url":"x"}`

func TestPublicStartKeyInHeader(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans", `{"tenant_id":"`+strings.ToUpper(pubTenant)+`"}`,
		map[string]string{"X-API-Key": pubKey}, nil)
	if rec.Code != 202 || !strings.Contains(rec.Body.String(), `"job_id":"1e86dec7-aaaa-4bbb-8ccc-123456789012"`) {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if pw.auth != "Bearer "+pubKey || pw.path != "/api/v1/scans" || pw.body["tenant_id"] != pubTenant {
		t.Fatalf("worker got auth=%q path=%q body=%v", pw.auth, pw.path, pw.body)
	}
	if strings.Contains(rec.Body.String(), pubKey) {
		t.Error("the key must never be echoed")
	}
}

func TestPublicStartKeyInBodyAndBearer(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	h := pubHandler(pw.srv.URL)
	if rec := pubDo(h.Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`","api_key":"`+pubKey+`"}`, nil, nil); rec.Code != 202 {
		t.Fatalf("body key: status %d body %s", rec.Code, rec.Body)
	}
	if rec := pubDo(h.Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, map[string]string{"Authorization": "Bearer " + pubKey}, nil); rec.Code != 202 {
		t.Fatalf("bearer key: status %d body %s", rec.Code, rec.Body)
	}
}

func TestPublicStartAlreadyRunningIs200(t *testing.T) {
	pw := newPubWorker(t, 200, `{"data":{"job_id":"j-run","status":"RUNNING"},"already_running":true}`)
	rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, map[string]string{"X-API-Key": pubKey}, nil)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"already_running":true`) {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestPublicStartKeyInURLIsRefused(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans?api-key="+pubKey, `{"tenant_id":"`+pubTenant+`"}`, nil, nil)
	e := pubDecode(t, rec)
	if rec.Code != 400 || e.Error.Code != "invalid_parameter" || !strings.Contains(e.Error.Message, "X-API-Key") {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if pw.calls.Load() != 0 {
		t.Error("the worker must not be called")
	}
}

func TestPublicStartWithoutKeyIs401(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, nil, nil)
	if rec.Code != 401 || pubDecode(t, rec).Error.Code != "unauthorized" || pw.calls.Load() != 0 {
		t.Fatalf("status %d body %s calls %d", rec.Code, rec.Body, pw.calls.Load())
	}
}

func TestPublicStartWrongKeyIsRejectedByWorker(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, map[string]string{"X-API-Key": "wrong-key"}, nil)
	if rec.Code != 401 || pubDecode(t, rec).Error.Code != "unauthorized" {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if pw.calls.Load() != 1 {
		t.Error("the worker is the one that validates the key")
	}
	if strings.Contains(rec.Body.String(), "bearer token") {
		t.Error("upstream text must not be echoed")
	}
}

func TestPublicStartBadInput(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	h := pubHandler(pw.srv.URL)
	key := map[string]string{"X-API-Key": pubKey}
	cases := []struct{ name, body, field string }{
		{"no tenant", `{}`, "tenant_id"},
		{"empty body", ``, "tenant_id"},
		{"not a uuid", `{"tenant_id":"abc"}`, "tenant_id"},
		{"scope is not accepted", `{"tenant_id":"` + pubTenant + `","scope":"all"}`, "body"},
		{"not json", `tenant_id=abc`, "body"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			rec := pubDo(h.Start, "POST", "/api/v1/scans", c.body, key, nil)
			e := pubDecode(t, rec)
			if rec.Code != 400 || e.Error.Field != c.field {
				t.Fatalf("status %d body %s", rec.Code, rec.Body)
			}
		})
	}
	if pw.calls.Load() != 0 {
		t.Error("bad input must not reach the worker")
	}
}

func TestPublicStartUnusableKeyIs401(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`","api_key":"has space"}`, nil, nil)
	if rec.Code != 401 || pw.calls.Load() != 0 {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestPublicStartWorkerErrors(t *testing.T) {
	cases := []struct {
		name     string
		status   int
		reply    string
		wantCode int
		wantErr  string
	}{
		{"tenant unknown", 404, `{"error":{"code":"not_found","message":"tenant x is not in the tenants table"}}`, 404, "not_found"},
		{"worker down", 500, `boom`, 502, "scan_unavailable"},
		{"wrong url", 404, `404 page not found`, 502, "scan_unavailable"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			pw := newPubWorker(t, c.status, c.reply)
			rec := pubDo(pubHandler(pw.srv.URL).Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, map[string]string{"X-API-Key": pubKey}, nil)
			if rec.Code != c.wantCode || pubDecode(t, rec).Error.Code != c.wantErr {
				t.Fatalf("status %d body %s", rec.Code, rec.Body)
			}
			if strings.Contains(rec.Body.String(), "boom") || strings.Contains(rec.Body.String(), "tenants table") {
				t.Error("upstream text must not be echoed")
			}
		})
	}
}

func TestPublicNotConfiguredIs503(t *testing.T) {
	h := NewPublicHandler(NewClient(WorkerConfig{}))
	rec := pubDo(h.Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, map[string]string{"X-API-Key": pubKey}, nil)
	if rec.Code != 503 || pubDecode(t, rec).Error.Code != "scan_unavailable" {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestPublicJob(t *testing.T) {
	pw := newPubWorker(t, 200, `{"data":{"job_id":"j1","status":"COMPLETED","tenants":[{"tenant_id":"`+pubTenant+`","status":"COMPLETED"}]}}`)
	h := pubHandler(pw.srv.URL)
	rec := pubDo(h.Job, "GET", "/api/v1/scans/j1", "", map[string]string{"X-API-Key": pubKey}, map[string]string{"job_id": "j1"})
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"status":"COMPLETED"`) {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if pw.path != "/api/v1/scans/j1" || pw.auth != "Bearer "+pubKey {
		t.Fatalf("worker got %q %q", pw.path, pw.auth)
	}
	if rec := pubDo(h.Job, "GET", "/api/v1/scans/j1", "", nil, map[string]string{"job_id": "j1"}); rec.Code != 401 {
		t.Fatalf("no key: status %d", rec.Code)
	}
	if rec := pubDo(h.Job, "GET", "/api/v1/scans/j1?api_key="+pubKey, "", nil, map[string]string{"job_id": "j1"}); rec.Code != 400 {
		t.Fatalf("key in URL: status %d", rec.Code)
	}
	if rec := pubDo(h.Job, "GET", "/api/v1/scans/..%2Fx", "", map[string]string{"X-API-Key": pubKey}, map[string]string{"job_id": "../x"}); rec.Code != 400 {
		t.Fatalf("unsafe id: status %d", rec.Code)
	}
}

func TestPublicJobUnknownIs404(t *testing.T) {
	pw := newPubWorker(t, 404, `{"error":{"code":"not_found","message":"unknown job"}}`)
	rec := pubDo(pubHandler(pw.srv.URL).Job, "GET", "/api/v1/scans/zz", "", map[string]string{"X-API-Key": pubKey}, map[string]string{"job_id": "zz"})
	if rec.Code != 404 {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestPublicRateLimit(t *testing.T) {
	pw := newPubWorker(t, 202, startReply)
	h := pubHandler(pw.srv.URL)
	var last *httptest.ResponseRecorder
	for i := 0; i < publicRatePerMin+1; i++ {
		last = pubDo(h.Start, "POST", "/api/v1/scans", `{"tenant_id":"`+pubTenant+`"}`, map[string]string{"X-API-Key": "bad"}, nil)
	}
	if last.Code != 429 || last.Header().Get("Retry-After") == "" {
		t.Fatalf("status %d", last.Code)
	}
}
