package scan

import (
	"encoding/json"
	"errors"
	"io"
	"log"
	"net/http"
	"strings"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/posture/common"
)

type Handler struct {
	service *Service
}

func NewHandler(service *Service) *Handler { return &Handler{service: service} }

// Error codes of this API (same body as the rest of the posture API).
const (
	codeScanUnavailable = "scan_unavailable"
	codeNotFound        = "not_found"
)

// Start handles POST /ispm/scans — the "Sync" button. The request takes no
// fields: the tenant and the requester come from the JWT, so a user cannot
// scan another company's tenant by editing the request.
//
//	202 {"data":{"job_id":"…","already_running":false}}  a scan was started
//	200 {"data":{"job_id":"…","already_running":true}}   one is already running
func (h *Handler) Start(w http.ResponseWriter, r *http.Request) {
	c, ok := common.Begin(w, r)
	if !ok {
		return
	}
	if !c.CanWrite() { // checked before reading anything else
		common.Fail(w, "start scan", common.ErrForbidden)
		return
	}
	if !rejectKeyParams(w, r) || !common.StrictQuery(w, r.URL.Query(), common.Allow()) {
		return
	}
	// No body, or an empty object. Anything else (for example a tenant_id) is refused.
	dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<10))
	dec.DisallowUnknownFields()
	var none struct{}
	if err := dec.Decode(&none); err != nil && !errors.Is(err, io.EOF) {
		common.Invalid(w, "body", "this request takes no fields: the tenant is taken from your login")
		return
	}

	res, err := h.service.Start(r.Context(), c)
	if err != nil {
		h.fail(w, "start scan", err)
		return
	}
	status := http.StatusAccepted
	if res.AlreadyRunning {
		status = http.StatusOK
	}
	w.Header().Set("Cache-Control", "no-store")
	common.WriteJSON(w, status, Response{Data: res})
}

// Job handles GET /ispm/scans/{job_id} — polled every few seconds until the
// job's status is COMPLETED (or failed).
func (h *Handler) Job(w http.ResponseWriter, r *http.Request) {
	c, ok := common.Begin(w, r)
	if !ok {
		return
	}
	jobID := strings.TrimSpace(mux.Vars(r)["job_id"])
	if !common.TokenRegex.MatchString(jobID) {
		common.Invalid(w, "job_id", "job_id is not valid")
		return
	}
	if !rejectKeyParams(w, r) || !common.StrictQuery(w, r.URL.Query(), common.Allow()) {
		return
	}
	job, err := h.service.Job(r.Context(), c, jobID)
	if err != nil {
		h.fail(w, "load scan job", err)
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	common.WriteJSON(w, http.StatusOK, Response{Data: job})
}

// rejectKeyParams answers a request that carries an API key. The worker's key
// (WORKER_SCAN_TOKEN) lives only in this backend's environment; callers send
// just their login token, as "Authorization: Bearer <JWT>".
func rejectKeyParams(w http.ResponseWriter, r *http.Request) bool {
	for k := range r.URL.Query() {
		if isKeyParam(k) {
			common.Invalid(w, k, "do not send an API key: the worker key is configured on the backend (WORKER_SCAN_TOKEN). Send only your login token as \"Authorization: Bearer <JWT>\", with no query parameters")
			return false
		}
	}
	return true
}

// isKeyParam reports whether a query parameter name looks like an API key
// (api-key, api_key, apikey, key, token, ...).
func isKeyParam(name string) bool {
	switch strings.ToLower(strings.NewReplacer("-", "", "_", "").Replace(name)) {
	case "apikey", "key", "token", "accesstoken", "scantoken", "workertoken":
		return true
	}
	return false
}

// fail turns worker errors into the documented error body; everything else
// goes through the shared mapping. Upstream text is logged, never returned.
func (h *Handler) fail(w http.ResponseWriter, what string, err error) {
	switch {
	case errors.Is(err, ErrWorkerNotConfigured):
		common.WriteJSON(w, http.StatusServiceUnavailable, common.ErrorEnvelope{Error: common.ErrorBody{
			Code: codeScanUnavailable, Message: "scanning is not configured on this server"}})
	case errors.Is(err, ErrTenantUnknown):
		log.Printf("scan api: %s: %v", what, err)
		common.WriteJSON(w, http.StatusNotFound, common.ErrorEnvelope{Error: common.ErrorBody{
			Code: codeNotFound, Message: "this tenant is not registered for scanning"}})
	case errors.Is(err, ErrWorkerAuth), errors.Is(err, ErrWorkerRejected), errors.Is(err, ErrWorkerUnavailable):
		log.Printf("scan api: %s failed: %v", what, err)
		common.WriteJSON(w, http.StatusBadGateway, common.ErrorEnvelope{Error: common.ErrorBody{
			Code: codeScanUnavailable, Message: "the scan service could not be reached; try again shortly"}})
	default:
		common.Fail(w, what, err)
	}
}
