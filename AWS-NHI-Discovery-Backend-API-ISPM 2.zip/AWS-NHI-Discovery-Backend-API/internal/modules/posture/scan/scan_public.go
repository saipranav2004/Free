package scan

import (
	"encoding/json"
	"errors"
	"io"
	"log"
	"net"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/posture/common"
)

// Public scan API: no login (JWT). The caller proves itself with the worker's
// API key, and the ispm-worker is the one that validates it.
//
//	POST /api/v1/scans            {"tenant_id":"<uuid>","api_key":"<key>"}
//	GET  /api/v1/scans/{job_id}   (key in the header)
//
// The key is read from the "X-API-Key" header, or "Authorization: Bearer <key>",
// or the "api_key" field of the JSON body. It is never accepted in the URL:
// URLs end up in logs, browser history and proxies.
//
// The backend does not know or store the key. It forwards the caller's key to
// the worker and relays the answer: 202/200 with the job id, or 401 when the
// worker rejects the key.

const (
	codeUnauthorized = "unauthorized"
	codeRateLimited  = "rate_limited"

	maxKeyLen         = 256
	maxRequestedBy    = 100
	publicRatePerMin  = 30 // requests per client address per minute
	publicBodyMaxSize = 4 << 10
)

var uuidRE = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

// PublicHandler serves the no-login scan endpoints.
type PublicHandler struct {
	client  *Client
	limiter *addrLimiter
}

func NewPublicHandler(client *Client) *PublicHandler {
	return &PublicHandler{client: client, limiter: newAddrLimiter(publicRatePerMin, time.Minute)}
}

// PublicModule mounts the public scan routes. Register it on a router that has
// NO authentication middleware.
type PublicModule struct{ h *PublicHandler }

func NewPublicModule(cfg WorkerConfig) *PublicModule {
	return &PublicModule{h: NewPublicHandler(NewClient(cfg))}
}

func (m *PublicModule) Register(r *mux.Router) {
	r.HandleFunc("/scans", m.h.Start).Methods(http.MethodPost)
	r.HandleFunc("/scans/{job_id}", m.h.Job).Methods(http.MethodGet)
}

type publicStartRequest struct {
	TenantID    string `json:"tenant_id"`
	APIKey      string `json:"api_key"`
	RequestedBy string `json:"requested_by"` // optional label shown in the worker's job
}

// Start handles POST /api/v1/scans.
//
//	202 {"data":{"job_id":"…","already_running":false}}  a scan was started
//	200 {"data":{"job_id":"…","already_running":true}}   one is already running
func (h *PublicHandler) Start(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	if !h.client.Configured() {
		h.fail(w, "start scan", ErrWorkerNotConfigured)
		return
	}
	if !h.allow(w, r) || !noQuery(w, r) {
		return
	}

	var req publicStartRequest
	dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, publicBodyMaxSize))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&req); err != nil && !errors.Is(err, io.EOF) {
		common.Invalid(w, "body", `body must be JSON: {"tenant_id":"<uuid>","api_key":"<key>"}`)
		return
	}

	key, ok := apiKey(r, req.APIKey)
	if !ok {
		unauthorized(w)
		return
	}
	tenantID := strings.ToLower(strings.TrimSpace(req.TenantID))
	if tenantID == "" {
		common.Invalid(w, "tenant_id", "tenant_id is required")
		return
	}
	if !uuidRE.MatchString(tenantID) {
		common.Invalid(w, "tenant_id", "tenant_id must be a UUID")
		return
	}

	res, err := h.client.StartAs(r.Context(), key, tenantID, label(req.RequestedBy))
	if err != nil {
		h.fail(w, "start scan", err)
		return
	}
	status := http.StatusAccepted
	if res.AlreadyRunning {
		status = http.StatusOK
	}
	common.WriteJSON(w, status, Response{Data: res})
}

// Job handles GET /api/v1/scans/{job_id}: poll until status is COMPLETED.
func (h *PublicHandler) Job(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	if !h.client.Configured() {
		h.fail(w, "load scan job", ErrWorkerNotConfigured)
		return
	}
	if !h.allow(w, r) || !noQuery(w, r) {
		return
	}
	key, ok := apiKey(r, "")
	if !ok {
		unauthorized(w)
		return
	}
	jobID := strings.TrimSpace(mux.Vars(r)["job_id"])
	if !common.TokenRegex.MatchString(jobID) {
		common.Invalid(w, "job_id", "job_id is not valid")
		return
	}
	job, err := h.client.JobAs(r.Context(), key, jobID)
	if err != nil {
		h.fail(w, "load scan job", err)
		return
	}
	common.WriteJSON(w, http.StatusOK, Response{Data: job})
}

// fail maps worker errors to the documented error body. Upstream text is
// logged, never returned.
func (h *PublicHandler) fail(w http.ResponseWriter, what string, err error) {
	switch {
	case errors.Is(err, ErrWorkerNotConfigured):
		writeErr(w, http.StatusServiceUnavailable, codeScanUnavailable, "scanning is not configured on this server")
	case errors.Is(err, ErrWorkerAuth):
		unauthorized(w) // the worker did not accept the key
	case errors.Is(err, ErrTenantUnknown), errors.Is(err, ErrJobNotFound):
		log.Printf("scan api (public): %s: %v", what, err)
		writeErr(w, http.StatusNotFound, codeNotFound, "tenant or job not found")
	case errors.Is(err, ErrWorkerRejected):
		log.Printf("scan api (public): %s: %v", what, err)
		writeErr(w, http.StatusBadRequest, "invalid_parameter", "the scan service rejected the request")
	default:
		log.Printf("scan api (public): %s failed: %v", what, err)
		writeErr(w, http.StatusBadGateway, codeScanUnavailable, "the scan service could not be reached; try again shortly")
	}
}

func writeErr(w http.ResponseWriter, status int, code, msg string) {
	common.WriteJSON(w, status, common.ErrorEnvelope{Error: common.ErrorBody{Code: code, Message: msg}})
}

func unauthorized(w http.ResponseWriter) {
	w.Header().Set("WWW-Authenticate", `Bearer realm="ispm-scan"`)
	writeErr(w, http.StatusUnauthorized, codeUnauthorized, "missing or invalid API key: send it in the X-API-Key header (or as api_key in the JSON body)")
}

// apiKey finds the caller's key: X-API-Key, then "Authorization: Bearer", then
// the body field. It must be printable ASCII of sane length (it becomes a
// header value for the worker).
func apiKey(r *http.Request, fromBody string) (string, bool) {
	key := strings.TrimSpace(r.Header.Get("X-API-Key"))
	if key == "" {
		if scheme, rest, ok := strings.Cut(strings.TrimSpace(r.Header.Get("Authorization")), " "); ok && strings.EqualFold(scheme, "Bearer") {
			key = strings.TrimSpace(rest)
		}
	}
	if key == "" {
		key = strings.TrimSpace(fromBody)
	}
	if key == "" || len(key) > maxKeyLen {
		return "", false
	}
	for i := 0; i < len(key); i++ {
		if key[i] < 0x21 || key[i] > 0x7e {
			return "", false
		}
	}
	return key, true
}

// noQuery refuses any query string. A key in the URL is the usual mistake, so
// that case gets its own message.
func noQuery(w http.ResponseWriter, r *http.Request) bool {
	for k := range r.URL.Query() {
		msg := "this endpoint takes no query parameters"
		if isKeyParam(k) {
			msg = "never put the API key in the URL: send it in the X-API-Key header (or as api_key in the JSON body)"
		}
		common.Invalid(w, k, msg)
		return false
	}
	return true
}

// label cleans the optional requested_by text: trimmed, printable, short.
func label(s string) string {
	s = strings.Map(func(r rune) rune {
		if r < 0x20 || r == 0x7f {
			return -1
		}
		return r
	}, strings.TrimSpace(s))
	if len(s) > maxRequestedBy {
		s = s[:maxRequestedBy]
	}
	if s == "" {
		return "api-key"
	}
	return s
}

func (h *PublicHandler) allow(w http.ResponseWriter, r *http.Request) bool {
	ok, wait := h.limiter.allow(clientAddr(r), time.Now())
	if ok {
		return true
	}
	secs := int(wait.Seconds()) + 1
	w.Header().Set("Retry-After", strconv.Itoa(secs))
	writeErr(w, http.StatusTooManyRequests, codeRateLimited, "too many requests; slow down")
	return false
}

// clientAddr is the TCP peer address. X-Forwarded-For is deliberately not
// trusted: anyone could forge it to dodge the limit.
func clientAddr(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// addrLimiter is a small per-address token bucket (keeps the key from being
// guessed or the worker flooded through this open endpoint).
type addrLimiter struct {
	mu      sync.Mutex
	perMin  float64
	burst   float64
	buckets map[string]*bucket
	lastGC  time.Time
}

type bucket struct {
	tokens float64
	at     time.Time
}

func newAddrLimiter(perPeriod int, period time.Duration) *addrLimiter {
	return &addrLimiter{perMin: float64(perPeriod) / period.Minutes(), burst: float64(perPeriod), buckets: map[string]*bucket{}}
}

func (l *addrLimiter) allow(addr string, now time.Time) (bool, time.Duration) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if now.Sub(l.lastGC) > 10*time.Minute { // drop idle addresses
		for k, b := range l.buckets {
			if now.Sub(b.at) > 10*time.Minute {
				delete(l.buckets, k)
			}
		}
		l.lastGC = now
	}
	b := l.buckets[addr]
	if b == nil {
		b = &bucket{tokens: l.burst, at: now}
		l.buckets[addr] = b
	}
	b.tokens += now.Sub(b.at).Minutes() * l.perMin
	if b.tokens > l.burst {
		b.tokens = l.burst
	}
	b.at = now
	if b.tokens >= 1 {
		b.tokens--
		return true, 0
	}
	need := (1 - b.tokens) / l.perMin // minutes
	return false, time.Duration(need * float64(time.Minute))
}
