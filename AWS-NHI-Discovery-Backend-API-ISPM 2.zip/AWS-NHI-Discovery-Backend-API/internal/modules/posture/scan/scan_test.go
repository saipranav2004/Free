package scan

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/posture/common"
	"nhi-backend-api/internal/platform/jwt"
	"nhi-backend-api/internal/platform/middleware"
)

const (
	testToken  = "9f2c4e-secret-token-a71b"
	testTenant = "de300000-0000-4000-8000-000000000001"
	testUser   = "user@acme.com"
)

// fakeWorker is a stand-in for the ispm-worker. It records the last request.
type fakeWorker struct {
	srv     *httptest.Server
	calls   atomic.Int32
	method  string
	path    string
	auth    string
	body    map[string]string
	status  int
	reply   string
	handler http.HandlerFunc
}

func newFakeWorker(t *testing.T, status int, reply string) *fakeWorker {
	t.Helper()
	fw := &fakeWorker{status: status, reply: reply}
	fw.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fw.calls.Add(1)
		fw.method, fw.path, fw.auth = r.Method, r.URL.EscapedPath(), r.Header.Get("Authorization")
		raw, _ := io.ReadAll(r.Body)
		fw.body = nil
		_ = json.Unmarshal(raw, &fw.body)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(fw.status)
		_, _ = w.Write([]byte(fw.reply))
	}))
	t.Cleanup(fw.srv.Close)
	return fw
}

func handlerFor(url string) *Handler {
	c := NewClient(WorkerConfig{BaseURL: url, Token: testToken})
	svc := &Service{client: c, check: func(context.Context, common.Caller) error { return nil }}
	return NewHandler(svc)
}

// do runs one request through the handler as a signed-in user with role.
func do(h http.HandlerFunc, method, target, body, role string, vars map[string]string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(method, target, strings.NewReader(body))
	claims := &jwt.CustomClaims{UserID: testUser, Email: testUser, TenantID: testTenant, DBName: "tenant_demo", Role: role}
	req = req.WithContext(context.WithValue(req.Context(), middleware.UserClaimsKey, claims))
	if vars != nil {
		req = mux.SetURLVars(req, vars)
	}
	rec := httptest.NewRecorder()
	h(rec, req)
	return rec
}

type errBody struct {
	Error struct {
		Code    string `json:"code"`
		Message string `json:"message"`
		Field   string `json:"field"`
	} `json:"error"`
}

func decodeErr(t *testing.T, rec *httptest.ResponseRecorder) errBody {
	t.Helper()
	var e errBody
	if err := json.Unmarshal(rec.Body.Bytes(), &e); err != nil {
		t.Fatalf("not an error body: %q", rec.Body.String())
	}
	return e
}

func TestStartSendsTenantAndTokenToWorker(t *testing.T) {
	fw := newFakeWorker(t, 202, `{"job_id":"job-123"}`)
	rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "", "admin", nil)

	if rec.Code != 202 {
		t.Fatalf("status = %d, body %s", rec.Code, rec.Body)
	}
	if fw.method != "POST" || fw.path != "/api/v1/scans" {
		t.Errorf("worker got %s %s", fw.method, fw.path)
	}
	if fw.auth != "Bearer "+testToken {
		t.Errorf("worker Authorization = %q", fw.auth)
	}
	if fw.body["tenant_id"] != testTenant || fw.body["requested_by"] != testUser {
		t.Errorf("worker body = %v (tenant must come from the JWT)", fw.body)
	}
	var out struct {
		Data StartResult `json:"data"`
	}
	_ = json.Unmarshal(rec.Body.Bytes(), &out)
	if out.Data.JobID != "job-123" || out.Data.AlreadyRunning {
		t.Errorf("data = %+v", out.Data)
	}
	if strings.Contains(rec.Body.String(), testToken) {
		t.Error("the worker token must never appear in a response")
	}
}

func TestStartAlreadyRunningIs200(t *testing.T) {
	fw := newFakeWorker(t, 200, `{"job_id":"job-9","already_running":true}`)
	rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "{}", "analyst", nil)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"job_id":"job-9"`) || !strings.Contains(rec.Body.String(), `"already_running":true`) {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestStartRefusesTenantFromRequest(t *testing.T) {
	fw := newFakeWorker(t, 202, `{"job_id":"x"}`)
	rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", `{"tenant_id":"`+testTenant+`"}`, "admin", nil)
	if rec.Code != 400 || decodeErr(t, rec).Error.Code != "invalid_parameter" {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if fw.calls.Load() != 0 {
		t.Error("the worker must not be called")
	}
}

func TestStartNeedsWriteRole(t *testing.T) {
	fw := newFakeWorker(t, 202, `{"job_id":"x"}`)
	rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "", "viewer", nil)
	if rec.Code != 403 || decodeErr(t, rec).Error.Code != "forbidden" {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if fw.calls.Load() != 0 {
		t.Error("the worker must not be called")
	}
}

func TestStartRejectsQueryParameters(t *testing.T) {
	fw := newFakeWorker(t, 202, `{"job_id":"x"}`)
	rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans?tenant_id=abc", "", "admin", nil)
	if rec.Code != 400 {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestStartWorkerErrorsAreMapped(t *testing.T) {
	cases := []struct {
		name     string
		status   int
		reply    string
		wantCode int
		wantErr  string
	}{
		{"wrong token", 401, `{"error":"bad token 9f2c4e"}`, 502, "scan_unavailable"},
		{"bad request", 400, `{"error":"tenant_id not a uuid"}`, 502, "scan_unavailable"},
		{"worker down", 500, `boom`, 502, "scan_unavailable"},
		{"tenant unknown", 404, `{"error":"no such tenant"}`, 404, "not_found"},
		{"no job id", 202, `{}`, 502, "scan_unavailable"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			fw := newFakeWorker(t, c.status, c.reply)
			rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "", "admin", nil)
			if rec.Code != c.wantCode || decodeErr(t, rec).Error.Code != c.wantErr {
				t.Fatalf("status %d body %s", rec.Code, rec.Body)
			}
			if strings.Contains(rec.Body.String(), "9f2c4e") || strings.Contains(rec.Body.String(), "boom") {
				t.Error("upstream text must not be echoed to the browser")
			}
		})
	}
}

func TestStartWorkerUnreachable(t *testing.T) {
	fw := newFakeWorker(t, 202, `{}`)
	url := fw.srv.URL
	fw.srv.Close()
	rec := do(handlerFor(url).Start, "POST", "/ispm/scans", "", "admin", nil)
	if rec.Code != 502 || decodeErr(t, rec).Error.Code != "scan_unavailable" {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestNotConfiguredAnswers503(t *testing.T) {
	h := NewHandler(&Service{client: NewClient(WorkerConfig{}), check: func(context.Context, common.Caller) error { return nil }})
	rec := do(h.Start, "POST", "/ispm/scans", "", "admin", nil)
	if rec.Code != 503 || decodeErr(t, rec).Error.Code != "scan_unavailable" {
		t.Fatalf("start: status %d body %s", rec.Code, rec.Body)
	}
	rec = do(h.Job, "GET", "/ispm/scans/job-1", "", "admin", map[string]string{"job_id": "job-1"})
	if rec.Code != 503 {
		t.Fatalf("job: status %d body %s", rec.Code, rec.Body)
	}
}

func TestJobRelaysWorkerStatus(t *testing.T) {
	fw := newFakeWorker(t, 200, `{"job_id":"job-123","status":"RUNNING","tenant_id":"`+testTenant+`"}`)
	rec := do(handlerFor(fw.srv.URL).Job, "GET", "/ispm/scans/job-123", "", "viewer", map[string]string{"job_id": "job-123"})
	if rec.Code != 200 {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if fw.method != "GET" || fw.path != "/api/v1/scans/job-123" || fw.auth != "Bearer "+testToken {
		t.Errorf("worker got %s %s auth=%q", fw.method, fw.path, fw.auth)
	}
	var out struct {
		Data map[string]any `json:"data"`
	}
	_ = json.Unmarshal(rec.Body.Bytes(), &out)
	if out.Data["status"] != "RUNNING" || out.Data["job_id"] != "job-123" {
		t.Errorf("data = %v", out.Data)
	}
}

func TestJobOfAnotherTenantIsNotFound(t *testing.T) {
	fw := newFakeWorker(t, 200, `{"job_id":"job-5","status":"COMPLETED","tenant_id":"aaaaaaaa-0000-4000-8000-000000000009"}`)
	rec := do(handlerFor(fw.srv.URL).Job, "GET", "/ispm/scans/job-5", "", "admin", map[string]string{"job_id": "job-5"})
	if rec.Code != 404 || decodeErr(t, rec).Error.Code != "not_found" {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
	if strings.Contains(rec.Body.String(), "COMPLETED") {
		t.Error("another tenant's job must not leak")
	}
}

func TestJobUnknownIs404(t *testing.T) {
	fw := newFakeWorker(t, 404, `{"error":"no such job"}`)
	rec := do(handlerFor(fw.srv.URL).Job, "GET", "/ispm/scans/nope", "", "admin", map[string]string{"job_id": "nope"})
	if rec.Code != 404 {
		t.Fatalf("status %d body %s", rec.Code, rec.Body)
	}
}

func TestJobRejectsUnsafeIDs(t *testing.T) {
	fw := newFakeWorker(t, 200, `{}`)
	for _, id := range []string{"../admin", "a/b", "a b", "", "x?y=1", strings.Repeat("a", 65)} {
		rec := do(handlerFor(fw.srv.URL).Job, "GET", "/ispm/scans/x", "", "admin", map[string]string{"job_id": id})
		if rec.Code != 400 || decodeErr(t, rec).Error.Field != "job_id" {
			t.Errorf("id %q: status %d body %s", id, rec.Code, rec.Body)
		}
	}
	if fw.calls.Load() != 0 {
		t.Error("the worker must not be called for an invalid job id")
	}
}

// The real worker wraps its answer: {"data":{"job_id":...,"tenants":[...]},"already_running":bool}.
func TestStartReadsWorkersWrappedAnswer(t *testing.T) {
	fw := newFakeWorker(t, 202, `{"data":{"job_id":"j-77","status":"RUNNING","tenants":[{"tenant_id":"`+testTenant+`"}]},"status_url":"/api/v1/scans/j-77"}`)
	rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "", "admin", nil)
	if rec.Code != 202 || !strings.Contains(rec.Body.String(), `"job_id":"j-77"`) {
		t.Fatalf("got %d %s", rec.Code, rec.Body.String())
	}
	fw = newFakeWorker(t, 200, `{"data":{"job_id":"j-78"},"already_running":true}`)
	rec = do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "", "admin", nil)
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"already_running":true`) {
		t.Fatalf("got %d %s", rec.Code, rec.Body.String())
	}
}

func TestJobWrappedAnswerChecksTenants(t *testing.T) {
	fw := newFakeWorker(t, 200, `{"data":{"job_id":"j-1","status":"COMPLETED","tenants":[{"tenant_id":"`+testTenant+`","status":"COMPLETED"}]}}`)
	rec := do(handlerFor(fw.srv.URL).Job, "GET", "/ispm/scans/j-1", "", "viewer", map[string]string{"job_id": "j-1"})
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), `"status":"COMPLETED"`) {
		t.Fatalf("got %d %s", rec.Code, rec.Body.String())
	}
	fw = newFakeWorker(t, 200, `{"data":{"job_id":"j-2","tenants":[{"tenant_id":"aaaaaaaa-0000-4000-8000-000000000009"}]}}`)
	rec = do(handlerFor(fw.srv.URL).Job, "GET", "/ispm/scans/j-2", "", "viewer", map[string]string{"job_id": "j-2"})
	if rec.Code != 404 {
		t.Fatalf("other tenant's job: got %d %s", rec.Code, rec.Body.String())
	}
}

// The caller must never send the worker's API key: the backend adds it.
func TestStartRejectsAPIKeyFromCaller(t *testing.T) {
	for _, q := range []string{"api-key=abc", "api_key=abc", "apikey=abc", "token=abc"} {
		fw := newFakeWorker(t, 202, `{"data":{"job_id":"x"}}`)
		rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans?"+q, "", "admin", nil)
		e := decodeErr(t, rec)
		if rec.Code != 400 || e.Error.Code != "invalid_parameter" || !strings.Contains(e.Error.Message, "WORKER_SCAN_TOKEN") {
			t.Fatalf("%s: status %d body %s", q, rec.Code, rec.Body)
		}
		if fw.calls.Load() != 0 {
			t.Fatalf("%s: the worker must not be called", q)
		}
	}
}

// A 404 that is not the worker's own answer (wrong WORKER_URL, e.g. this
// backend itself) is "scan service unreachable", not "unknown tenant".
func TestStartForeign404IsNotTenantUnknown(t *testing.T) {
	for _, reply := range []string{`404 page not found`, `{"success":false,"message":"route not found: POST /api/v1/scans"}`} {
		fw := newFakeWorker(t, 404, reply)
		rec := do(handlerFor(fw.srv.URL).Start, "POST", "/ispm/scans", "", "admin", nil)
		if rec.Code != 502 || decodeErr(t, rec).Error.Code != "scan_unavailable" {
			t.Fatalf("reply %q: status %d body %s", reply, rec.Code, rec.Body)
		}
	}
}

func TestClientSendsLowerCaseTenant(t *testing.T) {
	fw := newFakeWorker(t, 202, `{"data":{"job_id":"j1"}}`)
	c := NewClient(WorkerConfig{BaseURL: fw.srv.URL, Token: testToken})
	if _, err := c.Start(context.Background(), " DE300000-0000-4000-8000-000000000001 ", testUser); err != nil {
		t.Fatal(err)
	}
	if fw.body["tenant_id"] != testTenant {
		t.Fatalf("tenant_id sent = %q", fw.body["tenant_id"])
	}
}
