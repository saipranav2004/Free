package identityactivity

import (
 "context"
 "fmt"
 "log"
 "nhi-backend-api/internal/identitygraph"
 "nhi-backend-api/internal/identitygraph/eventstore"
 "nhi-backend-api/internal/modules/posture/common"
 "nhi-backend-api/internal/platform/scope"
 "strings"
 "time"
)

// IdentityActivityRepository reads the identity's CloudTrail calls from the
// events table of the tenant schema, or from the ClickHouse event store when
// that table does not exist. When neither is available the endpoint answers
// "no data" (data_available = false) instead of failing.
type IdentityActivityRepository struct {
 ch     *eventstore.Repository
 lookup *identitygraph.IdentityLookupRepository
}

func NewIdentityActivityRepository(ch *eventstore.Repository, lookup *identitygraph.IdentityLookupRepository) *IdentityActivityRepository {
 return &IdentityActivityRepository{ch: ch, lookup: lookup}
}

type activityCursor struct {
 T  time.Time `json:"t"`
 ID string    `json:"id"`
}

// Get implements GET /identities/{id}/activity. It returns the events, the
// next cursor, and whether the event data could be read.
func (r *IdentityActivityRepository) Get(ctx context.Context, s *scope.DataScope, id string, f IdentityActivityFilter) ([]ActivityEvent, *string, bool, error) {
 if err := common.Need(s); err != nil {
  return nil, nil, false, err
 }
 ref, err := common.LoadIdentityRef(ctx, s, id)
 if err != nil {
  return nil, nil, false, err
 }
 empty := []ActivityEvent{}
 limit := common.ClampLimit(f.Limit)

 // 1) the scanner's events table in the tenant database (preferred)
 tblEvents, tblNext, found, err := r.fromEventsTable(ctx, s, ref, f, limit)
 if err != nil {
  return nil, nil, false, err
 }
 if found {
  return tblEvents, tblNext, true, nil
 }

 // 2) otherwise the ClickHouse event store, when it is configured
 if !r.ch.Enabled() {
  return empty, nil, false, nil
 }

 pf := eventstore.ActivityPageFilter{Mutating: f.Mutating, Limit: limit + 1}
 if strings.TrimSpace(f.Cursor) != "" {
  var c activityCursor
  if err := common.DecodeCursor(f.Cursor, &c); err != nil || c.ID == "" || c.T.IsZero() {
   return nil, nil, false, common.ErrInvalidCursor
  }
  pf.HasCursor, pf.CursorTime, pf.CursorID = true, c.T, c.ID
 }

 keys, err := r.subjectKeys(ctx, s, ref)
 if err != nil {
  return nil, nil, false, err
 }
 accounts, err := r.tenantAccounts(ctx, s)
 if err != nil {
  return nil, nil, false, err
 }
 sc := eventstore.Scope{
  Accounts: accounts,
  Start:    time.Now().UTC().Add(-f.Window.Duration),
  Service:  eventstore.ServiceName(f.Service),
 }
 events, err := r.ch.ActivityPage(ctx, eventstore.NewSubject(keys...), sc, pf)
 if err != nil {
  msg := err.Error()
  if len(msg) > 300 { // ClickHouse errors echo the whole query
   msg = msg[:300] + "..."
  }
  log.Printf("clickhouse identity activity: %s (activity data unavailable)", msg)
  return empty, nil, false, nil
 }

 var next *string
 if len(events) > limit {
  events = events[:limit]
  last := events[limit-1]
  c := common.EncodeCursor(activityCursor{T: last.EventTime.UTC(), ID: last.EventID})
  next = &c
 }
 out := make([]ActivityEvent, 0, len(events))
 for _, e := range events {
  ev := ActivityEvent{
   EventTime: e.EventTime.UTC(), Action: e.EventName, Service: e.EventSource,
   SourceIP: e.SourceIP, Region: e.Region, Mutating: !e.IsReadOnly,
  }
  if e.ErrorCode != "" {
   code := e.ErrorCode
   ev.ErrorCode = &code
  }
  out = append(out, ev)
 }
 return out, next, true, nil
}

// subjectKeys are the CloudTrail identifiers of the identity: its own ARN, the
// credentials it is bound to, and the access-key ids inside those ARNs.
func (r *IdentityActivityRepository) subjectKeys(ctx context.Context, s *scope.DataScope, ref *common.IdentityRef) ([]string, error) {
 keys := []string{ref.ARN}
 if ref.ARN == "" {
  return keys, nil
 }
 q := fmt.Sprintf(`SELECT DISTINCT target_arn FROM %s
  WHERE tenant_id = $1 AND source_arn = $2 AND edge_type = 'BOUND_TO'`, s.Table(common.TAccessEdges))
 rows, err := s.DB.QueryContext(ctx, q, s.TenantID, ref.ARN)
 if err != nil {
  if common.IsUndefinedTable(err) {
   return keys, nil
  }
  return nil, fmt.Errorf("load activity keys: %w", err)
 }
 defer rows.Close()
 for rows.Next() {
  var arn string
  if err := rows.Scan(&arn); err != nil {
   return nil, fmt.Errorf("scan activity key: %w", err)
  }
  keys = append(keys, arn)
  if i := strings.LastIndex(arn, "access-key/"); i >= 0 {
   keys = append(keys, arn[i+len("access-key/"):])
  }
 }
 return keys, rows.Err()
}

// tenantAccounts lists the AWS accounts of the tenant straight from
// dummy_identities (the tenant is the schema). It is the isolation boundary
// for the ClickHouse query.
func (r *IdentityActivityRepository) tenantAccounts(ctx context.Context, s *scope.DataScope) ([]string, error) {
 q := fmt.Sprintf(`SELECT DISTINCT account_id FROM %s
  WHERE account_id IS NOT NULL AND account_id <> '' AND deleted_at IS NULL
  ORDER BY account_id`, s.Table(common.TDummyIdentities))
 rows, err := s.DB.QueryContext(ctx, q)
 if err != nil {
  return nil, fmt.Errorf("load tenant accounts: %w", err)
 }
 defer rows.Close()
 out := make([]string, 0)
 for rows.Next() {
  var id string
  if err := rows.Scan(&id); err != nil {
   return nil, fmt.Errorf("scan tenant account: %w", err)
  }
  out = append(out, id)
 }
 return out, rows.Err()
}

// fromEventsTable reads GET /identities/{id}/activity from the events table of
// the tenant schema: newest first, keyset paged on (event_time, event_id).
// found is false when the table (or one of its columns) does not exist yet, so
// the endpoint can fall back to the event store and finally answer
// data_available = false.
func (r *IdentityActivityRepository) fromEventsTable(ctx context.Context, s *scope.DataScope, ref *common.IdentityRef, f IdentityActivityFilter, limit int) ([]ActivityEvent, *string, bool, error) {
 args := []any{ref.ID, time.Now().UTC().Add(-f.Window.Duration)}
 add := func(v any) string {
  args = append(args, v)
  return fmt.Sprintf("$%d", len(args))
 }
 where := "identity_id = $1 AND event_time >= $2"
 if f.Mutating != nil {
  where += " AND COALESCE(is_read_only, false) = " + add(!*f.Mutating)
 }
 if svc := strings.ToLower(strings.TrimSpace(f.Service)); svc != "" {
  if !strings.Contains(svc, ".") {
   svc += ".amazonaws.com"
  }
  where += " AND event_source = " + add(svc)
 }
 if strings.TrimSpace(f.Cursor) != "" {
  var c activityCursor
  if err := common.DecodeCursor(f.Cursor, &c); err != nil || c.ID == "" || c.T.IsZero() {
   return nil, nil, false, common.ErrInvalidCursor
  }
  t, id := add(c.T.UTC()), add(c.ID)
  where += fmt.Sprintf(" AND (event_time < %s OR (event_time = %s AND event_id::text > %s))", t, t, id)
 }
 q := fmt.Sprintf(`SELECT event_time, COALESCE(event_name, ''), COALESCE(event_source, ''), COALESCE(source_ip::text, ''),
   COALESCE(aws_region, ''), COALESCE(is_read_only, false), COALESCE(error_code, ''), COALESCE(event_id::text, '')
  FROM %s WHERE %s
  ORDER BY event_time DESC, event_id
  LIMIT %d`, s.Table(common.TIdentityEvents), where, limit+1)

 rows, err := s.DB.QueryContext(ctx, q, args...)
 if err != nil {
  if common.IsUndefinedTable(err) || common.IsUndefinedColumn(err) {
   return nil, nil, false, nil
  }
  return nil, nil, false, fmt.Errorf("query identity events: %w", err)
 }
 defer rows.Close()

 type row struct {
  t       time.Time
  name    string
  source  string
  ip      string
  region  string
  readOnl bool
  errCode string
  id      string
 }
 var got []row
 for rows.Next() {
  var x row
  if err := rows.Scan(&x.t, &x.name, &x.source, &x.ip, &x.region, &x.readOnl, &x.errCode, &x.id); err != nil {
   return nil, nil, false, fmt.Errorf("scan identity event: %w", err)
  }
  got = append(got, x)
 }
 if err := rows.Err(); err != nil {
  return nil, nil, false, err
 }

 var next *string
 if len(got) > limit {
  got = got[:limit]
  last := got[limit-1]
  c := common.EncodeCursor(activityCursor{T: last.t.UTC(), ID: last.id})
  next = &c
 }
 out := make([]ActivityEvent, 0, len(got))
 for _, x := range got {
  ev := ActivityEvent{
   EventTime: x.t.UTC(), Action: x.name, Service: x.source,
   SourceIP: x.ip, Region: x.region, Mutating: !x.readOnl,
  }
  if x.errCode != "" {
   code := x.errCode
   ev.ErrorCode = &code
  }
  out = append(out, ev)
 }
 return out, next, true, nil
}