// package config

// import (
// 	"strings"
// 	"testing"
// )

// func validBase() Config {
// 	return Config{
// 		Server:   ServerConfig{Host: "0.0.0.0", Port: 8080},
// 		Database: DatabaseConfig{Host: "h", DatabaseName: "nhi_db", User: "u", Password: "p", Schema: "nhi_global"},
// 		JWT:      JWTConfig{Secret: strings.Repeat("s", 32), AccessTTLMinutes: 60, RefreshTTLHours: 168},
// 	}
// }

// func TestWorkerConfig(t *testing.T) {
// 	cases := []struct {
// 		name    string
// 		w       WorkerConfig
// 		wantErr bool
// 	}{
// 		{"not configured is fine", WorkerConfig{}, false},
// 		{"http url with token", WorkerConfig{BaseURL: "http://ispm-worker:8080", ScanToken: "tok"}, false},
// 		{"https url with token", WorkerConfig{BaseURL: "https://worker.example.com", ScanToken: "tok"}, false},
// 		{"token missing", WorkerConfig{BaseURL: "http://ispm-worker:8080"}, true},
// 		{"no scheme", WorkerConfig{BaseURL: "ispm-worker:8080", ScanToken: "tok"}, true},
// 		{"ftp scheme", WorkerConfig{BaseURL: "ftp://worker", ScanToken: "tok"}, true},
// 		{"credentials in url", WorkerConfig{BaseURL: "http://u:p@worker:8080", ScanToken: "tok"}, true},
// 		{"query in url", WorkerConfig{BaseURL: "http://worker:8080/?a=1", ScanToken: "tok"}, true},
// 	}
// 	for _, c := range cases {
// 		t.Run(c.name, func(t *testing.T) {
// 			cfg := validBase()
// 			cfg.Worker = c.w
// 			cfg.applyDefaults()
// 			err := cfg.validate()
// 			if (err != nil) != c.wantErr {
// 				t.Fatalf("err = %v, wantErr %v", err, c.wantErr)
// 			}
// 			if err == nil && cfg.Worker.Enabled() && cfg.Worker.TimeoutSeconds != 10 {
// 				t.Errorf("timeout default = %d, want 10", cfg.Worker.TimeoutSeconds)
// 			}
// 		})
// 	}
// }

// func TestWorkerEnvironment(t *testing.T) {
// 	t.Setenv("WORKER_URL", " http://localhost:8080/ ")
// 	t.Setenv("WORKER_SCAN_TOKEN", "abc")
// 	var cfg Config
// 	if err := cfg.applyEnvironment(); err != nil {
// 		t.Fatal(err)
// 	}
// 	cfg.applyDefaults()
// 	if cfg.Worker.BaseURL != "http://localhost:8080" || cfg.Worker.ScanToken != "abc" {
// 		t.Fatalf("worker = %+v", cfg.Worker)
// 	}
// }



















package config

import (
	"strings"
	"testing"
)

func validBase() Config {
	return Config{
		Server:   ServerConfig{Host: "0.0.0.0", Port: 8080},
		Database: DatabaseConfig{Host: "h", DatabaseName: "nhi_db", User: "u", Password: "p", Schema: "nhi_global"},
		JWT:      JWTConfig{Secret: strings.Repeat("s", 32), AccessTTLMinutes: 60, RefreshTTLHours: 168},
	}
}

func TestWorkerConfig(t *testing.T) {
	cases := []struct {
		name    string
		w       WorkerConfig
		wantErr bool
	}{
		{"not configured is fine", WorkerConfig{}, false},
		{"http url with token", WorkerConfig{BaseURL: "http://ispm-worker:8080", ScanToken: "tok"}, false},
		{"https url with token", WorkerConfig{BaseURL: "https://worker.example.com", ScanToken: "tok"}, false},
		{"token not needed for the no-login route", WorkerConfig{BaseURL: "http://ispm-worker:8080"}, false},
		{"no scheme", WorkerConfig{BaseURL: "ispm-worker:8080", ScanToken: "tok"}, true},
		{"ftp scheme", WorkerConfig{BaseURL: "ftp://worker", ScanToken: "tok"}, true},
		{"credentials in url", WorkerConfig{BaseURL: "http://u:p@worker:8080", ScanToken: "tok"}, true},
		{"query in url", WorkerConfig{BaseURL: "http://worker:8080/?a=1", ScanToken: "tok"}, true},
		{"worker on another local port", WorkerConfig{BaseURL: "http://localhost:8090", ScanToken: "tok"}, false},
		{"worker is this backend (localhost)", WorkerConfig{BaseURL: "http://localhost:8080", ScanToken: "tok"}, true},
		{"worker is this backend (127.0.0.1)", WorkerConfig{BaseURL: "http://127.0.0.1:8080/", ScanToken: "tok"}, true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			cfg := validBase()
			cfg.Worker = c.w
			cfg.applyDefaults()
			err := cfg.validate()
			if (err != nil) != c.wantErr {
				t.Fatalf("err = %v, wantErr %v", err, c.wantErr)
			}
			if err == nil && cfg.Worker.Enabled() && cfg.Worker.TimeoutSeconds != 10 {
				t.Errorf("timeout default = %d, want 10", cfg.Worker.TimeoutSeconds)
			}
		})
	}
}

func TestWorkerEnvironment(t *testing.T) {
	t.Setenv("WORKER_URL", " http://localhost:8080/ ")
	t.Setenv("WORKER_SCAN_TOKEN", "abc")
	var cfg Config
	if err := cfg.applyEnvironment(); err != nil {
		t.Fatal(err)
	}
	cfg.applyDefaults()
	if cfg.Worker.BaseURL != "http://localhost:8080" || cfg.Worker.ScanToken != "abc" {
		t.Fatalf("worker = %+v", cfg.Worker)
	}
}
