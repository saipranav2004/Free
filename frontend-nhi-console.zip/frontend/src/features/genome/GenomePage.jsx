import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Dna, Download, SearchX } from 'lucide-react';
import {
  fetchGenomeFleetIndex,
  fetchGenomeIdentities,
  fetchGenomeSummary,
} from '../../lib/api/genome';
import { genomeRoute } from '../../lib/identityLinks';
import { useDebouncedValue, useQuery } from '../../lib/hooks';
import { exportRowsToCsv, timestampedName } from '../../lib/csv';
import { severityMeta } from '../../lib/domain';
import { formatDateTime, formatNumber, formatRelative } from '../../lib/format';
import { PageHeader } from '../../shell/PageHeader';
import { Button } from '../../ui/Button';
import { DataGrid } from '../../ui/DataGrid';
import { SearchInput, Select } from '../../ui/Field';
import { AppliedFilters, FacetRail, useFacetRail } from '../../ui/FacetRail';
import { Meter, ProportionBar } from '../../ui/Meter';
import { Panel, PanelHeader } from '../../ui/Panel';
import { StatStripSkeleton } from '../../ui/Skeleton';
import { MetricTile } from '../../ui/Stat';
import { EmptyState, ErrorState } from '../../ui/States';
import { SegmentedControl } from '../../ui/Tabs';
import { Tag } from '../../ui/Tag';
import { RefreshButton, TableToolbar } from '../../ui/TableTools';
import { useToast } from '../../ui/Toast';
import { RecordBar, ResultCount, ShowFiltersButton, WorkArea } from '../../ui/WorkArea';
import { TrendChart } from '../../charts/TrendChart';
import { IdentityQuickView } from './IdentityQuickView';
import {
  baselineMeta,
  CursorPager,
  dimensionLabel,
  learningPercent,
  RiskCell,
  sourceTypeLabel,
  useCursorPager,
} from './meta';

const WINDOWS = [
  { value: '24h', label: '24h' },
  { value: '7d', label: '7d' },
  { value: '30d', label: '30d' },
];

const SORTS = [
  { value: 'risk_desc', label: 'Highest risk first' },
  { value: 'last_seen_desc', label: 'Most recently seen' },
  { value: 'name_asc', label: 'Name (A-Z)' },
];

const PAGE_SIZES = [10, 25, 50, 100];

/* The fleet facets map one-to-one onto the list API's filters. Each takes a
   single value, so a group behaves as a radio set that can be cleared. */
const FACETS = [
  { key: 'source', param: 'sourceType', field: 'source_type', label: 'Source type', describe: sourceTypeLabel },
  { key: 'account', param: 'accountId', field: 'account_id', label: 'Account', describe: (value) => value },
  { key: 'region', param: 'region', field: 'region', label: 'Region', describe: (value) => value },
  { key: 'status', param: 'status', field: 'status', label: 'Lifecycle state', describe: (value) => value },
];

function windowLabel(hours) {
  if (!Number.isFinite(hours) || hours <= 0) return '-';
  if (hours < 48) return `${hours} hours`;
  return `${Math.round(hours / 24)} days`;
}

const utcDay = (date) => date.toISOString().slice(0, 10);

/** Every UTC day of the chart window, with the days that had no anomaly at 0. */
function dailySeries(rows, from) {
  const counts = new Map(rows.map((row) => [row.day, Number(row.count) || 0]));
  const end = new Date();
  const start = from ? new Date(from) : new Date(end.getTime() - 13 * 86400000);
  const out = [];
  const cursor = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate()));
  while (cursor <= end) {
    const day = utcDay(cursor);
    out.push({
      day,
      label: cursor.toLocaleDateString(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' }),
      anomalies: counts.get(day) ?? 0,
    });
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return out;
}

/**
 * NHI Genome - fleet view.
 *
 * Top: is the fleet baselined, what departed from its baselines in the window,
 * and who departed most. Bottom: the monitored fleet itself, filterable by the
 * fields the genome service filters on, each row opening a quick view.
 *
 * The genome service is read-only: anomalies are raised and closed by the
 * detection pipeline, so there is nothing to acknowledge or suppress here.
 */
export default function GenomePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { notify } = useToast();
  const { railOpen, toggleRail } = useFacetRail();
  const [selected, setSelected] = useState(null);

  const window = WINDOWS.some((entry) => entry.value === searchParams.get('window')) ? searchParams.get('window') : '24h';
  const sort = SORTS.some((entry) => entry.value === searchParams.get('sort')) ? searchParams.get('sort') : 'risk_desc';
  const pageSize = PAGE_SIZES.includes(Number(searchParams.get('size'))) ? Number(searchParams.get('size')) : 25;
  const filters = useMemo(
    () => Object.fromEntries(FACETS.map((facet) => [facet.param, searchParams.get(facet.key) || ''])),
    [searchParams],
  );

  const setParam = useCallback(
    (key, value) => {
      const next = new URLSearchParams(searchParams);
      if (value) next.set(key, value);
      else next.delete(key);
      setSearchParams(next, { replace: true });
    },
    [searchParams, setSearchParams],
  );

  /* Search is typed, so it is debounced before it becomes a request; the URL
     follows it so a filtered view can be shared. */
  const [searchDraft, setSearchDraft] = useState(() => searchParams.get('q') || '');
  const search = useDebouncedValue(searchDraft, 320).trim();
  const lastSearch = useRef(search);
  useEffect(() => {
    if (lastSearch.current === search) return;
    lastSearch.current = search;
    setSearchParams(
      (current) => {
        const next = new URLSearchParams(current);
        if (search) next.set('q', search);
        else next.delete('q');
        return next;
      },
      { replace: true },
    );
  }, [search, setSearchParams]);

  const clearAll = useCallback(() => {
    const next = new URLSearchParams();
    for (const key of ['window', 'sort', 'size']) {
      if (searchParams.get(key)) next.set(key, searchParams.get(key));
    }
    setSearchDraft('');
    setSearchParams(next, { replace: true });
  }, [searchParams, setSearchParams, setSearchDraft]);

  const summary = useQuery((signal) => fetchGenomeSummary({ window }, signal), [window]);
  const index = useQuery((signal) => fetchGenomeFleetIndex(signal), []);

  const listKey = JSON.stringify([filters, search, sort, pageSize]);
  const pager = useCursorPager(listKey);
  const fleet = useQuery(
    (signal) =>
      fetchGenomeIdentities({ ...filters, search, sort, limit: pageSize, cursor: pager.cursor ?? undefined }, signal),
    [listKey, pager.cursor],
  );

  const rows = useMemo(() => fleet.data?.items ?? [], [fleet.data]);
  const loading = fleet.isLoading && !fleet.data;

  const chips = useMemo(
    () =>
      [
        ...FACETS.filter((facet) => filters[facet.param]).map((facet) => ({
          key: facet.key,
          label: facet.label,
          value: facet.describe(filters[facet.param]),
        })),
        search && { key: 'q', label: 'Search', value: search },
      ].filter(Boolean),
    [filters, search],
  );

  /* Facet options and counts come from the whole fleet, read once. The counts
     describe the fleet rather than the current result, so they do not move
     while you type. Beyond 1,000 identities they would be partial, so the rail
     lists options without counts instead of undercounting. */
  const indexItems = useMemo(() => index.data?.items ?? [], [index.data]);
  const countsKnown = Boolean(index.data?.complete);
  const facetGroups = useMemo(
    () =>
      FACETS.map((facet) => {
        const active = filters[facet.param];
        const counts = new Map();
        for (const item of indexItems) {
          const value = item[facet.field];
          if (value) counts.set(value, (counts.get(value) ?? 0) + 1);
        }
        if (active && !counts.has(active)) counts.set(active, undefined);
        const options = [...counts.entries()]
          .sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0) || String(a[0]).localeCompare(String(b[0])))
          .map(([value, count]) => ({
            value,
            label: facet.describe(value),
            active: active === value,
            count: countsKnown ? count : undefined,
          }));
        return {
          key: facet.key,
          label: facet.label,
          options,
          onToggle: (value) => setParam(facet.key, active === value ? '' : value),
          note:
            facet.key === 'status'
              ? 'The lifecycle state discovery recorded for the workload, as the cloud reports it.'
              : undefined,
        };
      }),
    [filters, indexItems, countsKnown, setParam],
  );

  /* An exact total is only known when the whole fleet is indexed and the
     filters are ones the index can apply the same way the service does. */
  const knownTotal = useMemo(() => {
    if (!countsKnown || search) return null;
    return indexItems.filter((item) =>
      FACETS.every((facet) => {
        const want = filters[facet.param];
        return !want || String(item[facet.field] ?? '').toLowerCase() === want.toLowerCase();
      }),
    ).length;
  }, [countsKnown, search, indexItems, filters]);

  const onExport = useCallback(() => {
    exportRowsToCsv({
      filename: timestampedName('nhi-genome-fleet'),
      columns: [
        { header: 'Identity', value: (row) => row.display_name },
        { header: 'ARN', value: (row) => row.identity_name },
        { header: 'Source type', value: (row) => row.source_type },
        { header: 'Account', value: (row) => row.account_id },
        { header: 'Region', value: (row) => row.region ?? '' },
        { header: 'Lifecycle state', value: (row) => row.status ?? '' },
        { header: 'Baseline', value: (row) => baselineMeta(row.baseline?.status).label },
        { header: 'Days learned', value: (row) => row.baseline?.built_days ?? '' },
        { header: 'Days required', value: (row) => row.baseline?.required_days ?? '' },
        { header: 'Risk score', value: (row) => row.risk?.score ?? '' },
        { header: 'Severity', value: (row) => row.risk?.severity ?? '' },
        { header: 'Open anomalies', value: (row) => row.open_anomaly_count ?? '' },
        { header: 'Last seen (UTC)', value: (row) => row.last_seen ?? '' },
      ],
      rows,
    });
    notify({
      title: 'Exported this page',
      description: `${formatNumber(rows.length)} identities written, in the order shown.`,
      variant: 'success',
    });
  }, [rows, notify]);

  const columns = [
    {
      key: 'identity',
      header: 'Identity',
      primary: true,
      width: '27%',
      cell: (row) => (
        <span className="block min-w-0">
          <span className="block truncate text-[13px] font-semibold text-ink" title={row.identity_name}>
            {row.display_name || row.identity_name}
          </span>
          <span className="block truncate text-[11.5px] text-ink-3">
            {sourceTypeLabel(row.source_type)}
            {row.status ? ` · ${row.status}` : ''}
          </span>
        </span>
      ),
    },
    {
      key: 'scope',
      header: 'Account / region',
      width: '16%',
      priority: 'wide',
      cell: (row) => (
        <span className="block min-w-0">
          <span data-numeric="" className="block truncate font-mono text-[12px] text-ink-2">
            {row.account_id || '-'}
          </span>
          <span className="block truncate text-[11.5px] text-ink-3">{row.region || 'Global'}</span>
        </span>
      ),
    },
    {
      key: 'baseline',
      header: 'Baseline',
      width: '19%',
      cell: (row) => <BaselineCell baseline={row.baseline} />,
    },
    {
      key: 'risk',
      header: 'Risk',
      width: '14%',
      cell: (row) => <RiskCell score={row.risk?.score} severity={row.risk?.severity} />,
    },
    {
      key: 'anomalies',
      header: 'Open anomalies',
      width: '11%',
      cell: (row) =>
        row.open_anomaly_count === null || row.open_anomaly_count === undefined ? (
          <span className="text-[12px] text-ink-3" title="Not measured yet">
            -
          </span>
        ) : (
          <span
            data-numeric=""
            className={row.open_anomaly_count > 0 ? 'text-[13px] font-semibold text-high' : 'text-[12.5px] text-ink-3'}
          >
            {formatNumber(row.open_anomaly_count)}
          </span>
        ),
    },
    {
      key: 'seen',
      header: 'Last seen',
      width: '13%',
      cell: (row) =>
        row.last_seen ? (
          <span className="block whitespace-nowrap text-[12.5px] text-ink-2" title={formatDateTime(row.last_seen)}>
            {formatRelative(row.last_seen)}
          </span>
        ) : (
          <span className="text-[12px] text-ink-3">No calls seen</span>
        ),
    },
  ];

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="NHI Genome"
        lede="An anomaly is a measured departure from an identity's own baseline, never from a fleet average."
        actions={
          <>
            <SegmentedControl
              label="Detection window"
              options={WINDOWS}
              value={window}
              onChange={(value) => setParam('window', value === '24h' ? '' : value)}
            />
            <Button variant="secondary" icon={Download} onClick={onExport} disabled={rows.length === 0}>
              Export page
            </Button>
          </>
        }
      />

      {summary.isError && !summary.data ? (
        <Panel prominence="quiet">
          <ErrorState error={summary.error} onRetry={summary.refetch} title="The behaviour summary failed to load" />
        </Panel>
      ) : summary.isLoading && !summary.data ? (
        <StatStripSkeleton count={4} />
      ) : (
        <SummarySection summary={summary.data} window={window} />
      )}

      <WorkArea
        railOpen={railOpen}
        rail={
          <FacetRail
            groups={facetGroups}
            appliedCount={chips.length}
            onClearAll={clearAll}
            onClose={toggleRail}
            mobileTitle="Filter the fleet"
          />
        }
      >
        <Panel prominence="lead" flush className="animate-rise overflow-hidden">
          <RecordBar
            trailing={
              <TableToolbar>
                <SearchInput
                  value={searchDraft}
                  onChange={setSearchDraft}
                  placeholder="Search name, ARN, service, role..."
                  size="sm"
                  className="w-full sm:w-64"
                  aria-label="Search monitored identities"
                />
                <Select
                  size="sm"
                  value={sort}
                  onChange={(event) => setParam('sort', event.target.value === 'risk_desc' ? '' : event.target.value)}
                  options={SORTS}
                  aria-label="Sort identities"
                  className="w-44"
                />
                {!railOpen && <ShowFiltersButton onClick={toggleRail} appliedCount={chips.length} />}
                <RefreshButton onRefresh={fleet.refetch} refreshing={fleet.isRefreshing} label="Refresh fleet" />
              </TableToolbar>
            }
          >
            {knownTotal !== null ? (
              <ResultCount
                shown={formatNumber(knownTotal)}
                total={formatNumber(indexItems.length)}
                unit="monitored identities"
                filtered={chips.length > 0}
                loading={loading}
              />
            ) : (
              <ResultCount
                shown={`${formatNumber(rows.length)}${fleet.data?.nextCursor ? '+' : ''}`}
                unit={search ? 'matching identities' : 'monitored identities'}
                loading={loading}
              />
            )}
            <span className="hidden text-[11.5px] text-ink-3 xl:inline">Open a row for a quick view</span>
          </RecordBar>

          <AppliedFilters
            filters={chips}
            onRemove={(key) => {
              if (key === 'q') setSearchDraft('');
              else setParam(key, '');
            }}
            onClearAll={clearAll}
          />

          {fleet.isError && !fleet.data ? (
            <ErrorState error={fleet.error} onRetry={fleet.refetch} />
          ) : (
            <DataGrid
              caption="Monitored identities"
              columns={columns}
              rows={rows}
              rowKey={(row) => row.id}
              loading={loading}
              refreshing={fleet.isRefreshing}
              onRowClick={setSelected}
              density="comfortable"
              skeletonRows={8}
              emptyState={
                chips.length > 0 ? (
                  <EmptyState
                    icon={SearchX}
                    title="No monitored identity matches"
                    description="Nothing in the fleet matches the current search and filters."
                    action={
                      <Button variant="secondary" size="sm" onClick={clearAll}>
                        Clear filters
                      </Button>
                    }
                  />
                ) : (
                  <EmptyState
                    icon={Dna}
                    title="No identity is monitored yet"
                    description="The genome watches workload identities (compute, functions, pipelines) found by discovery in your selected accounts and regions. None are in scope yet."
                  />
                )
              }
            />
          )}

          {!loading && !fleet.isError && (pager.page > 1 || fleet.data?.nextCursor) && (
            <CursorPager
              page={pager.page}
              shown={rows.length}
              pageSize={pageSize}
              hasNext={Boolean(fleet.data?.nextCursor)}
              onPrev={pager.prev}
              onNext={() => pager.next(fleet.data?.nextCursor)}
              onPageSizeChange={(next) => setParam('size', next === 25 ? '' : String(next))}
              unit="identities"
            />
          )}
        </Panel>
      </WorkArea>

      <IdentityQuickView identity={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

/* ── Summary ──────────────────────────────────────────────────────────────── */

function SummarySection({ summary, window }) {
  const { cards } = summary;
  const watched = cards.identities_watched;
  const established = cards.baselines_established;
  const learning = cards.still_learning;
  const baselinesKnown = established !== null && established !== undefined;
  /* The alert-backed cards and panels share one store. When the open-anomaly
     count is null that store could not be read, and an empty chart would
     claim "no anomalies" rather than "not known". */
  const alertsKnown = cards.open_anomalies !== null && cards.open_anomalies !== undefined;
  const cardWindow = windowLabel(cards.window_hours);
  const chartWindow = window === '24h' ? '14 days' : window === '7d' ? '7 days' : '30 days';
  const trend = useMemo(() => dailySeries(summary.anomaliesByDay, summary.chartsFrom), [summary]);
  const totalDepartures = summary.departuresByDimension.reduce((sum, row) => sum + (Number(row.count) || 0), 0);
  const notReported = 'Not reported yet for this scope';

  return (
    <>
      <div className="grid gap-3 @min-[30rem]:grid-cols-2 @min-[54rem]:grid-cols-4">
        <MetricTile
          label="Baselines established"
          value={established}
          tone="info"
          caption={baselinesKnown ? `of ${formatNumber(watched)} identities watched` : notReported}
          meter={baselinesKnown ? cards.baseline_coverage_percent ?? 0 : undefined}
          meterLabel="Share of the fleet baselined"
          className="animate-rise"
        />
        <MetricTile
          label="Still learning"
          value={learning}
          tone="medium"
          caption={baselinesKnown ? 'No baseline yet, so no anomaly can be raised' : notReported}
          className="animate-rise"
          data-stagger=""
          style={{ '--stagger': 1 }}
        />
        <MetricTile
          label="Open anomalies"
          value={cards.open_anomalies}
          tone="high"
          caption={alertsKnown ? `Raised in the last ${cardWindow} and still open` : notReported}
          className="animate-rise"
          data-stagger=""
          style={{ '--stagger': 2 }}
        />
        <MetricTile
          label="Baseline coverage"
          value={cards.baseline_coverage_percent}
          unit={cards.baseline_coverage_percent !== null && cards.baseline_coverage_percent !== undefined ? '%' : undefined}
          tone="low"
          caption={
            cards.baseline_coverage_percent !== null && cards.baseline_coverage_percent !== undefined
              ? 'Baselined identities over identities watched'
              : watched === 0
                ? 'No identity is watched in this scope'
                : notReported
          }
          className="animate-rise"
          data-stagger=""
          style={{ '--stagger': 3 }}
        />
      </div>

      <div className="grid gap-4 @min-[52rem]:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)]">
        <div className="flex flex-col gap-4">
          <Panel prominence="quiet" className="animate-rise">
            <PanelHeader prominence="quiet" title="Baseline coverage" />
            {baselinesKnown && watched > 0 ? (
              <ProportionBar
                className="mt-3"
                height={10}
                total={watched}
                ariaLabel={`${established} established and ${learning} learning of ${watched}`}
                segments={[
                  { key: 'established', label: 'Established', value: established, color: 'var(--t-low)' },
                  { key: 'learning', label: 'Learning', value: learning ?? 0, color: 'var(--t-medium)' },
                ]}
              />
            ) : (
              <p className="mt-3 text-[12.5px] text-ink-3">
                {watched === 0 ? 'No identity is watched in this scope.' : 'Baseline state has not been reported yet.'}
              </p>
            )}
            <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3">
              <Fact label="Identities watched" value={formatNumber(watched)} />
              <Fact
                label="Coverage"
                value={cards.baseline_coverage_percent !== null && cards.baseline_coverage_percent !== undefined ? `${cards.baseline_coverage_percent}%` : '-'}
              />
              <Fact label="Card window" value={cardWindow} />
              <Fact label="Chart window" value={chartWindow} />
            </dl>
            <p className="mt-4 text-[11.5px] leading-relaxed text-ink-3">
              An identity still learning cannot raise an anomaly, so coverage is how much of the fleet the
              detector can actually speak for.
            </p>
          </Panel>

          <Panel prominence="quiet" className="animate-rise" data-stagger="" style={{ '--stagger': 1 }}>
            <PanelHeader prominence="quiet" title="Anomalies per day" />
            {alertsKnown ? (
              <>
                <TrendChart className="mt-3" data={trend} dataKey="anomalies" label="Anomalies raised" height={132} />
                <p className="mt-1 text-[11.5px] text-ink-3">Last {chartWindow}, every status, by day raised (UTC).</p>
              </>
            ) : (
              <NotReported>Anomaly history has not been reported yet.</NotReported>
            )}
          </Panel>
        </div>

        <Panel prominence="quiet" className="animate-rise" data-stagger="" style={{ '--stagger': 2 }}>
          <PanelHeader
            prominence="quiet"
            title="Departures by dimension"
            subtitle={`Open anomalies raised in the last ${chartWindow}, by the behaviour that departed.`}
          />
          {!alertsKnown ? (
            <NotReported>Departures have not been reported yet.</NotReported>
          ) : summary.departuresByDimension.length === 0 ? (
            <p className="mt-3 text-[12.5px] text-ink-3">No open departure in this window.</p>
          ) : (
            <ul className="mt-3 flex flex-col">
              {summary.departuresByDimension.map((entry) => (
                <li key={entry.dimension} className="border-b border-line py-2 last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[12.5px] text-ink-2" title={entry.dimension}>
                        {dimensionLabel(entry.dimension)}
                      </span>
                      <span className="mt-1 block h-1.5 overflow-hidden rounded-full bg-track">
                        <span
                          className="block h-full rounded-full"
                          style={{
                            width: `${totalDepartures ? (entry.count / totalDepartures) * 100 : 0}%`,
                            background: 'var(--t-series-1)',
                          }}
                        />
                      </span>
                    </span>
                    <span data-numeric="" className="shrink-0 text-[12.5px] font-semibold text-ink">
                      {formatNumber(entry.count)}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <div className="grid gap-4 @min-[52rem]:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <Panel prominence="quiet" flush className="animate-rise overflow-hidden">
          <div className="border-b border-line px-4 py-3">
            <PanelHeader
              prominence="quiet"
              title="Most anomalous identities"
              subtitle="Highest latest risk score. Anomalous calls are counted in the scoring window."
            />
          </div>
          {summary.mostAnomalous.length === 0 ? (
            <p className="px-4 py-6 text-[12.5px] text-ink-3">No identity has a risk score yet.</p>
          ) : (
            <ul className="divide-y divide-line">
              {summary.mostAnomalous.map((identity) => {
                const severity = severityMeta(identity.severity);
                return (
                  <li key={identity.id}>
                    <Link
                      to={genomeRoute(identity.source_type, identity.identity_name)}
                      className="flex items-center gap-3 px-4 py-2.5 transition-colors hover:bg-surface-3"
                    >
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-medium text-ink" title={identity.identity_name}>
                          {identity.display_name || identity.identity_name}
                        </span>
                        <span className="block truncate text-[11.5px] text-ink-3">
                          {sourceTypeLabel(identity.source_type)} · {identity.account_id}
                          {identity.region ? ` · ${identity.region}` : ''}
                        </span>
                      </span>
                      <span
                        data-numeric=""
                        className="hidden shrink-0 text-[12px] text-ink-3 sm:inline"
                        title={`${formatNumber(identity.anomalous_event_count)} anomalous of ${formatNumber(identity.event_count)} calls scored`}
                      >
                        {identity.event_count
                          ? `${formatNumber(identity.anomalous_event_count)} of ${formatNumber(identity.event_count)} calls anomalous`
                          : 'No calls scored'}
                      </span>
                      <span data-numeric="" className="w-10 shrink-0 text-right text-[13px] font-semibold text-ink">
                        {formatNumber(identity.risk_score)}
                      </span>
                      {identity.severity && (
                        <Tag tone={severity.tone} size="sm" dot>
                          {severity.label}
                        </Tag>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>

        <Panel prominence="quiet" className="animate-rise" data-stagger="" style={{ '--stagger': 1 }}>
          <PanelHeader prominence="quiet" title="Recently baselined" />
          {summary.recentlyBaselined.length === 0 ? (
            <p className="mt-2 text-[12.5px] text-ink-3">No baseline has been established or republished yet.</p>
          ) : (
            <ul className="mt-2 flex flex-col gap-1.5">
              {summary.recentlyBaselined.map((entry) => (
                <li key={entry.id} className="flex items-center gap-2">
                  <Link
                    to={genomeRoute(entry.source_type, entry.identity_name)}
                    className="min-w-0 flex-1 truncate text-[12px] text-ink-2 hover:text-ink hover:underline"
                    title={entry.identity_name}
                  >
                    {entry.display_name || entry.identity_name}
                  </Link>
                  <span className="shrink-0 text-[11px] text-ink-3" title={formatDateTime(entry.occurred_at)}>
                    {formatRelative(entry.occurred_at)}
                  </span>
                  {entry.event === 'baseline_version_published' ? (
                    <Tag tone="info" size="sm">
                      {entry.version ? `Version ${entry.version}` : 'New version'}
                    </Tag>
                  ) : (
                    <Tag tone="low" size="sm">
                      Established
                    </Tag>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </>
  );
}

function BaselineCell({ baseline }) {
  const meta = baselineMeta(baseline?.status);
  const pct = learningPercent(baseline?.built_days, baseline?.required_days);
  return (
    <span className="block min-w-0">
      <Tag tone={meta.tone} size="sm" dot>
        {meta.label}
      </Tag>
      {pct !== null && (
        <span className="mt-1.5 flex items-center gap-2">
          <Meter value={pct} tone={meta.key === 'active' ? 'low' : 'medium'} height={3} className="min-w-0 flex-1" label="Learning progress" />
          <span data-numeric="" className="shrink-0 text-[11px] leading-none text-ink-3">
            {formatNumber(baseline.built_days)}/{formatNumber(baseline.required_days)}d
          </span>
        </span>
      )}
    </span>
  );
}

function NotReported({ children }) {
  return <p className="mt-3 rounded-[var(--radius-control)] border border-dashed border-line px-3 py-6 text-center text-[12.5px] text-ink-3">{children}</p>;
}

function Fact({ label, value }) {
  return (
    <div className="min-w-0">
      <dt className="text-[10.5px] font-semibold tracking-[0.1em] text-ink-3 uppercase">{label}</dt>
      <dd data-numeric="" className="mt-0.5 truncate text-[13px] font-semibold text-ink">
        {value}
      </dd>
    </div>
  );
}
