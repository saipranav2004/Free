import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { identitySearchRoute, resolveDiscoveryId } from '../../lib/api/posture';
import { identityRoute } from '../../lib/identityLinks';
import { useToast } from '../../ui/Toast';

/**
 * Opens a posture identity on the identity page. Posture rows carry the
 * posture id and name; the identity page needs the discovery id, so it is
 * resolved by exact ARN first. When discovery does not hold the identity the
 * inventory search for its name opens instead, and the toast says why.
 */
export function useOpenPostureIdentity() {
  const navigate = useNavigate();
  const { notify } = useToast();
  const [opening, setOpening] = useState(null);

  const open = useCallback(
    async ({ postureId, name, arn }) => {
      setOpening(postureId ?? name);
      try {
        const id = await resolveDiscoveryId({ postureId, name, arn });
        if (id) {
          navigate(identityRoute(id, 'posture'));
          return;
        }
        notify({
          variant: 'info',
          title: 'Not in the current inventory',
          description: `${name} is scored by posture but is not in the inventory you can see. Showing the closest matches by name.`,
        });
        navigate(identitySearchRoute(name));
      } catch (error) {
        notify({ variant: 'error', title: 'Could not open the identity', description: error?.message });
      } finally {
        setOpening(null);
      }
    },
    [navigate, notify],
  );

  return { open, opening };
}
