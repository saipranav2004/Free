import { AlertTriangle, CheckCircle2, Plus } from 'lucide-react';
import { cn } from '../../ui/cn';

/**
 * One platform's scanning state on one account:
 *
 *   on       switched on and its last check passed
 *   failing  switched on, but the last check did not pass - nothing is scanned
 *   off      not switched on
 */
export function exposureState(platform) {
  if (platform.connected) return 'on';
  if (platform.checks.length > 0) return 'failing';
  return 'off';
}

const STATE = {
  on: { icon: CheckCircle2, className: 'border-low/30 bg-low-soft text-low', word: 'On' },
  failing: { icon: AlertTriangle, className: 'border-medium/35 bg-medium-soft text-medium', word: 'Check failed' },
  off: { icon: null, className: 'border-line bg-surface-2 text-ink-3', word: 'Off' },
};

/** GitHub and CodeCommit state for an account row, opening its settings when allowed. */
export function ExposureBadges({ account, onOpen }) {
  if (!account.connectedAt) {
    return <span className="text-[12px] text-ink-3">After the account connects</span>;
  }
  const github = exposureState(account.exposure.github);
  const codecommit = exposureState(account.exposure.codecommit);
  const none = github === 'off' && codecommit === 'off';

  if (none) {
    return onOpen ? (
      <button
        type="button"
        onClick={onOpen}
        className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[12px] font-medium text-brand transition-colors hover:bg-info-soft"
        aria-label={`Set up exposed-credential scanning for ${account.accountId}`}
      >
        <Plus aria-hidden="true" className="size-3.5" />
        Set up
      </button>
    ) : (
      <span className="text-[12px] text-ink-3">Off</span>
    );
  }

  const body = (
    <span className="inline-flex flex-wrap items-center gap-1">
      <Badge label="GitHub" state={github} />
      <Badge label="CodeCommit" state={codecommit} />
    </span>
  );
  return onOpen ? (
    <button
      type="button"
      onClick={onOpen}
      className="-mx-1 rounded-md px-1 py-1 text-left transition-colors hover:bg-surface-3"
      aria-label={`Exposed-credential scanning for ${account.accountId}: GitHub ${STATE[github].word}, CodeCommit ${STATE[codecommit].word}. Manage`}
    >
      {body}
    </button>
  ) : (
    body
  );
}

function Badge({ label, state }) {
  const meta = STATE[state];
  const Icon = meta.icon;
  return (
    <span
      title={`${label}: ${meta.word}`}
      className={cn('inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium', meta.className)}
    >
      {Icon && <Icon aria-hidden="true" className="size-3" />}
      {label}
    </span>
  );
}
