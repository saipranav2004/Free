import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, CheckCircle2, FileWarning, Settings2, ShieldCheck } from 'lucide-react';
import { useAccess } from '../../app/useAccess';
import { Button } from '../../ui/Button';
import { Panel, PanelHeader } from '../../ui/Panel';
import { Tag } from '../../ui/Tag';
import { cn } from '../../ui/cn';
import { exposureState } from './ExposureBadges';
import { CodeCommitMark, GitHubMark } from './parts';

const PLATFORMS = [
  {
    key: 'github',
    name: 'GitHub',
    Mark: GitHubMark,
    needs: 'A read-only GitHub token, kept in your own Secrets Manager, that the role may read.',
  },
  {
    key: 'codecommit',
    name: 'AWS CodeCommit',
    Mark: CodeCommitMark,
    needs: 'AWSCodeCommitReadOnly on the role you already created.',
  },
];

/**
 * The exposed-credentials feature on the Integrations page: whether it is on,
 * where, and the one button that sets it up. Its screens join the sidebar
 * once any platform passes its checks for any account.
 */
export function ExposurePanel({ accounts, exposureEnabled, canManage, onOpen }) {
  const { lock, can } = useAccess();
  const eligible = accounts.filter((account) => account.connectedAt);
  const summary = PLATFORMS.map((platform) => {
    const on = [];
    const failing = [];
    for (const account of eligible) {
      const state = exposureState(account.exposure[platform.key]);
      if (state === 'on') on.push(account.accountId);
      if (state === 'failing') failing.push(account.accountId);
    }
    return { ...platform, on, failing };
  });
  const anyFailing = summary.some((platform) => platform.failing.length > 0);
  const locked = !canManage ? lock('integrations.manage') || 'Only an admin can change this' : undefined;

  return (
    <Panel aria-labelledby="exposure-panel-title">
      <PanelHeader
        id="exposure-panel-title"
        icon={FileWarning}
        title="Exposed credentials"
        subtitle="Scan your GitHub and CodeCommit repositories for access keys, tokens and passwords committed to code. Optional - switch it on per account."
        actions={
          <>
            {exposureEnabled ? (
              <Tag tone={anyFailing ? 'medium' : 'low'} size="sm" icon={anyFailing ? AlertTriangle : CheckCircle2}>
                {anyFailing ? 'On, needs attention' : 'On'}
              </Tag>
            ) : anyFailing ? (
              <Tag tone="medium" size="sm" icon={AlertTriangle}>
                Check failed
              </Tag>
            ) : (
              <Tag tone="neutral" size="sm">
                Off
              </Tag>
            )}
            <Button
              variant={exposureEnabled ? 'secondary' : 'primary'}
              size="sm"
              icon={exposureEnabled ? Settings2 : ShieldCheck}
              locked={locked}
              disabled={eligible.length === 0}
              title={eligible.length === 0 ? 'Available once an account is connected' : undefined}
              onClick={() => onOpen(null)}
            >
              {exposureEnabled ? 'Manage' : 'Set up scanning'}
            </Button>
          </>
        }
      />

      <ul className="mt-4 grid gap-3 @min-[46rem]:grid-cols-2">
        {summary.map((platform) => (
          <li
            key={platform.key}
            className={cn(
              'flex gap-3 rounded-[var(--radius-control)] border px-3.5 py-3',
              platform.failing.length ? 'border-medium/35 bg-medium-soft/50' : 'border-line bg-surface-2',
            )}
          >
            <platform.Mark size="sm" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                <p className="text-[13px] font-semibold text-ink">{platform.name}</p>
                <PlatformState on={platform.on} failing={platform.failing} total={eligible.length} />
              </div>
              <p className="mt-0.5 text-[12px] leading-relaxed text-ink-3">{platform.needs}</p>
              {platform.failing.length > 0 && canManage && (
                <button
                  type="button"
                  onClick={() => onOpen(platform.failing[0])}
                  className="mt-1.5 inline-flex items-center gap-1 text-[12px] font-medium text-brand hover:underline"
                >
                  See what failed in {platform.failing[0]}
                  <ArrowRight aria-hidden="true" className="size-3.5" />
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>

      <p className="mt-3 text-[12px] text-ink-3">
        {exposureEnabled && !can('exposure.view') ? (
          'Findings are visible to admins.'
        ) : exposureEnabled ? (
          <>
            Findings are listed under{' '}
            <Link to="/exposure" className="font-medium text-brand hover:underline">
              Exposed credentials
            </Link>{' '}
            in the sidebar.
          </>
        ) : (
          'Exposed credentials joins the sidebar as soon as one platform passes its checks.'
        )}
      </p>
    </Panel>
  );
}

function PlatformState({ on, failing, total }) {
  if (on.length === 0 && failing.length === 0) return <span className="text-[11.5px] text-ink-3">Off</span>;
  const parts = [];
  if (on.length) parts.push(<span key="on" className="text-low">On in {count(on.length, total)}</span>);
  if (failing.length) parts.push(<span key="f" className="text-medium">check failed in {count(failing.length, total)}</span>);
  return (
    <span className="text-[11.5px] font-medium" title={[...on, ...failing].join(', ')}>
      {parts.reduce((all, part, index) => (index ? [...all, ' · ', part] : [part]), [])}
    </span>
  );
}

function count(n, total) {
  if (total === 1) return 'your account';
  return `${n} of ${total} accounts`;
}
