# NHI Console - frontend

React 19 + Vite + Tailwind v4. The console for the NHI backend, one Go service
that serves every API below on one origin, behind one sign-in. No demo data:
every screen reads a real API.

| Browser path | API | Used by |
|---|---|---|
| `/api/v1/*` | Discovery | sign-in, dashboard, identities, credentials, activity, access graph, exposed credentials, integrations |
| `/api/v1/ispm/*` | ISPM posture | Posture page, identity Posture tab, posture scores elsewhere |
| `/api/v1/genome/*` | NHI Genome | NHI Genome pages, behaviour panel on the dashboard |

## Run locally

```sh
npm ci
cp .env.example .env      # backend URL for the dev proxy; nothing secret
npm run dev               # http://localhost:3000
npm run lint && npm run build
```

The dev server proxies `/api` to the backend (see `vite.config.js`). In
production nginx does the same (`nginx/nginx.conf.template`); the image takes
`API_UPSTREAM` and `DNS_RESOLVER` at run time (see `Dockerfile`).

## Sessions

`POST /api/v1/login` starts a session and returns an access token and a refresh
token. A 401 refreshes once (single-flight, shared across tabs with the Web
Locks API) and retries; when that fails the console returns to sign-in.
Signing out ends the session on the server, so its access token stops working
everywhere at once, other tabs included. See `src/lib/api/{client,session,auth}.js`.

## What a workspace sees

Driven by `GET /api/v1/integrations/aws` (`src/app/WorkspaceContext.jsx`):

1. **No AWS account connected yet:** only the Integrations setup, in a focused
   layout. Any other URL redirects there (`src/app/ConnectionGate.jsx`).
2. **An account has connected:** the full console, except the exposed-credential
   screens.
3. **Exposed-credential scanning switched on** (GitHub or CodeCommit passed its
   checks for any account): *Credential exposure → Exposed credentials /
   Accepted* join the sidebar and the command palette. A typed URL before that
   shows how to switch it on (`src/app/RequireFeature.jsx`).

If that check cannot be made at all, the console opens as usual rather than
locking out a workspace that is already set up.

## Roles

Server roles map to console roles in `src/lib/api/auth.js`; what each may do is
in `src/lib/roles.js`. Changing integrations and the exposed-credential screens
are admin-only (the API enforces the same); finding updates on Posture are for
analysts and admins.

## Screens

| Route | Source |
|---|---|
| `/integrations` | Connect AWS (role, EventBridge rule, verify with regions), accounts (sync, regions, re-check, remove), exposed-credential scanning per account |
| `/overview` | discovery dashboard, posture overview, genome summary, exposure summary (only when on) |
| `/posture` | posture overview, facets, identities, checks, CSV export |
| `/identities`, `/identities/:id` | discovery identities; tabs overview, posture, permissions, credentials, role use, activity |
| `/credentials` | discovery credentials and their detail tabs |
| `/activity` | CloudTrail activity for a chosen identity |
| `/access-graph`, `/access-graph/:id` | relationships around an identity or credential; granted vs used |
| `/genome`, `/genome/:id` | behavioural summary, baselines, activity, timeline |
| `/exposure`, `/exposure/dismissed` | exposed-credential findings, verdicts, accepted list, deep scans |

Pages in the design reference with no API behind them (Alerts, Reports, Users,
Scans) are not part of this build.
