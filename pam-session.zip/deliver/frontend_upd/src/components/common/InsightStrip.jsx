import clsx from 'clsx'
import { useValueChange } from '../../hooks/useValueChange'

// ---------------------------------------------------------------------------
// Insight cards
// ---------------------------------------------------------------------------
// Analytics lived on the dashboard and nowhere else: one page of eleven had a
// chart, and the other ten opened straight into a table. Meanwhile
// components/charts/Charts.jsx already exported an area chart, a donut, a bar
// list, a column chart and an activity heatmap — written, ours, and used once.
//
// This is the frame that lets them sit above any screen. The rules that make a
// strip read as premium rather than as decoration:
//
//   ONE QUESTION PER CARD. A card answers something the operator would
//     otherwise have to work out by scanning the table underneath it.
//   A HERO FIGURE, THEN THE SHAPE, THEN THE BREAKDOWN. That is the order the
//     eye wants, and it is what the analytics cards people admire all do.
//   A CARD THAT WOULD BE EMPTY SAYS SO. A chart drawn over no data is worse
//     than a sentence explaining there is none.
//   NOTHING IS A CARD BY DEFAULT. The strip carries one hairline frame; the
//     cards inside it are separated by rules, not stacked boxes, so the
//     hierarchy stays flat (see Badge.jsx for the same argument about pills).

export function InsightStrip({ children, cols = 3, className }) {
  return (
    <div
      className={clsx(
        'grid gap-px overflow-hidden rounded-xl border border-line bg-line',
        'sm:grid-cols-2',
        // Written out rather than built as `lg:grid-cols-${cols}`: Tailwind
        // scans source text for class names, so an interpolated one is never
        // generated and the strip would silently fall back to one column.
        cols === 4 ? 'lg:grid-cols-2 xl:grid-cols-4' : 'lg:grid-cols-3',
        className
      )}
    >
      {children}
    </div>
  )
}

// InsightCard is one question. `value` is the hero figure, `visual` the shape
// beside or beneath it, `footer` the breakdown.
export function InsightCard({
  label,
  value,
  unit,
  tone = 'default',
  hint,
  visual,
  footer,
  loading = false,
  empty = false,
  emptyLabel = 'Nothing recorded yet',
}) {
  // The figure acknowledges its own change. On a polling screen a number that
  // updates silently is indistinguishable from a screenshot.
  const changed = useValueChange(value)

  return (
    // data-insight names the card and data-insight-value marks the hero
    // figure. Both exist so a test can read ONE number out of a card without
    // scraping text — stripping non-digits from the card's innerText picks up
    // the "7" in "last 7 days" and reports 71,075 where the figure is 1,075,
    // which is a test that fails loudly for the wrong reason and, worse,
    // could pass for one.
    <section data-insight={label} className="flex min-w-0 flex-col gap-2.5 bg-surface p-4">
      <header className="flex min-w-0 items-baseline gap-2">
        <h3 className="min-w-0 flex-1 truncate text-2xs font-semibold uppercase tracking-[0.07em] text-tertiary">
          {label}
        </h3>
        {hint && <span className="flex-none text-2xs text-tertiary">{hint}</span>}
      </header>

      {loading ? (
        <>
          <div className="h-7 w-24 animate-pulse rounded bg-subtle" />
          <div className="h-10 w-full animate-pulse rounded bg-subtle" />
        </>
      ) : empty ? (
        <p className="py-3 text-sm leading-relaxed text-tertiary">{emptyLabel}</p>
      ) : (
        <>
          {value !== undefined && value !== null && (
            <p
              key={changed.animationKey}
              data-insight-value=""
              className={clsx(
                'flex items-baseline gap-1.5 text-2xl font-bold leading-none tabular',
                tone === 'danger' && 'text-danger',
                tone === 'warn' && 'text-warn',
                tone === 'ok' && 'text-ok',
                tone === 'default' && 'text-primary',
                changed.className
              )}
            >
              {value}
              {unit && <span className="text-sm font-medium text-tertiary">{unit}</span>}
            </p>
          )}
          {visual && <div className="min-w-0">{visual}</div>}
          {footer && <div className="min-w-0 text-2xs text-tertiary">{footer}</div>}
        </>
      )}
    </section>
  )
}

// A compact legend for a donut or a stacked figure: a dot, a name, a count.
// Deliberately not a chart legend library — three rows of text is all this
// needs, and anything more would compete with the figure it explains.
export function InsightLegend({ items }) {
  return (
    <ul className="flex flex-col gap-1">
      {(items || []).map((item) => (
        <li key={item.label} className="flex min-w-0 items-center gap-2">
          <span
            aria-hidden="true"
            className="h-1.5 w-1.5 flex-none rounded-full"
            style={{ background: item.color }}
          />
          <span className="min-w-0 flex-1 truncate text-2xs text-secondary">{item.label}</span>
          <span className="flex-none text-2xs tabular text-primary">{item.value}</span>
        </li>
      ))}
    </ul>
  )
}

// ---------------------------------------------------------------------------
// Card-sized visuals
// ---------------------------------------------------------------------------
// Charts.jsx draws full-size charts with value axes, gridlines and hover
// readouts. Inside a card none of that fits, and shrinking a real chart to
// 56px does not produce a small chart — it produces an unreadable one with a
// three-tick axis nobody can read. These are the two shapes a card actually
// needs, drawn at card scale and nothing more.

// InsightSpark is a series as bare columns: shape only, no axis. The point is
// "is this rising, flat, or spiky", which is exactly what a card can answer
// and a table cannot.
export function InsightSpark({ points, height = 40, ariaLabel }) {
  const bars = points || []
  const max = Math.max(1, ...bars.map((p) => Number(p.value) || 0))
  return (
    <div
      className="flex items-end gap-px"
      style={{ height }}
      role="img"
      aria-label={ariaLabel}
    >
      {bars.map((p, i) => {
        const value = Math.max(0, Number(p.value) || 0)
        // A zero day still draws a 1px floor. Without it a sparse series looks
        // like a shorter series, and the gaps stop being legible as zeroes.
        const pct = value === 0 ? 0 : (value / max) * 100
        return (
          <span
            key={p.label ?? i}
            title={`${p.label}: ${value}`}
            className="min-w-0 flex-1 rounded-t-[1px] bg-subtle"
            style={{ height: '100%', display: 'flex', alignItems: 'flex-end' }}
          >
            <span
              className="bar-grow w-full rounded-t-[1px]"
              style={{
                height: `${pct}%`,
                minHeight: value > 0 ? 2 : 0,
                background: 'rgb(var(--chart-series))',
                '--stagger-index': i,
              }}
            />
          </span>
        )
      })}
    </div>
  )
}

// InsightMeter is one proportion as a single filled rule. Used where the
// figure IS the proportion — recording coverage, refusal rate — and a chart
// would be three pixels of information dressed up as six.
export function InsightMeter({ value, max = 100, tone = 'default', ariaLabel }) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0
  return (
    <div
      className="h-1.5 w-full overflow-hidden rounded-full bg-subtle"
      role="img"
      aria-label={ariaLabel}
    >
      <span
        className="block h-full rounded-full transition-[width] duration-500"
        style={{
          width: `${pct}%`,
          transitionTimingFunction: 'var(--ease-expressive)',
          // --warn, not --chart-denied: the chart palette carries only
          // series and denied, so mapping warn onto denied put an amber
          // figure over a red bar — one card giving two verdicts on one
          // fact. The semantic token is the one that matches the number.
          background:
            tone === 'danger'
              ? 'rgb(var(--chart-denied))'
              : tone === 'warn'
                ? 'rgb(var(--warn))'
                : 'rgb(var(--chart-series))',
        }}
      />
    </div>
  )
}

// InsightBands is a set of ordinal buckets — session length, token runway —
// where the LABELS carry as much meaning as the heights, so they are drawn
// rather than hidden behind a hover.
export function InsightBands({ bands, tone = 'default', labelWidth = 'w-20' }) {
  const rows = (bands || []).filter(Boolean)
  const max = Math.max(1, ...rows.map((b) => Number(b.value) || 0))
  return (
    <ul className="flex flex-col gap-1">
      {rows.map((b) => {
        const value = Math.max(0, Number(b.value) || 0)
        return (
          <li key={b.label} className="flex items-center gap-2">
            <span className={clsx('flex-none truncate text-2xs text-tertiary', labelWidth)}>
              {b.label}
            </span>
            <span className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full bg-subtle">
              <span
                className="block h-full rounded-full"
                style={{
                  width: `${(value / max) * 100}%`,
                  background:
                    tone === 'danger' && value > 0
                      ? 'rgb(var(--chart-denied))'
                      : tone === 'warn' && value > 0
                        ? 'rgb(var(--warn))'
                        : 'rgb(var(--chart-series))',
                }}
              />
            </span>
            <span className="w-8 flex-none text-right text-2xs tabular text-primary">{value}</span>
          </li>
        )
      })}
    </ul>
  )
}

// A strip whose figures failed to load says so once, in its own frame, and
// leaves the page working. An insight card is decoration above somebody
// else's table; it must never become the reason the page looks broken.
export function InsightUnavailable({ message = 'Insights are unavailable right now.' }) {
  return (
    <div className="rounded-xl border border-line bg-surface px-4 py-3 text-2xs text-tertiary">
      {message}
    </div>
  )
}
