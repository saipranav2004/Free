import { useCallback, useEffect, useRef } from 'react'
import { ChevronRight } from 'lucide-react'
import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Tree browser — the archetype for a hierarchy
// ---------------------------------------------------------------------------
// The vault is safe → folder → secret. It was shipped as three separate pages
// of table, one per level, which loses the thing a hierarchy is for: seeing
// where you are in it. Every move down was a full navigation, every move
// across was two, and nothing on screen ever showed the shape.
//
// A tree shows the shape and keeps the position. It is the right archetype
// here and the WRONG one for a list of comparable rows — a flat list in a tree
// is a table with worse alignment and a pointless indent column.
//
// ACCESSIBILITY IS NOT OPTIONAL FOR THIS ONE. A tree built from nested divs is
// an unnavigable maze to a screen reader. The ARIA tree pattern is what makes
// it work, and it is specific: role=tree on the container, role=treeitem on
// every node, aria-expanded on a node WITH children and absent on a leaf (the
// attribute is what distinguishes the two), aria-level for depth, and exactly
// ONE tab stop for the whole tree with arrow keys moving inside it.

export function TreeBrowser({ children, className, 'aria-label': ariaLabel }) {
  return (
    <ul role="tree" aria-label={ariaLabel} className={clsx('min-w-0 select-none', className)}>
      {children}
    </ul>
  )
}

export function TreeNode({
  id,
  label,
  icon,
  meta,
  level = 1,
  expanded = false,
  selected = false,
  hasChildren = false,
  loading = false,
  onToggle,
  onSelect,
  focused = false,
  children,
}) {
  const Icon = icon
  const ref = useRef(null)

  // Only the focused node is tabbable, so the whole tree is one tab stop and
  // the arrow keys own movement inside it. A tree where every node is a tab
  // stop means tabbing past a vault of four hundred secrets to reach the
  // button after it.
  useEffect(() => {
    if (focused) ref.current?.focus({ preventScroll: true })
  }, [focused])

  return (
    <li role="none" className="min-w-0">
      <div
        ref={ref}
        role="treeitem"
        // Present only when the node can have children: on a leaf the
        // attribute itself announces "collapsed group", which is a lie about
        // a secret that contains nothing.
        aria-expanded={hasChildren ? expanded : undefined}
        aria-selected={selected}
        aria-level={level}
        tabIndex={focused ? 0 : -1}
        onClick={() => onSelect?.(id)}
        onDoubleClick={() => hasChildren && onToggle?.(id)}
        className={clsx(
          'group flex min-w-0 cursor-pointer items-center gap-1.5 rounded py-1 pr-2 text-sm transition-colors',
          selected ? 'bg-subtle text-primary' : 'text-secondary hover:bg-hover hover:text-primary',
          'focus-visible:outline focus-visible:outline-1 focus-visible:outline-accent'
        )}
        style={{ paddingLeft: `${0.25 + (level - 1) * 0.875}rem` }}
      >
        <button
          type="button"
          // The twisty is not a tab stop of its own: it duplicates what the
          // arrow keys already do, and inserting it into the tab order doubles
          // the number of stops to no benefit.
          tabIndex={-1}
          aria-hidden="true"
          onClick={(e) => {
            e.stopPropagation()
            if (hasChildren) onToggle?.(id)
          }}
          className={clsx('flex-none rounded p-0.5', hasChildren ? 'text-tertiary' : 'invisible')}
        >
          <ChevronRight
            className={clsx(
              'h-3 w-3 transition-transform duration-150',
              expanded && 'rotate-90',
              loading && 'animate-pulse'
            )}
          />
        </button>
        {Icon && <Icon className="h-3.5 w-3.5 flex-none text-tertiary" aria-hidden="true" />}
        <span className="min-w-0 flex-1 truncate">{label}</span>
        {meta && <span className="flex-none text-2xs tabular text-tertiary">{meta}</span>}
      </div>
      {expanded && hasChildren && (
        <ul role="group" className="min-w-0">
          {children}
        </ul>
      )}
    </li>
  )
}

// ---------------------------------------------------------------------------
// useTreeKeyboard — the ARIA tree keyboard contract
// ---------------------------------------------------------------------------
// ↓/↑ move through VISIBLE nodes (a collapsed node's children are not visible
// and must be skipped — walking the data instead of the rendering is the usual
// bug here, and it strands the cursor inside a collapsed branch).
// → expands, or steps into an already-expanded node.
// ← collapses, or steps out to the parent — which is what makes a deep tree
// escapable without reaching for the mouse.
// Home/End jump to the ends.
export function useTreeKeyboard({ visible, focusedId, setFocusedId, onToggle, onSelect, expandedIds, enabled = true }) {
  const ref = useRef({})
  ref.current = { visible, focusedId, setFocusedId, onToggle, onSelect, expandedIds }

  const handler = useCallback((e) => {
    const { visible: rows, focusedId: at, setFocusedId: setFocus, onToggle: toggle, onSelect: select, expandedIds: open } =
      ref.current
    if (!rows?.length) return
    const index = rows.findIndex((n) => n.id === at)
    const node = index === -1 ? null : rows[index]

    const move = (next) => {
      e.preventDefault()
      const clamped = Math.min(rows.length - 1, Math.max(0, next))
      setFocus(rows[clamped].id)
    }

    switch (e.key) {
      case 'ArrowDown':
        return move(index === -1 ? 0 : index + 1)
      case 'ArrowUp':
        return move(index === -1 ? rows.length - 1 : index - 1)
      case 'Home':
        return move(0)
      case 'End':
        return move(rows.length - 1)
      case 'ArrowRight':
        if (!node) return undefined
        e.preventDefault()
        if (node.hasChildren && !open.has(node.id)) toggle(node.id)
        else if (node.hasChildren) move(index + 1)
        return undefined
      case 'ArrowLeft': {
        if (!node) return undefined
        e.preventDefault()
        if (node.hasChildren && open.has(node.id)) {
          toggle(node.id)
          return undefined
        }
        // Step out: the nearest node above that sits one level shallower.
        for (let i = index - 1; i >= 0; i--) {
          if (rows[i].level < node.level) return move(i)
        }
        return undefined
      }
      case 'Enter':
      case ' ':
        if (!node) return undefined
        e.preventDefault()
        select?.(node.id, node)
        return undefined
      default:
        return undefined
    }
  }, [])

  useEffect(() => {
    if (!enabled) return undefined
    const onKey = (e) => {
      const el = document.activeElement
      // Only while the focus is actually inside the tree. A global listener
      // would make ↓ in the page's search box jump a vault node.
      if (!el?.closest?.('[role="tree"]')) return
      handler(e)
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [enabled, handler])
}

// flattenTree turns the nested model into the VISIBLE row list the keyboard
// walks: children of a collapsed node are omitted, because a cursor that can
// land on something nobody can see is the tree bug that is hardest to notice
// and most infuriating to hit.
export function flattenTree(nodes, expandedIds, level = 1, out = []) {
  for (const n of nodes || []) {
    out.push({ ...n, level })
    if (n.hasChildren && expandedIds.has(n.id) && n.children?.length) {
      flattenTree(n.children, expandedIds, level + 1, out)
    }
  }
  return out
}
