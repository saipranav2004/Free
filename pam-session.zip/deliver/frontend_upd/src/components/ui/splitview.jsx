import { createElement, isValidElement, useCallback, useEffect, useRef, useState } from 'react'
import { X } from 'lucide-react'
import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Split view — list on the left, the selected record on the right
// ---------------------------------------------------------------------------
// The console shipped one archetype eleven times: a table, and a drawer that
// slides over it. A drawer is right for an occasional aside. It is wrong for
// QUEUE WORK — going through identities, roles, policies or service accounts
// one after another — because it covers the list you are working down, so
// every step is open, read, close, find your place again.
//
// A split view keeps both on screen. The list stays where it was, the
// selection stays visible, and j/k or ↑/↓ walks it without touching the
// mouse. That is the difference between reviewing forty rows and dreading it.
//
// WHAT THIS IS NOT: it is not a drawer with different CSS. Three things have
// to be true or it is worse than the drawer it replaces —
//
//   1. The list must stay SCROLLED and SELECTED across changes. A pane that
//      re-scrolls to the top on each selection is unusable for queue work.
//   2. It must collapse to one column on a narrow screen, showing the detail
//      and a way back — a 30% list pane on a laptop is two useless columns.
//   3. The keyboard must move the selection, not just the focus ring.

const MIN_LIST = 22 // rem
const MAX_LIST = 44 // rem

// `icon` accepts EITHER a rendered element or an icon component, and the
// distinction is not "is it a function". A lucide icon is a forwardRef
// OBJECT, so `typeof icon === 'function'` is false for the more natural of
// the two spellings — and rendering the object as a child crashes the whole
// pane with React error #31, "Objects are not valid as a React child (found:
// object with keys {$$typeof, render, displayName})".
//
// Drawer.jsx hit exactly this and left a comment about it. Normalising here
// means the next component with an icon prop does not hit it a third time.
function renderIcon(icon, props = { className: 'h-4 w-4', strokeWidth: 1.75 }) {
  if (!icon) return null
  return isValidElement(icon) ? icon : createElement(icon, props)
}

export function SplitView({
  list,
  detail,
  // When nothing is selected the detail pane shows this instead of an empty
  // frame. A blank half-screen reads as a loading failure.
  placeholder,
  selected,
  onClose,
  listWidth = 30,
  onListWidthChange,
  className,
}) {
  const [width, setWidth] = useState(listWidth)
  const [dragging, setDragging] = useState(false)
  const frameRef = useRef(null)

  const applyWidth = useCallback(
    (next) => {
      const clamped = Math.min(MAX_LIST, Math.max(MIN_LIST, next))
      setWidth(clamped)
      onListWidthChange?.(clamped)
    },
    [onListWidthChange]
  )

  useEffect(() => {
    if (!dragging) return undefined
    const onMove = (e) => {
      const frame = frameRef.current
      if (!frame) return
      const left = frame.getBoundingClientRect().left
      const rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16
      applyWidth((e.clientX - left) / rem)
    }
    const onUp = () => setDragging(false)
    // Captured on the window, not the handle: the pointer routinely leaves a
    // 6px target mid-drag, and a handler bound to the handle stops receiving
    // moves the moment it does.
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    return () => {
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
  }, [dragging, applyWidth])

  const hasDetail = selected != null

  return (
    <div
      ref={frameRef}
      className={clsx('flex min-h-0 w-full items-stretch gap-0', className)}
      // While dragging, the cursor stays the resize cursor wherever it is, and
      // text selection is suppressed — without this a drag that strays over
      // the table highlights rows instead of resizing.
      style={dragging ? { cursor: 'col-resize', userSelect: 'none' } : undefined}
    >
      <div
        className={clsx(
          'min-w-0 flex-none',
          // Below lg there is only room for one pane. With something selected
          // the DETAIL is the one worth showing, and the list is one tap away.
          hasDetail ? 'hidden lg:block' : 'block w-full lg:w-auto'
        )}
        style={{ width: hasDetail ? `${width}rem` : undefined }}
      >
        {list}
      </div>

      {/* The handle is a real button so it is reachable and adjustable from
          the keyboard. A div with a mousedown handler is invisible to anyone
          not using a pointer. */}
      <button
        type="button"
        aria-label="Resize the list"
        aria-orientation="vertical"
        role="separator"
        aria-valuenow={Math.round(width)}
        aria-valuemin={MIN_LIST}
        aria-valuemax={MAX_LIST}
        onMouseDown={() => setDragging(true)}
        onDoubleClick={() => applyWidth(listWidth)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowLeft') applyWidth(width - 2)
          if (e.key === 'ArrowRight') applyWidth(width + 2)
        }}
        className={clsx(
          'group relative hidden w-px flex-none cursor-col-resize bg-line lg:block',
          !hasDetail && 'lg:hidden',
          'focus-visible:outline-none'
        )}
      >
        <span
          aria-hidden="true"
          className={clsx(
            'absolute inset-y-0 -left-1 -right-1 transition-colors',
            dragging ? 'bg-accent/40' : 'group-hover:bg-accent/25 group-focus-visible:bg-accent/40'
          )}
        />
      </button>

      {hasDetail && (
        <div className="min-w-0 flex-1 border-l border-line lg:border-l-0">
          {/* Only on narrow screens, where the list is hidden and this is the
              only way back to it. On wide screens the list is right there and
              a back button would be noise. */}
          <button
            type="button"
            onClick={onClose}
            className="flex w-full items-center gap-2 border-b border-line bg-subtle px-4 py-2 text-xs font-medium text-secondary lg:hidden"
          >
            <X className="h-3.5 w-3.5" />
            Back to the list
          </button>
          {detail}
        </div>
      )}

      {!hasDetail && placeholder && (
        <div className="hidden min-w-0 flex-1 lg:block">{placeholder}</div>
      )}
    </div>
  )
}

// SplitDetail is the frame for the right-hand pane: a sticky header carrying
// the record's identity and its actions, then the body, then a footer.
export function SplitDetail({ title, subtitle, icon, actions, footer, onClose, children }) {
  return (
    <section className="flex h-full min-w-0 flex-col">
      <header className="sticky top-0 z-10 flex items-start gap-3 border-b border-line bg-surface px-5 py-4">
        {icon && <span className="mt-0.5 flex-none text-tertiary">{renderIcon(icon)}</span>}
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-sm font-semibold text-primary">{title}</h2>
          {subtitle && <p className="mt-0.5 truncate text-2xs text-tertiary">{subtitle}</p>}
        </div>
        {actions}
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Close the detail pane"
            className="hidden flex-none rounded p-1 text-tertiary transition-colors hover:bg-hover hover:text-primary lg:block"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>
      {footer && <div className="border-t border-line bg-surface px-5 py-3">{footer}</div>}
    </section>
  )
}

// SplitPlaceholder fills the detail pane before anything is picked.
export function SplitPlaceholder({ icon, title, description }) {
  return (
    <div className="flex h-full min-h-[18rem] flex-col items-center justify-center gap-2 px-8 text-center">
      {icon && renderIcon(icon, { className: 'h-6 w-6 text-tertiary', 'aria-hidden': 'true' })}
      <p className="text-sm font-medium text-secondary">{title}</p>
      {description && <p className="max-w-[26rem] text-2xs text-tertiary">{description}</p>}
    </div>
  )
}

// ---------------------------------------------------------------------------
// useSplitSelection — the keyboard half, which is the half that matters
// ---------------------------------------------------------------------------
// A split view whose selection only moves by clicking is a drawer that takes
// up more room. ↑/↓ and j/k step through the list; Escape closes the pane.
//
// Bindings are ignored while the caret is in a field, so typing "j" in the
// search box searches for "j" rather than jumping a row — the bug every
// hand-rolled j/k implementation ships with at least once.
export function useSplitSelection({ items, selectedId, onSelect, idOf = (x) => x?.id, enabled = true }) {
  const stateRef = useRef({ items, selectedId, onSelect, idOf })
  stateRef.current = { items, selectedId, onSelect, idOf }

  useEffect(() => {
    if (!enabled) return undefined
    const onKey = (e) => {
      const el = document.activeElement
      const typing =
        el &&
        (el.tagName === 'INPUT' ||
          el.tagName === 'TEXTAREA' ||
          el.tagName === 'SELECT' ||
          el.isContentEditable)
      if (typing) return
      if (e.metaKey || e.ctrlKey || e.altKey) return

      const { items: rows, selectedId: current, onSelect: select, idOf: id } = stateRef.current
      if (!rows?.length) return

      let delta = 0
      if (e.key === 'ArrowDown' || e.key === 'j') delta = 1
      else if (e.key === 'ArrowUp' || e.key === 'k') delta = -1
      else if (e.key === 'Escape') {
        if (current != null) {
          e.preventDefault()
          select(null)
        }
        return
      } else return

      e.preventDefault()
      const index = rows.findIndex((r) => id(r) === current)
      // Nothing selected yet: ↓ takes the first row and ↑ the last, which is
      // what every list in every mail client does.
      const next =
        index === -1
          ? delta > 0
            ? 0
            : rows.length - 1
          : Math.min(rows.length - 1, Math.max(0, index + delta))
      select(id(rows[next]), rows[next])
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [enabled])
}
