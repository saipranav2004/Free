import { useCallback, useEffect, useRef, useState } from 'react'
import { ChevronRight } from 'lucide-react'
import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Log viewer — the archetype for a dense event stream
// ---------------------------------------------------------------------------
// An audit trail is not a list of comparable rows you filter and sort. It is a
// LOG: thousands of near-identical lines, read by scanning for the one that is
// different, and then read in full. A 25-row table with a drawer is the wrong
// shape for that in two specific ways.
//
//   DENSITY. A compliance table with 44px rows shows about fifteen events on a
//     laptop. Fifteen lines is not enough to see a pattern, and a pattern is
//     what somebody opens an audit log to find. A log line is one row high and
//     monospaced where the content is machine-written, so the eye can use
//     column alignment to skip.
//
//   EXPAND IN PLACE. Opening a drawer costs the operator their position in the
//     stream and covers the neighbouring lines — which are the context that
//     makes the line mean something. "Denied at 04:12" matters because of what
//     happened at 04:11. Expanding inline keeps both.
//
// Keyboard: ↑/↓ or j/k move the cursor, Enter or → expands, ← or Escape
// collapses. Bindings are inert while the caret is in a field.

export function LogViewer({ children, className, 'aria-label': ariaLabel }) {
  return (
    <div
      role="log"
      aria-label={ariaLabel}
      className={clsx(
        'overflow-hidden rounded-lg border border-line bg-surface',
        // The font is set once here rather than on every line, so a nested
        // cell that wants proportional text can simply say so.
        'font-mono text-xs',
        className
      )}
    >
      {children}
    </div>
  )
}

// LogLine is one event: a fixed-width gutter, the line itself, and an expanded
// body underneath when it is open.
export function LogLine({
  time,
  children,
  detail,
  tone = 'default',
  expanded = false,
  onToggle,
  selected = false,
  id,
}) {
  const hasDetail = detail != null
  return (
    <div
      data-log-line={id}
      className={clsx(
        'border-b border-line-soft last:border-b-0',
        selected && 'bg-subtle',
        // Off-screen lines cost nothing to keep in the DOM. Every line stays
        // findable by Ctrl+F and reachable by a screen reader, which is not
        // negotiable in a compliance view — it is the difference between a
        // record and a picture of a record.
        'content-visibility-auto'
      )}
      style={{ contentVisibility: 'auto', containIntrinsicSize: `auto ${expanded ? 200 : 28}px` }}
    >
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={hasDetail ? expanded : undefined}
        className={clsx(
          'flex w-full items-start gap-2 px-3 py-1 text-left leading-5 transition-colors',
          'hover:bg-hover focus-visible:bg-hover focus-visible:outline-none',
          // The tone rail replaces a coloured row. A whole row in red says
          // "something here is wrong" without saying what, and stops the row's
          // own text from being readable against it.
          tone === 'danger' && 'shadow-[inset_3px_0_0_0_rgb(var(--danger))]',
          tone === 'warn' && 'shadow-[inset_3px_0_0_0_rgb(var(--warn))]'
        )}
      >
        <ChevronRight
          className={clsx(
            'mt-0.5 h-3 w-3 flex-none transition-transform duration-150',
            hasDetail ? 'text-tertiary' : 'invisible',
            expanded && 'rotate-90'
          )}
          aria-hidden="true"
        />
        {time && (
          <span className="flex-none tabular text-tertiary" style={{ minWidth: '11.5rem' }}>
            {time}
          </span>
        )}
        <span className="min-w-0 flex-1 truncate">{children}</span>
      </button>

      {expanded && hasDetail && (
        <div className="content-in border-t border-line-soft bg-subtle px-3 py-3 pl-8">{detail}</div>
      )}
    </div>
  )
}

// LogField is one labelled value inside an expanded line. Deliberately a
// two-column grid rather than a definition list per row: an expanded audit
// event has fifteen fields and they have to align, or reading across them is
// the same work as reading unformatted JSON.
export function LogFields({ items }) {
  return (
    <dl className="grid grid-cols-[minmax(7rem,auto)_1fr] gap-x-4 gap-y-1.5">
      {(items || [])
        .filter((f) => f && f.value !== undefined && f.value !== null && f.value !== '')
        .map((f) => (
          <div key={f.label} className="contents">
            <dt className="truncate font-sans text-2xs uppercase tracking-[0.06em] text-tertiary">
              {f.label}
            </dt>
            <dd className={clsx('min-w-0 break-words text-xs text-primary', f.mono && 'font-mono')}>
              {f.value}
            </dd>
          </div>
        ))}
    </dl>
  )
}

// ---------------------------------------------------------------------------
// useLogCursor — keyboard navigation over the stream
// ---------------------------------------------------------------------------
export function useLogCursor({ rows, idOf = (r) => r?.id, enabled = true }) {
  const [cursor, setCursor] = useState(null)
  const [expanded, setExpanded] = useState(null)
  const stateRef = useRef({ rows, idOf, cursor, expanded })
  stateRef.current = { rows, idOf, cursor, expanded }

  const toggle = useCallback((id) => {
    setCursor(id)
    setExpanded((cur) => (cur === id ? null : id))
  }, [])

  useEffect(() => {
    if (!enabled) return undefined
    const onKey = (e) => {
      const el = document.activeElement
      if (
        el &&
        (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)
      )
        return
      if (e.metaKey || e.ctrlKey || e.altKey) return

      const { rows: list, idOf: id, cursor: at, expanded: open } = stateRef.current
      if (!list?.length) return
      const index = list.findIndex((r) => id(r) === at)

      const move = (delta) => {
        e.preventDefault()
        const next = index === -1 ? (delta > 0 ? 0 : list.length - 1) : Math.min(list.length - 1, Math.max(0, index + delta))
        const nextId = id(list[next])
        setCursor(nextId)
        // Scroll the line into view, but only just: `nearest` keeps the
        // surrounding lines where they are, and the surrounding lines are the
        // context that makes the cursor line mean anything.
        document.querySelector(`[data-log-line="${CSS.escape(String(nextId))}"]`)
          ?.scrollIntoView({ block: 'nearest' })
      }

      if (e.key === 'ArrowDown' || e.key === 'j') move(1)
      else if (e.key === 'ArrowUp' || e.key === 'k') move(-1)
      else if (e.key === 'Enter' || e.key === 'ArrowRight') {
        if (at != null) {
          e.preventDefault()
          setExpanded(open === at ? null : at)
        }
      } else if (e.key === 'ArrowLeft' || e.key === 'Escape') {
        if (open != null) {
          e.preventDefault()
          setExpanded(null)
        }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [enabled])

  return { cursor, expanded, setCursor, toggle }
}
