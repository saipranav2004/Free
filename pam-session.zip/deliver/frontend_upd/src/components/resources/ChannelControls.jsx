import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { AlertCircle, Check, Copy, Lock, Radar, Search } from 'lucide-react'
import clsx from 'clsx'
import { getResourceChannels } from '../../api/agent'
import { Button } from '../common/Button'
import { channelBlocker, channelIcon, isUsable, locateCommand, sortChannels, CHANNEL_META } from '../../lib/channels'

// ---------------------------------------------------------------------------
// One control per channel, each telling the truth about itself
// ---------------------------------------------------------------------------
// This replaces a single "Open in Desktop" button that silently stood in for
// whatever happened to be installed. An operator who wanted a terminal and did
// not have one got a GUI, with nothing on screen to say a substitution had
// happened.
//
// Now every channel the resource supports gets its own control, and a control
// that cannot be pressed says which of the two reasons applies:
//
//   policy   an administrator restricted this resource. Nothing to install.
//   tool     this laptop is missing the client. Install it, or point the
//            agent at a copy you already have.
//   pairing  this machine is not paired yet.
//
// Unusable controls are SHOWN, not hidden. A control that vanishes reads as a
// broken product; one that is present and explains itself reads as a decision.

function CopyableCommand({ value }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value)
          setCopied(true)
          setTimeout(() => setCopied(false), 1500)
        } catch {
          /* clipboard unavailable; the text is still selectable on screen */
        }
      }}
      className="mt-1.5 inline-flex max-w-full items-center gap-1.5 rounded border border-surface-700 bg-surface-900 px-2 py-1 text-left font-mono text-2xs text-ink-200 transition-colors hover:border-surface-600"
      title="Copy this command"
    >
      <span className="min-w-0 truncate">{value}</span>
      {copied ? (
        <Check className="h-3 w-3 flex-none text-emerald-500" strokeWidth={2.5} />
      ) : (
        <Copy className="h-3 w-3 flex-none text-ink-500" strokeWidth={1.75} />
      )}
    </button>
  )
}

function BlockedNote({ blocker }) {
  const Icon = blocker.kind === 'policy' ? Lock : blocker.kind === 'tool' ? Search : AlertCircle
  return (
    <div
      className={clsx(
        'mt-1.5 flex items-start gap-2 rounded-lg border px-2.5 py-2',
        blocker.kind === 'policy'
          ? 'border-surface-700 bg-surface-850'
          : 'border-amber-400/40 bg-amber-50/70 dark:bg-amber-950/20'
      )}
    >
      <Icon
        className={clsx(
          'mt-px h-3.5 w-3.5 flex-none',
          blocker.kind === 'policy' ? 'text-ink-500' : 'text-amber-600 dark:text-amber-400'
        )}
        strokeWidth={1.9}
      />
      <div className="min-w-0">
        <p className="text-2xs font-semibold text-ink-200">{blocker.title}</p>
        <p className="mt-0.5 text-2xs leading-relaxed text-ink-500">{blocker.detail}</p>
        {/* For a portable archive — Oracle SQL Developer is the case this
            exists for — "install it" is the wrong advice: the operator already
            has it, somewhere nothing can find. */}
        {blocker.locate && (
          <>
            <p className="mt-1.5 text-2xs leading-relaxed text-ink-500">
              Already have it? Point the agent at it — it opens a file chooser:
            </p>
            <CopyableCommand value={locateCommand(blocker.locate)} />
          </>
        )}
      </div>
    </div>
  )
}

export function ChannelControls({
  resourceId,
  busy = false,
  blockedReason,
  hasCredential = true,
  onOpen,
  pendingChannel = null,
}) {
  const channelsQuery = useQuery({
    queryKey: ['resource', resourceId, 'channels'],
    queryFn: ({ signal }) => getResourceChannels(resourceId, signal),
    enabled: !!resourceId,
    // Capability changes when someone installs something, which is a human
    // timescale — but not so slow that a fresh install should take minutes to
    // show up after "re-check".
    staleTime: 30_000,
  })

  if (channelsQuery.isLoading) {
    return (
      <div className="flex flex-wrap items-center gap-2.5">
        {[0, 1].map((i) => (
          <div key={i} className="h-10 w-40 animate-pulse rounded-lg bg-surface-800" />
        ))}
      </div>
    )
  }

  const channels = sortChannels(channelsQuery.data || [])
  if (channels.length === 0) {
    return (
      <p className="flex items-start gap-2 text-xs leading-relaxed text-ink-500">
        <Radar className="mt-0.5 h-3.5 w-3.5 flex-none" strokeWidth={1.9} />
        No way to open this resource is configured. An administrator can enable one.
      </p>
    )
  }

  // Visual weight goes to the first channel that actually works, so the
  // operator's eye lands on the one they can use — without hiding the others.
  const firstUsable = channels.find(isUsable)?.channel || null

  return (
    <div className="flex flex-col gap-3">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {channels.map((entry) => {
          const meta = CHANNEL_META[entry.channel] || {}
          const Icon = channelIcon(entry.channel)
          const blocker = channelBlocker(entry)
          const usable = isUsable(entry) && hasCredential
          const isPrimary = entry.channel === firstUsable

          return (
            <div key={entry.channel} className="flex min-w-0 flex-col">
              <Button
                variant={isPrimary ? 'primary' : 'secondary'}
                size="lg"
                icon={Icon}
                className="w-full justify-center"
                loading={pendingChannel === entry.channel}
                disabled={busy || !usable}
                title={!hasCredential ? blockedReason : blocker ? blocker.title : meta.note}
                onClick={() => onOpen(entry.channel)}
              >
                {meta.label || entry.channel}
              </Button>

              {usable ? (
                <p className="mt-1.5 text-2xs leading-relaxed text-ink-500">{meta.note}</p>
              ) : (
                blocker && <BlockedNote blocker={blocker} />
              )}
            </div>
          )
        })}
      </div>

      {!firstUsable && (
        <p className="flex items-start gap-2 text-xs leading-relaxed text-ink-400">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-none text-amber-600 dark:text-amber-400" strokeWidth={1.9} />
          There is no way to open this resource from this device right now. Each control above says why.
        </p>
      )}
    </div>
  )
}
