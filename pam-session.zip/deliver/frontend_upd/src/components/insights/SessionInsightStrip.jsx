import { DonutChart } from '../charts/Charts'
import {
  InsightBands,
  InsightCard,
  InsightMeter,
  InsightStrip,
  InsightUnavailable,
} from '../common/InsightStrip'
import { useSessionInsights } from '../../hooks/useInsights'
import { resourceTypeLabel } from '../resources/ResourceCard'
import { formatDuration } from '../../lib/format'

// Three questions the sessions table makes you count rows to answer.
//
// The figures are the SERVER's, not this page's. The listing is capped at the
// most recent 200 rows, so a count taken from the loaded rows silently stops
// being true the moment the cap bites — and a card that quietly disagrees with
// the truth is worse than no card. These come from one query over everything.

const TONES = ['blue', 'ink', 'red', 'blue', 'ink', 'red']

export function SessionInsightStrip() {
  const { data, isLoading, isError } = useSessionInsights()

  if (isError) {
    return <InsightUnavailable message="Session figures are unavailable right now. The list below is unaffected." />
  }

  const byType = data?.by_channel || []
  const segments = byType.map((row, i) => ({
    key: row.label,
    label: resourceTypeLabel(row.label),
    value: row.value,
    tone: TONES[i % TONES.length],
  }))
  const activeNow = data?.active_now || 0
  const breakglass = data?.breakglass_active || 0
  const longest = data?.longest_active_seconds || 0
  const recordedOf = data?.recorded_of || 0
  const recordedPct = data?.recorded_share_pct || 0
  const spread = data?.duration_spread || []
  const spreadTotal = spread.reduce((sum, b) => sum + (b.value || 0), 0)

  return (
    <InsightStrip cols={4}>
      <InsightCard
        label="Active now"
        // No hero of its own when the donut is up: the ring already carries
        // the figure in its centre, and on hover that centre becomes the
        // hovered slice's count. Printing the same number twice, once above
        // the ring and once inside it, is the kind of thing that reads as
        // unfinished.
        value={isLoading || segments.length > 0 ? undefined : (data?.active_now ?? 0)}
        hint={byType.length ? 'by resource type' : undefined}
        loading={isLoading}
        empty={!isLoading && (data?.active_now ?? 0) === 0}
        emptyLabel="No sessions are open."
        visual={
          segments.length > 0 && (
            <DonutChart
              segments={segments}
              size={92}
              centerValue={data?.active_now}
              // One word, because it has to fit inside the ring. The full
              // sentence is the chart's accessible name instead.
              centerLabel="active"
              ariaLabel="Active sessions by resource type"
            />
          )
        }
        footer={longest > 0 && `Longest has been open ${formatDuration(longest)}.`}
      />

      <InsightCard
        label="Under break glass"
        value={isLoading ? undefined : breakglass}
        tone={breakglass > 0 ? 'danger' : 'default'}
        loading={isLoading}
        visual={
          breakglass > 0 && activeNow > 0 ? (
            <InsightMeter
              value={breakglass}
              max={activeNow}
              tone="danger"
              ariaLabel={`${breakglass} of ${activeNow} active sessions are under break glass`}
            />
          ) : undefined
        }
        footer={
          breakglass > 0
            ? `${breakglass} of ${activeNow} open ${activeNow === 1 ? 'session' : 'sessions'}. Each one is a CRITICAL audit event.`
            : 'No emergency access is open.'
        }
      />

      <InsightCard
        label="Recorded this week"
        value={isLoading ? undefined : recordedPct}
        unit="%"
        // Below full coverage is a compliance gap, and the card should look
        // like one rather than like a neutral statistic.
        tone={recordedPct === 100 ? 'ok' : recordedPct >= 80 ? 'warn' : 'danger'}
        loading={isLoading}
        empty={!isLoading && recordedOf === 0}
        emptyLabel="No sessions in the last seven days."
        visual={
          <InsightMeter
            value={recordedPct}
            // Same verdict as the figure above it. An amber number over a red
            // bar is the card disagreeing with itself.
            tone={recordedPct === 100 ? 'default' : recordedPct >= 80 ? 'warn' : 'danger'}
            ariaLabel={`${recordedPct}% of sessions recorded`}
          />
        }
        footer={
          recordedOf > 0 &&
          `${Math.round((recordedPct / 100) * recordedOf)} of ${recordedOf} sessions carry a recording`
        }
      />

      <InsightCard
        label="Session length"
        hint="last 7 days"
        loading={isLoading}
        empty={!isLoading && spreadTotal === 0}
        emptyLabel="No sessions have finished this week."
        // Buckets rather than an average: an average hides the long tail,
        // which is the only part of this distribution anybody investigates.
        visual={<InsightBands bands={spread} />}
      />
    </InsightStrip>
  )
}
