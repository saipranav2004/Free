import {
  InsightBands,
  InsightCard,
  InsightMeter,
  InsightStrip,
  InsightUnavailable,
} from '../common/InsightStrip'
import { useServiceInsights } from '../../hooks/useInsights'

// Machine identity posture: how many can actually work, how wide their reach
// is, and how much notice there is before a token stops.
//
// READY is the figure that did not exist anywhere. The list shows every
// identity as "active", which only means nobody disabled it — an identity with
// a token and no grant authenticates and then reads nothing, and an identity
// with a grant and no token cannot authenticate at all. Both look healthy in a
// list and are broken in production.

const BREADTH_LABEL = {
  exact: 'One path',
  wildcard: 'One level',
  subtree: 'A subtree',
  all: 'Whole vault',
}

export function ServiceInsightStrip() {
  const { data, isLoading, isError } = useServiceInsights()

  if (isError) {
    return <InsightUnavailable message="Service figures are unavailable right now. The list below is unaffected." />
  }

  const identities = data?.identities ?? 0
  const disabled = data?.disabled ?? 0
  const ready = data?.ready_count ?? 0
  const breadth = (data?.scope_breadth || []).map((row) => ({
    label: BREADTH_LABEL[row.label] || row.label,
    value: row.value,
  }))
  const runway = data?.tokens_expiring || []
  const expiringSoon = runway
    .filter((b) => b.label === 'expired' || b.label === '< 7d')
    .reduce((sum, b) => sum + (b.value || 0), 0)
  const vaultWide = data?.vault_wide ?? 0

  return (
    <InsightStrip>
      <InsightCard
        label="Ready to use"
        value={isLoading ? undefined : ready}
        // "/ 4 active", not "/ 4": the table below lists disabled identities
        // too, so a bare denominator reads as disagreeing with its own header.
        unit={identities ? `/ ${identities} active` : undefined}
        tone={identities > 0 && ready < identities ? 'warn' : 'default'}
        loading={isLoading}
        empty={!isLoading && identities === 0}
        emptyLabel="No service identities yet."
        visual={<InsightMeter value={ready} max={identities || 1} ariaLabel={`${ready} of ${identities} ready`} />}
        footer={
          <>
            {identities > ready
              ? `${identities - ready} cannot read anything: no live token, or no live grant.`
              : identities > 0
                ? 'Every active identity has a live token and a live grant.'
                : null}
            {disabled > 0 && (
              <span className="block">
                {disabled} disabled {disabled === 1 ? 'identity is' : 'identities are'} not counted here.
              </span>
            )}
          </>
        }
      />

      <InsightCard
        label="Scope reach"
        hint="live grants"
        loading={isLoading}
        empty={!isLoading && breadth.every((b) => !b.value)}
        emptyLabel="No grants are in force."
        visual={<InsightBands bands={breadth} tone={vaultWide > 0 ? 'danger' : 'default'} />}
        footer={
          vaultWide > 0 &&
          `${vaultWide} ${vaultWide === 1 ? 'grant reaches' : 'grants reach'} the entire vault.`
        }
      />

      <InsightCard
        label="Token runway"
        value={isLoading ? undefined : expiringSoon}
        tone={expiringSoon > 0 ? 'danger' : 'ok'}
        loading={isLoading}
        visual={<InsightBands bands={runway} />}
        footer={
          expiringSoon > 0
            ? 'Already expired or stopping within seven days.'
            : 'Nothing stops within the next seven days.'
        }
      />
    </InsightStrip>
  )
}
