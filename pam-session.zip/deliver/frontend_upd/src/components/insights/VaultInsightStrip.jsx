import {
  InsightCard,
  InsightSpark,
  InsightStrip,
  InsightUnavailable,
} from '../common/InsightStrip'
import { useVaultInsights } from '../../hooks/useInsights'

// What the TABLE CANNOT SAY. That is the whole test for a card here.
//
// This strip used to lead with "Secrets held", broken down by safe — directly
// above a table of safes. The only reason that looked useful was that the
// table's own Credentials column was empty: the endpoint never returned a
// count, so every row read "-" and the card was the only place a number
// appeared. The right fix was the column, not a card compensating for it.
// With the count restored per row, that card became a worse copy of the list
// underneath it, and it is gone.
//
// What remains is what a list of safes genuinely cannot answer: which secrets
// are past their rotation date, how much emergency access exists, and how
// often anyone actually reads from the vault. Each is a fact about the whole
// vault rather than about any one safe, which is exactly what belongs above a
// list rather than in it.
//
// The reveal series is read from the AUDIT TRAIL, not from a counter on the
// credential. The audit log is the record of what happened; a second counter
// would be a second truth to keep in step, and the two would eventually
// disagree in a compliance conversation.

export function VaultInsightStrip() {
  const { data, isLoading, isError } = useVaultInsights()

  if (isError) {
    return <InsightUnavailable message="Vault figures are unavailable right now. The list below is unaffected." />
  }

  const reveals = data?.reveals_by_day || []
  const breakglass = data?.breakglass_count ?? 0
  const revealTotal = reveals.reduce((sum, b) => sum + (b.value || 0), 0)
  const overdue = data?.rotation_overdue || 0

  return (
    <InsightStrip>
      <InsightCard
        label="Break-glass accounts"
        value={isLoading ? undefined : breakglass}
        tone={breakglass > 0 ? 'warn' : 'default'}
        loading={isLoading}
        footer={
          breakglass > 0
            ? 'Using one skips the human approver: a waiting period, a CRITICAL alert, forced recording and an auto-generated report.'
            : 'No emergency accounts are configured.'
        }
      />

      <InsightCard
        label="Rotation overdue"
        value={isLoading ? undefined : overdue}
        tone={overdue > 0 ? 'danger' : 'ok'}
        loading={isLoading}
        footer={
          overdue === 0
            ? 'Every scheduled rotation is current.'
            : 'Past their next scheduled rotation.'
        }
      />

      <InsightCard
        label="Secrets read"
        value={isLoading ? undefined : revealTotal}
        hint="last 30 days"
        loading={isLoading}
        empty={!isLoading && revealTotal === 0}
        emptyLabel="Nothing has been read from the vault this month."
        visual={<InsightSpark points={reveals} ariaLabel="Secret reads per day over 30 days" />}
        footer={revealTotal > 0 && 'One column per day, oldest on the left.'}
      />
    </InsightStrip>
  )
}
