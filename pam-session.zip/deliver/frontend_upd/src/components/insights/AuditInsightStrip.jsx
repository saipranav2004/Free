import {
  InsightBands,
  InsightCard,
  InsightMeter,
  InsightSpark,
  InsightStrip,
  InsightUnavailable,
} from '../common/InsightStrip'
import { useAuditInsights } from '../../hooks/useInsights'

// The questions the audit table makes you build a filter to answer.
//
// Scoped SERVER-SIDE by role: an operator's figures count only their own
// trail. That is not a display choice — an aggregate is still a disclosure,
// and "who are the busiest actors in the organisation" is exactly the question
// a non-admin must not get an answer to. It is easier to leak here than in the
// table underneath, because no row is ever rendered and nothing looks wrong.

export function AuditInsightStrip({ days = 30, windowLabel }) {
  const { data, isLoading, isError } = useAuditInsights(days)
  // The hint repeats the words from the filter bar rather than restating the
  // day count, so the cards and the control that set them read as one thing.
  const hint = windowLabel || `last ${days} days`

  if (isError) {
    return <InsightUnavailable message="Audit figures are unavailable right now. The log below is unaffected." />
  }

  const byDay = data?.events_by_day || []
  const actors = data?.top_actors || []
  const denied = data?.denied_rate_pct || 0
  const total = data?.total_events || 0

  return (
    <InsightStrip>
      <InsightCard
        label="Events"
        value={isLoading ? undefined : total.toLocaleString()}
        hint={hint}
        loading={isLoading}
        empty={!isLoading && total === 0}
        emptyLabel="Nothing recorded in this window."
        visual={<InsightSpark points={byDay} ariaLabel={`Audit events per day over ${days} days`} />}
      />

      <InsightCard
        label="Refused"
        value={isLoading ? undefined : denied}
        unit="%"
        // A refusal rate is not automatically bad — a working policy refuses
        // things. It is worth LOOKING at, which is why this warns rather than
        // alarms until it is high enough to mean something is misconfigured.
        tone={denied === 0 ? 'default' : denied < 10 ? 'warn' : 'danger'}
        loading={isLoading}
        visual={<InsightMeter value={denied} tone="danger" ariaLabel={`${denied}% of events refused`} />}
        footer={
          total > 0 &&
          `${Math.round((denied / 100) * total).toLocaleString()} of ${total.toLocaleString()} events were denied`
        }
      />

      <InsightCard
        label="Busiest actors"
        hint={hint}
        loading={isLoading}
        empty={!isLoading && actors.length === 0}
        emptyLabel="No activity in this window."
        visual={<InsightBands bands={actors.slice(0, 4)} />}
      />
    </InsightStrip>
  )
}
