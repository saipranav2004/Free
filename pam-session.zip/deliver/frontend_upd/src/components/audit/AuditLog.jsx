import { LogFields, LogLine, LogViewer, useLogCursor } from '../ui/logviewer'
import { Meta, StatusDot } from '../ui/bits'
import { NoMatchState } from '../ui/states'
import { formatDateTime } from '../../lib/format'
import { eventTime, eventActor, eventTarget, eventIp, isFailure } from './auditFields'

// ---------------------------------------------------------------------------
// The audit trail as a LOG rather than a table
// ---------------------------------------------------------------------------
// Same rows, same data, different archetype — and the archetype is the point.
// A table asks "which of these rows do I want", which is a question you ask of
// a catalogue. A log asks "what happened, and what happened around it", which
// is the question somebody actually opens an audit trail with.
//
// Two consequences follow, and both are why this is not the table with smaller
// padding:
//
//   ONE LINE PER EVENT, monospaced, columns aligned by fixed width. Roughly
//   three times as many events on a laptop screen. The extra lines are not
//   nicety: a burst of refusals at 04:12 is invisible when fifteen rows fit
//   and obvious when forty-five do.
//
//   EXPANSION IN PLACE. The neighbouring lines are the context that makes a
//   line mean something — "denied" matters because of what came before it. A
//   drawer covers exactly that context and loses your position in the stream.
//
// The table is still available, because "which of these do I want" is a real
// question too, and the two shapes answer different ones.

const OUTCOME_TONE = {
  SUCCESS: 'ok',
  ALLOWED: 'ok',
  PENDING: 'warn',
  DENIED: 'danger',
  ERROR: 'danger',
  FAILURE: 'danger',
}

function lineTone(e) {
  const outcome = String(e?.outcome || '').toUpperCase()
  if (OUTCOME_TONE[outcome] === 'danger') return 'danger'
  if (String(e?.severity || '').toUpperCase() === 'CRITICAL') return 'danger'
  if (OUTCOME_TONE[outcome] === 'warn') return 'warn'
  return 'default'
}

function detailFields(e) {
  return [
    { label: 'Event', value: e?.id, mono: true },
    { label: 'Sequence', value: e?.sequence_number, mono: true },
    { label: 'Action', value: e?.action, mono: true },
    { label: 'Category', value: e?.category },
    { label: 'Outcome', value: e?.outcome },
    { label: 'Severity', value: e?.severity },
    { label: 'Actor', value: eventActor(e) },
    { label: 'Actor type', value: e?.actor_type },
    { label: 'Email', value: e?.email },
    { label: 'Target', value: eventTarget(e), mono: true },
    { label: 'Resource type', value: e?.resource_type },
    { label: 'Source IP', value: eventIp(e), mono: true },
    { label: 'User agent', value: e?.user_agent },
    { label: 'Request', value: e?.request_id, mono: true },
    { label: 'Session', value: e?.session_id, mono: true },
    { label: 'Grant', value: e?.grant_id, mono: true },
    { label: 'Justification', value: e?.justification },
    { label: 'Details', value: e?.details },
    // The chain stamp is the reason this log is evidence rather than a list.
    // It belongs in the expanded event where an auditor can read it, not in a
    // separate verification screen they have to be told about.
    { label: 'Entry hash', value: e?.entry_hash, mono: true },
    { label: 'Previous hash', value: e?.prev_hash, mono: true },
  ]
}

export function AuditLog({
  rows,
  loading,
  emptyTitle = 'No audit entries',
  emptyMessage = 'Nothing matches these filters.',
  onClearFilters,
  showActor = true,
}) {
  const idOf = (e) => e?.id ?? e?.sequence_number
  const { cursor, expanded, toggle } = useLogCursor({ rows, idOf, enabled: !loading })

  if (loading) {
    return (
      <div className="overflow-hidden rounded-lg border border-line bg-surface">
        {Array.from({ length: 14 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 border-b border-line-soft px-3 py-1.5 last:border-b-0">
            <span className="h-3 w-40 animate-pulse rounded bg-subtle" />
            <span className="h-3 w-56 animate-pulse rounded bg-subtle" />
            <span className="h-3 w-24 animate-pulse rounded bg-subtle" />
          </div>
        ))}
      </div>
    )
  }

  if (!rows || rows.length === 0) {
    return <NoMatchState title={emptyTitle} description={emptyMessage} onClear={onClearFilters} />
  }

  return (
    <LogViewer aria-label="Audit events">
      {rows.map((e) => {
        const id = idOf(e)
        const outcome = String(e?.outcome || '').toUpperCase()
        return (
          <LogLine
            key={id}
            id={id}
            time={formatDateTime(eventTime(e))}
            tone={lineTone(e)}
            expanded={expanded === id}
            selected={cursor === id}
            onToggle={() => toggle(id)}
            detail={<LogFields items={detailFields(e)} />}
          >
            <span className="flex min-w-0 items-center gap-2">
              <Meta className="flex-none">{e?.category || 'OTHER'}</Meta>
              <span className="min-w-0 flex-none truncate" style={{ maxWidth: '22rem' }}>
                {e?.action || '-'}
              </span>
              {showActor && (
                <span className="min-w-0 flex-none truncate text-tertiary" style={{ maxWidth: '10rem' }}>
                  {eventActor(e)}
                </span>
              )}
              <span className="min-w-0 flex-1 truncate text-tertiary">{eventTarget(e)}</span>
              {/* Only a non-ordinary outcome earns a mark. Fifty green dots in
                  a column is a decoration, not information — the eye stops
                  reading it by the second screen. */}
              {isFailure(e) ? (
                <StatusDot tone={OUTCOME_TONE[outcome] || 'warn'} label={outcome || 'UNKNOWN'} />
              ) : (
                <span className="flex-none text-tertiary">{eventIp(e)}</span>
              )}
            </span>
          </LogLine>
        )
      })}
    </LogViewer>
  )
}
