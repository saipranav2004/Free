import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Folder, KeyRound, Vault as VaultIcon, Zap } from 'lucide-react'
import { flattenTree, TreeBrowser, TreeNode, useTreeKeyboard } from '../ui/treebrowser'
import { SplitDetail, SplitPlaceholder, SplitView } from '../ui/splitview'
import { Badge } from '../common/Badge'
import { Spinner } from '../common/Spinner'
import { useVaultSecretIndex } from '../../hooks/useVaultSecretIndex'

// ---------------------------------------------------------------------------
// The vault as what it actually is: a hierarchy
// ---------------------------------------------------------------------------
// safe → folder → secret was shipped as three pages of table, one per level.
// That loses the only thing a hierarchy is for — seeing where you are in it.
// Every step down was a full navigation, every step sideways was two, and
// nothing on screen ever showed the shape.
//
// ONE REQUEST, not one per node. The whole index comes from the path endpoint
// the grant form already uses (services.ListSecretPaths, a single join), so
// the tree is built in the browser from data that is already resolved.
// Lazy-loading each level would be the obvious design and the wrong one here:
// it would reintroduce exactly the per-node fan-out that endpoint was written
// to remove, and a vault is small enough that the whole shape fits in one
// response.
//
// THE PATH IS THE POINT. `prod-db/replicas/pg-reader` is how a service
// identity's grant addresses this secret. An administrator writing a scope was
// typing a glob against an address space they could not see; this is that
// address space, drawn.

function buildTree(secrets) {
  const safes = new Map()
  for (const s of secrets) {
    if (!safes.has(s.safeId)) {
      safes.set(s.safeId, { id: `safe:${s.safeId}`, label: s.safeName, kind: 'safe', children: new Map(), count: 0 })
    }
    const safe = safes.get(s.safeId)
    safe.count++

    // A folder path is slash-separated and may be several levels deep. Nested
    // rather than flattened, because "replicas/eu-west" under one safe is two
    // levels of meaning and showing it as one label loses the grouping that
    // makes a glob like `prod-db/replicas/*` legible.
    const segments = (s.folderPath || '').split('/').filter(Boolean)
    let level = safe
    let prefix = `safe:${s.safeId}`
    for (const segment of segments) {
      prefix += `/${segment}`
      if (!level.children.has(segment)) {
        level.children.set(segment, { id: prefix, label: segment, kind: 'folder', children: new Map(), count: 0 })
      }
      level = level.children.get(segment)
      level.count++
    }
    level.children.set(`secret:${s.id}`, {
      id: `secret:${s.id}`,
      label: s.name,
      kind: 'secret',
      secret: s,
      children: new Map(),
    })
  }

  const toNodes = (map) =>
    [...map.values()]
      .sort((a, b) => {
        // Folders before secrets, then alphabetical. A mixed alphabetical
        // order buries the folders among the leaves and makes the shape
        // unreadable, which is the whole reason for a tree.
        if (a.kind !== b.kind) return a.kind === 'secret' ? 1 : -1
        return a.label.localeCompare(b.label)
      })
      .map((n) => ({ ...n, hasChildren: n.children.size > 0, children: toNodes(n.children) }))

  return toNodes(safes)
}

const NODE_ICON = { safe: VaultIcon, folder: Folder, secret: KeyRound }

export function VaultTree() {
  const { secrets, isLoading, isError } = useVaultSecretIndex(true)
  const [expanded, setExpanded] = useState(() => new Set())
  const [focusedId, setFocusedId] = useState(null)
  const [selectedId, setSelectedId] = useState(null)

  const tree = useMemo(() => buildTree(secrets || []), [secrets])
  const visible = useMemo(() => flattenTree(tree, expanded), [tree, expanded])
  const byId = useMemo(() => new Map(visible.map((n) => [n.id, n])), [visible])
  const selected = selectedId ? byId.get(selectedId) : null

  const toggle = (id) =>
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  useTreeKeyboard({
    visible,
    focusedId,
    setFocusedId,
    onToggle: toggle,
    onSelect: setSelectedId,
    expandedIds: expanded,
    enabled: !isLoading,
  })

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 px-4 py-10 text-sm text-tertiary">
        <Spinner size="h-4 w-4" /> Reading the vault&apos;s shape…
      </div>
    )
  }
  if (isError) {
    return (
      <p className="px-4 py-8 text-sm text-tertiary">
        The vault index is unavailable right now. The safe list is unaffected.
      </p>
    )
  }
  if (!secrets?.length) {
    return <p className="px-4 py-8 text-sm text-tertiary">The vault holds no secrets yet.</p>
  }

  const renderNodes = (nodes, level = 1) =>
    nodes.map((n) => {
      const Icon = NODE_ICON[n.kind]
      return (
        <TreeNode
          key={n.id}
          id={n.id}
          label={n.label}
          icon={Icon}
          level={level}
          hasChildren={n.hasChildren}
          expanded={expanded.has(n.id)}
          selected={selectedId === n.id}
          focused={focusedId === n.id}
          onToggle={toggle}
          onSelect={(id) => {
            setSelectedId(id)
            setFocusedId(id)
          }}
          meta={
            n.kind === 'secret'
              ? n.secret?.isBreakglass
                ? undefined
                : undefined
              : `${n.count}`
          }
        >
          {n.hasChildren && renderNodes(n.children, level + 1)}
        </TreeNode>
      )
    })

  return (
    <SplitView
      selected={selected}
      onClose={() => setSelectedId(null)}
      listWidth={26}
      list={
        <div className="max-h-[36rem] overflow-y-auto px-2 py-2">
          <TreeBrowser aria-label="Vault contents">{renderNodes(tree)}</TreeBrowser>
        </div>
      }
      detail={selected && <NodeDetail node={selected} />}
      placeholder={
        <SplitPlaceholder
          icon={VaultIcon}
          title="Pick a safe, folder or secret"
          description="Arrow keys move, → opens, ← closes and steps out. Every secret shows the canonical path a service identity's grant would address it by."
        />
      }
    />
  )
}

function NodeDetail({ node }) {
  if (node.kind !== 'secret') {
    return (
      <SplitDetail
        icon={node.kind === 'safe' ? VaultIcon : Folder}
        title={node.label}
        subtitle={node.kind === 'safe' ? 'Safe' : 'Folder'}
      >
        <p className="text-sm text-secondary">
          {node.count} {node.count === 1 ? 'secret' : 'secrets'} beneath this {node.kind}.
        </p>
        <p className="mt-3 text-2xs leading-relaxed text-tertiary">
          A grant scope of{' '}
          <code className="rounded bg-subtle px-1 py-0.5 font-mono text-2xs text-primary">
            {node.kind === 'safe' ? `${node.label}/**` : `…/${node.label}/**`}
          </code>{' '}
          reaches all of them. One of{' '}
          <code className="rounded bg-subtle px-1 py-0.5 font-mono text-2xs text-primary">
            {node.kind === 'safe' ? `${node.label}/*` : `…/${node.label}/*`}
          </code>{' '}
          reaches only this level, not the folders under it.
        </p>
      </SplitDetail>
    )
  }

  const s = node.secret
  return (
    <SplitDetail
      icon={s.isBreakglass ? Zap : KeyRound}
      title={s.name}
      subtitle={s.accountName || s.credentialType}
      actions={
        s.safeId && s.id ? (
          <Link
            to={`/vault/${s.safeId}/credentials/${s.id}`}
            className="flex-none rounded px-2 py-1 text-2xs font-medium text-accent hover:underline"
          >
            Open
          </Link>
        ) : null
      }
    >
      <dl className="grid grid-cols-[minmax(6rem,auto)_1fr] gap-x-4 gap-y-2">
        <dt className="text-2xs uppercase tracking-[0.06em] text-tertiary">Path</dt>
        <dd className="min-w-0 break-all font-mono text-xs text-primary">{s.path}</dd>
        <dt className="text-2xs uppercase tracking-[0.06em] text-tertiary">Safe</dt>
        <dd className="text-xs text-primary">{s.safeName}</dd>
        {s.folderPath && (
          <>
            <dt className="text-2xs uppercase tracking-[0.06em] text-tertiary">Folder</dt>
            <dd className="font-mono text-xs text-primary">{s.folderPath}</dd>
          </>
        )}
        <dt className="text-2xs uppercase tracking-[0.06em] text-tertiary">Account</dt>
        <dd className="text-xs text-primary">{s.accountName || '—'}</dd>
        <dt className="text-2xs uppercase tracking-[0.06em] text-tertiary">Type</dt>
        <dd className="text-xs text-primary">{s.credentialType || '—'}</dd>
      </dl>
      {s.isBreakglass && (
        <div className="mt-4">
          <Badge tone="danger">Break glass</Badge>
          <p className="mt-2 text-2xs leading-relaxed text-tertiary">
            Using this skips the human approver, and incurs a waiting period, a CRITICAL alert, forced
            session recording and an auto-generated report.
          </p>
        </div>
      )}
      {/* The path is the reason this view exists: it is the address a machine
          principal's grant is written against, and nothing else in the console
          showed it. */}
      <p className="mt-4 border-t border-line pt-3 text-2xs leading-relaxed text-tertiary">
        This is the canonical path the machine data plane reads by. A service identity needs a grant whose
        scope matches it.
      </p>
    </SplitDetail>
  )
}
