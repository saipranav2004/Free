import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { AlertTriangle, Eye, EyeOff, KeyRound, ShieldAlert, Terminal } from 'lucide-react'
import clsx from 'clsx'
import { issueServiceToken } from '../../api/serviceIdentity'
import { Modal } from '../common/Modal'
import { Field, FieldSet, inputClass } from '../common/FormFields'
import { Button } from '../common/Button'
import { CopyButton } from '../common/CopyButton'
import { SegmentedControl } from '../common/SegmentedControl'
import { apiErrorMessage, normalizeApiError } from '../../lib/apiError'
import { formatDateTime } from '../../lib/format'

// ---------------------------------------------------------------------------
// Mint a service token
// ---------------------------------------------------------------------------
// The response to this call carries the only copy of the secret that will ever
// exist — nothing on the server can return it again. That single fact drives
// every decision in this component:
//
//   * The dialog does NOT close on success. It swaps into a hand-off view, and
//     the only way out is a button that says the token has been stored.
//   * The secret is masked until asked for, so it does not sit on a projector
//     or in a screen share by default.
//   * It is offered as the three things an operator is actually about to do
//     with it — an environment variable, a curl call, a Kubernetes secret —
//     because the failure mode here is a token pasted into the wrong shape and
//     then re-minted, which leaves a live credential nobody is tracking.
//   * Rotation is explained where it matters: the previous token stays valid
//     until revoked, which is what makes a rolling deploy possible instead of
//     an outage.

const TTL_PRESETS = [
  { key: '30', label: '30 days' },
  { key: '90', label: '90 days' },
  { key: '365', label: '1 year' },
]

function snippets(token, serviceName) {
  const apiBase = `${window.location.origin}/api/v1/pam/svc`
  return {
    env: `# ${serviceName} — service token for the PAM vault data plane
PAM_SERVICE_TOKEN=${token}
PAM_VAULT_URL=${apiBase}`,
    curl: `curl -sS "${apiBase}/secrets/<safe>/<secret>?purpose=why+you+need+it" \\
  -H "X-Service-Token: ${token}"`,
    k8s: `kubectl create secret generic pam-service-token \\
  --from-literal=token='${token}'`,
  }
}

export function IssueServiceTokenModal({ open, onClose, identity }) {
  const queryClient = useQueryClient()
  const serviceName = identity?.name

  const [description, setDescription] = useState('')
  const [ttlDays, setTtlDays] = useState('90')
  const [issued, setIssued] = useState(null)
  const [revealed, setRevealed] = useState(false)
  const [shape, setShape] = useState('env')
  const [stored, setStored] = useState(false)

  useEffect(() => {
    if (!open) return
    setDescription('')
    setTtlDays('90')
    setIssued(null)
    setRevealed(false)
    setShape('env')
    setStored(false)
  }, [open])

  const mutation = useMutation({
    mutationFn: () =>
      issueServiceToken(serviceName, {
        description: description.trim() || undefined,
        ttl_days: Number(ttlDays) > 0 ? Number(ttlDays) : 90,
      }),
    onSuccess: (data) => {
      setIssued(data)
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-tokens', serviceName] })
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-identities'] })
    },
    onError: (err) => {
      const e = normalizeApiError(err)
      // Minting is behind RequireMFA. A 403 here means step up, not "denied".
      toast.error(
        e.status === 403
          ? 'Minting a service token needs a fresh MFA verification. Sign in again with your authenticator, then retry.'
          : apiErrorMessage(err)
      )
    },
  })

  const token = issued?.token || ''
  const code = useMemo(() => (token ? snippets(token, serviceName || 'service') : null), [token, serviceName])

  // Closing the hand-off view is deliberately gated: the operator has to say
  // they stored it. There is no second chance, and a stray Escape key should
  // not be the thing that costs them one.
  const finish = () => {
    if (!stored) {
      toast.error('Copy the token first — it cannot be shown again.')
      return
    }
    toast.success('Token stored', {
      description: 'The previous token, if any, is still valid until you revoke it.',
    })
    onClose()
  }

  if (issued) {
    return (
      <Modal
        open={open}
        onClose={finish}
        icon={ShieldAlert}
        tone="warning"
        title="Copy this token now"
        description="This is the only time it will ever be shown. Nothing on the server can return it again."
        size="lg"
        closeOnBackdrop={false}
        footer={
          <>
            <label className="mr-auto flex cursor-pointer items-center gap-2 text-xs font-medium text-ink-300">
              <input
                type="checkbox"
                checked={stored}
                onChange={(e) => setStored(e.target.checked)}
                className="h-3.5 w-3.5 rounded border-surface-600 accent-blue-600"
              />
              I have stored this token
            </label>
            <Button variant="primary" onClick={finish} disabled={!stored}>
              Done
            </Button>
          </>
        }
      >
        <div className="space-y-5">
          <div className="overflow-hidden rounded-xl border border-amber-500/40 bg-amber-50/70 dark:bg-amber-950/20">
            <div className="flex items-center gap-2 border-b border-amber-500/30 px-3 py-2">
              <KeyRound className="h-3.5 w-3.5 flex-none text-amber-700 dark:text-amber-300" strokeWidth={1.75} />
              <span className="flex-1 text-xs font-semibold text-amber-800 dark:text-amber-200">
                Service token
              </span>
              <button
                type="button"
                onClick={() => setRevealed((v) => !v)}
                className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-2xs font-semibold text-amber-800 transition-colors hover:bg-amber-500/15 dark:text-amber-200"
              >
                {revealed ? (
                  <>
                    <EyeOff className="h-3 w-3" strokeWidth={2} /> Hide
                  </>
                ) : (
                  <>
                    <Eye className="h-3 w-3" strokeWidth={2} /> Reveal
                  </>
                )}
              </button>
              <CopyButton value={token} label="Copy token" />
            </div>
            <p className="break-all px-3 py-3 font-mono text-xs leading-relaxed text-ink-100">
              {revealed ? token : `${token.slice(0, 15)}${'•'.repeat(Math.max(token.length - 15, 12))}`}
            </p>
          </div>

          <dl className="grid gap-x-4 gap-y-2 text-xs sm:grid-cols-2">
            <div>
              <dt className="text-2xs uppercase tracking-[0.07em] text-ink-500">Token ID</dt>
              <dd className="mt-0.5 break-all font-mono text-ink-200">{issued.token_id}</dd>
            </div>
            <div>
              <dt className="text-2xs uppercase tracking-[0.07em] text-ink-500">Expires</dt>
              <dd className="mt-0.5 text-ink-200">
                {issued.expires_at ? formatDateTime(issued.expires_at) : 'never'}
              </dd>
            </div>
          </dl>

          <section>
            <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-2">
              <h3 className="flex-none text-xs font-semibold text-ink-300">Ready to paste</h3>
              <SegmentedControl
                size="sm"
                ariaLabel="Snippet format"
                value={shape}
                onChange={setShape}
                options={[
                  { key: 'env', label: '.env' },
                  { key: 'curl', label: 'curl' },
                  { key: 'k8s', label: 'kubectl' },
                ]}
              />
              <span className="ml-auto flex-none">
                <CopyButton value={code[shape]} label="Copy snippet" />
              </span>
            </div>
            <pre className="overflow-x-auto rounded-lg border border-surface-700 bg-surface-900 px-3 py-2.5 font-mono text-2xs leading-relaxed text-ink-200">
              {code[shape]}
            </pre>
          </section>

          <p className="flex items-start gap-2 rounded-lg border border-surface-700 bg-surface-850 px-3 py-2.5 text-2xs leading-relaxed text-ink-400">
            <AlertTriangle className="mt-px h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
            <span>
              The token authenticates, it does not authorise. On its own it can read nothing — what it
              reaches is whatever scopes this identity has been granted.
            </span>
          </p>
        </div>
      </Modal>
    )
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      icon={KeyRound}
      title={`Mint a token for ${serviceName || 'this service'}`}
      description="The application presents this token to read secrets. It is shown once, on the next screen."
      size="md"
      busy={mutation.isPending}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            form="issue-token-form"
            type="submit"
            variant="primary"
            icon={KeyRound}
            loading={mutation.isPending}
          >
            Mint token
          </Button>
        </>
      }
    >
      <form
        id="issue-token-form"
        noValidate
        className="space-y-5"
        onSubmit={(e) => {
          e.preventDefault()
          mutation.mutate()
        }}
      >
        <FieldSet title="Lifetime">
          <Field
            label="Valid for"
            hint="A machine credential that never expires is a permanent liability. Shorter is safer; rotation is a rolling deploy, not an outage."
            htmlFor="it-ttl"
          >
            <div className="flex flex-wrap items-center gap-2">
              <SegmentedControl
                ariaLabel="Token lifetime"
                value={TTL_PRESETS.some((p) => p.key === ttlDays) ? ttlDays : ''}
                onChange={setTtlDays}
                options={TTL_PRESETS}
              />
              <input
                id="it-ttl"
                type="number"
                min="1"
                inputMode="numeric"
                className={clsx(inputClass(false), 'w-28 tabular-nums')}
                value={ttlDays}
                onChange={(e) => setTtlDays(e.target.value)}
              />
              <span className="text-xs text-ink-500">days</span>
            </div>
          </Field>

          <Field
            label="Label"
            hint="Which deployment this token is for. It is how you tell two live tokens apart when you revoke one."
            htmlFor="it-desc"
          >
            <input
              id="it-desc"
              autoComplete="off"
              placeholder="billing-api, eu-west-1, blue deployment"
              className={inputClass(false)}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </Field>
        </FieldSet>

        <p className="flex items-start gap-2 rounded-lg border border-surface-700 bg-surface-850 px-3 py-2.5 text-2xs leading-relaxed text-ink-400">
          <Terminal className="mt-px h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
          <span>
            Minting does not invalidate the current token. Roll the new one out, confirm the service is
            healthy, then revoke the old one — that overlap is the whole point.
          </span>
        </p>
      </form>
    </Modal>
  )
}
