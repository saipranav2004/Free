import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  AlertTriangle,
  Check,
  KeyRound,
  Radar,
  ShieldCheck,
  Timer,
  Vault,
} from 'lucide-react'
import clsx from 'clsx'
import { grantServiceScope } from '../../api/serviceIdentity'
import { useVaultSecretIndex } from '../../hooks/useVaultSecretIndex'
import {
  canonicalSecretPath,
  isValidScope,
  matchingPaths,
  scopeBreadth,
} from '../../lib/secretScope'
import { Modal } from '../common/Modal'
import { Field, FieldSet, inputClass } from '../common/FormFields'
import { Button } from '../common/Button'
import { apiErrorMessage, normalizeApiError } from '../../lib/apiError'

// ---------------------------------------------------------------------------
// Grant a secret scope to a service identity
// ---------------------------------------------------------------------------
// This is the form that decides what a machine can read, and the thing that
// makes it dangerous is that a scope is a GLOB: the difference between
// `prod-db/*` and `prod-db/**` is one character and a whole subtree, and
// neither tells you what it reaches until something in production either
// works or 403s.
//
// So the form is built around a live preview. Pick a safe, pick a folder, pick
// a secret or a wildcard, and the exact paths the scope matches right now are
// listed underneath, counted, with the `**` cases called out as also covering
// secrets that do not exist yet. The preview is computed by lib/secretScope,
// a line-for-line port of the server's matcher verified against it over
// ~316k (scope, path) pairs — but the server is still the authority, and the
// copy never implies otherwise.
//
// The scope can also be typed directly. An administrator who knows the
// dialect should not have to click through three selects, and a scope pasted
// from a ticket should go in as-is.

const MAX_PREVIEW = 12
const ANY_ONE = '*'
const ANY_SUBTREE = '**'

function breadthNotice(scope) {
  const breadth = scopeBreadth(scope)
  if (breadth === 'all') {
    return {
      tone: 'danger',
      title: 'This grants every secret in the vault',
      body: 'Including safes and credentials created after today. A machine identity almost never needs this — scope it to the safe it actually reads.',
    }
  }
  if (breadth === 'subtree') {
    return {
      tone: 'warn',
      title: 'This grants a whole subtree',
      body: 'Anything added under this path later is in scope automatically, with no second review.',
    }
  }
  if (breadth === 'wildcard') {
    return {
      tone: 'warn',
      title: 'This is a wildcard, not one secret',
      body: 'It covers matching secrets added under this path later, too.',
    }
  }
  return null
}

function PreviewRow({ secret }) {
  return (
    <li className="flex items-center gap-2 px-3 py-1.5">
      <Check className="h-3 w-3 flex-none text-emerald-600 dark:text-emerald-400" strokeWidth={2.5} />
      <span className="min-w-0 flex-1 break-all font-mono text-xs text-ink-200">{secret.path}</span>
      {secret.isBreakglass && (
        <span className="flex-none rounded border border-amber-300/70 bg-amber-50 px-1.5 py-px text-2xs font-semibold text-amber-700 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-300">
          break glass
        </span>
      )}
      <span className="flex-none text-2xs text-ink-500">{secret.accountName}</span>
    </li>
  )
}

export function GrantSecretScopeModal({ open, onClose, identity }) {
  const queryClient = useQueryClient()
  const serviceName = identity?.name

  const [safeName, setSafeName] = useState('')
  const [folderPath, setFolderPath] = useState('')
  const [leaf, setLeaf] = useState(ANY_ONE)
  const [scope, setScope] = useState('')
  const [typedScope, setTypedScope] = useState(false)
  const [reason, setReason] = useState('')
  const [maxTtl, setMaxTtl] = useState('300')
  const [expiresInDays, setExpiresInDays] = useState('')
  const [acknowledged, setAcknowledged] = useState(false)

  const { secrets, safes, isLoading, isPartial } = useVaultSecretIndex(open)

  useEffect(() => {
    if (!open) return
    setSafeName('')
    setFolderPath('')
    setLeaf(ANY_ONE)
    setScope('')
    setTypedScope(false)
    setReason('')
    setMaxTtl('300')
    setExpiresInDays('')
    setAcknowledged(false)
  }, [open])

  // Folders and leaves are derived from the real vault, so the builder can
  // only compose a path the address space actually has.
  const foldersInSafe = useMemo(() => {
    const set = new Set()
    for (const s of secrets) if (s.safeName === safeName && s.folderPath) set.add(s.folderPath)
    return [...set].sort()
  }, [secrets, safeName])

  const leavesInScope = useMemo(
    () =>
      secrets
        .filter((s) => s.safeName === safeName && (s.folderPath || '') === folderPath)
        .map((s) => s.name)
        .sort(),
    [secrets, safeName, folderPath]
  )

  // The builder writes into the same `scope` field the operator can type in.
  // Once they have typed, the builder stops overwriting them — having a select
  // silently rewrite a hand-entered pattern is the worse of the two surprises.
  const builtScope = useMemo(() => {
    if (!safeName) return ''
    if (leaf === ANY_SUBTREE) return `${canonicalSecretPath(safeName, folderPath, '')}/${ANY_SUBTREE}`
    return canonicalSecretPath(safeName, folderPath, leaf || ANY_ONE)
  }, [safeName, folderPath, leaf])

  useEffect(() => {
    if (typedScope) return
    setScope(builtScope)
  }, [builtScope, typedScope])

  const trimmedScope = scope.trim()
  const valid = isValidScope(trimmedScope)
  const matches = useMemo(
    () => (valid ? matchingPaths(trimmedScope, secrets.map((s) => s.path)) : []),
    [valid, trimmedScope, secrets]
  )
  const matchedSecrets = useMemo(() => {
    const set = new Set(matches)
    return secrets.filter((s) => set.has(s.path))
  }, [matches, secrets])

  const notice = trimmedScope && valid ? breadthNotice(trimmedScope) : null
  const needsAck = !!notice && notice.tone === 'danger'

  const mutation = useMutation({
    mutationFn: () =>
      grantServiceScope(serviceName, {
        scope: trimmedScope,
        reason: reason.trim(),
        max_ttl_seconds: Number(maxTtl) > 0 ? Number(maxTtl) : 0,
        expires_in_days: Number(expiresInDays) > 0 ? Number(expiresInDays) : 0,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-grants', serviceName] })
      toast.success(`${serviceName} can now read ${trimmedScope}`, {
        description:
          matchedSecrets.length === 0
            ? 'No secret matches it today. It will apply to anything created under it.'
            : `${matchedSecrets.length} secret${matchedSecrets.length === 1 ? '' : 's'} in scope right now.`,
      })
      onClose()
    },
    onError: (err) => {
      const e = normalizeApiError(err)
      // Granting is behind RequireMFA, so a 403 here is far more likely to be
      // "step up" than "you are not allowed" — saying the wrong one sends an
      // administrator to look for a permission they already have.
      toast.error(
        e.status === 403
          ? 'Granting a secret scope needs a fresh MFA verification. Sign in again with your authenticator, then retry.'
          : apiErrorMessage(err)
      )
    },
  })

  const blocked = !valid || !reason.trim() || (needsAck && !acknowledged)

  const submit = (e) => {
    e.preventDefault()
    if (!valid) {
      toast.error('That scope is not a pattern the server can parse.')
      return
    }
    if (!reason.trim()) {
      toast.error('A reason is required — it is what the audit record carries.')
      return
    }
    mutation.mutate()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      icon={KeyRound}
      title={`Grant a secret scope to ${serviceName || 'this service'}`}
      description="A scope is a pattern over secret paths. Everything it matches, this service can read with its token — and nothing else."
      size="xl"
      busy={mutation.isPending}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={mutation.isPending}>
            Cancel
          </Button>
          <Button
            form="grant-scope-form"
            type="submit"
            variant="primary"
            icon={ShieldCheck}
            loading={mutation.isPending}
            disabled={blocked}
          >
            Grant scope
          </Button>
        </>
      }
    >
      <form id="grant-scope-form" onSubmit={submit} noValidate className="space-y-6">
        <FieldSet
          title="What it can read"
          description="Build the path from the vault, or type the pattern directly if you already know it."
        >
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Safe" htmlFor="gs-safe">
              <select
                id="gs-safe"
                className={inputClass(false)}
                value={safeName}
                onChange={(e) => {
                  setSafeName(e.target.value)
                  setFolderPath('')
                  setLeaf(ANY_ONE)
                  setTypedScope(false)
                }}
              >
                <option value="">Select a safe…</option>
                {safes.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Folder" hint="Optional" htmlFor="gs-folder">
              <select
                id="gs-folder"
                className={inputClass(false)}
                value={folderPath}
                disabled={!safeName}
                onChange={(e) => {
                  setFolderPath(e.target.value)
                  setLeaf(ANY_ONE)
                  setTypedScope(false)
                }}
              >
                <option value="">Safe root</option>
                {foldersInSafe.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Secrets" htmlFor="gs-leaf">
              <select
                id="gs-leaf"
                className={inputClass(false)}
                value={leaf}
                disabled={!safeName}
                onChange={(e) => {
                  setLeaf(e.target.value)
                  setTypedScope(false)
                }}
              >
                <option value={ANY_ONE}>Everything at this level (*)</option>
                <option value={ANY_SUBTREE}>This level and below (**)</option>
                {leavesInScope.length > 0 && (
                  <optgroup label="One secret">
                    {leavesInScope.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </optgroup>
                )}
              </select>
            </Field>
          </div>

          <Field
            label="Scope"
            required
            hint="prod-db/* is one level. prod-db/** is the whole subtree. * on its own is the entire vault."
            error={trimmedScope && !valid ? 'The server cannot parse that pattern.' : undefined}
            htmlFor="gs-scope"
          >
            <input
              id="gs-scope"
              autoComplete="off"
              spellCheck={false}
              placeholder="prod-db/pg-app-writer"
              className={clsx(inputClass(!!trimmedScope && !valid), 'font-mono')}
              value={scope}
              onChange={(e) => {
                setScope(e.target.value)
                setTypedScope(true)
                setAcknowledged(false)
              }}
            />
          </Field>
        </FieldSet>

        {/* The preview. This is the part that turns a guess into a decision. */}
        <section className="overflow-hidden rounded-xl border border-surface-700 bg-surface-850">
          <header className="flex flex-wrap items-center gap-x-3 gap-y-1.5 border-b border-surface-800 px-3 py-2">
            <Radar className="h-3.5 w-3.5 flex-none text-ink-500" strokeWidth={1.75} />
            <h3 className="flex-none text-xs font-semibold text-ink-300">What this reaches today</h3>
            <span className="flex-none text-2xs tabular-nums text-ink-500">
              {isLoading
                ? 'reading the vault…'
                : `${matchedSecrets.length} of ${secrets.length} secret${secrets.length === 1 ? '' : 's'}`}
            </span>
          </header>

          {isPartial && (
            <p className="border-b border-surface-800 bg-amber-50/70 px-3 py-2 text-2xs leading-relaxed text-amber-800 dark:bg-amber-950/20 dark:text-amber-200">
              Part of the vault could not be listed, so this preview is incomplete. The scope may reach more
              than is shown.
            </p>
          )}

          {!trimmedScope ? (
            <p className="px-3 py-6 text-center text-xs text-ink-500">
              Pick a safe above, or type a scope, to see which secrets it covers.
            </p>
          ) : !valid ? (
            <p className="px-3 py-6 text-center text-xs text-ink-500">
              Nothing to preview — that pattern is not valid.
            </p>
          ) : matchedSecrets.length === 0 ? (
            <p className="px-3 py-5 text-center text-xs leading-relaxed text-ink-400">
              No secret matches this scope today.
              <br />
              <span className="text-ink-500">
                That is legitimate for a path you are about to populate, and a mistake if you expected this
                service to start reading something immediately.
              </span>
            </p>
          ) : (
            <>
              <ul className="max-h-52 divide-y divide-surface-800/70 overflow-y-auto">
                {matchedSecrets.slice(0, MAX_PREVIEW).map((s) => (
                  <PreviewRow key={s.id} secret={s} />
                ))}
              </ul>
              {matchedSecrets.length > MAX_PREVIEW && (
                <p className="border-t border-surface-800 px-3 py-1.5 text-2xs text-ink-500">
                  and {matchedSecrets.length - MAX_PREVIEW} more
                </p>
              )}
            </>
          )}

          {notice && (
            <div
              className={clsx(
                'flex items-start gap-2.5 border-t px-3 py-2.5',
                notice.tone === 'danger'
                  ? 'border-red-500/30 bg-red-50 dark:bg-red-950/25'
                  : 'border-amber-500/30 bg-amber-50/80 dark:bg-amber-950/20'
              )}
            >
              <AlertTriangle
                className={clsx(
                  'mt-px h-3.5 w-3.5 flex-none',
                  notice.tone === 'danger'
                    ? 'text-red-600 dark:text-red-400'
                    : 'text-amber-600 dark:text-amber-400'
                )}
                strokeWidth={2}
              />
              <div className="min-w-0">
                <p
                  className={clsx(
                    'text-xs font-semibold',
                    notice.tone === 'danger'
                      ? 'text-red-800 dark:text-red-200'
                      : 'text-amber-800 dark:text-amber-200'
                  )}
                >
                  {notice.title}
                </p>
                <p className="mt-0.5 text-2xs leading-relaxed text-ink-400">{notice.body}</p>
                {needsAck && (
                  <label className="mt-2 flex cursor-pointer items-center gap-2 text-2xs font-medium text-red-800 dark:text-red-200">
                    <input
                      type="checkbox"
                      checked={acknowledged}
                      onChange={(e) => setAcknowledged(e.target.checked)}
                      className="h-3.5 w-3.5 rounded border-surface-600 accent-red-600"
                    />
                    I understand this service will be able to read every secret in the vault.
                  </label>
                )}
              </div>
            </div>
          )}
        </section>

        <FieldSet
          title="Limits"
          description="How long a client may cache what it reads, and when the grant stops applying on its own."
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <Field
              label="Cache lifetime cap"
              hint="Seconds. This bounds how long a revoked grant can still be effective on a client that already holds the plaintext. Blank or 0 uses the server default."
              htmlFor="gs-ttl"
            >
              <div className="relative">
                <Timer
                  className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-500"
                  strokeWidth={1.75}
                />
                <input
                  id="gs-ttl"
                  type="number"
                  min="0"
                  inputMode="numeric"
                  placeholder="300"
                  className={clsx(inputClass(false), 'pl-8 tabular-nums')}
                  value={maxTtl}
                  onChange={(e) => setMaxTtl(e.target.value)}
                />
              </div>
            </Field>

            <Field
              label="Expires in"
              hint="Days. Blank means the grant lasts until someone revokes it."
              htmlFor="gs-exp"
            >
              <input
                id="gs-exp"
                type="number"
                min="0"
                inputMode="numeric"
                placeholder="never"
                className={clsx(inputClass(false), 'tabular-nums')}
                value={expiresInDays}
                onChange={(e) => setExpiresInDays(e.target.value)}
              />
            </Field>
          </div>

          <Field
            label="Reason"
            required
            hint="Why this service needs this scope. It goes into the audit record, and it is what a reviewer reads first."
            htmlFor="gs-reason"
          >
            <textarea
              id="gs-reason"
              rows={2}
              placeholder="The billing API reads the writer credential for the invoices database on start-up."
              className={inputClass(false)}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </Field>
        </FieldSet>

        <p className="flex items-start gap-2 text-2xs leading-relaxed text-ink-500">
          <Vault className="mt-px h-3.5 w-3.5 flex-none" strokeWidth={1.75} />
          <span>
            The preview mirrors the server&apos;s matcher, but the server decides. A grant takes effect
            immediately and applies to whichever token the service presents.
          </span>
        </p>
        <p className="sr-only" aria-live="polite">
          {valid ? `${matchedSecrets.length} secrets match ${trimmedScope}` : 'Scope is not valid'}
        </p>
      </form>
    </Modal>
  )
}
