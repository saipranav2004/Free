import { useCallback, useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Bot, KeyRound, Plus, ShieldCheck, ShieldOff, Undo2 } from 'lucide-react'
import clsx from 'clsx'
import {
  disableServiceIdentity,
  enableServiceIdentity,
  listServiceGrants,
  listServiceIdentities,
  listServiceTokens,
} from '../../api/serviceIdentity'
import { Container, PageTitle, Stack } from '../../components/ui/layout'
import { ServiceInsightStrip } from '../../components/insights/ServiceInsightStrip'
import { DataTable, RowActions, SkeletonGrid, SortTh, Td, Th, Tr, Trunc } from '../../components/ui/grid'
import { MenuItem, RowMenu } from '../../components/ui/menu'
import { FilterChip, Meta, StatusDot } from '../../components/ui/bits'
import {
  ActiveFilters,
  CommandBar,
  ExportMenu,
  Pagination,
  PreferencesMenu,
  RefreshControl,
  SearchField,
} from '../../components/ui/chrome'
import { DeniedState, EmptyState, ErrorState, NoMatchState, OfflineState } from '../../components/ui/states'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Button } from '../../components/common/Button'
import { CreateServiceIdentityModal } from '../../components/admin/CreateServiceIdentityModal'
import { IssueServiceTokenModal } from '../../components/admin/IssueServiceTokenModal'
import { GrantSecretScopeModal } from '../../components/admin/GrantSecretScopeModal'
import { ServiceIdentityDrawer } from '../../components/admin/ServiceIdentityDrawer'
import { SplitPlaceholder, SplitView, useSplitSelection } from '../../components/ui/splitview'
import { useTableState } from '../../hooks/useTableState'
import { exportRowsToCsv, exportRowsToJson } from '../../lib/exportRows'
import { apiErrorMessage, normalizeApiError } from '../../lib/apiError'
import { formatDateTime, formatRelativeToNow } from '../../lib/format'

// ---------------------------------------------------------------------------
// Admin Center, Service Identities
// ---------------------------------------------------------------------------
// The human side of the vault had a console; the machine side had a JSON API
// and nothing else, which meant nobody could answer the two questions that
// actually matter about a machine principal without querying the database:
//
//     What can this service read?      (its scopes)
//     What can authenticate as it?     (its tokens)
//
// So those are the two columns, and they are counts of LIVE things rather than
// totals — a service with four revoked tokens and none active cannot read
// anything, and a row that said "4" would be lying about the state of the
// world. The consequence is one extra request per identity, which is worth it:
// the alternative is a list where every row looks the same and the only way to
// tell a working service from a broken one is to open it.
//
// POSTURE is the column that earns its place. Three states, and each one is a
// different action:
//
//     ready       token + scope       nothing to do
//     no token    scope, no token     mint one, nothing can authenticate
//     no scope    token, no scope     grant one, every read is refused
//
// That last pair is the state that generates support tickets: the application
// has a token, it authenticates fine, and every secret read comes back 403
// with nothing in the application's logs to explain why.

const CSV_COLUMNS = [
  { key: 'name', label: 'Service' },
  { key: 'status', label: 'Status' },
  { key: 'environment', label: 'Environment' },
  { key: 'description', label: 'Description' },
  { key: 'owner_id', label: 'Owner' },
  { key: 'max_secrets_per_minute', label: 'Reads per minute' },
  { key: 'created_at', label: 'Registered' },
  { key: 'id', label: 'Identity ID' },
]

const POSTURE = {
  ready: { tone: 'ok', label: 'Ready', hint: 'Holds an active token and at least one scope.' },
  'no-token': {
    tone: 'warn',
    label: 'No token',
    hint: 'Has scopes but nothing can authenticate as it. Mint a token.',
  },
  'no-scope': {
    tone: 'warn',
    label: 'No scope',
    hint: 'Can authenticate but every secret read is refused. Grant a scope.',
  },
  unused: {
    tone: 'muted',
    label: 'Not set up',
    hint: 'No token and no scope. Registered, not yet in use.',
  },
  disabled: { tone: 'muted', label: 'Disabled', hint: 'All tokens revoked. Scopes intact.' },
}

function postureOf(identity, counts) {
  if (identity.status !== 'active') return 'disabled'
  if (!counts) return null
  const { liveTokens, liveGrants } = counts
  if (liveTokens > 0 && liveGrants > 0) return 'ready'
  if (liveTokens === 0 && liveGrants === 0) return 'unused'
  return liveTokens === 0 ? 'no-token' : 'no-scope'
}

export default function ServiceIdentitiesPage() {
  const queryClient = useQueryClient()

  // Prefetch on intent. Keyed IDENTICALLY to the drawer's own queries — a
  // prefetch under a different key warms a cache entry nobody reads, which
  // looks like it works (requests go out, no errors) and saves nothing.
  const prefetchIdentityDetail = useCallback(
    (name) => {
      queryClient.prefetchQuery({
        queryKey: ['admin', 'service-grants', name, false],
        queryFn: ({ signal }) => listServiceGrants(name, { includeInactive: false, signal }),
        staleTime: 30_000,
      })
      queryClient.prefetchQuery({
        queryKey: ['admin', 'service-tokens', name],
        queryFn: ({ signal }) => listServiceTokens(name, signal),
        staleTime: 30_000,
      })
    },
    [queryClient]
  )
  const [createOpen, setCreateOpen] = useState(false)
  const [peeked, setPeeked] = useState(null)
  const [grantTarget, setGrantTarget] = useState(null)
  const [tokenTarget, setTokenTarget] = useState(null)
  const [disableTarget, setDisableTarget] = useState(null)
  const [enableTarget, setEnableTarget] = useState(null)

  // Deep link: /admin/services?new=1 opens the create form, matching the
  // other admin pages. The param is stripped so a reload does not reopen it.
  const [params, setParams] = useSearchParams()
  useEffect(() => {
    if (params.get('new') === null) return
    setCreateOpen(true)
    const next = new URLSearchParams(params)
    next.delete('new')
    setParams(next, { replace: true })
  }, [params, setParams])

  const identitiesQuery = useQuery({
    queryKey: ['admin', 'service-identities'],
    queryFn: ({ signal }) => listServiceIdentities(signal),
  })

  const identities = useMemo(() => identitiesQuery.data || [], [identitiesQuery.data])

  // The counts come down ON the row, computed server-side in two grouped
  // queries. They used to be fanned out here, one request per identity per
  // table — 200 identities meant 400 requests on a single page load, which
  // degrades long before the row count itself is a problem. See
  // ListIdentitiesWithCounts.
  const countsByName = useMemo(() => {
    const map = new Map()
    for (const i of identities) {
      map.set(i.name, {
        liveTokens: i.live_tokens ?? 0,
        liveGrants: i.live_grants ?? 0,
        // Empty means "holds no live grant", which is not the same as "holds
        // one narrow grant" — postureOf reads liveGrants, not this.
        widest: i.widest_scope || null,
      })
    }
    return map
  }, [identities])

  // Counts arrive with the list, so there is no separate loading state for
  // them any more. Kept as a name so the row still renders a placeholder
  // during the list's own load rather than a bare dash.
  const countsLoading = identitiesQuery.isLoading

  const disableMutation = useMutation({
    mutationFn: (name) => disableServiceIdentity(name),
    onSuccess: (_data, name) => {
      toast.success(`${name} disabled`, {
        description: 'Every token it held is revoked. Its scopes are intact, and it can be enabled again.',
      })
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-identities'] })
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-tokens', name] })
      setDisableTarget(null)
      setPeeked(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDisableTarget(null)
    },
  })

  const enableMutation = useMutation({
    mutationFn: (name) => enableServiceIdentity(name),
    onSuccess: (_data, name) => {
      // Said explicitly, because the opposite is what an operator assumes:
      // the identity is back, the revoked tokens are not.
      toast.success(`${name} enabled`, {
        description: 'Its scopes are back. The tokens the disable revoked stay revoked — mint a new one.',
      })
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-identities'] })
      queryClient.invalidateQueries({ queryKey: ['admin', 'service-tokens', name] })
      setEnableTarget(null)
      setPeeked(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setEnableTarget(null)
    },
  })

  const table = useTableState({
    rows: identities,
    storageKey: 'service-identities',
    urlSync: true,
    rowId: (i) => i.id,
    initialSort: { key: 'name', dir: 'asc' },
    initialPageSize: 25,
    initialFilters: { posture: 'all' },
    searchFields: ['name', 'description', 'environment', 'owner_id'],
    filterFn: (i, f) => {
      if (f.posture === 'all') return true
      if (f.posture === 'attention') {
        const p = postureOf(i, countsByName.get(i.name))
        return p === 'no-token' || p === 'no-scope'
      }
      return postureOf(i, countsByName.get(i.name)) === f.posture
    },
    sortAccessor: (i, key) =>
      key === 'tokens'
        ? (countsByName.get(i.name)?.liveTokens ?? -1)
        : key === 'grants'
          ? (countsByName.get(i.name)?.liveGrants ?? -1)
          : i[key],
  })

  // ↑/↓ and j/k walk the list; Escape closes the pane. This is what makes a
  // split view worth having over a drawer — without it the operator is still
  // reaching for the mouse on every row, and all that was gained is that the
  // list stays visible while they do.
  //
  // Scoped to the rows ON THIS PAGE: stepping past the last visible row into
  // an unrendered one would select something nobody can see. Disabled while a
  // modal is up, so j in a text field is a character, not a jump.
  // The detail pane halves the list's width, so the list sheds the columns
  // the pane itself shows in full.
  const paneOpen = !!peeked

  useSplitSelection({
    items: table.pageRows,
    selectedId: peeked?.id ?? null,
    idOf: (i) => i?.id,
    onSelect: (id, row) => setPeeked(id == null ? null : row ?? null),
    enabled: !createOpen && !grantTarget && !tokenTarget && !disableTarget && !enableTarget,
  })


  const attentionCount = identities.filter((i) => {
    const p = postureOf(i, countsByName.get(i.name))
    return p === 'no-token' || p === 'no-scope'
  }).length
  const readyCount = identities.filter(
    (i) => postureOf(i, countsByName.get(i.name)) === 'ready'
  ).length
  const disabledCount = identities.filter((i) => i.status !== 'active').length
  const unscopedCount = identities.filter((i) => countsByName.get(i.name)?.widest === 'all').length

  const err = identitiesQuery.isError ? normalizeApiError(identitiesQuery.error) : null

  const chips = []
  if (table.query)
    chips.push({ key: 'q', label: 'Search', value: table.query, onClear: () => table.setQuery('') })
  if (table.filters.posture !== 'all')
    chips.push({
      key: 'posture',
      label: 'Posture',
      value: table.filters.posture,
      onClear: () => table.setFilter('posture', 'all'),
    })

  return (
    <Stack gap="lg">
      <PageTitle
        title="Service Identities"
        counter={identitiesQuery.isSuccess ? identities.length : undefined}
        description="Machine principals: applications, jobs and agents that read vault secrets with no person in the loop. A token says who it is; a scope says what it may read."
      />

      {/* The whole page already sits behind RequireAdmin, so no extra gate.
          READY is the figure the table below cannot show: every row says
          "active", which only means nobody disabled it — an identity with a
          token and no grant authenticates and then reads nothing. */}
      <ServiceInsightStrip />

      <Stack gap="sm">
        <CommandBar
          primary={
            <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
              Register identity
            </Button>
          }
          summary={
            identitiesQuery.isSuccess && table.total !== identities.length
              ? `${table.total} of ${identities.length} shown`
              : undefined
          }
        >
          <ExportMenu
            count={table.total}
            disabled={table.total === 0}
            onExportCsv={() => exportRowsToCsv(table.filteredRows, CSV_COLUMNS, 'service-identities')}
            onExportJson={() => exportRowsToJson(table.filteredRows, CSV_COLUMNS, 'service-identities')}
          />
          <RefreshControl
            onRefresh={() => identitiesQuery.refetch()}
            isFetching={identitiesQuery.isFetching}
            updatedAt={identitiesQuery.dataUpdatedAt}
          />
          <PreferencesMenu pageSize={table.pageSize} onPageSize={table.setPageSize} />
        </CommandBar>

        <div className="flex flex-wrap items-center gap-2">
          <SearchField
            value={table.query}
            onChange={table.setQuery}
            placeholder="Search service identities"
            label="Search service identities"
          />
          {[
            { key: 'all', label: 'All', count: identities.length },
            { key: 'ready', label: 'Ready', count: readyCount },
            { key: 'attention', label: 'Needs attention', count: attentionCount },
            { key: 'disabled', label: 'Disabled', count: disabledCount },
          ].map((f) => (
            <FilterChip
              key={f.key}
              active={table.filters.posture === f.key}
              count={f.count}
              onClick={() => table.setFilter('posture', f.key)}
            >
              {f.label}
            </FilterChip>
          ))}
          {unscopedCount > 0 && (
            <span className="text-sm text-danger" title="Identities holding a scope that covers the whole vault">
              {unscopedCount} with vault-wide access
            </span>
          )}
        </div>

        <ActiveFilters chips={chips} onClearAll={table.resetFilters} />
      </Stack>

      {/* SPLIT VIEW, not a drawer over the list.
          This is queue work: an administrator goes down the identities one
          after another, checking scopes and token runway. A drawer covers the
          very list being worked down, so each identity costs open → read →
          close → find your place again. Keeping both on screen removes two of
          those four steps, and ↑/↓ or j/k removes the mouse from the other
          two. Below lg there is only room for one pane, so the detail wins and
          the list is one tap away. */}
      <SplitView
        selected={peeked}
        onClose={() => setPeeked(null)}
        list={<Container padded={false}>
        {identitiesQuery.isLoading ? (
          <table className="w-full">
            <tbody>
              <SkeletonGrid colSpan={7} rows={6} />
            </tbody>
          </table>
        ) : err ? (
          err.status === 403 ? (
            <DeniedState description={err.message} />
          ) : err.code === 'network_error' ? (
            <OfflineState onRetry={() => identitiesQuery.refetch()} retrying={identitiesQuery.isFetching} />
          ) : (
            <ErrorState
              description={err.message}
              onRetry={() => identitiesQuery.refetch()}
              retrying={identitiesQuery.isFetching}
            />
          )
        ) : identities.length === 0 ? (
          <EmptyState
            icon={Bot}
            title="No service identities yet"
            description="Register one for each application that reads secrets. It holds no token and no scope until you add them, so registering is safe."
            action={
              <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
                Register the first identity
              </Button>
            }
          />
        ) : table.total === 0 ? (
          <NoMatchState
            description="Nothing matches the current search or posture filter."
            onClear={table.resetFilters}
          />
        ) : (
          <>
            {/* With the pane open the list becomes a NAVIGATOR: which row is
                this, and is it healthy. Everything else — scope and token
                counts, description, registration date — is in the pane at
                full size, so repeating it in a 30rem column would just make
                the list scroll sideways beside a panel already showing it.
                The fixed widths are the reason a narrower minWidth alone was
                not enough: five columns at 45rem of `col` widths clip at any
                pane size, whatever the table's own minimum says. */}
            <DataTable minWidth={paneOpen ? '24rem' : '62rem'}>
              <colgroup>
                <col className={paneOpen ? 'w-auto min-w-[11rem]' : 'w-[15rem] min-w-[11rem]'} />
                <col className="w-[9.5rem]" />
                {/* Wide enough for the header plus its sort arrow: at
                    6.5rem both of these truncated to "Sco…" and "Tok…",
                    which is the one thing a column header cannot do. */}
                {!paneOpen && <col className="w-[8.5rem]" />}
                {!paneOpen && <col className="w-[8.5rem]" />}
                {!paneOpen && <col className="w-auto" />}
                {!paneOpen && <col className="w-[9rem]" />}
                <col className="w-[4rem]" />
              </colgroup>
              <thead>
                <tr>
                  <SortTh columnKey="name" sort={table.sort} onSort={table.toggleSort} sticky edge>
                    Service
                  </SortTh>
                  <Th>Posture</Th>
                  {!paneOpen && (
                    <SortTh columnKey="grants" sort={table.sort} onSort={table.toggleSort} align="right">
                      Scopes
                    </SortTh>
                  )}
                  {!paneOpen && (
                    <SortTh columnKey="tokens" sort={table.sort} onSort={table.toggleSort} align="right">
                      Tokens
                    </SortTh>
                  )}
                  {!paneOpen && <Th>Description</Th>}
                  {!paneOpen && (
                    <SortTh columnKey="created_at" sort={table.sort} onSort={table.toggleSort}>
                      Registered
                    </SortTh>
                  )}
                  <Th align="right">
                    <span className="sr-only">Row actions</span>
                  </Th>
                </tr>
              </thead>
              <tbody>
                {table.pageRows.map((i) => {
                  const counts = countsByName.get(i.name)
                  const posture = postureOf(i, counts)
                  const p = posture ? POSTURE[posture] : null
                  const vaultWide = counts?.widest === 'all'
                  const needsWork = posture === 'no-token' || posture === 'no-scope'
                  return (
                    <Tr
                      key={i.id}
                      // Without this the pane shows one identity while nothing
                      // in the list says which — two panels side by side with
                      // no relationship visible between them.
                      selected={peeked?.id === i.id}
                      // The drawer fires TWO queries when it opens — grants
                      // and tokens. Warming them while the pointer rests on
                      // the row means it opens against a cache hit instead of
                      // two spinners. prefetchQuery is a no-op when the data
                      // is already fresh, so resting on the same row twice
                      // costs one request, not two.
                      onIntent={() => prefetchIdentityDetail(i.name)}
                      estimatedHeight={52}
                    >
                      {/* An identity with vault-wide access carries an edge
                          rail, the same mark a deny policy gets: it inverts
                          the meaning of the row and must be findable without
                          reading across to another column. */}
                      <Td
                        sticky
                        edge
                        className={
                          vaultWide
                            ? 'shadow-[inset_3px_0_0_0_rgb(var(--danger))]'
                            : needsWork
                              ? 'shadow-[inset_3px_0_0_0_rgb(var(--warn))]'
                              : undefined
                        }
                      >
                        <button
                          type="button"
                          onClick={() => setPeeked(i)}
                          title={i.name}
                          className="block max-w-full truncate text-left font-mono text-sm font-medium text-primary transition-colors hover:text-accent hover:underline"
                        >
                          {i.name}
                        </button>
                        {i.environment && <Meta className="mt-0.5 block">{i.environment}</Meta>}
                      </Td>
                      <Td>
                        {p ? (
                          <StatusDot tone={p.tone} label={p.label} title={p.hint} live={posture === 'ready'} />
                        ) : (
                          <span className="text-xs text-tertiary">
                            {countsLoading ? 'checking…' : 'unknown'}
                          </span>
                        )}
                      </Td>
                      {!paneOpen && (
                        <Td align="right">
                          <span
                            className={clsx(
                              'text-sm tabular',
                              vaultWide ? 'font-semibold text-danger' : 'text-primary'
                            )}
                            title={vaultWide ? 'One of these scopes covers the whole vault' : undefined}
                          >
                            {counts ? counts.liveGrants : '—'}
                          </span>
                        </Td>
                      )}
                      {!paneOpen && (
                        <Td align="right">
                          <span className="text-sm tabular text-primary">
                            {counts ? counts.liveTokens : '—'}
                          </span>
                        </Td>
                      )}
                      {!paneOpen && (
                        <Td>
                          <Trunc value={i.description || ''} muted />
                        </Td>
                      )}
                      {!paneOpen && (
                        <Td>
                          <span className="text-sm text-secondary" title={formatDateTime(i.created_at)}>
                            {formatRelativeToNow(i.created_at)}
                          </span>
                        </Td>
                      )}
                      <Td align="right">
                        <RowActions>
                          <RowMenu label={`Actions for ${i.name}`}>
                            <MenuItem icon={Bot} onClick={() => setPeeked(i)}>
                              Open identity
                            </MenuItem>
                            {i.status === 'active' ? (
                              <>
                                <MenuItem icon={ShieldCheck} onClick={() => setGrantTarget(i)}>
                                  Grant a scope
                                </MenuItem>
                                <MenuItem icon={KeyRound} onClick={() => setTokenTarget(i)}>
                                  Mint a token
                                </MenuItem>
                                <MenuItem icon={ShieldOff} danger onClick={() => setDisableTarget(i)}>
                                  Disable identity
                                </MenuItem>
                              </>
                            ) : (
                              <MenuItem icon={Undo2} onClick={() => setEnableTarget(i)}>
                                Enable identity
                              </MenuItem>
                            )}
                          </RowMenu>
                        </RowActions>
                      </Td>
                    </Tr>
                  )
                })}
              </tbody>
            </DataTable>

            <Pagination
              page={table.page}
              pageSize={table.pageSize}
              total={table.total}
              totalPages={table.totalPages}
              onPageChange={table.setPage}
              label="identities"
            />
          </>
        )}
      </Container>}
        detail={
          peeked && (
            <ServiceIdentityDrawer
              variant="panel"
              identity={peeked}
              onClose={() => setPeeked(null)}
              onGrant={setGrantTarget}
              onMintToken={setTokenTarget}
              onDisable={setDisableTarget}
              onEnable={setEnableTarget}
            />
          )
        }
        placeholder={
          <SplitPlaceholder
            icon={Bot}
            title="Pick an identity"
            description="Its live scopes, its tokens and how long they have left. Use ↑ and ↓, or j and k, to walk the list."
          />
        }
      />

      <CreateServiceIdentityModal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        // Straight into granting: an identity with no scope reads nothing, and
        // the next thing the operator came here to do is say what it may read.
        onCreated={(identity) => identity && setGrantTarget(identity)}
      />

      <GrantSecretScopeModal
        open={!!grantTarget}
        identity={grantTarget}
        onClose={() => setGrantTarget(null)}
      />

      <IssueServiceTokenModal
        open={!!tokenTarget}
        identity={tokenTarget}
        onClose={() => setTokenTarget(null)}
      />

      <ConfirmDialog
        open={!!disableTarget}
        title={`Disable “${disableTarget?.name}”?`}
        description="Every token this identity holds is revoked in one step, so anything running as it stops authenticating immediately. Its scopes are left intact and it can be enabled again — but the revoked tokens stay revoked, so recovery means minting a new one and redeploying."
        confirmLabel="Disable identity"
        destructive
        isLoading={disableMutation.isPending}
        onConfirm={() => disableMutation.mutate(disableTarget.name)}
        onCancel={() => setDisableTarget(null)}
      />

      <ConfirmDialog
        open={!!enableTarget}
        title={`Enable “${enableTarget?.name}”?`}
        description="The identity and its scopes come back. The tokens the disable revoked stay revoked — a credential that may have leaked is not resurrected to undo an administrative action — so nothing can authenticate as it until you mint a new token and redeploy."
        confirmLabel="Enable identity"
        destructive={false}
        isLoading={enableMutation.isPending}
        onConfirm={() => enableMutation.mutate(enableTarget.name)}
        onCancel={() => setEnableTarget(null)}
      />
    </Stack>
  )
}
