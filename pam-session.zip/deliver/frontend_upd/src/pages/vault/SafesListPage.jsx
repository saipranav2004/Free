import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, Vault as VaultIcon } from 'lucide-react'
import { listSafes } from '../../api/vault'
import { normalizeApiError } from '../../lib/apiError'
import { useAuthStore } from '../../store/authStore'
import { Container, PageTitle, Stack } from '../../components/ui/layout'
import { VaultInsightStrip } from '../../components/insights/VaultInsightStrip'
import { VaultTree } from '../../components/vault/VaultTree'
import { SegmentedControl } from '../../components/common/SegmentedControl'
import { DataTable, SkeletonGrid, SortTh, Td, Th, Tr, Trunc } from '../../components/ui/grid'
import { Meta } from '../../components/ui/bits'
import {
  CommandBar,
  Pagination,
  PreferencesMenu,
  RefreshControl,
  SearchField,
} from '../../components/ui/chrome'
import { DeniedState, EmptyState, ErrorState, NoMatchState, OfflineState } from '../../components/ui/states'
import { Button } from '../../components/common/Button'
import { CreateSafeModal } from '../../components/vault/CreateSafeModal'
import { useTableState } from '../../hooks/useTableState'
import { formatDate, formatRelativeToNow } from '../../lib/format'

// ---------------------------------------------------------------------------
// Vault, safes
// ---------------------------------------------------------------------------
// A safe is a container, and there are usually a handful of them, so the
// question this page answers is "which safe, and how much is in it".
//
// THE CARD VIEW IS GONE. Cards were the default: four bordered tiles with a
// name, a description and a count each. That is a table with extra chrome and
// a worse scan line, and it stopped being defensible the moment the count
// mattered, because you cannot compare numbers that are not in a column. The
// same information now reads down five aligned columns.
//
// COUNTS AND RETENTION ARE RIGHT ALIGNED AND TABULAR, because they are
// quantities and the whole point of putting them in a column is comparing
// them vertically. Created stays left aligned: a date is qualitative.
//
// listSafes() returns the whole collection and takes no parameters, so search,
// sort and paging are client side by necessity.

const SAFE_COLUMNS = [
  { key: 'name', label: 'Safe', required: true },
  { key: 'description', label: 'Description' },
  { key: 'credential_count', label: 'Credentials' },
  { key: 'retention_days', label: 'Retention' },
  { key: 'created_at', label: 'Created' },
]

export default function SafesListPage() {
  const [createOpen, setCreateOpen] = useState(false)

  const safesQuery = useQuery({
    queryKey: ['vault', 'safes'],
    queryFn: ({ signal }) => listSafes(signal),
  })

  const safes = useMemo(() => safesQuery.data || [], [safesQuery.data])

  const table = useTableState({
    rows: safes,
    storageKey: 'safes',
    // View state in the address bar, so a filtered list is something you can
    // send to someone. See useTableState.
    urlSync: true,
    rowId: (s) => s.id,
    initialSort: { key: 'name', dir: 'asc' },
    initialPageSize: 25,
    searchFields: ['name', 'description'],
  })

  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [view, setView] = useState('list')
  // Only an admin can see the tree at all — the path index behind it is on
  // the admin plane — so the toggle cannot strand an operator on a blank view.
  const showTree = isAdmin && view === 'tree'
  const err = safesQuery.isError ? normalizeApiError(safesQuery.error) : null
  const show = (key) => !table.visibleColumns || table.visibleColumns.includes(key)

  return (
    <Stack gap="lg">
      <PageTitle
        title="Vault"
        counter={safesQuery.isSuccess ? safes.length : undefined}
        description="Safes hold credentials. Revealing one is recorded against your identity, with the reason you give."
      />

      {/* Admin only, and gated HERE rather than left to fail: the figures are
          fleet-wide inventory served from the admin plane, so a non-admin
          would get a 403 and a card explaining that a thing they cannot use
          is unavailable. Not rendering it is the honest version. */}
      {isAdmin && <VaultInsightStrip />}

      {/* TWO SHAPES FOR TWO QUESTIONS.
          A table of safes answers "which safe do I open". It cannot answer
          "what is in this vault and how is it addressed", because the vault
          is a HIERARCHY — safe → folder → secret — and it was shipped as
          three separate pages of table, one per level. Every step down was a
          full navigation, every step sideways two, and the shape was never
          on screen at all.
          The tree is also the only place the CANONICAL PATH appears. That
          path is what a service identity's grant is written against, so an
          administrator writing a scope was typing a glob at an address space
          they could not see. Admin-only because the path index it is built
          from is served on the admin plane. */}
      {isAdmin && (
        <div className="flex items-center justify-end gap-3">
          <span className="text-2xs text-tertiary">
            {view === 'tree'
              ? 'Every secret, by the path a grant addresses it with.'
              : 'Safes, with what each one holds.'}
          </span>
          <SegmentedControl
            size="sm"
            ariaLabel="Vault view"
            value={view}
            onChange={setView}
            options={[
              { key: 'list', label: 'Safes' },
              { key: 'tree', label: 'Tree' },
            ]}
          />
        </div>
      )}

      {showTree && (
        <Container padded={false}>
          <VaultTree />
        </Container>
      )}

      {/* One shape at a time. Both at once would be two answers to "what is
          in this vault", stacked. Unmounted rather than hidden, so the table
          is not paginating and sorting rows nobody is looking at. */}
      {!showTree && (
        <>
      <Stack gap="sm">
        <CommandBar
          primary={
            <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
              Create safe
            </Button>
          }
          summary={
            safesQuery.isSuccess && table.total !== safes.length
              ? `${table.total} of ${safes.length} shown`
              : undefined
          }
        >
          <RefreshControl
            onRefresh={() => safesQuery.refetch()}
            isFetching={safesQuery.isFetching}
            updatedAt={safesQuery.dataUpdatedAt}
          />
          <PreferencesMenu
            columns={SAFE_COLUMNS}
            visible={table.visibleColumns}
            onVisibleChange={table.setVisibleColumns}
            pageSize={table.pageSize}
            onPageSize={table.setPageSize}
          />
        </CommandBar>

        <SearchField
          value={table.query}
          onChange={table.setQuery}
          placeholder="Search safes by name or description"
          label="Search safes"
        />
      </Stack>

      <Container padded={false}>
        {safesQuery.isLoading ? (
          <table className="w-full">
            <tbody>
              <SkeletonGrid colSpan={SAFE_COLUMNS.length} rows={5} />
            </tbody>
          </table>
        ) : err ? (
          err.status === 403 ? (
            <DeniedState description={err.message} />
          ) : err.code === 'network_error' ? (
            <OfflineState onRetry={() => safesQuery.refetch()} retrying={safesQuery.isFetching} />
          ) : (
            <ErrorState
              description={err.message}
              onRetry={() => safesQuery.refetch()}
              retrying={safesQuery.isFetching}
            />
          )
        ) : safes.length === 0 ? (
          <EmptyState
            icon={VaultIcon}
            title="No safes yet"
            description="Create a safe to start storing credentials under a retention policy."
            action={
              <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
                Create the first safe
              </Button>
            }
          />
        ) : table.total === 0 ? (
          <NoMatchState
            description="No safe matches that search."
            onClear={() => table.setQuery('')}
            clearLabel="Clear search"
          />
        ) : (
          <>
            <DataTable minWidth="52rem">
              <colgroup>
                {show('name') && <col className="w-[16rem] min-w-[12rem]" />}
                {show('description') && <col className="w-auto" />}
                {show('credential_count') && <col className="w-[8rem]" />}
                {show('retention_days') && <col className="w-[8rem]" />}
                {show('created_at') && <col className="w-[10rem]" />}
              </colgroup>

              <thead>
                <tr>
                  {show('name') && (
                    <SortTh columnKey="name" sort={table.sort} onSort={table.toggleSort} sticky edge>
                      Safe
                    </SortTh>
                  )}
                  {show('description') && <Th>Description</Th>}
                  {show('credential_count') && (
                    <SortTh
                      columnKey="credential_count"
                      sort={table.sort}
                      onSort={table.toggleSort}
                      align="right"
                    >
                      Credentials
                    </SortTh>
                  )}
                  {show('retention_days') && (
                    <SortTh
                      columnKey="retention_days"
                      sort={table.sort}
                      onSort={table.toggleSort}
                      align="right"
                    >
                      Retention
                    </SortTh>
                  )}
                  {show('created_at') && (
                    <SortTh columnKey="created_at" sort={table.sort} onSort={table.toggleSort}>
                      Created
                    </SortTh>
                  )}
                </tr>
              </thead>

              <tbody>
                {table.pageRows.map((s) => (
                  <Tr key={s.id} estimatedHeight={44}>
                    {show('name') && (
                      <Td sticky edge>
                        <div className="flex min-w-0 items-center gap-2">
                          <Link
                            to={`/vault/${s.id}`}
                            title={s.name}
                            className="min-w-0 truncate text-sm font-medium text-primary transition-colors hover:text-accent hover:underline"
                          >
                            {s.name}
                          </Link>
                          {s.is_default && <Meta>default</Meta>}
                        </div>
                      </Td>
                    )}
                    {show('description') && (
                      <Td>
                        <Trunc value={s.description} muted />
                      </Td>
                    )}
                    {show('credential_count') && (
                      <Td align="right">
                        <span className="text-sm tabular text-primary">{s.credential_count ?? '-'}</span>
                      </Td>
                    )}
                    {show('retention_days') && (
                      <Td align="right">
                        <span className="text-sm tabular text-secondary">
                          {s.retention_days ? `${s.retention_days} d` : '-'}
                        </span>
                      </Td>
                    )}
                    {show('created_at') && (
                      <Td>
                        <span className="text-sm text-secondary" title={formatDate(s.created_at)}>
                          {formatRelativeToNow(s.created_at)}
                        </span>
                      </Td>
                    )}
                  </Tr>
                ))}
              </tbody>
            </DataTable>

            <Pagination
              page={table.page}
              pageSize={table.pageSize}
              total={table.total}
              totalPages={table.totalPages}
              onPageChange={table.setPage}
              label="safes"
            />
          </>
        )}
      </Container>

        </>
      )}

      <CreateSafeModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </Stack>
  )
}
