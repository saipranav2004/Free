import { useEffect, useRef, useState } from 'react'

// ---------------------------------------------------------------------------
// Debounce, for values that cost a REQUEST
// ---------------------------------------------------------------------------
// Not the same tool as useDeferredValue, and the difference decides which one
// a given page needs:
//
//   useDeferredValue is a RENDER concession. React keeps the old list on
//     screen while it re-renders with the new value, so typing stays smooth.
//     Nothing is delayed except the paint. That is the right fix for a
//     client-paginated table where each keystroke re-filters and re-sorts a
//     large array synchronously — the textbook INP failure.
//
//   Debounce is a NETWORK concession. It genuinely waits, so eight keystrokes
//     produce one request instead of eight. That is the right fix once the
//     SERVER does the filtering, where useDeferredValue would smooth the
//     render and still fire a request per character.
//
// A server-paged table wants both: debounce what it sends, and let React defer
// the paint of what comes back.
export function useDebouncedValue(value, delay = 250) {
  const [settled, setSettled] = useState(value)
  const previous = useRef(value)

  useEffect(() => {
    // Clearing the box is not a "keystroke" in the sense that matters — the
    // operator wants the full list back NOW, and making them wait a beat for
    // an empty query feels like the control is stuck.
    if (value === '' && previous.current !== '') {
      previous.current = value
      setSettled(value)
      return undefined
    }
    previous.current = value
    const t = setTimeout(() => setSettled(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])

  return settled
}

// isSettling says whether the debounce is still waiting, so a list can show
// that it is about to change rather than appearing to ignore the keystrokes.
export function useIsSettling(value, settled) {
  return value !== settled
}
