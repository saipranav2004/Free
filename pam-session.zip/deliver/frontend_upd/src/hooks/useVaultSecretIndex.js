import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { listSecretPaths } from '../api/serviceIdentity'

// ---------------------------------------------------------------------------
// Every secret's canonical path, as the data plane addresses it
// ---------------------------------------------------------------------------
// A grant is a glob over paths like `prod-db/replicas/pg-reader`, and nothing
// in the console showed those paths anywhere — an administrator writing a
// scope was typing a pattern against an address space they could not see.
//
// This used to assemble the index in the browser: list safes, then list
// folders and credentials for EACH safe. That is 1 + 2N requests for a preview
// that is supposed to feel instant, and it grew with the vault. The server now
// resolves the whole index in one query, using the same join the data plane
// reads through — so the preview cannot disagree with what a service will
// actually be served.
//
// `enabled` keeps it inert until a form that needs it is open.
export function useVaultSecretIndex(enabled) {
  const query = useQuery({
    queryKey: ['admin', 'secret-paths'],
    queryFn: ({ signal }) => listSecretPaths(signal),
    enabled,
    // The vault's shape changes on human timescales, and this only backs a
    // preview, so a minute of staleness is worth not re-fetching it every
    // time a modal opens.
    staleTime: 60_000,
  })

  const secrets = useMemo(
    () =>
      (query.data || []).map((row) => ({
        id: row.credential_id,
        path: row.path,
        safeId: row.safe_id,
        safeName: row.safe_name,
        folderPath: row.folder_path || '',
        name: row.name,
        accountName: row.account_name,
        credentialType: row.credential_type,
        isBreakglass: !!row.is_breakglass,
      })),
    [query.data]
  )

  // The safe list is derived from the index rather than fetched separately —
  // one fewer request, and it cannot disagree with the paths beside it.
  const safes = useMemo(() => {
    const seen = new Map()
    for (const s of secrets) {
      if (s.safeId && !seen.has(s.safeId)) seen.set(s.safeId, { id: s.safeId, name: s.safeName })
    }
    return [...seen.values()].sort((a, b) => a.name.localeCompare(b.name))
  }, [secrets])

  return {
    secrets,
    safes,
    isLoading: query.isLoading,
    // One request now, so "partial" collapses to "it failed". Kept under the
    // same name because the preview still has to say so rather than quietly
    // under-reporting what a scope reaches.
    isPartial: query.isError,
  }
}
