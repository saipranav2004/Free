import { useCallback, useSyncExternalStore } from 'react'
import {
  localZoneName,
  setTimeZoneMode,
  subscribeTimeZone,
  timeZoneMode,
  zoneLabel,
  ZONE_LOCAL,
  ZONE_UTC,
} from '../lib/timezone'

// ---------------------------------------------------------------------------
// The timezone choice, as React state
// ---------------------------------------------------------------------------
// useSyncExternalStore rather than a context, deliberately: the formatters in
// lib/format.js are plain functions called from hundreds of places, and they
// cannot read a context. So the source of truth is a module-level value, and
// this hook is what makes React re-render when it changes.
//
// Without that, flipping the preference would leave every timestamp already on
// screen showing the old zone until something else happened to re-render it —
// which is exactly the kind of half-applied setting that makes a console feel
// unreliable.
export function useTimeZone() {
  const mode = useSyncExternalStore(subscribeTimeZone, timeZoneMode, () => ZONE_LOCAL)

  const setMode = useCallback((next) => setTimeZoneMode(next), [])

  return {
    mode,
    setMode,
    isUTC: mode === ZONE_UTC,
    // The words the UI shows: the short label beside a time, and the full
    // IANA name where there is room to be precise.
    label: zoneLabel(),
    localZone: localZoneName(),
    ZONE_LOCAL,
    ZONE_UTC,
  }
}
