import { useCallback, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { listUsers } from '../api/identity'

// ---------------------------------------------------------------------------
// User id -> username, for display
// ---------------------------------------------------------------------------
// Audit-bearing fields on the vault's machine records — a grant's `granted_by`
// and `revoked_by`, an identity's `owner_id` — store the actor's user id, which
// is right for the record and useless on screen: "granted by
// 73fb3c88-abd7-42f3-9375-1d0b9213b57c" answers nothing a reviewer asked.
//
// Resolved for DISPLAY ONLY. The id stays the stored truth; this just puts a
// name in front of it, with the id kept in the tooltip so it is still
// copyable into a ticket. An id that does not resolve (a deleted account, a
// non-user actor) falls back to a short prefix rather than rendering blank,
// because "who did this" going missing is worse than it being terse.
export function useActorNames(enabled = true) {
  const usersQuery = useQuery({
    queryKey: ['admin', 'identity', 'users', 'for-actor-names'],
    queryFn: ({ signal }) => listUsers(undefined, signal),
    enabled,
    staleTime: 5 * 60 * 1000,
  })

  const byId = useMemo(() => {
    const map = new Map()
    for (const u of usersQuery.data?.users || []) {
      if (u.user_id) map.set(u.user_id, u.username || u.full_name || u.email)
    }
    return map
  }, [usersQuery.data])

  // A username the server already gave us passes through untouched: the actor
  // field falls back to the username when no user id is present, and re-mapping
  // that through an id lookup would only lose it.
  const nameOf = useCallback(
    (id) => {
      if (!id) return null
      return byId.get(id) || (id.length > 20 ? `${id.slice(0, 8)}…` : id)
    },
    [byId]
  )

  return { nameOf, isResolved: usersQuery.isSuccess }
}
