import { useEffect, useRef, useState } from 'react'

// ---------------------------------------------------------------------------
// Acknowledging that a value changed
// ---------------------------------------------------------------------------
// The console animated things arriving and nothing changing: a number updating
// under the reader simply swapped, with no acknowledgement that anything had
// happened. On a screen that polls — active sessions, pending approvals, secret
// reads per minute — that is the difference between a live dashboard and a
// screenshot of one.
//
// Returns a className to spread onto the element holding the value. It is
// applied only when the value actually CHANGES, never on first render: an
// animation on mount would make every page load flicker, which is the opposite
// of what this is for.
export function useValueChange(value, { className = 'value-change' } = {}) {
  const previous = useRef(value)
  const [key, setKey] = useState(0)

  useEffect(() => {
    if (Object.is(previous.current, value)) return
    previous.current = value
    setKey((k) => k + 1)
  }, [value])

  // `key` is returned alongside so a caller can force a remount and restart
  // the animation even when the element itself is unchanged — an animation
  // class alone will not re-run on an element that never left the DOM.
  return { className: key === 0 ? undefined : className, animationKey: key }
}

// useHasChangedSince reports whether a value differs from what it was when the
// component last saw it settle. Used for "since you were away" style marks,
// where the point is not to animate but to remember.
export function useHasChangedSince(value) {
  const seen = useRef(value)
  const [changed, setChanged] = useState(false)

  useEffect(() => {
    if (Object.is(seen.current, value)) return
    setChanged(true)
  }, [value])

  const acknowledge = () => {
    seen.current = value
    setChanged(false)
  }

  return { changed, acknowledge }
}
