import { http } from '../lib/http'

// ---------------------------------------------------------------------------
// Insight figures — the numbers the cards above each listing render
// ---------------------------------------------------------------------------
// Split across two planes, and the split is not cosmetic:
//
//   /pam/insights/*        — scoped to the caller server-side. An operator's
//     sessions card counts their own sessions; an administrator's counts the
//     fleet. The console never asks for a scope, because a scope the client
//     chooses is a scope the client can change.
//
//   /pam/admin/insights/*  — fleet-wide inventory with no per-user meaning.
//     There is no honest "your share" of how many break-glass credentials
//     exist, so these are admin-only rather than scoped.
//
// Every breakdown comes back as an array, never null, so a chart is never
// handed nothing to iterate.

export async function getSessionInsights(signal) {
  const { data } = await http.get('/api/v1/pam/insights/sessions', { signal })
  return data.data
}

export async function getAuditInsights(days, signal) {
  const { data } = await http.get('/api/v1/pam/insights/audit', {
    params: { days },
    signal,
  })
  return data.data
}

export async function getVaultInsights(signal) {
  const { data } = await http.get('/api/v1/pam/admin/insights/vault', { signal })
  return data.data
}

export async function getServiceInsights(signal) {
  const { data } = await http.get('/api/v1/pam/admin/insights/services', { signal })
  return data.data
}
