import { http } from '../lib/http'

// Self-service only, your own sessions (list/end). Org-wide visibility and
// killing someone else's session are Admin Center only now (see
// api/admin.js's listSessions/killSession, which hit
// /api/v1/pam/admin/sessions and /api/v1/pam/admin/actions/sessions/:id/kill).

// Every filter the list can apply travels to the SERVER, including search and
// sort. Filtering or sorting in the browser once the server owns pagination
// would work on the 25 rows currently loaded and present the result as an
// answer about all of them — "no matches" for a session that exists on page 4,
// or "sorted by duration" over one arbitrary page.
export async function listMySessions({
  page = 1,
  pageSize = 25,
  status,
  activeOnly,
  q,
  breakglass,
  sort,
  order,
  signal,
} = {}) {
  const { data } = await http.get('/api/v1/pam/sessions/mine', {
    params: {
      page,
      page_size: pageSize,
      status: status || undefined,
      active: activeOnly ? 'true' : undefined,
      q: q || undefined,
      breakglass: breakglass ? 'true' : undefined,
      sort: sort || undefined,
      order: order || undefined,
    },
    signal,
  })
  return data.data // { sessions, pagination }
}

export async function endSession(id) {
  const { data } = await http.post(`/api/v1/pam/sessions/${id}/end`)
  return data.data
}
