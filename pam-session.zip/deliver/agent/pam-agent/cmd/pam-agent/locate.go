package main

import (
	"errors"
	"flag"
	"fmt"
	"net/url"
	"os"
	"sort"
	"strings"

	"github.com/yourorg/pam-agent/internal/filepicker"
	"github.com/yourorg/pam-agent/internal/launcher"
	"github.com/yourorg/pam-agent/internal/toolpaths"
)

// cmdLocate implements `pam-agent locate`, the escape hatch for tools that
// cannot be found by searching.
//
// WHY THIS EXISTS. Three of the ways the supported applications ship defeat
// every automatic strategy:
//
//	Oracle SQL Developer   a portable ZIP. Oracle's own documentation says to
//	                       extract it into "a folder you control" and NOT into
//	                       Program Files — so it is never on PATH, never in
//	                       the registry, and the one place a glob would look
//	                       is the place the vendor tells you to avoid.
//	Redis Insight (Linux)  a single AppImage, saved wherever its owner saved it.
//	anything unusual       a tool this product has never heard of.
//
// For those, the person who installed it is the only reliable source of
// truth. Asking once and remembering turns an unsolvable problem into a
// ten-second action.
//
// Invoked either from a terminal, or by the console through the URL handler
// (pam-agent://locate?tool=sqldeveloper) so the operator never has to open a
// terminal at all.
func cmdLocate(args []string, configDir string, configDirErr error) error {
	fs := flag.NewFlagSet("locate", flag.ContinueOnError)
	toolFlag := fs.String("tool", "", "candidate id to record a path for (e.g. sqldeveloper)")
	pathFlag := fs.String("path", "", "path to the executable; omit to open a file chooser")
	clearFlag := fs.Bool("clear", false, "forget the remembered path for --tool")
	listFlag := fs.Bool("list", false, "show every remembered path")

	tool := ""
	// The OS hands this over as `pam-agent locate "pam-agent://locate?tool=..."`
	// when the console asks for it, the same shape as launch.
	if len(args) > 0 && args[0] != "" && args[0][0] != '-' {
		if u, err := url.Parse(args[0]); err == nil && u.Scheme != "" {
			tool = u.Query().Get("tool")
			args = args[1:]
		}
	}
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *toolFlag != "" {
		tool = *toolFlag
	}

	if configDirErr != nil {
		return fmt.Errorf("no agent config directory: %w", configDirErr)
	}
	store := toolpaths.Open(configDir)

	if *listFlag {
		ids := store.IDs()
		if len(ids) == 0 {
			fmt.Println("No tool paths remembered on this machine.")
			return nil
		}
		fmt.Println("Remembered tool paths:")
		for _, id := range ids {
			fmt.Printf("  %-22s %s\n", id, store.Get(id))
		}
		return nil
	}

	if tool == "" {
		printLocatableTools(configDir)
		return errors.New("which tool? pass --tool <id> (see the list above), or --list to show what is already remembered")
	}

	if *clearFlag {
		if err := store.Set(tool, ""); err != nil {
			return fmt.Errorf("could not forget %s: %w", tool, err)
		}
		fmt.Printf("Forgot the remembered path for %s.\n", tool)
		return nil
	}

	path := strings.TrimSpace(*pathFlag)
	if path == "" {
		chosen, err := filepicker.Choose("Select the program for " + tool)
		switch {
		case errors.Is(err, filepicker.ErrCancelled):
			fmt.Println("Cancelled — nothing was changed.")
			return nil
		case errors.Is(err, filepicker.ErrNoPicker):
			return fmt.Errorf("this machine has no graphical file chooser; pass the path directly:\n"+
				"  pam-agent locate --tool %s --path /full/path/to/the/program", tool)
		case err != nil:
			return fmt.Errorf("file chooser: %w", err)
		}
		path = chosen
	}

	// Verified before it is stored. A path that does not resolve is worse
	// than none: it would be tried first on every launch and fail every time,
	// and the operator would have no idea their answer was the problem.
	if _, err := os.Stat(path); err != nil {
		return fmt.Errorf("cannot use %q: %w", path, err)
	}
	if err := store.Set(tool, path); err != nil {
		return fmt.Errorf("could not remember %s: %w", tool, err)
	}

	fmt.Printf("Remembered: %s -> %s\n", tool, path)
	fmt.Println("This device will report the tool as available the next time the console asks.")
	return nil
}

// printLocatableTools lists the candidate ids this machine has templates for,
// so an operator who ran `locate` with no arguments is told what to type
// rather than being sent to read documentation.
func printLocatableTools(configDir string) {
	templates, err := launcher.LoadTemplates(configDir)
	if err != nil {
		return
	}
	var ids []string
	seen := map[string]bool{}
	for _, candidates := range templates {
		for _, c := range candidates {
			// A browser candidate needs nothing installed, so there is
			// nothing to locate.
			if c.Kind == "browser" || seen[c.ID] {
				continue
			}
			seen[c.ID] = true
			ids = append(ids, c.ID)
		}
	}
	sort.Strings(ids)
	if len(ids) == 0 {
		return
	}
	fmt.Fprintln(os.Stderr, "Tools this agent can be pointed at:")
	for _, id := range ids {
		fmt.Fprintf(os.Stderr, "  %s\n", id)
	}
	fmt.Fprintln(os.Stderr)
}
