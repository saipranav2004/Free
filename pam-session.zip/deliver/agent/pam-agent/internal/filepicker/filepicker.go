// Package filepicker opens the operating system's own "choose a file" dialog.
//
// It exists so an operator can point at a tool the agent cannot find — a
// portable archive extracted somewhere private, a loose AppImage — without
// typing a path into a terminal. Typing a path is the difference between a
// feature people use and one they give up on.
//
// Zero third-party dependencies, by the same rule as the rest of this module:
// every platform already ships something that can do this, so the
// implementation is "run the thing that is already there".
package filepicker

import (
	"context"
	"errors"
	"fmt"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

// ErrCancelled is returned when the operator closed the dialog without
// choosing. It is a normal outcome, not a failure, and callers should treat
// it as "leave everything as it was".
var ErrCancelled = errors.New("file selection cancelled")

// ErrNoPicker means this machine has no dialog we know how to drive — a
// headless Linux box with neither zenity nor kdialog, typically. The caller
// falls back to asking for a path on the command line.
var ErrNoPicker = errors.New("no graphical file chooser is available on this machine")

// Choose asks the operator to pick a file, with title as the dialog's caption.
//
// Bounded by a timeout: a dialog nobody is sitting in front of must not pin
// the process open forever, which is a real risk when the agent was started
// by a URL handler rather than by a person at a terminal.
func Choose(title string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	switch runtime.GOOS {
	case "darwin":
		return chooseDarwin(ctx, title)
	case "windows":
		return chooseWindows(ctx, title)
	default:
		return chooseLinux(ctx, title)
	}
}

// chooseDarwin uses AppleScript, which is present on every macOS install.
// `choose file` returns an alias; POSIX path converts it to something exec
// can use. A cancel raises error -128, which osascript reports as a non-zero
// exit — indistinguishable from a real failure by exit code alone, so the
// message is what separates them.
func chooseDarwin(ctx context.Context, title string) (string, error) {
	script := fmt.Sprintf(
		`POSIX path of (choose file with prompt %q)`, title)
	out, err := exec.CommandContext(ctx, "osascript", "-e", script).CombinedOutput()
	text := strings.TrimSpace(string(out))
	if err != nil {
		if strings.Contains(text, "-128") || strings.Contains(strings.ToLower(text), "cancel") {
			return "", ErrCancelled
		}
		return "", fmt.Errorf("osascript: %w (%s)", err, text)
	}
	if text == "" {
		return "", ErrCancelled
	}
	return text, nil
}

// chooseWindows drives the standard Win32 open dialog through PowerShell,
// which ships with every supported Windows version. -STA is required:
// the common dialogs are single-threaded-apartment only and silently fail
// without it.
func chooseWindows(ctx context.Context, title string) (string, error) {
	script := fmt.Sprintf(`
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = %q
$dialog.Filter = 'Programs (*.exe;*.bat;*.cmd)|*.exe;*.bat;*.cmd|All files (*.*)|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  [Console]::Out.Write($dialog.FileName)
}`, title)

	out, err := exec.CommandContext(ctx, "powershell", "-NoProfile", "-STA",
		"-ExecutionPolicy", "Bypass", "-Command", script).Output()
	if err != nil {
		return "", fmt.Errorf("powershell file dialog: %w", err)
	}
	path := strings.TrimSpace(string(out))
	if path == "" {
		return "", ErrCancelled
	}
	return path, nil
}

// chooseLinux tries the two dialogs that actually exist on desktop Linux.
// Both return exit code 1 on cancel, which is how a cancel is told apart from
// the binary being absent (handled by LookPath before running anything).
func chooseLinux(ctx context.Context, title string) (string, error) {
	type picker struct {
		bin  string
		args []string
	}
	for _, p := range []picker{
		{"zenity", []string{"--file-selection", "--title", title}},
		{"kdialog", []string{"--getopenfilename", ".", "--title", title}},
	} {
		if _, err := exec.LookPath(p.bin); err != nil {
			continue
		}
		out, err := exec.CommandContext(ctx, p.bin, p.args...).Output()
		if err != nil {
			var exitErr *exec.ExitError
			if errors.As(err, &exitErr) {
				// Both report a cancelled dialog as exit 1 with no output.
				return "", ErrCancelled
			}
			return "", fmt.Errorf("%s: %w", p.bin, err)
		}
		path := strings.TrimSpace(string(out))
		if path == "" {
			return "", ErrCancelled
		}
		return path, nil
	}
	return "", ErrNoPicker
}
