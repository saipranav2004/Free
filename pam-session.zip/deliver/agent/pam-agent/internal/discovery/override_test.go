package discovery

import (
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

// writeExecutable creates a file the running OS would consider runnable.
func writeExecutable(t *testing.T, dir, name string) string {
	t.Helper()
	if runtime.GOOS == "windows" && filepath.Ext(name) == "" {
		name += ".exe"
	}
	p := filepath.Join(dir, name)
	if err := os.WriteFile(p, []byte("#!/bin/sh\nexit 0\n"), 0o755); err != nil {
		t.Fatalf("write %s: %v", p, err)
	}
	return p
}

// The Oracle case, which is the whole reason the override exists: a portable
// archive extracted somewhere private. Nothing on PATH, nothing in the
// registry, and the vendor's own instructions say not to put it where a glob
// would look.
func TestAnOperatorSuppliedPathFindsWhatSearchingCannot(t *testing.T) {
	extracted := t.TempDir() // stands in for ~/somewhere/sqldeveloper
	exe := writeExecutable(t, extracted, "sqldeveloper")

	spec := Spec{BinaryNames: []string{"definitely-not-a-real-binary-xyz-123"}}

	if Locate(spec).Found() {
		t.Fatal("the control case is broken: this spec should find nothing")
	}
	got := LocateWithOverride(spec, exe)
	if !got.Found() {
		t.Fatal("an operator-supplied path was ignored — this is the only way a portable archive is ever found")
	}
	if got.Path != exe {
		t.Fatalf("resolved to %q, want %q", got.Path, exe)
	}
}

// Pointing at the extracted FOLDER rather than the executable inside it is
// what people actually do, so it has to work.
func TestPointingAtTheExtractedFolderWorksToo(t *testing.T) {
	extracted := t.TempDir()
	exe := writeExecutable(t, extracted, "sqldeveloper")

	got := LocateWithOverride(Spec{}, extracted)
	if !got.Found() {
		t.Fatal("pointing at the extracted folder found nothing")
	}
	if got.Path != exe {
		t.Fatalf("resolved to %q, want the executable inside the folder (%q)", got.Path, exe)
	}
}

// A remembered path that no longer resolves — folder deleted, drive
// unmounted — must not poison every future launch. Discovery carries on.
func TestAStaleOverrideFallsBackToNormalDiscovery(t *testing.T) {
	realDir := t.TempDir()
	real := writeExecutable(t, realDir, "realtool")

	spec := Spec{AbsolutePathGlobs: map[string][]string{runtime.GOOS: {real}}}

	got := LocateWithOverride(spec, filepath.Join(t.TempDir(), "gone", "vanished"))
	if !got.Found() {
		t.Fatal("a stale override broke discovery entirely instead of being skipped")
	}
	if got.Path != real {
		t.Fatalf("resolved to %q, want the real tool at %q", got.Path, real)
	}
}

// The override must win over a tool that IS on PATH — an operator who points
// at a specific build is making a deliberate choice.
func TestTheOverrideWinsOverPath(t *testing.T) {
	dir := t.TempDir()
	chosen := writeExecutable(t, dir, "chosen-build")

	// "go" is genuinely on PATH in this environment.
	spec := Spec{BinaryNames: []string{"go"}}
	if !Locate(spec).Found() {
		t.Skip("go is not on PATH here, so there is nothing to out-rank")
	}

	got := LocateWithOverride(spec, chosen)
	if got.Path != chosen {
		t.Fatalf("resolved to %q, want the operator's choice %q", got.Path, chosen)
	}
}

// A portable archive one directory beneath a conventional root is the shape
// that actually occurs: ~/Downloads/sqldeveloper/sqldeveloper.
func TestPortableSearchFindsAnExtractedArchiveOneLevelDown(t *testing.T) {
	root := t.TempDir()
	inner := filepath.Join(root, "sqldeveloper-26.2.0")
	if err := os.MkdirAll(inner, 0o755); err != nil {
		t.Fatalf("mkdir: %v", err)
	}
	name := "sqldeveloper"
	if runtime.GOOS == "windows" {
		name += ".exe"
	}
	exe := writeExecutable(t, inner, name)

	spec := Spec{
		BinaryNames:   []string{"definitely-not-a-real-binary-xyz-123"},
		PortableRoots: []string{root},
		PortableNames: []string{name},
	}
	got := Locate(spec)
	if !got.Found() {
		t.Fatal("an extracted archive one level under a search root was not found")
	}
	if got.Path != exe {
		t.Fatalf("resolved to %q, want %q", got.Path, exe)
	}
}

// A spec with no portable names must not start searching the filesystem.
func TestPortableSearchIsInertWithoutNames(t *testing.T) {
	root := t.TempDir()
	writeExecutable(t, root, "something")
	if Locate(Spec{PortableRoots: []string{root}}).Found() {
		t.Fatal("portable search ran without any names to look for")
	}
}
