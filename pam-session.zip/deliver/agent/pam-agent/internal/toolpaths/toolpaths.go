// Package toolpaths remembers where an operator said a tool actually is.
//
// Three of the six ways the supported applications are distributed cannot be
// found by searching: a portable archive extracted wherever its owner chose
// (Oracle SQL Developer), a single loose AppImage, and anything installed
// somewhere no convention covers. For those, the only reliable source of
// truth is the person who put it there.
//
// So the agent asks, once, and remembers. That turns an unsolvable guessing
// problem into a ten-second action, and it covers every tool this product has
// never heard of as a side effect.
//
// Stored next to the device key in the agent's own config directory: this is
// machine-local preference, not account state, because the same person on two
// laptops genuinely has two different answers.
package toolpaths

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

const fileName = "tool-paths.json"

// Store is the on-disk map of candidate id -> absolute path.
type Store struct {
	mu   sync.Mutex
	dir  string
	data map[string]string
}

// Open loads the store for a config directory. A missing or corrupt file is
// an empty store, never an error: a bad overrides file must not stop the
// agent launching things it can find on its own.
func Open(configDir string) *Store {
	s := &Store{dir: configDir, data: map[string]string{}}
	raw, err := os.ReadFile(filepath.Join(configDir, fileName))
	if err != nil {
		return s
	}
	var parsed map[string]string
	if err := json.Unmarshal(raw, &parsed); err != nil {
		return s
	}
	for k, v := range parsed {
		if k != "" && strings.TrimSpace(v) != "" {
			s.data[k] = v
		}
	}
	return s
}

// Get returns the remembered path for a candidate, or "".
func (s *Store) Get(candidateID string) string {
	if s == nil {
		return ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.data[candidateID]
}

// Set records a path and writes the file through a temporary file, so an
// interrupted write cannot leave a truncated one behind.
func (s *Store) Set(candidateID, path string) error {
	if s == nil {
		return fmt.Errorf("no tool-path store")
	}
	if candidateID == "" {
		return fmt.Errorf("candidate id is required")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if strings.TrimSpace(path) == "" {
		delete(s.data, candidateID)
	} else {
		s.data[candidateID] = path
	}
	return s.writeLocked()
}

// All returns a copy, for the capability report.
func (s *Store) All() map[string]string {
	if s == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make(map[string]string, len(s.data))
	for k, v := range s.data {
		out[k] = v
	}
	return out
}

// IDs lists the candidates with a remembered path, sorted, for `pam-agent
// locate --list`.
func (s *Store) IDs() []string {
	out := make([]string, 0, len(s.data))
	for k := range s.All() {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func (s *Store) writeLocked() error {
	if s.dir == "" {
		return fmt.Errorf("no config directory to write to")
	}
	if err := os.MkdirAll(s.dir, 0o700); err != nil {
		return err
	}
	encoded, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	final := filepath.Join(s.dir, fileName)
	tmp, err := os.CreateTemp(s.dir, fileName+".*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)
	if _, err := tmp.Write(encoded); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Chmod(tmpName, 0o600); err != nil {
		return err
	}
	return os.Rename(tmpName, final)
}
