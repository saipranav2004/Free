//go:build darwin || linux

package launcher

import (
	"bytes"
	"os"
	"testing"
	"time"
)

// CLOSING THE TERMINAL WINDOW MUST END THE SESSION.
//
// The relay is the thing that reports a session's end and uploads its
// recording, and it runs INSIDE the operator's terminal. When that window is
// closed the emulator dies and the relay is signalled — and before Stop
// existed, Go's default action for SIGHUP killed the process outright, so the
// report and the upload never ran. PAM kept the session ACTIVE forever, still
// holding its grant, and the recording was a header with no events.
//
// Measured against the real agent before the fix: `\q` ended the session in
// 1s with a 92-event recording; closing the window left it ACTIVE past 30s
// with an empty one. After: 2s, with the events captured up to that point.
//
// This covers the mechanism cmd/pam-agent's signal handler depends on: that
// closing Stop makes RunRelay kill the tool and RETURN NORMALLY, so the
// caller's reporting path runs at all.
func TestStopEndsTheSessionAndStillReturnsNormally(t *testing.T) {
	in, err := os.Open(os.DevNull)
	if err != nil {
		t.Fatalf("open /dev/null: %v", err)
	}
	defer in.Close()

	stop := make(chan struct{})
	var out bytes.Buffer
	done := make(chan RelayResult, 1)
	errc := make(chan error, 1)

	go func() {
		// A tool that would otherwise outlive the test by a wide margin, so a
		// normal return can only be the Stop taking effect.
		res, runErr := RunRelay(RelayOptions{
			Exec: "sleep", Args: []string{"120"},
			In: in, Out: &out, Stop: stop,
		})
		done <- res
		errc <- runErr
	}()

	// Let the child actually start before asking for it to stop, or the kill
	// races process creation and proves nothing.
	time.Sleep(400 * time.Millisecond)
	close(stop)

	select {
	case res := <-done:
		if runErr := <-errc; runErr != nil {
			t.Fatalf("Stop must return normally so the caller can report the session end, got: %v", runErr)
		}
		// The tool was killed, so a zero exit would mean it finished on its
		// own and Stop did nothing.
		if res.ExitCode == 0 {
			t.Fatal("expected a non-zero exit from a killed tool; Stop appears not to have taken effect")
		}
	case <-time.After(20 * time.Second):
		t.Fatal("RunRelay did not return after Stop — this is the hang that left sessions ACTIVE forever")
	}
}

// A nil Stop is the pre-existing behaviour and must keep working: a tool that
// exits on its own still ends the session with no early-stop involved.
func TestNilStopLeavesNormalExitUnchanged(t *testing.T) {
	in, err := os.Open(os.DevNull)
	if err != nil {
		t.Fatalf("open /dev/null: %v", err)
	}
	defer in.Close()

	var out bytes.Buffer
	res, runErr := RunRelay(RelayOptions{
		Exec: "true", In: in, Out: &out, Stop: nil,
	})
	if runErr != nil {
		t.Fatalf("RunRelay: %v", runErr)
	}
	if res.ExitCode != 0 {
		t.Fatalf("a tool that exited cleanly reported exit code %d", res.ExitCode)
	}
}
