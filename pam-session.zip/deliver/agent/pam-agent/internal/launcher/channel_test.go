package launcher

import (
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/discovery"
)

// A resource offering a terminal client that is NOT installed and a desktop
// app that IS. This is the exact shape that produced the reported behaviour:
// ask for a terminal, silently get a GUI.
func mixedChannelCandidates() []Candidate {
	return []Candidate{
		{ID: "psql", Kind: "cli", Command: "psql", CredentialInjection: "none",
			Discovery: notFoundSpec(), InstallHint: "Install the PostgreSQL client tools."},
		{ID: "pgadmin4", Kind: "gui", Command: "go", CredentialInjection: "none",
			Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}
}

// The core of the channel model. Asking for a terminal and not having one is
// a failure with a remedy — it is NOT permission to open something else.
func TestAskingForCLINeverSilentlyOpensTheDesktopApp(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "h", Port: 5432, AccountName: "u", Password: "p",
		Channel: "cli",
	}

	_, chosen, err := SelectAndBuildCommand(resolved, mixedChannelCandidates(), t.TempDir(), testLogger())
	if err == nil {
		t.Fatalf("asking for cli launched %q instead of failing — this is the silent fallback the channel model exists to end", chosen.ID)
	}
	// And the failure must name the thing to install, not just say no.
	if !strings.Contains(err.Error(), "psql") && !strings.Contains(err.Error(), "PostgreSQL") {
		t.Fatalf("the error does not name the missing terminal client: %v", err)
	}
}

// The same list, asked the other way, must open the desktop app — the point
// is honouring the choice, not refusing one of them.
func TestAskingForDesktopOpensTheDesktopApp(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "h", Port: 5432, AccountName: "u", Password: "p",
		Channel: "desktop",
	}

	_, chosen, err := SelectAndBuildCommand(resolved, mixedChannelCandidates(), t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("asking for desktop failed even though the desktop app is present: %v", err)
	}
	if chosen.ID != "pgadmin4" {
		t.Fatalf("chose %q, want pgadmin4", chosen.ID)
	}
}

// Falling through to a SECOND candidate of the SAME channel is not a
// substitution and must keep working — Oracle has sqlplus and sqlcl, and a
// machine with only one of them should still open a terminal.
func TestFallingThroughWithinOneChannelStillWorks(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "oracle", Host: "h", Port: 1521, AccountName: "u", Password: "p",
		Channel: "cli",
	}
	candidates := []Candidate{
		{ID: "sqlplus", Kind: "cli", Command: "sqlplus", CredentialInjection: "none", Discovery: notFoundSpec()},
		{ID: "sqlcl", Kind: "cli", Command: "go", CredentialInjection: "none",
			Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
		{ID: "sqldeveloper", Kind: "gui", Command: "go", CredentialInjection: "none",
			Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}

	_, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("a second terminal client was available but the launch failed: %v", err)
	}
	if chosen.ID != "sqlcl" {
		t.Fatalf("chose %q, want sqlcl — the other CLI, not the GUI", chosen.ID)
	}
}

// Asking for a channel this resource type has no client for is a catalogue
// mismatch, and must not be reported as something the operator can install.
func TestAskingForAChannelThatDoesNotExistSaysSo(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "metabase", Host: "h", Port: 3000, Channel: "cli",
	}
	candidates := []Candidate{
		{ID: "metabase-web", Kind: "browser", Command: "{{.ConsoleURL}}", CredentialInjection: "clipboard"},
	}

	_, _, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err == nil {
		t.Fatal("asking metabase for a terminal should fail — it has no terminal client")
	}
	if !strings.Contains(err.Error(), "cannot be opened in cli") {
		t.Fatalf("the error should say the channel does not exist, not blame an install: %v", err)
	}
}

// An empty channel is what a launch issued before this feature carries. It
// must keep the old behaviour rather than refusing everything.
func TestAnEmptyChannelPreservesTheOldBehaviour(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "h", Port: 5432, AccountName: "u", Password: "p",
	}
	_, chosen, err := SelectAndBuildCommand(resolved, mixedChannelCandidates(), t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("a channel-less launch failed: %v", err)
	}
	if chosen.ID != "pgadmin4" {
		t.Fatalf("chose %q, want the old first-usable behaviour (pgadmin4)", chosen.ID)
	}
}
