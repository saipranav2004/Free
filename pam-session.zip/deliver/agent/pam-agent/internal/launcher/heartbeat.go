package launcher

import (
	"log/slog"
	"sync"
	"time"
)

// ── Session heartbeat ───────────────────────────────────────────────────────
//
// While a session is open the agent checks in with the server, and the ANSWER
// is what makes this worth having. Two things were impossible without it:
//
//	An administrator's force-terminate reached the database and stopped there.
//	The row said KILLED while the operator's psql was still connected, because
//	PAM is not in that data path and had no way to reach a process on someone
//	else's machine.
//
//	An agent that died — lid closed, process killed, VPN dropped — left the
//	session ACTIVE until the next server restart, because nothing on the server
//	could tell a working session from an abandoned one.
//
// The agent is not being watched. It is asking, and the reply carries orders.

// HeartbeatFunc reports in and returns whether to stop, and why.
type HeartbeatFunc func() (terminate bool, reason string, intervalSeconds int, err error)

// HeartbeatLoop runs a heartbeat for the life of one session.
type HeartbeatLoop struct {
	beat     HeartbeatFunc
	log      *slog.Logger
	interval time.Duration

	stopOnce sync.Once
	stop     chan struct{}
	done     chan struct{}
}

// NewHeartbeatLoop builds a loop. interval is the starting cadence; the server
// can retune it in any reply.
func NewHeartbeatLoop(beat HeartbeatFunc, interval time.Duration, log *slog.Logger) *HeartbeatLoop {
	if interval <= 0 {
		interval = 10 * time.Second
	}
	return &HeartbeatLoop{
		beat:     beat,
		log:      log,
		interval: interval,
		stop:     make(chan struct{}),
		done:     make(chan struct{}),
	}
}

// Start begins checking in. onTerminate is called at most once, from the
// loop's own goroutine, when the server says to stop — the caller uses it to
// kill the session's process.
//
// A FAILED heartbeat is not a terminate. A flaky network is the common case by
// a wide margin, and killing an operator's live session because one request
// timed out would be a far worse bug than the one this fixes. The server's
// reaper is the backstop for an agent that has genuinely gone: it closes the
// row, and this agent will be told to stop the moment it can reach the server
// again.
func (h *HeartbeatLoop) Start(onTerminate func(reason string)) {
	go func() {
		defer close(h.done)
		timer := time.NewTimer(h.interval)
		defer timer.Stop()

		for {
			select {
			case <-h.stop:
				return
			case <-timer.C:
			}

			terminate, reason, intervalSeconds, err := h.beat()
			if err != nil {
				h.log.Debug("session.heartbeat.failed", "error", err.Error(),
					"note", "not treated as a terminate; a flaky network must not end a live session")
				timer.Reset(h.interval)
				continue
			}
			if intervalSeconds > 0 {
				next := time.Duration(intervalSeconds) * time.Second
				if next != h.interval {
					h.log.Debug("session.heartbeat.retuned", "interval", next.String())
					h.interval = next
				}
			}
			// Debug, not Info: a healthy session beats every ten seconds for
			// its whole life, and logging each one at Info would bury
			// everything else the agent has to say.
			h.log.Debug("session.heartbeat.ok", "interval", h.interval.String())
			if terminate {
				h.log.Info("session.heartbeat.terminate", "reason", reason)
				if onTerminate != nil {
					onTerminate(reason)
				}
				return
			}
			timer.Reset(h.interval)
		}
	}()
}

// Stop ends the loop and waits for it to finish, so a session that has already
// closed does not leave a goroutine reporting on it.
func (h *HeartbeatLoop) Stop() {
	h.stopOnce.Do(func() { close(h.stop) })
	<-h.done
}
