// pam-agent/internal/launcher/capabilities.go
//
// WHAT THIS MACHINE CAN ACTUALLY OPEN, answered before anybody clicks.
//
// The console used to find out the same way the operator did: hand off to
// pam-agent:// and see what happened. So a user whose laptop had no psql
// clicked "Open in Desktop App", was told "Handing off to the desktop
// agent", and then nothing opened — the failure was real and the agent even
// reported it, but only AFTER a session had been created and the browser had
// already claimed success.
//
// This is the other half of that report: the agent runs the SAME discovery it
// would run at launch time, for every resource type it has a template for,
// and sends the result when it pairs. PAM stores it against the device, so
// the console can grey out a button and name the missing tool instead of
// promising a handoff it has no reason to believe in.
//
// It is a snapshot, not a live query — the agent is not resident, so there is
// nothing to ask at the moment of the click. It is refreshed on every launch
// resolve, which is the only other moment the agent is running and talking to
// the server. That means a tool installed after pairing is not known until the
// next launch attempt, and that attempt still fails with the exact
// tool_not_installed reason it always did. Stale in the safe direction: the
// console under-promises and the launch path stays authoritative.
package launcher

import (
	"runtime"
	"sort"

	"github.com/yourorg/pam-agent/internal/discovery"
)

// TypeCapability is what this machine can do with one resource type.
type TypeCapability struct {
	ResourceType string `json:"resource_type"`

	// Kinds actually available here, drawn from the candidates that were
	// found: "cli", "gui", "browser". A browser candidate is always
	// available — every machine has a browser — which is why a type whose
	// only candidate is a browser is never reported as unsupported.
	Kinds []string `json:"kinds"`

	// Tools is the candidate IDs that were found, in template order, so the
	// console can say "psql" rather than "a PostgreSQL client".
	Tools []string `json:"tools"`

	// Missing is every candidate that was looked for and not found, with the
	// install hint from the template. This is what lets the console say which
	// thing to install without the operator having to launch and fail first.
	Missing []MissingTool `json:"missing,omitempty"`
}

// Supported reports whether anything on this machine could open the type.
func (c TypeCapability) Supported() bool { return len(c.Kinds) > 0 }

// DeviceCapabilities is the whole report: one entry per resource type the
// agent has a template for.
type DeviceCapabilities struct {
	OS      string           `json:"os"`
	Arch    string           `json:"arch"`
	Types   []TypeCapability `json:"types"`
	Version string           `json:"agent_version,omitempty"`

	// ScreenRecorder reports whether ffmpeg is present, which is what decides
	// whether a DESKTOP (gui) session on a record-required resource can be
	// opened at all. Without it the agent must refuse such a launch, so the
	// console needs to know before offering the button.
	ScreenRecorder bool `json:"screen_recorder"`
}

// Capabilities runs discovery over every template on this machine.
//
// screenRecorderAvailable is injected rather than called directly so this
// stays pure logic that a test can drive; cmd/pam-agent passes
// recorder.ScreenRecorderAvailable.
func Capabilities(templates map[string][]Candidate, version string, screenRecorderAvailable bool, overrides map[string]string) DeviceCapabilities {
	caps := DeviceCapabilities{
		OS:             runtime.GOOS,
		Arch:           runtime.GOARCH,
		Version:        version,
		ScreenRecorder: screenRecorderAvailable,
	}

	types := make([]string, 0, len(templates))
	for t := range templates {
		types = append(types, t)
	}
	// Sorted so the stored JSON is stable and two reports from an unchanged
	// machine compare equal — otherwise every launch would look like a change.
	sort.Strings(types)

	for _, t := range types {
		tc := TypeCapability{ResourceType: t}
		seen := map[string]bool{}
		for i := range templates[t] {
			cand := &templates[t][i]

			if cand.Kind == "browser" {
				// Never "missing": opening the OS default browser needs
				// nothing installed. Whether the RESOURCE has a console_url
				// is a server-side fact the agent cannot see from here, so
				// that stays a launch-time answer.
				if !seen[cand.Kind] {
					seen[cand.Kind] = true
					tc.Kinds = append(tc.Kinds, cand.Kind)
				}
				tc.Tools = append(tc.Tools, cand.ID)
				continue
			}

			// An operator-supplied path wins over discovery, and is the only
			// thing that finds a portable archive or a loose AppImage — see
			// discovery.LocateWithOverride.
			if discovery.LocateWithOverride(cand.Discovery, overrides[cand.ID]).Found() {
				if !seen[cand.Kind] {
					seen[cand.Kind] = true
					tc.Kinds = append(tc.Kinds, cand.Kind)
				}
				tc.Tools = append(tc.Tools, cand.ID)
				continue
			}

			tc.Missing = append(tc.Missing, MissingTool{
				ID: cand.ID, Kind: cand.Kind, Command: cand.Command,
				InstallHint: cand.InstallHint,
				// Locatable says the operator could resolve this themselves by
				// pointing at the file. The console uses it to decide whether
				// to offer "Locate it myself" beside "Install it" — offering
				// it for a browser, which needs nothing installed, would be
				// noise.
				Locatable: cand.Kind != "browser",
			})
		}
		caps.Types = append(caps.Types, tc)
	}
	return caps
}
