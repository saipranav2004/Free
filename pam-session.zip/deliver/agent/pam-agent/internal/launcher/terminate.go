package launcher

import (
	"os/exec"
	"sync"
)

// watchTerminate kills cmd if the terminate channel fires before the returned
// stop function is called.
//
// This is how an administrator's force-terminate finally reaches the operator's
// machine. It used to reach the database row and stop there: the row said
// KILLED while the client kept running, because PAM is not in that data path.
// The heartbeat brought the instruction back; this acts on it.
//
// Killing the process the agent started ends the tool inside it and unblocks
// the Wait/Run the caller is parked on, so the normal end-of-session path runs
// afterwards unchanged — the session is reported, the recording is uploaded,
// nothing is special-cased.
//
// A nil channel never fires, which is what a launch with no heartbeat passes.
// Returns a stop function that is safe to call more than once.
func watchTerminate(terminate <-chan struct{}, cmd *exec.Cmd) func() {
	if terminate == nil {
		return func() {}
	}
	done := make(chan struct{})
	var once sync.Once
	go func() {
		select {
		case <-terminate:
			if cmd != nil && cmd.Process != nil {
				// Kill, not Interrupt: an interactive client sitting on a
				// prompt may ignore a signal it would normally handle, and a
				// termination an administrator ordered has to be certain.
				_ = cmd.Process.Kill()
			}
		case <-done:
		}
	}()
	return func() { once.Do(func() { close(done) }) }
}
