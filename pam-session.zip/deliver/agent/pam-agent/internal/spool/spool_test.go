package spool

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

// The guarantee the whole package exists for: the recording is on disk before
// any upload is attempted, so a failed upload cannot lose it.
func TestARecordingIsOnDiskBeforeItIsUploaded(t *testing.T) {
	store, err := Open(t.TempDir())
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	blob := []byte("asciicast-bytes")
	entry, err := store.Add(Entry{SessionID: "sess-1", AgentDeviceID: "dev-1", Format: "asciicast", Status: "COMPLETED"}, blob)
	if err != nil {
		t.Fatalf("Add: %v", err)
	}

	pending, err := store.Pending()
	if err != nil {
		t.Fatalf("Pending: %v", err)
	}
	if len(pending) != 1 {
		t.Fatalf("expected the recording to be waiting on disk, got %d entries", len(pending))
	}
	got, err := pending[0].Blob()
	if err != nil || string(got) != string(blob) {
		t.Fatalf("spooled bytes came back as %q (%v)", got, err)
	}
	if pending[0].SessionID != "sess-1" || pending[0].Format != "asciicast" {
		t.Fatalf("the manifest lost its context: %+v", pending[0])
	}

	// Only once the server has it does the file go.
	store.Done(entry)
	pending, _ = store.Pending()
	if len(pending) != 0 {
		t.Fatalf("a delivered recording is still spooled: %d", len(pending))
	}
}

// A backlog must drain oldest-first, so recordings arrive in the order they
// were made rather than newest-wins.
func TestPendingIsOldestFirst(t *testing.T) {
	store, _ := Open(t.TempDir())
	for _, id := range []string{"a", "b", "c"} {
		if _, err := store.Add(Entry{SessionID: id, Format: "asciicast"}, []byte(id)); err != nil {
			t.Fatalf("Add(%s): %v", id, err)
		}
		time.Sleep(2 * time.Millisecond) // distinct timestamps in the filename
	}
	pending, _ := store.Pending()
	if len(pending) != 3 {
		t.Fatalf("got %d entries", len(pending))
	}
	for i, want := range []string{"a", "b", "c"} {
		if pending[i].SessionID != want {
			t.Fatalf("position %d is %q, want %q — a backlog must drain in recording order", i, pending[i].SessionID, want)
		}
	}
}

// A crash between the two writes leaves a blob with no manifest. It must be
// cleaned up, not retried forever or uploaded as a recording with no context.
func TestAnOrphanedBlobIsSweptAway(t *testing.T) {
	dir := t.TempDir()
	store, _ := Open(dir)
	orphan := filepath.Join(dir, dirName, "orphan.blob")
	if err := os.WriteFile(orphan, []byte("half-written"), 0o600); err != nil {
		t.Fatalf("write orphan: %v", err)
	}
	if removed := store.Sweep(0); removed != 1 {
		t.Fatalf("swept %d, want 1", removed)
	}
	if _, err := os.Stat(orphan); err == nil {
		t.Fatal("the orphaned blob is still there")
	}
}

// Something the server will never accept must not be retried for the life of
// the machine.
func TestAnAncientRecordingIsGivenUpOn(t *testing.T) {
	store, _ := Open(t.TempDir())
	entry, _ := store.Add(Entry{SessionID: "ancient", Format: "asciicast"}, []byte("x"))
	// Rewrite the manifest as if it had been spooled long ago.
	entry.SpooledAt = time.Now().Add(-30 * 24 * time.Hour)
	if _, err := store.Add(*entry, []byte("x")); err != nil {
		t.Fatalf("re-add: %v", err)
	}
	_ = store.Sweep(14 * 24 * time.Hour)
	for _, e := range mustPending(t, store) {
		if e.Age() > 14*24*time.Hour {
			t.Fatalf("a %s-old recording survived the sweep", e.Age().Round(time.Hour))
		}
	}
}

func mustPending(t *testing.T, s *Store) []*Entry {
	t.Helper()
	p, err := s.Pending()
	if err != nil {
		t.Fatalf("Pending: %v", err)
	}
	return p
}

// A truncated write must never be delivered as if it were a whole recording.
func TestWritesAreAtomic(t *testing.T) {
	dir := t.TempDir()
	target := filepath.Join(dir, "x.blob")
	if err := writeFileAtomic(target, []byte("complete")); err != nil {
		t.Fatalf("writeFileAtomic: %v", err)
	}
	got, _ := os.ReadFile(target)
	if string(got) != "complete" {
		t.Fatalf("got %q", got)
	}
	// No temporary files left behind.
	entries, _ := os.ReadDir(dir)
	if len(entries) != 1 {
		t.Fatalf("writeFileAtomic left %d files behind", len(entries))
	}
}
