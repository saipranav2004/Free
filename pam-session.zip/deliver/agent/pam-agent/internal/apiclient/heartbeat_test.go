package apiclient

import (
	"crypto/ed25519"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

// The server answers inside the standard envelope. The client must read what
// is INSIDE `data`, not look for another `data` within it.
//
// Getting this wrong is silent: every field decodes to its zero value, so
// terminate comes back false on every reply and an administrator's
// force-terminate is answered correctly by the server and then discarded by
// the agent. It cost a live debugging session to find, because nothing
// errored — the tool simply kept running.
func TestHeartbeatReadsTheEnvelopesDataField(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.URL.Path; got != "/api/v1/pam/agent/sessions/sess-1/heartbeat" {
			t.Errorf("unexpected path %q", got)
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"success": true,
			"message": "ok",
			"data": map[string]any{
				"terminate":        true,
				"reason":           "Investigating unusual activity",
				"interval_seconds": 15,
			},
		})
	}))
	defer srv.Close()

	_, priv, err := ed25519.GenerateKey(nil)
	if err != nil {
		t.Fatalf("GenerateKey: %v", err)
	}
	client := &Client{ServerURL: srv.URL, httpClient: srv.Client()}

	res, err := client.Heartbeat("sess-1", "dev-1", priv)
	if err != nil {
		t.Fatalf("Heartbeat: %v", err)
	}
	if !res.Terminate {
		t.Fatal("terminate decoded as false — the agent would ignore a force-terminate entirely")
	}
	if res.Reason != "Investigating unusual activity" {
		t.Fatalf("reason %q — the operator would see no explanation", res.Reason)
	}
	if res.IntervalSeconds != 15 {
		t.Fatalf("interval %d, want 15 — the server cannot retune the cadence", res.IntervalSeconds)
	}
}

// A healthy session must decode as "carry on", not as a terminate.
func TestHeartbeatDecodesACarryOnReply(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{
			"success": true,
			"data":    map[string]any{"terminate": false, "interval_seconds": 10},
		})
	}))
	defer srv.Close()

	_, priv, _ := ed25519.GenerateKey(nil)
	client := &Client{ServerURL: srv.URL, httpClient: srv.Client()}

	res, err := client.Heartbeat("sess-2", "dev-1", priv)
	if err != nil {
		t.Fatalf("Heartbeat: %v", err)
	}
	if res.Terminate {
		t.Fatal("a healthy session decoded as a terminate — every session would be killed after one beat")
	}
	if res.IntervalSeconds != 10 {
		t.Fatalf("interval %d, want 10", res.IntervalSeconds)
	}
}
