#!/bin/bash
# Seed ACTIVE sessions so the donut, the break-glass card and the
# longest-running figure have something to draw.
#
# Must run AFTER the API is up: there is a startup orphan-reaper that marks
# every ACTIVE row FAILED on boot ("the server restarted while this session
# was still marked active"), which is correct behaviour and will quietly
# undo a seed done beforehand.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
ROOT_ID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q <<SQL
DELETE FROM pam.pam_connection_sessions WHERE id LIKE 'donut-test%';
INSERT INTO pam.pam_connection_sessions
  (id, user_id, username, resource_id, resource_name, resource_type, protocol, status, started_at, duration_seconds, is_breakglass, recording_required, created_at, updated_at)
VALUES
  ('donut-test-1','$ROOT_ID','root','r-pg','prod-postgres','postgresql','psql','ACTIVE', NOW() - INTERVAL '2 hours',    0, false, false, NOW(), NOW()),
  ('donut-test-2','$ROOT_ID','root','r-pg','prod-postgres','postgresql','psql','ACTIVE', NOW() - INTERVAL '30 minutes', 0, false, false, NOW(), NOW()),
  ('donut-test-3','$ROOT_ID','root','r-rd','cache','redis','redis-cli','ACTIVE',        NOW() - INTERVAL '10 minutes', 0, true,  false, NOW(), NOW()),
  ('donut-test-4','$ROOT_ID','root','r-mg','docs','mongodb','mongosh','ACTIVE',         NOW() - INTERVAL '5 minutes',  0, false, false, NOW(), NOW());
SQL
echo "seeded 4 active sessions (1 break-glass, oldest 2h)"
