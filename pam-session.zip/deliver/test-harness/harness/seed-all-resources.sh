#!/bin/bash
# One resource per integrated type, so the channel matrix can be driven for
# real instead of reasoned about. Hosts/ports are the local fixtures where one
# exists and placeholders otherwise — the matrix answers what a type SUPPORTS,
# which does not depend on the target being reachable.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
RID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")

ins() { # type name host port connect_mode console_url
  psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "
  DELETE FROM pam.pam_resources WHERE id='matrix-$1';
  INSERT INTO pam.pam_resources
    (id,name,description,resource_type,host,port,connect_mode,console_url,is_active,always_record,created_by,created_at,updated_at)
  VALUES ('matrix-$1','$2','Channel-matrix fixture','$1','$3',$4,'$5',NULLIF('$6',''),true,true,'$RID',NOW(),NOW());"
}

ins postgresql matrix-postgres   127.0.0.1 5433 web_terminal   ''
ins redis      matrix-redis      127.0.0.1 6379 web_terminal   ''
ins mongodb    matrix-mongo      127.0.0.1 27017 web_terminal  ''
ins oracle     matrix-oracle     127.0.0.1 1521 web_terminal   ''
ins clickhouse matrix-clickhouse 127.0.0.1 8123 embed_redirect 'http://127.0.0.1:8123/play'
ins minio      matrix-minio      127.0.0.1 9001 embed_redirect 'http://127.0.0.1:9001'
ins qdrant     matrix-qdrant     127.0.0.1 6333 embed_redirect 'http://127.0.0.1:6333/dashboard'
ins metabase   matrix-metabase   127.0.0.1 3000 embed_redirect 'http://127.0.0.1:3000'
ins langfuse   matrix-langfuse   127.0.0.1 3001 embed_redirect 'http://127.0.0.1:3001'

psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c \
  "SELECT count(*) FROM pam.pam_resources WHERE id LIKE 'matrix-%' AND deleted_at IS NULL;" \
  | xargs -I{} echo "seeded {} channel-matrix resources"
