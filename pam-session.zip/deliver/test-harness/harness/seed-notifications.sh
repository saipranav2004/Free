#!/bin/bash
# Seed unread notifications so the optimistic mark-read path has something to
# act on. read_at NULL is what "unread" means on this table.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
ROOT_ID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "
DELETE FROM pam.pam_notifications WHERE id LIKE 'seed-notif-%';
INSERT INTO pam.pam_notifications (id, org_id, user_id, category, severity, title, body, created_at, read_at)
SELECT 'seed-notif-'||g, 'default', '$ROOT_ID', 'SYSTEM', 'INFO',
       'Seeded notification '||g, 'Created by the end-to-end run.', NOW() - (g||' minutes')::interval, NULL
FROM generate_series(1,5) g;"
echo "seeded 5 unread notifications"
