#!/bin/bash
# A resource registered under the now-retired `web` type. Retiring a type must
# not downgrade existing rows to a raw enum in the table, drawer or exports.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
RID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "
DELETE FROM pam.pam_resources WHERE id='legacy-web-1';
INSERT INTO pam.pam_resources (id,name,description,resource_type,host,port,connect_mode,console_url,is_active,created_by,created_at,updated_at)
VALUES ('legacy-web-1','legacy-intranet','Registered before the type was retired','web','10.0.0.9',443,'embed_redirect','https://intranet.local',true,'$RID',NOW(),NOW());"
echo "seeded legacy web-typed resource"
