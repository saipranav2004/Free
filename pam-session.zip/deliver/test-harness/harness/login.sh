#!/bin/bash
# Re-mint a root access token. The access TTL is 60 minutes, so any test run
# that starts after a break needs this first.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
U=$(grep '^PAM_ROOT_USERNAME=' $S/harness/api.env | cut -d= -f2-)
P=$(grep '^PAM_ROOT_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
R=$(curl -s --noproxy '*' -X POST http://127.0.0.1:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d "$(python3 -c "import json,sys;print(json.dumps({'identifier':sys.argv[1],'password':sys.argv[2]}))" "$U" "$P")")
echo "$R" | python3 -c "
import sys, json
d = json.load(sys.stdin)
tok = (d.get('data') or {}).get('access_token')
if not tok:
    print('LOGIN FAILED:', json.dumps(d)[:400], file=sys.stderr); sys.exit(1)
open('/tmp/tok','w').write(tok)
print('token refreshed')
"
