#!/bin/bash
# Mint a token for a NON-admin account. Everything the console shows a
# standard operator has to be checked as one — an admin token passes checks
# a standard user would fail, which is the whole point of the role.
set -e
U=${1:-operator1}
P=${2:-'Operator1!Passw0rd'}
OUT=${3:-/tmp/tok-user}
R=$(curl -s --noproxy '*' -X POST http://127.0.0.1:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d "$(python3 -c "import json,sys;print(json.dumps({'identifier':sys.argv[1],'password':sys.argv[2]}))" "$U" "$P")")
echo "$R" | python3 -c "
import sys, json
d = json.load(sys.stdin)
tok = (d.get('data') or {}).get('access_token')
if not tok:
    print('LOGIN FAILED:', json.dumps(d)[:300], file=sys.stderr); sys.exit(1)
open('$OUT','w').write(tok)
print('user token ->', '$OUT')
"
