"""Line-ending-preserving edit helper.

The frontend tree is mostly CRLF and the agent tree is LF. Editing a CRLF file
with LF-only match strings silently fails (or, worse, half-succeeds and leaves
the file with mixed endings, which is how a stray \r\r\n got into nav.js once
already). So: read, normalise to LF, edit, write back in the file's ORIGINAL
dominant ending.
"""
import io, sys


def dominant(raw):
    crlf = raw.count('\r\n')
    lf = raw.count('\n') - crlf
    return '\r\n' if crlf >= lf else '\n'


def load(path):
    raw = io.open(path, encoding='utf-8', newline='').read()
    return raw.replace('\r\n', '\n'), dominant(raw)


def save(path, text, nl):
    # Normalise first so a file that arrived mixed leaves consistent.
    text = text.replace('\r\n', '\n')
    if nl == '\r\n':
        text = text.replace('\n', '\r\n')
    io.open(path, 'w', encoding='utf-8', newline='').write(text)


def sub(path, old, new, count=1, required=True):
    text, nl = load(path)
    old = old.replace('\r\n', '\n')
    new = new.replace('\r\n', '\n')
    n = text.count(old)
    if n == 0:
        if required:
            raise SystemExit('NOT FOUND in %s:\n%s' % (path, old[:300]))
        return 0
    if count and n > count:
        raise SystemExit('AMBIGUOUS in %s: %d matches of:\n%s' % (path, n, old[:300]))
    save(path, text.replace(old, new, count or -1), nl)
    return n


def append(path, text):
    body, nl = load(path)
    save(path, body.rstrip('\n') + '\n' + text.replace('\r\n', '\n'), nl)


def normalise(path):
    """Rewrite a file in its own dominant ending, fixing a mixed file."""
    text, nl = load(path)
    save(path, text, nl)
    return nl
