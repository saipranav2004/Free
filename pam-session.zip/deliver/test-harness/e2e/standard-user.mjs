import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The console as an ORDINARY OPERATOR.
//
// Every check so far has run as root, and root passes checks a standard user
// would fail — which is exactly what a role is for. Two different failures
// matter here and they are not the same:
//
//   A LEAK: a standard user can reach admin data. That is a security bug.
//   A TEASE: the console offers something the server will refuse. That is a
//     usability bug, and in a PAM console it is a bad one — an operator
//     cannot tell "you may not" from "it is broken".

const adminToken = readFileSync('/tmp/tok', 'utf8').trim()
const userToken = readFileSync('/tmp/tok-user', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const call = async (path, token) => {
  const r = await fetch(`${API}/api/v1/${path}`, { headers: { Authorization: 'Bearer ' + token } })
  return { status: r.status, body: await r.text() }
}

// ── The server must refuse, whatever the console shows ────────────────────
console.log('=== admin endpoints, called with an operator token ===')
const adminOnly = [
  'pam/admin/insights/vault',
  'pam/admin/insights/services',
  'pam/admin/services',
  'pam/admin/secret-paths',
  'pam/admin/sessions',
  'pam/admin/audit',
  'pam/admin/identity/users',
  'pam/admin/rbac/roles',
  'pam/admin/recordings',
]
for (const p of adminOnly) {
  const res = await call(p, userToken)
  check(`/${p} refuses an operator`, res.status === 403 || res.status === 401,
    `HTTP ${res.status}`)
}

// And the same endpoints must still work for an admin, or the test is only
// proving the routes are broken.
console.log('\n=== the same endpoints, as root ===')
let adminOk = 0
for (const p of adminOnly) {
  const res = await call(p, adminToken)
  if (res.status === 200) adminOk++
}
check('an admin can still reach all of them', adminOk === adminOnly.length,
  `${adminOk}/${adminOnly.length}`)

// ── Scoped endpoints: allowed, but only over the caller's own data ────────
console.log('\n=== scoped endpoints ===')
const own = await call('pam/insights/sessions', userToken)
check('an operator may read their own session insights', own.status === 200, `HTTP ${own.status}`)

const auditIns = await call('pam/insights/audit?days=30', userToken)
if (auditIns.status === 200) {
  const d = JSON.parse(auditIns.body).data
  const actors = (d.top_actors || []).map((a) => a.label)
  check('their audit insight names only themselves',
    actors.every((a) => a === 'operator1' || a === ''), `actors: ${actors.join(', ') || 'none'}`)
} else {
  check('audit insights are reachable or cleanly refused',
    auditIns.status === 403, `HTTP ${auditIns.status}`)
}

// ── The console itself ────────────────────────────────────────────────────
console.log('\n=== the console as an operator ===')
const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox'],
})
const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0, 140)) })
const forbidden = []
page.on('response', (r) => { if (r.status() === 403) forbidden.push(new URL(r.url()).pathname) })

const me = JSON.parse((await call('auth/me', userToken)).body).data
await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [userToken, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

await page.goto(APP + '/', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
const nav = await page.locator('nav, aside').first().innerText().catch(() => '')
check('the Admin Center is not offered in the navigation',
  !/admin center/i.test(nav), nav.replace(/\n+/g, ' / ').slice(0, 140))
for (const item of ['Identity Graph', 'Roles', 'MFA Policy', 'Policies', 'Service Identities', 'Vault Operations']) {
  check(`"${item}" is not in an operator's navigation`, !nav.includes(item))
}

// Typing an admin URL directly must not render admin data.
forbidden.length = 0
await page.goto(APP + '/admin/services', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
const body = await page.locator('main').innerText().catch(() => '')
check('a typed admin URL does not render admin data',
  /not authorised|not authorized|no access|denied|forbidden|not found/i.test(body) ||
    !body.includes('Ready to use'),
  body.replace(/\s+/g, ' ').slice(0, 110))

// Pages an operator SHOULD have must work, and must not be quietly 403-ing.
for (const [label, path] of [['Resources', '/resources'], ['Vault', '/vault'], ['Sessions', '/sessions']]) {
  forbidden.length = 0
  await page.goto(APP + path, { waitUntil: 'networkidle' })
  await page.waitForTimeout(1500)
  const txt = await page.locator('main').innerText().catch(() => '')
  check(`${label} renders for an operator`, txt.length > 40 && !/something went wrong/i.test(txt),
    txt.replace(/\s+/g, ' ').slice(0, 70))
  check(`${label} does not fire refused requests`, forbidden.length === 0,
    forbidden.join(', '))
}

check('no page errors as an operator', errors.length === 0, errors.slice(0, 3).join(' | '))

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
