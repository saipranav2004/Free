// The channel model, in a real browser against the real server.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'
import { execSync } from 'node:child_process'

const BASE = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const PG = '85b62f4a-41a7-40d5-9152-7a8167702f59'
const token = readFileSync('/tmp/tok', 'utf8').trim()
let failures = 0
const check = (n, ok, d = '') => { if (!ok) failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? `  — ${d}` : ''}`) }
const psql = (sql) =>
  execSync(`/usr/lib/postgresql/16/bin/psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -Atc ${JSON.stringify(sql)}`).toString().trim()

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
const me = await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: `Bearer ${token}` } })).json()
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } })
const page = await ctx.newPage()
const problems = []
page.on('pageerror', (e) => problems.push(e.message))

await page.goto(BASE, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u })),
  [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }])

async function openResource() {
  await page.goto(`${BASE}/resources/${PG}`, { waitUntil: 'networkidle' })
  // Root sees the admin view, where connect is a tab rather than the whole page.
  const tab = page.getByRole('tab', { name: /Connect/ })
  if (await tab.count()) await tab.first().click()
  await page.getByRole('button', { name: /Open in/ }).first().waitFor({ timeout: 10000 })
  await page.waitForTimeout(500)
}

// ── 1. every supported channel gets its own control ──────────────────────
psql(`update pam.pam_resources set allowed_channels='' where id='${PG}'`)
await openResource()

const labels = await page.getByRole('button', { name: /^Open in / }).allInnerTexts()
check('one control per channel, not a single button', labels.length >= 3, JSON.stringify(labels))
check('the terminal channel is offered explicitly', labels.some((l) => /CLI/i.test(l)))
check('the desktop channel is offered explicitly', labels.some((l) => /Desktop/i.test(l)))
check('the web channel is offered explicitly', labels.some((l) => /Web/i.test(l)))

// ── 2. a missing tool disables its control and names the remedy ──────────
const desktopBtn = page.getByRole('button', { name: /Open in Desktop/ }).first()
check('the desktop control is disabled — pgAdmin is not installed here', await desktopBtn.isDisabled())
const panel = await page.locator('text=/is not on this device/').first().innerText().catch(() => '')
check('it names the missing application, not just "unavailable"', /pgAdmin/i.test(panel), panel)
const hint = await page.locator('text=/pgadmin.org/').count()
check('it carries the install hint from the template', hint > 0)
const locate = await page.locator('text=/pam-agent locate --tool/').count()
check('it also offers "point the agent at it" for an already-installed copy', locate > 0)

// The CLI control IS usable here, which is the whole contrast.
const cliBtn = page.getByRole('button', { name: /Open in CLI/ }).first()
check('the terminal control is enabled — psql IS installed here', !(await cliBtn.isDisabled()))

await page.screenshot({ path: '/tmp/shot-channels.png', fullPage: true })

// ── 3. policy off reads as policy, never as a missing tool ───────────────
psql(`update pam.pam_resources set allowed_channels='cli' where id='${PG}'`)
await openResource()
const desktopAfter = page.getByRole('button', { name: /Open in Desktop/ }).first()
check('a policy-disabled channel is still SHOWN, not hidden', (await desktopAfter.count()) > 0)
check('and it is disabled', await desktopAfter.isDisabled())
const policyNote = await page.locator('text=/Turned off for this resource/').count()
check('it says policy, not "install something"', policyNote > 0)
const stillBlamesTool = await page.locator('text=/pgAdmin 4 is not on this device/').count()
check('it does NOT blame the tool when policy is the reason', stillBlamesTool === 0)

await page.screenshot({ path: '/tmp/shot-channels-policy.png', fullPage: true })

// ── 4. the request actually carries the channel ──────────────────────────
psql(`update pam.pam_resources set allowed_channels='' where id='${PG}'`)
await openResource()
const sent = []
page.on('request', (r) => {
  if (r.url().includes('/launch') && r.method() === 'POST') sent.push(r.postData() || '')
})
await page.getByRole('button', { name: /Open in CLI/ }).first().click()
await page.waitForTimeout(1500)
check('clicking "Open in CLI" sends channel=cli', sent.some((b) => /"channel"\s*:\s*"cli"/.test(b)), JSON.stringify(sent.slice(0, 2)))

check('no unhandled exceptions', problems.length === 0, problems.slice(0, 2).join(' // '))
await browser.close()
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
