// Group C: timestamps that name their zone, a UTC pin that applies everywhere,
// and motion that acknowledges change rather than only arrival.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const BASE = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()
let failures = 0
const check = (n, ok, d = '') => { if (!ok) failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? `  — ${d}` : ''}`) }

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
const me = await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: `Bearer ${token}` } })).json()
const seed = (page) => page.evaluate(([t, u]) =>
  sessionStorage.setItem('pam_session', JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u })),
  [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }])

// ── timezone ──────────────────────────────────────────────────────────────
{
  // A non-UTC zone, so "local vs UTC" is actually distinguishable.
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 950 }, timezoneId: 'Asia/Kolkata' })
  const page = await ctx.newPage()
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await seed(page)

  await page.goto(`${BASE}/admin/services`, { waitUntil: 'networkidle' })
  await page.locator('tbody tr').first().waitFor({ timeout: 10000 })
  await page.locator('tbody tr').first().locator('button[title]').first().click()
  await page.locator('dt', { hasText: /^Registered$/ }).first().waitFor({ timeout: 8000 })

  const registered = await page.locator('dt', { hasText: /^Registered$/ }).first().locator('xpath=following-sibling::dd[1]').innerText()
  check('a rendered timestamp names its zone', /\b(GMT|UTC|IST|[A-Z]{2,5})\b/.test(registered), registered)
  check('and it is in the browser zone, not UTC, by default', /GMT\+5:30|IST/.test(registered), registered)

  // Pin to UTC in Settings and confirm it applies to an already-rendered page.
  await page.goto(`${BASE}/settings?tab=appearance`, { waitUntil: 'networkidle' })
  const utcBtn = page.getByRole('tab', { name: 'UTC' })
  check('Settings offers a UTC pin', (await utcBtn.count()) > 0)
  await utcBtn.first().click()
  await page.waitForTimeout(400)

  await page.goto(`${BASE}/admin/services`, { waitUntil: 'networkidle' })
  await page.locator('tbody tr').first().waitFor({ timeout: 10000 })
  await page.locator('tbody tr').first().locator('button[title]').first().click()
  await page.locator('dt', { hasText: /^Registered$/ }).first().waitFor({ timeout: 8000 })
  const utcTime = await page.locator('dt', { hasText: /^Registered$/ }).first().locator('xpath=following-sibling::dd[1]').innerText()
  check('pinning to UTC changes what every timestamp shows', /UTC/.test(utcTime) && utcTime !== registered,
    `${registered}  ->  ${utcTime}`)
  await ctx.close()
}

// ── motion ────────────────────────────────────────────────────────────────
{
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 950 } })
  const page = await ctx.newPage()
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await seed(page)
  await page.goto(`${BASE}/`, { waitUntil: 'networkidle' })
  await page.waitForTimeout(1500)

  const tokens = await page.evaluate(() => {
    const cs = getComputedStyle(document.documentElement)
    return {
      quick: cs.getPropertyValue('--motion-quick').trim(),
      state: cs.getPropertyValue('--motion-state').trim(),
      attention: cs.getPropertyValue('--motion-attention').trim(),
      responsive: cs.getPropertyValue('--ease-responsive').trim(),
    }
  })
  // The browser normalises 250ms to .25s, so compare in seconds rather than
  // as typed.
  const ms = (v) => (v.endsWith('ms') ? parseFloat(v) : parseFloat(v) * 1000)
  check('the Cloudscape motion durations are defined as tokens',
    ms(tokens.quick) === 115 && ms(tokens.state) === 165 && ms(tokens.attention) === 250, JSON.stringify(tokens))
  check('and the responsive easing curve', tokens.responsive.includes('cubic-bezier'), tokens.responsive)

  const animated = await page.evaluate(() => ({
    arcs: document.querySelectorAll('.arc-draw').length,
    bars: document.querySelectorAll('.bar-grow').length,
  }))
  // DonutChart is exported but has no consumer yet — it gets one with the
  // insight cards. Checked there rather than asserted here against a page
  // that legitimately has no donut on it.
  console.log(`  NOTE  donut arcs on the dashboard: ${animated.arcs} (DonutChart has no consumer until the insight cards land)`)
  check('chart bars grow in', animated.bars > 0, `${animated.bars} bars`)

  // The arcs must carry real geometry, or the animation would draw nothing.

  await ctx.close()
}

// ── reduced motion is honoured ────────────────────────────────────────────
{
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 800 }, reducedMotion: 'reduce' })
  const page = await ctx.newPage()
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await seed(page)
  await page.goto(`${BASE}/`, { waitUntil: 'networkidle' })
  await page.waitForTimeout(1000)
  const stillAnimating = await page.evaluate(() =>
    [...document.querySelectorAll('.arc-draw, .bar-grow, .value-change')]
      .filter((el) => getComputedStyle(el).animationName !== 'none').length)
  check('every new animation is off under prefers-reduced-motion', stillAnimating === 0, `${stillAnimating} still animating`)
  await ctx.close()
}

await browser.close()
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
