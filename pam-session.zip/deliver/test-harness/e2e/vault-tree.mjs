import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The vault as a hierarchy. The tree is the only place the CANONICAL PATH
// appears — the address a service identity's grant is written against — so an
// administrator writing a scope was previously typing a glob at an address
// space they could not see.
const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
const paths = (await (await fetch(`${API}/api/v1/pam/admin/secret-paths`, { headers: { Authorization: 'Bearer ' + token } })).json()).data || []

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
console.log(`server knows ${paths.length} secret paths\n`)

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox'],
})
const page = await (await browser.newContext({ viewport: { width: 1500, height: 1000 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text().slice(0, 140)) })
const requests = []
page.on('request', (r) => { if (r.url().includes('/api/')) requests.push(new URL(r.url()).pathname) })

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

await page.goto(APP + '/vault', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
check('the vault offers a tree view', (await page.getByRole('radio', { name: /^Tree$/ }).count()) > 0 ||
  (await page.getByText(/^Tree$/).count()) > 0)

requests.length = 0
await page.getByText(/^Tree$/).first().click()
await page.waitForTimeout(2000)

const tree = page.locator('[role="tree"]')
check('a tree renders', (await tree.count()) > 0)

// ONE request for the whole shape, not one per node. Lazy-loading each level
// would reintroduce the per-node fan-out the path endpoint exists to remove.
const pathReqs = requests.filter((p) => p.includes('secret-paths'))
check('the whole hierarchy comes from ONE request', pathReqs.length <= 1,
  `${pathReqs.length} calls to the path index`)

const items = page.locator('[role="treeitem"]')
const topLevel = await items.count()
check('safes appear as tree nodes', topLevel > 0, `${topLevel} nodes`)

// ARIA: a leaf must NOT carry aria-expanded — the attribute is what
// distinguishes a group from a leaf, and on a secret it announces a
// collapsed group that contains nothing.
const first = items.first()
await first.click()
await page.waitForTimeout(600)
const expandedAttrs = await items.evaluateAll((els) =>
  els.map((e) => ({ level: e.getAttribute('aria-level'), exp: e.getAttribute('aria-expanded') })))
check('every node declares its depth', expandedAttrs.every((a) => a.level != null),
  `${expandedAttrs.filter((a) => a.level == null).length} missing aria-level`)

// Expand and find a secret, then confirm the canonical path is shown.
await page.keyboard.press('ArrowRight')
await page.waitForTimeout(500)
await page.keyboard.press('ArrowDown')
await page.waitForTimeout(400)
await page.keyboard.press('ArrowRight')
await page.waitForTimeout(400)
await page.keyboard.press('Enter')
await page.waitForTimeout(800)

const detail = await page.locator('main').innerText()
const somePath = paths[0]?.path
check('selecting a node opens a detail pane', /Path|Safe|secrets? beneath/i.test(detail),
  detail.replace(/\s+/g, ' ').slice(-110))
if (somePath) {
  // The path is the point of this view.
  const anyPathShown = paths.some((p) => detail.includes(p.path))
  check('a canonical path is shown somewhere in the tree view', anyPathShown || /\bPath\b/.test(detail),
    somePath)
}

check('only one tree keyboard handler is bound (no duplicate nodes)',
  (await page.locator('[role="tree"]').count()) === 1)
check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))

await page.screenshot({ path: '/tmp/vault-tree.png' })
await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
