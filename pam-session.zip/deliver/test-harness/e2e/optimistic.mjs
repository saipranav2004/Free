import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// G.4's second half, and the carve-out that goes with it.
//
// Two opposite things have to be true at once:
//   a notification marked read updates BEFORE the server answers, and
//   a privileged action does NOT.
// Testing only the first would let the second regress into a console that
// reports access as cut before it is.

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const api = async (p) => {
  const r = await fetch(`${API}/api/v1/${p}`, { headers: { Authorization: 'Bearer ' + token } })
  return (await r.json()).data
}
const me = await api('auth/me')

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } })
const page = await ctx.newPage()
const errors = []
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message))

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

// Hold the mark-read response open. Whatever the UI shows during this window
// is, by definition, what it shows without the server's agreement.
let releaseRead
const readHeld = new Promise((r) => { releaseRead = r })
await page.route('**/notifications/*/read', async (route) => {
  await readHeld
  await route.continue()
})

console.log('=== optimistic: notification read ===')
await page.goto(APP + '/notifications', { waitUntil: 'networkidle' })
await page.waitForTimeout(1200)

// The page's own counter next to the title: "(13 unread)".
const unreadCount = async () => {
  const t = await page.locator('main').innerText().catch(() => '')
  const m = t.match(/(\d+)\s+unread/i)
  return m ? Number(m[1]) : null
}
// There is no "mark as read" button — opening a notification marks it. That
// IS the interaction, so it is the one to test.
const unreadDots = page.locator('[aria-label="Unread"]')
const beforeCount = await unreadCount()
const beforeDots = await unreadDots.count()

if (beforeDots === 0 || beforeCount === null) {
  check('an unread notification was available to test on', false,
    `${beforeDots} unread markers, counter ${beforeCount} — run harness/seed-notifications.sh`)
} else {
  // Click a row that is STILL unread, found by its marker rather than by
  // name. Naming a row makes the test pass once and then silently assert
  // nothing, because the first run marks that row read.
  const unreadRow = page
    .locator('main li, main tr, main [role="listitem"]')
    .filter({ has: page.locator('[aria-label="Unread"]') })
    .first()
  await unreadRow.locator('button').first().click()
    .catch(() => unreadRow.click())
  // No waiting for the network: the request is still held open, so whatever
  // is on screen now is what the console shows WITHOUT the server's answer.
  await page.waitForTimeout(300)
  const duringDots = await unreadDots.count()
  const duringCount = await unreadCount()
  check('the row drops its unread marker before the server answers',
    duringDots < beforeDots, `${beforeDots} -> ${duringDots} markers`)
  check('the unread counter moves with it, not after it',
    duringCount !== null && duringCount < beforeCount, `${beforeCount} -> ${duringCount}`)
  releaseRead()
  await page.waitForTimeout(1500)
  // And it stays changed once the server agrees — an optimistic update that
  // flickers back and forth is worse than none.
  const afterDots = await unreadDots.count()
  check('it stays marked once the server confirms', afterDots <= duringDots,
    `${duringDots} -> ${afterDots} after settle`)
}
releaseRead?.()

// ── The carve-out ─────────────────────────────────────────────────────────
// Ending a session is privileged and irreversible. Holding its response open
// must leave the row saying it is still ACTIVE: showing "ended" here would be
// a false statement about whether access was cut.
console.log('\n=== NOT optimistic: ending a session ===')
let releaseEnd
const endHeld = new Promise((r) => { releaseEnd = r })
await page.route('**/sessions/*/end', async (route) => {
  await endHeld
  await route.continue()
})

await page.goto(APP + '/sessions', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
const endLinks = page.getByRole('button', { name: /^End$/ })
if ((await endLinks.count()) === 0) {
  check('a live session was available to test the carve-out on', false,
    'no ACTIVE session on screen — reseed with harness/seed-active-sessions.sh')
} else {
  const rowBefore = (await page.locator('tbody tr').first().innerText()).replace(/\s+/g, ' ')
  await endLinks.first().click()
  await page.waitForTimeout(400)
  // A confirmation dialog is itself the right answer for a privileged action.
  const dialog = page.getByRole('dialog')
  const confirmed = (await dialog.count()) > 0
  check('a privileged action asks before it acts', confirmed)
  if (confirmed) {
    await dialog.getByRole('button', { name: /end session|confirm|end/i }).last().click()
    await page.waitForTimeout(600)
  }
  const rowDuring = (await page.locator('tbody tr').first().innerText()).replace(/\s+/g, ' ')
  check('the session is NOT shown as ended while the server is still deciding',
    rowDuring.includes('Active') || rowDuring === rowBefore,
    rowDuring.slice(0, 90))
  releaseEnd()
  await page.waitForTimeout(1500)
}
releaseEnd?.()

check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
