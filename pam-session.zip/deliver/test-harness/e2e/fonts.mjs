// The real test for self-hosted fonts: block every external host, the way an
// egress-filtered network does, and check the typography still renders.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const BASE = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()
let failures = 0
const check = (n, ok, d = '') => { if (!ok) failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? `  — ${d}` : ''}`) }

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } })
const page = await ctx.newPage()

// Simulate the customer's network: nothing but our own origin resolves.
const external = []
await page.route('**/*', (route) => {
  const url = route.request().url()
  // Our own origins only. The console addresses the API as localhost, the
  // static server as 127.0.0.1 — both are "us"; everything else is the
  // outside world this network does not have.
  if (/^https?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(url) || url.startsWith('data:')) return route.continue()
  external.push(url)
  return route.abort()
})

const me = await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: `Bearer ${token}` } })).json()
await page.goto(BASE, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u })),
  [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }])
await page.goto(`${BASE}/resources`, { waitUntil: 'networkidle' })
await page.waitForTimeout(1200)

check('the console makes no external requests at all', external.length === 0, external.slice(0, 3).join(' '))

// A webfont only downloads once something on the page is actually set in it,
// so put mono text on screen before asking.
await page.evaluate(() => {
  const probe = document.createElement('code')
  probe.textContent = 'pamsvc.0123456789abcdef'
  probe.style.cssText = 'position:absolute;left:-9999px;font-family:"JetBrains Mono Variable"'
  document.body.appendChild(probe)
})
await page.evaluate(() => document.fonts.ready)
await page.waitForTimeout(500)

const fonts = await page.evaluate(async () => {
  await document.fonts.ready
  const loaded = [...document.fonts].filter((f) => f.status === 'loaded').map((f) => f.family)
  const body = getComputedStyle(document.body).fontFamily
  const mono = document.querySelector('.font-mono, code, pre')
  return { loaded: [...new Set(loaded)], body, mono: mono ? getComputedStyle(mono).fontFamily : null }
})
check('Inter actually loaded from the bundle', fonts.loaded.some((f) => /Inter/i.test(f)), JSON.stringify(fonts.loaded))
check('JetBrains Mono loaded too', fonts.loaded.some((f) => /JetBrains/i.test(f)), JSON.stringify(fonts.loaded))
check('body text is set in Inter, not a system fallback', /Inter/i.test(fonts.body), fonts.body)

// Measured, not assumed: if the webfont failed we would be seeing a fallback,
// and the rendered width of a known string would differ.
const usingFallback = await page.evaluate(() => {
  const probe = document.createElement('span')
  probe.textContent = 'Privileged access'
  probe.style.cssText = 'position:absolute;visibility:hidden;font-size:40px;font-family:"Inter Variable"'
  document.body.appendChild(probe)
  const withFont = probe.getBoundingClientRect().width
  probe.style.fontFamily = 'sans-serif'
  const fallback = probe.getBoundingClientRect().width
  probe.remove()
  return { withFont, fallback, same: Math.abs(withFont - fallback) < 0.5 }
})
check('the rendered text really is Inter, not a lookalike fallback', !usingFallback.same,
  `Inter=${usingFallback.withFont.toFixed(1)}px vs sans-serif=${usingFallback.fallback.toFixed(1)}px`)

await page.screenshot({ path: '/tmp/shot-fonts.png' })
await browser.close()
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
