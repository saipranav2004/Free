// A stand-in for a brokered console (MinIO's Object Browser shape): one HTML
// page, then everything by XHR, with a strict CSP — `script-src 'self'` — so
// the app's own script is an EXTERNAL file, exactly as a real SPA ships it.
//
// The CSP is the point, not incidental. PAM's replay recorder is served from
// the proxy origin precisely so a target's `script-src 'self'` admits it with
// no CSP rewrite; a stub with a lax policy would not test that at all.
const http = require('http')
const PORT = Number(process.argv[2] || 9101)

const PAGE = `<!doctype html>
<html><head><title>Stub Object Browser</title>
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; connect-src 'self'">
</head><body>
<h1 id="t">Buckets</h1>
<input id="search" placeholder="Filter buckets" />
<button id="go">Load</button>
<ul id="list"></ul>
<script src="/app.js"></script>
</body></html>`

const APP = `
document.getElementById('go').addEventListener('click', async () => {
  const r = await fetch('/api/buckets'); const j = await r.json();
  document.getElementById('list').innerHTML = j.buckets.map(b => '<li>' + b + '</li>').join('')
})
document.getElementById('search').addEventListener('input', e => {
  document.getElementById('t').textContent = 'Buckets matching ' + e.target.value
})
`

http.createServer((req, res) => {
  if (req.url.startsWith('/app.js')) {
    res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8' })
    return res.end(APP)
  }
  if (req.url.startsWith('/api/buckets')) {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ buckets: ['evidence', 'backups', 'logs'] }))
  }
  res.writeHead(200, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; connect-src 'self'",
  })
  res.end(PAGE)
}).listen(PORT, '127.0.0.1', () => console.log('stub target on ' + PORT))
