import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// Does a BROKERED WEB SESSION actually record the screen?
//
// The HTTP transaction log answers "what did they request". For a console like
// MinIO's — one page load then hundreds of XHRs — that is a poor substitute for
// watching the session back. The claim under test is the stronger one: that an
// rrweb recorder is injected, captures DOM mutations and INPUT, and lands as a
// replayable recording on the session.
//
// Nothing here trusts a file existing. It drives a real browser through the
// real proxy and then reads the stored artifact.

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  const j = await r.json().catch(() => ({}))
  return { ok: r.ok, status: r.status, data: j.data, raw: j }
}

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

// ── Open a brokered session ───────────────────────────────────────────────
const open = await api('pam/resources/matrix-minio/web-session', { method: 'POST', body: '{}' })
if (!open.ok) {
  console.log('FAIL  could not open a brokered session:', JSON.stringify(open.raw).slice(0, 300))
  process.exit(1)
}
const { launch_url, session_id, web_proxy_session_id } = open.data
console.log(`session ${session_id}\n  ${launch_url}\n`)

// The proxy routes by subdomain. Chromium resolves any *.pam.local to the
// loopback so no DNS or hosts entry is needed.
const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})
const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage()
const replayPosts = []
page.on('request', (r) => {
  if (r.url().includes('/__pam/replay')) replayPosts.push(r.method() + ' ' + new URL(r.url()).pathname)
})
const pageErrors = []
page.on('pageerror', (e) => pageErrors.push(e.message))

console.log('=== inside the brokered session ===')
await page.goto(launch_url, { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)

const title = await page.title()
check('the target application renders through the proxy', title.includes('Stub Object Browser'), `title "${title}"`)

const replayScript = await page.locator('script[src*="__pam/replay"]').count()
check('the replay recorder is injected into the page', replayScript > 0, `${replayScript} script tags`)

// Do something worth recording: type, and cause a DOM mutation.
await page.locator('#search').click()
await page.locator('#search').type('evidence', { delay: 60 })
await page.waitForTimeout(400)
await page.locator('#go').click()
await page.waitForTimeout(1200)
const listed = await page.locator('#list li').count()
check('the app works through the proxy (XHR reached the target)', listed === 3, `${listed} buckets listed`)
const heading = await page.locator('#t').innerText()
check('typing changed the DOM, so there is something to replay', heading.includes('evidence'), heading)

// Give the recorder time to flush a batch.
await page.waitForTimeout(3500)
check('the recorder posted events back', replayPosts.length > 0, `${replayPosts.length} posts`)
check('no page errors inside the session', pageErrors.length === 0, pageErrors.slice(0, 2).join(' | '))

await browser.close()

// ── End the session and read the artifact back ───────────────────────────
console.log('\n=== the stored recording ===')
await api(`pam/web-sessions/${web_proxy_session_id}/end`, { method: 'POST', body: '{}' })
await new Promise((r) => setTimeout(r, 2500))

const recs = await api('pam/admin/recordings?page=1&page_size=50')
const mine = (recs.data?.recordings || []).filter((r) => r.session_id === session_id)
check('a recording row exists for the session', mine.length > 0, `${mine.length} rows`)
if (mine.length) {
  const rec = mine[0]
  console.log('   ', JSON.stringify({ format: rec.format, status: rec.status, size: rec.size_bytes ?? rec.size }, null, 0))
  check('it is a VISUAL recording, not just a transaction log',
    String(rec.format).toLowerCase() === 'rrweb', `format=${rec.format}`)
  const size = Number(rec.size_bytes ?? rec.size ?? 0)
  check('it has actual frames in it', size > 0, `${size} bytes`)

  // And it must be fetchable for replay, not merely catalogued.
  const r = await fetch(`${API}/api/v1/pam/admin/recordings/${rec.id}/cast`, {
    headers: { Authorization: 'Bearer ' + token },
  })
  const body = await r.text()
  check('the replay stream is served back', r.ok && body.length > 0, `${r.status}, ${body.length} bytes`)
  // rrweb events carry a type and a timestamp; typing shows up as type 3
  // (IncrementalSnapshot). This is the difference between "a file exists"
  // and "the session was actually captured".
  check('the stream contains rrweb events including interaction',
    body.includes('"type"') && /"type":\s*3/.test(body),
    body.slice(0, 120).replace(/\s+/g, ' '))
}

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
