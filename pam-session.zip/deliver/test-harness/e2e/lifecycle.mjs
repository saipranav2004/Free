// Disable and recover a service identity entirely through the console, and
// check the screen tells the truth about what comes back.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const BASE = 'http://127.0.0.1:4180'
const API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok', 'utf8').trim()
let failures = 0
const check = (n, ok, d = '') => {
  if (!ok) failures++
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? `  — ${d}` : ''}`)
}
const admin = (p, init = {}) =>
  fetch(`${API}/api/v1/pam/admin${p}`, {
    ...init,
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
  })

// A dedicated identity, so the run never depends on another test's leftovers.
const name = `lifecycle-${Date.now().toString(36)}`
await admin('/services', { method: 'POST', body: JSON.stringify({ name, environment: 'staging' }) })
await admin(`/services/${name}/grants`, {
  method: 'POST',
  body: JSON.stringify({ scope: 'prod-db/*', reason: 'lifecycle test', max_ttl_seconds: 90 }),
})
const minted = await (await admin(`/services/${name}/tokens`, {
  method: 'POST',
  body: JSON.stringify({ ttl_days: 7, description: 'lifecycle' }),
})).json()
const oldToken = minted.data.token

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox'],
})
const me = await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: `Bearer ${token}` } })).json()
const ctx = await browser.newContext({ viewport: { width: 1440, height: 960 } })
const page = await ctx.newPage()
const problems = []
page.on('pageerror', (e) => problems.push(e.message))

await page.goto(BASE, { waitUntil: 'domcontentloaded' })
await page.evaluate(
  ([t, u]) =>
    sessionStorage.setItem(
      'pam_session',
      JSON.stringify({ accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u })
    ),
  [token, { user_id: me.data.user_id, username: me.data.username, roles: me.data.roles, email: me.data.email }]
)
await page.goto(`${BASE}/admin/services`, { waitUntil: 'networkidle' })

const row = () => page.locator('tbody tr', { hasText: name })
await row().first().waitFor({ timeout: 10000 })
const settled = () =>
  page.waitForFunction(
    (n) => {
      const tr = [...document.querySelectorAll('tbody tr')].find((r) => r.textContent.includes(n))
      return tr && !tr.textContent.includes('checking')
    },
    name,
    { timeout: 10000 }
  )
await settled()
check('a provisioned identity reads as Ready', (await row().first().innerText()).includes('Ready'))

// ── disable, through the console ──────────────────────────────────────────
await row().first().getByRole('button', { name: `Actions for ${name}` }).click()
await page.getByText('Disable identity').first().click()
const dialog = page.locator('text=/Every token this identity holds is revoked/')
await dialog.first().waitFor({ timeout: 5000 })
const warning = await dialog.first().innerText()
check(
  'the disable warning says the revoked tokens stay revoked',
  warning.includes('revoked tokens stay revoked'),
  warning.slice(0, 110)
)
check('and that it can be enabled again', warning.includes('can be enabled again'))
await page.getByRole('button', { name: 'Disable identity' }).last().click()
await page.waitForTimeout(1500)
await settled()
check('the row now reads Disabled', (await row().first().innerText()).includes('Disabled'), (await row().first().innerText()).replace(/\n/g, ' | '))

// The old token is dead on the data plane.
const deadRead = await fetch(
  `${API}/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=after+console+disable`,
  { headers: { 'X-Service-Token': oldToken } }
)
check('the token stops working immediately', deadRead.status !== 200, `http ${deadRead.status}`)

// ── the drawer must not claim minting still works ────────────────────────
await row().first().locator(`button[title="${name}"]`).click()
await page.getByText(/This identity is disabled/).first().waitFor({ timeout: 5000 })
const drawerText = await page.getByText(/This identity is disabled/).first().innerText()
check(
  'the drawer says a disabled identity cannot mint, and names the recovery',
  drawerText.includes('cannot mint a token') && drawerText.includes('enable it'),
  drawerText
)
check(
  'the drawer offers Enable instead of Disable',
  (await page.getByRole('button', { name: 'Enable identity' }).count()) > 0 &&
    (await page.getByRole('button', { name: 'Disable identity' }).count()) === 0
)

// ── enable, through the console ──────────────────────────────────────────
await page.getByRole('button', { name: 'Enable identity' }).first().click()
const enableDialog = page.locator('text=/The identity and its scopes come back/')
await enableDialog.first().waitFor({ timeout: 5000 })
const enableCopy = await enableDialog.first().innerText()
check(
  'the enable dialog is explicit that old tokens do not come back',
  enableCopy.includes('stay revoked') && enableCopy.includes('mint a new token'),
  enableCopy.slice(0, 130)
)
await page.getByRole('button', { name: 'Enable identity' }).last().click()
await page.waitForTimeout(1500)
await settled()
const afterEnable = await row().first().innerText()
check(
  'after enabling, the row reads "No token" — scopes back, nothing authenticating',
  afterEnable.includes('No token'),
  afterEnable.replace(/\n/g, ' | ')
)

const stillDead = await fetch(
  `${API}/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=after+console+enable+old+token`,
  { headers: { 'X-Service-Token': oldToken } }
)
check('the revoked token is still refused after enabling', stillDead.status !== 200, `http ${stillDead.status}`)

const grants = await (await admin(`/services/${name}/grants`)).json()
check('the grants survived the whole cycle', (grants.data || []).some((g) => g.scope === 'prod-db/*'))

// Recovery: mint one fresh token through the UI and confirm it reads.
await page.keyboard.press('Escape')
await page.waitForTimeout(400)
await row().first().getByRole('button', { name: `Actions for ${name}` }).click()
check(
  'a disabled-then-enabled identity offers Mint again',
  (await page.getByText('Mint a token').count()) > 0
)
await page.getByText('Mint a token').first().click()
await page.locator('#it-ttl').waitFor({ timeout: 5000 })
await page.getByRole('button', { name: 'Mint token' }).last().click()
await page.getByText('Copy this token now').waitFor({ timeout: 10000 })
await page.getByRole('button', { name: /Reveal/ }).click()
const fresh = (await page.locator('p.break-all.font-mono').first().innerText()).trim()
const good = await fetch(
  `${API}/api/v1/pam/svc/secrets/prod-db/pg-app-writer?purpose=recovered+through+the+console`,
  { headers: { 'X-Service-Token': fresh } }
)
check('the fresh token reads the granted secret — full recovery', good.status === 200, `http ${good.status}`)
await page.locator('input[type="checkbox"]').last().check()
await page.getByRole('button', { name: 'Done' }).click()
await page.waitForTimeout(800)
await settled()
check('and the row is Ready again', (await row().first().innerText()).includes('Ready'))

check('no unhandled exceptions', problems.length === 0, problems.slice(0, 2).join(' // '))
await browser.close()
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`)
process.exit(failures === 0 ? 0 : 1)
