// Serves the real built console on :4180 and proxies /api to the real pam-api,
// so the browser exercises the shipped bundle against the shipped backend.
const http = require('http')
const fs = require('fs')
const path = require('path')

const DIST = '/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad/src/frontend/frontend_upd/dist'
const TYPES = {
  '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
  '.svg': 'image/svg+xml', '.json': 'application/json', '.woff2': 'font/woff2',
  '.png': 'image/png', '.ico': 'image/x-icon',
}

http.createServer((req, res) => {
  if (req.url.startsWith('/api/')) {
    const up = http.request(
      { host: '127.0.0.1', port: 8080, path: req.url, method: req.method, headers: req.headers },
      (r) => { res.writeHead(r.statusCode, r.headers); r.pipe(res) }
    )
    up.on('error', (e) => { res.writeHead(502); res.end(String(e)) })
    req.pipe(up)
    return
  }
  const rel = req.url.split('?')[0]
  let file = path.join(DIST, rel === '/' ? 'index.html' : rel)
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(DIST, 'index.html')
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' })
  fs.createReadStream(file).pipe(res)
}).listen(4180, () => console.log('console on http://127.0.0.1:4180'))
