import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The bugs reported from the deployed build, each driven the way they were hit.
const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox'],
})
const page = await (await browser.newContext({ viewport: { width: 1500, height: 1000 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0, 160)) })
const auditReqs = []
page.on('request', (r) => {
  if (r.url().includes('/pam/admin/audit?')) auditReqs.push(new URL(r.url()).searchParams.get('page_size'))
})

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

// ── 1. "Web Application" must be gone from the create form ────────────────
console.log('=== 1. Web Application resource option ===')
await page.goto(APP + '/resources', { waitUntil: 'networkidle' })
await page.waitForTimeout(1200)
await page.getByRole('button', { name: /add resource|register resource|new resource|create/i }).first().click()
  .catch(() => {})
await page.waitForTimeout(1000)
// Scoped to the FORM, not the page. The list behind it legitimately shows
// "Web Application" for a resource already registered under that type, and
// reading the whole body conflates "cannot be created" with "cannot exist" —
// which are exactly the two things this change separates.
const dialog = page.getByRole('dialog').first()
const formText = (
  (await dialog.count()) > 0 ? await dialog.innerText() : await page.locator('form').first().innerText()
).toLowerCase()
check('the create form no longer offers "Web Application"', !formText.includes('web application'),
  formText.includes('web application') ? 'still offered in the form' : '')
// The nine that remain must all still be there.
for (const t of ['PostgreSQL', 'MongoDB', 'Redis', 'ClickHouse', 'MinIO', 'Qdrant', 'Metabase', 'Langfuse', 'Oracle']) {
  check(`"${t}" is still offered`, formText.includes(t.toLowerCase()))
}
await page.keyboard.press('Escape')
await page.waitForTimeout(500)

// Retiring a type must not corrupt rows already registered under it. A
// resource of type `web` is seeded in the database (harness/seed-legacy-web.sh)
// precisely so this is checked against real data rather than asserted.
await page.reload({ waitUntil: 'networkidle' })
await page.waitForTimeout(1200)
const legacyRow = page.locator('tr, li').filter({ hasText: 'legacy-intranet' }).first()
const seeded = (await legacyRow.count()) > 0
if (!seeded) {
  check('the seeded legacy web resource is listed', false, 'run harness/seed-legacy-web.sh')
} else {
  const rowText = await legacyRow.innerText()
  check('a retired type still renders its label, not the raw enum',
    rowText.includes('Web Application') && !/\bweb\b(?!\s*[Aa]pplication)/.test(rowText),
    rowText.replace(/\s+/g, ' ').slice(0, 90))
}

// ── 2. Rows per page: the control must state what is actually fetched ─────
console.log('\n=== 2. Audit rows-per-page ===')
await page.goto(APP + '/admin/audit', { waitUntil: 'networkidle' })
await page.waitForTimeout(1800)

const sizeSelect = page.locator('select').filter({ has: page.locator('option') }).last()
const shown = await sizeSelect.inputValue().catch(() => null)
const requested = auditReqs[auditReqs.length - 1]
check('the rows-per-page control agrees with what was requested',
  shown != null && requested != null && String(shown) === String(requested),
  `control shows ${shown}, request asked for ${requested}`)

const options = await sizeSelect.locator('option').allInnerTexts().catch(() => [])
check('the current size is among the offered options', options.includes(String(shown)),
  `options [${options.join(', ')}], current ${shown}`)

// Now actually pick 10 and confirm ten rows arrive.
auditReqs.length = 0
await sizeSelect.selectOption('10')
await page.waitForTimeout(1800)
check('choosing 10 sends page_size=10', auditReqs.includes('10'), `sent ${auditReqs.join(',')}`)
const rowsAfter = await page.locator('[data-log-line]').count()
check('choosing 10 renders 10 events', rowsAfter === 10, `${rowsAfter} rendered`)
const shownAfter = await sizeSelect.inputValue()
check('the control still reads 10 afterwards', shownAfter === '10', `reads ${shownAfter}`)

check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
