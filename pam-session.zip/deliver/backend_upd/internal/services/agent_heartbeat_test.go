package services

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"fmt"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
)

func (f *launchFixture) heartbeat(t *testing.T, sessionID string) *HeartbeatResult {
	t.Helper()
	ts := time.Now()
	sig := ed25519.Sign(f.priv, []byte(fmt.Sprintf("%s|%d", sessionID, ts.Unix())))
	res, err := f.agentSvc.Heartbeat(sessionID, f.device.ID, base64.StdEncoding.EncodeToString(sig), ts)
	if err != nil {
		t.Fatalf("Heartbeat: %v", err)
	}
	return res
}

// A live session heartbeats quietly and is told to carry on.
func TestAHealthySessionIsToldToCarryOn(t *testing.T) {
	f := newLaunchFixture(t, "u-hb")
	_, sessionID := f.resolve(t)

	res := f.heartbeat(t, sessionID)
	if res.Terminate {
		t.Fatalf("a healthy session was told to stop: %+v", res)
	}
	if res.IntervalSeconds <= 0 {
		t.Fatalf("no cadence returned, so the agent cannot retune: %+v", res)
	}

	var session models.ConnectionSession
	if err := f.db.Where("id = ?", sessionID).First(&session).Error; err != nil {
		t.Fatalf("load session: %v", err)
	}
	if session.LastHeartbeatAt == nil {
		t.Fatal("the heartbeat was not recorded, so the reaper can never tell this session is alive")
	}
}

// THE POINT OF THE WHOLE MECHANISM. An administrator's force-terminate used to
// close the database row while the operator's client kept running, because
// nothing could reach a process on someone else's machine. The instruction now
// comes back on the next heartbeat.
func TestAForceTerminateReachesTheAgentOnItsNextHeartbeat(t *testing.T) {
	f := newLaunchFixture(t, "u-kill")
	_, sessionID := f.resolve(t)

	if res := f.heartbeat(t, sessionID); res.Terminate {
		t.Fatal("told to stop before anything asked for it")
	}

	if err := f.agentSvc.RequestTerminate(sessionID, "admin-1", "Investigating unusual activity"); err != nil {
		t.Fatalf("RequestTerminate: %v", err)
	}

	res := f.heartbeat(t, sessionID)
	if !res.Terminate {
		t.Fatal("the agent was not told to stop — the operator's client would keep running, which is the bug this fixes")
	}
	if res.Reason != "Investigating unusual activity" {
		t.Fatalf("reason %q — the operator should see the administrator's own words, not a generic message", res.Reason)
	}
}

// A session closed by any other route must also stop the tool. Whoever ended
// it, the client should not still be open.
func TestASessionThatIsNoLongerActiveStopsTheTool(t *testing.T) {
	f := newLaunchFixture(t, "u-closed")
	_, sessionID := f.resolve(t)

	if err := f.db.Model(&models.ConnectionSession{}).Where("id = ?", sessionID).
		Update("status", "COMPLETED").Error; err != nil {
		t.Fatalf("close session: %v", err)
	}
	if res := f.heartbeat(t, sessionID); !res.Terminate {
		t.Fatal("a closed session left its tool running")
	}
}

// Revoking a device mid-session must end that session, not wait for it.
func TestARevokedDeviceIsToldToStop(t *testing.T) {
	f := newLaunchFixture(t, "u-revoked")
	_, sessionID := f.resolve(t)

	if err := f.db.Model(&models.AgentDevice{}).Where("id = ?", f.device.ID).
		Update("status", "REVOKED").Error; err != nil {
		t.Fatalf("revoke device: %v", err)
	}
	ts := time.Now()
	sig := ed25519.Sign(f.priv, []byte(fmt.Sprintf("%s|%d", sessionID, ts.Unix())))
	res, err := f.agentSvc.Heartbeat(sessionID, f.device.ID, base64.StdEncoding.EncodeToString(sig), ts)
	if err != nil {
		t.Fatalf("Heartbeat: %v", err)
	}
	if !res.Terminate {
		t.Fatal("a revoked device kept its session open")
	}
}

// A forgeable heartbeat would let anyone keep a dead session looking alive, or
// learn that a termination had been ordered.
func TestAnUnsignedHeartbeatIsRefused(t *testing.T) {
	f := newLaunchFixture(t, "u-forge")
	_, sessionID := f.resolve(t)

	if _, err := f.agentSvc.Heartbeat(sessionID, f.device.ID, "not-a-signature", time.Now()); err == nil {
		t.Fatal("a heartbeat with a bogus signature was accepted")
	}
}

// The reaper: an agent that stops reporting must not leave an ACTIVE row until
// the next server restart.
func TestTheReaperClosesSessionsWhoseAgentWentAway(t *testing.T) {
	f := newLaunchFixture(t, "u-reap")
	_, sessionID := f.resolve(t)
	f.heartbeat(t, sessionID)

	// Age the heartbeat past the grace window.
	stale := time.Now().UTC().Add(-5 * time.Minute)
	if err := f.db.Model(&models.ConnectionSession{}).Where("id = ?", sessionID).
		Update("last_heartbeat_at", stale).Error; err != nil {
		t.Fatalf("age heartbeat: %v", err)
	}

	reaper := NewNativeSessionReconciler(f.agentSvc)
	closed, err := reaper.ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 1 {
		t.Fatalf("closed %d sessions, want 1", closed)
	}

	var session models.ConnectionSession
	f.db.Where("id = ?", sessionID).First(&session)
	// COMPLETED, not KILLED: a closed laptop is not a disciplinary event, and
	// recording it as a kill would put one on somebody's audit trail.
	if session.Status != "COMPLETED" {
		t.Fatalf("status %q, want COMPLETED", session.Status)
	}
	if session.EndedAt == nil {
		t.Fatal("no ended_at, so the session's duration is unknowable")
	}
}

// A session that has NEVER heartbeat must be left alone. Brokered web sessions
// and anything from an older agent do not heartbeat, and a reaper that closed
// session types it does not understand would be worse than no reaper.
func TestTheReaperIgnoresSessionsThatNeverHeartbeat(t *testing.T) {
	f := newLaunchFixture(t, "u-noheartbeat")
	_, sessionID := f.resolve(t)

	// Old enough to be swept, but it never checked in.
	if err := f.db.Model(&models.ConnectionSession{}).Where("id = ?", sessionID).
		Update("started_at", time.Now().UTC().Add(-2*time.Hour)).Error; err != nil {
		t.Fatalf("age session: %v", err)
	}

	reaper := NewNativeSessionReconciler(f.agentSvc)
	closed, err := reaper.ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 0 {
		t.Fatalf("the reaper closed %d sessions it knows nothing about", closed)
	}

	var session models.ConnectionSession
	f.db.Where("id = ?", sessionID).First(&session)
	if session.Status != "ACTIVE" {
		t.Fatalf("status %q — a session type the reaper does not understand was swept away", session.Status)
	}
}

// A brief network blip must not end a live session. The grace window is
// several heartbeat intervals precisely so a sleeping laptop or a reconnecting
// VPN survives.
func TestARecentlyHeardSessionSurvivesTheReaper(t *testing.T) {
	f := newLaunchFixture(t, "u-blip")
	_, sessionID := f.resolve(t)
	f.heartbeat(t, sessionID)

	// One interval ago: late, but well inside the grace window.
	if err := f.db.Model(&models.ConnectionSession{}).Where("id = ?", sessionID).
		Update("last_heartbeat_at", time.Now().UTC().Add(-15*time.Second)).Error; err != nil {
		t.Fatalf("age heartbeat: %v", err)
	}
	closed, err := NewNativeSessionReconciler(f.agentSvc).ReconcileExpired(context.Background())
	if err != nil {
		t.Fatalf("ReconcileExpired: %v", err)
	}
	if closed != 0 {
		t.Fatal("a session that checked in moments ago was closed — a network blip must not end a live session")
	}
	_ = zap.NewNop()
}
