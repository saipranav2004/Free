package services

import (
	"context"
	"strings"
	"testing"

	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/pkg/crypto"
)

// Reading back a credential the VAULT wrote.
//
// The vault moved to envelope encryption — the stored column became a JSON
// document with the data key wrapped by the KMS and the row's identity bound
// in as AAD. Everything that WRITES a credential moved with it. This service,
// which READS them to inject into a session, did not: it kept calling the
// raw base64 AES path, so every such read failed on the first character with
// "illegal base64 data at input byte 0" — because `{` is not base64.
//
// It surfaced as several unrelated-looking bugs, one per consumer: a brokered
// web session that would not open, a native launch with no password, an agent
// download that appeared to do nothing. One cause, three symptoms, none of
// which named the vault.
//
// These tests read back through the same path a session does, so a future
// change to either side has to keep them agreeing.

func testKMS(t *testing.T) crypto.KMSProvider {
	t.Helper()
	// The same local provider the dev/test configuration uses.
	kms, err := crypto.NewLocalKMSProvider("bG9jYWwtdGVzdC1rZXktMzJieXRlcy1leGFjdGx5ISE=")
	if err != nil {
		t.Fatalf("local kms: %v", err)
	}
	return kms
}

func TestCredentialWrittenByTheVaultCanBeReadBack(t *testing.T) {
	kms := testKMS(t)
	svc := (&ResourceService{}).WithKMS(kms)

	entry := models.Credential{
		ID:          "cred-1",
		SafeID:      "safe-1",
		AccountName: "minioadmin",
		ResourceID:  "res-1",
	}
	sealed, err := crypto.EnvelopeEncryptor(context.Background(), kms, "s3cr3t", entry.EncryptionAAD())
	if err != nil {
		t.Fatalf("seal: %v", err)
	}
	entry.CredentialEnc = sealed

	// The shape matters: if this stops being JSON the bug cannot recur, and
	// the test would be pinning nothing.
	if !strings.HasPrefix(strings.TrimSpace(sealed), "{") {
		t.Fatalf("the vault no longer writes a JSON envelope (%.40s) — this test is obsolete", sealed)
	}

	got, err := svc.decryptCredential(entry)
	if err != nil {
		t.Fatalf("reading back a credential the vault wrote: %v", err)
	}
	if got != "s3cr3t" {
		t.Fatalf("plaintext = %q, want %q", got, "s3cr3t")
	}
}

// Rows written before the move must still open, or upgrading the server
// silently breaks every existing resource.
func TestLegacyRawAESCredentialStillReadsBack(t *testing.T) {
	const keyB64 = "bG9jYWwtdGVzdC1rZXktMzJieXRlcy1leGFjdGx5ISE="
	sealed, err := crypto.Encrypt("old-password", keyB64)
	if err != nil {
		t.Fatalf("legacy seal: %v", err)
	}
	entry := models.Credential{ID: "cred-2", SafeID: "safe-1", AccountName: "legacy", CredentialEnc: sealed}

	// With a KMS: EnvelopeDecryptor recognises the non-JSON shape and falls
	// back on its own.
	withKMS := (&ResourceService{}).WithKMS(testKMS(t))
	if got, err := withKMS.decryptCredential(entry); err != nil || got != "old-password" {
		t.Fatalf("legacy row via KMS = %q, %v; want old-password", got, err)
	}

	// And without one, for a deployment that never adopted envelopes.
	noKMS := &ResourceService{cryptoKey: keyB64}
	if got, err := noKMS.decryptCredential(entry); err != nil || got != "old-password" {
		t.Fatalf("legacy row without KMS = %q, %v; want old-password", got, err)
	}
}

// The failure that hid this one. An envelope reaching a service with no KMS
// must say so, not report a base64 error about a value that was never base64.
func TestEnvelopeWithoutKMSSaysWhatIsActuallyWrong(t *testing.T) {
	svc := &ResourceService{cryptoKey: "bG9jYWwtdGVzdC1rZXktMzJieXRlcy1leGFjdGx5ISE="}
	entry := models.Credential{CredentialEnc: `{"ciphertext":"aaaa","nonce":"bbbb"}`}

	_, err := svc.decryptCredential(entry)
	if err == nil {
		t.Fatal("expected an error")
	}
	if strings.Contains(err.Error(), "base64") {
		t.Errorf("error still describes the wrong scheme: %v", err)
	}
	if !strings.Contains(err.Error(), "KMS") {
		t.Errorf("error does not name the missing dependency: %v", err)
	}
}

// AAD is the point of the envelope: a ciphertext lifted onto another row must
// not open. Without this the envelope is just a slower AES.
func TestACredentialMovedToAnotherRowDoesNotOpen(t *testing.T) {
	kms := testKMS(t)
	svc := (&ResourceService{}).WithKMS(kms)

	original := models.Credential{ID: "c1", SafeID: "safe-prod", AccountName: "root", ResourceID: "res-prod"}
	sealed, err := crypto.EnvelopeEncryptor(context.Background(), kms, "prod-root-password", original.EncryptionAAD())
	if err != nil {
		t.Fatalf("seal: %v", err)
	}

	// Same ciphertext, different row identity — what an attacker with write
	// access to the table would try.
	moved := models.Credential{ID: "c2", SafeID: "safe-dev", AccountName: "root", ResourceID: "res-dev", CredentialEnc: sealed}
	if got, err := svc.decryptCredential(moved); err == nil {
		t.Fatalf("a ciphertext moved to another row decrypted to %q; the AAD binding is not in force", got)
	}
}
