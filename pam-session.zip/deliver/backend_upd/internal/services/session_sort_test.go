package services

import "testing"

// ORDER BY cannot take a bound placeholder — it takes an identifier — so the
// only defence is an allowlist. These tests are about the two ways that goes
// wrong: letting a request string reach the clause, and quietly changing the
// order every existing caller already depends on.

func TestSessionOrderByOnlyEmitsKnownColumns(t *testing.T) {
	// Anything a request could carry. None of it may appear in the output.
	hostile := []string{
		"started_at; DROP TABLE pam_connection_sessions",
		"(SELECT 1)",
		"username--",
		"1",
		"started_at DESC, (SELECT pg_sleep(10))",
		"pam_users.password_hash",
		"",
		"totally_unknown",
	}
	allowed := map[string]bool{}
	for _, col := range sessionSortColumns {
		allowed[col] = true
	}
	for _, s := range hostile {
		for _, desc := range []bool{true, false} {
			got := sessionOrderBy(s, desc)
			// Every clause is built from allowlisted identifiers plus ASC/DESC,
			// commas and spaces. Nothing else can be in there.
			for _, tok := range []string{";", "(", ")", "--", "/*", "SELECT", "pg_sleep", "password"} {
				if containsFold(got, tok) {
					t.Errorf("sessionOrderBy(%q, %v) = %q — leaked %q", s, desc, got, tok)
				}
			}
			first := firstIdentifier(got)
			if !allowed[first] {
				t.Errorf("sessionOrderBy(%q, %v) = %q — %q is not an allowlisted column", s, desc, got, first)
			}
		}
	}
}

func TestSessionOrderByKeepsTheHistoricalDefault(t *testing.T) {
	// Every caller that predates sorting passes no sort at all. If that fell
	// through to the generic ASC branch the sessions list would silently flip
	// to oldest-first — a behaviour change disguised as a feature.
	if got := sessionOrderBy("", false); got != "started_at DESC, id ASC" {
		t.Errorf("sessionOrderBy(\"\", false) = %q, want newest first", got)
	}
	if got := sessionOrderBy("", true); got != "started_at DESC, id ASC" {
		t.Errorf("sessionOrderBy(\"\", true) = %q, want newest first", got)
	}
}

func TestSessionOrderByIsAlwaysATotalOrder(t *testing.T) {
	// Two rows equal on the sort column must not be free to swap places
	// between requests: paging over an unstable order skips and repeats rows,
	// which looks like data loss and is near-impossible to reproduce.
	for key := range sessionSortColumns {
		for _, desc := range []bool{true, false} {
			got := sessionOrderBy(key, desc)
			if !containsFold(got, "id ASC") {
				t.Errorf("sessionOrderBy(%q, %v) = %q — no unique tiebreaker, so paging can skip rows", key, desc, got)
			}
		}
	}
	if !containsFold(sessionOrderBy("nonsense", false), "id ASC") {
		t.Error("the fallback order also needs a tiebreaker")
	}
}

func TestSessionSortDirectionIsHonoured(t *testing.T) {
	asc := sessionOrderBy("username", false)
	desc := sessionOrderBy("username", true)
	if asc == desc {
		t.Fatalf("direction ignored: both %q", asc)
	}
	if !containsFold(asc, "username ASC") {
		t.Errorf("ascending = %q", asc)
	}
	if !containsFold(desc, "username DESC") {
		t.Errorf("descending = %q", desc)
	}
	// The console's "duration" column is duration_seconds in the table.
	if !containsFold(sessionOrderBy("duration", true), "duration_seconds DESC") {
		t.Errorf("duration maps to %q", sessionOrderBy("duration", true))
	}
}

func containsFold(s, sub string) bool {
	return len(sub) <= len(s) && indexFold(s, sub) >= 0
}

func indexFold(s, sub string) int {
	lower := func(b byte) byte {
		if b >= 'A' && b <= 'Z' {
			return b + 32
		}
		return b
	}
	for i := 0; i+len(sub) <= len(s); i++ {
		ok := true
		for j := 0; j < len(sub); j++ {
			if lower(s[i+j]) != lower(sub[j]) {
				ok = false
				break
			}
		}
		if ok {
			return i
		}
	}
	return -1
}

func firstIdentifier(clause string) string {
	for i := 0; i < len(clause); i++ {
		if clause[i] == ' ' || clause[i] == ',' {
			return clause[:i]
		}
	}
	return clause
}
