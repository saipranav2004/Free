package services

import (
	"encoding/json"
	"strings"
	"testing"

	"go.uber.org/zap"
)

// The device report is what makes the two reported bugs fixable:
//
//  1. "clicking connect says handing off to the agent even when THIS machine
//     is not the paired one" — the console could not tell, because a device
//     row held a name and a public key and nothing about the machine.
//  2. "it says handing off even when the tool is not installed" — same cause:
//     nothing on the server knew what the machine had.
//
// These cover the server half: that a report is stored, that it is refreshed,
// and — the part that matters most — that an agent which sends nothing cannot
// erase a good report.

const capsJSON = `{"os":"linux","arch":"amd64","screen_recorder":true,` +
	`"types":[{"resource_type":"postgresql","kinds":["cli"],"tools":["psql"],` +
	`"missing":[{"id":"pgadmin4","kind":"gui","command":"pgadmin4","install_hint":"apt install pgadmin4"}]}]}`

func TestPairingStoresTheDeviceReport(t *testing.T) {
	db := newLaunchTestDB(t)
	svc := NewAgentService(db, nil, nil, nil, zap.NewNop())

	code, _, err := svc.InitPairing("u-1", pairingTTLForTest)
	if err != nil {
		t.Fatalf("InitPairing: %v", err)
	}
	device, err := svc.CompletePairing(code, "workstation (linux)", freshDeviceKey(t), &DeviceReport{
		OS: "linux", Arch: "amd64", Hostname: "workstation", AgentVersion: "2026.09.11",
		Capabilities: json.RawMessage(capsJSON),
	})
	if err != nil {
		t.Fatalf("CompletePairing: %v", err)
	}

	if device.OS != "linux" || device.Arch != "amd64" || device.Hostname != "workstation" {
		t.Fatalf("machine details not stored: %+v", device)
	}
	if device.AgentVersion != "2026.09.11" {
		t.Fatalf("agent version not stored: %q", device.AgentVersion)
	}
	if !strings.Contains(device.Capabilities, `"psql"`) {
		t.Fatalf("capabilities not stored: %q", device.Capabilities)
	}
	if device.CapabilitiesAt == nil {
		t.Fatal("capabilities_at not stamped, so the console cannot tell how stale the report is")
	}

	// It must survive the round trip the console actually reads.
	devices, err := svc.ListDevices("u-1")
	if err != nil {
		t.Fatalf("ListDevices: %v", err)
	}
	if len(devices) != 1 || devices[0].OS != "linux" {
		t.Fatalf("ListDevices lost the report: %+v", devices)
	}
	var parsed struct {
		Types []struct {
			ResourceType string   `json:"resource_type"`
			Kinds        []string `json:"kinds"`
			Tools        []string `json:"tools"`
		} `json:"types"`
	}
	if err := json.Unmarshal([]byte(devices[0].Capabilities), &parsed); err != nil {
		t.Fatalf("stored capabilities are not valid JSON: %v", err)
	}
	if len(parsed.Types) != 1 || parsed.Types[0].Tools[0] != "psql" {
		t.Fatalf("capabilities did not round-trip: %+v", parsed)
	}
}

// An agent older than this feature sends no report at all. It must pair
// normally, and — the case that would be a real regression — a re-pair from
// such an agent must not blank the details an up-to-date agent stored.
func TestAnOlderAgentNeitherFailsNorErasesAGoodReport(t *testing.T) {
	db := newLaunchTestDB(t)
	svc := NewAgentService(db, nil, nil, nil, zap.NewNop())
	const name = "workstation (linux)"

	code, _, _ := svc.InitPairing("u-2", pairingTTLForTest)
	if _, err := svc.CompletePairing(code, name, freshDeviceKey(t), &DeviceReport{
		OS: "linux", Arch: "amd64", Hostname: "workstation",
		Capabilities: json.RawMessage(capsJSON),
	}); err != nil {
		t.Fatalf("first pair: %v", err)
	}

	code2, _, _ := svc.InitPairing("u-2", pairingTTLForTest)
	device, err := svc.CompletePairing(code2, name, freshDeviceKey(t), nil)
	if err != nil {
		t.Fatalf("re-pair from an older agent failed: %v", err)
	}
	if device.OS != "linux" || device.Hostname != "workstation" {
		t.Fatalf("an older agent erased the machine details: %+v", device)
	}
	if !strings.Contains(device.Capabilities, `"psql"`) {
		t.Fatalf("an older agent erased the capability report: %q", device.Capabilities)
	}
}

// A partial report updates only what it names. Anything else would make a
// single missing field on one call throw away a good value from another.
func TestAPartialReportLeavesUnmentionedFieldsAlone(t *testing.T) {
	db := newLaunchTestDB(t)
	svc := NewAgentService(db, nil, nil, nil, zap.NewNop())
	const name = "laptop (darwin)"

	code, _, _ := svc.InitPairing("u-3", pairingTTLForTest)
	if _, err := svc.CompletePairing(code, name, freshDeviceKey(t), &DeviceReport{
		OS: "darwin", Arch: "arm64", Hostname: "laptop",
		Capabilities: json.RawMessage(capsJSON),
	}); err != nil {
		t.Fatalf("first pair: %v", err)
	}

	code2, _, _ := svc.InitPairing("u-3", pairingTTLForTest)
	device, err := svc.CompletePairing(code2, name, freshDeviceKey(t), &DeviceReport{
		AgentVersion: "2026.10.01",
	})
	if err != nil {
		t.Fatalf("re-pair: %v", err)
	}
	if device.AgentVersion != "2026.10.01" {
		t.Fatalf("the field that WAS reported did not update: %q", device.AgentVersion)
	}
	if device.OS != "darwin" || device.Arch != "arm64" {
		t.Fatalf("unmentioned fields were blanked: %+v", device)
	}
	if !strings.Contains(device.Capabilities, `"psql"`) {
		t.Fatalf("unmentioned capabilities were blanked: %q", device.Capabilities)
	}
}

// An absurd report is refused rather than stored: it is read back by
// administrators and comes from a machine PAM does not control.
func TestAnOversizedCapabilityReportIsNotStored(t *testing.T) {
	db := newLaunchTestDB(t)
	svc := NewAgentService(db, nil, nil, nil, zap.NewNop())

	huge := `{"types":["` + strings.Repeat("x", maxCapabilitiesBytes) + `"]}`
	code, _, _ := svc.InitPairing("u-4", pairingTTLForTest)
	device, err := svc.CompletePairing(code, "big (linux)", freshDeviceKey(t), &DeviceReport{
		OS: "linux", Capabilities: json.RawMessage(huge),
	})
	if err != nil {
		t.Fatalf("pairing must still succeed: %v", err)
	}
	if device.Capabilities != "" {
		t.Fatalf("an oversized report was stored (%d bytes)", len(device.Capabilities))
	}
	if device.OS != "linux" {
		t.Fatal("the rest of the report should still have applied")
	}
}
