package services

import (
	"testing"

	"github.com/glebarez/sqlite"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// The bug these cover
// -------------------
// The Admin Center's audit screen has one box labelled "Username or ID". The
// console sent what was typed as `actor`; the handler read `actor_user_id`,
// so the filter never reached the database. The server answered with an
// unfiltered page and the browser filtered whatever happened to be on it, so
// searching for somebody worked when their events were on the page in hand
// and returned nothing when they were not — reported as "does not
// consistently return the correct matching results".
//
// ActorUserID could not have served that box even once wired: it compares the
// whole user_id, so a username matched nothing and a partial id matched
// nothing. Hence AuditFilter.Actor, and hence these tests.

func auditFilterDB(t *testing.T) *gorm.DB {
	t.Helper()
	// models.AuditLog qualifies its table with PAM_DATABASE_SCHEMA; unset that
	// is a leading dot, which sqlite rejects. Same shim the neighbouring tests use.
	t.Setenv("PAM_DATABASE_SCHEMA", "main")

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		t.Fatalf("open in-memory sqlite: %v", err)
	}
	if err := db.AutoMigrate(&models.AuditLog{}); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

func seedAuditRows(t *testing.T, db *gorm.DB) {
	t.Helper()
	rows := []models.AuditLog{
		{UserID: "11111111-aaaa-4000-8000-000000000001", Username: "mallesh", Action: "auth:login", Outcome: models.AuditOutcomeSuccess},
		{UserID: "11111111-aaaa-4000-8000-000000000001", Username: "mallesh", Action: "pam:session:Start", Outcome: models.AuditOutcomeSuccess},
		{UserID: "22222222-bbbb-4000-8000-000000000002", Username: "rohit", Action: "auth:login", Outcome: models.AuditOutcomeSuccess},
		{UserID: "33333333-cccc-4000-8000-000000000003", Username: "das.admin", Action: "pam:vault:Reveal", Outcome: models.AuditOutcomeSuccess},
	}
	for i := range rows {
		rows[i].SequenceNumber = int64(i + 1)
		if err := db.Create(&rows[i]).Error; err != nil {
			t.Fatalf("seed audit row %d: %v", i, err)
		}
	}
}

func newAuditSvcForFilter(db *gorm.DB) *AuditService {
	return NewAuditService(db, []byte("test-secret-not-used-by-List-0001"), "default", zap.NewNop())
}

func TestAuditFilterActor(t *testing.T) {
	db := auditFilterDB(t)
	seedAuditRows(t, db)
	svc := newAuditSvcForFilter(db)

	cases := []struct {
		name  string
		actor string
		want  int
	}{
		// The exact thing the reporter typed: a username, not a UUID.
		{"full username", "mallesh", 2},
		// Partial, because people type the first few letters and stop.
		{"username prefix", "mal", 2},
		{"username is case-insensitive", "MALLESH", 2},
		// The other half of the field's own label.
		{"full user id", "22222222-bbbb-4000-8000-000000000002", 1},
		{"user id prefix", "33333333", 1},
		// A dot in a username must be matched literally, not as a wildcard.
		{"dotted username", "das.admin", 1},
		{"no match", "nobody-by-this-name", 0},
		// Empty must not filter anything out.
		{"empty actor returns everything", "", 4},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rows, total, err := svc.List(AuditFilter{Actor: tc.actor, PageSize: 100})
			if err != nil {
				t.Fatalf("List: %v", err)
			}
			if len(rows) != tc.want || int(total) != tc.want {
				t.Fatalf("actor %q: got %d rows (total %d), want %d", tc.actor, len(rows), total, tc.want)
			}
		})
	}
}

// Actor must narrow the set alongside the other filters, not replace them or
// leak rows past them. This is the case GORM's OR-parenthesising gets wrong if
// the clause is ever split into two chained Where calls.
func TestAuditFilterActorCombinesWithOtherFilters(t *testing.T) {
	db := auditFilterDB(t)
	seedAuditRows(t, db)
	svc := newAuditSvcForFilter(db)

	rows, total, err := svc.List(AuditFilter{Actor: "mallesh", Action: "auth:login", PageSize: 100})
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if len(rows) != 1 || total != 1 {
		t.Fatalf("actor+action: got %d rows (total %d), want 1", len(rows), total)
	}
	if rows[0].Username != "mallesh" || rows[0].Action != "auth:login" {
		t.Fatalf("wrong row returned: %+v", rows[0])
	}

	// rohit has no session-start event; the actor filter must not let one
	// through just because the action matches somebody else's row.
	_, total, err = svc.List(AuditFilter{Actor: "rohit", Action: "pam:session:Start", PageSize: 100})
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if total != 0 {
		t.Fatalf("actor+action mismatch: got total %d, want 0", total)
	}
}

// ActorUserID keeps its exact-match meaning for callers that hold a real id.
func TestAuditFilterActorUserIDStaysExact(t *testing.T) {
	db := auditFilterDB(t)
	seedAuditRows(t, db)
	svc := newAuditSvcForFilter(db)

	_, total, err := svc.List(AuditFilter{ActorUserID: "11111111-aaaa-4000-8000-000000000001", PageSize: 100})
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if total != 2 {
		t.Fatalf("exact id: got %d, want 2", total)
	}

	// A prefix must NOT match here — that is what Actor is for.
	_, total, err = svc.List(AuditFilter{ActorUserID: "11111111", PageSize: 100})
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if total != 0 {
		t.Fatalf("prefix against ActorUserID: got %d, want 0 (exact match only)", total)
	}
}
