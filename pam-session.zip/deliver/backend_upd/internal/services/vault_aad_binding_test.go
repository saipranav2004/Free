package services

import (
	"context"
	"os"
	"testing"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// THE LATENT BUG THIS PINS DOWN.
//
// Credential.SafeID carries `gorm:"default:'default'"`. A GORM column default
// applies only once the row reaches the DATABASE — GORM omits the Go zero
// value from the INSERT and lets Postgres fill it in.
//
// The envelope's AAD (the data AES-GCM authenticates but does not encrypt) is
// built from SafeID. StoreCredential builds it from the REQUEST, before the
// insert; every read builds it from the ROW, after it. So for a credential
// stored with an empty safe_id:
//
//	STORE: AAD = {account}                      (SafeID "" in Go)
//	         ↓ INSERT, Postgres fills 'default'
//	READ:  AAD = {account, safe_id:"default"}    (SafeID "default" from the DB)
//	         ↓
//	       AES-GCM tag mismatch — undecryptable, permanently.
//
// The credential stores fine, lists fine, and then can never be read. Nothing
// surfaces it until somebody tries.
//
// Runs against real Postgres because that is where the column default lives;
// on sqlite the defect does not reproduce at all.
func vaultAADTestDB(t *testing.T) *gorm.DB {
	t.Helper()
	dsn := os.Getenv("PAM_TEST_POSTGRES_DSN")
	if dsn == "" {
		t.Skip("set PAM_TEST_POSTGRES_DSN to run the vault AAD binding test against Postgres")
	}
	t.Setenv("PAM_KMS_PROVIDER", "local-dev")
	t.Setenv("PAM_VAULT_ENCRYPTION_KEY", "bG9jYWwtdGVzdC1rZXktMzJieXRlcy1leGFjdGx5ISE=")

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("open postgres: %v", err)
	}
	// A private schema per run, so a failure cannot poison another test.
	if err := db.Exec(`DROP SCHEMA IF EXISTS vault_aad_test CASCADE; CREATE SCHEMA vault_aad_test;`).Error; err != nil {
		t.Fatalf("create schema: %v", err)
	}
	t.Cleanup(func() { db.Exec(`DROP SCHEMA IF EXISTS vault_aad_test CASCADE;`) })
	if err := db.Exec(`SET search_path TO vault_aad_test`).Error; err != nil {
		t.Fatalf("search_path: %v", err)
	}
	if err := db.AutoMigrate(&models.Safe{}, &models.Folder{}, &models.Credential{},
		&models.CredentialVersion{}, &models.PasswordPolicy{}); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

// A credential stored WITHOUT an explicit safe_id must still be readable.
// Before the fix this failed with an AES-GCM authentication error.
func TestCredentialStoredWithNoSafeIDIsStillReadable(t *testing.T) {
	db := vaultAADTestDB(t)
	svc, err := NewVaultService(db, zap.NewNop())
	if err != nil {
		t.Fatalf("NewVaultService: %v", err)
	}
	ctx := context.Background()

	cred, err := svc.StoreCredential(ctx, StoreCredentialRequest{
		// SafeID deliberately EMPTY — this is the whole point.
		AccountName:     "app_user",
		Name:            "pg-app-writer",
		CredentialType:  models.CredentialTypePassword,
		SecretPlaintext: "s3cr3t-value",
		CreatedBy:       "tester",
	})
	if err != nil {
		t.Fatalf("StoreCredential: %v", err)
	}

	// Read it back the way the database has it, not the way Go left it.
	var row models.Credential
	if err := db.Where("id = ?", cred.ID).First(&row).Error; err != nil {
		t.Fatalf("reload: %v", err)
	}
	t.Logf("safe_id as stored in the database: %q", row.SafeID)

	got, err := svc.RevealCredential(ctx, cred.ID, "tester", "verifying AAD binding")
	if err != nil {
		t.Fatalf("a credential stored with no safe_id could not be read back: %v\n"+
			"This is the AAD drift: it was sealed under AAD without safe_id, and the read "+
			"derives one from the row where Postgres filled in %q.", err, row.SafeID)
	}
	if got.Plaintext != "s3cr3t-value" {
		t.Fatalf("wrong plaintext: %q", got.Plaintext)
	}
}

// The same credential, stored with safe_id given explicitly, has always
// worked — included so a failure above cannot be blamed on the harness.
func TestCredentialStoredWithAnExplicitSafeIDIsReadable(t *testing.T) {
	db := vaultAADTestDB(t)
	svc, err := NewVaultService(db, zap.NewNop())
	if err != nil {
		t.Fatalf("NewVaultService: %v", err)
	}
	ctx := context.Background()

	cred, err := svc.StoreCredential(ctx, StoreCredentialRequest{
		SafeID:          "default",
		AccountName:     "app_user",
		Name:            "pg-app-writer-2",
		CredentialType:  models.CredentialTypePassword,
		SecretPlaintext: "another-secret",
		CreatedBy:       "tester",
	})
	if err != nil {
		t.Fatalf("StoreCredential: %v", err)
	}
	got, err := svc.RevealCredential(ctx, cred.ID, "tester", "verifying AAD binding")
	if err != nil {
		t.Fatalf("RevealCredential: %v", err)
	}
	if got.Plaintext != "another-secret" {
		t.Fatalf("wrong plaintext: %q", got.Plaintext)
	}
}
