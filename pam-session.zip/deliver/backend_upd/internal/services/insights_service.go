// pam/internal/services/insights_service.go
//
// The numbers the console's insight cards are built from.
//
// Analytics lived on one screen out of eleven, and every other page opened
// straight into a table. The charts existed; what was missing was anything to
// put in them per page. These are those figures — each one answering a
// question an operator would otherwise work out by scanning the table
// underneath it.
//
// Every query here is deliberately cheap and bounded: an insight strip renders
// above the content on a page somebody opens constantly, so it has to cost
// about as much as the listing it sits above, not more.
package services

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/models"
	"gorm.io/gorm"
)

// InsightsService reads aggregate figures for the console's insight cards.
type InsightsService struct {
	db *gorm.DB
}

func NewInsightsService(db *gorm.DB) *InsightsService {
	return &InsightsService{db: db}
}

// LabelledCount is the shape every breakdown comes back in: something named,
// and how many of it there are.
type LabelledCount struct {
	Label string `json:"label"`
	Value int64  `json:"value"`
}

// TimeBucket is one column of a time series.
type TimeBucket struct {
	Label string `json:"label"`
	Value int64  `json:"value"`
	// Denied is drawn as a separate segment on the same column: on an audit
	// chart the ratio of refusals to total is the interesting shape, and
	// splitting it across two charts loses that.
	Denied int64 `json:"denied,omitempty"`
}

// ── Sessions ────────────────────────────────────────────────────────────────

// SessionInsights answers "what is happening right now", which is the question
// the sessions table makes you count rows to answer.
type SessionInsights struct {
	ActiveNow int64           `json:"active_now"`
	ByChannel []LabelledCount `json:"by_channel"`
	// BreakglassActive and LongestActiveSeconds used to be counted in the
	// browser over the rows the sessions table had loaded — and that table is
	// capped at the most recent 200. Past the cap the figures silently stopped
	// being true, which is the worst way for a number to be wrong: it still
	// looks like an answer. Counted here, over everything.
	BreakglassActive     int64        `json:"breakglass_active"`
	LongestActiveSeconds int64        `json:"longest_active_seconds"`
	RecordedShare        int          `json:"recorded_share_pct"`
	RecordedOf           int64        `json:"recorded_of"`
	DurationSpread       []TimeBucket `json:"duration_spread"`
}

func (s *InsightsService) Sessions(ctx context.Context, userID string, scopeToUser bool) (*SessionInsights, error) {
	out := &SessionInsights{}
	base := s.db.WithContext(ctx).Model(&models.ConnectionSession{})
	if scopeToUser {
		base = base.Where("user_id = ?", userID)
	}

	if err := base.Session(&gorm.Session{}).
		Where("status = ?", "ACTIVE").Count(&out.ActiveNow).Error; err != nil {
		return nil, fmt.Errorf("failed to count active sessions: %w", err)
	}

	// Grouped by resource type rather than by channel: the channel a native
	// session used is not stored on the row, and inventing a column to make a
	// chart prettier is the wrong trade. Resource type is what an operator
	// actually recognises anyway.
	var byType []LabelledCount
	if err := base.Session(&gorm.Session{}).
		Select("resource_type AS label, COUNT(*) AS value").
		Where("status = ?", "ACTIVE").
		Group("resource_type").Order("value DESC").Limit(6).
		Scan(&byType).Error; err != nil {
		return nil, fmt.Errorf("failed to group active sessions: %w", err)
	}
	if byType == nil {
		byType = []LabelledCount{}
	}
	out.ByChannel = byType

	if err := base.Session(&gorm.Session{}).
		Where("status = ? AND is_breakglass = ?", "ACTIVE", true).
		Count(&out.BreakglassActive).Error; err != nil {
		return nil, fmt.Errorf("failed to count break-glass sessions: %w", err)
	}

	// Longest RUNNING session, measured from started_at rather than read from
	// duration_seconds: that column is only stamped when a session ends, so on
	// a live row it is zero and "longest running" would always answer 0.
	// sql.NullTime, not *time.Time: MIN() over no rows is NULL, and the driver
	// refuses to store a NULL into a *time.Time — it errors rather than
	// leaving the pointer nil. An install with nothing running is the normal
	// case, not an edge case.
	var oldestStart sql.NullTime
	if err := base.Session(&gorm.Session{}).
		Where("status = ?", "ACTIVE").
		Select("MIN(started_at)").Scan(&oldestStart).Error; err != nil {
		return nil, fmt.Errorf("failed to find the longest running session: %w", err)
	}
	if oldestStart.Valid {
		if elapsed := time.Since(oldestStart.Time); elapsed > 0 {
			out.LongestActiveSeconds = int64(elapsed.Seconds())
		}
	}

	// Recording coverage over the last week. "How much of what we did is
	// actually on tape" is the compliance question, and nothing on screen
	// answered it.
	since := time.Now().UTC().AddDate(0, 0, -7)
	var total, recorded int64
	weekly := base.Session(&gorm.Session{}).Where("started_at >= ?", since)
	if err := weekly.Session(&gorm.Session{}).Count(&total).Error; err != nil {
		return nil, err
	}
	if err := weekly.Session(&gorm.Session{}).
		Where("recording_id IS NOT NULL").Count(&recorded).Error; err != nil {
		return nil, err
	}
	out.RecordedOf = total
	if total > 0 {
		out.RecordedShare = int(recorded * 100 / total)
	}

	// Duration spread, as buckets rather than an average. An average session
	// length hides the thing worth seeing, which is the long tail.
	type bucketRow struct {
		Label string
		Value int64
	}
	var spread []bucketRow
	err := base.Session(&gorm.Session{}).
		Select(`CASE
				WHEN duration_seconds < 60 THEN '< 1m'
				WHEN duration_seconds < 300 THEN '1-5m'
				WHEN duration_seconds < 1800 THEN '5-30m'
				WHEN duration_seconds < 7200 THEN '30m-2h'
				ELSE '2h+'
			END AS label, COUNT(*) AS value`).
		Where("started_at >= ? AND status <> ?", since, "ACTIVE").
		Group("label").Scan(&spread).Error
	if err != nil {
		return nil, fmt.Errorf("failed to bucket session durations: %w", err)
	}
	// Ordered here rather than in SQL: the buckets are ordinal, and sorting
	// them alphabetically would put "1-5m" after "< 1m" but "30m-2h" before
	// "5-30m", which reads as noise.
	order := []string{"< 1m", "1-5m", "5-30m", "30m-2h", "2h+"}
	byLabel := map[string]int64{}
	for _, r := range spread {
		byLabel[r.Label] = r.Value
	}
	for _, label := range order {
		out.DurationSpread = append(out.DurationSpread, TimeBucket{Label: label, Value: byLabel[label]})
	}
	return out, nil
}

// secretReadActions are the audit actions that mean "somebody saw a secret".
// These are the strings the vault path actually writes (secret_access_service),
// not a guess at what they might be called: an insight card fed by an action
// name nothing emits shows a flat zero line forever and looks like a quiet
// week rather than a bug.
var secretReadActions = []string{"pam.secret.read", "pam.secret.batch_read"}

// ── Vault ───────────────────────────────────────────────────────────────────

type VaultInsights struct {
	TotalSecrets    int64           `json:"total_secrets"`
	BySafe          []LabelledCount `json:"by_safe"`
	RotationOverdue int64           `json:"rotation_overdue"`
	BreakglassCount int64           `json:"breakglass_count"`
	RevealsByDay    []TimeBucket    `json:"reveals_by_day"`
}

func (s *InsightsService) Vault(ctx context.Context) (*VaultInsights, error) {
	out := &VaultInsights{}
	creds := s.db.WithContext(ctx).Model(&models.Credential{}).Where("status = ?", "active")

	if err := creds.Session(&gorm.Session{}).Count(&out.TotalSecrets).Error; err != nil {
		return nil, fmt.Errorf("failed to count credentials: %w", err)
	}
	if err := creds.Session(&gorm.Session{}).
		Select("COALESCE(pam_safes.name, 'unfiled') AS label, COUNT(*) AS value").
		Joins("LEFT JOIN pam_safes ON pam_safes.id = pam_credentials.safe_id AND pam_safes.deleted_at IS NULL").
		Group("label").Order("value DESC").Limit(6).
		Scan(&out.BySafe).Error; err != nil {
		return nil, fmt.Errorf("failed to group credentials by safe: %w", err)
	}
	if out.BySafe == nil {
		out.BySafe = []LabelledCount{}
	}

	now := time.Now().UTC()
	if err := creds.Session(&gorm.Session{}).
		Where("next_rotation_at IS NOT NULL AND next_rotation_at < ?", now).
		Count(&out.RotationOverdue).Error; err != nil {
		return nil, err
	}
	if err := creds.Session(&gorm.Session{}).
		Where("is_breakglass = ?", true).Count(&out.BreakglassCount).Error; err != nil {
		return nil, err
	}

	// Reveals over 30 days, read from the audit trail rather than a counter:
	// the audit log is the record of what happened, and a second counter
	// would be a second truth to keep in step.
	buckets, err := s.dailyAuditCounts(ctx, 30, secretReadActions, "")
	if err != nil {
		return nil, err
	}
	out.RevealsByDay = buckets
	return out, nil
}

// ── Service identities ──────────────────────────────────────────────────────

type ServiceInsights struct {
	// Identities counts ACTIVE identities only, and Disabled counts the rest.
	// Both are returned because the card sits directly above a table that
	// lists every identity including the disabled ones: reporting "2 / 4"
	// over a list headed "16" reads as the two disagreeing, when they are
	// answering different questions. The card has to be able to say which
	// question it answered.
	Identities int64 `json:"identities"`
	Disabled   int64 `json:"disabled"`
	// ReadyCount is how many active identities can actually authenticate AND
	// read something: a live token and a live grant. An identity with one but
	// not the other is configured, not working, and that gap is invisible in
	// a list that shows every identity as "active".
	ReadyCount     int64           `json:"ready_count"`
	ScopeBreadth   []LabelledCount `json:"scope_breadth"`
	TokensExpiring []TimeBucket    `json:"tokens_expiring"`
	VaultWide      int64           `json:"vault_wide"`
}

func (s *InsightsService) Services(ctx context.Context) (*ServiceInsights, error) {
	out := &ServiceInsights{}
	now := time.Now().UTC()

	if err := s.db.WithContext(ctx).Model(&models.ServiceIdentity{}).
		Where("status = ?", "active").Count(&out.Identities).Error; err != nil {
		return nil, fmt.Errorf("failed to count service identities: %w", err)
	}

	if err := s.db.WithContext(ctx).Model(&models.ServiceIdentity{}).
		Where("status <> ?", "active").Count(&out.Disabled).Error; err != nil {
		return nil, fmt.Errorf("failed to count disabled service identities: %w", err)
	}

	// Two EXISTS rather than two joins: joining live tokens to live grants
	// multiplies the rows and then needs a DISTINCT to undo itself, which is
	// both slower and easier to get subtly wrong.
	if err := s.db.WithContext(ctx).Model(&models.ServiceIdentity{}).
		Where("status = ?", "active").
		Where(`EXISTS (SELECT 1 FROM pam_service_tokens t
			WHERE t.service_id = pam_service_identities.id
			  AND t.revoked_at IS NULL
			  AND (t.expires_at IS NULL OR t.expires_at > ?))`, now).
		Where(`EXISTS (SELECT 1 FROM pam_service_grants g
			WHERE g.service_id = pam_service_identities.id
			  AND g.revoked_at IS NULL
			  AND (g.expires_at IS NULL OR g.expires_at > ?))`, now).
		Count(&out.ReadyCount).Error; err != nil {
		return nil, fmt.Errorf("failed to count ready service identities: %w", err)
	}

	// Scope breadth, classified in Go because the glob dialect is defined
	// there (models.ScopeBreadth) and encoding it in SQL would be a second
	// implementation to keep in step with the matcher.
	var grants []models.ServiceGrant
	if err := s.db.WithContext(ctx).
		Where("revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)", now).
		Find(&grants).Error; err != nil {
		return nil, err
	}
	counts := map[string]int64{}
	for i := range grants {
		b := models.ScopeBreadth(grants[i].Scope)
		counts[b]++
		if b == models.ScopeBreadthAll {
			out.VaultWide++
		}
	}
	for _, b := range []string{models.ScopeBreadthExact, models.ScopeBreadthWildcard, models.ScopeBreadthSubtree, models.ScopeBreadthAll} {
		out.ScopeBreadth = append(out.ScopeBreadth, LabelledCount{Label: b, Value: counts[b]})
	}

	// Token expiry runway. "How much notice do I have" is the operational
	// question, and a list of dates does not answer it at a glance.
	type row struct {
		Label string
		Value int64
	}
	var runway []row
	err := s.db.WithContext(ctx).Model(&models.ServiceToken{}).
		Select(`CASE
				WHEN expires_at IS NULL THEN 'never'
				WHEN expires_at < NOW() THEN 'expired'
				WHEN expires_at < NOW() + INTERVAL '7 days' THEN '< 7d'
				WHEN expires_at < NOW() + INTERVAL '30 days' THEN '< 30d'
				ELSE '30d+'
			END AS label, COUNT(*) AS value`).
		Where("revoked_at IS NULL").
		Group("label").Scan(&runway).Error
	if err != nil {
		return nil, fmt.Errorf("failed to bucket token expiry: %w", err)
	}
	byLabel := map[string]int64{}
	for _, r := range runway {
		byLabel[r.Label] = r.Value
	}
	for _, label := range []string{"expired", "< 7d", "< 30d", "30d+", "never"} {
		out.TokensExpiring = append(out.TokensExpiring, TimeBucket{Label: label, Value: byLabel[label]})
	}
	return out, nil
}

// ── Shared ──────────────────────────────────────────────────────────────────

// dailyAuditCounts buckets audit events by day, filling empty days with zero
// so a sparse series still reads as a timeline rather than as a few floating
// points.
func (s *InsightsService) dailyAuditCounts(ctx context.Context, days int, actions []string, scopeUserID string) ([]TimeBucket, error) {
	since := time.Now().UTC().AddDate(0, 0, -days).Truncate(24 * time.Hour)

	type row struct {
		Day   time.Time
		Total int64
	}
	var rows []row
	q := s.db.WithContext(ctx).Model(&models.AuditLog{}).
		Select("DATE_TRUNC('day', occurred_at) AS day, COUNT(*) AS total").
		Where("occurred_at >= ?", since)
	if len(actions) > 0 {
		q = q.Where("action IN ?", actions)
	}
	if scopeUserID != "" {
		q = q.Where("user_id = ?", scopeUserID)
	}
	if err := q.Group("day").Order("day").Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("failed to bucket audit events: %w", err)
	}

	byDay := map[string]int64{}
	for _, r := range rows {
		byDay[r.Day.Format("2006-01-02")] = r.Total
	}
	out := make([]TimeBucket, 0, days)
	for i := days - 1; i >= 0; i-- {
		d := time.Now().UTC().AddDate(0, 0, -i).Format("2006-01-02")
		out = append(out, TimeBucket{Label: d, Value: byDay[d]})
	}
	return out, nil
}

// AuditInsights answers the questions the audit table makes you filter for.
type AuditInsights struct {
	EventsByDay []TimeBucket    `json:"events_by_day"`
	TopActors   []LabelledCount `json:"top_actors"`
	DeniedRate  int             `json:"denied_rate_pct"`
	TotalEvents int64           `json:"total_events"`
}

// Audit reads the figures over the caller's own visible slice of the trail.
//
// scopeUserID carries the same rule the audit LISTING already enforces: empty
// for root and admin, the caller's own id for everyone else. An aggregate is
// still a disclosure — "who are the busiest actors in the org" is exactly the
// question a non-admin must not get an answer to, and it would have been
// easier to leak here than in the table underneath, because no row is ever
// shown.
func (s *InsightsService) Audit(ctx context.Context, days int, scopeUserID string) (*AuditInsights, error) {
	out := &AuditInsights{}
	since := time.Now().UTC().AddDate(0, 0, -days)

	buckets, err := s.dailyAuditCounts(ctx, days, nil, scopeUserID)
	if err != nil {
		return nil, err
	}
	out.EventsByDay = buckets

	base := s.db.WithContext(ctx).Model(&models.AuditLog{}).Where("occurred_at >= ?", since)
	if scopeUserID != "" {
		base = base.Where("user_id = ?", scopeUserID)
	}
	if err := base.Session(&gorm.Session{}).Count(&out.TotalEvents).Error; err != nil {
		return nil, err
	}
	if err := base.Session(&gorm.Session{}).
		Select("COALESCE(NULLIF(username, ''), user_id) AS label, COUNT(*) AS value").
		Group("label").Order("value DESC").Limit(6).
		Scan(&out.TopActors).Error; err != nil {
		return nil, fmt.Errorf("failed to find top actors: %w", err)
	}
	if out.TopActors == nil {
		out.TopActors = []LabelledCount{}
	}

	var denied int64
	if err := base.Session(&gorm.Session{}).
		Where("outcome = ?", models.OutcomeDenied).Count(&denied).Error; err != nil {
		return nil, err
	}
	if out.TotalEvents > 0 {
		out.DeniedRate = int(denied * 100 / out.TotalEvents)
	}
	return out, nil
}
