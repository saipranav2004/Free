// pam/internal/services/agent_heartbeat.go
//
// The channel from server to agent that did not exist.
//
// Every other agent call is one-shot and outbound: pair, resolve, end, upload.
// Nothing could reach a RUNNING agent, and two failures followed directly from
// that. An administrator's force-terminate closed the database row while the
// operator's psql carried on, because PAM is not in that data path and had no
// way to say stop. And an agent that died — lid closed, process killed, network
// gone — left an ACTIVE row until the next server restart, because native
// sessions had no periodic reaper and nothing to reap on.
//
// A heartbeat fixes both, and it only works because the RESPONSE carries
// instructions back. The agent is not being watched; it is asking.
package services

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

const (
	// HeartbeatInterval is what the agent is told to use. Short enough that a
	// force-terminate feels immediate, long enough that a thousand idle
	// sessions are not a load problem.
	HeartbeatInterval = 10 * time.Second

	// heartbeatGrace is how long a session may go unheard before the reaper
	// closes it. Deliberately several intervals: a laptop that sleeps briefly,
	// a VPN that reconnects, or a server pause must not end a session somebody
	// is still using. Ending a live session wrongly is far worse than leaving
	// a dead row a minute longer.
	heartbeatGrace = 90 * time.Second
)

// HeartbeatResult is what the agent gets back. The instruction is the point.
type HeartbeatResult struct {
	// Terminate tells the agent to stop the session's process now. This is the
	// only way an administrator's kill reaches the operator's machine.
	Terminate bool `json:"terminate"`
	// Reason is shown to the operator so a window closing under them is
	// explained rather than mysterious.
	Reason string `json:"reason,omitempty"`
	// IntervalSeconds lets the server retune the cadence without redeploying
	// every agent in the fleet.
	IntervalSeconds int `json:"interval_seconds"`
}

// Heartbeat records that an agent is still running a session, and answers with
// anything the server needs it to do.
//
// Authenticated the same way every other agent call is: the device signs the
// session id with its Ed25519 key. A heartbeat that could be forged would let
// anyone keep a dead session looking alive, or — worse — learn that a
// terminate had been ordered.
func (s *AgentService) Heartbeat(sessionID, agentDeviceID, signatureB64 string, timestamp time.Time) (*HeartbeatResult, error) {
	var device models.AgentDevice
	if err := s.db.Where("id = ?", agentDeviceID).First(&device).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrDeviceNotFound
		}
		return nil, err
	}
	if device.Status != "ACTIVE" {
		// A revoked device is told to stop. Revoking a device that is midway
		// through a session should end that session, not wait for it.
		return &HeartbeatResult{
			Terminate:       true,
			Reason:          "This device's access has been revoked.",
			IntervalSeconds: int(HeartbeatInterval.Seconds()),
		}, nil
	}
	if err := verifySignature(device.PublicKey, sessionID, timestamp, signatureB64); err != nil {
		s.logger.Warn("agent.heartbeat.signature_invalid",
			zap.String("device_id", agentDeviceID), zap.String("session_id", sessionID))
		return nil, ErrSignatureInvalid
	}

	var session models.ConnectionSession
	if err := s.db.Where("id = ?", sessionID).First(&session).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrSessionNotFound
		}
		return nil, err
	}

	result := &HeartbeatResult{IntervalSeconds: int(HeartbeatInterval.Seconds())}

	// A session that is no longer ACTIVE has already been closed out by
	// somebody — an administrator, the reaper, or the agent itself on a
	// previous run. Whatever the cause, the tool on the operator's machine
	// should not still be open.
	if session.Status != "ACTIVE" {
		result.Terminate = true
		result.Reason = terminateReason(&session)
		return result, nil
	}

	if session.TerminateRequestedAt != nil {
		result.Terminate = true
		result.Reason = terminateReason(&session)
	}

	now := time.Now().UTC()
	if err := s.db.Model(&models.ConnectionSession{}).
		Where("id = ?", sessionID).
		Update("last_heartbeat_at", now).Error; err != nil {
		return nil, fmt.Errorf("failed to record heartbeat: %w", err)
	}
	return result, nil
}

// terminateReason puts the administrator's own words in front of the operator
// where there are any, so a window closing under them is explained.
func terminateReason(session *models.ConnectionSession) string {
	if session.KillReason != "" {
		return session.KillReason
	}
	return "This session was ended by an administrator."
}

// RequestTerminate marks a session for termination without claiming it has
// happened.
//
// The distinction matters and is the whole reason this is separate from the
// existing kill path: marking a row KILLED says "the access is stopped", and
// for a native session that was simply untrue — the operator's psql was still
// connected. The row now moves to KILLED only when the agent confirms, and
// until then the console can honestly say "stopping".
func (s *AgentService) RequestTerminate(sessionID, requestedBy, reason string) error {
	now := time.Now().UTC()
	updates := map[string]any{
		"terminate_requested_at": now,
		"killed_by":              requestedBy,
	}
	if reason != "" {
		updates["kill_reason"] = reason
	}
	res := s.db.Model(&models.ConnectionSession{}).
		Where("id = ? AND status = ?", sessionID, "ACTIVE").
		Updates(updates)
	if res.Error != nil {
		return res.Error
	}
	if res.RowsAffected == 0 {
		return ErrSessionNotFound
	}
	s.logger.Info("agent.session.terminate_requested",
		zap.String("session_id", sessionID), zap.String("by", requestedBy))
	return nil
}

// ── The reaper ──────────────────────────────────────────────────────────────

// NativeSessionReconciler closes out sessions whose agent has stopped checking
// in. Registered with the same sweeper that already expires JIT grants, so it
// runs on a schedule that exists rather than inventing another ticker.
type NativeSessionReconciler struct {
	svc *AgentService
}

// NewNativeSessionReconciler wires the reaper to an agent service.
func NewNativeSessionReconciler(svc *AgentService) *NativeSessionReconciler {
	return &NativeSessionReconciler{svc: svc}
}

func (r *NativeSessionReconciler) Name() string { return "native-agent-sessions" }

// ReconcileExpired closes ACTIVE sessions that have not been heard from within
// the grace window.
//
// ONLY sessions that have heartbeat at least once are eligible. That is what
// keeps this from sweeping away session types it knows nothing about — a
// brokered web session, which the proxy closes itself, or anything started by
// an agent too old to heartbeat. A reaper that closed sessions it did not
// understand would be worse than no reaper at all.
func (r *NativeSessionReconciler) ReconcileExpired(ctx context.Context) (int, error) {
	cutoff := time.Now().UTC().Add(-heartbeatGrace)
	now := time.Now().UTC()

	var stale []models.ConnectionSession
	if err := r.svc.db.WithContext(ctx).
		Where("status = ? AND last_heartbeat_at IS NOT NULL AND last_heartbeat_at < ?",
			"ACTIVE", cutoff).
		Find(&stale).Error; err != nil {
		return 0, fmt.Errorf("failed to find stale agent sessions: %w", err)
	}
	if len(stale) == 0 {
		return 0, nil
	}

	closed := 0
	for i := range stale {
		session := &stale[i]
		duration := int(now.Sub(session.StartedAt).Seconds())
		if duration < 0 {
			duration = 0
		}
		// COMPLETED, not KILLED: the agent going quiet is almost always the
		// operator closing their laptop, not an administrator's action, and
		// recording it as a kill would put a disciplinary-looking event on
		// somebody's audit trail for shutting a lid.
		err := r.svc.db.WithContext(ctx).Model(&models.ConnectionSession{}).
			Where("id = ? AND status = ?", session.ID, "ACTIVE").
			Updates(map[string]any{
				"status":           "COMPLETED",
				"ended_at":         now,
				"duration_seconds": duration,
				"kill_reason":      "The agent stopped reporting; the session was closed automatically.",
			}).Error
		if err != nil {
			r.svc.logger.Error("agent.session.reap.fail",
				zap.String("session_id", session.ID), zap.Error(err))
			continue
		}
		closed++
		r.svc.logger.Info("agent.session.reaped",
			zap.String("session_id", session.ID),
			zap.Time("last_heartbeat", *session.LastHeartbeatAt))
	}
	return closed, nil
}
