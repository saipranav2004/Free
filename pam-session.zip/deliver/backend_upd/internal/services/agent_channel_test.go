package services

import (
	"encoding/json"
	"testing"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
)

// A device that has psql but not pgAdmin, reported the way the agent reports.
const capsCLIOnly = `{"os":"linux","arch":"amd64","screen_recorder":true,` +
	`"types":[{"resource_type":"postgresql","kinds":["cli"],"tools":["psql"],` +
	`"missing":[{"id":"pgadmin4","kind":"gui","command":"pgAdmin 4","install_hint":"apt install pgadmin4"}]}]}`

// A device that has both.
const capsBoth = `{"os":"linux","arch":"amd64","screen_recorder":true,` +
	`"types":[{"resource_type":"postgresql","kinds":["cli","gui"],"tools":["psql","pgAdmin 4"],"missing":[]}]}`

func seedResourceAndDevice(t *testing.T, caps string, allowedChannels string) (*AgentService, string, string) {
	t.Helper()
	db := newLaunchTestDB(t)
	svc := NewAgentService(db, nil, nil, nil, zap.NewNop())

	resource := &models.PAMResource{
		ID: "res-pg", Name: "prod-pg", ResourceType: "postgresql",
		Host: "127.0.0.1", Port: 5432, AllowedChannels: allowedChannels,
	}
	if err := db.Create(resource).Error; err != nil {
		t.Fatalf("create resource: %v", err)
	}

	code, _, err := svc.InitPairing("u-1", pairingTTLForTest)
	if err != nil {
		t.Fatalf("InitPairing: %v", err)
	}
	if _, err := svc.CompletePairing(code, "laptop", freshDeviceKey(t), &DeviceReport{
		OS: "linux", Arch: "amd64", Hostname: "laptop", AgentVersion: "test",
		Capabilities: json.RawMessage(caps),
	}); err != nil {
		t.Fatalf("CompletePairing: %v", err)
	}
	return svc, "u-1", resource.ID
}

func channelByName(t *testing.T, rows []ChannelAvailability, name string) ChannelAvailability {
	t.Helper()
	for _, r := range rows {
		if r.Channel == name {
			return r
		}
	}
	t.Fatalf("no %q channel in %+v", name, rows)
	return ChannelAvailability{}
}

// The whole point of the model: "you may not" and "you have not installed it"
// are different facts with different remedies, and a single disabled control
// that cannot tell them apart is the worst outcome in the product.
func TestAllowedAndAvailableAreReportedSeparately(t *testing.T) {
	// Policy permits everything; the device only has the CLI.
	svc, uid, resourceID := seedResourceAndDevice(t, capsCLIOnly, "")

	rows, err := svc.ResourceChannels(uid, resourceID)
	if err != nil {
		t.Fatalf("ResourceChannels: %v", err)
	}

	cli := channelByName(t, rows, models.ChannelCLI)
	if !cli.Allowed || !cli.Available || cli.Reason != "ok" {
		t.Fatalf("cli should be allowed and available: %+v", cli)
	}

	desktop := channelByName(t, rows, models.ChannelDesktop)
	if !desktop.Allowed {
		t.Fatalf("desktop is permitted by policy but was reported as not allowed: %+v", desktop)
	}
	if desktop.Available {
		t.Fatalf("desktop has no tool on this device but was reported available: %+v", desktop)
	}
	if desktop.Reason != "tool_missing" {
		t.Fatalf("desktop reason %q, want tool_missing — the console cannot tell the operator what to do otherwise", desktop.Reason)
	}
	if desktop.Tool == "" {
		t.Fatal("a missing desktop tool must still name itself, or the control cannot say what to install")
	}

	// A browser is on every machine; it must not be gated on a capability
	// report that may not have arrived yet.
	web := channelByName(t, rows, models.ChannelWeb)
	if !web.Available || web.Reason != "ok" {
		t.Fatalf("web should always be available: %+v", web)
	}
}

// Policy off must read as policy off, NOT as a missing tool — even when the
// tool is genuinely present.
func TestAPolicyDenialIsNeverReportedAsAMissingTool(t *testing.T) {
	// The device has pgAdmin. Policy forbids desktop anyway.
	svc, uid, resourceID := seedResourceAndDevice(t, capsBoth, "cli")

	rows, err := svc.ResourceChannels(uid, resourceID)
	if err != nil {
		t.Fatalf("ResourceChannels: %v", err)
	}
	desktop := channelByName(t, rows, models.ChannelDesktop)
	if desktop.Allowed {
		t.Fatalf("policy said cli only, but desktop came back allowed: %+v", desktop)
	}
	if desktop.Reason != "not_allowed" {
		t.Fatalf("desktop reason %q, want not_allowed — the tool IS installed, so blaming the tool would send the operator to install something they already have", desktop.Reason)
	}
}

// Every supported channel must appear, including the ones that are off. A
// control that silently vanishes reads as a broken product; one that is
// present and explains itself reads as a decision.
func TestEverySupportedChannelIsReportedEvenWhenUnusable(t *testing.T) {
	svc, uid, resourceID := seedResourceAndDevice(t, capsCLIOnly, "cli")

	rows, err := svc.ResourceChannels(uid, resourceID)
	if err != nil {
		t.Fatalf("ResourceChannels: %v", err)
	}
	if len(rows) != len(models.SupportedChannels("postgresql")) {
		t.Fatalf("got %d channels, want all %d supported ones: %+v",
			len(rows), len(models.SupportedChannels("postgresql")), rows)
	}
}

// The admin view must be the FLEET, never the administrator's own laptop.
func TestFleetCoverageCountsDevicesNotTheAdminsOwnMachine(t *testing.T) {
	svc, _, resourceID := seedResourceAndDevice(t, capsCLIOnly, "")

	coverage, err := svc.FleetCoverage(resourceID)
	if err != nil {
		t.Fatalf("FleetCoverage: %v", err)
	}
	var cli, desktop FleetChannelCoverage
	for _, row := range coverage {
		switch row.Channel {
		case models.ChannelCLI:
			cli = row
		case models.ChannelDesktop:
			desktop = row
		}
	}
	if cli.Total != 1 || cli.Capable != 1 {
		t.Fatalf("cli coverage %d/%d, want 1/1", cli.Capable, cli.Total)
	}
	if desktop.Capable != 0 || desktop.Total != 1 {
		t.Fatalf("desktop coverage %d/%d, want 0/1 — one paired device, none with the tool",
			desktop.Capable, desktop.Total)
	}
}

// A device that has a ClickHouse client and NO PostgreSQL client. Read across
// all resource types this looks like "the CLI works"; read correctly it does
// not, and the tool to name is psql.
const capsWrongTypeOnly = `{"os":"linux","arch":"amd64","screen_recorder":true,` +
	`"types":[` +
	`{"resource_type":"clickhouse","kinds":["cli"],"tools":["clickhouse-client"],"missing":[]},` +
	`{"resource_type":"postgresql","kinds":[],"tools":[],` +
	`"missing":[{"id":"psql","kind":"cli","command":"psql","install_hint":"Install the PostgreSQL client tools."},` +
	`{"id":"pgadmin4","kind":"gui","command":"pgAdmin 4","install_hint":"Install pgAdmin 4."}]}` +
	`]}`

// Capability is per resource TYPE. Collapsing the report across types answers
// "can this device open anything at all", which is both the wrong verdict and
// the wrong tool name — found by driving the real API, where a PostgreSQL
// resource reported its terminal client as "clickhouse-client".
func TestCapabilityIsReadForTheRightResourceType(t *testing.T) {
	svc, uid, resourceID := seedResourceAndDevice(t, capsWrongTypeOnly, "")

	rows, err := svc.ResourceChannels(uid, resourceID) // the resource is postgresql
	if err != nil {
		t.Fatalf("ResourceChannels: %v", err)
	}

	cli := channelByName(t, rows, models.ChannelCLI)
	if cli.Available {
		t.Fatalf("a ClickHouse client was counted as a PostgreSQL terminal client: %+v", cli)
	}
	if cli.Tool == "clickhouse-client" {
		t.Fatalf("the console would tell the operator to blame clickhouse-client: %+v", cli)
	}
	if cli.Tool != "psql" {
		t.Fatalf("cli tool %q, want psql — the client this resource actually needs", cli.Tool)
	}
	if cli.InstallHint == "" {
		t.Fatal("no install hint, so a blocked control has no remedy to offer")
	}

	desktop := channelByName(t, rows, models.ChannelDesktop)
	if desktop.Tool != "pgAdmin 4" {
		t.Fatalf("desktop tool %q, want pgAdmin 4", desktop.Tool)
	}
}
