package services

import (
	"context"
	"fmt"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// Every insight query, run against a real Postgres.
//
// These queries are strings. The compiler cannot tell `occurred_at` from
// `timestamp`, and it cannot tell an audit action the code actually writes
// from one somebody wished into a chart — and both mistakes were in the first
// draft of this file's subject. The first is a 500; the second is worse,
// because a card fed by an action nothing emits draws a confident flat zero
// and reads as a quiet week.
//
// So the assertions here are on NUMBERS, not on err == nil. A query that runs
// and returns nothing is exactly the failure mode being guarded against.

func insightsDB(t *testing.T) *gorm.DB {
	t.Helper()
	dsn := os.Getenv("PAM_TEST_POSTGRES_DSN")
	if dsn == "" {
		t.Skip("set PAM_TEST_POSTGRES_DSN to run the insights tests")
	}

	// models.AuditLog qualifies its table with PAM_DATABASE_SCHEMA; unset,
	// that is a leading dot and the DDL is rejected. So the schema is named
	// before AutoMigrate, and the search_path points at the same name.
	schema := "insights_test"
	t.Setenv("PAM_DATABASE_SCHEMA", schema)

	bootstrap, err := gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("open postgres: %v", err)
	}
	if err := bootstrap.Exec(fmt.Sprintf(`DROP SCHEMA IF EXISTS %s CASCADE; CREATE SCHEMA %s;`, schema, schema)).Error; err != nil {
		t.Fatalf("create schema: %v", err)
	}
	if sqlDB, err := bootstrap.DB(); err == nil {
		_ = sqlDB.Close()
	}

	// search_path in the DSN, not a SET: SET binds to whichever pooled
	// connection served it, so the first query on a second connection looks
	// in public and reports the table missing.
	sep := " "
	if strings.HasPrefix(dsn, "postgres://") || strings.HasPrefix(dsn, "postgresql://") {
		sep = "?"
		if strings.Contains(dsn, "?") {
			sep = "&"
		}
		dsn += sep + "search_path=" + schema
	} else {
		dsn += " search_path=" + schema
	}

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("open postgres: %v", err)
	}
	t.Cleanup(func() {
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
		cleanup, err := gorm.Open(postgres.Open(os.Getenv("PAM_TEST_POSTGRES_DSN")),
			&gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
		if err != nil {
			return
		}
		cleanup.Exec(fmt.Sprintf(`DROP SCHEMA IF EXISTS %s CASCADE;`, schema))
		if sqlDB, err := cleanup.DB(); err == nil {
			_ = sqlDB.Close()
		}
	})
	if err := db.AutoMigrate(
		&models.ConnectionSession{}, &models.Safe{}, &models.Credential{},
		&models.AuditLog{}, &models.ServiceIdentity{}, &models.ServiceToken{},
		&models.ServiceGrant{},
	); err != nil {
		t.Fatalf("automigrate: %v", err)
	}
	return db
}

func ptrTime(t time.Time) *time.Time { return &t }

func TestSessionInsightsCountWhatIsOnScreen(t *testing.T) {
	db := insightsDB(t)
	svc := NewInsightsService(db)
	now := time.Now().UTC()
	rec := "rec-1"

	rows := []models.ConnectionSession{
		{ID: "s1", UserID: "u1", Username: "a", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "ACTIVE", StartedAt: now.Add(-1 * time.Hour)},
		{ID: "s2", UserID: "u1", Username: "a", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "ACTIVE", StartedAt: now.Add(-1 * time.Hour)},
		{ID: "s3", UserID: "u2", Username: "b", ResourceID: "r2", ResourceName: "rd", ResourceType: "redis", Status: "ACTIVE", StartedAt: now.Add(-4 * time.Hour), IsBreakglass: true},
		// Finished this week, one of them recorded.
		{ID: "s4", UserID: "u1", Username: "a", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "COMPLETED", StartedAt: now.Add(-2 * time.Hour), DurationSeconds: 30, RecordingID: &rec},
		{ID: "s5", UserID: "u2", Username: "b", ResourceID: "r2", ResourceName: "rd", ResourceType: "redis", Status: "COMPLETED", StartedAt: now.Add(-3 * time.Hour), DurationSeconds: 900},
		// Older than the seven-day window: must not move the weekly figures.
		{ID: "s6", UserID: "u1", Username: "a", ResourceID: "r1", ResourceName: "pg", ResourceType: "postgresql", Status: "COMPLETED", StartedAt: now.AddDate(0, 0, -20), DurationSeconds: 99999},
	}
	for i := range rows {
		if err := db.Create(&rows[i]).Error; err != nil {
			t.Fatalf("seed session %s: %v", rows[i].ID, err)
		}
	}

	got, err := svc.Sessions(context.Background(), "", false)
	if err != nil {
		t.Fatalf("Sessions: %v", err)
	}
	if got.ActiveNow != 3 {
		t.Errorf("ActiveNow = %d, want 3", got.ActiveNow)
	}
	if got.BreakglassActive != 1 {
		t.Errorf("BreakglassActive = %d, want 1", got.BreakglassActive)
	}
	// s3 started four hours ago and is still ACTIVE. Measured from started_at,
	// because duration_seconds is only stamped when a session ends — reading
	// that column would make "longest running" answer 0 forever.
	if got.LongestActiveSeconds < 4*3600 || got.LongestActiveSeconds > 4*3600+120 {
		t.Errorf("LongestActiveSeconds = %d, want about %d", got.LongestActiveSeconds, 4*3600)
	}
	byType := map[string]int64{}
	for _, c := range got.ByChannel {
		byType[c.Label] = c.Value
	}
	if byType["postgresql"] != 2 || byType["redis"] != 1 {
		t.Errorf("active by resource type = %v, want postgresql:2 redis:1", byType)
	}
	// Five sessions started inside the week (s1..s5); one carries a recording.
	if got.RecordedOf != 5 {
		t.Errorf("RecordedOf = %d, want 5 (the 20-day-old row must be outside the window)", got.RecordedOf)
	}
	if got.RecordedShare != 20 {
		t.Errorf("RecordedShare = %d%%, want 20%%", got.RecordedShare)
	}
	// Duration spread covers only finished sessions inside the window: s4 at
	// 30s and s5 at 900s.
	spread := map[string]int64{}
	for _, b := range got.DurationSpread {
		spread[b.Label] = b.Value
	}
	if spread["< 1m"] != 1 || spread["5-30m"] != 1 {
		t.Errorf("duration spread = %v, want one in '< 1m' and one in '5-30m'", spread)
	}
	if len(got.DurationSpread) != 5 {
		t.Errorf("duration spread has %d buckets, want all 5 present even when empty", len(got.DurationSpread))
	}
	// Ordinal, not alphabetical: '30m-2h' must not sort before '5-30m'.
	wantOrder := []string{"< 1m", "1-5m", "5-30m", "30m-2h", "2h+"}
	for i, b := range got.DurationSpread {
		if b.Label != wantOrder[i] {
			t.Fatalf("bucket %d is %q, want %q — buckets are ordinal", i, b.Label, wantOrder[i])
		}
	}

	// Scoped to one user, an operator sees only their own.
	mine, err := svc.Sessions(context.Background(), "u2", true)
	if err != nil {
		t.Fatalf("Sessions scoped: %v", err)
	}
	if mine.ActiveNow != 1 {
		t.Errorf("scoped ActiveNow = %d, want 1", mine.ActiveNow)
	}
}

func TestVaultInsightsReadRevealsFromActionsTheVaultActuallyWrites(t *testing.T) {
	db := insightsDB(t)
	svc := NewInsightsService(db)
	now := time.Now().UTC()

	db.Create(&models.Safe{ID: "safe-prod", Name: "production", OwnerID: "u1"})
	creds := []models.Credential{
		{ID: "c1", SafeID: "safe-prod", Name: "db", AccountName: "app", CredentialType: "password", CredentialEnc: "x", Status: "active", NextRotationAt: ptrTime(now.Add(-24 * time.Hour))},
		{ID: "c2", SafeID: "safe-prod", Name: "api", AccountName: "app", CredentialType: "password", CredentialEnc: "x", Status: "active", NextRotationAt: ptrTime(now.Add(24 * time.Hour))},
		{ID: "c3", SafeID: "safe-missing", Name: "loose", AccountName: "app", CredentialType: "password", CredentialEnc: "x", Status: "active", IsBreakglass: true},
		{ID: "c4", SafeID: "safe-prod", Name: "retired", AccountName: "app", CredentialType: "password", CredentialEnc: "x", Status: "disabled"},
	}
	for i := range creds {
		if err := db.Create(&creds[i]).Error; err != nil {
			t.Fatalf("seed credential: %v", err)
		}
	}

	// Reveals, written under the action names the vault path really uses. A
	// near-miss name is seeded alongside to prove the filter is doing work.
	seedAudit := func(action string, when time.Time, outcome models.AuditOutcome) {
		row := models.AuditLog{ID: "", Action: action, OccurredAt: when, UserID: "u1", Username: "alice", Outcome: outcome, PrevHash: "0", EntryHash: "0"}
		if err := db.Create(&row).Error; err != nil {
			t.Fatalf("seed audit %s: %v", action, err)
		}
	}
	seedAudit("pam.secret.read", now.Add(-2*time.Hour), models.OutcomeSuccess)
	seedAudit("pam.secret.read", now.Add(-3*time.Hour), models.OutcomeSuccess)
	seedAudit("pam.secret.batch_read", now.AddDate(0, 0, -2), models.OutcomeSuccess)
	seedAudit("pam.vault.reveal", now.Add(-1*time.Hour), models.OutcomeSuccess) // not a real action
	seedAudit("pam.service_token.issued", now.Add(-1*time.Hour), models.OutcomeSuccess)

	got, err := svc.Vault(context.Background())
	if err != nil {
		t.Fatalf("Vault: %v", err)
	}
	if got.TotalSecrets != 3 {
		t.Errorf("TotalSecrets = %d, want 3 active", got.TotalSecrets)
	}
	bySafe := map[string]int64{}
	for _, c := range got.BySafe {
		bySafe[c.Label] = c.Value
	}
	if bySafe["production"] != 2 {
		t.Errorf("BySafe[production] = %d, want 2", bySafe["production"])
	}
	if bySafe["unfiled"] != 1 {
		t.Errorf("BySafe[unfiled] = %d, want 1 — a credential whose safe is gone still has to appear somewhere", bySafe["unfiled"])
	}
	if got.RotationOverdue != 1 {
		t.Errorf("RotationOverdue = %d, want 1", got.RotationOverdue)
	}
	if got.BreakglassCount != 1 {
		t.Errorf("BreakglassCount = %d, want 1", got.BreakglassCount)
	}

	var revealTotal int64
	for _, b := range got.RevealsByDay {
		revealTotal += b.Value
	}
	if revealTotal != 3 {
		t.Fatalf("reveals over 30 days = %d, want 3 — the chart must count pam.secret.read/batch_read and nothing else", revealTotal)
	}
	if len(got.RevealsByDay) != 30 {
		t.Errorf("RevealsByDay has %d points, want 30 — empty days are filled so the line stays a timeline", len(got.RevealsByDay))
	}
	// The last point is today, whatever today is.
	last := got.RevealsByDay[len(got.RevealsByDay)-1]
	if last.Label != now.Format("2006-01-02") {
		t.Errorf("last bucket is %q, want today (%s)", last.Label, now.Format("2006-01-02"))
	}
	// Each read is asserted into the day it actually falls in, computed from
	// the same timestamp that seeded it. Hard-coding "two landed today" made
	// the test pass in the afternoon and fail after midnight UTC, because
	// now-3h crosses into yesterday.
	wantPerDay := map[string]int64{}
	for _, when := range []time.Time{now.Add(-2 * time.Hour), now.Add(-3 * time.Hour), now.AddDate(0, 0, -2)} {
		wantPerDay[when.Format("2006-01-02")]++
	}
	gotPerDay := map[string]int64{}
	for _, b := range got.RevealsByDay {
		if b.Value > 0 {
			gotPerDay[b.Label] = b.Value
		}
	}
	for day, n := range wantPerDay {
		if gotPerDay[day] != n {
			t.Errorf("reveals on %s = %d, want %d (got %v)", day, gotPerDay[day], n, gotPerDay)
		}
	}
}

func TestServiceInsightsClassifyScopeInGo(t *testing.T) {
	db := insightsDB(t)
	svc := NewInsightsService(db)
	now := time.Now().UTC()

	db.Create(&models.ServiceIdentity{ID: "svc-1", Name: "billing", Status: "active"})
	db.Create(&models.ServiceIdentity{ID: "svc-2", Name: "retired", Status: "disabled"})
	// Active but not usable: a token and no grant authenticates and then reads
	// nothing. This is the gap a list showing every identity as "active" hides.
	db.Create(&models.ServiceIdentity{ID: "svc-3", Name: "halfway", Status: "active"})
	// Active, granted, but no token at all — cannot authenticate.
	db.Create(&models.ServiceIdentity{ID: "svc-4", Name: "tokenless", Status: "active"})
	db.Create(&models.ServiceGrant{ID: "g7", ServiceID: "svc-4", ServiceName: "tokenless", Scope: "prod/x"})

	grants := []models.ServiceGrant{
		{ID: "g1", ServiceID: "svc-1", ServiceName: "billing", Scope: "prod/db/main"},
		{ID: "g2", ServiceID: "svc-1", ServiceName: "billing", Scope: "prod/db/*"},
		{ID: "g3", ServiceID: "svc-1", ServiceName: "billing", Scope: "prod/**"},
		{ID: "g4", ServiceID: "svc-1", ServiceName: "billing", Scope: "**"},
		{ID: "g5", ServiceID: "svc-1", ServiceName: "billing", Scope: "gone", RevokedAt: ptrTime(now.Add(-time.Hour))},
		{ID: "g6", ServiceID: "svc-1", ServiceName: "billing", Scope: "lapsed", ExpiresAt: ptrTime(now.Add(-time.Hour))},
	}
	for i := range grants {
		if err := db.Create(&grants[i]).Error; err != nil {
			t.Fatalf("seed grant: %v", err)
		}
	}

	toks := []models.ServiceToken{
		{TokenID: "t1", ServiceID: "svc-1", ServiceName: "billing", TokenHash: "h"},
		{TokenID: "t2", ServiceID: "svc-1", ServiceName: "billing", TokenHash: "h", ExpiresAt: ptrTime(now.Add(-time.Hour))},
		{TokenID: "t3", ServiceID: "svc-1", ServiceName: "billing", TokenHash: "h", ExpiresAt: ptrTime(now.Add(72 * time.Hour))},
		{TokenID: "t4", ServiceID: "svc-1", ServiceName: "billing", TokenHash: "h", ExpiresAt: ptrTime(now.AddDate(0, 0, 200))},
		{TokenID: "t5", ServiceID: "svc-1", ServiceName: "billing", TokenHash: "h", RevokedAt: ptrTime(now)},
		{TokenID: "t6", ServiceID: "svc-3", ServiceName: "halfway", TokenHash: "h"},
	}
	for i := range toks {
		if err := db.Create(&toks[i]).Error; err != nil {
			t.Fatalf("seed token: %v", err)
		}
	}

	got, err := svc.Services(context.Background())
	if err != nil {
		t.Fatalf("Services: %v", err)
	}
	if got.Identities != 3 {
		t.Errorf("Identities = %d, want 3 active", got.Identities)
	}
	// Reported separately so the card can say which population it counted:
	// the table beneath it lists disabled identities too, and "2 / 3" over a
	// list headed "4" reads as the two disagreeing.
	if got.Disabled != 1 {
		t.Errorf("Disabled = %d, want 1 (svc-2)", got.Disabled)
	}
	// Only svc-1 has BOTH a live token and a live grant. svc-3 has a token and
	// no grant, svc-4 a grant and no token; neither can do anything.
	if got.ReadyCount != 1 {
		t.Errorf("ReadyCount = %d, want 1 — an identity needs a live token AND a live grant", got.ReadyCount)
	}
	breadth := map[string]int64{}
	for _, c := range got.ScopeBreadth {
		breadth[c.Label] = c.Value
	}
	want := map[string]int64{
		// g1 "prod/db/main" and g7 "prod/x" are both exact paths.
		models.ScopeBreadthExact:    2,
		models.ScopeBreadthWildcard: 1,
		models.ScopeBreadthSubtree:  1,
		models.ScopeBreadthAll:      1,
	}
	for label, n := range want {
		if breadth[label] != n {
			t.Errorf("scope breadth %q = %d, want %d (got %v)", label, breadth[label], n, breadth)
		}
	}
	if got.VaultWide != 1 {
		t.Errorf("VaultWide = %d, want 1", got.VaultWide)
	}
	runway := map[string]int64{}
	for _, b := range got.TokensExpiring {
		runway[b.Label] = b.Value
	}
	if runway["never"] != 2 || runway["expired"] != 1 || runway["< 7d"] != 1 || runway["30d+"] != 1 {
		t.Errorf("token runway = %v, want never:2 expired:1 < 7d:1 30d+:1 and the revoked one excluded", runway)
	}
	var total int64
	for _, b := range got.TokensExpiring {
		total += b.Value
	}
	// Five live tokens seeded (t1, t2, t3, t4, t6); t5 is revoked.
	if total != 5 {
		t.Errorf("token runway total = %d, want 5 — the revoked token must not be counted", total)
	}
}

func TestAuditInsightsBucketByOccurredAt(t *testing.T) {
	db := insightsDB(t)
	svc := NewInsightsService(db)
	now := time.Now().UTC()

	seed := func(action, user string, when time.Time, outcome models.AuditOutcome) {
		row := models.AuditLog{Action: action, UserID: user, Username: user, OccurredAt: when, Outcome: outcome, PrevHash: "0", EntryHash: "0"}
		if err := db.Create(&row).Error; err != nil {
			t.Fatalf("seed audit: %v", err)
		}
	}
	seed("pam.secret.read", "alice", now.Add(-time.Hour), models.OutcomeSuccess)
	seed("pam.secret.read", "alice", now.Add(-2*time.Hour), models.OutcomeSuccess)
	seed("pam.secret.read", "alice", now.Add(-3*time.Hour), models.OutcomeDenied)
	seed("pam.secret.read", "bob", now.AddDate(0, 0, -3), models.OutcomeSuccess)
	// Outside the window entirely.
	seed("pam.secret.read", "carol", now.AddDate(0, 0, -40), models.OutcomeSuccess)

	got, err := svc.Audit(context.Background(), 7, "")
	if err != nil {
		t.Fatalf("Audit: %v", err)
	}
	if got.TotalEvents != 4 {
		t.Errorf("TotalEvents = %d, want 4 over 7 days", got.TotalEvents)
	}
	if got.DeniedRate != 25 {
		t.Errorf("DeniedRate = %d%%, want 25%%", got.DeniedRate)
	}
	if len(got.EventsByDay) != 7 {
		t.Fatalf("EventsByDay has %d points, want 7", len(got.EventsByDay))
	}
	// Bucketed by the day each event actually falls in, not by "today": three
	// events at now-1h, now-2h and now-3h straddle midnight UTC depending on
	// when the suite runs, and a test that only passes in the afternoon is
	// worse than no test.
	wantPerDay := map[string]int64{}
	for _, when := range []time.Time{now.Add(-time.Hour), now.Add(-2 * time.Hour), now.Add(-3 * time.Hour), now.AddDate(0, 0, -3)} {
		wantPerDay[when.Format("2006-01-02")]++
	}
	gotPerDay := map[string]int64{}
	for _, b := range got.EventsByDay {
		if b.Value > 0 {
			gotPerDay[b.Label] = b.Value
		}
	}
	for day, n := range wantPerDay {
		if gotPerDay[day] != n {
			t.Errorf("events on %s = %d, want %d (got %v)", day, gotPerDay[day], n, gotPerDay)
		}
	}
	if len(got.TopActors) == 0 || got.TopActors[0].Label != "alice" || got.TopActors[0].Value != 3 {
		t.Errorf("TopActors = %+v, want alice first with 3", got.TopActors)
	}
	for _, a := range got.TopActors {
		if a.Label == "carol" {
			t.Errorf("carol is 40 days old and must be outside the 7-day window")
		}
	}

	// Scoped to a non-admin, the aggregate must not answer "who else is busy".
	// A count is still a disclosure, and this is the easier place to leak one
	// than the table, because no row is ever rendered.
	mine, err := svc.Audit(context.Background(), 7, "bob")
	if err != nil {
		t.Fatalf("Audit scoped: %v", err)
	}
	if mine.TotalEvents != 1 {
		t.Errorf("scoped TotalEvents = %d, want 1 — bob has one event in the window", mine.TotalEvents)
	}
	for _, a := range mine.TopActors {
		if a.Label != "bob" {
			t.Errorf("scoped TopActors leaked %q; a non-admin sees only themselves", a.Label)
		}
	}
	var scopedTotal int64
	for _, b := range mine.EventsByDay {
		scopedTotal += b.Value
	}
	if scopedTotal != 1 {
		t.Errorf("scoped series totals %d, want 1 — the chart is scoped too, not just the counts", scopedTotal)
	}
}

// An empty database must produce zeroes and full-length series, not an error
// and not a short chart. A brand-new install opens on these cards.
func TestInsightsOnAnEmptyDatabase(t *testing.T) {
	db := insightsDB(t)
	svc := NewInsightsService(db)
	ctx := context.Background()

	s, err := svc.Sessions(ctx, "", false)
	if err != nil {
		t.Fatalf("Sessions: %v", err)
	}
	// MIN(started_at) over no rows is NULL. Scanned into a *time.Time that is
	// a nil pointer, not an error — and dereferencing it would panic.
	if s.LongestActiveSeconds != 0 || s.BreakglassActive != 0 {
		t.Errorf("empty Sessions longest/breakglass = %d/%d, want 0/0", s.LongestActiveSeconds, s.BreakglassActive)
	}
	if s.ActiveNow != 0 || s.RecordedShare != 0 || len(s.DurationSpread) != 5 {
		t.Errorf("empty Sessions = %+v, want zeroes with all 5 buckets", s)
	}
	v, err := svc.Vault(ctx)
	if err != nil {
		t.Fatalf("Vault: %v", err)
	}
	if v.TotalSecrets != 0 || len(v.RevealsByDay) != 30 {
		t.Errorf("empty Vault = %+v, want zeroes with a full 30-day series", v)
	}
	sv, err := svc.Services(ctx)
	if err != nil {
		t.Fatalf("Services: %v", err)
	}
	if sv.Identities != 0 || sv.ReadyCount != 0 || sv.Disabled != 0 ||
		len(sv.ScopeBreadth) != 4 || len(sv.TokensExpiring) != 5 {
		t.Errorf("empty Services = %+v, want zeroes with every band present", sv)
	}
	a, err := svc.Audit(ctx, 30, "")
	if err != nil {
		t.Fatalf("Audit: %v", err)
	}
	if a.TotalEvents != 0 || a.DeniedRate != 0 || len(a.EventsByDay) != 30 {
		t.Errorf("empty Audit = %+v, want zeroes with a full 30-day series", a)
	}

	// Non-nil, so the JSON is [] and not null: a chart handed null throws,
	// where "nothing is running" is a perfectly sayable answer.
	if s.ByChannel == nil {
		t.Error("empty Sessions.ByChannel is nil; must serialise as [] not null")
	}
	if v.BySafe == nil {
		t.Error("empty Vault.BySafe is nil; must serialise as [] not null")
	}
	if a.TopActors == nil {
		t.Error("empty Audit.TopActors is nil; must serialise as [] not null")
	}
}
