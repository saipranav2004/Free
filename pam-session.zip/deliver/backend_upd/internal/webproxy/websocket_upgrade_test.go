package webproxy

import (
	"bufio"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
)

// The WebSocket handshake, end to end, through the real proxy.
//
// origin_rewrite_test.go asserts what the Director puts in the headers. That
// is necessary and not sufficient: it proves the headers are right and proves
// nothing about whether an upgrade actually completes, which is what the
// reported bug was. A header assertion would still pass if the proxy dropped
// Connection/Upgrade, refused to hijack, or never returned the 101.
//
// So this stands up an upstream that applies gorilla/websocket's DEFAULT
// CheckOrigin rule verbatim — the rule MinIO's Console, Metabase, Langfuse and
// most Go admin UIs use unchanged — and dials it through the proxy, asserting
// the browser receives 101 Switching Protocols.

// equalASCIIFold and checkSameOrigin are gorilla/websocket's own default
// origin check, copied rather than imported so the test states the rule it is
// pinning instead of depending on a library staying the same.
//
//	func checkSameOrigin(r *http.Request) bool {
//	    origin := r.Header["Origin"]
//	    if len(origin) == 0 { return true }
//	    u, err := url.Parse(origin[0])
//	    if err != nil { return false }
//	    return equalASCIIFold(u.Host, r.Host)
//	}
func checkSameOrigin(r *http.Request) bool {
	origin := r.Header.Get("Origin")
	if origin == "" {
		// No Origin at all is allowed: that is a non-browser client, and the
		// check exists to stop browsers being used as confused deputies.
		return true
	}
	u, err := url.Parse(origin)
	if err != nil {
		return false
	}
	return strings.EqualFold(u.Host, r.Host)
}

// gorillaStyleUpstream answers a WebSocket upgrade exactly as a gorilla
// server does: 403 when the origin check fails, 101 when it passes.
func gorillaStyleUpstream(t *testing.T, refused *bool) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") {
			w.WriteHeader(http.StatusOK)
			return
		}
		if !checkSameOrigin(r) {
			*refused = true
			// The exact body MinIO returned in the field.
			w.WriteHeader(http.StatusForbidden)
			_, _ = w.Write([]byte(`{"code":500,"message":"websocket: request origin not allowed by Upgrader.CheckOrigin"}`))
			return
		}
		hj, ok := w.(http.Hijacker)
		if !ok {
			t.Errorf("upstream ResponseWriter cannot hijack; cannot complete a handshake")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		conn, buf, err := hj.Hijack()
		if err != nil {
			t.Errorf("upstream hijack: %v", err)
			return
		}
		defer conn.Close()
		_, _ = buf.WriteString("HTTP/1.1 101 Switching Protocols\r\n" +
			"Upgrade: websocket\r\nConnection: Upgrade\r\n" +
			"Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=\r\n\r\n")
		_ = buf.Flush()
	}))
}

func TestWebSocketUpgradeSurvivesTheProxy(t *testing.T) {
	var refused bool
	upstream := gorillaStyleUpstream(t, &refused)
	defer upstream.Close()
	targetURL, _ := url.Parse(upstream.URL)

	h := NewHandler(testService(defaultTestConfig()), zap.NewNop())
	proxy := h.buildReverseProxy(&ResolvedSession{
		Session:  &models.WebProxySession{ID: "wps-1", Subdomain: "app-abc12345"},
		Upstream: &UpstreamState{Cookies: map[string]string{}},
		Target:   targetURL,
	})

	// A real server, because an upgrade needs a hijackable connection and a
	// httptest.ResponseRecorder is not one. This is the hop the header-level
	// test cannot exercise.
	front := httptest.NewServer(proxy)
	defer front.Close()

	frontURL, _ := url.Parse(front.URL)
	conn, err := net.DialTimeout("tcp", frontURL.Host, 5*time.Second)
	if err != nil {
		t.Fatalf("dial the proxy: %v", err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(5 * time.Second))

	// Exactly what a browser sends, including the browser-facing Origin that
	// caused the field failure.
	_, err = conn.Write([]byte(
		"GET /ws/objectManager HTTP/1.1\r\n" +
			"Host: app-abc12345.pam.example.com\r\n" +
			"Origin: https://app-abc12345.pam.example.com\r\n" +
			"Connection: Upgrade\r\nUpgrade: websocket\r\n" +
			"Sec-WebSocket-Version: 13\r\n" +
			"Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n\r\n"))
	if err != nil {
		t.Fatalf("write the handshake: %v", err)
	}

	resp, err := http.ReadResponse(bufio.NewReader(conn), nil)
	if err != nil {
		t.Fatalf("read the handshake response: %v", err)
	}
	defer resp.Body.Close()

	if refused {
		t.Fatal("the upstream refused the origin — this is the bucket-view spinner: " +
			"the page renders, /ws/objectManager is answered 403, and the console retries forever")
	}
	if resp.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("handshake = %d %s, want 101 Switching Protocols", resp.StatusCode, resp.Status)
	}
	if !strings.EqualFold(resp.Header.Get("Upgrade"), "websocket") {
		t.Errorf("Upgrade header on the 101 = %q, want websocket", resp.Header.Get("Upgrade"))
	}
}

// The negative control. Without this the test above could pass for the wrong
// reason — a stub that accepts everything proves nothing about a rule.
func TestTheOriginCheckIsRealAndWouldHaveCaughtTheBug(t *testing.T) {
	var refused bool
	upstream := gorillaStyleUpstream(t, &refused)
	defer upstream.Close()

	// The pre-fix situation, reproduced directly against the upstream: the
	// browser's Origin with the target's Host.
	req, _ := http.NewRequest(http.MethodGet, upstream.URL+"/ws/objectManager", nil)
	req.Header.Set("Connection", "Upgrade")
	req.Header.Set("Upgrade", "websocket")
	req.Header.Set("Origin", "https://app-abc12345.pam.example.com")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	if !refused || resp.StatusCode != http.StatusForbidden {
		t.Fatalf("the stub upstream accepted a mismatched origin (%d) — it is not applying "+
			"gorilla's rule, so the passing test above proves nothing", resp.StatusCode)
	}
}
