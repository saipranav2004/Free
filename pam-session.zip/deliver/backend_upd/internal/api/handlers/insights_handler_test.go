package handlers

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// The insight endpoints hand back aggregates, and an aggregate is still a
// disclosure: "who are the busiest actors in the organisation" is a question a
// non-admin must not get an answer to, and it is EASIER to leak here than in
// the table underneath, because no row is ever rendered and nothing looks
// wrong on screen.
//
// So what is tested here is the branch that decides the scope, driven through
// the real gin handler with the same context keys PAMAuth sets.

func insightsCtx(roles []string, userID string) (*gin.Context, *httptest.ResponseRecorder) {
	gin.SetMode(gin.TestMode)
	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet, "/api/v1/pam/insights/audit?days=14", nil)
	c.Set("user_id", userID)
	c.Set("roles", roles)
	return c, rec
}

func TestInsightScopeFollowsTheCallersRole(t *testing.T) {
	cases := []struct {
		name             string
		roles            []string
		wantUnrestricted bool
	}{
		{"root sees the fleet", []string{"root"}, true},
		{"admin sees the fleet", []string{"admin"}, true},
		{"an operator sees only themselves", []string{"operator"}, false},
		{"no roles at all sees only themselves", nil, false},
		// A role that merely CONTAINS the word is not the role. This is the
		// mistake a substring check would make.
		{"a lookalike role is not admin", []string{"administrator-readonly"}, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			c, _ := insightsCtx(tc.roles, "user-1")
			uid, unrestricted := callerScope(c)
			if unrestricted != tc.wantUnrestricted {
				t.Fatalf("unrestricted = %v, want %v for roles %v", unrestricted, tc.wantUnrestricted, tc.roles)
			}
			if uid != "user-1" {
				t.Errorf("caller id = %q, want user-1 — read from the token, never the request", uid)
			}
		})
	}
}

func TestAuditWindowIsClamped(t *testing.T) {
	cases := []struct {
		query string
		want  int
	}{
		{"", 30},
		{"?days=7", 7},
		{"?days=90", 90},
		// Clamped, not rejected: this feeds a chart above a table, and a bad
		// query string should degrade to a sensible chart rather than a red
		// error box. The ceiling is what stops days=100000 from turning a
		// decorative header into a full-table scan.
		{"?days=100000", 90},
		{"?days=0", 30},
		{"?days=-5", 30},
		{"?days=banana", 30},
	}
	for _, tc := range cases {
		gin.SetMode(gin.TestMode)
		rec := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(rec)
		c.Request = httptest.NewRequest(http.MethodGet, "/api/v1/pam/insights/audit"+tc.query, nil)
		if got := auditWindowDays(c); got != tc.want {
			t.Errorf("auditWindowDays(%q) = %d, want %d", tc.query, got, tc.want)
		}
	}
}

// The failure path must not leak the database error to the caller. An insight
// card is decoration on someone else's page; a driver error in it should read
// as "could not load", not as a schema disclosure.
func TestInsightsFailureIsOpaque(t *testing.T) {
	gin.SetMode(gin.TestMode)
	rec := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(rec)
	c.Request = httptest.NewRequest(http.MethodGet, "/api/v1/pam/insights/sessions", nil)
	c.Set("user_id", "u1")
	c.Set("roles", []string{"operator"})

	// A real connection pointed at an empty schema: the query runs and comes
	// back "relation does not exist". A nil *gorm.DB would panic instead of
	// erroring, which tests the recovery middleware rather than this handler.
	dsn := os.Getenv("PAM_TEST_POSTGRES_DSN")
	if dsn == "" {
		t.Skip("set PAM_TEST_POSTGRES_DSN to run the insights failure-path test")
	}
	db, err := gorm.Open(postgres.Open(withSearchPath(dsn, "insights_nothing_here")),
		&gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		t.Fatalf("open postgres: %v", err)
	}
	t.Cleanup(func() {
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
	})

	h := NewInsightsHandler(services.NewInsightsService(db), zap.NewNop())
	h.Sessions(c)

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d, want 500", rec.Code)
	}
	var body map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("response is not JSON: %v", err)
	}
	// The envelope is {success:false, error:{message:...}} — error is an
	// object, not a string.
	errObj, _ := body["error"].(map[string]any)
	msg, _ := errObj["message"].(string)
	if msg != "Failed to load session insights" {
		t.Errorf("error message = %q, want the fixed opaque message", msg)
	}
	// Nothing about the schema reaches the caller.
	for _, leak := range []string{"relation", "SQLSTATE", "pam_connection_sessions", "SELECT"} {
		if strings.Contains(rec.Body.String(), leak) {
			t.Errorf("response leaks %q: %s", leak, rec.Body.String())
		}
	}
}
