// pam/internal/models/channel.go
//
// A CHANNEL is how an operator reaches a resource: a terminal client, a
// desktop application, or a browser. It is the single most user-visible
// decision in the product, and it has exactly two independent inputs that
// must never be collapsed into one another:
//
//	ALLOWED   — policy. Set by an administrator, applies to everyone, stored
//	            on the resource. "This production database may only be
//	            reached by a recorded CLI."
//	AVAILABLE — capability. Measured on one operator's paired device.
//	            "SQL Developer is not installed on this laptop."
//
// Conflating them produces the worst error message in a privileged-access
// product: a greyed-out button that cannot say whether the operator is not
// permitted, or merely missing a tool. One of those is a policy conversation
// and the other is a ten-second install, and the operator cannot tell which.
package models

import (
	"sort"
	"strings"
)

// The channel vocabulary. These strings cross the wire to the agent and the
// console, and are stored on the resource, so they are API surface.
const (
	ChannelCLI     = "cli"     // a terminal client, relayed through a pty and recordable as asciicast
	ChannelDesktop = "desktop" // a native GUI application, recordable only as screen capture
	ChannelWeb     = "web"     // a browser, brokered through the web proxy and recordable as rrweb
)

// AllChannels is the canonical order channels are offered in: terminal first,
// because it is the one that records most faithfully and costs least.
var AllChannels = []string{ChannelCLI, ChannelDesktop, ChannelWeb}

// IsChannel reports whether s is a channel this product understands.
func IsChannel(s string) bool {
	switch s {
	case ChannelCLI, ChannelDesktop, ChannelWeb:
		return true
	}
	return false
}

// AgentKindToChannel maps the agent's launch-template `kind` onto a channel.
// The agent's vocabulary predates this one and says "gui" and "browser";
// translating in one place stops the two drifting.
func AgentKindToChannel(kind string) string {
	switch strings.ToLower(strings.TrimSpace(kind)) {
	case "cli":
		return ChannelCLI
	case "gui":
		return ChannelDesktop
	case "browser":
		return ChannelWeb
	}
	return ""
}

// ParseChannels turns the stored comma-separated column into a clean,
// de-duplicated, canonically-ordered list. Unknown entries are dropped rather
// than surfaced: a typo in the column must never widen access, and must never
// render a button the product cannot honour.
func ParseChannels(raw string) []string {
	seen := map[string]bool{}
	for _, part := range strings.Split(raw, ",") {
		c := strings.ToLower(strings.TrimSpace(part))
		if IsChannel(c) {
			seen[c] = true
		}
	}
	out := make([]string, 0, len(seen))
	for _, c := range AllChannels {
		if seen[c] {
			out = append(out, c)
		}
	}
	return out
}

// JoinChannels is ParseChannels' inverse, for storage.
func JoinChannels(channels []string) string {
	clean := ParseChannels(strings.Join(channels, ","))
	return strings.Join(clean, ",")
}

// AllowedChannelsOrDefault resolves the policy axis for a resource.
//
// An EMPTY column means "no restriction stated", not "nothing allowed" —
// every resource that predates this feature has an empty column, and reading
// that as a deny would lock every operator out of every resource on upgrade.
// So empty widens to "whatever this resource type can actually do", which is
// the behaviour before the policy existed.
func AllowedChannelsOrDefault(raw string, supported []string) []string {
	allowed := ParseChannels(raw)
	if len(allowed) == 0 {
		return append([]string(nil), supported...)
	}
	// Policy can only ever NARROW what the resource type supports. Allowing a
	// channel the type has no client for would render a button that cannot
	// work, and an administrator editing policy should not be able to invent
	// capability.
	support := map[string]bool{}
	for _, s := range supported {
		support[s] = true
	}
	out := make([]string, 0, len(allowed))
	for _, c := range allowed {
		if support[c] {
			out = append(out, c)
		}
	}
	return out
}

// ChannelAllowed is the single question the launch path asks of policy.
func ChannelAllowed(raw string, supported []string, channel string) bool {
	for _, c := range AllowedChannelsOrDefault(raw, supported) {
		if c == channel {
			return true
		}
	}
	return false
}

// SortChannels puts a list into the canonical order for display.
func SortChannels(in []string) []string {
	rank := map[string]int{}
	for i, c := range AllChannels {
		rank[c] = i
	}
	out := append([]string(nil), in...)
	sort.SliceStable(out, func(a, b int) bool { return rank[out[a]] < rank[out[b]] })
	return out
}

// ── What each resource type can actually be reached by ──────────────────────
//
// This is the CAPABILITY ceiling, independent of any one laptop and of any
// policy: it says which channels a real client exists for at all. Policy can
// only narrow it (see AllowedChannelsOrDefault), and a device can only fail to
// meet it.
//
// Verified against each vendor's current distribution, September 2026. The
// entries that are absent are as deliberate as the ones that are present:
//
//	clickhouse — no official desktop client exists. The official clients are
//	             clickhouse-client and, on any self-hosted server, the built-in
//	             /play query UI. Third-party desktop tools (DBeaver, Beekeeper)
//	             exist but are not something this product should require.
//	minio      — mc and the Console embedded in the server. No desktop app.
//	qdrant     — the dashboard shipped inside the server. No CLI, no desktop.
//	metabase   — is itself a web application.
//	mongodb    — Compass and mongosh; the web UI is Atlas-only, so not ours.
//
// Keep this in step with the agent's launch-templates.default.json. The agent
// reports the channels it holds templates for in its capability report, so
// drift shows up as a device that cannot do something this table promises.
var resourceTypeChannels = map[string][]string{
	"postgresql": {ChannelCLI, ChannelDesktop, ChannelWeb},
	"redis":      {ChannelCLI, ChannelDesktop, ChannelWeb},
	"mongodb":    {ChannelCLI, ChannelDesktop},
	"oracle":     {ChannelCLI, ChannelDesktop, ChannelWeb},
	"clickhouse": {ChannelCLI, ChannelWeb},
	"minio":      {ChannelCLI, ChannelWeb},
	"qdrant":     {ChannelWeb},
	"metabase":   {ChannelWeb},
	"langfuse":   {ChannelCLI, ChannelWeb},
	"web":        {ChannelWeb},
}

// SupportedChannels returns the channels a resource type can be reached by.
//
// An unknown type falls back to web only. That is the safe direction: a
// browser is the one client that always exists, and promising a terminal for a
// type we have no template for would render a button that cannot work.
func SupportedChannels(resourceType string) []string {
	if c, ok := resourceTypeChannels[strings.ToLower(strings.TrimSpace(resourceType))]; ok {
		return append([]string(nil), c...)
	}
	return []string{ChannelWeb}
}

// KnownResourceTypes lists the types this table covers, for tests and for the
// admin policy editor.
func KnownResourceTypes() []string {
	out := make([]string, 0, len(resourceTypeChannels))
	for k := range resourceTypeChannels {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
