package models

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// Policy may only ever narrow what a resource type can do. An administrator
// editing the allowed list must not be able to invent a channel there is no
// client for — that renders a button which cannot work, and the operator who
// clicks it gets a failure with no explanation.
func TestPolicyCanNarrowChannelsButNeverWidenThem(t *testing.T) {
	supported := SupportedChannels("clickhouse") // cli + web, no desktop

	// Narrowing works.
	if got := AllowedChannelsOrDefault("cli", supported); len(got) != 1 || got[0] != ChannelCLI {
		t.Fatalf("narrowing to cli gave %v", got)
	}
	// Widening is silently dropped rather than honoured.
	if ChannelAllowed("cli,desktop", supported, ChannelDesktop) {
		t.Fatal("policy invented a desktop channel for a type that has no desktop client")
	}
	// Garbage in the column does not widen anything either.
	if ChannelAllowed("cli,desktop,nonsense,,CLI", supported, ChannelDesktop) {
		t.Fatal("a malformed allowed-channels column widened access")
	}
	if !ChannelAllowed("CLI , cli", supported, ChannelCLI) {
		t.Fatal("case and whitespace broke a legitimate allow")
	}
}

// Every resource that predates this feature has an empty column. Reading that
// as "nothing allowed" would lock every operator out of every resource the
// moment this shipped.
func TestAnEmptyPolicyMeansUnrestrictedNotDenied(t *testing.T) {
	for _, rt := range KnownResourceTypes() {
		supported := SupportedChannels(rt)
		allowed := AllowedChannelsOrDefault("", supported)
		if len(allowed) != len(supported) {
			t.Fatalf("%s: empty policy gave %v, want all of %v", rt, allowed, supported)
		}
		for _, c := range supported {
			if !ChannelAllowed("", supported, c) {
				t.Fatalf("%s: empty policy denied %s", rt, c)
			}
		}
	}
}

// An unknown type must not promise a terminal we have no client for.
func TestAnUnknownResourceTypeFallsBackToWebOnly(t *testing.T) {
	got := SupportedChannels("something-we-have-never-shipped")
	if len(got) != 1 || got[0] != ChannelWeb {
		t.Fatalf("unknown type offered %v, want web only", got)
	}
}

// The server's table and the agent's launch templates describe the same
// reality from two sides. If they drift, the console offers a channel the
// agent has no template for — a button that always fails.
func TestTheChannelTableAgreesWithTheAgentTemplates(t *testing.T) {
	// The agent lives in a sibling checkout; skip rather than fail when this
	// test runs somewhere that checkout is not present.
	path := filepath.Join("..", "..", "..", "..", "agent", "pam-agent",
		"internal", "launcher", "launch-templates.default.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Skipf("agent templates not reachable from here (%v)", err)
	}

	var templates map[string][]struct {
		ID   string `json:"id"`
		Kind string `json:"kind"`
	}
	if err := json.Unmarshal(raw, &templates); err != nil {
		t.Fatalf("agent templates are not valid JSON: %v", err)
	}

	for _, rt := range KnownResourceTypes() {
		candidates, ok := templates[rt]
		if !ok {
			t.Errorf("%s: the server promises channels but the agent has no templates for it", rt)
			continue
		}
		have := map[string]bool{}
		for _, c := range candidates {
			if ch := AgentKindToChannel(c.Kind); ch != "" {
				have[ch] = true
			}
		}
		for _, want := range SupportedChannels(rt) {
			if !have[want] {
				t.Errorf("%s: server promises %q but the agent has no %q candidate — the console would render a button that always fails",
					rt, want, want)
			}
		}
	}
}
