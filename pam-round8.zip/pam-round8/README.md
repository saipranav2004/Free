# PAM — round 8 changes (Deep Algorithms)

Copy the folders over your project root. Every path here matches your tree:

| In this zip | Goes to | What it is |
|---|---|---|
| `backend_upd/agents/` | `backend_upd/agents/` (replace the whole folder) | Agent executables for all 5 platforms, `VERSION` (`2026.09.25.2`) and `SHA256SUMS.txt` |
| `backend_upd/internal/webproxy/*.go` | same path | Qdrant landing page + the "session never reached" explanation (from round 7, which was never zipped for you) |
| `frontend_upd/src/...` | same path | Console changes (listed below). Run `npm run build` afterwards |
| `test-harness/e2e/*.mjs` | optional | The click-through scripts used to produce the proof screenshots |
| `proof/` | not code | Screenshots from the real click tests |

**No agent source code is included**, as you asked. Only the built executables are.
**`.env` is not included.** Your real `.env` still holds live production secrets; please rotate them if you haven't already.

After copying: restart `pam-api`. The console's **Settings → Devices** installer will then hand out `2026.09.25.2`. Re-install the agent on each machine (Windows: download the installer again from the console).

Check the binaries: `cd backend_upd/agents && sha256sum -c SHA256SUMS.txt` (PowerShell: `Get-FileHash pam-agent_windows_amd64.exe`, then compare with the file).

> Do **not** build the agent from the round-7 agent source if you still have it. Its pgAdmin import used `--replace`, which deletes **all** of the operator's own pgAdmin servers. These binaries replace it.

---

## How this round was tested

Every result below comes from clicking the real console (`Resources → <resource> → Connect → Open in Desktop / Open in Web`). The `pam-agent://` link was handed to the agent exactly as the OS link handler does. The real application was then used, closed, and the recording was played from **Audit & Compliance → Recordings**. The applications were real: pgAdmin 4 9.18 desktop, Redis Insight 2.70.1, MinIO, Qdrant 1.12.4 (with its real web dashboard) and Metabase.

| What | Result |
|---|---|
| pgAdmin 4: Open in Desktop → connects with **no password prompt** | ✅ `pg_stat_activity` shows `pam_pgadmin_test / pgAdmin 4` |
| pgAdmin 4: recording plays in the Recordings tab | ✅ 1920×1080 video, 2 m 17 s |
| pgAdmin 4: operator's own servers untouched | ✅ their "PostgreSQL 18" entry survives every launch |
| pgAdmin 4: reopening keeps saved Query Tool tabs working | ✅ (was broken, now fixed; see below) |
| pgAdmin 4 already open when clicking: operator is told what to do | ✅ (new, see below) |
| Redis Insight: Open in Desktop → connects to a password-protected Redis with **no prompt** | ✅ reads key `pam:demo` |
| Redis Insight: first-ever run (terms screen) | ✅ PAM connection appears right after accepting the terms, in the same session |
| Redis Insight: relaunch doesn't duplicate the entry | ✅ |
| Redis Insight: recording plays | ✅ |
| MinIO: Open in Web → signed in, files **inside** a bucket listed | ✅ recording is a 256 KB visual replay (not the 1.4 KB transcript you saw) |
| Qdrant: resource URL `http://host:6333` → lands on **/dashboard**, API key works, no username needed | ✅ |
| Metabase: Open in Web → signed in | ✅ |
| All three web sessions: replay plays in the Recordings tab | ✅ |
| Session the browser never reached (your Windows MinIO case) | ✅ the recording now says why, instead of showing an empty log |
| Qdrant API-key credential form: account name optional | ✅ |
| Backend `go test ./...`, agent `go test ./...`, Windows + macOS cross-builds, console lint + build | ✅ all pass |
| This zip applied on top of the last full backend/console you received | ✅ builds, tests pass, checksums verify |

---

## Bugs found by clicking, and fixed

1. **pgAdmin still asked for the password.** PAM's credential file was deleted 5 seconds after launch, but pgAdmin only asks for the password when you connect, which is usually later. The file now lives for the whole session and is deleted when the application closes. Redis Insight's connection file had the same problem and got the same fix.
2. **Redis Insight was never found on Windows/macOS.** Current releases are named **"Redis Insight.exe"** / **"Redis Insight.app"** (with a space) and install to `%LOCALAPPDATA%\Programs\Redis Insight\` (or `C:\Program Files\Redis Insight\`); on Linux the path is `/opt/redisinsight/`. The agent only looked for the old `RedisInsight.exe` name. It now checks all current and older paths. The Flathub ID was also wrong (it is `com.redis.RedisInsight`). This is the most likely reason Redis desktop didn't connect for you.
3. **macOS: Redis Insight would open empty.** `open -a` starts apps without the agent's environment, so Redis Insight never saw PAM's connection file. When a launch needs environment variables, the agent now runs the app's own executable inside the `.app` bundle instead.
4. **pgAdmin already open → silent, unrecorded work.** pgAdmin (like Redis Insight and Compass) allows only one copy. A second copy hands over to the open window and exits (measured: 1.6 s). PAM used to record a "completed" 2-second session while you kept working unrecorded. Now, if a desktop app closes within 8 seconds, PAM reports the launch as failed. The console shows: *"pgAdmin 4 closed 1.5s after PAM opened it. That almost always means it was already running… Close pgAdmin 4 completely (including from the system tray or menu bar), then click Open in Desktop again."* (see `proof/desktop/07`).
5. **pgAdmin's restored Query Tool tabs said "The server was not found".** Each launch deleted and re-imported PAM's server entry, which gave it a new internal ID. pgAdmin's saved tabs and query history point at the old ID. The entry is now updated in place and keeps its ID (`proof/desktop/05` → `06`).
6. **Console stopped watching too early.** After "Opened on your machine" it stopped checking, so a failure a few seconds later was never shown. It now keeps watching for 25 seconds after the agent opens.
7. **Recording side panel wording.** For desktop (video) and web (visual) recordings it now says what was recorded instead of "No commands logged… transcript".

Console files included: `ResourceAccess.jsx` (item 6), `SessionRecordingViewer.jsx` (item 7, plus the earlier WebSocket-ingress warning), `constants.js` and `ResourceDetailPage.jsx` (API-key credentials don't need an account name), and `DeviceCapabilities.jsx` (per-OS "install ffmpeg" hint). Only `ResourceAccess.jsx` and `SessionRecordingViewer.jsx` changed this round; the other three are earlier-round changes the last full console zip didn't include.

---

## What operators need to know

- **pgAdmin 4:** open pgAdmin once on a new machine before the first PAM launch (it creates its settings then). Close pgAdmin before clicking **Open in Desktop**.
- **Redis Insight:** on first use, accept its terms screen; the PAM connection then appears immediately.
- **Web sessions (MinIO, Qdrant, Metabase):** each session gets its own sub-domain (`<resource>-<id>.<PAM_WEBPROXY_BASE_DOMAIN>`). Production needs **wildcard DNS**, an ingress/load balancer that routes those sub-domains to PAM, and a wildcard TLS certificate if you use https. Without them the browser never reaches the session. That is what produced your 1.4 KB MinIO recording, and such recordings now explain this themselves (`proof/web/10`).
- The pgAdmin **"master password"** dialog in the screenshots comes from the Linux test machine having no OS keyring. On Windows, pgAdmin uses Windows Credential Manager and doesn't show it.

## Honest limits

- **Tested live on Linux.** Windows and macOS were covered by unit tests of the exact paths and commands, plus cross-builds; I have no Windows/macOS desktop here. The Windows path names come from Redis Insight's own build configuration and install scripts.
- **Oracle SQL Developer** still can't be pre-connected. It has no supported way to accept a password from outside (its wallet needs Oracle's `mkstore`). It opens, and the session is recorded.
- **Web replays:** images drawn as separate files (for example Qdrant's logo) can appear broken in a replay after the session has ended. Page content, clicks and navigation are all recorded. Fixing this properly means storing each session's images with its recording. That is a larger change I did not rush into this round.
