// Opens ONE session's recording from the console's Audit → Recordings tab,
// the way an auditor does, presses play, and screenshots what the player
// shows. Works for both renderers: desktop sessions (<video>) and brokered
// web sessions (rrweb replay).
//
// Usage: node play-recording.mjs <session-id> <shot-prefix> [seek-fraction]
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const [sessionId, prefix, seekArg] = process.argv.slice(2)
const seek = Number(seekArg || 0.6)
const APP = 'http://127.0.0.1:4180', API = 'http://127.0.0.1:8080'
const token = readFileSync('/tmp/tok-mfa', 'utf8').trim()
const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const page = await (await browser.newContext({ viewport: { width: 1600, height: 1000 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])
await page.goto(APP + '/admin/audit?tab=recordings', { waitUntil: 'networkidle' })
await page.waitForTimeout(2500)

let row = null
for (let hop = 0; hop < 20; hop++) {
  const r = page.locator('tbody tr').filter({ hasText: sessionId.slice(0, 8) }).first()
  if (await r.count()) { row = r; break }
  const next = page.getByRole('button', { name: 'Next page' }).first()
  if (!(await next.count()) || (await next.isDisabled().catch(() => true))) break
  await next.click(); await page.waitForTimeout(1200)
}
check('the session appears in Audit → Recordings', !!row)
if (!row) { await page.screenshot({ path: `${prefix}-table.png` }); await browser.close(); process.exit(1) }
await row.scrollIntoViewIfNeeded()
await page.screenshot({ path: `${prefix}-table.png` })
await row.getByRole('button', { name: /play recording/i }).first().click()
await page.waitForTimeout(6000)

const modal = page.locator('.fixed.inset-0').first()
check('the recording viewer opened', await modal.isVisible().catch(() => false))
const video = modal.locator('video').first()
if (await video.count()) {
  const meta = await video.evaluate((el) => ({ d: el.duration, w: el.videoWidth, h: el.videoHeight, err: el.error && el.error.code }))
  check('desktop video decoded', meta.w > 0 && Number.isFinite(meta.d) && meta.d > 1 && !meta.err, `${meta.w}x${meta.h} ${meta.d.toFixed(1)}s`)
  await page.getByRole('button', { name: /^play$/i }).first().click().catch(() => {})
  await page.waitForTimeout(2500)
  const t0 = await video.evaluate((el) => el.currentTime)
  check('pressing play advances the video', t0 > 0, `${t0.toFixed(2)}s`)
  // Jump to where the operator was working, so the screenshot shows content.
  await video.evaluate((el, f) => { el.pause(); el.currentTime = el.duration * f }, seek)
  await page.waitForTimeout(2500)
} else {
  const stage = modal.locator('iframe, .replayer-wrapper').first()
  check('web session replay stage rendered', await stage.count() > 0)
  await page.getByRole('button', { name: /^play$/i }).first().click().catch(() => {})
  await page.waitForTimeout(6000)
}
const text = (await modal.innerText().catch(() => '')).replace(/\s+/g, ' ')
console.log('  viewer text:', text.slice(0, 400))
await page.screenshot({ path: `${prefix}-player.png` })
const fatal = errors.filter((e) => !/favicon|manifest|ResizeObserver/i.test(e))
check('no page errors', fatal.length === 0, fatal[0] || '')
await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`${checks.length - failed.length}/${checks.length} checks passed`)
process.exit(failed.length ? 1 : 0)
