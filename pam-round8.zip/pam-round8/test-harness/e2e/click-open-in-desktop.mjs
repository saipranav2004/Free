// Clicks "Open in Desktop" in the real console, exactly as an operator does,
// and captures the pam-agent:// URL the console hands to the operating system.
//
// A headless browser has no OS URL handler, so the URL is written to a file
// and the caller runs `pam-agent launch <url>` with it — which is precisely
// what the handler `pam-agent install` registers does (Exec=pam-agent launch %u).
// Everything before and after that hand-off is the product's own code.
//
// Usage: node click-open-in-desktop.mjs <resource-id> <out-file> [shot.png]
import { chromium } from 'playwright-core'
import { readFileSync, writeFileSync } from 'node:fs'

const [resourceId, outFile, shot] = process.argv.slice(2)
const token = readFileSync('/tmp/tok-mfa', 'utf8').trim()
const API = 'http://127.0.0.1:8080', APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const page = await (await browser.newContext({ viewport: { width: 1500, height: 1000 } })).newPage()

let launchUrl = null, launchId = null
page.on('response', async (r) => {
  if (/\/resources\/[^/]+\/launch$/.test(new URL(r.url()).pathname) && r.request().method() === 'POST') {
    const body = await r.json().catch(() => ({}))
    launchUrl = body?.data?.launch_url || null
    launchId = body?.data?.launch_id || null
  }
})
// The console hands pam-agent:// to the OS by navigating to it. Swallow that
// navigation (there is no handler in a headless browser) so the page stays up
// to show the launch outcome.
await page.route(/^pam-agent:/, (r) => r.abort())

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

await page.goto(`${APP}/resources`, { waitUntil: 'networkidle' })
await page.waitForTimeout(2500)
// Type it into the list's own search box, as an operator does: the list is
// paged, so a resource past page one is not on screen until searched for.
const search = page.getByPlaceholder(/Search name, host/i).first()
await search.click()
await search.pressSequentially(resourceId, { delay: 40 })
await page.waitForTimeout(3000)
await page.locator('tbody tr').filter({ hasText: resourceId }).first()
  .getByText(resourceId, { exact: true }).first().click({ timeout: 15000 })
await page.waitForTimeout(3500)

// "Open in Desktop" lives on the resource's Connect tab, beside Open in CLI
// and Open in Web — the same place an operator clicks it.
await page.getByRole('tab', { name: /^Connect$/ }).first().click({ timeout: 8000 })
await page.waitForTimeout(2500)
const btn = page.getByRole('button', { name: /Open in Desktop/i }).first()
await btn.waitFor({ timeout: 15000 })
await btn.click()
for (let i = 0; i < 30 && !launchUrl; i++) await page.waitForTimeout(500)

if (shot) await page.screenshot({ path: shot })
if (!launchUrl) {
  console.error('the console did not produce a launch URL; page says:',
    (await page.locator('body').innerText()).replace(/\s+/g, ' ').slice(0, 300))
  await browser.close()
  process.exit(1)
}
writeFileSync(outFile, JSON.stringify({ launch_url: launchUrl, launch_id: launchId }))
console.log('launch_url captured from the console:', launchUrl.replace(/token=[^&]+/, 'token=…'))
// Optional: keep the page open while the caller runs the agent, then capture
// what the console shows the operator about how the launch went.
const [, , , waitSec, afterShot] = process.argv.slice(2)
if (waitSec) {
  await page.waitForTimeout(Number(waitSec) * 1000)
  if (afterShot) await page.screenshot({ path: afterShot })
  console.log('console now says:', (await page.locator('body').innerText()).replace(/\s+/g, ' ').match(/.{0,120}(already|could not|closed|Connected|opened).{0,260}/i)?.[0] || '(no launch status text)')
}
await browser.close()
