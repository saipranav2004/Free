// Clicks "Open in Web" in the real console, works inside the tab PAM opens,
// closes that tab (which is how an operator ends a web session), and waits for
// PAM's recording of it to be COMPLETED. The recording is then played by
// e2e/play-recording.mjs from Audit → Recordings.
//
// Usage: node click-open-in-web.mjs <resource-id> <shot-prefix> <minio|qdrant|metabase>
import { chromium } from 'playwright-core'
import { readFileSync, writeFileSync } from 'node:fs'

const [resourceId, prefix, app] = process.argv.slice(2)
const token = readFileSync('/tmp/tok-mfa', 'utf8').trim()
const API = 'http://127.0.0.1:8080', APP = 'http://127.0.0.1:4180'
const checks = []
const check = (n, ok, d = '') => { checks.push({ n, ok }); console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`) }
const api = async (p) => (await (await fetch(`${API}/api/v1/${p}`, { headers: { Authorization: 'Bearer ' + token } })).json()).data
const me = await api('auth/me')

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  // The per-session hostnames (<id>.pam.local) need wildcard DNS in a real
  // deployment; this maps them the way that DNS record would.
  args: ['--no-sandbox', '--no-proxy-server', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
const page = await ctx.newPage()
let sessionId = null
page.on('response', async (r) => {
  if (/\/web-session$/.test(new URL(r.url()).pathname) && r.request().method() === 'POST') {
    const b = await r.json().catch(() => ({}))
    sessionId = b?.data?.session_id || b?.data?.session?.id || null
  }
})

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null, expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])
await page.goto(`${APP}/resources`, { waitUntil: 'networkidle' })
await page.waitForTimeout(2000)
const search = page.getByPlaceholder(/Search name, host/i).first()
await search.click()
await search.pressSequentially(resourceId, { delay: 40 })
await page.waitForTimeout(3000)
await page.locator('tbody tr').filter({ hasText: resourceId }).first()
  .getByText(resourceId, { exact: true }).first().click({ timeout: 15000 })
await page.waitForTimeout(3000)
await page.getByRole('tab', { name: /^Connect$/ }).first().click({ timeout: 8000 })
await page.waitForTimeout(2000)

const [tab] = await Promise.all([
  ctx.waitForEvent('page', { timeout: 20000 }),
  page.getByRole('button', { name: /Open in Web/i }).first().click(),
])
await page.waitForTimeout(1500)
await page.screenshot({ path: `${prefix}-01-console-clicked.png` })
// The tab starts on about:blank and is pointed at the launch URL once PAM
// answers; wait for it to land on the proxied application.
for (let i = 0; i < 40 && !/pam\.local/.test(tab.url()); i++) await tab.waitForTimeout(500)
await tab.waitForLoadState('networkidle', { timeout: 30000 }).catch(() => {})
await tab.waitForTimeout(4000)
check('the tab opened on the brokered application', /pam\.local/.test(tab.url()), tab.url().replace(/[?#].*/, ''))
check('a PAM session id came back from the click', !!sessionId, sessionId || '')
// First-run notices the application itself shows (MinIO's AGPL licence
// dialog, Metabase's tours) are acknowledged the way an operator would.
for (const name of [/^Acknowledge$/i, /^Got it$/i, /^Skip$/i]) {
  const b = tab.getByRole('button', { name }).first()
  if (await b.isVisible().catch(() => false)) { await b.click().catch(() => {}); await tab.waitForTimeout(1200) }
}
const text = async () => (await tab.locator('body').innerText().catch(() => '')).replace(/\s+/g, ' ')

if (app === 'minio') {
  const t0 = await text()
  check('MinIO: signed in without a login form (object browser shown)', !/Login|Sign in/i.test(t0.slice(0, 200)) && /Bucket|Object Browser/i.test(t0), t0.slice(0, 120))
  await tab.screenshot({ path: `${prefix}-02-app.png` })
  const bucket = tab.getByText(/pam-demo|pam-test|demo/i).first()
  if (await bucket.count()) { await bucket.click().catch(() => {}); await tab.waitForTimeout(5000) }
  const t1 = await text()
  check('MinIO: the files INSIDE a bucket load', /\.(txt|json|csv|log|md)\b/i.test(t1), t1.match(/[\w-]+\.(txt|json|csv|log|md)/i)?.[0] || t1.slice(0, 160))
} else if (app === 'qdrant') {
  const t0 = await text()
  check('Qdrant: lands on the dashboard, not the JSON version banner', !/"title":"qdrant/.test(t0) && /Collections|Console|Dashboard/i.test(t0), t0.slice(0, 140))
  await tab.screenshot({ path: `${prefix}-02-app.png` })
  const col = tab.getByText('pam_demo', { exact: true }).first()
  if (await col.count()) { await col.click().catch(() => {}); await tab.waitForTimeout(4000) }
  const t1 = await text()
  check('Qdrant: the collection opens (API key accepted by the API behind the UI)', /pam_demo/.test(t1) && !/Unauthorized|Forbidden|401/.test(t1), t1.slice(0, 160))
} else if (app === 'metabase') {
  const t0 = await text()
  check('Metabase: signed in without a login form', !/Sign in to Metabase|Email address/i.test(t0) && /(Home|Browse|New|Collections|Metabase)/i.test(t0), t0.slice(0, 140))
  await tab.screenshot({ path: `${prefix}-02-app.png` })
  const browse = tab.getByText(/Browse data|Databases|Our analytics/i).first()
  if (await browse.count()) { await browse.click().catch(() => {}); await tab.waitForTimeout(5000) }
}
await tab.screenshot({ path: `${prefix}-03-app-in-use.png` })
await tab.waitForTimeout(3000)

// End the session the way the console tells the operator to: close the tab.
await tab.close()
await page.waitForTimeout(2000)

let rec = null
for (let i = 0; i < 60 && sessionId && !rec; i++) {
  const d = await api(`pam/admin/recordings?session_id=${sessionId}&limit=10`)
  rec = (d?.recordings || []).find((x) => x.status === 'COMPLETED' && (x.size_bytes || 0) > 0) || null
  if (!rec) await new Promise((r) => setTimeout(r, 2000))
}
check('closing the tab ended the session and the recording is COMPLETED', !!rec,
  rec ? `${rec.format} ${rec.size_bytes} B` : 'no completed recording')
check('it is a visual (rrweb) recording, not a bare transcript', rec?.format === 'rrweb' || rec?.format === 'visual', rec?.format || '')
writeFileSync(`${prefix}.session`, sessionId || '')
await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`${checks.length - failed.length}/${checks.length} checks passed; session ${sessionId}`)
process.exit(failed.length ? 1 : 0)
