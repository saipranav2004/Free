package identities

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

type IdentitiesListService struct {
	repo     *IdentitiesListRepository
	resolver *scope.Resolver
	activity *identitygraph.ActivityService
}

func NewIdentitiesListService(repo *IdentitiesListRepository, resolver *scope.Resolver, activity *identitygraph.ActivityService) *IdentitiesListService {
	return &IdentitiesListService{repo: repo, resolver: resolver, activity: activity}
}

func (s *IdentitiesListService) GetIdentities(ctx context.Context, userID, tenantID, dbName string, f IdentityListFilter) (*IdentityListResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	result, err := s.repo.GetIdentitiesList(ctx, resolved, f, s.activity.ForRequest(resolved))
	if err != nil {
		return nil, fmt.Errorf("get scoped identities: %w", err)
	}
	return result, nil
}
