package identities

// Allowed query parameters and enum values — strict validation so typos like
// credential_tye are not silently ignored.

var (
	identitiesListAllowed = map[string]struct{}{
		"page": {}, "page_size": {}, "search": {},
		"identity_type": {}, "functional_class": {}, "environment": {},
		"status": {}, "owner": {}, "vpc_id": {},
		"is_publicly_accessible": {}, "min_idle_days": {},
		"sort_by": {}, "sort_order": {},
	}

	identityDetailAllowed = map[string]struct{}{
		"tab": {}, "time_range": {}, "start_date": {}, "end_date": {},
		"service": {}, "used_only": {}, "depth": {}, "edge_type": {},
		"page": {}, "page_size": {},
	}

	// sort_by enums — must match repository maps
	identitySortColumnsAllowed = map[string]struct{}{
		"name": {}, "arn": {}, "identity_type": {}, "functional_class": {},
		"account_id": {}, "region": {}, "environment": {}, "owner": {},
		"status": {}, "last_activity_at": {}, "created_at_aws": {},
		"age_days": {}, "idle_days": {}, "bound_credentials_count": {},
		"permission_utilization_pct": {},
	}

	// value enums — strict so credential_type=w errors
	validIdentityTypes = map[string]struct{}{
		"ec2_instance": {}, "lambda_function": {}, "ecs_task": {}, "eks_pod": {},
		"batch_job": {}, "iam_user": {}, "iam_role": {}, "rds_instance": {},
		"s3_bucket": {}, "ebs_volume": {}, "eni": {}, "vpc": {}, "subnet": {},
		"security_group": {}, "emr_cluster": {}, "sagemaker_notebook": {},
		"glue_job": {}, "step_function": {}, "api_gateway": {},
		"cloudformation_stack": {}, "codebuild_project": {}, "codepipeline": {},
		"ecs_service": {}, "eks_cluster": {}, "elasticache_cluster": {},
		"redshift_cluster": {}, "dynamodb_table": {}, "kinesis_stream": {},
		"sqs_queue": {}, "sns_topic": {}, "cloudfront_distribution": {},
	}

	validFunctionalClasses = map[string]struct{}{
		"service": {}, "application": {}, "infrastructure": {}, "data": {},
		"security": {}, "compute": {}, "storage": {}, "network": {},
	}

	validEnvironments = map[string]struct{}{
		"production": {}, "staging": {}, "development": {}, "testing": {},
		"sandbox": {}, "prod": {}, "dev": {}, "qa": {}, "uat": {},
	}

	validIdentityStatuses = map[string]struct{}{
		"active": {}, "inactive": {}, "stopped": {}, "terminated": {},
		"running": {}, "pending": {}, "deleted": {}, "available": {},
		"creating": {}, "failed": {},
	}

	validIdentityTabs = map[string]struct{}{
		"overview": {}, "permissions": {}, "activity": {}, "relationships": {},
		"credentials": {}, "raw": {}, "changes": {},
	}
)
