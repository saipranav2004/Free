// Package identities serves the non-human identity API: the filtered identity
// list and the per-identity detail tabs.
//
// The shared graph, activity and detail queries live in internal/identitygraph.
package identities

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handlers and registers their routes.
type Module struct {
	list   *IdentitiesListHandler
	detail *IdentityDetailHandler
}

// New builds the module.
func New(resolver *scope.Resolver, activity *identitygraph.ActivityService) *Module {
	return &Module{
		list:   NewIdentitiesListHandler(NewIdentitiesListService(NewIdentitiesListRepository(), resolver, activity)),
		detail: NewIdentityDetailHandler(NewIdentityDetailService(identitygraph.NewIdentityDetailRepository(), resolver, activity)),
	}
}

// Register mounts the identity routes on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/identities", m.list.List).Methods(http.MethodGet)
	r.HandleFunc("/identities/{id}", m.detail.Get).Methods(http.MethodGet)
}
