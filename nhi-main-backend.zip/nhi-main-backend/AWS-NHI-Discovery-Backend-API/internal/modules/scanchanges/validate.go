package scanchanges

import (
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"nhi-backend-api/internal/platform/httpx"
)

// Allowed query parameters and enum values — strict validation, so a typo is
// a 400 instead of a silently unfiltered list.
var (
	scanChangesAllowed = map[string]struct{}{
		"change_type": {}, "entity_type": {}, "page": {}, "limit": {},
	}

	validChangeTypes = map[string]struct{}{
		"created": {}, "deleted": {}, "modified": {},
	}

	validEntityTypes = map[string]struct{}{
		"identity": {}, "credential": {}, "permission": {}, "binding": {}, "trust_edge": {},
	}
)

// entityTypes is the fixed zero-fill key set of summary.by_entity, so the
// block always has the same shape whatever the scan contains.
var entityTypes = []string{"identity", "credential", "permission", "binding", "trust_edge"}

// scanIDPattern accepts the scanner's scan identifiers (e.g.
// "scan-20261016-190603"). It is deliberately a length-bounded slug check,
// not a UUID check: nhi_scans_aws.scan_id is text and its format belongs to
// the scanner, so this only keeps control characters and absurd lengths out of
// the query.
var scanIDPattern = regexp.MustCompile(`^[A-Za-z0-9._:-]{1,128}$`)

// ScanChangesFilter is the parsed & validated query of one request.
type ScanChangesFilter struct {
	ScanID     string
	ChangeType string // upper-case, "" = all
	EntityType string // lower-case, "" = all
	Page       int    // default 1
	Limit      int    // default 50, max 200
}

const (
	defaultChangesLimit = 50
	maxChangesLimit     = 200 // spec ceiling; the inventory lists clamp at 100
	maxChangesPageEnd   = 100_000
)

// ParseChangeType validates ?change_type= and normalises it to the stored
// upper-case vocabulary. It writes the 400 itself.
func ParseChangeType(w http.ResponseWriter, raw string) (string, bool) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", true
	}
	if _, ok := validChangeTypes[strings.ToLower(raw)]; !ok {
		httpx.WriteError(w, http.StatusBadRequest,
			"Invalid change_type: "+raw+". Allowed: "+httpx.AllowedList(validChangeTypes),
			"INVALID_CHANGE_TYPE")
		return "", false
	}
	return strings.ToUpper(raw), true
}

// ParseEntityType validates ?entity_type= and normalises it to the stored
// lower-case vocabulary. It writes the 400 itself.
func ParseEntityType(w http.ResponseWriter, raw string) (string, bool) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", true
	}
	if _, ok := validEntityTypes[strings.ToLower(raw)]; !ok {
		httpx.WriteError(w, http.StatusBadRequest,
			"Invalid entity_type: "+raw+". Allowed: "+httpx.AllowedList(validEntityTypes),
			"INVALID_ENTITY_TYPE")
		return "", false
	}
	return strings.ToLower(raw), true
}

// ParseChangesPaging reads ?page= and ?limit= (defaults 1 / 50, limit max 200).
// It writes the 400 itself and returns ok=false when a value is invalid.
func ParseChangesPaging(w http.ResponseWriter, q url.Values) (page, limit int, ok bool) {
	page, limit = 1, defaultChangesLimit
	bad := func(msg string) (int, int, bool) {
		httpx.WriteError(w, http.StatusBadRequest, msg, "INVALID_PAGINATION")
		return 0, 0, false
	}
	if raw := strings.TrimSpace(q.Get("page")); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 1 {
			return bad("page must be a positive integer")
		}
		page = v
	}
	if raw := strings.TrimSpace(q.Get("limit")); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 1 || v > maxChangesLimit {
			return bad("limit must be an integer between 1 and 200")
		}
		limit = v
	}
	if page > maxChangesPageEnd/page { // overflow-safe bound on page * limit
		return bad("page is too large")
	}
	return page, limit, true
}
