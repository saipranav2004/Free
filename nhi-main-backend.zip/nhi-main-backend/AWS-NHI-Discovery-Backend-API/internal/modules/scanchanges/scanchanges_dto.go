package scanchanges

import (
	"encoding/json"
	"time"
)

// DTOs: the JSON shapes of GET /api/v1/scans/{scan_id}/changes. Pagination
// follows the scan-changes spec (page/limit/total) rather than the
// page_size/total_count block the inventory lists use; no existing endpoint
// changes shape.

// ScanChangesSummary is the roll-up over the whole scan. It is computed from
// an unfiltered GROUP BY, so filters never shift the summary.
type ScanChangesSummary struct {
	Total    int            `json:"total"`
	Created  int            `json:"created"`
	Deleted  int            `json:"deleted"`
	Modified int            `json:"modified"`
	ByEntity map[string]int `json:"by_entity"`
}

// ScanChangeItem is one diff row. EntityID is nullable; Details passes the
// stored jsonb through untouched.
type ScanChangeItem struct {
	ID         string          `json:"id"`
	ChangeType string          `json:"change_type"`
	EntityType string          `json:"entity_type"`
	EntityARN  string          `json:"entity_arn"`
	EntityID   *string         `json:"entity_id,omitempty"`
	Summary    string          `json:"summary"`
	Details    json.RawMessage `json:"details,omitempty"`
	DetectedAt time.Time       `json:"detected_at"`
}

// ScanChangesPagination is the spec's pagination block.
type ScanChangesPagination struct {
	Page  int `json:"page"`
	Limit int `json:"limit"`
	Total int `json:"total"`
}

// ScanChangesResponse wraps the scan header, the filter-independent summary
// and the filtered page. Changes is always [] (never null), and PreviousScanID
// is null when the previous scan is unknown (no change row carries one, or
// scan_changes has not been created for this tenant).
type ScanChangesResponse struct {
	ScanID         string                `json:"scan_id"`
	Status         string                `json:"status"`
	ScannedAt      *time.Time            `json:"scan_time"`
	PreviousScanID *string               `json:"previous_scan_id"`
	Summary        ScanChangesSummary    `json:"summary"`
	Changes        []ScanChangeItem      `json:"changes"`
	Pagination     ScanChangesPagination `json:"pagination"`
}

// scanHeader mirrors the scan row we expose: identity, status and time.
type scanHeader struct {
	ScanID    string
	Status    string
	ScannedAt *time.Time
}

// countRow is one (change_type, entity_type) group of the whole scan.
type countRow struct {
	ChangeType string
	EntityType string
	Count      int
}

// ScanStatusResponse is the data payload of GET /api/v1/scans/{scan_id}/status.
type ScanStatusResponse struct {
	ScanID    string     `json:"scan_id"`
	Status    string     `json:"status"`
	ScannedAt *time.Time `json:"scan_time"`
}
