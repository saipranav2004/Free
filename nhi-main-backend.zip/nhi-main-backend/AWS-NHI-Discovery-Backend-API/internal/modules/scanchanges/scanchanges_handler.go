package scanchanges

import (
	"errors"
	"net/http"
	"strings"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/logging"
	"nhi-backend-api/internal/platform/middleware"
)

// Handler layer: HTTP only. Parse and validate the request, call the service,
// write the response. No SQL and no business rules here.

type ScanChangesHandler struct {
	service *ScanChangesService
}

func NewScanChangesHandler(service *ScanChangesService) *ScanChangesHandler {
	return &ScanChangesHandler{service: service}
}

// List handles GET /api/v1/scans/{scan_id}/changes.
func (h *ScanChangesHandler) List(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{Success: false, Message: "Unauthorized"})
		return
	}

	scanID := strings.TrimSpace(mux.Vars(r)["scan_id"])
	if !scanIDPattern.MatchString(scanID) {
		httpx.WriteError(w, http.StatusBadRequest, "Invalid scan ID", "INVALID_SCAN_ID")
		return
	}

	if httpx.RejectUnknownQuery(w, r, scanChangesAllowed) {
		return
	}
	q := r.URL.Query()

	changeType, ok := ParseChangeType(w, q.Get("change_type"))
	if !ok {
		return
	}
	entityType, ok := ParseEntityType(w, q.Get("entity_type"))
	if !ok {
		return
	}
	page, limit, ok := ParseChangesPaging(w, q)
	if !ok {
		return
	}

	resp, err := h.service.List(r.Context(), claims.UserID, claims.TenantID, claims.DBName, ScanChangesFilter{
		ScanID:     scanID,
		ChangeType: changeType,
		EntityType: entityType,
		Page:       page,
		Limit:      limit,
	})
	if err != nil {
		if errors.Is(err, ErrScanNotFound) {
			// 404 (never 403) for a scan outside the caller's scope, so the
			// response never reveals whether the scan exists elsewhere.
			httpx.WriteError(w, http.StatusNotFound, "scan '"+scanID+"' not found", "SCAN_NOT_FOUND")
			return
		}
		logging.FromContext(r.Context()).Error("scan changes failed", "err", err)
		httpx.WriteError(w, http.StatusInternalServerError, "Failed to retrieve scan changes", "SCANS_CHANGES_LOAD_FAILED")
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Scan changes retrieved successfully",
		Data:    resp,
	})
}

// Status handles GET /api/v1/scans/{scan_id}/status.
func (h *ScanChangesHandler) Status(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{Success: false, Message: "Unauthorized"})
		return
	}

	scanID := strings.TrimSpace(mux.Vars(r)["scan_id"])
	if !scanIDPattern.MatchString(scanID) {
		httpx.WriteError(w, http.StatusBadRequest, "Invalid scan ID", "INVALID_SCAN_ID")
		return
	}

	if httpx.RejectUnknownQuery(w, r, httpx.NoQuery) {
		return
	}

	resp, err := h.service.GetStatus(r.Context(), claims.UserID, claims.TenantID, claims.DBName, scanID)
	if err != nil {
		if errors.Is(err, ErrScanNotFound) {
			// 404 (never 403) for a scan outside the caller's scope.
			httpx.WriteError(w, http.StatusNotFound, "scan '"+scanID+"' not found", "SCAN_NOT_FOUND")
			return
		}
		logging.FromContext(r.Context()).Error("scan status failed", "err", err)
		httpx.WriteError(w, http.StatusInternalServerError, "Failed to retrieve scan status", "SCAN_STATUS_LOAD_FAILED")
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Scan status retrieved successfully",
		Data:    resp,
	})
}
