// Package dashboardsummary serves GET /api/v1/genome/dashboard/summary: the
// genome dashboard's cards and panels, built from the tenant's discovery,
// baseline, risk and alert tables.
package dashboardsummary

import (
	"time"

	"nhi-backend-api/internal/modules/genome/common"
)

// Response is the data block of the dashboard summary.
type Response struct {
	Cards                   Cards                       `json:"cards"`
	DeparturesByDimension   []DimensionCount            `json:"departures_by_dimension"`
	AnomaliesByDay          []DayCount                  `json:"anomalies_by_day"`
	MostAnomalousIdentities []AnomalousIdentity         `json:"most_anomalous_identities"`
	PeerGroupOutliers       []PeerOutlier               `json:"peer_group_outliers"`
	RecentlyBaselined       []RecentlyBaselinedIdentity `json:"recently_baselined"`
}

// Cards are the summary cards. A pointer is null when the value could not
// be read from its store, or, for critical_anomalies /
// mean_provenance_confidence, until ClickHouse log_events is connected.
// drifting_baselines is null with drifting_baselines_available=false.
type Cards struct {
	BaselinesEstablished       *int     `json:"baselines_established"`
	IdentitiesWatched          *int     `json:"identities_watched"`
	StillLearning              *int     `json:"still_learning"`
	OpenAnomalies              *int     `json:"open_anomalies"`
	CriticalAnomalies          *int     `json:"critical_anomalies"`
	BaselineCoveragePercent    *float64 `json:"baseline_coverage_percent"`
	MeanProvenanceConfidence   *float64 `json:"mean_provenance_confidence"`
	MeanConfidencePercent      *float64 `json:"mean_confidence_percent"`
	DriftingBaselines          *int     `json:"drifting_baselines"`
	DriftingBaselinesAvailable bool     `json:"drifting_baselines_available"`
	WindowHours                int      `json:"window_hours"`
}

// DimensionCount is one departures_by_dimension row: the exact
// alerts.dimension value and COUNT(*).
type DimensionCount struct {
	Dimension string `json:"dimension"`
	Count     int    `json:"count"`
}

// DayCount is one anomalies_by_day row: DATE_TRUNC('day', alerts.created_at)
// as YYYY-MM-DD (UTC) and COUNT(*).
type DayCount struct {
	Day   string `json:"day"`
	Count int    `json:"count"`
}

// AnomalousIdentity is one most_anomalous_identities row: the latest
// identity_risk_scores columns joined to identities for display_name,
// account_id, region and workload metadata.
type AnomalousIdentity struct {
	common.DashboardIdentityRef
	AccountID           string    `json:"account_id"`
	Region              string    `json:"region"`
	ServiceName         string    `json:"service_name"`
	WorkloadKey         string    `json:"workload_key"`
	RiskScore           *int      `json:"risk_score"`
	Severity            string    `json:"severity"`
	ScoreStatus         string    `json:"score_status"`
	EventCount          int       `json:"event_count"`
	AnomalousEventCount int       `json:"anomalous_event_count"`
	WindowStart         time.Time `json:"window_start"`
	WindowEnd           time.Time `json:"window_end"`
	ComputedAt          time.Time `json:"computed_at"`
}

// PeerOutlier is one peer_group_outliers row (MVP: derived peer_key, the
// identity's recent anomaly count and risk score compared to the
// peer-group means).
type PeerOutlier struct {
	common.DashboardIdentityRef
	PeerKey              string   `json:"peer_key"`
	PeerCount            int      `json:"peer_count"`
	RiskScore            *int     `json:"risk_score"`
	PeerMeanRiskScore    *float64 `json:"peer_mean_risk_score"`
	AnomalyCount         int      `json:"anomaly_count"`
	PeerMeanAnomalyCount float64  `json:"peer_mean_anomaly_count"`
}

// RecentlyBaselinedIdentity is one recently_baselined row:
// baselines.active_since or baseline_versions.published_at joined to
// identities.
type RecentlyBaselinedIdentity struct {
	common.DashboardIdentityRef
	AccountID  string    `json:"account_id"`
	Region     string    `json:"region"`
	Event      string    `json:"event"` // baseline_established | baseline_version_published
	OccurredAt time.Time `json:"occurred_at"`
	Version    *int64    `json:"version"`
}
