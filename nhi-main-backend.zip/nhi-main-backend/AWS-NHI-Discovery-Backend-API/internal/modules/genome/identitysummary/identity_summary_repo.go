package identitysummary

import (
	"context"
	"database/sql"
	"errors"

	"nhi-backend-api/internal/modules/genome/common"
	"nhi-backend-api/internal/platform/scope"
)

// Repository reads what the identity summary needs from the caller's
// tenant schema: baselines (baseline_summary) and alerts
// (headline_metrics.open_anomalies). The identity itself and its risk
// snapshot come from common.LatestIdentities / common.LatestRiskPreferred.
// Every method takes the resolved *scope.DataScope and looks the
// monitoring tables up by the normalized keys the service passes —
// identity key first, then the shared workload key. Nothing is written.
type Repository struct{}

// NewRepository creates the repository.
func NewRepository() *Repository { return &Repository{} }

// BaselineSummaryRow is baseline_summary (schema guide §7).
type BaselineSummaryRow struct {
	Key          common.MonitoringKey // key the row is stored under (identity key or shared workload key)
	Status       string
	BuiltDays    int
	RequiredDays int
}

// BaselineSummary returns the baselines row of the first key, in the order
// given, that has one; nil, nil when none has.
func (r *Repository) BaselineSummary(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey) (*BaselineSummaryRow, error) {
	if len(keys) == 0 {
		return nil, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT b.source_type, b.identity_name, b.status, b.built_days, b.required_days
	      FROM ` + resolved.Table("baselines") + ` b` + common.KeyPreferenceJoin("b") + `
	      ORDER BY k.preference
	      LIMIT 1`
	var row BaselineSummaryRow
	err := resolved.DB.QueryRowContext(ctx, q, types, names).Scan(&row.Key.SourceType, &row.Key.IdentityName, &row.Status, &row.BuiltDays, &row.RequiredDays)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "baseline summary", err)
	}
	return &row, nil
}

// OpenAlertCount is headline_metrics.open_anomalies: COUNT(*) from alerts
// where the identity matches (any of the keys) and status = 'open' — no
// time window.
func (r *Repository) OpenAlertCount(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey) (int, error) {
	if len(keys) == 0 {
		return 0, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT COUNT(*) FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      WHERE a.status = 'open'`
	var n int
	if err := resolved.DB.QueryRowContext(ctx, q, types, names).Scan(&n); err != nil {
		return 0, common.WrapMonitoringErr(ctx, "open alert count", err)
	}
	return n, nil
}
