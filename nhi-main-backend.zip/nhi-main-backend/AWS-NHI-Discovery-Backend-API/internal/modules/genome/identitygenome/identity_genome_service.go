package identitygenome

import (
	"context"

	"nhi-backend-api/internal/modules/genome/common"
)

// Service implements
// GET /api/v1/genome/identities/{source_type}/{identity_name}/genome — the
// behavioural fingerprint, typical actions, typical resources and the
// activity schedule. Everything is aggregated by ClickHouse from
// log_events inside the requested window; the service only resolves the
// identity, forwards the limit and turns distinct-event counts into share
// percentages (count / all calls × 100).
//
// Nothing is invented: while the monitoring ClickHouse is not configured or
// cannot be read all four lists are empty (logged server-side).
type Service struct {
	lookup *common.MonitoredIdentityLookup
	events *common.MonitoringEvents // nil when no monitoring ClickHouse is configured
}

// NewService wires the service.
func NewService(lookup *common.MonitoredIdentityLookup, events *common.MonitoringEvents) *Service {
	return &Service{lookup: lookup, events: events}
}

// Params are the parsed query parameters.
type Params struct {
	Window common.TimeWindow // from (inclusive) / to (exclusive)
	Limit  int               // rows of typical_actions / typical_resources and values per fingerprint dimension
}

// GetGenome builds the response. Unknown identities are
// common.ErrIdentityNotFound; scope/discovery failures are
// *common.StoreUnavailableError.
func (s *Service) GetGenome(ctx context.Context, userID, tenantID, dbName, sourceType, identityName string, p Params) (*Response, error) {
	res, err := s.lookup.Resolve(ctx, userID, tenantID, dbName, sourceType, identityName)
	if err != nil {
		return nil, err
	}
	key := res.Identity.Key
	from, to := p.Window.From, p.Window.To

	out := &Response{
		Fingerprint:      []FingerprintPoint{},
		TypicalActions:   []TypicalAction{},
		TypicalResources: []TypicalResource{},
		ActivitySchedule: []ScheduleCell{},
	}

	// Denominator of every share: all calls of the identity in the window.
	total, err := s.events.TotalCalls(ctx, key.SourceType, key.IdentityName, from, to)
	if !common.EventsReadOK("identity genome total calls", err) {
		return out, nil
	}

	if points, err := s.events.Fingerprint(ctx, key.SourceType, key.IdentityName, from, to, common.FingerprintDimensions, p.Limit); common.EventsReadOK("identity fingerprint", err) {
		for _, pt := range points {
			out.Fingerprint = append(out.Fingerprint, FingerprintPoint{Dimension: pt.Dimension, Value: pt.Value, SharePercent: sharePercent(pt.Calls, total)})
		}
	}
	if actions, err := s.events.TypicalActions(ctx, key.SourceType, key.IdentityName, from, to, p.Limit); common.EventsReadOK("identity typical actions", err) {
		for _, a := range actions {
			out.TypicalActions = append(out.TypicalActions, TypicalAction{APIOperation: common.APIOperation(a.EventSource, a.EventName), Calls: a.Calls, SharePercent: sharePercent(a.Calls, total)})
		}
	}
	if resources, err := s.events.TypicalResources(ctx, key.SourceType, key.IdentityName, from, to, p.Limit); common.EventsReadOK("identity typical resources", err) {
		for _, r := range resources {
			out.TypicalResources = append(out.TypicalResources, TypicalResource{Resource: r.ResourceARN, ResourceType: common.OptionalString(r.ResourceType), Calls: r.Calls})
		}
	}
	if cells, err := s.events.ActivitySchedule(ctx, key.SourceType, key.IdentityName, from, to); common.EventsReadOK("identity activity schedule", err) {
		for _, c := range cells {
			out.ActivitySchedule = append(out.ActivitySchedule, ScheduleCell{DayOfWeek: int(c.DayOfWeek), Hour: int(c.Hour), Calls: c.Calls})
		}
	}
	if err := common.BudgetExceeded(ctx, "identity genome"); err != nil {
		return nil, err
	}
	return out, nil
}

// sharePercent is share_percent: part / all calls × 100, one decimal.
func sharePercent(part, total uint64) float64 {
	if total == 0 {
		return 0
	}
	return common.Round1(float64(part) / float64(total) * 100)
}
