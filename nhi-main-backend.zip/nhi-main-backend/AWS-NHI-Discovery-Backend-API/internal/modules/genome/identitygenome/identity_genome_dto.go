// Package identitygenome serves
// GET /api/v1/genome/identities/{source_type}/{identity_name}/genome: the
// behavioural fingerprint, typical actions/resources and activity schedule.
// Every number is computed by ClickHouse from log_events; all four lists
// are empty until the identity has events in the window (or while the
// monitoring ClickHouse is unavailable).
package identitygenome

// Response is the data block.
type Response struct {
	Fingerprint      []FingerprintPoint `json:"fingerprint"`
	TypicalActions   []TypicalAction    `json:"typical_actions"`
	TypicalResources []TypicalResource  `json:"typical_resources"`
	ActivitySchedule []ScheduleCell     `json:"activity_schedule"`
}

// FingerprintPoint is one (dimension, value) of the behavioural
// fingerprint: dimension/value are a key/value of log_events.dimensions_json,
// share_percent = distinct events carrying the value / all calls × 100.
type FingerprintPoint struct {
	Dimension    string  `json:"dimension"`
	Value        string  `json:"value"`
	SharePercent float64 `json:"share_percent"`
}

// TypicalAction is one typical_actions row: event_source + ':' +
// event_name, its distinct-event count and share of all calls.
type TypicalAction struct {
	APIOperation string  `json:"api_operation"`
	Calls        uint64  `json:"calls"`
	SharePercent float64 `json:"share_percent"`
}

// TypicalResource is one typical_resources row: one ARN of the split
// log_events.resource_arns, the distinct events that touched it and the
// dimensions_json.resource_type seen with it (null when the key is missing
// — NEEDS CONFIRMATION).
type TypicalResource struct {
	Resource     string  `json:"resource"`
	ResourceType *string `json:"resource_type"`
	Calls        uint64  `json:"calls"`
}

// ScheduleCell is one activity_schedule cell: ClickHouse toDayOfWeek
// (1 = Monday … 7 = Sunday) × toHour (0–23, UTC).
type ScheduleCell struct {
	DayOfWeek int    `json:"day_of_week"`
	Hour      int    `json:"hour"`
	Calls     uint64 `json:"calls"`
}
