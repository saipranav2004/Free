package identitytimeline

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"sort"
	"strconv"
	"strings"
	"time"

	"nhi-backend-api/internal/modules/genome/common"
)

// Service implements
// GET /api/v1/genome/identities/{source_type}/{identity_name}/timeline —
// the lifecycle timeline derived from the current tables, newest first:
//
//   - anomaly                     one item per alerts row   (alerts.created_at)
//   - baseline_version_published  one item per version      (baseline_versions.published_at)
//   - learning_started            baselines.first_seen_date
//   - baseline_established        baselines.active_since
//
// The identity is resolved from the tenant's discovery table first
// (unknown → common.ErrIdentityNotFound). Nothing is invented: a source
// table that cannot be read contributes no items (logged server-side); the
// milestones exist only when the baselines row carries the timestamp.
type Service struct {
	lookup *common.MonitoredIdentityLookup
	repo   *Repository
}

// NewService wires the service.
func NewService(lookup *common.MonitoredIdentityLookup, repo *Repository) *Service {
	return &Service{lookup: lookup, repo: repo}
}

// Params are the parsed query parameters.
type Params struct {
	Limit  int    // page size: default 25, max 100
	Cursor string // opaque, from a previous meta.next_cursor; "" for the first page
}

// Display titles per item type.
var titles = map[string]string{
	TypeAnomaly:                  "Anomaly detected",
	TypeBaselineVersionPublished: "Baseline version published",
	TypeLearningStarted:          "Learning started",
	TypeBaselineEstablished:      "Baseline established",
}

// GetTimeline builds the page and the meta.next_cursor (nil on the last
// page). Unknown identities are common.ErrIdentityNotFound,
// scope/discovery failures *common.StoreUnavailableError, a foreign cursor
// common.ErrInvalidCursor.
func (s *Service) GetTimeline(ctx context.Context, userID, tenantID, dbName, sourceType, identityName string, p Params) (*Response, *string, error) {
	after, err := decodeCursor(p.Cursor)
	if err != nil {
		return nil, nil, err
	}
	res, err := s.lookup.Resolve(ctx, userID, tenantID, dbName, sourceType, identityName)
	if err != nil {
		return nil, nil, err
	}
	id, sc := res.Identity, res.Scope
	keys := id.AllKeys() // identity key, then the shared workload key

	var entries []timelineEntry
	if alerts, err := s.repo.Alerts(ctx, sc, keys); common.ReadOK("identity timeline alerts", err) {
		for _, a := range alerts {
			desc := "Dimension: " + a.Dimension + "; " + a.Reason
			status := a.Status
			entries = append(entries, timelineEntry{
				key: timelineKey{At: a.CreatedAt.UnixMilli(), Type: TypeAnomaly, Ref: strconv.FormatInt(a.ID, 10)},
				item: Item{Type: TypeAnomaly, Title: titles[TypeAnomaly],
					Description: &desc, OccurredAt: a.CreatedAt, Status: &status},
			})
		}
	}
	versionsKey := id.Key
	if row, err := s.repo.BaselineMilestones(ctx, sc, keys); common.ReadOK("identity timeline baseline", err) && row != nil {
		versionsKey = row.Key
		if row.FirstSeenDate != nil {
			entries = append(entries, milestone(TypeLearningStarted, *row.FirstSeenDate))
		}
		if row.ActiveSince != nil {
			entries = append(entries, milestone(TypeBaselineEstablished, *row.ActiveSince))
		}
	}
	if versions, err := s.repo.PublishedVersions(ctx, sc, versionsKey); common.ReadOK("identity timeline versions", err) {
		for _, v := range versions {
			desc := "Version " + strconv.FormatInt(v.Version, 10)
			entries = append(entries, timelineEntry{
				key: timelineKey{At: v.PublishedAt.UnixMilli(), Type: TypeBaselineVersionPublished, Ref: strconv.FormatInt(v.Version, 10)},
				item: Item{Type: TypeBaselineVersionPublished, Title: titles[TypeBaselineVersionPublished],
					Description: &desc, OccurredAt: v.PublishedAt},
			})
		}
	}

	sort.SliceStable(entries, func(i, j int) bool { return compareKeys(entries[i].key, entries[j].key) < 0 })
	if after != nil {
		cut := sort.Search(len(entries), func(i int) bool { return compareKeys(entries[i].key, *after) > 0 })
		entries = entries[cut:]
	}
	var next *string
	if len(entries) > p.Limit {
		entries = entries[:p.Limit]
		next = encodeCursor(entries[len(entries)-1].key)
	}
	out := &Response{Items: make([]Item, 0, len(entries))}
	for _, e := range entries {
		out.Items = append(out.Items, e.item)
	}
	if err := common.BudgetExceeded(ctx, "identity timeline"); err != nil {
		return nil, nil, err
	}
	return out, next, nil
}

// milestone builds a baselines-derived item (no description, no status).
func milestone(typ string, at time.Time) timelineEntry {
	return timelineEntry{
		key:  timelineKey{At: at.UnixMilli(), Type: typ},
		item: Item{Type: typ, Title: titles[typ], OccurredAt: at},
	}
}

// ---------------------------------------------------------------------------
// ordering and the keyset cursor
// ---------------------------------------------------------------------------

// timelineEntry is one item with its total-order key.
type timelineEntry struct {
	key  timelineKey
	item Item
}

// timelineKey orders items: occurred_at descending, then type, then the
// source row reference (alert id / version) descending — a total order,
// so a keyset cursor can resume it.
type timelineKey struct {
	At   int64  `json:"t"` // occurred_at, unix milliseconds
	Type string `json:"k"`
	Ref  string `json:"r,omitempty"`
}

func compareKeys(a, b timelineKey) int {
	switch {
	case a.At != b.At:
		if a.At > b.At {
			return -1
		}
		return 1
	case a.Type != b.Type:
		return strings.Compare(a.Type, b.Type)
	}
	ra, ea := strconv.ParseInt(a.Ref, 10, 64)
	rb, eb := strconv.ParseInt(b.Ref, 10, 64)
	if ea == nil && eb == nil {
		switch {
		case ra > rb:
			return -1
		case ra < rb:
			return 1
		}
		return 0
	}
	return -strings.Compare(a.Ref, b.Ref)
}

func encodeCursor(k timelineKey) *string {
	raw, _ := json.Marshal(k)
	s := base64.RawURLEncoding.EncodeToString(raw)
	return &s
}

func decodeCursor(s string) (*timelineKey, error) {
	if s == "" {
		return nil, nil
	}
	raw, err := base64.RawURLEncoding.DecodeString(s)
	if err != nil {
		return nil, common.ErrInvalidCursor
	}
	var k timelineKey
	if err := json.Unmarshal(raw, &k); err != nil || titles[k.Type] == "" {
		return nil, common.ErrInvalidCursor
	}
	return &k, nil
}
