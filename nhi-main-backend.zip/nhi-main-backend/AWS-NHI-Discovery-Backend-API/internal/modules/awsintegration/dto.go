package awsintegration

import "time"

// ─────────────────────────────────────────────────────────────────────────
// AWS account connection ("Integrations" page)
//
//   GET    /api/v1/integrations/aws                                setup values + accounts
//   POST   /api/v1/integrations/aws/verify                         run the checks, save the account
//   PUT    /api/v1/integrations/aws/accounts/{account_id}/regions  change the regions read
//   POST   /api/v1/integrations/aws/accounts/{account_id}/sync     queue a sync
//   DELETE /api/v1/integrations/aws/accounts/{account_id}          remove the account
//
// Backing tables (global database, migrations/global/002_tenant_aws_integration.sql):
// tenants (domain, aws_account_id, external_id, event_bus_arn) and
// tenant_aws_accounts. Connected accounts are also registered, one row per
// region, in the tenant schema's accounts table - the list every
// other screen scopes by.
// ─────────────────────────────────────────────────────────────────────────

// Connection status of a tenant, and of one AWS account.
const (
	AWSStatusNotConnected = "not_connected" // tenant only: no account has passed AssumeRole yet
	AWSStatusActionNeeded = "action_needed" // role assumed, but a later check failed
	AWSStatusConnected    = "connected"     // all three checks passed
)

// State of one check.
const (
	AWSCheckPass    = "pass"
	AWSCheckFail    = "fail"    // the customer's setup needs a change; Fix says which
	AWSCheckSkipped = "skipped" // not run because an earlier check failed
	AWSCheckError   = "error"   // could not be run (our side); try again
)

// Check keys, in the order they run.
const (
	AWSCheckAssumeRole = "assume_role"
	AWSCheckReadAccess = "read_access"
	AWSCheckEvents     = "events"
)

// Sync state of one account. The API sets queued; the discovery worker moves
// it to running and then succeeded or failed.
const (
	AWSSyncIdle      = "idle"
	AWSSyncQueued    = "queued"
	AWSSyncRunning   = "running"
	AWSSyncSucceeded = "succeeded"
	AWSSyncFailed    = "failed"
)

type AWSIntegrationResponse struct {
	// Status is the tenant's overall state: connected when any account is.
	Status string `json:"status"`
	// CanManage is true for roles allowed to connect accounts (admin). Setup
	// is null for everyone else.
	CanManage bool                  `json:"can_manage"`
	Workspace AWSWorkspace          `json:"workspace"`
	Setup     *AWSSetupValues       `json:"setup"`
	Accounts  []AWSConnectedAccount `json:"accounts"`
}

type AWSWorkspace struct {
	Domain string `json:"domain"`
}

// AWSSetupValues is everything the customer copies into the AWS console, and
// the regions they may choose from.
type AWSSetupValues struct {
	AccountID       string      `json:"account_id"`
	ExternalID      string      `json:"external_id"`
	EventBusARN     string      `json:"event_bus_arn"`
	Region          string      `json:"region"`
	AssumerRoleARN  string      `json:"assumer_role_arn"`
	RoleName        string      `json:"role_name"`
	RuleName        string      `json:"rule_name"`
	ManagedPolicies []string    `json:"managed_policies"`
	EventSources    []string    `json:"event_sources"`
	Regions         []AWSRegion `json:"regions"`
}

type AWSRegion struct {
	Code  string `json:"code"`
	Name  string `json:"name"`
	Group string `json:"group"`
	OptIn bool   `json:"opt_in"`
}

type AWSConnectedAccount struct {
	AccountID      string     `json:"account_id"`
	RoleARN        string     `json:"role_arn"`
	Regions        []string   `json:"regions"`
	Status         string     `json:"status"`
	Checks         []AWSCheck `json:"checks"`
	LastVerifiedAt time.Time  `json:"last_verified_at"`
	LastVerifiedBy string     `json:"last_verified_by"`
	ConnectedAt    *time.Time `json:"connected_at"`
	Sync           AWSSync    `json:"sync"`
}

type AWSSync struct {
	Status      string     `json:"status"`
	RequestedAt *time.Time `json:"requested_at"`
	RequestedBy string     `json:"requested_by"`
	StartedAt   *time.Time `json:"started_at"`
	LastSyncAt  *time.Time `json:"last_synced_at"`
	LastError   string     `json:"last_error,omitempty"`
}

type AWSCheck struct {
	Key     string `json:"key"`
	Label   string `json:"label"`
	State   string `json:"state"`
	Message string `json:"message"`
	// Fix is the one change that makes a failed check pass. Empty unless
	// State is "fail".
	Fix string `json:"fix,omitempty"`
}

type AWSVerifyRequest struct {
	RoleARN string   `json:"role_arn"`
	Regions []string `json:"regions"`
}

type AWSRegionsRequest struct {
	Regions []string `json:"regions"`
}

type AWSVerifyResponse struct {
	Status     string     `json:"status"` // connected | action_needed
	AccountID  string     `json:"account_id"`
	RoleARN    string     `json:"role_arn"`
	Regions    []string   `json:"regions"`
	Checks     []AWSCheck `json:"checks"`
	VerifiedAt time.Time  `json:"verified_at"`
	// Saved is false when the role could not be assumed: nothing about an
	// account is stored until the tenant has proved it controls it.
	Saved bool `json:"saved"`
	// SyncQueued is true when this verification connected the account for
	// the first time and its first sync was queued.
	SyncQueued bool `json:"sync_queued"`
}

type AWSSyncResponse struct {
	Account AWSConnectedAccount `json:"account"`
	// AlreadyQueued: a sync was already queued or running; nothing changed.
	AlreadyQueued bool `json:"already_queued"`
}

// AWSTenantSettings is the tenant's row in nhi_global.tenants, as the
// integration reads it.
type AWSTenantSettings struct {
	Domain       string
	AWSAccountID string
	ExternalID   string
	EventBusARN  string
}

// AWSAccountRecord is one row of nhi_global.tenant_aws_accounts.
type AWSAccountRecord struct {
	TenantID        string
	AccountID       string
	RoleARN         string
	Regions         []string
	ExternalID      string
	Status          string
	Checks          []AWSCheck
	LastVerifiedAt  time.Time
	LastVerifiedBy  string
	ConnectedAt     *time.Time
	SyncStatus      string
	SyncRequestedAt *time.Time
	SyncRequestedBy string
	SyncStartedAt   *time.Time
	LastSyncedAt    *time.Time
	LastSyncError   string
}

// ToAPI is the account as the API returns it.
func (r AWSAccountRecord) ToAPI() AWSConnectedAccount {
	regions := r.Regions
	if regions == nil {
		regions = []string{}
	}
	checks := r.Checks
	if checks == nil {
		checks = []AWSCheck{}
	}
	return AWSConnectedAccount{
		AccountID:      r.AccountID,
		RoleARN:        r.RoleARN,
		Regions:        regions,
		Status:         r.Status,
		Checks:         checks,
		LastVerifiedAt: r.LastVerifiedAt,
		LastVerifiedBy: r.LastVerifiedBy,
		ConnectedAt:    r.ConnectedAt,
		Sync: AWSSync{
			Status:      r.SyncStatus,
			RequestedAt: r.SyncRequestedAt,
			RequestedBy: r.SyncRequestedBy,
			StartedAt:   r.SyncStartedAt,
			LastSyncAt:  r.LastSyncedAt,
			LastError:   r.LastSyncError,
		},
	}
}
