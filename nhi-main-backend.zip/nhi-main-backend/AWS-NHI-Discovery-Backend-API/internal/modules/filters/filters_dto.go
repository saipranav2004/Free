package filters

import "nhi-backend-api/internal/identitygraph"

type FilterResponse struct {
	Accounts          []AccountFilter                        `json:"accounts"`
	Regions           []identitygraph.RegionFilter           `json:"regions"`
	IdentityTypes     []identitygraph.TypeCountFilter        `json:"identity_types"`
	FunctionalClasses []identitygraph.ClassCountFilter       `json:"functional_classes"`
	CredentialTypes   []identitygraph.TypeCountFilter        `json:"credential_types"`
	Environments      []identitygraph.EnvironmentCountFilter `json:"environments"`
	Statuses          []identitygraph.StatusCountFilter      `json:"statuses"`
}

type AccountFilter struct {
	AccountID       string `json:"account_id"`
	IdentityCount   int    `json:"identity_count"`
	CredentialCount int    `json:"credential_count"`
	IsDefault       bool   `json:"is_default"`
}
