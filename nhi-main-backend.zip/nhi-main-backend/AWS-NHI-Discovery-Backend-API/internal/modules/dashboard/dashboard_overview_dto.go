package dashboard

import "nhi-backend-api/internal/identitygraph"

import "time"

// ─────────────────────────────────────────────────────────────────────────
// GET /api/v1/dashboard/overview ("ENDPOINT 3: Dashboard Overview")
// No query params — all KPIs + all charts in one response.
// ─────────────────────────────────────────────────────────────────────────

type DashboardOverviewResponse struct {
	KPIs   DashboardKPIs   `json:"kpis"`
	Charts DashboardCharts `json:"charts"`
	// ActivityDataAvailable is false when CloudTrail data could not be read;
	// stale counts then fall back to creation dates only.
	ActivityDataAvailable bool `json:"activity_data_available"`
	// RecentChanges is always present (empty when the tenant has no scan or
	// no scan_changes table yet) and is appended last so existing clients see
	// the same keys in the same order as before.
	RecentChanges RecentChanges `json:"recent_changes"`
}

// RecentChanges is the change-tracking block of the overview: the total for
// the latest finished scan plus the five largest (change_type, entity_type)
// groups. Highlights is always [] (never null), and the scan pointers are null
// when there is no finished scan yet.
type RecentChanges struct {
	LastScanID     *string                 `json:"last_scan_id"`
	PreviousScanID *string                 `json:"previous_scan_id"`
	LastScanTime   *time.Time              `json:"last_scan_time"`
	TotalChanges   int                     `json:"total_changes"`
	Highlights     []RecentChangeHighlight `json:"highlights"`
}

// RecentChangeHighlight is one top-N group with a human-readable label.
type RecentChangeHighlight struct {
	ChangeType string `json:"change_type"`
	EntityType string `json:"entity_type"`
	Count      int    `json:"count"`
	Label      string `json:"label"`
}

type DashboardKPIs struct {
	TotalIdentities          int     `json:"total_identities"`
	TotalCredentials         int     `json:"total_credentials"`
	OrphanedCredentials      int     `json:"orphaned_credentials"`
	StaleIdentities          int     `json:"stale_identities"`
	StaleCredentials         int     `json:"stale_credentials"`
	PubliclyAccessible       int     `json:"publicly_accessible"`
	ShadowIdentities         int     `json:"shadow_identities"`
	AccountsScanned          int     `json:"accounts_scanned"`
	PermissionUtilizationPct float64 `json:"permission_utilization_pct"`
}

type DashboardCharts struct {
	IdentitiesByType            []identitygraph.TypeCountFilter        `json:"identities_by_type"`
	IdentitiesByFunctionalClass []identitygraph.ClassCountFilter       `json:"identities_by_functional_class"`
	IdentitiesByAccount         []AccountCountItem                     `json:"identities_by_account"`
	IdentitiesByRegion          []identitygraph.RegionFilter           `json:"identities_by_region"`
	IdentitiesByEnvironment     []identitygraph.EnvironmentCountFilter `json:"identities_by_environment"`
	IdentitiesByStatus          []identitygraph.StatusCountFilter      `json:"identities_by_status"`
	IdentityGrowth              []GrowthPoint                          `json:"identity_growth"`
	CredentialGrowth            []GrowthPoint                          `json:"credential_growth"`
	StaleVsActive               StaleVsActive                          `json:"stale_vs_active"`
	CredentialTypes             []identitygraph.TypeCountFilter        `json:"credential_types"`
	TopOwners                   []OwnerCountItem                       `json:"top_owners"`
	CredentialsExpiringSoon     []ExpiringCredentialItem               `json:"credentials_expiring_soon"`
}

type AccountCountItem struct {
	AccountID string `json:"account_id"`
	Count     int    `json:"count"`
}

type GrowthPoint struct {
	Date  string `json:"date"`
	Count int    `json:"count"`
}

type StaleVsActive struct {
	Active int `json:"active"`
	Stale  int `json:"stale"`
}

type OwnerCountItem struct {
	Owner string `json:"owner"`
	Count int    `json:"count"`
}

type ExpiringCredentialItem struct {
	CredentialName string    `json:"credential_name"`
	ExpiresAt      time.Time `json:"expires_at"`
	DaysRemaining  int       `json:"days_remaining"`
}
