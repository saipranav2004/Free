package dashboard

import (
	"net/http"
	"strconv"
	"strings"

	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/logging"
	"nhi-backend-api/internal/platform/middleware"
)

const (
	trendsDefaultLimit = 20
	trendsMaxLimit     = 100
)

var trendsAllowedQuery = map[string]struct{}{
	"account_ids": {},
	"regions":     {},
	"limit":       {},
}

type DashboardTrendsHandler struct {
	service *DashboardTrendsService
}

func NewDashboardTrendsHandler(service *DashboardTrendsService) *DashboardTrendsHandler {
	return &DashboardTrendsHandler{service: service}
}

// Get handles GET /api/v1/dashboard/trends.
func (h *DashboardTrendsHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{Success: false, Message: "Unauthorized"})
		return
	}

	if httpx.RejectUnknownQuery(w, r, trendsAllowedQuery) {
		return
	}

	q := r.URL.Query()
	limit, ok := parseTrendsLimit(q.Get("limit"))
	if !ok {
		httpx.WriteError(w, http.StatusBadRequest, "limit must be an integer between 1 and 100", "INVALID_QUERY_PARAM")
		return
	}

	result, err := h.service.GetTrends(r.Context(), claims.UserID, claims.TenantID, claims.DBName,
		splitCSV(q.Get("account_ids")), splitCSV(q.Get("regions")), limit)
	if err != nil {
		logging.FromContext(r.Context()).Error("dashboard trends failed", "err", err)
		httpx.WriteJSON(w, http.StatusInternalServerError, httpx.APIResponse{
			Success: false,
			Message: "Failed to retrieve dashboard trends",
			Error:   "DASHBOARD_TRENDS_FAILED",
		})
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Dashboard trends retrieved successfully",
		Data:    result,
	})
}

func parseTrendsLimit(raw string) (int, bool) {
	if raw == "" {
		return trendsDefaultLimit, true
	}
	n, err := strconv.Atoi(raw)
	if err != nil || n < 1 || n > trendsMaxLimit {
		return 0, false
	}
	return n, true
}

// splitCSV splits a comma-separated value, trimming blanks and duplicates.
func splitCSV(raw string) []string {
	var out []string
	seen := map[string]struct{}{}
	for _, p := range strings.Split(raw, ",") {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		if _, dup := seen[p]; dup {
			continue
		}
		seen[p] = struct{}{}
		out = append(out, p)
	}
	return out
}
