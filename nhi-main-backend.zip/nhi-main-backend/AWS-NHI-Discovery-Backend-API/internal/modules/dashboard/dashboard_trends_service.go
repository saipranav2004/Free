package dashboard

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/platform/scope"
)

type DashboardTrendsService struct {
	repo     *DashboardTrendsRepository
	resolver *scope.Resolver
}

func NewDashboardTrendsService(repo *DashboardTrendsRepository, resolver *scope.Resolver) *DashboardTrendsService {
	return &DashboardTrendsService{repo: repo, resolver: resolver}
}

// GetTrends resolves the caller's scope, narrows it to the requested
// accounts/regions (never widening it) and loads the trend points.
func (s *DashboardTrendsService) GetTrends(ctx context.Context, userID, tenantID, dbName string, accountIDs, regions []string, limit int) (*DashboardTrendsResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	accounts := narrowScope(resolved.AccountIDs, accountIDs)
	regs := narrowScope(resolved.Regions, regions)
	if len(accounts) == 0 || len(regs) == 0 {
		return &DashboardTrendsResponse{Trends: []TrendPoint{}}, nil
	}
	points, err := s.repo.GetTrends(ctx, resolved, accounts, regs, limit)
	if err != nil {
		return nil, fmt.Errorf("get dashboard trends: %w", err)
	}
	return &DashboardTrendsResponse{Trends: points}, nil
}

// narrowScope intersects the requested values with the allowed ones. An empty
// request keeps the full allowed set.
func narrowScope(allowed, requested []string) []string {
	if len(requested) == 0 {
		return allowed
	}
	ok := make(map[string]struct{}, len(allowed))
	for _, a := range allowed {
		ok[a] = struct{}{}
	}
	out := make([]string, 0, len(requested))
	for _, v := range requested {
		if _, found := ok[v]; found {
			out = append(out, v)
		}
	}
	return out
}
