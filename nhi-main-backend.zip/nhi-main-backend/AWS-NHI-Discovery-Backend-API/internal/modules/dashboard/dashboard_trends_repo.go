package dashboard

import (
	"context"
	"fmt"

	"github.com/lib/pq"

	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/scope"
)

// DashboardTrendsRepository reads per-scan totals from nhi_scans_aws.
type DashboardTrendsRepository struct{}

func NewDashboardTrendsRepository() *DashboardTrendsRepository {
	return &DashboardTrendsRepository{}
}

// GetTrends sums scan totals per hour across the given accounts and regions
// and returns the most recent limit buckets in ascending date order.
func (r *DashboardTrendsRepository) GetTrends(ctx context.Context, sc *scope.DataScope, accountIDs, regions []string, limit int) ([]TrendPoint, error) {
	q := fmt.Sprintf(`
SELECT scan_date, total_identities, total_credentials FROM (
  SELECT date_trunc('hour', s.scan_end)        AS scan_date,
         COALESCE(SUM(s.total_identities), 0)  AS total_identities,
         COALESCE(SUM(s.total_credentials), 0) AS total_credentials
  FROM %s s
  WHERE upper(s.status) IN ('COMPLETED','PARTIAL')
    AND s.scan_end IS NOT NULL
    AND s.account_id = ANY($1::text[])
    AND s.regions && $2::text[]
  GROUP BY 1
  ORDER BY 1 DESC
  LIMIT $3
) t
ORDER BY scan_date ASC`, sc.Table("nhi_scans_aws"))

	rows, err := sc.DB.QueryContext(ctx, q, pq.Array(accountIDs), pq.Array(regions), limit)
	if err != nil {
		if database.IsUndefinedTable(err) {
			return []TrendPoint{}, nil
		}
		return nil, fmt.Errorf("query scan trends: %w", err)
	}
	defer rows.Close()

	points := []TrendPoint{}
	for rows.Next() {
		var p TrendPoint
		if err := rows.Scan(&p.ScanDate, &p.TotalIdentities, &p.TotalCredentials); err != nil {
			return nil, fmt.Errorf("scan trend row: %w", err)
		}
		points = append(points, p)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate trend rows: %w", err)
	}
	return points, nil
}
