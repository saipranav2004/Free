package dashboard

import (
	"context"
	"database/sql"
	"fmt"
	"sort"
	"strings"
	"time"

	scanmeta "nhi-backend-api/internal/identitygraph/scanchanges"
	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/scope"
)

// recentChangesTopN is how many (change_type, entity_type) groups the
// highlights list carries; total_changes always counts every group of the
// scan, not just these.
const recentChangesTopN = 5

// emptyRecentChanges is the block served when there is nothing to report: no
// finished scan, no scan_changes table for this tenant, or a failed read (the
// caller substitutes it so the overview still returns 200).
func emptyRecentChanges() RecentChanges {
	return RecentChanges{Highlights: []RecentChangeHighlight{}}
}

// recentCount is one (change_type, entity_type) group of the latest scan.
type recentCount struct {
	ChangeType string
	EntityType string
	Count      int
}

// loadRecentChanges reads the latest finished scan's changes. Errors are the
// caller's to log and degrade: this loader must never fail the overview.
func (r *DashboardOverviewRepository) loadRecentChanges(ctx context.Context, resolved *scope.DataScope) (RecentChanges, error) {
	meta, found, err := scanmeta.LatestCompletedScan(ctx, resolved)
	if err != nil {
		return emptyRecentChanges(), err
	}
	if !found {
		return emptyRecentChanges(), nil
	}

	query := fmt.Sprintf(`
		SELECT change_type, entity_type, count(*)::int,
		       NULLIF(max(previous_scan_id), '')
		FROM %s
		WHERE scan_id = $1
		GROUP BY change_type, entity_type`, resolved.Table("scan_changes"))

	rows, err := resolved.DB.QueryContext(ctx, query, meta.ScanID)
	if err != nil {
		if database.IsUndefinedTable(err) {
			// The scan exists but this tenant has no scan_changes yet: report
			// the scan, zero changes.
			return recentChangesBlock(meta.ScanID, nil, meta.ScannedAt, nil), nil
		}
		return emptyRecentChanges(), err
	}
	defer rows.Close()

	var (
		counts []recentCount
		prev   *string
	)
	for rows.Next() {
		var (
			c recentCount
			p sql.NullString
		)
		if err := rows.Scan(&c.ChangeType, &c.EntityType, &c.Count, &p); err != nil {
			return emptyRecentChanges(), fmt.Errorf("scan recent change count: %w", err)
		}
		if prev == nil && p.Valid {
			v := p.String
			prev = &v
		}
		counts = append(counts, c)
	}
	if err := rows.Err(); err != nil {
		return emptyRecentChanges(), err
	}
	return recentChangesBlock(meta.ScanID, prev, meta.ScannedAt, counts), nil
}

// recentChangesBlock is a pure function over one scan's group counts, so the
// totals, ordering and labels are unit-testable without a database. Counts are
// normalised (change_type upper-case, entity_type lower-case) before sorting so
// the top-5 and its tie-breaks are deterministic.
func recentChangesBlock(scanID string, previousScanID *string, scannedAt *time.Time, counts []recentCount) RecentChanges {
	out := RecentChanges{
		Highlights:     []RecentChangeHighlight{},
		LastScanID:     &scanID,
		PreviousScanID: previousScanID,
		LastScanTime:   scannedAt,
	}

	norm := make([]recentCount, 0, len(counts))
	for _, c := range counts {
		ct := strings.ToUpper(strings.TrimSpace(c.ChangeType))
		et := strings.ToLower(strings.TrimSpace(c.EntityType))
		norm = append(norm, recentCount{ChangeType: ct, EntityType: et, Count: c.Count})
		out.TotalChanges += c.Count
	}

	sort.Slice(norm, func(i, j int) bool {
		if norm[i].Count != norm[j].Count {
			return norm[i].Count > norm[j].Count
		}
		if norm[i].ChangeType != norm[j].ChangeType {
			return norm[i].ChangeType < norm[j].ChangeType
		}
		return norm[i].EntityType < norm[j].EntityType
	})
	if len(norm) > recentChangesTopN {
		norm = norm[:recentChangesTopN]
	}

	for _, c := range norm {
		out.Highlights = append(out.Highlights, RecentChangeHighlight{
			ChangeType: c.ChangeType,
			EntityType: c.EntityType,
			Count:      c.Count,
			Label:      recentChangeLabel(c.ChangeType, c.EntityType, c.Count),
		})
	}
	return out
}

// recentChangeNouns maps entity_type to its singular/plural display noun.
// TODO(frontend): confirm the wording of the 15 change/entity combos — the
// spec specified only three examples (CREATED/identity, DELETED/credential,
// MODIFIED/permission); the rest follow the same patterns.
var recentChangeNouns = map[string][2]string{
	"identity":   {"identity", "identities"},
	"credential": {"credential", "credentials"},
	"permission": {"permission", "permissions"},
	"binding":    {"binding", "bindings"},
	"trust_edge": {"trust edge", "trust edges"},
}

// recentChangeLabel builds the human-readable highlight text:
//
//	5 new identities discovered   (CREATED, plural)
//	1 new identity discovered     (CREATED, singular)
//	3 credentials removed         (DELETED, plural)
//	6 permission changes detected (MODIFIED, plural)
//
// Unknown change/entity types fall back to the MODIFIED pattern with a
// derived noun, so a new scanner vocabulary never renders an empty label.
func recentChangeLabel(changeType, entityType string, n int) string {
	singular, plural := "", ""
	if pair, ok := recentChangeNouns[entityType]; ok {
		singular, plural = pair[0], pair[1]
	} else {
		singular = strings.ReplaceAll(entityType, "_", " ")
		plural = singular + "s"
	}
	noun := plural
	if n == 1 {
		noun = singular
	}
	switch changeType {
	case "CREATED":
		return fmt.Sprintf("%d new %s discovered", n, noun)
	case "DELETED":
		return fmt.Sprintf("%d %s removed", n, noun)
	default: // MODIFIED and anything unknown
		// "6 permission changes detected": the noun stays singular, the count
		// word carries the plural.
		if n == 1 {
			return fmt.Sprintf("%d %s change detected", n, singular)
		}
		return fmt.Sprintf("%d %s changes detected", n, singular)
	}
}
