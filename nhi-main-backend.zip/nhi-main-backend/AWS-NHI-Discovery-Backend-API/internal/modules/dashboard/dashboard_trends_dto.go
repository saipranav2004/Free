package dashboard

import "time"

// TrendPoint is one aggregated scan cycle on the dashboard trend chart.
type TrendPoint struct {
	ScanDate         time.Time `json:"scan_date"`
	TotalIdentities  int64     `json:"total_identities"`
	TotalCredentials int64     `json:"total_credentials"`
}

// DashboardTrendsResponse is the data payload of GET /api/v1/dashboard/trends.
type DashboardTrendsResponse struct {
	Trends []TrendPoint `json:"trends"`
}
