package dashboard

import (
	"reflect"
	"testing"
)

func TestParseTrendsLimit(t *testing.T) {
	cases := []struct {
		in   string
		want int
		ok   bool
	}{
		{"", 20, true}, {"5", 5, true}, {"100", 100, true},
		{"0", 0, false}, {"101", 0, false}, {"-1", 0, false}, {"abc", 0, false},
	}
	for _, c := range cases {
		got, ok := parseTrendsLimit(c.in)
		if got != c.want || ok != c.ok {
			t.Errorf("parseTrendsLimit(%q) = %d,%v want %d,%v", c.in, got, ok, c.want, c.ok)
		}
	}
}

func TestSplitCSV(t *testing.T) {
	got := splitCSV(" a, b ,,a,c")
	if want := []string{"a", "b", "c"}; !reflect.DeepEqual(got, want) {
		t.Errorf("got %v want %v", got, want)
	}
	if got := splitCSV(""); len(got) != 0 {
		t.Errorf("expected empty, got %v", got)
	}
}

func TestNarrowScope(t *testing.T) {
	allowed := []string{"a1", "a2"}
	cases := []struct {
		name      string
		requested []string
		want      []string
	}{
		{"none requested keeps allowed", nil, allowed},
		{"subset", []string{"a2"}, []string{"a2"}},
		{"foreign dropped", []string{"a1", "zz"}, []string{"a1"}},
		{"all foreign", []string{"zz"}, []string{}},
	}
	for _, c := range cases {
		if got := narrowScope(allowed, c.requested); !reflect.DeepEqual(got, c.want) {
			t.Errorf("%s: got %v want %v", c.name, got, c.want)
		}
	}
}
