package common

import "testing"

func TestCursorRoundTrip(t *testing.T) {
	type cur struct {
		S  string `json:"s"`
		ID string `json:"id"`
	}
	in := cur{S: "-score", ID: "abc"}
	var out cur
	if err := DecodeCursor(EncodeCursor(in), &out); err != nil || out != in {
		t.Fatalf("round trip failed: %v %+v", err, out)
	}
	if err := DecodeCursor("!!!not-base64", &out); err != ErrInvalidCursor {
		t.Errorf("want ErrInvalidCursor, got %v", err)
	}
	if err := DecodeCursor("bm90LWpzb24", &out); err != ErrInvalidCursor {
		t.Errorf("want ErrInvalidCursor for non-JSON, got %v", err)
	}
}

func TestClampLimit(t *testing.T) {
	for in, want := range map[int]int{0: 50, -3: 50, 1: 1, 100: 100, 500: 100} {
		if got := ClampLimit(in); got != want {
			t.Errorf("clampLimit(%d)=%d want %d", in, got, want)
		}
	}
}

func TestEscapeLike(t *testing.T) {
	if got := EscapeLike(`50%_a\b`); got != `50\%\_a\\b` {
		t.Errorf("got %q", got)
	}
}
