package auth

import (
	"encoding/json"
	"net/http"

	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/logging"
	"nhi-backend-api/internal/platform/middleware"
)

type AuthHandler struct {
	authService *AuthService
}

func NewAuthHandler(authService *AuthService) *AuthHandler {
	return &AuthHandler{authService: authService}
}

// Login handles POST /api/v1/login
func (h *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	if rejectUnknownQuery(w, r, httpx.NoQuery) {
		return
	}

	// Prevent large payloads / slowloris
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20) // 1MB
	defer r.Body.Close()

	var req LoginRequest
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(&req); err != nil {
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
			Success: false,
			Message: "Invalid request payload",
			Error:   err.Error(),
		})
		return
	}

	if req.Email == "" || req.Password == "" {
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
			Success: false,
			Message: "Email and password are required",
		})
		return
	}

	resp, err := h.authService.Login(r.Context(), req)
	if err != nil {
		logging.FromContext(r.Context()).Warn("login failed", "err", err)
		logging.Audit(r.Context(), "login", req.Email, "", "", "failure")
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{
			Success: false,
			Message: "Invalid email or password",
			Error:   "AUTHENTICATION_FAILED",
		})
		return
	}

	logging.Audit(r.Context(), "login", req.Email, "", "", "success")
	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Login successful",
		Data:    resp,
	})
}

// decodeRefreshRequest reads and validates the {"refresh_token"} body.
func decodeRefreshRequest(w http.ResponseWriter, r *http.Request) (string, bool) {
	if rejectUnknownQuery(w, r, httpx.NoQuery) {
		return "", false
	}
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	defer r.Body.Close()

	var req RefreshRequest
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(&req); err != nil || req.RefreshToken == "" {
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
			Success: false,
			Message: "refresh_token is required",
		})
		return "", false
	}
	return req.RefreshToken, true
}

// Refresh handles POST /api/v1/refresh
func (h *AuthHandler) Refresh(w http.ResponseWriter, r *http.Request) {
	token, ok := decodeRefreshRequest(w, r)
	if !ok {
		return
	}
	resp, err := h.authService.Refresh(r.Context(), token)
	if err != nil {
		logging.FromContext(r.Context()).Warn("refresh failed", "err", err)
		logging.Audit(r.Context(), "refresh", "", "", "", "failure")
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{
			Success: false,
			Message: "Invalid or expired refresh token",
			Error:   "AUTHENTICATION_FAILED",
		})
		return
	}
	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Token refreshed",
		Data:    resp,
	})
}

// Logout handles POST /api/v1/logout
func (h *AuthHandler) Logout(w http.ResponseWriter, r *http.Request) {
	token, ok := decodeRefreshRequest(w, r)
	if !ok {
		return
	}
	if err := h.authService.Logout(r.Context(), token); err != nil {
		logging.FromContext(r.Context()).Error("logout failed", "err", err)
		httpx.WriteJSON(w, http.StatusInternalServerError, httpx.APIResponse{
			Success: false,
			Message: "Logout failed",
		})
		return
	}
	logging.Audit(r.Context(), "logout", "", "", "", "success")
	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{Success: true, Message: "Logged out"})
}

// Me handles GET /api/v1/me
func (h *AuthHandler) Me(w http.ResponseWriter, r *http.Request) {
	if rejectUnknownQuery(w, r, httpx.NoQuery) {
		return
	}

	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{
			Success: false,
			Message: "Unauthorized",
		})
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "User profile retrieved",
		Data: map[string]interface{}{
			"user_id":   claims.UserID,
			"tenant_id": claims.TenantID,
			"db_name":   claims.DBName,
			"role":      claims.Role,
		},
	})
}
