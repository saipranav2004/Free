package auth

import (
	"fmt"
	"net/http"

	"nhi-backend-api/internal/platform/httpx"
)

func rejectUnknownQuery(w http.ResponseWriter, r *http.Request, allowed map[string]struct{}) bool {
	if unknown, ok := httpx.CheckUnknown(r.URL.Query(), allowed); ok {
		msg := "(none)"
		if len(allowed) > 0 {
			// not used for auth endpoints, but keep generic
			msg = "no query parameters allowed"
		}
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
			Success: false,
			Message: fmt.Sprintf("Unknown query parameter: %s. %s", unknown, msg),
			Error:   "INVALID_QUERY_PARAM",
		})
		return true
	}
	return false
}
