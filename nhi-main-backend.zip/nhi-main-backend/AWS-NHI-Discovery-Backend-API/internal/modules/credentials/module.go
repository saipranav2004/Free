// Package credentials serves the credential inventory API: the filtered
// credential list and the per-credential detail tabs (overview, trust,
// activity, rotation, relationships, raw, changes).
//
// The shared graph, activity and detail queries live in internal/identitygraph.
package credentials

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handlers and registers their routes.
type Module struct {
	list   *CredentialsHandler
	detail *CredentialDetailHandler
}

// New builds the module.
func New(resolver *scope.Resolver, activity *identitygraph.ActivityService) *Module {
	return &Module{
		list:   NewCredentialsHandler(NewCredentialsService(NewCredentialsRepository(), resolver, activity)),
		detail: NewCredentialDetailHandler(NewCredentialDetailService(identitygraph.NewCredentialDetailRepository(), resolver, activity)),
	}
}

// Register mounts the credential routes on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/credentials", m.list.List).Methods(http.MethodGet)
	r.HandleFunc("/credentials/{id}", m.detail.Get).Methods(http.MethodGet)
}
