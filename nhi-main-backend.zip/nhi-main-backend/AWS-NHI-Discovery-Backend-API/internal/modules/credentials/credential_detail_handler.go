package credentials

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/logging"
	"nhi-backend-api/internal/platform/middleware"
)

type CredentialDetailHandler struct {
	service *CredentialDetailService
}

func NewCredentialDetailHandler(service *CredentialDetailService) *CredentialDetailHandler {
	return &CredentialDetailHandler{service: service}
}

// Get handles GET /api/v1/credentials/{id}?tab=&time_range=&depth=&edge_type=
// ("ENDPOINT 7: Credential Detail").
func (h *CredentialDetailHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{Success: false, Message: "Unauthorized"})
		return
	}

	id := strings.TrimSpace(mux.Vars(r)["id"])
	if id == "" {
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{Success: false, Message: "credential id is required"})
		return
	}
	// Validate UUID format before it reaches "id = $1::uuid" in Postgres —
	// otherwise a malformed id throws a raw "invalid input syntax for type
	// uuid" (SQLSTATE 22P02) error that must never reach the client.
	if !httpx.UUIDRegex.MatchString(id) {
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{Success: false, Message: "Invalid credential ID"})
		return
	}

	if httpx.RejectUnknownQuery(w, r, credentialDetailAllowed) {
		return
	}

	q := r.URL.Query()

	tab := strings.ToLower(strings.TrimSpace(q.Get("tab")))
	if tab == "" {
		tab = "overview"
	}
	if ok, _ := httpx.ValidateSingleEnum(tab, validCredentialTabs); !ok {
		httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
			Success: false,
			Message: "Invalid tab: " + tab + ". Allowed: " + httpx.AllowedList(validCredentialTabs),
			Error:   "INVALID_TAB",
		})
		return
	}

	timeRange := strings.TrimSpace(q.Get("time_range"))
	if timeRange == "" {
		timeRange = "90d"
	}

	depth := 1
	if raw := q.Get("depth"); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 1 || v > identitygraph.MaxRelationshipDepth {
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
				Success: false,
				Message: fmt.Sprintf("depth must be an integer between 1 and %d", identitygraph.MaxRelationshipDepth)})
			return
		}
		depth = v
	}

	if et := strings.TrimSpace(q.Get("edge_type")); et != "" {
		if ok, _ := httpx.ValidateSingleEnum(et, identitygraph.ValidEdgeTypes); !ok {
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
				Success: false,
				Message: "Invalid edge_type: " + et + ". Allowed: " + httpx.AllowedList(identitygraph.ValidEdgeTypes),
				Error:   "INVALID_EDGE_TYPE",
			})
			return
		}
	}

	if sd := strings.TrimSpace(q.Get("start_date")); sd != "" {
		if !httpx.IsValidDate(sd) {
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{Success: false, Message: "Invalid start_date format. Use YYYY-MM-DD or RFC3339", Error: "INVALID_DATE"})
			return
		}
	}
	if ed := strings.TrimSpace(q.Get("end_date")); ed != "" {
		if !httpx.IsValidDate(ed) {
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{Success: false, Message: "Invalid end_date format. Use YYYY-MM-DD or RFC3339", Error: "INVALID_DATE"})
			return
		}
	}
	if strings.EqualFold(timeRange, "custom") {
		if strings.TrimSpace(q.Get("start_date")) == "" || strings.TrimSpace(q.Get("end_date")) == "" {
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{Success: false, Message: "time_range=custom requires both start_date and end_date", Error: "INVALID_TIME_RANGE"})
			return
		}
	} else {
		if strings.TrimSpace(q.Get("start_date")) != "" || strings.TrimSpace(q.Get("end_date")) != "" {
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{Success: false, Message: "start_date and end_date are only allowed when time_range=custom", Error: "INVALID_TIME_RANGE"})
			return
		}
	}

	page, pageSize, ok := httpx.ParseActivityPaging(w, q)
	if !ok {
		return
	}

	filter := identitygraph.DetailFilter{
		CredentialID: id,
		Tab:          tab,
		TimeRange:    timeRange,
		StartDate:    strings.TrimSpace(q.Get("start_date")),
		EndDate:      strings.TrimSpace(q.Get("end_date")),
		Page:         page,
		PageSize:     pageSize,
		Depth:        depth,
		EdgeType:     strings.TrimSpace(q.Get("edge_type")),
	}

	result, err := h.service.GetDetail(r.Context(), claims.UserID, claims.TenantID, claims.DBName, filter)
	if err != nil {
		var timeRangeErr *identitygraph.TimeRangeError
		switch {
		case errors.As(err, &timeRangeErr):
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
				Success: false, Message: timeRangeErr.Msg, Error: "INVALID_TIME_RANGE"})
		case errors.Is(err, ErrInvalidTab):
			httpx.WriteJSON(w, http.StatusBadRequest, httpx.APIResponse{
				Success: false,
				Message: "Unsupported tab. Available tabs: overview, trust, activity, rotation, relationships, raw, changes.",
			})
		case errors.Is(err, identitygraph.ErrCredentialNotFound):
			httpx.WriteJSON(w, http.StatusNotFound, httpx.APIResponse{
				Success: false,
				Message: fmt.Sprintf("credential with id '%s' not found", id),
			})
		default:
			logging.FromContext(r.Context()).Error("credential detail failed", "err", err)
			httpx.WriteJSON(w, http.StatusInternalServerError, httpx.APIResponse{
				Success: false,
				Message: "Failed to retrieve credential detail",
				Error:   "CREDENTIAL_DETAIL_FAILED",
			})
		}
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Credential detail retrieved successfully",
		Data:    result,
	})
}
