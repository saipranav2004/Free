package credentialexposure

import (
	"fmt"
	"strings"
)

// findingList names the five lists a finding can be sorted into. Which list a
// finding belongs to is decided at read time from its score/tag columns; nothing
// is stored (scanner guide, section 8b). Every non-allowlisted finding is in
// exactly one list.
const (
	listMain      = "main"
	listRepeated  = "repeated"
	listNoise     = "noise"
	listReview    = "review"
	listMLFlagged = "ml_flagged"
)

var validLists = map[string]struct{}{
	listMain: {}, listRepeated: {}, listNoise: {}, listReview: {}, listMLFlagged: {},
}

// Live values of the scanner's settings. Keep in step with the scanner guide.
const (
	repeatMinLocations     = 3       // REPEAT_FILTER_MIN_LOCATIONS
	reviewBandLow          = 0.25    // REVIEW_BAND_LOW
	reviewDoubtMainBelow   = 0.40    // REVIEW_DOUBT_MAIN_BELOW
	reviewDoubtSecondBelow = 0.50    // REVIEW_DOUBT_SECOND_BELOW
	mlVetoThreshold        = 0.13305 // ML_VETO_THRESHOLD
	secondNetMainMin       = 0.95    // SECOND_NET_MAIN_MIN
	secondNetSecondMin     = 0.30    // SECOND_NET_SECOND_MIN
)

// noiseTags are the noise_flags values that move a finding to the noise list
// (NOISE_FILTER_TAGS).
var noiseTags = []string{
	"known_example_value", "expired_signed_url", "vector_image_file",
	"integrity_hash", "arn_identifier", "password_hash", "plain_url",
}

// genericPrefixes and genericSuffix identify generic (non-provider) detectors,
// the only ones the second ML model may veto.
var genericPrefixes = []string{
	"generic_", "high_entropy_string", "jwt", "basic_auth_header", "bearer_token",
	"authorization_header", "url_embedded", "curl_", "docker_login",
	"webhook_url_generic", "azure_sas_token",
}

const (
	genericSuffix        = "_connection_string"
	genericSuffixExclude = "azure_storage_"
)

// isGenericDetector mirrors genericSQL for Go callers and tests.
func isGenericDetector(detector string) bool {
	for _, p := range genericPrefixes {
		if strings.HasPrefix(detector, p) {
			return true
		}
	}
	return strings.HasSuffix(detector, genericSuffix) && !strings.HasPrefix(detector, genericSuffixExclude)
}

// hasNoiseTag reports whether a comma-separated noise_flags value carries a
// tag that sends the finding to the noise list.
func hasNoiseTag(flags string) bool {
	for _, tag := range strings.Split(flags, ",") {
		tag = strings.TrimSpace(tag)
		for _, n := range noiseTags {
			if tag == n {
				return true
			}
		}
	}
	return false
}

func sqlStrings(values []string) string {
	quoted := make([]string, len(values))
	for i, v := range values {
		quoted[i] = "'" + strings.ReplaceAll(v, "'", "''") + "'"
	}
	return strings.Join(quoted, ",")
}

// genericSQL is true for generic detectors. Inputs are the constants above.
func genericSQL() string {
	parts := make([]string, 0, len(genericPrefixes)+1)
	for _, p := range genericPrefixes {
		parts = append(parts, fmt.Sprintf("starts_with(detector,'%s')", p))
	}
	parts = append(parts, fmt.Sprintf("(right(detector,%d)='%s' AND NOT starts_with(detector,'%s'))",
		len(genericSuffix), genericSuffix, genericSuffixExclude))
	return "(" + strings.Join(parts, " OR ") + ")"
}

// listCaseSQL assigns each row its list, applying rules 2-5 in order. A NULL
// score or tag never hides a finding: a NULL comparison is not true, so the
// row falls through to the next rule and finally to main.
func listCaseSQL() string {
	generic := genericSQL()
	return fmt.Sprintf(`CASE
 WHEN value_fingerprint IS NOT NULL AND position('private_key' in lower(detector))=0
      AND COALESCE(rep_locations,0) >= %d THEN '%s'
 WHEN string_to_array(replace(COALESCE(noise_flags,''),' ',''),',') && ARRAY[%s]::text[] THEN '%s'
 WHEN (ml_decision='FALSE_POSITIVE' AND ml_score >= %g)
   OR (ml_decision='REAL_SECRET' AND (ml_score < %g OR (%s AND ml_veto_score < %g))) THEN '%s'
 WHEN ml_decision='FALSE_POSITIVE'
   OR (%s AND ml_veto_score < %g)
   OR (right(detector,6)='_broad' AND NOT COALESCE(ml_score >= %g AND ml_veto_score >= %g, false)) THEN '%s'
 ELSE '%s' END`,
		repeatMinLocations, listRepeated,
		sqlStrings(noiseTags), listNoise,
		reviewBandLow, reviewDoubtMainBelow, generic, reviewDoubtSecondBelow, listReview,
		generic, mlVetoThreshold, secondNetMainMin, secondNetSecondMin, listMLFlagged,
		listMain)
}

// classifiedFindings wraps the allowlist-filtered union with a list_name
// column. rep_locations counts the distinct (file, line) places one value
// fingerprint appears at within one commit of one repository.
func classifiedFindings(schema string) string {
	return `WITH u AS (` + findingsUnion(schema) + `)
SELECT ` + findingColumns + `, ` + listCaseSQL() + ` AS list_name FROM (
 SELECT u.*, r.n AS rep_locations FROM u
 LEFT JOIN (
  SELECT client_id, repository, commit_id, value_fingerprint, COUNT(*) AS n FROM (
   SELECT DISTINCT client_id, repository, commit_id, value_fingerprint, file_path, line_number
   FROM u WHERE value_fingerprint IS NOT NULL) d
  GROUP BY client_id, repository, commit_id, value_fingerprint) r
 ON r.client_id=u.client_id AND r.repository=u.repository AND r.commit_id=u.commit_id
    AND r.value_fingerprint=u.value_fingerprint
) w`
}
