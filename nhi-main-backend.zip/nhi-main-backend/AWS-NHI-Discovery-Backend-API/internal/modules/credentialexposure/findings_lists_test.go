package credentialexposure

import (
	"strings"
	"testing"
)

func TestIsGenericDetector(t *testing.T) {
	cases := map[string]bool{
		"generic_api_key":                 true,
		"high_entropy_string":             true,
		"jwt":                             true,
		"curl_basic_auth":                 true,
		"mysql_connection_string":         true,
		"azure_storage_connection_string": false, // provider-format, never vetoed
		"aws_access_key_id":               false,
		"stripe_key":                      false,
		"github_pat":                      false,
	}
	for detector, want := range cases {
		if got := isGenericDetector(detector); got != want {
			t.Errorf("isGenericDetector(%q) = %v, want %v", detector, got, want)
		}
	}
}

func TestHasNoiseTag(t *testing.T) {
	cases := []struct {
		flags string
		want  bool
	}{
		{"", false},
		{"plain_url", true},
		{"foo, integrity_hash", true},
		{"known_example_value,arn_identifier", true},
		{"plain_url_extra", false}, // whole-tag match, not substring
		{"unrelated", false},
	}
	for _, c := range cases {
		if got := hasNoiseTag(c.flags); got != c.want {
			t.Errorf("hasNoiseTag(%q) = %v, want %v", c.flags, got, c.want)
		}
	}
}

func TestNormalizeList(t *testing.T) {
	for in, want := range map[string]string{"": listMain, " Review ": listReview, "ml_flagged": listMLFlagged} {
		got, err := normalizeList(in)
		if err != nil || got != want {
			t.Errorf("normalizeList(%q) = %q, %v; want %q", in, got, err, want)
		}
	}
	if _, err := normalizeList("bogus"); err == nil || !strings.Contains(err.Error(), "list must") {
		t.Errorf("expected a 'list must' error for an unknown list, got %v", err)
	}
}

// The classification is SQL, so assert the generated statement keeps the rule
// order and never selects ml_features.
func TestClassifiedFindingsSQL(t *testing.T) {
	q := classifiedFindings(`"t"`)
	if strings.Contains(q, "ml_features") {
		t.Error("ml_features must never be selected")
	}
	order := []string{"'" + listRepeated + "'", "'" + listNoise + "'", "'" + listReview + "'", "'" + listMLFlagged + "'", "ELSE '" + listMain + "'"}
	last := -1
	for _, token := range order {
		i := strings.Index(q, "THEN "+token)
		if token == order[len(order)-1] {
			i = strings.Index(q, token)
		}
		if i < 0 || i < last {
			t.Fatalf("list rule %s missing or out of order in:\n%s", token, q)
		}
		last = i
	}
	for _, want := range []string{"0.13305", "0.25", "0.4", "0.5", "0.95", "0.3", "private_key", "azure_storage_"} {
		if !strings.Contains(q, want) {
			t.Errorf("expected %q in classification SQL", want)
		}
	}
}
