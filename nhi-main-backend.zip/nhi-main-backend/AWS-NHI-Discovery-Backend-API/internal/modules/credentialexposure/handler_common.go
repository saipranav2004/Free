package credentialexposure

import (
	"encoding/json"
	"io"
	"net/http"
	"strings"

	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/logging"
	"nhi-backend-api/internal/platform/middleware"
)

func requireScannerAdmin(w http.ResponseWriter, r *http.Request) bool {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeError(w, http.StatusUnauthorized, "UNAUTHORIZED", "Authentication required")
		return false
	}
	if !strings.EqualFold(strings.TrimSpace(claims.Role), "admin") {
		writeError(w, http.StatusForbidden, "FORBIDDEN", "Credential Exposure APIs require an admin role")
		return false
	}
	return true
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	writeJSON(w, status, map[string]string{"error": code, "message": message})
}

func writeAPIError(w http.ResponseWriter, status int, message, code string) {
	writeJSON(w, status, httpx.APIResponse{Success: false, Message: message, Error: code})
}

func decodeJSONBody(w http.ResponseWriter, r *http.Request, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", "Request body must be valid JSON with supported fields: "+err.Error())
		return false
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", "Request body must contain exactly one JSON object")
		return false
	}
	return true
}

// rejectUnknownQuery is the credential-exposure variant of the shared check:
// same message and code, but written through writeJSON so the response is
// marked no-store like every other endpoint in this package.
func rejectUnknownQuery(w http.ResponseWriter, r *http.Request, allowed map[string]struct{}) bool {
	if unknown, ok := httpx.CheckUnknown(r.URL.Query(), allowed); ok {
		writeAPIError(w, http.StatusBadRequest, httpx.UnknownParamMessage(unknown, allowed), "INVALID_QUERY_PARAM")
		return true
	}
	return false
}

// serverError logs the real error, with the request id, before answering with
// the generic 500 the client sees. Handlers must never return a 500 without it.
func serverError(w http.ResponseWriter, r *http.Request, message string, err error) {
	logging.FromContext(r.Context()).Error(message, "err", err)
	writeError(w, http.StatusInternalServerError, "INTERNAL_ERROR", message)
}
