package identitygraph

import "strings"

// The effective-permission Grant lookup shared by the permission-source and
// identity-events features.

const policyMayHaveChangedNote = "Policy may have changed since this event"

// PermissionSourceResponse names the policy behind one event. When no granted
// permission matches (for example the policy was removed since it was last discovered)
// Matched is false, the policy fields are null and Note says why.
type PermissionSourceResponse struct {
	Matched       bool    `json:"matched"`
	PolicySource  *string `json:"policy_source"`
	PolicyType    *string `json:"policy_type"`
	Effect        *string `json:"effect"`
	ResourceARN   *string `json:"resource_arn"`
	MatchedAction *string `json:"matched_action"`
	Note          *string `json:"note"`
}

// Grant is one effective-permission entry that covers an event.
type Grant struct {
	policySource, policyType, effect, resourceARN, action string
}

// BestGrant picks the entry that explains an event. An exact action beats a
// wildcard one, and an Allow beats a Deny (so the Grant that let the call
// through is the one reported); ties keep the first entry. nil means no entry
// covers the event.
func BestGrant(entries []map[string]interface{}, service, eventName string) *Grant {
	str := func(m map[string]interface{}, keys ...string) string {
		for _, k := range keys {
			if v, ok := m[k].(string); ok && v != "" {
				return v
			}
		}
		return ""
	}
	var best *Grant
	bestScore := -1
	for _, e := range entries {
		svc, action := str(e, "service", "Service"), str(e, "action", "Action")
		if !matchGranted(svc, action, service, eventName) {
			continue
		}
		effect := str(e, "effect", "Effect")
		if effect == "" {
			effect = "Allow"
		}
		_, bare := splitGrantedAction(svc, action)
		score := 0
		if !strings.ContainsAny(bare, "*?") {
			score += 2 // exact action
		}
		if strings.EqualFold(effect, "Allow") {
			score += 4
		}
		if score <= bestScore {
			continue
		}
		bestScore = score
		resource := str(e, "resource_arn", "resource", "Resource")
		if resource == "" {
			resource = "*"
		}
		best = &Grant{
			policySource: str(e, "policy_source", "policy_name", "PolicySource"),
			policyType:   str(e, "policy_type", "PolicyType"),
			effect:       effect,
			resourceARN:  resource,
			action:       action,
		}
	}
	return best
}

func GrantResponse(g *Grant) *PermissionSourceResponse {
	if g == nil {
		note := policyMayHaveChangedNote
		return &PermissionSourceResponse{Matched: false, Note: &note}
	}
	opt := func(s string) *string {
		if s == "" {
			return nil
		}
		return &s
	}
	return &PermissionSourceResponse{
		Matched:       true,
		PolicySource:  opt(g.policySource),
		PolicyType:    opt(g.policyType),
		Effect:        opt(g.effect),
		ResourceARN:   opt(g.resourceARN),
		MatchedAction: opt(g.action),
	}
}
