package identitygraph

import "strings"

// Helpers shared by several inventory features.

// CredentialActivityKeys returns what identifies a credential in CloudTrail:
// its ARN (the session issuer for roles) and, for access keys, the key ID
// (which is the credential's name).
func CredentialActivityKeys(arn, name, credentialType string) []string {
	var keys []string
	if arn != "" {
		keys = append(keys, arn)
	}
	if strings.EqualFold(credentialType, "access_key") && name != "" {
		keys = append(keys, name)
	}
	return keys
}

func LowerTrimAll(in []string) []string {
	out := make([]string, 0, len(in))
	for _, s := range in {
		s = strings.ToLower(strings.TrimSpace(s))
		if s != "" {
			out = append(out, s)
		}
	}
	return out
}

// ValidEdgeTypes are the ?edge_type= values the relationship tabs accept.
var (
	ValidEdgeTypes = map[string]struct{}{
		"assume_role": {}, "bound_to": {}, "accesses": {}, "trusts": {},
		"contains": {}, "manages": {}, "attached_to": {}, "uses": {},
		// Stored in trust_edges today, and the CloudTrail-derived created_by.
		"service_trust": {}, "cross_account": {}, "federated_oidc": {}, "federated_saml": {},
		"created_by": {},
	}
)

// MaxRelationshipDepth is the documented ceiling for ?depth= on the
// relationships tab (PDF: "Hops: 1, 2, 3"). Values outside 1..3 are rejected
// with 400 so the client knows what it actually received.
const MaxRelationshipDepth = 3
