package identitygraph

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"

	chrepo "nhi-backend-api/internal/identitygraph/eventstore"
	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/scope"
)

// entityChangesLimit is the row cap of the changes tab; the tab is not paginated.
const entityChangesLimit = 50

// EntityChange is one scan_changes row for a single identity or credential,
// with the scan's time. Details is the stored jsonb passed through untouched.
type EntityChange struct {
	ScanID     string          `json:"scan_id"`
	ScanTime   *time.Time      `json:"scan_time"`
	ChangeType string          `json:"change_type"`
	EntityType string          `json:"entity_type"`
	Summary    string          `json:"summary"`
	Details    json.RawMessage `json:"details,omitempty"`
	// Evidence is the CloudTrail event behind a CREATED/DELETED row. It is
	// absent when ClickHouse is off, slow or has no matching event.
	Evidence *ChangeEvidence `json:"cloudtrail_evidence,omitempty"`

	detectedAt time.Time
}

// ChangeEvidence is the CloudTrail call that created or deleted the entity.
// For a DELETED row, CreatedBy/CreatedAt describe the delete call.
type ChangeEvidence struct {
	EventName string    `json:"event_name"`
	CreatedBy string    `json:"created_by"`
	CreatedAt time.Time `json:"created_at"`
	SourceIP  string    `json:"source_ip"`
}

// loadEntityChanges returns the newest changes recorded against arn, newest
// first. The scan time comes from a per-account-scoped LATERAL lookup so a scan
// id that has several nhi_scans_aws rows can never duplicate a change row. A
// tenant without these tables yet has no changes, which is not an error.
func loadEntityChanges(ctx context.Context, resolved *scope.DataScope, arn string) ([]EntityChange, error) {
	out := []EntityChange{}
	if resolved == nil || resolved.DB == nil || strings.TrimSpace(arn) == "" {
		return out, nil
	}
	query := fmt.Sprintf(`
		SELECT c.scan_id, s.scan_end, c.change_type, c.entity_type,
		       COALESCE(c.summary, ''), c.details, c.detected_at
		FROM %s c
		LEFT JOIN LATERAL (
			SELECT scan_end FROM %s
			WHERE scan_id::text = c.scan_id AND account_id = ANY($2::text[])
			ORDER BY scan_end DESC NULLS LAST
			LIMIT 1
		) s ON true
		WHERE c.entity_arn = $1
		ORDER BY c.detected_at DESC, c.id
		LIMIT %d`,
		resolved.Table("scan_changes"), resolved.Table("nhi_scans_aws"), entityChangesLimit)

	rows, err := resolved.DB.QueryContext(ctx, query, arn, pq.Array(resolved.AccountIDs))
	if err != nil {
		if database.IsUndefinedTable(err) {
			return out, nil
		}
		return nil, fmt.Errorf("query entity changes: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var (
			c       EntityChange
			scanEnd sql.NullTime
			details []byte
		)
		if err := rows.Scan(&c.ScanID, &scanEnd, &c.ChangeType, &c.EntityType,
			&c.Summary, &details, &c.detectedAt); err != nil {
			return nil, fmt.Errorf("scan entity change: %w", err)
		}
		if scanEnd.Valid {
			t := scanEnd.Time
			c.ScanTime = &t
		}
		if len(details) > 0 {
			c.Details = json.RawMessage(details)
		}
		out = append(out, c)
	}
	return out, rows.Err()
}

// enrichChanges attaches CloudTrail evidence to CREATED and DELETED rows only.
// It asks the source once per request (never per row); a source that is off,
// slow or failing returns nothing and the rows go out unchanged.
func enrichChanges(ctx context.Context, changes []EntityChange, arn string, src ActivitySource) {
	need := false
	for _, c := range changes {
		if t := strings.ToUpper(c.ChangeType); t == "CREATED" || t == "DELETED" {
			need = true
			break
		}
	}
	if !need {
		return
	}
	attachEvidence(changes, OrNoActivity(src).ChangeEvents(ctx, arn))
}

// attachEvidence is the pure matcher. For a CREATED row it takes the newest
// Create* event at or before the row's detected_at, for a DELETED row the
// newest Delete* event: the CloudTrail call always precedes the scan that
// notices it, and the newest such call is the one the scan saw (an ARN can be
// created, deleted and recreated). events must be newest first. A row with no
// earlier matching event gets no evidence rather than a wrong one.
func attachEvidence(changes []EntityChange, events []chrepo.ChangeEvent) {
	if len(events) == 0 {
		return
	}
	for i := range changes {
		var prefix string
		switch strings.ToUpper(changes[i].ChangeType) {
		case "CREATED":
			prefix = "Create"
		case "DELETED":
			prefix = "Delete"
		default:
			continue
		}
		for _, e := range events {
			if !strings.HasPrefix(e.EventName, prefix) || e.EventTime.After(changes[i].detectedAt) {
				continue
			}
			changes[i].Evidence = &ChangeEvidence{
				EventName: e.EventName,
				CreatedBy: e.CallerARN,
				CreatedAt: e.EventTime,
				SourceIP:  e.SourceIP,
			}
			break
		}
	}
}

// IdentityChangesResponse is the identity detail "changes" tab.
type IdentityChangesResponse struct {
	Tab         string         `json:"tab"`
	IdentityARN string         `json:"identity_arn"`
	Changes     []EntityChange `json:"changes"`
}

// CredentialChangesResponse is the credential detail "changes" tab.
type CredentialChangesResponse struct {
	Tab           string         `json:"tab"`
	CredentialARN string         `json:"credential_arn"`
	Changes       []EntityChange `json:"changes"`
}

// GetChanges is the identity "changes" tab. The identity is loaded through the
// same scope-checked loader as every other tab, so an unknown or out-of-scope
// id is ErrIdentityNotFound (404) exactly as before.
func (r *IdentityDetailRepository) GetChanges(ctx context.Context, resolved *scope.DataScope, id string, src ActivitySource) (*IdentityChangesResponse, error) {
	ci, err := r.loadCoreIdentity(ctx, resolved, id)
	if err != nil {
		return nil, err
	}
	changes, err := loadEntityChanges(ctx, resolved, ci.ARN)
	if err != nil {
		return nil, err
	}
	enrichChanges(ctx, changes, ci.ARN, src)
	return &IdentityChangesResponse{Tab: "changes", IdentityARN: ci.ARN, Changes: changes}, nil
}

// GetChanges is the credential "changes" tab; see the identity version.
func (r *CredentialDetailRepository) GetChanges(ctx context.Context, resolved *scope.DataScope, id string, src ActivitySource) (*CredentialChangesResponse, error) {
	c, err := r.loadCoreCredential(ctx, resolved, id)
	if err != nil {
		return nil, err
	}
	changes, err := loadEntityChanges(ctx, resolved, c.ARN)
	if err != nil {
		return nil, err
	}
	enrichChanges(ctx, changes, c.ARN, src)
	return &CredentialChangesResponse{Tab: "changes", CredentialARN: c.ARN, Changes: changes}, nil
}
