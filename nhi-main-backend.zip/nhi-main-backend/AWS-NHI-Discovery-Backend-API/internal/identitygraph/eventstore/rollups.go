package eventstore

import (
	"context"
	"fmt"
	"time"

	ch "github.com/ClickHouse/clickhouse-go/v2"

	"nhi-backend-api/internal/platform/logging"
)

// Rollups names the optional pre-aggregated tables (see
// migrations/clickhouse/001_event_rollups.sql). An empty name keeps that
// section on the raw table.
type Rollups struct {
	Heatmap     string // hourly buckets
	Credentials string // daily buckets
	Resources   string // daily buckets
	IPs         string // daily buckets
}

// WithRollups enables the pre-aggregated tables.
func WithRollups(r Rollups) Option {
	return func(c *Repository) { c.rollups = r }
}

const (
	// A rollup row covers a whole bucket, so a window narrower than a few
	// buckets would over-count at its edges; those fall back to the raw table.
	minHourlyWindow = 6 * time.Hour
	minDailyWindow  = 24 * time.Hour
)

// Why a section read the raw table instead of its rollup.
const (
	reasonNoTable      = "rollup_not_configured"
	reasonRowFilter    = "row_level_filter"
	reasonNarrowWindow = "window_too_narrow"
	reasonNoSubject    = "no_subject_or_accounts"
)

// logSource records which table answered a section, with the request id from
// ctx, so "rollup or raw?" can be read from the logs.
func logSource(ctx context.Context, section, source, reason string) {
	attrs := []any{"section", section, "source", source}
	if reason != "" {
		attrs = append(attrs, "reason", reason)
	}
	logging.FromContext(ctx).Info("identity events source", attrs...)
}

// rollupWhere builds the WHERE body for a rollup table. ok is false when the
// raw table must be used instead (reason says why): the request has a
// row-level filter the rollup cannot answer, or the window is too narrow for
// the bucket size.
func rollupWhere(sub Subject, sc Scope, f EventFilter, bucket time.Duration, minWindow time.Duration) (where string, args []any, reason string) {
	if f.Action != "" || f.Resource != "" || f.SourceIP != "" || f.Credential != "" ||
		(f.Result != "" && f.Result != "all") || (f.ReadWrite != "" && f.ReadWrite != "all") {
		return "", nil, reasonRowFilter
	}
	if !sc.Start.IsZero() {
		end := sc.End
		if end.IsZero() {
			end = time.Now()
		}
		if end.Sub(sc.Start) < minWindow {
			return "", nil, reasonNarrowWindow
		}
	}
	base := sc
	base.Start, base.End = time.Time{}, time.Time{}
	where, args, ok := buildFilter(sub, base)
	if !ok {
		return "", nil, reasonNoSubject
	}
	trunc := "toStartOfDay"
	if bucket == time.Hour {
		trunc = "toStartOfHour"
	}
	if !sc.Start.IsZero() {
		where += fmt.Sprintf(" AND bucket >= %s({start:DateTime64(3)})", trunc)
		args = append(args, ch.Named("start", sc.Start.UTC()))
	}
	if !sc.End.IsZero() {
		where += " AND bucket <= {end:DateTime64(3)}"
		args = append(args, ch.Named("end", sc.End.UTC()))
	}
	return where, args, ""
}

func (c *Repository) heatmapRollup(ctx context.Context, sub Subject, sc Scope, f EventFilter) ([]HeatCell, bool, error) {
	if c.rollups.Heatmap == "" {
		logSource(ctx, "heatmap", "raw", reasonNoTable)
		return nil, false, nil
	}
	where, args, reason := rollupWhere(sub, sc, f, time.Hour, minHourlyWindow)
	if reason != "" {
		logSource(ctx, "heatmap", "raw", reason)
		return nil, false, nil
	}
	logSource(ctx, "heatmap", "rollup", "")
	q := fmt.Sprintf(`SELECT event_name, toHour(bucket) AS h, countMerge(c)
		FROM %[1]s
		WHERE %[2]s AND event_name IN (
			SELECT event_name FROM %[1]s WHERE %[2]s
			GROUP BY event_name ORDER BY countMerge(c) DESC, event_name LIMIT %[3]d)
		GROUP BY event_name, h
		ORDER BY event_name, h`, c.rollups.Heatmap, where, heatmapActions)
	ctx, cancel := c.eventsCtx(ctx)
	defer cancel()
	rows, err := c.conn.Query(ctx, q, args...)
	if err != nil {
		return nil, true, fmt.Errorf("clickhouse heatmap rollup: %w", err)
	}
	defer rows.Close()
	var out []HeatCell
	for rows.Next() {
		var h HeatCell
		if err := rows.Scan(&h.Action, &h.Hour, &h.Count); err != nil {
			return nil, true, fmt.Errorf("clickhouse heatmap rollup scan: %w", err)
		}
		out = append(out, h)
	}
	return out, true, rows.Err()
}

func (c *Repository) credentialUsageRollup(ctx context.Context, sub Subject, sc Scope, f EventFilter) ([]CredentialUsageRow, bool, error) {
	if c.rollups.Credentials == "" {
		logSource(ctx, "credentials", "raw", reasonNoTable)
		return nil, false, nil
	}
	where, args, reason := rollupWhere(sub, sc, f, 24*time.Hour, minDailyWindow)
	if reason != "" {
		logSource(ctx, "credentials", "raw", reason)
		return nil, false, nil
	}
	logSource(ctx, "credentials", "rollup", "")
	q := fmt.Sprintf(`SELECT
			multiIf(session_issuer_arn != '', session_issuer_arn, access_key_id != '', access_key_id, caller_arn) AS ckey,
			multiIf(session_issuer_arn != '', 'issuer', access_key_id != '', 'access_key', 'caller') AS kind,
			countMerge(c) AS n, minMerge(first_seen), maxMerge(last_seen),
			groupUniqArrayMerge(20)(actions), uniqExactMerge(resources)
		FROM %s WHERE %s
		GROUP BY ckey, kind
		ORDER BY n DESC
		LIMIT 200`, c.rollups.Credentials, where)
	ctx, cancel := c.eventsCtx(ctx)
	defer cancel()
	rows, err := c.conn.Query(ctx, q, args...)
	if err != nil {
		return nil, true, fmt.Errorf("clickhouse credential usage rollup: %w", err)
	}
	defer rows.Close()
	var out []CredentialUsageRow
	for rows.Next() {
		var r CredentialUsageRow
		if err := rows.Scan(&r.Key, &r.Kind, &r.Count, &r.First, &r.Last, &r.Actions, &r.UniqueResources); err != nil {
			return nil, true, fmt.Errorf("clickhouse credential usage rollup scan: %w", err)
		}
		out = append(out, r)
	}
	return out, true, rows.Err()
}

func (c *Repository) resourceAccessRollup(ctx context.Context, sub Subject, sc Scope, f EventFilter) ([]ResourceRow, uint64, bool, error) {
	if c.rollups.Resources == "" {
		logSource(ctx, "resources", "raw", reasonNoTable)
		return nil, 0, false, nil
	}
	where, args, reason := rollupWhere(sub, sc, f, 24*time.Hour, minDailyWindow)
	if reason != "" {
		logSource(ctx, "resources", "raw", reason)
		return nil, 0, false, nil
	}
	logSource(ctx, "resources", "rollup", "")
	q := fmt.Sprintf(`SELECT resource_arn, any(resource_type), groupUniqArrayMerge(20)(actions),
			sumMerge(reads), sumMerge(writes), countIfMerge(errors),
			minMerge(first_seen), maxMerge(last_seen)
		FROM %s WHERE %s
		GROUP BY resource_arn
		ORDER BY countMerge(c) DESC, resource_arn
		LIMIT %d`, c.rollups.Resources, where, maxResourceRows)
	ctx, cancel := c.eventsCtx(ctx)
	defer cancel()
	rows, err := c.conn.Query(ctx, q, args...)
	if err != nil {
		return nil, 0, true, fmt.Errorf("clickhouse resources rollup: %w", err)
	}
	var out []ResourceRow
	for rows.Next() {
		var r ResourceRow
		if err := rows.Scan(&r.ARN, &r.Type, &r.Actions, &r.Reads, &r.Writes, &r.Errors, &r.First, &r.Last); err != nil {
			rows.Close()
			return nil, 0, true, fmt.Errorf("clickhouse resources rollup scan: %w", err)
		}
		out = append(out, r)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, 0, true, err
	}
	rows.Close()
	var total uint64
	if err := c.conn.QueryRow(ctx, fmt.Sprintf("SELECT uniqExact(resource_arn) FROM %s WHERE %s", c.rollups.Resources, where), args...).Scan(&total); err != nil {
		return nil, 0, true, fmt.Errorf("clickhouse resources rollup total: %w", err)
	}
	return out, total, true, nil
}

func (c *Repository) ipStatsRollup(ctx context.Context, sub Subject, sc Scope, f EventFilter) ([]IPRow, uint64, bool, error) {
	if c.rollups.IPs == "" {
		logSource(ctx, "ips", "raw", reasonNoTable)
		return nil, 0, false, nil
	}
	where, args, reason := rollupWhere(sub, sc, f, 24*time.Hour, minDailyWindow)
	if reason != "" {
		logSource(ctx, "ips", "raw", reason)
		return nil, 0, false, nil
	}
	logSource(ctx, "ips", "rollup", "")
	q := fmt.Sprintf(`SELECT source_ip, countMerge(c) AS n, minMerge(first_seen), maxMerge(last_seen)
		FROM %s WHERE %s
		GROUP BY source_ip
		ORDER BY n DESC, source_ip
		LIMIT %d`, c.rollups.IPs, where, maxIPRows)
	ctx, cancel := c.eventsCtx(ctx)
	defer cancel()
	rows, err := c.conn.Query(ctx, q, args...)
	if err != nil {
		return nil, 0, true, fmt.Errorf("clickhouse ips rollup: %w", err)
	}
	var out []IPRow
	for rows.Next() {
		var r IPRow
		if err := rows.Scan(&r.IP, &r.Count, &r.First, &r.Last); err != nil {
			rows.Close()
			return nil, 0, true, fmt.Errorf("clickhouse ips rollup scan: %w", err)
		}
		out = append(out, r)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, 0, true, err
	}
	rows.Close()
	var total uint64
	if err := c.conn.QueryRow(ctx, fmt.Sprintf("SELECT uniqExact(source_ip) FROM %s WHERE %s", c.rollups.IPs, where), args...).Scan(&total); err != nil {
		return nil, 0, true, fmt.Errorf("clickhouse ips rollup total: %w", err)
	}
	return out, total, true, nil
}
