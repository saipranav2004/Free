package eventstore

import (
	"testing"
	"time"
)

func TestRollupWhereReason(t *testing.T) {
	sub := NewSubject("arn:aws:iam::1:role/r")
	now := time.Now()
	wide := Scope{Accounts: []string{"1"}, Start: now.Add(-7 * 24 * time.Hour), End: now}
	narrow := Scope{Accounts: []string{"1"}, Start: now.Add(-time.Hour), End: now}

	cases := []struct {
		name   string
		sub    Subject
		sc     Scope
		f      EventFilter
		reason string
	}{
		{"rollup used", sub, wide, EventFilter{}, ""},
		{"all is not a filter", sub, wide, EventFilter{Result: "all", ReadWrite: "all"}, ""},
		{"action filter", sub, wide, EventFilter{Action: "GetObject"}, reasonRowFilter},
		{"result filter", sub, wide, EventFilter{Result: "error"}, reasonRowFilter},
		{"narrow window", sub, narrow, EventFilter{}, reasonNarrowWindow},
		{"no accounts", sub, Scope{Start: wide.Start, End: wide.End}, EventFilter{}, reasonNoSubject},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			where, _, reason := rollupWhere(tc.sub, tc.sc, tc.f, 24*time.Hour, minDailyWindow)
			if reason != tc.reason {
				t.Fatalf("reason = %q, want %q", reason, tc.reason)
			}
			if reason == "" && where == "" {
				t.Fatal("empty where for a usable rollup")
			}
		})
	}
}
