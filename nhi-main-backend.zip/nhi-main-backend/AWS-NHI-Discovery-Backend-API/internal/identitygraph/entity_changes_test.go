package identitygraph

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"

	chrepo "nhi-backend-api/internal/identitygraph/eventstore"
)

func changeAt(changeType string, detected time.Time) EntityChange {
	return EntityChange{ChangeType: changeType, EntityType: "identity", detectedAt: detected}
}

func TestAttachEvidencePicksNewestMatchingEventBeforeDetection(t *testing.T) {
	day := func(d int) time.Time { return time.Date(2026, 10, d, 12, 0, 0, 0, time.UTC) }
	// newest first, as ChangeEventsByARN returns them
	events := []chrepo.ChangeEvent{
		{EventName: "CreateRole", CallerARN: "arn:later", EventTime: day(14), SourceIP: "9.9.9.9"}, // after the scan: must not match
		{EventName: "DeleteRole", CallerARN: "arn:deleter", EventTime: day(12), SourceIP: "2.2.2.2"},
		{EventName: "CreateRole", CallerARN: "arn:creator", EventTime: day(10), SourceIP: "1.1.1.1"},
		{EventName: "CreateRole", CallerARN: "arn:older", EventTime: day(5), SourceIP: "5.5.5.5"},
	}
	changes := []EntityChange{
		changeAt("CREATED", day(11)),
		changeAt("DELETED", day(13)),
		changeAt("MODIFIED", day(13)),
		changeAt("CREATED", day(2)), // nothing earlier: no evidence, not a wrong one
	}
	attachEvidence(changes, events)

	if got := changes[0].Evidence; got == nil || got.CreatedBy != "arn:creator" || got.EventName != "CreateRole" || got.SourceIP != "1.1.1.1" {
		t.Errorf("CREATED evidence = %+v, want the day-10 CreateRole by arn:creator", got)
	}
	if got := changes[1].Evidence; got == nil || got.EventName != "DeleteRole" || got.CreatedBy != "arn:deleter" {
		t.Errorf("DELETED evidence = %+v, want the day-12 DeleteRole", got)
	}
	if changes[2].Evidence != nil {
		t.Errorf("MODIFIED row must never get evidence, got %+v", changes[2].Evidence)
	}
	if changes[3].Evidence != nil {
		t.Errorf("row with no earlier event must stay bare, got %+v", changes[3].Evidence)
	}
}

func TestAttachEvidenceNoEventsLeavesRowsUntouched(t *testing.T) {
	changes := []EntityChange{changeAt("CREATED", time.Now())}
	attachEvidence(changes, nil)
	if changes[0].Evidence != nil {
		t.Fatalf("evidence = %+v, want none", changes[0].Evidence)
	}
}

// countingSource records how often the enrichment asks for events.
type countingSource struct {
	*FakeActivity
	calls int
}

func (c *countingSource) ChangeEvents(ctx context.Context, arn string) []chrepo.ChangeEvent {
	c.calls++
	return c.FakeActivity.ChangeEvents(ctx, arn)
}

func TestEnrichChangesAsksOncePerRequestAndOnlyForCreatedDeleted(t *testing.T) {
	const arn = "arn:aws:iam::111122223333:role/AdminBot"
	det := time.Date(2026, 10, 10, 12, 0, 0, 0, time.UTC)
	src := &countingSource{FakeActivity: &FakeActivity{Up: true, Changes: map[string][]chrepo.ChangeEvent{
		arn: {{EventName: "CreateRole", CallerARN: "arn:admin", EventTime: det.Add(-time.Hour), SourceIP: "203.0.113.50"}},
	}}}

	// Several enrichable rows: still exactly one lookup, not one per row.
	changes := []EntityChange{changeAt("CREATED", det), changeAt("CREATED", det), changeAt("DELETED", det)}
	enrichChanges(context.Background(), changes, arn, src)
	if src.calls != 1 {
		t.Errorf("ChangeEvents calls = %d, want 1", src.calls)
	}
	if changes[0].Evidence == nil || changes[1].Evidence == nil {
		t.Errorf("CREATED rows should carry evidence: %+v / %+v", changes[0].Evidence, changes[1].Evidence)
	}
	if changes[2].Evidence != nil {
		t.Errorf("DELETED row has no Delete* event, evidence = %+v", changes[2].Evidence)
	}

	// Only MODIFIED rows: ClickHouse is not touched at all.
	src.calls = 0
	enrichChanges(context.Background(), []EntityChange{changeAt("MODIFIED", det)}, arn, src)
	if src.calls != 0 {
		t.Errorf("ChangeEvents called %d times for MODIFIED-only rows, want 0", src.calls)
	}
}

func TestEnrichChangesDegradesWithoutClickHouse(t *testing.T) {
	changes := []EntityChange{changeAt("CREATED", time.Now())}
	enrichChanges(context.Background(), changes, "arn:x", nil)             // nil source
	enrichChanges(context.Background(), changes, "arn:x", NoActivity{})    // ClickHouse not wired
	enrichChanges(context.Background(), changes, "arn:x", &FakeActivity{}) // configured, no events
	if changes[0].Evidence != nil {
		t.Fatalf("evidence = %+v, want none when ClickHouse has nothing", changes[0].Evidence)
	}

	// A RequestActivity that cannot reach ClickHouse (no scope/DB) answers nil
	// instead of blocking or panicking.
	if got := (&ActivityService{}).ForRequest(nil).ChangeEvents(context.Background(), "arn:x"); got != nil {
		t.Fatalf("unavailable source returned %v, want nil", got)
	}
}

func TestChangesResponseJSONShape(t *testing.T) {
	when := time.Date(2026, 10, 10, 12, 0, 0, 0, time.UTC)
	resp := IdentityChangesResponse{
		Tab:         "changes",
		IdentityARN: "arn:aws:iam::111122223333:role/AdminBot",
		Changes: []EntityChange{
			{
				ScanID: "scan-1", ScanTime: &when, ChangeType: "CREATED", EntityType: "identity", Summary: "created",
				Details:  json.RawMessage(`{"name":"AdminBot"}`),
				Evidence: &ChangeEvidence{EventName: "CreateRole", CreatedBy: "arn:admin", CreatedAt: when, SourceIP: "203.0.113.50"},
			},
			{ScanID: "scan-2", ChangeType: "MODIFIED", EntityType: "permission", Summary: "2 added"},
		},
	}
	b, err := json.Marshal(resp)
	if err != nil {
		t.Fatal(err)
	}
	s := string(b)
	for _, want := range []string{`"tab":"changes"`, `"identity_arn":`, `"scan_time":"2026-10-10T12:00:00Z"`,
		`"cloudtrail_evidence":{"event_name":"CreateRole","created_by":"arn:admin"`, `"source_ip":"203.0.113.50"`} {
		if !strings.Contains(s, want) {
			t.Errorf("JSON missing %s\n%s", want, s)
		}
	}
	// The second row has no evidence and no details: both keys are absent, and
	// its null scan_time is explicit rather than dropped.
	second := s[strings.Index(s, `"scan_id":"scan-2"`):]
	if strings.Contains(second, "cloudtrail_evidence") || strings.Contains(second, `"details"`) {
		t.Errorf("bare row should omit evidence/details: %s", second)
	}
	if !strings.Contains(second, `"scan_time":null`) {
		t.Errorf("bare row should serialise scan_time as null: %s", second)
	}

	empty, _ := json.Marshal(CredentialChangesResponse{Tab: "changes", CredentialARN: "arn:c", Changes: []EntityChange{}})
	if !strings.Contains(string(empty), `"changes":[]`) {
		t.Errorf("empty changes must be [], got %s", empty)
	}
}
