package middleware

import (
	"encoding/json"
	"net/http"
	"strings"
)

// PostureBasePath is where the ISPM posture dashboard API is mounted, below
// /api/v1 (and /api). /identities and /identities/{id} already belong to the
// inventory API, so the posture API lives under its own prefix.
const PostureBasePath = "/ispm"

// IsPosturePath reports whether the request path belongs to the posture API.
func IsPosturePath(path string) bool {
	p := "/api/v1" + PostureBasePath
	return path == p || strings.HasPrefix(path, p+"/")
}

// WritePostureError writes the error body documented in ISPM_Dashboard_API_v2:
// { "error": { "code", "message" } }.
func WritePostureError(w http.ResponseWriter, status int, code, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]any{"error": map[string]string{"code": code, "message": message}})
}
