// Package httpx holds the HTTP helpers shared by every feature module:
// the response envelope, JSON writing, and query-string validation.
package httpx

import (
	"encoding/json"
	"net/http"
)

// APIResponse is the standard wrapper for all API responses.
type APIResponse struct {
	Success bool        `json:"success"`
	Message string      `json:"message"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
}

// WriteJSON writes v as a JSON body with the given status code.
func WriteJSON(w http.ResponseWriter, status int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

// WriteError writes the standard failure envelope with an error code.
func WriteError(w http.ResponseWriter, status int, message, code string) {
	WriteJSON(w, status, APIResponse{Success: false, Message: message, Error: code})
}
