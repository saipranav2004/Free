package httpx

import (
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
)

// Request-limit constants shared by every list endpoint, so the documented
// contract is enforced in exactly one place.
const (
	// MaxPageSize is the documented ceiling for ?page_size= (PDF: "Rows per
	// page (max 100)"). Values above it are clamped, not rejected.
	MaxPageSize = 100

	// MaxActivityPageSize and MaxActivityEventsEnd bound the activity tabs: up
	// to 100 events per page and at most 1000 events (page * page_size)
	// reachable per request.
	MaxActivityPageSize  = 100
	MaxActivityEventsEnd = 1000
)

// UUIDRegex matches a canonical UUID path parameter.
var UUIDRegex = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

var validSortOrders = map[string]struct{}{"asc": {}, "desc": {}}

// IsValidSortOrder accepts an empty value, "asc" or "desc" (any case).
func IsValidSortOrder(s string) bool {
	if s == "" {
		return true
	}
	_, ok := validSortOrders[strings.ToLower(strings.TrimSpace(s))]
	return ok
}

// ValidateEnumValues returns the first value outside allowed.
func ValidateEnumValues(values []string, allowed map[string]struct{}) (string, bool) {
	for _, v := range values {
		low := strings.ToLower(strings.TrimSpace(v))
		if low == "" {
			continue
		}
		if _, ok := allowed[low]; !ok {
			return v, false
		}
	}
	return "", true
}

// ValidateSingleEnum reports whether value (or empty) is in allowed; the
// second result is the offending value.
func ValidateSingleEnum(value string, allowed map[string]struct{}) (bool, string) {
	low := strings.ToLower(strings.TrimSpace(value))
	if low == "" {
		return true, ""
	}
	if _, ok := allowed[low]; !ok {
		return false, value
	}
	return true, ""
}

// SplitAndTrim splits a comma-separated list and drops empty items.
func SplitAndTrim(raw string) []string {
	parts := strings.Split(raw, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// ParseOptionalBool returns nil when key is absent or empty.
func ParseOptionalBool(q map[string][]string, key string) (*bool, error) {
	raw := strings.TrimSpace(firstOrEmpty(q, key))
	if raw == "" {
		return nil, nil
	}
	v, err := strconv.ParseBool(raw)
	if err != nil {
		return nil, err
	}
	return &v, nil
}

// ParseOptionalInt returns nil when key is absent or empty.
func ParseOptionalInt(q map[string][]string, key string) (*int, error) {
	raw := strings.TrimSpace(firstOrEmpty(q, key))
	if raw == "" {
		return nil, nil
	}
	v, err := strconv.Atoi(raw)
	if err != nil {
		return nil, err
	}
	return &v, nil
}

func firstOrEmpty(q map[string][]string, key string) string {
	if vs, ok := q[key]; ok && len(vs) > 0 {
		return vs[0]
	}
	return ""
}

// ParseActivityPaging reads ?page= and ?page_size= for the activity tabs. It
// writes the 400 itself and returns ok=false when a value is invalid.
func ParseActivityPaging(w http.ResponseWriter, q url.Values) (page, size int, ok bool) {
	page, size = 1, 50
	bad := func(msg string) (int, int, bool) {
		WriteJSON(w, http.StatusBadRequest, APIResponse{Success: false, Message: msg, Error: "INVALID_PAGINATION"})
		return 0, 0, false
	}
	if raw := strings.TrimSpace(q.Get("page")); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 1 {
			return bad("page must be a positive integer")
		}
		page = v
	}
	if raw := strings.TrimSpace(q.Get("page_size")); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil || v < 1 || v > MaxActivityPageSize {
			return bad("page_size must be an integer between 1 and 100")
		}
		size = v
	}
	if page*size > MaxActivityEventsEnd {
		return bad("page * page_size must not exceed 1000 events; narrow the time range or filter instead")
	}
	return page, size, true
}
