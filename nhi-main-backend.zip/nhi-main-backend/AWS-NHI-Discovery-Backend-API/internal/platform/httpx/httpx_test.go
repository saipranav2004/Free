package httpx

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestRejectUnknownQueryBody(t *testing.T) {
	allowed := map[string]struct{}{"b": {}, "a": {}}
	r := httptest.NewRequest(http.MethodGet, "/x?zzz=1", nil)
	w := httptest.NewRecorder()
	if !RejectUnknownQuery(w, r, allowed) {
		t.Fatal("expected rejection")
	}
	want := `{"success":false,"message":"Unknown query parameter: zzz. Allowed parameters: a, b","error":"INVALID_QUERY_PARAM"}` + "\n"
	if w.Code != 400 || w.Body.String() != want || w.Header().Get("Content-Type") != "application/json" {
		t.Fatalf("got %d %q %v", w.Code, w.Body.String(), w.Header())
	}
}

func TestRejectUnknownQueryPasses(t *testing.T) {
	r := httptest.NewRequest(http.MethodGet, "/x?a=1", nil)
	if RejectUnknownQuery(httptest.NewRecorder(), r, map[string]struct{}{"a": {}}) {
		t.Fatal("unexpected rejection")
	}
}

func TestAllowedListEmpty(t *testing.T) {
	if AllowedList(nil) != "(none)" {
		t.Fatal("empty list should render (none)")
	}
}

func TestIsValidDate(t *testing.T) {
	for _, ok := range []string{"2026-01-02", "2026-01-02T03:04:05Z", "2026-01-02T03:04:05.123Z", "2026-01-02 03:04:05"} {
		if !IsValidDate(ok) {
			t.Errorf("%q should be valid", ok)
		}
	}
	for _, bad := range []string{"", "  ", "yesterday", "2026-13-01"} {
		if IsValidDate(bad) {
			t.Errorf("%q should be invalid", bad)
		}
	}
}
