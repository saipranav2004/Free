package config

import (
	"fmt"
	"net"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

var (
	iamNameRE      = regexp.MustCompile(`^[\w+=,.@-]{1,64}$`)
	ruleNameRE     = regexp.MustCompile(`^[.\-_A-Za-z0-9]{1,64}$`)
	logGroupNameRE = regexp.MustCompile(`^[.\-_/#A-Za-z0-9]{1,512}$`)
)

var databaseNameRE = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_-]{0,62}$`)

// schemaNameRE is stricter than databaseNameRE: tenant schema names come from
// the tenant registry via the JWT and are interpolated (quoted) into SQL.
var schemaNameRE = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_]{0,62}$`)

// DefaultGlobalSchema holds the users and tenant registry tables.
const DefaultGlobalSchema = "nhi_global"

type Config struct {
	Server ServerConfig `yaml:"server"`
	// Database is the single PostgreSQL database (nhi_db). The global schema
	// holds authentication/tenant registry tables; every tenant's data lives in
	// its own schema of this same database.
	Database   DatabaseConfig   `yaml:"database"`
	JWT        JWTConfig        `yaml:"jwt"`
	CORS       CORSConfig       `yaml:"cors"`
	Logging    LoggingConfig    `yaml:"logging"`
	Scanner    ScannerConfig    `yaml:"scanner"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	// AWSIntegration is optional; every field has a default.
	AWSIntegration AWSIntegrationConfig `yaml:"aws_integration"`
}

// AWSIntegrationConfig is how this process reaches AWS to verify a customer's
// connection. The per-tenant values customers copy (our account, External ID,
// event bus) live in the tenants table of the global schema, not here.
type AWSIntegrationConfig struct {
	// AssumeAssumerRole: true when this process runs with another identity (a
	// developer's AWS profile, say) and must first assume the assumer role.
	// false when it already runs as that role (ECS task role, EC2 profile).
	AssumeAssumerRole bool `yaml:"assume_assumer_role"`
	// AssumerRoleName is the role in our account that every customer trust
	// policy names.
	AssumerRoleName string `yaml:"assumer_role_name"`
	// CollectorRoleName / ForwardRuleName are what customers are told to call
	// the role and the EventBridge rule they create.
	CollectorRoleName string `yaml:"collector_role_name"`
	ForwardRuleName   string `yaml:"forward_rule_name"`
	// EventLogGroup is a fallback for the "events received" check when
	// ClickHouse is not configured: a CloudWatch Logs group that a rule on the
	// central bus writes every event to.
	EventLogGroup string `yaml:"event_log_group"`
	// EventLookbackHours is how far back that check looks for an event.
	EventLookbackHours int `yaml:"event_lookback_hours"`
}

// ClickHouseConfig holds the read-only connection to the CloudTrail event
// store. It is optional: when Host is empty ClickHouse is disabled and the API
// serves Postgres data only.
type ClickHouseConfig struct {
	Host     string `yaml:"host"`
	Port     int    `yaml:"port"`
	Database string `yaml:"database"`
	User     string `yaml:"user"`
	Password string `yaml:"password"`
	// Table is the CloudTrail events table; MonitoringTable is the genome
	// pipeline's log table. Both are required when ClickHouse is enabled: no
	// table name is built into the code.
	Table           string `yaml:"table"`
	MonitoringTable string `yaml:"monitoring_table"`
	TimeoutSeconds  int    `yaml:"timeout_seconds"`
	Secure          bool   `yaml:"secure"`
	// Protocol is "native" (TCP, default port 9000/9440) or "http" (port
	// 8123/8443). Use "http" when only the HTTP port is reachable, e.g. via a tunnel.
	Protocol string `yaml:"protocol"`
	// Rollup* name optional pre-aggregated tables (see
	// migrations/clickhouse/001_event_rollups.sql). Empty keeps the raw table.
	RollupHeatmap     string `yaml:"rollup_heatmap"`
	RollupCredentials string `yaml:"rollup_credentials"`
	RollupResources   string `yaml:"rollup_resources"`
	RollupIPs         string `yaml:"rollup_ips"`
}

// Enabled reports whether a ClickHouse host has been configured.
func (c ClickHouseConfig) Enabled() bool {
	return strings.TrimSpace(c.Host) != ""
}

type ServerConfig struct {
	Port int    `yaml:"port"`
	Host string `yaml:"host"`
}

type ScannerConfig struct {
	BaseURL      string `yaml:"base_url"`
	DashboardKey string `yaml:"dashboard_key"`
}

type DatabaseConfig struct {
	Host         string `yaml:"host"`
	DatabaseName string `yaml:"database_name"`
	User         string `yaml:"user"`
	Password     string `yaml:"password"`
	Schema       string `yaml:"schema"`

	// Pool sizing. RDS has a small max_connections budget shared by every
	// developer and service, so the defaults stay conservative.
	MaxOpenConns           int `yaml:"max_open_conns"`
	MaxIdleConns           int `yaml:"max_idle_conns"`
	ConnMaxIdleTimeMinutes int `yaml:"conn_max_idle_time_minutes"`
	ConnMaxLifetimeMinutes int `yaml:"conn_max_lifetime_minutes"`
}

func (d DatabaseConfig) DBName() string {
	return strings.TrimSpace(d.DatabaseName)
}

func (d DatabaseConfig) GetConnectionString() string {
	// Port and SSL are fixed in code — RDS and local both use 5432 + require.
	// No auto-upgrade, no fallback, no hints.
	const port = 5432
	const sslmode = "require"
	u := url.URL{
		Scheme: "postgres",
		User:   url.UserPassword(d.User, d.Password),
		Host:   net.JoinHostPort(d.Host, strconv.Itoa(port)),
		Path:   "/" + d.DBName(),
		RawQuery: url.Values{
			"sslmode":          []string{sslmode},
			"application_name": []string{"nhi-backend"},
		}.Encode(),
	}
	return u.String()
}

type JWTConfig struct {
	Secret           string `yaml:"secret"`
	AccessTTLMinutes int    `yaml:"access_ttl_minutes"`
	RefreshTTLHours  int    `yaml:"refresh_ttl_hours"`
}

// LoggingConfig controls the structured logger (env: NHI_LOG_LEVEL,
// NHI_LOG_FORMAT, NHI_SLOW_QUERY_MS).
type LoggingConfig struct {
	Level  string `yaml:"level"`  // debug | info | warn | error
	Format string `yaml:"format"` // json | text
	// SlowQueryMS is the duration above which a ClickHouse query is logged as
	// a warning. 0 means the default (1000).
	SlowQueryMS int `yaml:"slow_query_ms"`
}

type CORSConfig struct {
	AllowedOrigins []string `yaml:"allowed_origins"`
}

func Load() (*Config, error) {
	path := strings.TrimSpace(os.Getenv("NHI_CONFIG_FILE"))
	if path == "" {
		path = "configs/config.yaml"
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %q: %w", path, err)
	}
	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("parse config %q: %w", path, err)
	}
	if err := cfg.applyEnvironment(); err != nil {
		return nil, err
	}
	cfg.applyDefaults()
	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (c *Config) applyEnvironment() error {
	setString := func(dst *string, key string) {
		if value, ok := os.LookupEnv(key); ok && strings.TrimSpace(value) != "" {
			*dst = strings.TrimSpace(value)
		}
	}
	setInt := func(dst *int, key string) error {
		if value, ok := os.LookupEnv(key); ok && strings.TrimSpace(value) != "" {
			parsed, err := strconv.Atoi(strings.TrimSpace(value))
			if err != nil {
				return fmt.Errorf("config: %s must be an integer", key)
			}
			*dst = parsed
		}
		return nil
	}

	setString(&c.Server.Host, "NHI_SERVER_HOST")
	if err := setInt(&c.Server.Port, "NHI_SERVER_PORT"); err != nil {
		return err
	}

	setString(&c.Database.Host, "NHI_DB_HOST")
	setString(&c.Database.DatabaseName, "NHI_DB_NAME")
	setString(&c.Database.User, "NHI_DB_USER")
	setString(&c.Database.Password, "NHI_DB_PASSWORD")
	setString(&c.Database.Schema, "NHI_GLOBAL_SCHEMA")
	for dst, key := range map[*int]string{
		&c.Database.MaxOpenConns:           "NHI_DB_MAX_OPEN_CONNS",
		&c.Database.MaxIdleConns:           "NHI_DB_MAX_IDLE_CONNS",
		&c.Database.ConnMaxIdleTimeMinutes: "NHI_DB_CONN_MAX_IDLE_TIME_MINUTES",
		&c.Database.ConnMaxLifetimeMinutes: "NHI_DB_CONN_MAX_LIFETIME_MINUTES",
	} {
		if err := setInt(dst, key); err != nil {
			return err
		}
	}

	setString(&c.Logging.Level, "NHI_LOG_LEVEL")
	setString(&c.Logging.Format, "NHI_LOG_FORMAT")
	if err := setInt(&c.Logging.SlowQueryMS, "NHI_SLOW_QUERY_MS"); err != nil {
		return err
	}

	setString(&c.JWT.Secret, "NHI_JWT_SECRET")
	if err := setInt(&c.JWT.AccessTTLMinutes, "NHI_JWT_ACCESS_TTL_MINUTES"); err != nil {
		return err
	}
	if err := setInt(&c.JWT.RefreshTTLHours, "NHI_JWT_REFRESH_TTL_HOURS"); err != nil {
		return err
	}
	setString(&c.Scanner.BaseURL, "SECRET_SCANNER_BASE_URL")
	setString(&c.Scanner.DashboardKey, "SECRET_SCANNER_DASHBOARD_KEY")
	setString(&c.Scanner.BaseURL, "NHI_SCANNER_BASE_URL")
	setString(&c.Scanner.DashboardKey, "NHI_SCANNER_DASHBOARD_KEY")
	setString(&c.AWSIntegration.AssumerRoleName, "NHI_AWS_ASSUMER_ROLE_NAME")
	setString(&c.AWSIntegration.CollectorRoleName, "NHI_AWS_COLLECTOR_ROLE_NAME")
	setString(&c.AWSIntegration.ForwardRuleName, "NHI_AWS_FORWARD_RULE_NAME")
	setString(&c.AWSIntegration.EventLogGroup, "NHI_AWS_EVENT_LOG_GROUP")
	if err := setInt(&c.AWSIntegration.EventLookbackHours, "NHI_AWS_EVENT_LOOKBACK_HOURS"); err != nil {
		return err
	}
	if value, ok := os.LookupEnv("NHI_AWS_ASSUME_ASSUMER_ROLE"); ok && strings.TrimSpace(value) != "" {
		parsed, err := strconv.ParseBool(strings.TrimSpace(value))
		if err != nil {
			return fmt.Errorf("config: NHI_AWS_ASSUME_ASSUMER_ROLE must be true or false")
		}
		c.AWSIntegration.AssumeAssumerRole = parsed
	}
	setString(&c.ClickHouse.Host, "NHI_CLICKHOUSE_HOST")
	if err := setInt(&c.ClickHouse.Port, "NHI_CLICKHOUSE_PORT"); err != nil {
		return err
	}
	setString(&c.ClickHouse.Database, "NHI_CLICKHOUSE_DATABASE")
	setString(&c.ClickHouse.User, "NHI_CLICKHOUSE_USER")
	setString(&c.ClickHouse.Password, "NHI_CLICKHOUSE_PASSWORD")
	setString(&c.ClickHouse.Table, "NHI_CLICKHOUSE_TABLE")
	setString(&c.ClickHouse.MonitoringTable, "NHI_CLICKHOUSE_MONITORING_TABLE")
	setString(&c.ClickHouse.Protocol, "NHI_CLICKHOUSE_PROTOCOL")
	setString(&c.ClickHouse.RollupHeatmap, "NHI_CLICKHOUSE_ROLLUP_HEATMAP")
	setString(&c.ClickHouse.RollupCredentials, "NHI_CLICKHOUSE_ROLLUP_CREDENTIALS")
	setString(&c.ClickHouse.RollupResources, "NHI_CLICKHOUSE_ROLLUP_RESOURCES")
	setString(&c.ClickHouse.RollupIPs, "NHI_CLICKHOUSE_ROLLUP_IPS")
	if err := setInt(&c.ClickHouse.TimeoutSeconds, "NHI_CLICKHOUSE_TIMEOUT_SECONDS"); err != nil {
		return err
	}
	if value, ok := os.LookupEnv("NHI_CLICKHOUSE_SECURE"); ok && strings.TrimSpace(value) != "" {
		secure, err := strconv.ParseBool(strings.TrimSpace(value))
		if err != nil {
			return fmt.Errorf("config: NHI_CLICKHOUSE_SECURE must be true or false")
		}
		c.ClickHouse.Secure = secure
	}
	if origins := strings.TrimSpace(os.Getenv("NHI_CORS_ALLOWED_ORIGINS")); origins != "" {
		c.CORS.AllowedOrigins = make([]string, 0)
		for _, origin := range strings.Split(origins, ",") {
			origin = strings.TrimSpace(origin)
			if origin != "" {
				c.CORS.AllowedOrigins = append(c.CORS.AllowedOrigins, origin)
			}
		}
	}
	return nil
}

func (c *Config) applyDefaults() {
	if c.Server.Host == "" {
		c.Server.Host = "0.0.0.0"
	}
	if c.Server.Port == 0 {
		c.Server.Port = 8080
	}
	if c.Database.Schema == "" {
		c.Database.Schema = DefaultGlobalSchema
	}
	aws := &c.AWSIntegration
	aws.AssumerRoleName = strings.TrimSpace(aws.AssumerRoleName)
	if aws.AssumerRoleName == "" {
		aws.AssumerRoleName = "NHIPlatformAssumer"
	}
	aws.CollectorRoleName = strings.TrimSpace(aws.CollectorRoleName)
	if aws.CollectorRoleName == "" {
		aws.CollectorRoleName = "NHIPlatformCollector"
	}
	aws.ForwardRuleName = strings.TrimSpace(aws.ForwardRuleName)
	if aws.ForwardRuleName == "" {
		aws.ForwardRuleName = "nhi-forward-events"
	}
	aws.EventLogGroup = strings.TrimSpace(aws.EventLogGroup)
	if aws.EventLookbackHours == 0 {
		aws.EventLookbackHours = 24
	}
	if c.ClickHouse.Port == 0 {
		c.ClickHouse.Port = 9000
	}
	c.ClickHouse.Protocol = strings.ToLower(strings.TrimSpace(c.ClickHouse.Protocol))
	if c.ClickHouse.Protocol == "" {
		c.ClickHouse.Protocol = "native"
	}
	if c.ClickHouse.TimeoutSeconds == 0 {
		c.ClickHouse.TimeoutSeconds = 5
	}
	if c.Database.MaxOpenConns == 0 {
		c.Database.MaxOpenConns = 10
	}
	if c.Database.MaxIdleConns == 0 {
		c.Database.MaxIdleConns = 5
	}
	if c.Database.ConnMaxIdleTimeMinutes == 0 {
		c.Database.ConnMaxIdleTimeMinutes = 2
	}
	if c.Database.ConnMaxLifetimeMinutes == 0 {
		c.Database.ConnMaxLifetimeMinutes = 30
	}
}

func (c *Config) validate() error {
	if c.Server.Port < 1 || c.Server.Port > 65535 {
		return fmt.Errorf("config: server.port must be between 1 and 65535")
	}
	if strings.TrimSpace(c.Server.Host) == "" {
		return fmt.Errorf("config: server.host is required")
	}
	if c.Database.DBName() == "" || !databaseNameRE.MatchString(c.Database.DBName()) {
		return fmt.Errorf("config: database.database_name must be a valid PostgreSQL database name")
	}
	if strings.TrimSpace(c.Database.Host) == "" || strings.TrimSpace(c.Database.User) == "" {
		return fmt.Errorf("config: database.host and database.user are required")
	}
	if c.Database.Password == "" {
		return fmt.Errorf("config: database.password is required (set NHI_DB_PASSWORD)")
	}
	if c.Database.MaxOpenConns < 1 || c.Database.MaxIdleConns < 0 || c.Database.MaxIdleConns > c.Database.MaxOpenConns {
		return fmt.Errorf("config: database.max_open_conns must be >= 1 and max_idle_conns must be between 0 and max_open_conns")
	}
	if c.Database.ConnMaxIdleTimeMinutes < 1 || c.Database.ConnMaxLifetimeMinutes < 1 {
		return fmt.Errorf("config: database.conn_max_idle_time_minutes and conn_max_lifetime_minutes must be >= 1")
	}
	if strings.TrimSpace(c.JWT.Secret) == "" || len(c.JWT.Secret) < 32 {
		return fmt.Errorf("config: jwt.secret must be at least 32 characters")
	}
	if c.JWT.AccessTTLMinutes < 1 || c.JWT.AccessTTLMinutes > 24*60 {
		return fmt.Errorf("config: jwt.access_ttl_minutes must be between 1 and 1440")
	}
	if c.JWT.RefreshTTLHours < 1 || c.JWT.RefreshTTLHours > 24*90 {
		return fmt.Errorf("config: jwt.refresh_ttl_hours must be between 1 and 2160")
	}
	if time.Duration(c.JWT.RefreshTTLHours)*time.Hour <= time.Duration(c.JWT.AccessTTLMinutes)*time.Minute {
		return fmt.Errorf("config: jwt.refresh_ttl_hours must be longer than jwt.access_ttl_minutes")
	}
	if !schemaNameRE.MatchString(c.Database.Schema) {
		return fmt.Errorf("config: database.schema (global schema) must be a valid identifier")
	}
	// Empty values mean "use the default", which applyDefaults fills in.
	aws := c.AWSIntegration
	if (aws.AssumerRoleName != "" && !iamNameRE.MatchString(aws.AssumerRoleName)) ||
		(aws.CollectorRoleName != "" && !iamNameRE.MatchString(aws.CollectorRoleName)) {
		return fmt.Errorf("config: aws_integration role names must be valid IAM role names")
	}
	if aws.ForwardRuleName != "" && !ruleNameRE.MatchString(aws.ForwardRuleName) {
		return fmt.Errorf("config: aws_integration.forward_rule_name must be a valid EventBridge rule name")
	}
	if aws.EventLogGroup != "" && !logGroupNameRE.MatchString(aws.EventLogGroup) {
		return fmt.Errorf("config: aws_integration.event_log_group is not a valid CloudWatch Logs group name")
	}
	if aws.EventLookbackHours != 0 && (aws.EventLookbackHours < 1 || aws.EventLookbackHours > 24*14) {
		return fmt.Errorf("config: aws_integration.event_lookback_hours must be between 1 and 336")
	}
	if c.ClickHouse.Enabled() {
		ch := c.ClickHouse
		if ch.Port < 1 || ch.Port > 65535 {
			return fmt.Errorf("config: clickhouse.port must be between 1 and 65535")
		}
		if strings.TrimSpace(ch.Database) == "" || !databaseNameRE.MatchString(ch.Database) {
			return fmt.Errorf("config: clickhouse.database must be a valid identifier")
		}
		// Table names are interpolated into SQL, so each must be a plain identifier.
		for _, t := range []struct {
			env, val string
			optional bool
		}{
			{"NHI_CLICKHOUSE_TABLE", ch.Table, false},
			{"NHI_CLICKHOUSE_MONITORING_TABLE", ch.MonitoringTable, false},
			{"NHI_CLICKHOUSE_ROLLUP_HEATMAP", ch.RollupHeatmap, true},
			{"NHI_CLICKHOUSE_ROLLUP_CREDENTIALS", ch.RollupCredentials, true},
			{"NHI_CLICKHOUSE_ROLLUP_RESOURCES", ch.RollupResources, true},
			{"NHI_CLICKHOUSE_ROLLUP_IPS", ch.RollupIPs, true},
		} {
			if t.val == "" && t.optional {
				continue
			}
			if t.val == "" {
				return fmt.Errorf("config: %s is required when ClickHouse is enabled", t.env)
			}
			if !databaseNameRE.MatchString(t.val) {
				return fmt.Errorf("config: %s must be a valid identifier", t.env)
			}
		}
		if ch.Protocol != "native" && ch.Protocol != "http" {
			return fmt.Errorf("config: clickhouse.protocol must be native or http")
		}
		if ch.TimeoutSeconds < 1 || ch.TimeoutSeconds > 60 {
			return fmt.Errorf("config: clickhouse.timeout_seconds must be between 1 and 60")
		}
	}
	return nil
}

// ValidateSchemaName rejects unsafe or malformed tenant schema names before
// they are used to qualify queries.
func ValidateSchemaName(name string) error {
	if !schemaNameRE.MatchString(strings.TrimSpace(name)) {
		return fmt.Errorf("invalid tenant schema name")
	}
	return nil
}
