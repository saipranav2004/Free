-- Pre-aggregated rollups of cloudtrail_events for the Identity Event Graph
-- sections heatmap, credentials, resources and ips. Applied manually on
-- ClickHouse: select the target database first (USE <db>), then run every
-- statement. The source table is cloudtrail_events; if yours is named
-- differently, change it in the four FROM clauses. After creating the tables,
-- backfill and set NHI_CLICKHOUSE_ROLLUP_* to the rollup_* names used here.
--
-- Every key keeps the subject columns (caller_arn, session_issuer_arn,
-- access_key_id), account_id (tenant isolation) and event_source (service
-- filter), so the API's WHERE clause works unchanged.
-- Caveat: rollups aggregate every INSERT. Duplicate event_ids that the raw
-- ReplacingMergeTree drops on merge are counted twice here.

-- 1. heatmap: action x hour
CREATE TABLE IF NOT EXISTS rollup_heatmap_hourly (
    bucket DateTime, account_id LowCardinality(String), caller_arn String,
    session_issuer_arn String, access_key_id String,
    event_source LowCardinality(String), event_name LowCardinality(String),
    c AggregateFunction(count)
) ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMM(bucket)
ORDER BY (account_id, caller_arn, session_issuer_arn, access_key_id, event_source, event_name, bucket)
TTL bucket + INTERVAL 180 DAY;

CREATE MATERIALIZED VIEW IF NOT EXISTS rollup_heatmap_hourly_mv TO rollup_heatmap_hourly AS
SELECT toStartOfHour(event_time) AS bucket, account_id, caller_arn, session_issuer_arn, access_key_id,
       event_source, event_name, countState() AS c
FROM cloudtrail_events
GROUP BY bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source, event_name;

-- 2. credentials: usage per credential per day
CREATE TABLE IF NOT EXISTS rollup_credentials_daily (
    bucket DateTime, account_id LowCardinality(String), caller_arn String,
    session_issuer_arn String, access_key_id String,
    event_source LowCardinality(String),
    c AggregateFunction(count),
    first_seen AggregateFunction(min, DateTime64(3, 'UTC')),
    last_seen AggregateFunction(max, DateTime64(3, 'UTC')),
    actions AggregateFunction(groupUniqArray(20), String),
    resources AggregateFunction(uniqExact, String)
) ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMM(bucket)
ORDER BY (account_id, caller_arn, session_issuer_arn, access_key_id, event_source, bucket)
TTL bucket + INTERVAL 180 DAY;

CREATE MATERIALIZED VIEW IF NOT EXISTS rollup_credentials_daily_mv TO rollup_credentials_daily AS
SELECT toStartOfDay(event_time) AS bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source,
       countState() AS c, minState(event_time) AS first_seen, maxState(event_time) AS last_seen,
       groupUniqArrayState(20)(event_name) AS actions, uniqExactState(resource_arn) AS resources
FROM cloudtrail_events
GROUP BY bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source;

-- 3. resources: per resource per day
CREATE TABLE IF NOT EXISTS rollup_resources_daily (
    bucket DateTime, account_id LowCardinality(String), caller_arn String,
    session_issuer_arn String, access_key_id String,
    event_source LowCardinality(String), resource_arn String, resource_type LowCardinality(String),
    c AggregateFunction(count),
    reads AggregateFunction(sum, UInt8),
    writes AggregateFunction(sum, UInt8),
    errors AggregateFunction(countIf, UInt8),
    actions AggregateFunction(groupUniqArray(20), String),
    first_seen AggregateFunction(min, DateTime64(3, 'UTC')),
    last_seen AggregateFunction(max, DateTime64(3, 'UTC'))
) ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMM(bucket)
ORDER BY (account_id, caller_arn, session_issuer_arn, access_key_id, event_source, resource_arn, resource_type, bucket)
TTL bucket + INTERVAL 180 DAY;

CREATE MATERIALIZED VIEW IF NOT EXISTS rollup_resources_daily_mv TO rollup_resources_daily AS
SELECT toStartOfDay(event_time) AS bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source,
       resource_arn, resource_type,
       countState() AS c, sumState(is_read_only) AS reads, sumState(toUInt8(1 - is_read_only)) AS writes,
       countIfState(error_code != '') AS errors,
       groupUniqArrayState(20)(event_name) AS actions,
       minState(event_time) AS first_seen, maxState(event_time) AS last_seen
FROM cloudtrail_events
WHERE resource_arn != ''
GROUP BY bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source, resource_arn, resource_type;

-- 4. ips: per source address per day
CREATE TABLE IF NOT EXISTS rollup_ips_daily (
    bucket DateTime, account_id LowCardinality(String), caller_arn String,
    session_issuer_arn String, access_key_id String,
    event_source LowCardinality(String), source_ip String,
    c AggregateFunction(count),
    first_seen AggregateFunction(min, DateTime64(3, 'UTC')),
    last_seen AggregateFunction(max, DateTime64(3, 'UTC'))
) ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMM(bucket)
ORDER BY (account_id, caller_arn, session_issuer_arn, access_key_id, event_source, source_ip, bucket)
TTL bucket + INTERVAL 180 DAY;

CREATE MATERIALIZED VIEW IF NOT EXISTS rollup_ips_daily_mv TO rollup_ips_daily AS
SELECT toStartOfDay(event_time) AS bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source,
       source_ip, countState() AS c, minState(event_time) AS first_seen, maxState(event_time) AS last_seen
FROM cloudtrail_events
WHERE source_ip != ''
GROUP BY bucket, account_id, caller_arn, session_issuer_arn, access_key_id, event_source, source_ip;

-- Backfill existing data ONCE, after the MVs exist (events arriving during the
-- backfill can be double counted; run it in a quiet window or bound by time):
--   INSERT INTO rollup_heatmap_hourly SELECT <same SELECT as the MV> FROM cloudtrail_events WHERE event_time < now() - INTERVAL 1 HOUR ...
-- Use the SELECT of each *_mv above verbatim, with a matching event_time bound.
