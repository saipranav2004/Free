import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Metric tile.
// ---------------------------------------------------------------------------
// Not a "stat card with a big coloured circle" — an enterprise metric plate:
// a hairline-framed surface with an accent rail keyed to the metric's tone, a
// small-caps label, a large tabular figure, and a quiet supporting line. The
// number is the loudest thing on it; everything else recedes.
//
// Purely presentational: `value` is rendered exactly as passed in, so counts
// and their loading state behave identically to before.
export function StatCard({ label, value, icon: Icon, tone = 'default', hint, loading, footer, className }) {
  const t = TONES[tone] || TONES.default
  return (
    <div
      className={clsx(
        'group relative flex h-full flex-col overflow-hidden rounded-xl border border-surface-700/70 bg-surface-900 shadow-card',
        'transition-[border-color,box-shadow,transform] duration-200 hover:-translate-y-0.5 hover:border-surface-600 hover:shadow-raised',
        className
      )}
    >
      {/* Accent rail — the only colour on the plate when idle. */}
      <span aria-hidden="true" className={clsx('absolute inset-y-0 left-0 w-[3px]', t.rail)} />

      <div className="flex items-start justify-between gap-3 p-4 pl-5">
        <div className="min-w-0">
          <p className="truncate text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">{label}</p>
          <div className="mt-2 flex items-baseline gap-2">
            {loading ? (
              <span className="skeleton inline-block h-8 w-16 rounded-md" aria-hidden="true" />
            ) : (
              <span className="text-[1.75rem] font-semibold leading-none tabular-nums tracking-tight text-ink-50">
                {value}
              </span>
            )}
          </div>
          {hint && <p className="mt-2 text-xs leading-relaxed text-ink-500">{hint}</p>}
        </div>

        {Icon && (
          <span
            className={clsx(
              'flex h-9 w-9 flex-none items-center justify-center rounded-lg ring-1 ring-inset transition-colors',
              t.chip
            )}
          >
            <Icon className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
          </span>
        )}
      </div>

      {footer && (
        <div className="mt-auto border-t border-surface-800 px-5 py-2.5 text-xs text-ink-500">{footer}</div>
      )}
    </div>
  )
}

const TONES = {
  default: {
    rail: 'bg-blue-500/70',
    chip: 'bg-blue-50 text-blue-600 ring-blue-600/15 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-500/25',
  },
  amber: {
    rail: 'bg-amber-500/80',
    chip: 'bg-amber-50 text-amber-600 ring-amber-600/15 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25',
  },
  emerald: {
    rail: 'bg-emerald-500/80',
    chip: 'bg-emerald-50 text-emerald-600 ring-emerald-600/15 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25',
  },
  red: {
    rail: 'bg-red-500/80',
    chip: 'bg-red-50 text-red-600 ring-red-600/15 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25',
  },
  purple: {
    rail: 'bg-purple-500/80',
    chip: 'bg-purple-50 text-purple-600 ring-purple-600/15 dark:bg-purple-500/10 dark:text-purple-300 dark:ring-purple-500/25',
  },
}
