import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useCallback, useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  LayoutDashboard, Boxes, Vault, Radio, KeyRound, ScrollText,
  LogOut, Settings as SettingsIcon, Users, Lock, FileKey2,
  ClipboardList, Archive, Menu, X, PanelLeftClose, PanelLeftOpen, ShieldCheck,
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { me, logout as logoutApi } from '../../api/auth'
import { ROLE_BADGE } from '../../config/constants'
import { Badge } from './Badge'
import { ThemeToggle } from './ThemeToggle'
import { toast } from 'sonner'
import logoWordmark from '../../assets/logo-wordmark.png'
import logoWordmarkDark from '../../assets/logo-wordmark-dark.png'
import logoMark from '../../assets/logo-mark.png'

// Self-service — visible to every authenticated user, regardless of role.
const CONSOLE_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/resources', label: 'Resources', icon: Boxes },
  { to: '/vault', label: 'Vault', icon: Vault },
  { to: '/sessions', label: 'Sessions', icon: Radio },
  { to: '/jit', label: 'JIT Access', icon: KeyRound },
  { to: '/audit', label: 'Audit', icon: ScrollText },
]

// Admin Center — only rendered for accounts holding the "admin" or "root"
// role (see AdminRoute for the matching route guard). This is PAM's own
// central control plane now; there is no separate admin login, just a
// section of the same console that appears once the JWT says you're allowed
// to see it.
const ADMIN_NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/identity', label: 'Identity', icon: Users },
  { to: '/admin/roles', label: 'Roles', icon: Lock },
  { to: '/admin/policies', label: 'Policies', icon: FileKey2 },
  { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound },
  { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
  { to: '/admin/vault-ops', label: 'Vault Operations', icon: Archive },
]

const SIDEBAR_STORAGE_KEY = 'pam_sidebar_collapsed'

// Sidebar starts OPEN. It only stays collapsed if this user explicitly
// collapsed it before (persisted per browser) — a missing/invalid value
// always resolves to open.
function readCollapsed() {
  try {
    return localStorage.getItem(SIDEBAR_STORAGE_KEY) === '1'
  } catch {
    return false
  }
}

function NavItem({ to, label, icon: Icon, end, onNavigate, collapsed }) {
  return (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      title={collapsed ? label : undefined}
      className={({ isActive }) =>
        clsx(
          'group relative flex items-center rounded-lg text-sm font-medium outline-none transition-colors',
          collapsed ? 'h-10 w-10 justify-center' : 'h-9 gap-3 px-3',
          isActive
            ? 'bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-200'
            : 'text-ink-400 hover:bg-surface-800 hover:text-ink-50'
        )
      }
    >
      {({ isActive }) => (
        <>
          {/* Active rail — the enterprise-console convention for "you are
              here", readable at a glance even in the collapsed rail. */}
          <span
            aria-hidden="true"
            className={clsx(
              'absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full transition-opacity',
              isActive ? 'bg-blue-600 opacity-100 dark:bg-blue-400' : 'opacity-0'
            )}
          />
          <Icon
            className={clsx('h-[1.05rem] w-[1.05rem] flex-none', isActive ? 'text-blue-600 dark:text-blue-300' : 'text-ink-500 group-hover:text-ink-200')}
            strokeWidth={1.75}
          />
          {!collapsed && <span className="truncate">{label}</span>}
        </>
      )}
    </NavLink>
  )
}

function NavSection({ label, items, collapsed, onNavigate }) {
  return (
    <div>
      {!collapsed && label && (
        <p className="px-3 pb-1.5 pt-1 text-2xs font-semibold uppercase tracking-[0.1em] text-ink-500">{label}</p>
      )}
      {collapsed && label && <div className="mx-auto mb-2 h-px w-6 bg-surface-700" aria-hidden="true" />}
      <div className={clsx('space-y-0.5', collapsed && 'flex flex-col items-center')}>
        {items.map((item) => (
          <NavItem key={item.to} {...item} collapsed={collapsed} onNavigate={onNavigate} />
        ))}
      </div>
    </div>
  )
}

// The brand block. The wordmark is the product logo asset (two tone-matched
// variants so it stays legible in both themes); the line under it is the
// console title, which is role-dependent — administrators operate the
// identity control plane ("IAM Console"), everyone else sees the privileged
// access console ("PAM Console").
function SidebarBrand({ collapsed, consoleTitle }) {
  return (
    <div className={clsx('flex flex-none flex-col border-b border-surface-800', collapsed ? 'items-center px-2 py-4' : 'px-4 py-4')}>
      {collapsed ? (
        <img src={logoMark} alt="Deep Algorithms" className="h-8 w-8 object-contain" />
      ) : (
        <>
          {/* Two tone-matched variants of the same asset — the theme is a
              class on <html>, not an OS preference, so the swap is a CSS
              class swap rather than a <picture> media query. */}
          <img src={logoWordmark} alt="Deep Algorithms" className="h-6 w-auto self-start object-contain object-left dark:hidden" />
          <img src={logoWordmarkDark} alt="" aria-hidden="true" className="hidden h-6 w-auto self-start object-contain object-left dark:block" />
          <div className="mt-3 flex items-center gap-2">
            <ShieldCheck className="h-3.5 w-3.5 flex-none text-blue-600 dark:text-blue-400" strokeWidth={2} />
            <h1 className="truncate text-[0.8125rem] font-semibold uppercase tracking-[0.11em] text-ink-100">
              {consoleTitle}
            </h1>
          </div>
        </>
      )}
    </div>
  )
}

function SidebarContent({ isAdmin, onNavigate, collapsed, consoleTitle }) {
  return (
    <>
      <SidebarBrand collapsed={collapsed} consoleTitle={consoleTitle} />

      <nav
        aria-label="Primary"
        className={clsx('flex-1 space-y-5 overflow-y-auto overflow-x-hidden py-4', collapsed ? 'px-2' : 'px-3')}
      >
        <NavSection label={collapsed ? null : 'Console'} items={CONSOLE_NAV} collapsed={collapsed} onNavigate={onNavigate} />
        {isAdmin && (
          <NavSection label="Admin Center" items={ADMIN_NAV} collapsed={collapsed} onNavigate={onNavigate} />
        )}
      </nav>
    </>
  )
}

function initialsOf(name) {
  if (!name) return '—'
  const parts = String(name).replace(/[._-]+/g, ' ').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '—'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

function Avatar({ name, size = 'md' }) {
  return (
    <span
      aria-hidden="true"
      className={clsx(
        'flex flex-none items-center justify-center rounded-lg bg-blue-600 font-semibold uppercase tracking-wide text-white ring-1 ring-inset ring-white/15',
        size === 'sm' ? 'h-7 w-7 text-2xs' : 'h-8 w-8 text-xs'
      )}
    >
      {initialsOf(name)}
    </span>
  )
}

export function AppLayout() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const setUser = useAuthStore((s) => s.setUser)
  const doLogout = useAuthStore((s) => s.logout)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(readCollapsed)

  // Role-dependent console title (see SidebarBrand).
  const consoleTitle = isAdmin ? 'IAM Console' : 'PAM Console'

  const toggleCollapsed = useCallback(() => {
    setCollapsed((v) => {
      const next = !v
      try {
        localStorage.setItem(SIDEBAR_STORAGE_KEY, next ? '1' : '0')
      } catch {
        // Storage can be unavailable (private mode / locked-down profile) —
        // the toggle still works for this session, it just won't persist.
      }
      return next
    })
  }, [])

  // /auth/me is the source of truth for "who am I" — login only returns
  // access_token/expires_at, not the user's profile, so this fetch is what
  // actually populates the header/username/roles rather than showing blank
  // (and is also what AdminRoute/the nav's isAdmin() check depends on).
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal), retry: false })

  useEffect(() => {
    if (meQuery.data) setUser(meQuery.data)
  }, [meQuery.data, setUser])

  // Close the mobile drawer on Escape — a drawer you can only dismiss by
  // hitting a small X is a real accessibility gap.
  useEffect(() => {
    if (!mobileNavOpen) return undefined
    const onKey = (e) => e.key === 'Escape' && setMobileNavOpen(false)
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [mobileNavOpen])

  const handleLogout = async () => {
    try {
      await logoutApi()
    } catch {
      // Even if the server-side logout call fails (network blip, already
      // expired token), we still clear the local session below — a failed
      // logout call must never leave the user stuck "logged in" client-side
      // when they explicitly asked to log out.
    } finally {
      doLogout()
      navigate('/login', { replace: true })
      toast.success('Logged out')
    }
  }

  const roles = user?.roles || []
  const displayName = user?.username || (meQuery.isLoading ? '…' : 'Signed in')

  return (
    // h-screen + overflow-hidden pins this whole shell to exactly the
    // viewport height, so the browser's own document scrollbar never kicks
    // in. Previously this was min-h-screen, which lets the container grow
    // taller than the viewport with tall page content — at that point the
    // *document* scrolls, dragging the sidebar along with everything else
    // instead of leaving it in place. Now only <main> below scrolls
    // internally; the sidebar (and topbar) stay fixed on screen.
    <div className="flex h-screen overflow-hidden bg-surface-950">
      {/* Desktop sidebar — bounded to the parent's h-screen height via flex
          stretch; the nav list inside SidebarContent scrolls internally
          (overflow-y-auto) while SidebarFooter stays pinned at the bottom.
          Open by default; collapsing narrows it to an icon rail. */}
      <aside
        className={clsx(
          'hidden flex-none flex-col border-r border-surface-800 bg-surface-900 transition-[width] duration-200 ease-emphasis md:flex',
          collapsed ? 'w-[4.5rem]' : 'w-[16.5rem]'
        )}
      >
        <SidebarContent isAdmin={isAdmin} onNavigate={() => {}} collapsed={collapsed} consoleTitle={consoleTitle} />
        <SidebarFooter
          user={user}
          roles={roles}
          loadingUser={meQuery.isLoading}
          onLogout={handleLogout}
          collapsed={collapsed}
        />
      </aside>

      {/* Mobile sidebar (overlay) */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div
            className="animate-overlay-in fixed inset-0 bg-slate-950/55 backdrop-blur-[3px] dark:bg-black/70"
            onClick={() => setMobileNavOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative flex w-[17rem] flex-col border-r border-surface-800 bg-surface-900 shadow-overlay">
            <button
              onClick={() => setMobileNavOpen(false)}
              className="absolute right-3 top-3.5 flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-50"
              aria-label="Close menu"
            >
              <X className="h-4 w-4" strokeWidth={2} />
            </button>
            <SidebarContent
              isAdmin={isAdmin}
              onNavigate={() => setMobileNavOpen(false)}
              collapsed={false}
              consoleTitle={consoleTitle}
            />
            <SidebarFooter
              user={user}
              roles={roles}
              loadingUser={meQuery.isLoading}
              onLogout={handleLogout}
              collapsed={false}
            />
          </aside>
        </div>
      )}

      {/* min-h-0 overrides flex's default min-height:auto — without it, a
          flex child (main, below) can't shrink below its content height,
          so overflow-y-auto never actually engages and the page scrolls as
          a whole instead of just the content area. */}
      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="z-20 flex h-14 flex-none items-center gap-2 border-b border-surface-800 bg-surface-900/80 px-3 backdrop-blur-md sm:px-4">
          <button
            onClick={() => setMobileNavOpen(true)}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-50 md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
          </button>

          <button
            onClick={toggleCollapsed}
            className="hidden h-9 w-9 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-50 md:flex"
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-pressed={collapsed}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? (
              <PanelLeftOpen className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
            ) : (
              <PanelLeftClose className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
            )}
          </button>

          {/* Product mark on small screens, where the sidebar (and its
              brand block) is off-canvas. */}
          <div className="flex min-w-0 flex-1 items-center gap-2.5 md:hidden">
            <img src={logoMark} alt="Deep Algorithms" className="h-6 w-6 flex-none object-contain" />
            <span className="truncate text-xs font-semibold uppercase tracking-[0.11em] text-ink-100">
              {consoleTitle}
            </span>
          </div>
          <div className="hidden flex-1 md:block" />

          <ThemeToggle compact />

          <div className="mx-1 hidden h-5 w-px bg-surface-700 sm:block" aria-hidden="true" />

          <div className="relative">
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={userMenuOpen}
              className="flex items-center gap-2.5 rounded-lg py-1 pl-1 pr-2 text-sm text-ink-200 transition-colors hover:bg-surface-800"
            >
              <Avatar name={user?.username} />
              <span className="hidden max-w-[11rem] truncate font-medium sm:inline" title={user?.username}>
                {displayName}
              </span>
            </button>
            {userMenuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
                <div
                  role="menu"
                  className="animate-menu-in absolute right-0 z-20 mt-2 w-60 overflow-hidden rounded-xl border border-surface-700 bg-surface-900 shadow-overlay"
                >
                  <div className="flex items-center gap-3 border-b border-surface-800 px-3.5 py-3">
                    <Avatar name={user?.username} />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-ink-50">{user?.username || '—'}</p>
                      <p className="truncate text-xs text-ink-500">{user?.email || '—'}</p>
                    </div>
                  </div>
                  {roles.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 border-b border-surface-800 px-3.5 py-2.5">
                      {roles.map((r) => (
                        <Badge key={r} className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                          {r}
                        </Badge>
                      ))}
                    </div>
                  )}
                  <div className="p-1.5">
                    <NavLink
                      to="/settings"
                      role="menuitem"
                      onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-ink-200 transition-colors hover:bg-surface-800 hover:text-ink-50"
                    >
                      <SettingsIcon className="h-4 w-4 text-ink-500" strokeWidth={1.75} /> Settings
                    </NavLink>
                    <button
                      role="menuitem"
                      onClick={handleLogout}
                      className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm font-medium text-red-600 transition-colors hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                    >
                      <LogOut className="h-4 w-4" strokeWidth={1.75} /> Log out
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </header>

        <main className="min-w-0 flex-1 overflow-y-auto">
          <div className="mx-auto max-w-[80rem] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}

function SidebarFooter({ user, roles, loadingUser, onLogout, collapsed }) {
  if (collapsed) {
    return (
      <div className="flex flex-none flex-col items-center gap-2 border-t border-surface-800 p-2.5">
        <Avatar name={user?.username} size="sm" />
        <button
          onClick={onLogout}
          className="flex h-9 w-9 items-center justify-center rounded-lg text-ink-500 transition-colors hover:bg-surface-800 hover:text-red-600 dark:hover:text-red-400"
          title="Log out"
          aria-label="Log out"
        >
          <LogOut className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </div>
    )
  }

  return (
    <div className="flex-none border-t border-surface-800 p-3">
      <div className="flex items-center gap-2.5 rounded-lg border border-surface-700/70 bg-surface-850 px-2.5 py-2">
        <Avatar name={user?.username} size="sm" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-semibold text-ink-100" title={user?.username}>
            {user?.username || (loadingUser ? '…' : 'Signed in')}
          </p>
          <div className="mt-1 flex flex-wrap gap-1">
            {roles.length === 0 && !loadingUser && (
              <Badge className="bg-ink-500/10 text-ink-500 ring-ink-500/25">no roles</Badge>
            )}
            {roles.map((r) => (
              <Badge key={r} className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                {r}
              </Badge>
            ))}
          </div>
        </div>
        <button
          onClick={onLogout}
          className="flex h-8 w-8 flex-none items-center justify-center rounded-lg text-ink-500 transition-colors hover:bg-surface-800 hover:text-red-600 dark:hover:text-red-400"
          title="Log out"
          aria-label="Log out"
        >
          <LogOut className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </div>
    </div>
  )
}
