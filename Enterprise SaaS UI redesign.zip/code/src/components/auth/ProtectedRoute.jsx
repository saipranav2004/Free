import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'

// Redirects to /login with the attempted location preserved in router state
// (LoginPage reads `location.state.from` so a deep link like
// /jit/requests/abc123 that got interrupted by a login redirect actually
// lands the user back where they meant to go, instead of always dumping
// them on the dashboard root after signing in.
export function ProtectedRoute() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated())
  const location = useLocation()

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />
  }
  return <Outlet />
}
