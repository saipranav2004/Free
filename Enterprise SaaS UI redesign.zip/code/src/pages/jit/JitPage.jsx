import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { toast } from 'sonner'
import { Plus, ShieldAlert, ArrowRight, Info } from 'lucide-react'
import { listMyJitRequests, listMyGrants, cancelJitRequest } from '../../api/jit'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { TabBar } from '../../components/common/TabBar'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { CreateJitRequestModal } from '../../components/jit/CreateJitRequestModal'
import { formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  JIT_STATUS,
  JIT_STATUS_LABELS,
  JIT_STATUS_BADGE,
  GRANT_STATUS,
  GRANT_STATUS_BADGE,
  DEFAULT_PAGE_SIZE,
} from '../../config/constants'

const TABS = [
  { key: 'requests', label: 'My Requests' },
  { key: 'grants', label: 'My Grants' },
]

// Requests in these two states are the only ones a self-service user can
// still back out of — anything already APPROVED/DENIED/CANCELLED/EXPIRED
// is a done deal (the backend's own cancel endpoint would 409 on those).
const CANCELLABLE_STATUSES = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

const selectClass =
  'rounded-md border border-surface-700 bg-surface-800 px-2.5 py-1.5 text-sm text-ink-100 focus:border-blue-500 focus:outline-none focus:ring-[3px] focus:ring-blue-500/20'

export default function JitPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [tab, setTab] = useState('requests')
  const [requestStatus, setRequestStatus] = useState('')
  const [grantStatus, setGrantStatus] = useState('')
  const [page, setPage] = useState(1)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalBreakglass, setModalBreakglass] = useState(false)
  const [cancelTarget, setCancelTarget] = useState(null)
  const queryClient = useQueryClient()

  // Reset to page 1 whenever the tab or its filter changes — otherwise a
  // stale page number from one filter/tab combination can carry over into a
  // result set that doesn't have that many pages.
  const changeTab = (next) => {
    setTab(next)
    setPage(1)
  }
  const changeRequestStatus = (next) => {
    setRequestStatus(next)
    setPage(1)
  }
  const changeGrantStatus = (next) => {
    setGrantStatus(next)
    setPage(1)
  }

  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', { page, status: requestStatus }],
    queryFn: ({ signal }) =>
      listMyJitRequests({ page, pageSize: DEFAULT_PAGE_SIZE, status: requestStatus || undefined, signal }),
    enabled: tab === 'requests',
  })

  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', { page, status: grantStatus }],
    queryFn: ({ signal }) =>
      listMyGrants({ page, pageSize: DEFAULT_PAGE_SIZE, status: grantStatus || undefined, signal }),
    enabled: tab === 'grants',
  })

  const activeQuery = tab === 'requests' ? requestsQuery : grantsQuery

  const cancelMutation = useMutation({
    mutationFn: ({ id, reason }) => cancelJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request cancelled')
      setCancelTarget(null)
      queryClient.invalidateQueries({ queryKey: ['jit'] })
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setCancelTarget(null)
    },
  })

  const openNewRequest = () => {
    setModalBreakglass(false)
    setModalOpen(true)
  }
  const openBreakglass = () => {
    setModalBreakglass(true)
    setModalOpen(true)
  }

  const requests = requestsQuery.data?.requests
  const grants = grantsQuery.data?.grants
  const pagination = activeQuery.data?.pagination

  return (
    <div>
      <PageHeader
        title="Just-in-Time Access"
        description="Request time-boxed access to JIT-gated resources and track requests and grants you personally made."
        actions={
          <>
            <button
              onClick={openBreakglass}
              className="flex items-center gap-1.5 rounded-lg border border-red-300 transition-colors dark:border-red-900/50 px-3 py-1.5 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30"
            >
              <ShieldAlert className="h-4 w-4" /> Emergency access
            </button>
            <button
              onClick={openNewRequest}
              className="flex items-center gap-1.5 h-9 rounded-lg bg-blue-600 px-3.5 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700"
            >
              <Plus className="h-4 w-4" /> New request
            </button>
          </>
        }
      />

      {isAdmin && (
        <div className="mb-4 flex items-center justify-between gap-3 rounded-md border border-blue-300 dark:border-blue-800/40 bg-blue-50 dark:bg-blue-950/20 px-4 py-2.5">
          <p className="flex items-center gap-2 text-sm text-blue-700 dark:text-blue-200">
            <Info className="h-4 w-4 flex-none" />
            This page only shows requests and grants <strong>you personally</strong> made. To review
            and approve requests from everyone in the org, use JIT Approvals.
          </p>
          <Link
            to="/admin/jit"
            className="flex flex-none items-center gap-1 text-sm font-medium text-blue-700 dark:text-blue-300 hover:underline"
          >
            JIT Approvals <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      )}

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <TabBar tabs={TABS} active={tab} onChange={changeTab} />

        {tab === 'requests' ? (
          <select
            value={requestStatus}
            onChange={(e) => changeRequestStatus(e.target.value)}
            className={selectClass}
          >
            <option value="">All statuses</option>
            {Object.values(JIT_STATUS).map((s) => (
              <option key={s} value={s}>
                {JIT_STATUS_LABELS[s] || s}
              </option>
            ))}
          </select>
        ) : (
          <select
            value={grantStatus}
            onChange={(e) => changeGrantStatus(e.target.value)}
            className={selectClass}
          >
            <option value="">All statuses</option>
            {Object.values(GRANT_STATUS).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        )}
      </div>

      <Card>
        {tab === 'requests' ? (
          <QueryState
            query={requestsQuery}
            empty={(d) => !d?.requests || d.requests.length === 0}
            emptyMessage="No JIT requests yet."
          >
            {() => (
              <>
                <ul className="divide-y divide-surface-800">
                  {requests.map((r) => (
                    <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
                      <Link to={`/jit/requests/${r.id}`} className="min-w-0 flex-1 hover:opacity-80">
                        <p className="flex items-center gap-2 text-sm font-medium text-ink-100">
                          {r.resource_name || r.resource_id || '—'}
                          {r.type === 'BREAKGLASS' && (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-red-600 dark:text-red-400">
                              <ShieldAlert className="h-3 w-3" /> break-glass
                            </span>
                          )}
                        </p>
                        <p className="truncate text-xs text-ink-500">
                          Requested {formatDateTime(r.created_at)}
                          {r.reason ? ` · ${r.reason}` : ''}
                        </p>
                      </Link>
                      <div className="flex flex-none items-center gap-2">
                        <Badge className={JIT_STATUS_BADGE[r.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                          {JIT_STATUS_LABELS[r.status] || r.status}
                        </Badge>
                        {CANCELLABLE_STATUSES.includes(r.status) && (
                          <button
                            onClick={() => setCancelTarget(r)}
                            disabled={cancelMutation.isPending}
                            className="rounded-lg border border-red-300 transition-colors dark:border-red-900/50 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-60"
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
                {pagination && (
                  <Pagination
                    page={pagination.page}
                    pageSize={pagination.page_size}
                    total={pagination.total}
                    totalPages={pagination.total_pages}
                    onPageChange={setPage}
                  />
                )}
              </>
            )}
          </QueryState>
        ) : (
          <QueryState
            query={grantsQuery}
            empty={(d) => !d?.grants || d.grants.length === 0}
            emptyMessage="No grants yet."
          >
            {() => (
              <>
                <ul className="divide-y divide-surface-800">
                  {grants.map((g) => (
                    <li key={g.id} className="flex items-center justify-between gap-3 px-4 py-3">
                      <Link
                        to={g.resource_id ? `/resources/${g.resource_id}` : '#'}
                        className="min-w-0 flex-1 hover:opacity-80"
                      >
                        <p className="text-sm font-medium text-ink-100">{g.resource_name || g.resource_id || '—'}</p>
                        <p className="truncate text-xs text-ink-500">
                          Granted {formatDateTime(g.created_at)}
                          {g.expires_at ? ` · Expires ${formatDateTime(g.expires_at)}` : ''}
                        </p>
                      </Link>
                      <Badge className={GRANT_STATUS_BADGE[g.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                        {g.status}
                      </Badge>
                    </li>
                  ))}
                </ul>
                {pagination && (
                  <Pagination
                    page={pagination.page}
                    pageSize={pagination.page_size}
                    total={pagination.total}
                    totalPages={pagination.total_pages}
                    onPageChange={setPage}
                  />
                )}
              </>
            )}
          </QueryState>
        )}
      </Card>

      <CreateJitRequestModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        defaultBreakglass={modalBreakglass}
      />

      <ConfirmDialog
        open={!!cancelTarget}
        title={`Cancel request for "${cancelTarget?.resource_name || cancelTarget?.resource_id || 'this resource'}"?`}
        description="This withdraws the request. You can submit a new one later if you still need access."
        confirmLabel="Cancel request"
        destructive
        requireReason
        reasonLabel="Reason (required for the audit record)"
        isLoading={cancelMutation.isPending}
        onConfirm={(reason) => cancelMutation.mutate({ id: cancelTarget.id, reason })}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  )
}
