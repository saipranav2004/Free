import { useEffect, useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ChevronLeft, ChevronRight, ShieldCheck, ShieldAlert, Download, FileSearch } from 'lucide-react'
import { searchAudit, generateComplianceReport } from '../../api/audit'
import { verifyAudit } from '../../api/admin'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Spinner } from '../../components/common/Spinner'
import { inputClass } from '../../components/common/FormFields'
import { AuditEventDetailModal } from '../../components/audit/AuditEventDetailModal'
import {
  formatDateTime,
  dateInputToRFC3339,
  todayDateInputValue,
  daysAgoDateInputValue,
} from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  AUDIT_CATEGORIES,
  AUDIT_OUTCOMES,
  AUDIT_OUTCOME_BADGE,
  AUDIT_SEVERITY_BADGE,
  SEARCH_DEBOUNCE_MS,
} from '../../config/constants'

const PAGE_LIMIT = 20

// Defensive readers — the exact field names an audit item carries for
// "when did this happen" / "who did it" / "what did it touch" aren't pinned
// down anywhere we've been given, so try the plausible candidates and fall
// back to a placeholder rather than crashing on `undefined.foo`.
function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}
function actorLabel(item) {
  return (
    item?.actor_username ||
    item?.username ||
    item?.actor?.username ||
    item?.user_email ||
    item?.actor_id ||
    item?.user_id ||
    '—'
  )
}
function targetLabel(item) {
  return (
    item?.resource_name ||
    item?.resource ||
    item?.target ||
    item?.resource_id ||
    '—'
  )
}

function AuditRow({ item, onSelect }) {
  const ts = itemTimestamp(item)
  return (
    <li>
      <button
        type="button"
        onClick={() => onSelect(item)}
        className="flex w-full flex-col gap-2 px-4 py-3.5 text-left transition-colors hover:bg-surface-850 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="min-w-0">
          <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink-100">
            <span className="text-ink-400">{item?.category || 'OTHER'}</span>
            <span>{item?.action || '—'}</span>
            {item?.outcome && (
              <Badge className={AUDIT_OUTCOME_BADGE[item.outcome] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                {item.outcome}
              </Badge>
            )}
            {item?.severity && (
              <Badge className={AUDIT_SEVERITY_BADGE[item.severity] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                {item.severity}
              </Badge>
            )}
          </p>
          <p className="mt-1 truncate text-xs text-ink-500">
            {formatDateTime(ts)} · actor: {actorLabel(item)} · target: {targetLabel(item)}
          </p>
        </div>
      </button>
    </li>
  )
}

export default function AuditPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [offset, setOffset] = useState(0)
  const [reportOpen, setReportOpen] = useState(false)
  const [reportFormat, setReportFormat] = useState('pdf')
  // Default to the last 30 days — the backend requires a from/to range on
  // every report request (see api/audit.js's generateComplianceReport doc
  // comment), so this needs a real default rather than forcing the user to
  // pick dates just to generate a report at all.
  const [reportFrom, setReportFrom] = useState(() => daysAgoDateInputValue(30))
  const [reportTo, setReportTo] = useState(() => todayDateInputValue())
  const [selectedEvent, setSelectedEvent] = useState(null)

  // Debounce the free-text search so it doesn't fire a request per keystroke —
  // the input updates immediately for responsiveness, the query key only
  // picks up `search` after SEARCH_DEBOUNCE_MS of no further typing.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  // Any filter change invalidates the current offset — otherwise "offset 60"
  // can persist into a filtered result set with only 10 total items.
  useEffect(() => {
    setOffset(0)
  }, [search, category, outcome])

  // AuditHandler.Search (audit_handler.go) exposes two very different
  // params: `action` is an EXACT match against the stored action string
  // ("pam:resource:Connect", "pam:vault:Reveal", ...), while `q` runs a
  // full-text search (Postgres tsvector + plainto_tsquery, see
  // audit_query_service.go) across the row's searchable fields. This search
  // box was wired to `action`, so typing anything other than one exact,
  // correctly-formatted action string returned zero rows regardless of
  // what was typed — which is why "search doesn't work" even though the
  // backend search endpoint itself was fine. Free text belongs on `q`.
  const filters = {
    q: search || undefined,
    category: category || undefined,
    outcome: outcome || undefined,
  }

  const auditQuery = useQuery({
    queryKey: ['audit', 'search', { search, category, outcome, offset }],
    queryFn: ({ signal }) => searchAudit({ ...filters, limit: PAGE_LIMIT, offset }, signal),
    placeholderData: (prev) => prev,
  })

  // Chain verification is inherently org-wide (it walks the whole hash
  // chain, not a per-account slice), and the backend only ever exposes it
  // under the admin-gated /admin/audit/verify route — there is no
  // self-service equivalent (see api/audit.js's comment where the old,
  // always-404ing self-service call used to live). Reusing api/admin.js's
  // verifyAudit() here rather than duplicating the request.
  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const reportMutation = useMutation({
    mutationFn: () => {
      const fromTime = dateInputToRFC3339(reportFrom, false)
      const toTime = dateInputToRFC3339(reportTo, true)
      if (!fromTime || !toTime) {
        throw new Error('Pick a start and end date for the report range.')
      }
      if (new Date(fromTime) > new Date(toTime)) {
        throw new Error('The start date must be before the end date.')
      }
      return generateComplianceReport({ ...filters, fromTime, toTime, format: reportFormat })
    },
    onSuccess: (result) => {
      toast.success(result?.filename ? `Report downloaded: ${result.filename}` : 'Report downloaded')
    },
    onError: (err) => {
      // Client-side validation above throws a plain Error, not an axios
      // error — apiErrorMessage would just fall through to a generic
      // "Something went wrong" for that shape, so show err.message directly
      // when there's no HTTP response to normalize.
      toast.error(err?.response ? apiErrorMessage(err) : err.message || apiErrorMessage(err))
    },
  })

  const total = auditQuery.data?.total ?? 0
  const limit = auditQuery.data?.limit ?? PAGE_LIMIT
  const items = auditQuery.data?.items
  const canPrev = offset > 0
  const canNext = offset + limit < total
  const rangeStart = total === 0 ? 0 : offset + 1
  const rangeEnd = Math.min(offset + limit, total)

  const verifyResult = verifyMutation.data
  // The field naming inside the verification payload isn't pinned down
  // anywhere we have access to — probe the plausible boolean fields and
  // otherwise fall back to showing the raw JSON rather than silently
  // dropping the signal.
  const verifyKnownField =
    verifyResult && (
      'valid' in verifyResult ? 'valid'
      : 'chain_valid' in verifyResult ? 'chain_valid'
      : 'success' in verifyResult ? 'success'
      : null
    )
  const verifyIsValid = verifyKnownField ? Boolean(verifyResult[verifyKnownField]) : null

  return (
    <div>
      <PageHeader
        title="Audit"
        description="Your own audit trail — actions performed by or affecting your account."
      />

      {isAdmin && verifyMutation.isSuccess && (
        <div
          className={
            'mb-4 flex items-center gap-3 rounded-lg border p-4 ' +
            (verifyIsValid === false
              ? 'border-red-400 dark:border-red-600/60 bg-red-50 dark:bg-red-950/40'
              : verifyIsValid === true
                ? 'border-emerald-300 dark:border-emerald-600/40 bg-emerald-50 dark:bg-emerald-950/20'
                : 'border-surface-800 bg-surface-900')
          }
        >
          {verifyIsValid === false && <ShieldAlert className="h-6 w-6 flex-none text-red-600 dark:text-red-400" />}
          {verifyIsValid === true && <ShieldCheck className="h-6 w-6 flex-none text-emerald-600 dark:text-emerald-400" />}
          <div className="min-w-0">
            {verifyIsValid === true && (
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                Audit chain intact — no tampering detected.
              </p>
            )}
            {verifyIsValid === false && (
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">
                Audit chain broken — possible tampering detected. Notify a security administrator.
              </p>
            )}
            {verifyIsValid === null && (
              <>
                <p className="mb-1 text-sm font-medium text-ink-100">Verification result</p>
                <pre className="max-w-full overflow-x-auto text-xs text-ink-400">
                  {JSON.stringify(verifyResult, null, 2)}
                </pre>
              </>
            )}
          </div>
        </div>
      )}

      {isAdmin && (
        <Card className="mb-4">
          <CardHeader className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-medium text-ink-100">Chain integrity (org-wide)</h2>
            <button
              onClick={() => verifyMutation.mutate()}
              disabled={verifyMutation.isPending}
              className="flex items-center gap-1.5 rounded-lg bg-surface-800 transition-colors px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
            >
              {verifyMutation.isPending ? <Spinner size="h-3.5 w-3.5" /> : <ShieldCheck className="h-3.5 w-3.5" />}
              Verify audit chain
            </button>
          </CardHeader>
          <div className="px-4 py-3 text-xs text-ink-500">
            Checks that every recorded audit entry in this PAM install forms an unbroken,
            tamper-evident chain. This is not run automatically — trigger it explicitly.
          </div>
        </Card>
      )}

      <Card className="mb-4">
        <CardHeader className="flex flex-wrap items-center gap-3">
          <input
            className={inputClass(false) + ' max-w-xs'}
            placeholder="Search…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
          <select
            className={inputClass(false) + ' max-w-[10rem]'}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All categories</option>
            {AUDIT_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select
            className={inputClass(false) + ' max-w-[10rem]'}
            value={outcome}
            onChange={(e) => setOutcome(e.target.value)}
          >
            <option value="">All outcomes</option>
            {AUDIT_OUTCOMES.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
          <button
            onClick={() => setReportOpen((v) => !v)}
            className="ml-auto flex items-center gap-1.5 h-9 rounded-lg bg-blue-600 px-3.5 text-sm font-medium text-white shadow-sm ring-1 ring-inset ring-blue-500/50 transition-colors hover:bg-blue-500 active:bg-blue-700"
          >
            <FileSearch className="h-4 w-4" /> Generate report
          </button>
        </CardHeader>

        {reportOpen && (
          <div className="flex flex-wrap items-end gap-3 border-b border-surface-800 px-4 py-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-ink-300">From</label>
              <input
                type="date"
                value={reportFrom}
                max={reportTo}
                onChange={(e) => setReportFrom(e.target.value)}
                className={inputClass(false)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-ink-300">To</label>
              <input
                type="date"
                value={reportTo}
                min={reportFrom}
                max={todayDateInputValue()}
                onChange={(e) => setReportTo(e.target.value)}
                className={inputClass(false)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium text-ink-300">Format</span>
              <div className="flex items-center gap-3 py-1.5">
                <label className="flex items-center gap-1.5 text-sm text-ink-200">
                  <input
                    type="radio"
                    name="report-format"
                    checked={reportFormat === 'pdf'}
                    onChange={() => setReportFormat('pdf')}
                  />
                  PDF
                </label>
                <label className="flex items-center gap-1.5 text-sm text-ink-200">
                  <input
                    type="radio"
                    name="report-format"
                    checked={reportFormat === 'csv'}
                    onChange={() => setReportFormat('csv')}
                  />
                  CSV
                </label>
              </div>
            </div>
            <button
              onClick={() => reportMutation.mutate()}
              disabled={reportMutation.isPending}
              className="flex items-center gap-1.5 rounded-lg bg-surface-800 transition-colors px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
            >
              {reportMutation.isPending ? <Spinner size="h-3.5 w-3.5" /> : <Download className="h-3.5 w-3.5" />}
              Download
            </button>
            <span className="text-xs text-ink-500">
              Also scoped to the search filters above (category/outcome/action).
            </span>
          </div>
        )}

        <QueryState
          query={auditQuery}
          empty={(d) => !d?.items || d.items.length === 0}
          emptyMessage="No audit entries found."
        >
          {() => (
            <>
              <ul className="divide-y divide-surface-800">
                {items.map((item, idx) => (
                  <AuditRow key={item?.id ?? item?.sequence ?? idx} item={item} onSelect={setSelectedEvent} />
                ))}
              </ul>
              <div className="flex items-center justify-between border-t border-surface-800 px-4 py-3 text-sm text-ink-400">
                <span>
                  Showing <span className="text-ink-200">{rangeStart}</span>–
                  <span className="text-ink-200">{rangeEnd}</span> of{' '}
                  <span className="text-ink-200">{total}</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={!canPrev}
                    onClick={() => canPrev && setOffset((o) => Math.max(0, o - limit))}
                    className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
                    aria-label="Previous page"
                  >
                    <ChevronLeft className="h-4 w-4" /> Prev
                  </button>
                  <button
                    disabled={!canNext}
                    onClick={() => canNext && setOffset((o) => o + limit)}
                    className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
                    aria-label="Next page"
                  >
                    Next <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </>
          )}
        </QueryState>
      </Card>

      <AuditEventDetailModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />
    </div>
  )
}
