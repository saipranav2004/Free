import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Radio, Square, ShieldAlert } from 'lucide-react'
import { listMySessions, endSession } from '../../api/sessions'
import { listSessions, killSession } from '../../api/admin'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Spinner } from '../../components/common/Spinner'
import { ResourceTypeIcon } from '../../components/resources/ResourceTypeIcon'
import { formatDateTime, formatDuration } from '../../lib/format'
import { SESSION_STATUS_BADGE, SESSIONS_POLL_MS, DEFAULT_PAGE_SIZE } from '../../config/constants'
import { apiErrorMessage } from '../../lib/apiError'

const TABS = [
  { key: 'mine', label: 'My sessions' },
  { key: 'all', label: 'All active (org-wide)' },
]

function StatusBadge({ status }) {
  return (
    <Badge className={SESSION_STATUS_BADGE[status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
      {status}
    </Badge>
  )
}

// Live duration for a still-running session — the backend's duration_seconds
// field is only populated once a session ends (see session.go's End()), so
// an ACTIVE row's own DurationSeconds is always 0. Computing it client-side
// from started_at avoids showing a permanently-stuck "0s" for live sessions.
function LiveDuration({ session }) {
  if (session.status !== 'ACTIVE') {
    return <>{formatDuration(session.duration_seconds)}</>
  }
  const elapsedSec = (Date.now() - new Date(session.started_at).getTime()) / 1000
  return <>{formatDuration(elapsedSec)}</>
}

function SessionRow({ session, onEnd, onKill, canKill, isMutating }) {
  return (
    <li className="flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-3">
        <ResourceTypeIcon type={session.resource_type} />
        <div>
          <p className="text-sm font-medium text-ink-100">
            {session.resource_name}
            {session.is_breakglass && (
              <span className="ml-2 inline-flex items-center gap-1 text-xs font-medium text-red-600 dark:text-red-400">
                <ShieldAlert className="h-3 w-3" /> break-glass
              </span>
            )}
          </p>
          <p className="text-xs text-ink-500">
            {session.username ? `${session.username} · ` : ''}
            Started {formatDateTime(session.started_at)}
            {session.protocol ? ` · ${session.protocol}` : ''}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs text-ink-400">
          <LiveDuration session={session} />
        </span>
        <StatusBadge status={session.status} />
        {session.status === 'ACTIVE' && (
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onEnd(session.id)}
              disabled={isMutating}
              className="rounded-lg bg-surface-800 transition-colors px-2.5 py-1 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
            >
              End
            </button>
            {canKill && (
              <button
                onClick={() => onKill(session)}
                disabled={isMutating}
                className="flex items-center gap-1 rounded-lg border border-red-300 transition-colors dark:border-red-900/50 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-60"
              >
                <Square className="h-3 w-3" /> Kill
              </button>
            )}
          </div>
        )}
      </div>
    </li>
  )
}

export default function SessionsPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [tab, setTab] = useState('mine')
  const [activeOnly, setActiveOnly] = useState(true)
  const [page, setPage] = useState(1)
  const [killTarget, setKillTarget] = useState(null)
  const queryClient = useQueryClient()

  // Reset to page 1 whenever a filter that changes the result set changes —
  // otherwise "page 3" can persist after switching filters into a set with
  // only 1 page, leaving Pagination's own bounds-check to silently clamp it
  // but the fetch itself would still have requested a now-invalid page.
  const changeTab = (next) => {
    setTab(next)
    setPage(1)
  }
  const changeActiveOnly = (next) => {
    setActiveOnly(next)
    setPage(1)
  }

  const mineQuery = useQuery({
    queryKey: ['sessions', 'mine', { page, activeOnly }],
    queryFn: ({ signal }) =>
      listMySessions({ page, pageSize: DEFAULT_PAGE_SIZE, activeOnly, signal }),
    enabled: tab === 'mine',
    // Poll only when looking at active sessions — a completed-sessions
    // history view has no reason to refetch every 15s.
    refetchInterval: tab === 'mine' && activeOnly ? SESSIONS_POLL_MS : false,
  })

  const allQuery = useQuery({
    queryKey: ['sessions', 'all', { activeOnly }],
    queryFn: ({ signal }) => listSessions({ active: activeOnly ? 'true' : undefined }, signal),
    enabled: tab === 'all' && isAdmin,
    refetchInterval: tab === 'all' && activeOnly ? SESSIONS_POLL_MS : false,
  })

  const activeQuery = tab === 'mine' ? mineQuery : allQuery

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ['sessions'] })
  }

  const endMutation = useMutation({
    mutationFn: (id) => endSession(id),
    onSuccess: () => {
      toast.success('Session ended')
      invalidateAll()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const killMutation = useMutation({
    mutationFn: ({ id, reason }) => killSession(id, reason),
    onSuccess: () => {
      toast.success('Session killed')
      setKillTarget(null)
      invalidateAll()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setKillTarget(null)
    },
  })

  const sessions = activeQuery.data?.sessions
  const pagination = tab === 'mine' ? activeQuery.data?.pagination : null

  return (
    <div>
      <PageHeader
        title="Sessions"
        description="Tracked connection sessions — start/end lifecycle for audit and JIT grant expiry, not a live terminal."
      />

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1 rounded-md bg-surface-900 p-1">
          {TABS.filter((t) => t.key !== 'all' || isAdmin).map((t) => (
            <button
              key={t.key}
              onClick={() => changeTab(t.key)}
              className={
                'rounded px-3 py-1.5 text-sm font-medium ' +
                (tab === t.key ? 'bg-blue-600 text-white' : 'text-ink-400 hover:text-ink-100')
              }
            >
              {t.label}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-2 text-sm text-ink-300">
          <input
            type="checkbox"
            checked={activeOnly}
            onChange={(e) => changeActiveOnly(e.target.checked)}
            className="rounded border-surface-700 bg-surface-800"
          />
          Active only
        </label>
      </div>

      <Card>
        <QueryState
          query={activeQuery}
          empty={(d) => !d?.sessions || d.sessions.length === 0}
          emptyMessage={activeOnly ? 'No active sessions.' : 'No sessions found.'}
        >
          {() => (
            <>
              <ul className="divide-y divide-surface-800">
                {sessions.map((s) => (
                  <SessionRow
                    key={s.id}
                    session={s}
                    canKill={tab === 'all'}
                    isMutating={endMutation.isPending || killMutation.isPending}
                    onEnd={(id) => endMutation.mutate(id)}
                    onKill={(session) => setKillTarget(session)}
                  />
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <ConfirmDialog
        open={!!killTarget}
        title={`Kill session on "${killTarget?.resource_name}"?`}
        description="This immediately terminates the tracked session and is recorded in the audit log."
        confirmLabel="Kill session"
        destructive
        requireReason
        reasonLabel="Reason (required for the audit record)"
        isLoading={killMutation.isPending}
        onConfirm={(reason) => killMutation.mutate({ id: killTarget.id, reason })}
        onCancel={() => setKillTarget(null)}
      />
    </div>
  )
}
