# Update: activity sample filter, recording viewer, live MFA status

Drop these files over your `src/` tree. No new dependencies, no backend
changes, no API contract changes.

## Project structure (files in this archive)

```
src/
├── components/
│   ├── audit/
│   │   └── SessionRecordingViewer.jsx   NEW  premium recording viewer
│   └── common/
│       └── AppLayout.jsx                MOD  navbar MFA chip is live
├── hooks/
│   └── useMfaStatus.js                  NEW  subscribed MFA status hook
├── lib/
│   └── mfaEvidence.js                   MOD  evidence map now publishes changes
└── pages/
    ├── DashboardPage.jsx                MOD  event-limit filter, no em-dashes
    ├── SettingsPage.jsx                 MOD  uses useMfaStatus
    └── admin/
        └── AdminAuditPage.jsx           MOD  recording rows open the viewer
```

---

## Task 1 - DashboardPage.jsx

Built on the refined version already in the workspace (masthead posture KPIs,
attention collapse, shortcut rows, client-side charts). Nothing was dropped.

**Event limit filter.** `AUDIT_SAMPLE = 200` is gone. A compact select labelled
"Sample" sits in the Activity section header:

| Option | page_size / limit sent |
| --- | --- |
| Last 200 events (default) | 200 |
| Last 500 events | 500 |
| Last 1,000 events | 1000 |
| All available audits | 5000 (single-request ceiling) |

* The chosen size is part of the react-query key, so switching refetches;
  `placeholderData` keeps the current charts on screen while it does, and a
  small spinner next to the select shows the fetch.
* One fetch feeds the whole zone, so the filter drives **every** consumer of
  the events array: activity volume chart, outcomes donut, most frequent
  actions, by category, most active accounts, denied & failed list, and the
  "needs your attention" logic.
* Scoped per view: the admin dashboard and the self-service dashboard each keep
  their own selection in their own state, with their own query key
  (`['admin','audit','dashboard-sample',N]` / `['audit','dashboard-sample',N]`).
* `scopeNote` is now derived from the selection, e.g. "Organization-wide,
  computed from the 500 most recent audit entries." and for the self-service
  view "Your own trail, computed from every audit entry this deployment returns
  in a single request, capped at 5,000."

**Em-dashes.** Zero remain in the file (verified). Prose was rephrased with
periods, colons and commas; the `'-'`-style placeholder dashes were replaced
with words that say what is missing ("n/a", "Unnamed resource", "unknown
requester", "unknown action").

API calls and data logic are untouched apart from the sample size passed to
`listAudit` / `searchAudit`.

---

## Task 2 - Recordings tab: session recording viewer

`src/components/audit/SessionRecordingViewer.jsx` (new) + row wiring in
`AdminAuditPage.jsx`.

Row click opens the viewer. The play button on a row (visible on hover/focus)
opens it already playing. Rows are keyboard reachable (Tab, then Enter/Space).

Deliberately **not** a port of the old modal. It is a redesigned dual-pane
viewer in the console's own vocabulary (Card/Button/Badge/EmptyState/Spinner
/SearchField), following the CyberArk PVWA / BeyondTrust / Datadog Session
Replay pattern: replay on the left, synchronised event log on the right, one
shared timeline.

* **Header** - resource, status badge, failed-command count, user, session id,
  start time, duration, exact stored size.
* **Replay** - terminal pane on a dark console surface, driven by one clock
  (real elapsed time x speed, 10 ticks/sec) instead of chained timeouts. Play,
  pause, restart, back/forward 10s, speed 0.5x-4x, "skip idle" (jumps dead air
  over 1.5s and flashes how much it skipped), fullscreen, live event counter.
  ANSI escape sequences are stripped and CR/BS are emulated per line, so
  native-agent captures full of redraw codes stay readable. Replay is
  incremental forward and re-derived on rewind, which is the only correct
  behaviour for an overwrite stream.
* **Scrubber** - progress track with a tick for every logged command, red for
  failed/denied, plus a transparent range input so it is draggable and
  keyboard-operable.
* **Command log** - searchable, sequence numbers, local timestamps, offsets,
  duration, masked-input marker, outcome badges, copy button per entry. Click
  or Enter on a line seeks the replay and highlights it; entries already
  reached get a green edge; risky entries a red one. Paged with prev/next when
  the backend reports more than one page.
* **Properties tab** - full session properties (ids, local + UTC start,
  duration, size in bytes, terminal geometry, transcript event count, commands
  logged), risk indicators, and exports: `.cast` transcript via the existing
  `downloadRecordingCast`, and a tab-separated command log built client-side.
* **Keyboard** - Space play/pause, arrows (or J/L) seek, F fullscreen, Esc back
  to list. Shortcuts are printed in the footer so they are discoverable.
* Loading skeletons, an error state with retry, and an explicit "recording is
  still in progress, the transcript is written when the session ends" state.

Backend contracts are untouched: `getRecordingCast`, `listRecordingCommands`,
`downloadRecordingCast` and `listRecordings` are called exactly as before.
There is no real video on this backend, so the viewer replays the stored
transcript rather than pretending a video stream exists.

---

## Task 3 - MFA status updating live

**Root cause.** The MFA answer is computed from two inputs:
`readMfaStatus(me)` = fields on `/auth/me` + the enrolment evidence map in
localStorage. Enabling or disabling MFA changes the evidence map, but this
deployment's `/auth/me` reports no enrolment at all, so the refetch triggered
by `invalidateQueries(['me'])` came back byte-identical. React Query's
structural sharing then returns the **previous data object reference**, so no
consumer re-rendered, so nothing re-read localStorage. Only a full page load
recomputed it. The invalidations were never the problem.

**Fix.**
* `lib/mfaEvidence.js` now publishes: every write bumps a version counter and
  notifies subscribers (plus a `storage` listener for other tabs).
* `hooks/useMfaStatus.js` (new) subscribes via `useSyncExternalStore` and
  recomputes `readMfaStatus` whenever the evidence changes or `me` changes.
* `SettingsPage.jsx` uses `useMfaStatus(meQuery.data)`, so the Security tab
  card and the Account tab posture chip both flip in the same tick as
  "I've saved these codes" or "Disable MFA".
* `AppLayout.jsx` uses the same hook for the navbar posture chip, so no surface
  can disagree with another.

No change to `readMfaStatus` semantics, to `MfaEnrollment`'s flow, or to any
endpoint. If a backend later reports real enrolment on `/auth/me`, it still
wins automatically.
