import { useCallback, useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Plus, Boxes, KeyRound, ShieldCheck, ShieldOff, LayoutGrid, Rows3, Power, PowerOff,
  RefreshCw, Trash2, Download, ServerOff, SearchX,
} from 'lucide-react'
import { toast } from 'sonner'
import { listResourceGroups } from '../../api/resources'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card, EmptyState } from '../../components/common/Layout'
import { Button } from '../../components/common/Button'
import { Pagination } from '../../components/common/Pagination'
import { BulkActionBar } from '../../components/common/BulkActionBar'
import { SegmentedControl } from '../../components/common/SegmentedControl'
import { QueryState } from '../../components/common/QueryState'
import {
  SearchField, ColumnChooser, DensityToggle, ExportMenu, RefreshControl,
  SavedViewsMenu, useSavedViews, ActiveFilters,
} from '../../components/common/TableControls'
import { CreateResourceModal } from '../../components/resources/CreateResourceModal'
import { ResourceCard, resourceTypeLabel } from '../../components/resources/ResourceCard'
import { ResourceTable, RESOURCE_COLUMNS } from '../../components/resources/ResourceTable'
import { ResourceDrawer } from '../../components/resources/ResourceDrawer'
import { useTableState } from '../../hooks/useTableState'
import { exportRowsToCsv, exportRowsToJson } from '../../lib/exportRows'
import { RESOURCE_TYPES } from '../../config/constants'

// ---------------------------------------------------------------------------
// Resource catalogue.
// ---------------------------------------------------------------------------
// Same single API call as before (GET /pam/resources/groups). Everything the
// toolbar does — search, faceted filters, sort, paging, selection, export —
// happens over the collection that call already returns, because the endpoint
// takes no query parameters. When it grows them, `useTableState({ serverMode
// })` is the one switch that moves this page onto server paging.
//
// Grouping by platform (the old page's only organising idea) survives as an
// optional "Group by platform" toggle rather than as the mandatory structure:
// grouping is useful when you're browsing and actively in the way when you're
// looking for one specific host among four hundred.

const CSV_COLUMNS = [
  { key: 'name', label: 'Name' },
  { key: 'resource_type', label: 'Type', value: (r) => resourceTypeLabel(r.resource_type) },
  { key: 'host', label: 'Host' },
  { key: 'port', label: 'Port' },
  { key: 'database_name', label: 'Database' },
  { key: 'group', label: 'Group' },
  { key: 'connect_mode', label: 'Connect mode' },
  { key: 'requires_jit', label: 'JIT required', value: (r) => (r.requires_jit ? 'yes' : 'no') },
  { key: 'always_record', label: 'Always recorded', value: (r) => (r.always_record ? 'yes' : 'no') },
  { key: 'is_active', label: 'Active', value: (r) => (r.is_active ? 'yes' : 'no') },
  { key: 'credential', label: 'Credential', value: (r) => (r.vault_entry_id ? 'attached' : 'none') },
  { key: 'id', label: 'Resource ID' },
]

const INITIAL_FILTERS = { type: 'all', status: 'all', access: 'all', credential: 'all', group: 'all' }

const FILTER_LABELS = { type: 'Type', status: 'Status', access: 'Access', credential: 'Credential', group: 'Group' }

const NO_BULK_ENDPOINT = 'Requires a backend batch endpoint — not available yet'

function FilterSelect({ label, value, onChange, options }) {
  return (
    <label className="flex min-w-0 items-center gap-2">
      <span className="whitespace-nowrap text-xs font-medium text-ink-400">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 min-w-0 cursor-pointer rounded-lg border border-surface-700 bg-surface-900 pl-2.5 pr-7 text-xs font-medium text-ink-100 shadow-sm transition-colors hover:border-surface-600 focus:border-blue-500 focus:outline-none"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  )
}

export default function ResourcesPage() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [createOpen, setCreateOpen] = useState(false)
  const [view, setView] = useState(() => localStorage.getItem('pam_resources_view') || 'grid')
  const [groupBy, setGroupBy] = useState(false)
  const [peeked, setPeeked] = useState(null)
  const [focusedId, setFocusedId] = useState(null)

  const groupsQuery = useQuery({
    queryKey: ['resources', 'groups'],
    queryFn: ({ signal }) => listResourceGroups(signal),
  })

  // The endpoint returns resources nested under their platform group; every
  // view here wants one flat list, with the group name carried along as a
  // filterable/​sortable field rather than as nesting.
  const resources = useMemo(() => {
    const groups = groupsQuery.data || []
    return groups.flatMap((g) => (g.resources || []).map((r) => ({ ...r, group: g.name })))
  }, [groupsQuery.data])

  const groupNames = useMemo(
    () => [...new Set((groupsQuery.data || []).map((g) => g.name))].sort(),
    [groupsQuery.data]
  )

  const table = useTableState({
    rows: resources,
    storageKey: 'resources',
    initialSort: { key: 'name', dir: 'asc' },
    initialPageSize: 24,
    initialFilters: INITIAL_FILTERS,
    searchFields: ['name', 'host', 'description', 'database_name', 'group', 'resource_type'],
    filterFn: (r, f) => {
      if (f.type !== 'all' && r.resource_type !== f.type) return false
      if (f.status === 'active' && !r.is_active) return false
      if (f.status === 'inactive' && r.is_active) return false
      if (f.access === 'jit' && !r.requires_jit) return false
      if (f.access === 'standing' && r.requires_jit) return false
      if (f.credential === 'attached' && !r.vault_entry_id) return false
      if (f.credential === 'missing' && r.vault_entry_id) return false
      if (f.group !== 'all' && r.group !== f.group) return false
      return true
    },
  })

  const savedViews = useSavedViews('resources')
  const [activeViewName, setActiveViewName] = useState(null)

  const setView_ = useCallback((v) => {
    setView(v)
    try {
      localStorage.setItem('pam_resources_view', v)
    } catch {
      // Preference simply doesn't persist when storage is unavailable.
    }
  }, [])

  // Keyboard row navigation. j/k walk the current page, x ticks the focused
  // row, Escape drops focus and any selection. Ignored while the user is
  // typing in a field — a filter box that eats "j" is worse than no shortcut.
  useEffect(() => {
    const onKey = (e) => {
      const el = document.activeElement
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)) return
      if (e.metaKey || e.ctrlKey || e.altKey) return
      const rows = table.pageRows
      if (rows.length === 0) return
      const idx = rows.findIndex((r) => r.id === focusedId)

      if (e.key === 'j' || e.key === 'ArrowDown') {
        e.preventDefault()
        setFocusedId(rows[Math.min(idx + 1, rows.length - 1)]?.id ?? rows[0].id)
      } else if (e.key === 'k' || e.key === 'ArrowUp') {
        e.preventDefault()
        setFocusedId(rows[Math.max(idx - 1, 0)]?.id ?? rows[0].id)
      } else if (e.key === 'x' && idx >= 0) {
        e.preventDefault()
        table.toggleRow(rows[idx])
      } else if (e.key === 'Enter' && idx >= 0) {
        e.preventDefault()
        setPeeked(rows[idx])
      } else if (e.key === 'Escape') {
        setFocusedId(null)
        table.clearSelection()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [focusedId, table])

  const counts = useMemo(
    () => ({
      total: resources.length,
      jit: resources.filter((r) => r.requires_jit).length,
      standing: resources.filter((r) => !r.requires_jit).length,
      inactive: resources.filter((r) => !r.is_active).length,
      credentialed: resources.filter((r) => r.vault_entry_id).length,
    }),
    [resources]
  )

  const filterChips = useMemo(() => {
    const chips = []
    if (table.query.trim()) {
      chips.push({ key: 'q', label: 'Search', value: table.query.trim(), onClear: () => table.setQuery('') })
    }
    Object.entries(table.filters).forEach(([k, v]) => {
      if (v && v !== 'all') {
        chips.push({
          key: k,
          label: FILTER_LABELS[k] || k,
          value: k === 'type' ? resourceTypeLabel(v) : v,
          onClear: () => table.setFilter(k, 'all'),
        })
      }
    })
    return chips
  }, [table])

  const bulkActions = [
    {
      key: 'export',
      label: 'Export',
      icon: Download,
      onClick: () => {
        exportRowsToCsv(table.selectedRows, CSV_COLUMNS, 'resources-selection')
        toast.success(`Exported ${table.selectedCount} resources`)
      },
    },
    // Every action below needs a batch endpoint this backend doesn't expose.
    // Shown disabled with the reason rather than hidden: the console should be
    // honest about what the platform can and cannot do today.
    { key: 'enable', label: 'Enable', icon: Power, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'disable', label: 'Disable', icon: PowerOff, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'rotate', label: 'Rotate credentials', icon: RefreshCw, disabled: true, disabledReason: NO_BULK_ENDPOINT },
    { key: 'delete', label: 'Delete', icon: Trash2, variant: 'dangerGhost', disabled: true, disabledReason: NO_BULK_ENDPOINT },
  ]

  const grouped = useMemo(() => {
    if (!groupBy) return null
    const map = new Map()
    table.pageRows.forEach((r) => {
      const key = r.group || 'Ungrouped'
      if (!map.has(key)) map.set(key, [])
      map.get(key).push(r)
    })
    return [...map.entries()]
  }, [groupBy, table.pageRows])

  const cardGrid = (rows) => (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {rows.map((r) => (
        <ResourceCard
          key={r.id}
          resource={r}
          selected={table.isSelected(r)}
          selectionActive={table.selectedCount > 0}
          onToggleSelect={table.toggleRow}
          onPeek={setPeeked}
        />
      ))}
    </div>
  )

  return (
    <div className="pb-24">
      <PageHeader
        eyebrow="Access"
        title="Resources"
        description="Every system PAM can broker access to — searchable, filterable, and exportable as the view you build."
        actions={
          isAdmin && (
            <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
              Register resource
            </Button>
          )
        }
      />

      {/* Toolbar — chrome, deliberately not a Card, so it never reads as
          content. Row one is find/act, row two is faceted narrowing. */}
      <div className="mb-4 space-y-3 rounded-xl border border-surface-700/70 bg-surface-900 px-3 py-3 shadow-card">
        <div className="flex flex-wrap items-center gap-2">
          <SearchField
            value={table.query}
            onChange={(v) => {
              table.setQuery(v)
              setActiveViewName(null)
            }}
            placeholder="Search name, host, database or group…"
            className="min-w-[16rem]"
          />

          <SavedViewsMenu
            views={savedViews.views}
            activeName={activeViewName}
            canSave={table.activeFilterCount > 0}
            onApply={(v) => {
              table.setQuery(v.state.query || '')
              table.setFilters({ ...INITIAL_FILTERS, ...(v.state.filters || {}) })
              setActiveViewName(v.name)
            }}
            onSave={(name) => {
              savedViews.saveView(name, { query: table.query, filters: table.filters })
              setActiveViewName(name)
              toast.success(`Saved view “${name}”`)
            }}
            onRemove={(name) => {
              savedViews.removeView(name)
              if (activeViewName === name) setActiveViewName(null)
            }}
          />

          <span className="ml-auto flex flex-wrap items-center gap-2">
            <SegmentedControl
              size="sm"
              ariaLabel="View mode"
              value={view}
              onChange={setView_}
              options={[
                { key: 'grid', label: 'Cards', icon: LayoutGrid },
                { key: 'table', label: 'Table', icon: Rows3 },
              ]}
            />
            {view === 'table' && (
              <>
                <ColumnChooser columns={RESOURCE_COLUMNS} visible={table.visibleColumns} onChange={table.setVisibleColumns} />
                <DensityToggle value={table.density} onChange={table.setDensity} />
              </>
            )}
            <ExportMenu
              count={table.total}
              disabled={table.total === 0}
              onExportCsv={() => exportRowsToCsv(table.filteredRows, CSV_COLUMNS, 'resources')}
              onExportJson={() => exportRowsToJson(table.filteredRows, CSV_COLUMNS, 'resources')}
            />
            <RefreshControl
              onRefresh={() => groupsQuery.refetch()}
              isFetching={groupsQuery.isFetching}
              updatedAt={groupsQuery.dataUpdatedAt}
            />
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-surface-800 pt-3">
          <FilterSelect
            label="Type"
            value={table.filters.type}
            onChange={(v) => table.setFilter('type', v)}
            options={[{ value: 'all', label: 'All types' }, ...RESOURCE_TYPES.map((t) => ({ value: t.value, label: t.label }))]}
          />
          <FilterSelect
            label="Group"
            value={table.filters.group}
            onChange={(v) => table.setFilter('group', v)}
            options={[{ value: 'all', label: 'All groups' }, ...groupNames.map((g) => ({ value: g, label: g }))]}
          />
          <FilterSelect
            label="Status"
            value={table.filters.status}
            onChange={(v) => table.setFilter('status', v)}
            options={[
              { value: 'all', label: 'Any' },
              { value: 'active', label: 'Active' },
              { value: 'inactive', label: 'Inactive' },
            ]}
          />
          <FilterSelect
            label="Access"
            value={table.filters.access}
            onChange={(v) => table.setFilter('access', v)}
            options={[
              { value: 'all', label: 'Any' },
              { value: 'jit', label: 'JIT-gated' },
              { value: 'standing', label: 'Standing' },
            ]}
          />
          <FilterSelect
            label="Credential"
            value={table.filters.credential}
            onChange={(v) => table.setFilter('credential', v)}
            options={[
              { value: 'all', label: 'Any' },
              { value: 'attached', label: 'Attached' },
              { value: 'missing', label: 'Missing' },
            ]}
          />
          {view === 'grid' && (
            <label className="ml-auto inline-flex cursor-pointer select-none items-center gap-2 text-xs font-medium text-ink-400">
              <input
                type="checkbox"
                checked={groupBy}
                onChange={(e) => setGroupBy(e.target.checked)}
                className="h-3.5 w-3.5 rounded border-surface-600 bg-surface-800 text-blue-600 focus:ring-blue-500/30"
              />
              Group by platform
            </label>
          )}
        </div>

        {filterChips.length > 0 && (
          <div className="border-t border-surface-800 pt-3">
            <ActiveFilters
              chips={filterChips}
              onClearAll={() => {
                table.resetFilters()
                setActiveViewName(null)
              }}
            />
          </div>
        )}
      </div>

      <QueryState
        query={groupsQuery}
        skeletonRows={6}
        empty={() => resources.length === 0}
        emptyTitle="No resources registered"
        emptyMessage="Once a system is registered it appears here with its connection details and access requirements."
        emptyAction={
          isAdmin && (
            <Button variant="primary" icon={Plus} onClick={() => setCreateOpen(true)}>
              Register the first resource
            </Button>
          )
        }
      >
        {() =>
          // Filters that match nothing is a different situation from an empty
          // catalogue, and needs a different way out — clear the filters, not
          // "register a resource".
          table.total === 0 ? (
            <Card>
              <EmptyState
                icon={SearchX}
                title="No resources match these filters"
                description="Nothing in the catalogue matches the current search and filter combination."
                action={
                  <Button
                    variant="secondary"
                    onClick={() => {
                      table.resetFilters()
                      setActiveViewName(null)
                    }}
                  >
                    Clear filters
                  </Button>
                }
              />
            </Card>
          ) : view === 'grid' ? (
            <div className="space-y-6">
              {grouped
                ? grouped.map(([name, rows]) => (
                    <section key={name}>
                      <div className="mb-3 flex items-center gap-3">
                        <h2 className="flex-none text-2xs font-semibold uppercase tracking-[0.11em] text-ink-400">{name}</h2>
                        <span className="rounded bg-surface-800 px-1.5 py-0.5 text-2xs font-semibold tabular-nums text-ink-400 ring-1 ring-inset ring-surface-700">
                          {rows.length}
                        </span>
                        <span className="h-px flex-1 bg-surface-800" aria-hidden="true" />
                      </div>
                      {rows.length === 0 ? (
                        <Card>
                          <EmptyState icon={ServerOff} title="No systems in this group" className="py-8" />
                        </Card>
                      ) : (
                        cardGrid(rows)
                      )}
                    </section>
                  ))
                : cardGrid(table.pageRows)}

              <Card className="overflow-hidden">
                <Pagination
                  page={table.page}
                  pageSize={table.pageSize}
                  total={table.total}
                  totalPages={table.totalPages}
                  onPageChange={table.setPage}
                  onPageSizeChange={table.setPageSize}
                  pageSizeOptions={[12, 24, 48, 96]}
                  label="resources"
                  className="border-t-0"
                />
              </Card>
            </div>
          ) : (
            <Card className="overflow-hidden">
              <ResourceTable
                rows={table.pageRows}
                sort={table.sort}
                onSort={table.toggleSort}
                density={table.density}
                visibleColumns={table.visibleColumns}
                isSelected={table.isSelected}
                onToggleRow={table.toggleRow}
                onToggleAll={table.toggleAllOnPage}
                allOnPageSelected={table.allOnPageSelected}
                someOnPageSelected={table.someOnPageSelected}
                onPeek={setPeeked}
                focusedId={focusedId}
              />
              <Pagination
                page={table.page}
                pageSize={table.pageSize}
                total={table.total}
                totalPages={table.totalPages}
                onPageChange={table.setPage}
                onPageSizeChange={table.setPageSize}
                label="resources"
              />
            </Card>
          )
        }
      </QueryState>

      <ResourceDrawer resource={peeked} open={!!peeked} onClose={() => setPeeked(null)} />

      <BulkActionBar
        count={table.selectedCount}
        total={table.total}
        noun="resource"
        actions={bulkActions}
        allMatchingSelected={table.allMatchingSelected}
        onSelectAllMatching={table.selectAllMatching}
        onClear={table.clearSelection}
      />

      {isAdmin && <CreateResourceModal open={createOpen} onClose={() => setCreateOpen(false)} />}
    </div>
  )
}
