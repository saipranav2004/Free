import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { toast } from 'sonner'
import {
  Boxes, Vault, Radio, KeyRound, ScrollText, ShieldAlert, ArrowRight, Users,
  ClipboardList, Lock, Activity, ChevronRight, ShieldCheck,
  Clock, TrendingUp, FileKey2, Link2, CheckCircle2,
} from 'lucide-react'
import clsx from 'clsx'
import { useAuthStore } from '../store/authStore'
import { getStats, listJitRequests, listAudit, verifyAudit, approveJitRequest, denyJitRequest } from '../api/admin'
import { listMyGrants, listMyJitRequests } from '../api/jit'
import { listMySessions } from '../api/sessions'
import { searchAudit } from '../api/audit'
import { PageHeader, Card, CardHeader, CardTitle, CardFooter, Section, EmptyState } from '../components/common/Layout'
import { KpiStrip } from '../components/common/KpiStrip'
import { QueryState } from '../components/common/QueryState'
import { Badge } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { ConfirmDialog } from '../components/common/ConfirmDialog'
import { AuditEventDrawer } from '../components/audit/AuditEventDrawer'
import { AreaChart, DonutChart, BarList } from '../components/charts/Charts'
import {
  bucketByTime, outcomeBreakdown, topActions, topActors, categoryBreakdown,
  attentionCounts, expiringGrants,
} from '../lib/dashboardMetrics'
import { eventActor, eventTarget, isFailure } from '../components/audit/auditFields'
import { formatDateTime, formatRelativeToNow } from '../lib/format'
import { apiErrorMessage } from '../lib/apiError'
import {
  JIT_STATUS_BADGE, JIT_STATUS_LABELS, AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE,
} from '../config/constants'

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------
// Now the console's ONLY landing page — Admin Center → Overview has been
// removed and everything it did that couldn't be got elsewhere (the live
// approval queue with inline approve/deny, the denied-activity feed, chain
// verification) is folded in here. Two dashboards existing side by side, one
// of them a strict subset of the other, was the actual problem: neither was
// worth opening.
//
// What makes this one worth opening, in the order an operator reads it:
//   1. Posture      — the five numbers from /admin/stats
//   2. Attention    — what is waiting on YOU, actionable in place
//   3. Analysis     — activity over time, outcome split, what's being done
//   4. Integrity    — is the audit chain intact
//
// Every chart is computed client-side from audit rows this page fetched (see
// lib/dashboardMetrics) because the backend has no analytics endpoint. Each
// one prints its sample size rather than implying a complete picture.

const AUDIT_SAMPLE = 200

function pick(obj, ...keys) {
  if (!obj) return undefined
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null) return obj[k]
  }
  return undefined
}

const RANGES = [
  { key: '24h', label: '24h', buckets: 24, span: 'hour' },
  { key: '7d', label: '7 days', buckets: 7, span: 'day' },
  { key: '30d', label: '30 days', buckets: 30, span: 'day' },
]

function SectionLink({ to, children }) {
  return (
    <Link
      to={to}
      className="group inline-flex items-center gap-1 text-xs font-semibold text-blue-600 transition-colors hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
    >
      {children}
      <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" strokeWidth={2} />
    </Link>
  )
}

function NavPlate({ to, label, description, icon: Icon }) {
  return (
    <Link to={to} className="group block h-full rounded-xl outline-none">
      <Card interactive className="flex h-full items-center gap-3.5 p-4">
        <span className="flex h-10 w-10 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-ink-400 transition-colors duration-200 group-hover:border-blue-500/40 group-hover:bg-blue-50 group-hover:text-blue-600 dark:group-hover:bg-blue-500/10 dark:group-hover:text-blue-300">
          <Icon className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-semibold text-ink-100">{label}</span>
          {description && <span className="mt-0.5 block truncate text-xs text-ink-500">{description}</span>}
        </span>
        <ArrowRight
          className="h-4 w-4 flex-none text-ink-600 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-blue-600 dark:group-hover:text-blue-300"
          strokeWidth={1.5}
        />
      </Card>
    </Link>
  )
}

// One shared analysis block, fed by whichever audit source the caller has
// access to. Self-service users get their own trail; admins get the org's.
function ActivityAnalysis({ events, loading, range, onRangeChange, scopeNote, auditHref }) {
  const [selected, setSelected] = useState(null)
  const preset = RANGES.find((r) => r.key === range) || RANGES[0]

  const series = useMemo(
    () => bucketByTime(events, { buckets: preset.buckets, span: preset.span }),
    [events, preset]
  )
  const outcomes = useMemo(() => outcomeBreakdown(events), [events])
  const actions = useMemo(() => topActions(events), [events])
  const categories = useMemo(() => categoryBreakdown(events), [events])
  const counts = useMemo(() => attentionCounts(events), [events])
  const plotted = series.reduce((n, s) => n + s.value, 0)

  return (
    <>
      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <Card className="overflow-hidden">
          <CardHeader className="flex-wrap gap-y-2">
            <CardTitle icon={TrendingUp}>Activity volume</CardTitle>
            <span className="ml-auto">
              <SegmentedControl
                size="sm"
                ariaLabel="Time range"
                value={range}
                onChange={onRangeChange}
                options={RANGES.map((r) => ({ key: r.key, label: r.label }))}
              />
            </span>
          </CardHeader>
          <div className="px-4 pb-3 pt-4">
            {loading ? (
              <div className="h-[132px] animate-pulse rounded-lg bg-surface-850" />
            ) : (
              <AreaChart points={series} valueLabel="Audit events" />
            )}
          </div>
          <CardFooter className="justify-between">
            <p className="text-2xs leading-relaxed text-ink-500">
              {plotted.toLocaleString()} of the last {counts.total.toLocaleString()} recorded events
              fall inside this window. {scopeNote}
            </p>
            <SectionLink to={auditHref}>Open audit</SectionLink>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle icon={ShieldCheck}>Outcomes</CardTitle>
          </CardHeader>
          <div className="p-4">
            {loading ? (
              <div className="h-[132px] animate-pulse rounded-lg bg-surface-850" />
            ) : counts.total === 0 ? (
              <p className="py-10 text-center text-xs text-ink-500">No events recorded yet</p>
            ) : (
              <DonutChart
                segments={outcomes}
                centerValue={counts.total.toLocaleString()}
                centerLabel="events"
              />
            )}
          </div>
          <CardFooter>
            <p className="text-2xs leading-relaxed text-ink-500">
              Across the last {counts.total.toLocaleString()} events. A denial is not necessarily an
              incident — policy working is the common case.
            </p>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle icon={Activity}>Most frequent actions</CardTitle>
          </CardHeader>
          <BarList items={actions} mono emptyLabel="No actions recorded yet" />
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle icon={ClipboardList}>By category</CardTitle>
            <span className="ml-auto text-2xs text-ink-500">red = contains a denial</span>
          </CardHeader>
          <BarList items={categories} emptyLabel="No categories recorded yet" />
        </Card>
      </div>

      <AuditEventDrawer event={selected} onClose={() => setSelected(null)} />
    </>
  )
}

function DeniedFeed({ events, loading, href }) {
  const denied = (events || []).filter(isFailure).slice(0, 6)

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle icon={ShieldAlert}>Denied &amp; failed</CardTitle>
        <span className="ml-auto">
          <SectionLink to={href}>View all</SectionLink>
        </span>
      </CardHeader>
      {loading ? (
        <div className="space-y-2 p-4">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-10 animate-pulse rounded-lg bg-surface-850" />
          ))}
        </div>
      ) : denied.length === 0 ? (
        <EmptyState
          icon={CheckCircle2}
          title="Nothing denied recently"
          description="Blocked and failed actions surface here as soon as they're recorded."
          className="py-10"
        />
      ) : (
        <ul className="divide-y divide-surface-800">
          {denied.map((e, i) => (
            <li key={e?.id ?? i} className="px-4 py-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded border border-surface-700 bg-surface-850 px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-[0.06em] text-ink-500">
                  {e?.category || 'OTHER'}
                </span>
                <span className="min-w-0 flex-1 truncate font-mono text-xs font-medium text-ink-100">
                  {e?.action || '—'}
                </span>
                {e?.outcome && <Badge className={AUDIT_OUTCOME_BADGE[e.outcome]}>{e.outcome}</Badge>}
                {e?.severity === 'CRITICAL' && (
                  <Badge className={AUDIT_SEVERITY_BADGE.CRITICAL}>CRITICAL</Badge>
                )}
              </div>
              <p className="mt-1 truncate text-2xs text-ink-500">
                {eventActor(e) || 'unknown actor'}
                {eventTarget(e) ? ` · ${eventTarget(e)}` : ''} · {formatDateTime(e?.occurred_at || e?.created_at)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </Card>
  )
}

// ---------------------------------------------------------------------------
// Admin
// ---------------------------------------------------------------------------

function AdminDashboard({ user }) {
  const queryClient = useQueryClient()
  const [range, setRange] = useState('24h')
  const [approveTarget, setApproveTarget] = useState(null)
  const [denyTarget, setDenyTarget] = useState(null)

  const statsQuery = useQuery({ queryKey: ['admin', 'stats'], queryFn: ({ signal }) => getStats(signal) })

  // One sample serves every chart AND the denied feed — the old Overview page
  // ran a separate query per widget for data it already had.
  const auditQuery = useQuery({
    queryKey: ['admin', 'audit', 'dashboard-sample'],
    queryFn: ({ signal }) => listAudit({ page: 1, page_size: AUDIT_SAMPLE }, signal),
    retry: false,
  })

  const pendingQuery = useQuery({
    queryKey: ['admin', 'jit-requests', 'pending-list'],
    queryFn: ({ signal }) => listJitRequests({ page: 1, page_size: 5, status: 'PENDING' }, signal),
  })

  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const invalidatePending = () => queryClient.invalidateQueries({ queryKey: ['admin', 'jit-requests'] })

  const approveMutation = useMutation({
    mutationFn: ({ id, reason }) => approveJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request approved')
      setApproveTarget(null)
      invalidatePending()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setApproveTarget(null)
    },
  })

  const denyMutation = useMutation({
    mutationFn: ({ id, reason }) => denyJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request denied')
      setDenyTarget(null)
      invalidatePending()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDenyTarget(null)
    },
  })

  const s = statsQuery.data
  const events = useMemo(() => auditQuery.data?.events || [], [auditQuery.data])
  const actors = useMemo(() => topActors(events), [events])
  const pending = pendingQuery.data?.requests || []
  const isMutatingJit = approveMutation.isPending || denyMutation.isPending

  const vr = verifyMutation.data
  const vField = vr && ('valid' in vr ? 'valid' : 'chain_valid' in vr ? 'chain_valid' : 'intact' in vr ? 'intact' : 'success' in vr ? 'success' : null)
  const vIsValid = vField ? Boolean(vr[vField]) : null

  return (
    <div>
      <PageHeader
        eyebrow="Control plane"
        title={`Good to see you${user?.username ? `, ${user.username}` : ''}`}
        description="Organization-wide posture across identity, privileged access and audit — and everything currently waiting on you."
        meta={
          <span className="inline-flex items-center gap-2 rounded-md border border-surface-700 bg-surface-900 px-2.5 py-1 text-2xs font-medium uppercase tracking-[0.08em] text-ink-400">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" strokeWidth={1.75} />
            All privileged activity brokered &amp; recorded
          </span>
        }
      />

      <Section label="Posture">
        <KpiStrip
          loading={statsQuery.isLoading}
          items={[
            {
              key: 'sessions',
              label: 'Active sessions',
              icon: Activity,
              tone: 'emerald',
              live: true,
              value: pick(s, 'active_sessions') ?? '—',
              description: 'Live brokered connections',
              to: '/sessions',
            },
            {
              key: 'pending',
              label: 'Pending approvals',
              icon: KeyRound,
              tone: (pick(s, 'pending_approvals') ?? 0) > 0 ? 'amber' : 'default',
              value: pick(s, 'pending_approvals') ?? '—',
              description: 'Awaiting a decision from you',
              to: '/admin/jit',
            },
            {
              key: 'grants',
              label: 'Active grants',
              icon: Lock,
              tone: 'emerald',
              value: pick(s, 'active_grants') ?? '—',
              description: 'Elevation currently in force',
              to: '/admin/jit',
            },
            {
              key: 'resources',
              label: 'Resources',
              icon: Boxes,
              value: pick(s, 'active_resources') ?? '—',
              description: 'Registered and reachable',
              to: '/resources',
            },
            {
              key: 'breakglass',
              label: 'Break-glass active',
              icon: ShieldAlert,
              tone: (pick(s, 'active_breakglass_grants') ?? 0) > 0 ? 'red' : 'default',
              value: pick(s, 'active_breakglass_grants') ?? '—',
              description: 'Emergency access in use',
              to: '/admin/jit',
            },
          ]}
        />
      </Section>

      {/* Waiting on you — the approval queue is actionable in place, which is
          the one thing the removed Overview page did that this page didn't. */}
      <Section label="Waiting on you">
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle icon={KeyRound}>Approval queue</CardTitle>
              <span className="ml-auto">
                <SectionLink to="/admin/jit">View all</SectionLink>
              </span>
            </CardHeader>
            <QueryState
              query={pendingQuery}
              empty={(d) => !d?.requests || d.requests.length === 0}
              emptyTitle="Queue clear"
              emptyMessage="No JIT or break-glass requests are waiting on a decision."
              skeletonRows={3}
            >
              {() => (
                <ul className="divide-y divide-surface-800">
                  {pending.map((r) => (
                    <li key={r.id} className="flex flex-col gap-2.5 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-ink-100">
                          {r?.resource_name || r?.resource_id || '—'}
                          <span className="ml-2 text-xs font-normal text-ink-500">
                            by {r?.requester_username || r?.username || r?.requested_by || r?.user_id || '—'}
                          </span>
                        </p>
                        <p className="mt-0.5 truncate text-xs text-ink-500">
                          {formatRelativeToNow(r?.created_at)}
                          {r?.reason ? ` · ${r.reason}` : ''}
                        </p>
                      </div>
                      <div className="flex flex-none items-center gap-2">
                        <Badge className={JIT_STATUS_BADGE[r?.status]}>
                          {JIT_STATUS_LABELS[r?.status] || r?.status || '—'}
                        </Badge>
                        <Button size="xs" variant="primary" disabled={isMutatingJit} onClick={() => setApproveTarget(r)}>
                          Approve
                        </Button>
                        <Button size="xs" variant="dangerGhost" disabled={isMutatingJit} onClick={() => setDenyTarget(r)}>
                          Deny
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </QueryState>
          </Card>

          <DeniedFeed events={events} loading={auditQuery.isLoading} href="/admin/audit" />
        </div>
      </Section>

      <Section label="Analysis">
        <ActivityAnalysis
          events={events}
          loading={auditQuery.isLoading}
          range={range}
          onRangeChange={setRange}
          auditHref="/admin/audit"
          scopeNote={`Organization-wide, from the ${AUDIT_SAMPLE} most recent audit entries — this backend exposes no aggregate endpoint, so nothing here is extrapolated beyond that sample.`}
        />

        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.4fr]">
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle icon={Users}>Most active accounts</CardTitle>
            </CardHeader>
            <BarList items={actors} emptyLabel="No actor activity in the sample" />
            <CardFooter>
              <p className="text-2xs leading-relaxed text-ink-500">
                High volume is not itself suspicious — an automation account should be here.
              </p>
            </CardFooter>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle icon={Link2}>Audit chain integrity</CardTitle>
              <Button
                size="sm"
                variant="secondary"
                icon={ShieldCheck}
                className="ml-auto"
                loading={verifyMutation.isPending}
                onClick={() => verifyMutation.mutate()}
              >
                Verify chain
              </Button>
            </CardHeader>
            {verifyMutation.isSuccess ? (
              <div
                className={clsx(
                  'flex items-start gap-3.5 px-4 py-5',
                  vIsValid === false ? 'bg-red-50 dark:bg-red-950/25' : vIsValid === true ? 'bg-emerald-50 dark:bg-emerald-950/20' : ''
                )}
              >
                <span
                  className={clsx(
                    'flex h-10 w-10 flex-none items-center justify-center rounded-xl ring-1 ring-inset',
                    vIsValid === false
                      ? 'bg-red-100 text-red-600 ring-red-600/20 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25'
                      : vIsValid === true
                        ? 'bg-emerald-100 text-emerald-600 ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25'
                        : 'border border-surface-700 bg-surface-850 text-ink-400 ring-transparent'
                  )}
                >
                  {vIsValid === false ? (
                    <ShieldAlert className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
                  ) : (
                    <ShieldCheck className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
                  )}
                </span>
                <div className="min-w-0">
                  {vIsValid === true && (
                    <>
                      <p className="text-sm font-semibold text-emerald-800 dark:text-emerald-300">
                        Chain intact — no tampering detected
                      </p>
                      <p className="mt-1 text-sm leading-relaxed text-emerald-700/90 dark:text-emerald-300/80">
                        Every entry&apos;s hash matches its predecessor.
                      </p>
                    </>
                  )}
                  {vIsValid === false && (
                    <>
                      <p className="text-sm font-semibold text-red-800 dark:text-red-300">
                        Chain broken — possible tampering
                      </p>
                      <p className="mt-1 text-sm leading-relaxed text-red-700/90 dark:text-red-300/80">
                        Notify a security administrator and preserve the database before further writes.
                      </p>
                    </>
                  )}
                  {vIsValid === null && (
                    <pre className="max-w-full overflow-x-auto rounded-lg border border-surface-700 bg-surface-850 p-2.5 font-mono text-xs text-ink-400">
                      {JSON.stringify(vr, null, 2)}
                    </pre>
                  )}
                </div>
              </div>
            ) : (
              <EmptyState
                icon={Link2}
                title="Not verified in this session"
                description="Walks every audit entry and re-computes its hash against the previous one. Runs only when you ask for it."
                className="py-10"
              />
            )}
          </Card>
        </div>
      </Section>

      <Section label="Administration">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            { to: '/admin/identity', label: 'Identity', icon: Users, description: 'Accounts and lifecycle' },
            { to: '/admin/roles', label: 'Roles', icon: Lock, description: 'Bundle policies for assignment' },
            { to: '/admin/policies', label: 'Policies', icon: FileKey2, description: 'Allow/deny rules' },
            { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList, description: 'Search and verify the trail' },
          ].map((l) => (
            <NavPlate key={l.to} {...l} />
          ))}
        </div>
      </Section>

      <ConfirmDialog
        open={!!approveTarget}
        title={`Approve request for "${approveTarget?.resource_name || approveTarget?.resource_id || 'this resource'}"?`}
        description="This grants time-boxed access immediately."
        confirmLabel="Approve"
        reasonLabel="Reason (optional)"
        isLoading={approveMutation.isPending}
        onConfirm={(reason) => approveMutation.mutate({ id: approveTarget.id, reason })}
        onCancel={() => setApproveTarget(null)}
      />

      <ConfirmDialog
        open={!!denyTarget}
        title={`Deny request for "${denyTarget?.resource_name || denyTarget?.resource_id || 'this resource'}"?`}
        description="This rejects the request. The requester will need to submit a new one if access is still needed."
        confirmLabel="Deny"
        destructive
        requireReason
        reasonLabel="Reason for denial (required for the audit record)"
        isLoading={denyMutation.isPending}
        onConfirm={(reason) => denyMutation.mutate({ id: denyTarget.id, reason })}
        onCancel={() => setDenyTarget(null)}
      />
    </div>
  )
}

// ---------------------------------------------------------------------------
// Self-service
// ---------------------------------------------------------------------------

const QUICK_LINKS = [
  { to: '/resources', label: 'Resources', icon: Boxes, description: 'Browse systems you can connect to' },
  { to: '/vault', label: 'Vault', icon: Vault, description: 'Safes, folders & credentials' },
  { to: '/sessions', label: 'Sessions', icon: Radio, description: 'Your connection history' },
  { to: '/jit', label: 'JIT Access', icon: KeyRound, description: 'Request or view time-boxed access' },
  { to: '/audit', label: 'Audit', icon: ScrollText, description: 'Search your activity trail' },
]

function UserDashboard({ user }) {
  const [range, setRange] = useState('7d')

  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMyGrants({ activeOnly: true, pageSize: 25, signal }),
  })
  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', 'mine', { status: 'PENDING', dashboard: true }],
    queryFn: ({ signal }) => listMyJitRequests({ status: 'PENDING', pageSize: 5, signal }),
  })
  const sessionsQuery = useQuery({
    queryKey: ['sessions', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMySessions({ activeOnly: true, pageSize: 5, signal }),
  })
  const auditQuery = useQuery({
    queryKey: ['audit', 'dashboard-sample'],
    queryFn: ({ signal }) => searchAudit({ limit: AUDIT_SAMPLE, offset: 0 }, signal),
    retry: false,
  })

  const events = useMemo(() => auditQuery.data?.items || [], [auditQuery.data])
  const grants = grantsQuery.data?.grants || []
  const expiring = useMemo(() => expiringGrants(grants), [grants])
  const pendingRequests = requestsQuery.data?.requests ?? []

  return (
    <div>
      <PageHeader
        eyebrow="Overview"
        title={`Welcome${user?.username ? `, ${user.username}` : ''}`}
        description="Your access at a glance — elevation in force, requests in flight, live sessions, and what you've been doing."
      />

      <Section label="Your access">
        <KpiStrip
          items={[
            {
              key: 'grants',
              label: 'Active grants',
              icon: Lock,
              tone: 'emerald',
              loading: grantsQuery.isLoading,
              value: grantsQuery.data?.pagination?.total ?? grants.length,
              description: 'Elevation available to you right now',
              to: '/jit',
            },
            {
              key: 'expiring',
              label: 'Expiring soon',
              icon: Clock,
              tone: expiring.some((e) => e.tone === 'red') ? 'red' : expiring.length > 0 ? 'amber' : 'default',
              loading: grantsQuery.isLoading,
              value: expiring.length,
              description: 'Within the next 12 hours',
              to: '/jit',
            },
            {
              key: 'requests',
              label: 'Pending requests',
              icon: KeyRound,
              tone: 'amber',
              loading: requestsQuery.isLoading,
              value: requestsQuery.data?.pagination?.total ?? pendingRequests.length,
              description: 'Waiting on an approver',
              to: '/jit',
            },
            {
              key: 'sessions',
              label: 'Active sessions',
              icon: Activity,
              live: true,
              loading: sessionsQuery.isLoading,
              value: sessionsQuery.data?.pagination?.total ?? sessionsQuery.data?.sessions?.length ?? 0,
              description: 'Connections open in your name',
              to: '/sessions',
            },
          ]}
        />
      </Section>

      <Section label="Needs your attention">
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle icon={Clock}>Access expiring soon</CardTitle>
              <span className="ml-auto">
                <SectionLink to="/jit">All grants</SectionLink>
              </span>
            </CardHeader>
            {grantsQuery.isLoading ? (
              <div className="space-y-2 p-4">
                {[0, 1].map((i) => (
                  <div key={i} className="h-10 animate-pulse rounded-lg bg-surface-850" />
                ))}
              </div>
            ) : expiring.length === 0 ? (
              <EmptyState
                icon={CheckCircle2}
                title="Nothing expiring in the next 12 hours"
                description="Grants approaching expiry appear here so a session doesn't end mid-task."
                className="py-10"
              />
            ) : (
              <ul className="divide-y divide-surface-800">
                {expiring.slice(0, 5).map(({ grant, label, tone }) => (
                  <li key={grant.id} className="flex items-center justify-between gap-4 px-4 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-ink-100">
                        {grant.resource_name || grant.resource_id || '—'}
                      </p>
                      <p className="mt-0.5 truncate text-xs text-ink-500">
                        Expires {formatDateTime(grant.expires_at)}
                      </p>
                    </div>
                    <span
                      className={clsx(
                        'flex-none rounded-md px-2 py-1 text-2xs font-semibold tabular-nums ring-1 ring-inset',
                        tone === 'red'
                          ? 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25'
                          : tone === 'amber'
                            ? 'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25'
                            : 'bg-surface-800 text-ink-400 ring-surface-700'
                      )}
                    >
                      {label}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle icon={KeyRound}>Requests in flight</CardTitle>
              <span className="ml-auto">
                <SectionLink to="/jit">View all</SectionLink>
              </span>
            </CardHeader>
            <QueryState
              query={requestsQuery}
              empty={(d) => !d?.requests || d.requests.length === 0}
              emptyTitle="No requests awaiting approval"
              emptyMessage="Requests you submit for time-boxed access appear here until an approver decides."
              skeletonRows={3}
            >
              {() => (
                <ul className="divide-y divide-surface-800">
                  {pendingRequests.map((r) => (
                    <li key={r.id}>
                      <Link
                        to={`/jit/requests/${r.id}`}
                        className="group flex items-center justify-between gap-4 px-4 py-3 transition-colors hover:bg-surface-850"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-ink-100">
                            {r.resource_name || r.resource_id}
                          </p>
                          <p className="mt-0.5 text-xs text-ink-500">
                            Requested {formatRelativeToNow(r.created_at)}
                          </p>
                        </div>
                        <div className="flex flex-none items-center gap-2.5">
                          <Badge className={JIT_STATUS_BADGE[r.status]}>
                            {JIT_STATUS_LABELS[r.status] || r.status}
                          </Badge>
                          <ChevronRight
                            className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                            strokeWidth={1.5}
                          />
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </QueryState>
          </Card>
        </div>
      </Section>

      <Section label="Your activity">
        <ActivityAnalysis
          events={events}
          loading={auditQuery.isLoading}
          range={range}
          onRangeChange={setRange}
          auditHref="/audit"
          scopeNote={`Your own trail, from your ${AUDIT_SAMPLE} most recent audit entries.`}
        />
      </Section>

      <Section label="Go to">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {QUICK_LINKS.map((l) => (
            <NavPlate key={l.to} {...l} />
          ))}
        </div>
      </Section>
    </div>
  )
}

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  return isAdmin ? <AdminDashboard user={user} /> : <UserDashboard user={user} />
}
