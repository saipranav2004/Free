import clsx from 'clsx'
import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'
import { Checkbox } from '../common/Checkbox'
import { SortHeader } from '../common/TableControls'
import { StatusIndicator } from '../common/Badge'
import { stickyCell, stickyHeader, cell, COL, TruncCell } from '../common/tableStyles'
import { ResourceTypeIcon } from './ResourceTypeIcon'
import { resourceTypeLabel } from './ResourceCard'

// ---------------------------------------------------------------------------
// Resources table
// ---------------------------------------------------------------------------
// Two things were wrong and both are fixed here.
//
// 1. FROZEN COLUMNS SMEARED ON HORIZONTAL SCROLL. The select and name cells
//    were `bg-inherit` while the row colour lived on the `<tr>` — and a
//    `<tr>` is transparent by default, so the frozen cells were see-through
//    and every other column scrolled visibly underneath them. They now paint
//    their own opaque background for every row state, and the last frozen
//    column carries a hairline + shadow so the freeze boundary is visible
//    rather than implied. See components/common/tableStyles.js.
//
// 2. EVERY COLUMN THE SAME WIDTH. Auto table layout shares width by content,
//    so a 40-character hostname and a 4-digit port competed for the same
//    space and both lost. `table-fixed` plus a declared width per column
//    gives data-shaped columns exactly what they need and hands the slack to
//    the resource name. Overflow truncates with the full value on `title`.
//
// The status columns also stop being coloured pills. Access/Credential/Status
// are populated on EVERY row, so as filled chips they produced ~75 saturated
// blocks per screen — which in dark mode glow and drown the data. They are
// now dot-plus-text indicators, the treatment AWS, Google Cloud and Okta all
// use for per-row state. Filled badges are kept for exceptions only.

export const RESOURCE_COLUMNS = [
  { key: 'name', label: 'Resource', required: true },
  { key: 'resource_type', label: 'Type' },
  { key: 'host', label: 'Host' },
  { key: 'port', label: 'Port', align: 'right' },
  { key: 'group', label: 'Group' },
  { key: 'database_name', label: 'Database' },
  { key: 'access', label: 'Access' },
  { key: 'credential', label: 'Credential' },
  { key: 'status', label: 'Status' },
]

export function ResourceTable({
  rows,
  sort,
  onSort,
  density,
  visibleColumns,
  isSelected,
  onToggleRow,
  onToggleAll,
  allOnPageSelected,
  someOnPageSelected,
  onPeek,
  focusedId,
}) {
  const show = (key) => !visibleColumns || visibleColumns.includes(key)
  const pad = density === 'compact' ? 'py-2' : 'py-3'

  return (
    <div className="relative overflow-x-auto overscroll-x-contain">
      <table className="w-full min-w-[64rem] table-fixed border-separate border-spacing-0 text-sm">
        <colgroup>
          <col className={COL.select} />
          {show('name') && <col className={COL.name} />}
          {show('resource_type') && <col className={COL.short} />}
          {show('host') && <col className={COL.wide} />}
          {show('port') && <col className={COL.count} />}
          {show('group') && <col className={COL.medium} />}
          {show('database_name') && <col className={COL.medium} />}
          {show('access') && <col className={COL.status} />}
          {show('credential') && <col className={COL.status} />}
          {show('status') && <col className={COL.status} />}
          <col className={COL.actions} />
        </colgroup>

        <thead>
          <tr>
            <th scope="col" className={clsx(stickyHeader({ left: 'left-0', edge: !show('name') }), 'px-4 py-2.5')}>
              <Checkbox
                checked={allOnPageSelected}
                indeterminate={someOnPageSelected}
                onChange={onToggleAll}
                srLabel="Select all rows on this page"
              />
            </th>
            {show('name') && (
              <SortHeader
                label="Resource"
                columnKey="name"
                sort={sort}
                onSort={onSort}
                className={clsx(stickyHeader({ left: 'left-12', edge: true }), 'z-30')}
              />
            )}
            {show('resource_type') && <SortHeader label="Type" columnKey="resource_type" sort={sort} onSort={onSort} />}
            {show('host') && <SortHeader label="Host" columnKey="host" sort={sort} onSort={onSort} />}
            {show('port') && <SortHeader label="Port" columnKey="port" sort={sort} onSort={onSort} align="right" />}
            {show('group') && <SortHeader label="Group" columnKey="group" sort={sort} onSort={onSort} />}
            {show('database_name') && <SortHeader label="Database" columnKey="database_name" sort={sort} onSort={onSort} />}
            {show('access') && <SortHeader label="Access" columnKey="requires_jit" sort={sort} onSort={onSort} />}
            {show('credential') && <SortHeader label="Credential" columnKey="vault_entry_id" sort={sort} onSort={onSort} />}
            {show('status') && <SortHeader label="Status" columnKey="is_active" sort={sort} onSort={onSort} />}
            <SortHeader label="Open" columnKey="_open" srOnly />
          </tr>
        </thead>

        <tbody>
          {rows.map((r) => {
            const selected = isSelected(r)
            return (
              <tr
                key={r.id}
                data-row-id={r.id}
                className={clsx('group', focusedId === r.id && 'outline outline-1 -outline-offset-1 outline-blue-500/40')}
              >
                <td className={clsx(stickyCell({ left: 'left-0', selected, edge: !show('name') }), 'px-4', pad)}>
                  <Checkbox checked={selected} onChange={() => onToggleRow(r)} srLabel={`Select ${r.name}`} />
                </td>

                {show('name') && (
                  <td className={clsx(stickyCell({ left: 'left-12', selected, edge: true }), 'px-4', pad)}>
                    <div className="flex min-w-0 items-center gap-2.5">
                      <ResourceTypeIcon type={r.resource_type} className="h-4 w-4 flex-none" />
                      <button
                        type="button"
                        onClick={() => onPeek(r)}
                        title={r.name}
                        className="min-w-0 flex-1 truncate text-left font-medium text-ink-50 outline-none transition-colors hover:text-blue-600 dark:hover:text-blue-300"
                      >
                        {r.name}
                      </button>
                    </div>
                  </td>
                )}

                {show('resource_type') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    <TruncCell value={resourceTypeLabel(r.resource_type)} />
                  </td>
                )}

                {show('host') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    <TruncCell value={r.host} mono />
                  </td>
                )}

                {show('port') && (
                  <td className={clsx(cell({ selected }), 'px-4 text-right font-mono text-xs tabular-nums text-ink-300', pad)}>
                    {r.port ?? '—'}
                  </td>
                )}

                {show('group') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    <TruncCell value={r.group} muted />
                  </td>
                )}

                {show('database_name') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    <TruncCell value={r.database_name} muted />
                  </td>
                )}

                {/* Access is the one column where the two values mean
                    genuinely different things operationally, so JIT gets the
                    warmer dot — but neither is a filled chip. */}
                {show('access') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    {r.requires_jit ? (
                      <StatusIndicator tone="amber" title="Requires an approved just-in-time request">
                        JIT required
                      </StatusIndicator>
                    ) : (
                      <StatusIndicator tone="blue" title="Available without a request">
                        Standing
                      </StatusIndicator>
                    )}
                  </td>
                )}

                {show('credential') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    {r.vault_entry_id ? (
                      <StatusIndicator tone="emerald">Attached</StatusIndicator>
                    ) : (
                      <StatusIndicator tone="neutral">None</StatusIndicator>
                    )}
                  </td>
                )}

                {show('status') && (
                  <td className={clsx(cell({ selected }), 'px-4', pad)}>
                    {r.is_active ? (
                      <StatusIndicator tone="emerald">Active</StatusIndicator>
                    ) : (
                      <StatusIndicator tone="neutral">Inactive</StatusIndicator>
                    )}
                  </td>
                )}

                <td className={clsx(cell({ selected }), 'px-2', pad)}>
                  <Link
                    to={`/resources/${r.id}`}
                    aria-label={`Open ${r.name}`}
                    className="ml-auto flex h-7 w-7 items-center justify-center rounded-md text-ink-600 transition-colors hover:bg-surface-800 hover:text-ink-100"
                  >
                    <ChevronRight className="h-4 w-4" strokeWidth={2} />
                  </Link>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
