import clsx from 'clsx'

// ---------------------------------------------------------------------------
// Charts
// ---------------------------------------------------------------------------
// Hand-drawn SVG, no charting dependency. Three reasons that is the right
// call here rather than a limitation:
//
//   1. No new npm dependency can be added to this project, and a chart
//      library is a large one to take for four small visualisations.
//   2. Every chart below renders from data the console has ALREADY fetched
//      for another purpose (the audit page's own event rows), so there is no
//      extra request and nothing can disagree with the tables.
//   3. These are read-at-a-glance instruments, not exploratory analytics —
//      no zoom, no brush, no legend interactions to implement.
//
// Every chart states its sample in the caller's caption. None of them invent
// a trend line, a forecast, or a comparison period the data can't support.

// --- area / volume over time -------------------------------------------------

export function AreaChart({ points, height = 132, accent = 'blue', valueLabel = 'events' }) {
  const data = Array.isArray(points) ? points : []
  if (data.length < 2) {
    return (
      <div
        style={{ height }}
        className="flex items-center justify-center text-xs text-ink-500"
      >
        Not enough data to plot
      </div>
    )
  }

  const W = 100 // viewBox units — the SVG scales to its container width
  const H = 100
  const max = Math.max(...data.map((d) => d.value), 1)
  const stepX = W / (data.length - 1)

  const coords = data.map((d, i) => ({
    x: i * stepX,
    y: H - (d.value / max) * (H - 8),
    ...d,
  }))

  const line = coords.map((c, i) => `${i === 0 ? 'M' : 'L'}${c.x.toFixed(2)},${c.y.toFixed(2)}`).join(' ')
  const area = `${line} L${W},${H} L0,${H} Z`

  const stroke = accent === 'red' ? 'rgb(239 68 68)' : accent === 'emerald' ? 'rgb(16 185 129)' : 'rgb(37 99 235)'
  const fillId = `area-${accent}`

  const peak = coords.reduce((a, b) => (b.value > a.value ? b : a), coords[0])

  return (
    <div className="relative" style={{ height }}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        preserveAspectRatio="none"
        className="h-full w-full overflow-visible"
        role="img"
        aria-label={`${valueLabel} over time, peak ${peak.value} at ${peak.label}`}
      >
        <defs>
          <linearGradient id={fillId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={stroke} stopOpacity="0.22" />
            <stop offset="100%" stopColor={stroke} stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Reference grid — three lines, not a full graticule: enough to read
            magnitude, quiet enough not to compete with the series. */}
        {[0.25, 0.5, 0.75].map((f) => (
          <line
            key={f}
            x1="0"
            x2={W}
            y1={H * f}
            y2={H * f}
            stroke="currentColor"
            className="text-surface-800"
            strokeWidth="0.4"
            vectorEffect="non-scaling-stroke"
          />
        ))}

        <path d={area} fill={`url(#${fillId})`} />
        <path
          d={line}
          fill="none"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinejoin="round"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
        />
        <circle cx={peak.x} cy={peak.y} r="2" fill={stroke} vectorEffect="non-scaling-stroke" />
      </svg>

      <div className="mt-2 flex justify-between text-2xs tabular-nums text-ink-500">
        <span>{data[0].label}</span>
        <span className="font-medium text-ink-400">
          peak {peak.value.toLocaleString()} · {peak.label}
        </span>
        <span>{data[data.length - 1].label}</span>
      </div>
    </div>
  )
}

// --- donut -------------------------------------------------------------------

const DONUT_TONES = {
  emerald: 'rgb(16 185 129)',
  red: 'rgb(239 68 68)',
  amber: 'rgb(245 158 11)',
  blue: 'rgb(37 99 235)',
  ink: 'rgb(148 163 184)',
}

export function DonutChart({ segments, size = 132, centerValue, centerLabel }) {
  const parts = (segments || []).filter((s) => s.value > 0)
  const total = parts.reduce((sum, s) => sum + s.value, 0)

  const R = 42
  const C = 2 * Math.PI * R
  let offset = 0

  return (
    <div className="flex items-center gap-5">
      <div className="relative flex-none" style={{ width: size, height: size }}>
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90" role="img" aria-label={centerLabel}>
          <circle
            cx="50"
            cy="50"
            r={R}
            fill="none"
            stroke="currentColor"
            className="text-surface-800"
            strokeWidth="11"
          />
          {total > 0 &&
            parts.map((s) => {
              const len = (s.value / total) * C
              const el = (
                <circle
                  key={s.key}
                  cx="50"
                  cy="50"
                  r={R}
                  fill="none"
                  stroke={DONUT_TONES[s.tone] || DONUT_TONES.blue}
                  strokeWidth="11"
                  strokeDasharray={`${len} ${C - len}`}
                  strokeDashoffset={-offset}
                  strokeLinecap="butt"
                />
              )
              offset += len
              return el
            })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-xl font-semibold tabular-nums leading-none text-ink-50">
            {centerValue}
          </span>
          {centerLabel && (
            <span className="mt-1 text-2xs font-medium uppercase tracking-[0.08em] text-ink-500">
              {centerLabel}
            </span>
          )}
        </div>
      </div>

      <ul className="min-w-0 flex-1 space-y-2">
        {(segments || []).map((s) => (
          <li key={s.key} className="flex items-center gap-2.5">
            <span
              aria-hidden="true"
              className="h-2 w-2 flex-none rounded-full"
              style={{ background: DONUT_TONES[s.tone] || DONUT_TONES.blue }}
            />
            <span className="min-w-0 flex-1 truncate text-xs text-ink-300">{s.label}</span>
            <span className="flex-none text-xs font-semibold tabular-nums text-ink-100">
              {s.value.toLocaleString()}
            </span>
            <span className="w-9 flex-none text-right text-2xs tabular-nums text-ink-500">
              {total > 0 ? `${Math.round((s.value / total) * 100)}%` : '—'}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

// --- ranked bar list ---------------------------------------------------------

export function BarList({ items, emptyLabel = 'Nothing recorded', mono = false, onSelect }) {
  const rows = items || []
  if (rows.length === 0) {
    return <p className="px-4 py-8 text-center text-xs text-ink-500">{emptyLabel}</p>
  }
  const max = Math.max(...rows.map((r) => r.value), 1)

  return (
    <ul className="divide-y divide-surface-800">
      {rows.map((r) => {
        const pct = (r.value / max) * 100
        const Row = onSelect ? 'button' : 'div'
        return (
          <li key={r.key}>
            <Row
              {...(onSelect
                ? { type: 'button', onClick: () => onSelect(r), className: 'group relative block w-full px-4 py-2.5 text-left transition-colors hover:bg-surface-850' }
                : { className: 'relative px-4 py-2.5' })}
            >
              {/* The bar is the row's own background, not a separate column —
                  keeps the label readable at any length and avoids a fixed
                  gutter that truncates long action strings. */}
              <span
                aria-hidden="true"
                className={clsx(
                  'absolute inset-y-1 left-0 rounded-r-md',
                  r.tone === 'red'
                    ? 'bg-red-500/[0.14]'
                    : r.tone === 'amber'
                      ? 'bg-amber-500/[0.14]'
                      : 'bg-blue-500/[0.11]'
                )}
                style={{ width: `${Math.max(pct, 3)}%` }}
              />
              <span className="relative flex items-center gap-3">
                <span
                  className={clsx(
                    'min-w-0 flex-1 truncate text-xs text-ink-100',
                    mono && 'font-mono',
                    onSelect && 'group-hover:text-blue-600 dark:group-hover:text-blue-300'
                  )}
                  title={r.label}
                >
                  {r.label}
                </span>
                {r.meta && <span className="flex-none text-2xs text-ink-500">{r.meta}</span>}
                <span className="flex-none text-xs font-semibold tabular-nums text-ink-200">
                  {r.value.toLocaleString()}
                </span>
              </span>
            </Row>
          </li>
        )
      })}
    </ul>
  )
}
