import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  LayoutDashboard, Boxes, Vault, Radio, KeyRound, ScrollText,
  LogOut, Settings as SettingsIcon, Users, Lock, FileKey2,
  ClipboardList, Archive, Menu, X, PanelLeftClose, PanelLeftOpen,
  ChevronRight,
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { me, logout as logoutApi } from '../../api/auth'
import { ROLE_BADGE } from '../../config/constants'
import { Badge } from './Badge'
import { ThemeToggle } from './ThemeToggle'
import { toast } from 'sonner'
import logoMark from '../../assets/logo-mark.png'

// Self-service — visible to every authenticated user, regardless of role.
const CONSOLE_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/resources', label: 'Resources', icon: Boxes },
  { to: '/vault', label: 'Vault', icon: Vault },
  { to: '/sessions', label: 'Sessions', icon: Radio },
  { to: '/jit', label: 'JIT Access', icon: KeyRound },
  { to: '/audit', label: 'Audit', icon: ScrollText },
]

// Admin Center — only rendered for accounts holding the "admin" or "root"
// role (see AdminRoute for the matching route guard). This is PAM's own
// central control plane now; there is no separate admin login, just a
// section of the same console that appears once the JWT says you're allowed
// to see it.
const ADMIN_NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/identity', label: 'Identity', icon: Users },
  { to: '/admin/roles', label: 'Roles', icon: Lock },
  { to: '/admin/policies', label: 'Policies', icon: FileKey2 },
  { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound },
  { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
  { to: '/admin/vault-ops', label: 'Vault Operations', icon: Archive },
]

// Presentational only — maps a path segment to a human label for the
// topbar breadcrumb. Reads location; never influences routing or fetching.
const CRUMB_LABELS = {
  resources: 'Resources',
  vault: 'Vault',
  sessions: 'Sessions',
  jit: 'JIT Access',
  requests: 'Request',
  audit: 'Audit',
  settings: 'Settings',
  admin: 'Admin Center',
  identity: 'Identity',
  roles: 'Roles',
  policies: 'Policies',
  'vault-ops': 'Vault Operations',
  credentials: 'Credential',
  'mfa-verify': 'Verification',
}

const SIDEBAR_STORAGE_KEY = 'pam_sidebar_collapsed'

// Sidebar starts OPEN. It only stays collapsed if this user explicitly
// collapsed it before (persisted per browser) — a missing/invalid value
// always resolves to open.
function readCollapsed() {
  try {
    return localStorage.getItem(SIDEBAR_STORAGE_KEY) === '1'
  } catch {
    return false
  }
}

function NavItem({ to, label, icon: Icon, end, onNavigate, collapsed }) {
  return (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      title={collapsed ? label : undefined}
      className={({ isActive }) =>
        clsx(
          'group relative flex items-center rounded-lg text-[0.8125rem] font-medium outline-none transition-all duration-150',
          collapsed ? 'h-10 w-10 justify-center' : 'h-9 gap-2.5 pl-2.5 pr-3',
          isActive
            ? 'bg-blue-50 text-blue-700 ring-1 ring-inset ring-blue-600/15 dark:bg-blue-500/[0.12] dark:text-blue-100 dark:ring-blue-400/20'
            : 'text-ink-400 hover:bg-surface-800/70 hover:text-ink-50'
        )
      }
    >
      {({ isActive }) => (
        <>
          {/* Active rail — the enterprise-console convention for "you are
              here", readable at a glance even in the collapsed icon rail. */}
          <span
            aria-hidden="true"
            className={clsx(
              'absolute -left-3 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-blue-600 transition-all duration-200 ease-emphasis dark:bg-blue-400',
              isActive ? 'opacity-100' : 'scale-y-0 opacity-0',
              collapsed && '-left-2'
            )}
          />
          <Icon
            className={clsx(
              'h-[1.05rem] w-[1.05rem] flex-none transition-colors',
              isActive ? 'text-blue-600 dark:text-blue-300' : 'text-ink-500 group-hover:text-ink-200'
            )}
            strokeWidth={1.5}
          />
          {!collapsed && <span className="truncate">{label}</span>}
        </>
      )}
    </NavLink>
  )
}

function NavSection({ label, items, collapsed, onNavigate }) {
  return (
    <div>
      {!collapsed && label && (
        <div className="mb-1.5 flex items-center gap-2 px-2.5">
          <p className="flex-none text-2xs font-semibold uppercase tracking-[0.12em] text-ink-600">{label}</p>
          <span className="h-px flex-1 bg-surface-800" aria-hidden="true" />
        </div>
      )}
      {collapsed && label && <div className="mx-auto mb-2 h-px w-5 bg-surface-700" aria-hidden="true" />}
      <div className={clsx('space-y-0.5', collapsed && 'flex flex-col items-center')}>
        {items.map((item) => (
          <NavItem key={item.to} {...item} collapsed={collapsed} onNavigate={onNavigate} />
        ))}
      </div>
    </div>
  )
}

// Collapse control — pinned to the sidebar's own top-right corner, the
// placement every mature enterprise console uses (Okta, Entra ID, CyberArk).
// It belongs to the panel it resizes, so the affordance points at the edge
// that actually moves; when collapsed it centres in the icon rail.
function SidebarCollapseControl({ collapsed, onToggle }) {
  return (
    <div
      className={clsx(
        'flex flex-none items-center px-3 pt-3.5',
        collapsed ? 'justify-center' : 'justify-end'
      )}
    >
      <button
        type="button"
        onClick={onToggle}
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        aria-pressed={collapsed}
        title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-500 transition-colors duration-150 hover:bg-surface-800 hover:text-ink-100"
      >
        {collapsed ? (
          <PanelLeftOpen className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
        ) : (
          <PanelLeftClose className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.5} />
        )}
      </button>
    </div>
  )
}

// Console identity, role-dependent: administrators operate the identity
// control plane ("IAM Console"), everyone else the privileged access console
// ("PAM Console"). Plain text at the foot of the panel — no icon, no plate.
function SidebarConsoleTitle({ consoleTitle, collapsed }) {
  if (collapsed) return null
  return (
    <p className="flex-none px-4 pb-5 pt-2 text-xs font-medium tracking-[0.01em] text-ink-500">
      {consoleTitle}
    </p>
  )
}

function SidebarContent({ isAdmin, onNavigate, collapsed }) {
  return (
    <>
      <nav
        aria-label="Primary"
        className={clsx(
          'scrollbar-none flex-1 space-y-6 overflow-y-auto overflow-x-hidden pb-4 pt-3',
          collapsed ? 'px-3' : 'px-4'
        )}
      >
        <NavSection label={collapsed ? null : 'Console'} items={CONSOLE_NAV} collapsed={collapsed} onNavigate={onNavigate} />
        {isAdmin && (
          <NavSection label="Admin Center" items={ADMIN_NAV} collapsed={collapsed} onNavigate={onNavigate} />
        )}
      </nav>
    </>
  )
}

function initialsOf(name) {
  if (!name) return '—'
  const parts = String(name).replace(/[._-]+/g, ' ').trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '—'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

function Avatar({ name, size = 'md' }) {
  return (
    <span
      aria-hidden="true"
      className={clsx(
        'flex flex-none items-center justify-center rounded-lg bg-blue-600 font-semibold uppercase tracking-wide text-white ring-1 ring-inset ring-white/15',
        size === 'sm' ? 'h-7 w-7 text-2xs' : 'h-8 w-8 text-xs'
      )}
    >
      {initialsOf(name)}
    </span>
  )
}

// Topbar breadcrumb, derived from the URL. Presentational only.
function Breadcrumb() {
  const { pathname } = useLocation()
  const crumbs = useMemo(() => {
    const parts = pathname.split('/').filter(Boolean)
    if (parts.length === 0) return []
    const out = []
    let acc = ''
    for (const p of parts) {
      acc += `/${p}`
      const label = CRUMB_LABELS[p]
      // Opaque segments (UUIDs, numeric ids) get a neutral label rather
      // than being printed raw — a 36-character UUID in a breadcrumb is
      // noise, not navigation.
      out.push({ to: acc, label: label || (p.length > 12 ? 'Detail' : p) })
    }
    return out
  }, [pathname])

  if (crumbs.length === 0) return null

  return (
    <nav aria-label="Breadcrumb" className="hidden min-w-0 items-center gap-1.5 text-xs md:flex">
      <NavLink to="/" className="flex-none text-ink-500 transition-colors hover:text-ink-100">
        Home
      </NavLink>
      {crumbs.map((c, i) => (
        <span key={c.to} className="flex min-w-0 items-center gap-1.5">
          <ChevronRight className="h-3 w-3 flex-none text-ink-600" strokeWidth={2} />
          {i === crumbs.length - 1 ? (
            <span className="truncate font-medium text-ink-200">{c.label}</span>
          ) : (
            <NavLink to={c.to} className="truncate text-ink-500 transition-colors hover:text-ink-100">
              {c.label}
            </NavLink>
          )}
        </span>
      ))}
    </nav>
  )
}

export function AppLayout() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const setUser = useAuthStore((s) => s.setUser)
  const doLogout = useAuthStore((s) => s.logout)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(readCollapsed)

  // Role-dependent console title (see SidebarBrand).
  const consoleTitle = isAdmin ? 'IAM Console' : 'PAM Console'

  const toggleCollapsed = useCallback(() => {
    setCollapsed((v) => {
      const next = !v
      try {
        localStorage.setItem(SIDEBAR_STORAGE_KEY, next ? '1' : '0')
      } catch {
        // Storage can be unavailable (private mode / locked-down profile) —
        // the toggle still works for this session, it just won't persist.
      }
      return next
    })
  }, [])

  // /auth/me is the source of truth for "who am I" — login only returns
  // access_token/expires_at, not the user's profile, so this fetch is what
  // actually populates the header/username/roles rather than showing blank
  // (and is also what AdminRoute/the nav's isAdmin() check depends on).
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal), retry: false })

  useEffect(() => {
    if (meQuery.data) setUser(meQuery.data)
  }, [meQuery.data, setUser])

  // Close the mobile drawer on Escape — a drawer you can only dismiss by
  // hitting a small X is a real accessibility gap.
  useEffect(() => {
    if (!mobileNavOpen) return undefined
    const onKey = (e) => e.key === 'Escape' && setMobileNavOpen(false)
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [mobileNavOpen])

  const handleLogout = async () => {
    try {
      await logoutApi()
    } catch {
      // Even if the server-side logout call fails (network blip, already
      // expired token), we still clear the local session below — a failed
      // logout call must never leave the user stuck "logged in" client-side
      // when they explicitly asked to log out.
    } finally {
      doLogout()
      navigate('/login', { replace: true })
      toast.success('Logged out')
    }
  }

  const roles = user?.roles || []
  const displayName = user?.username || (meQuery.isLoading ? '…' : 'Signed in')

  return (
    // h-screen + overflow-hidden pins this whole shell to exactly the
    // viewport height, so the browser's own document scrollbar never kicks
    // in. Previously this was min-h-screen, which lets the container grow
    // taller than the viewport with tall page content — at that point the
    // *document* scrolls, dragging the sidebar along with everything else
    // instead of leaving it in place. Now only <main> below scrolls
    // internally; the sidebar (and topbar) stay fixed on screen.
    <div className="flex h-screen overflow-hidden bg-surface-950">
      {/* Desktop sidebar. Its own surface step (surface-1000) sits one level
          behind the content plane, which is what makes the navigation read
          as chrome rather than as another panel of content — the separation
          does more for perceived quality than any amount of styling on the
          items themselves. Open by default; collapsing narrows it to an
          icon rail. */}
      <aside
        className={clsx(
          'relative hidden flex-none flex-col border-r border-surface-800 bg-surface-1000 transition-[width] duration-200 ease-emphasis md:flex',
          collapsed ? 'w-[4.75rem]' : 'w-[16.5rem]'
        )}
      >
        <SidebarCollapseControl collapsed={collapsed} onToggle={toggleCollapsed} />
        <SidebarContent isAdmin={isAdmin} onNavigate={() => {}} collapsed={collapsed} />
        <SidebarConsoleTitle consoleTitle={consoleTitle} collapsed={collapsed} />
      </aside>

      {/* Mobile sidebar (overlay) */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div
            className="animate-overlay-in fixed inset-0 bg-slate-950/55 backdrop-blur-[3px] dark:bg-black/70"
            onClick={() => setMobileNavOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative flex w-[17rem] flex-col border-r border-surface-800 bg-surface-1000 shadow-overlay">
            <button
              onClick={() => setMobileNavOpen(false)}
              className="absolute right-3 top-3.5 flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-50"
              aria-label="Close menu"
            >
              <X className="h-4 w-4" strokeWidth={2} />
            </button>
            <div className="h-12 flex-none" aria-hidden="true" />
            <SidebarContent
              isAdmin={isAdmin}
              onNavigate={() => setMobileNavOpen(false)}
              collapsed={false}
            />
            <SidebarConsoleTitle consoleTitle={consoleTitle} collapsed={false} />
          </aside>
        </div>
      )}

      {/* min-h-0 overrides flex's default min-height:auto — without it, a
          flex child (main, below) can't shrink below its content height,
          so overflow-y-auto never actually engages and the page scrolls as
          a whole instead of just the content area. */}
      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="z-20 flex h-14 flex-none items-center gap-2 border-b border-surface-800 bg-surface-900/85 px-3 backdrop-blur-md sm:px-5">
          <button
            onClick={() => setMobileNavOpen(true)}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-surface-800 hover:text-ink-50 md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.5} />
          </button>

          <Breadcrumb />

          {/* Product mark on small screens, where the sidebar (and its
              brand block) is off-canvas. */}
          <div className="flex min-w-0 flex-1 items-center gap-2.5 md:hidden">
            <img src={logoMark} alt="Deep Algorithms" className="h-6 w-6 flex-none object-contain" />
            <span className="truncate text-xs font-semibold uppercase tracking-[0.11em] text-ink-100">
              {consoleTitle}
            </span>
          </div>
          <div className="hidden flex-1 md:block" />

          <ThemeToggle compact />

          <div className="mx-1 hidden h-5 w-px bg-surface-700 sm:block" aria-hidden="true" />

          <div className="relative">
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={userMenuOpen}
              className="flex items-center gap-2.5 rounded-lg py-1 pl-1 pr-2 text-sm text-ink-200 transition-colors hover:bg-surface-800"
            >
              <Avatar name={user?.username} />
              <span className="hidden max-w-[11rem] truncate font-medium sm:inline" title={user?.username}>
                {displayName}
              </span>
            </button>
            {userMenuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
                <div
                  role="menu"
                  className="animate-menu-in absolute right-0 z-20 mt-2 w-60 overflow-hidden rounded-xl border border-surface-700 bg-surface-900 shadow-overlay"
                >
                  <div className="flex items-center gap-3 border-b border-surface-800 px-3.5 py-3">
                    <Avatar name={user?.username} />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-ink-50">{user?.username || '—'}</p>
                      <p className="truncate text-xs text-ink-500">{user?.email || '—'}</p>
                    </div>
                  </div>
                  {roles.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 border-b border-surface-800 px-3.5 py-2.5">
                      {roles.map((r) => (
                        <Badge key={r} className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                          {r}
                        </Badge>
                      ))}
                    </div>
                  )}
                  <div className="p-1.5">
                    <NavLink
                      to="/settings"
                      role="menuitem"
                      onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-ink-200 transition-colors hover:bg-surface-800 hover:text-ink-50"
                    >
                      <SettingsIcon className="h-4 w-4 text-ink-500" strokeWidth={1.5} /> Settings
                    </NavLink>
                    <button
                      role="menuitem"
                      onClick={handleLogout}
                      className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm font-medium text-red-600 transition-colors hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                    >
                      <LogOut className="h-4 w-4" strokeWidth={1.5} /> Log out
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </header>

        <main className="min-w-0 flex-1 overflow-y-auto">
          <div className="mx-auto max-w-[82rem] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
