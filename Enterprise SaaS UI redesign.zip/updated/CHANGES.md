# PAM Console — UI/UX redesign drop

Copy this folder's contents over your project root, preserving paths. Only
changed and new files are included — nothing under `src/api`, `src/lib`,
`src/store`, `src/config`, `src/hooks`, `src/main.jsx` or `src/App.jsx` was
touched, so backend calls, payloads, query keys, mutations, cache
invalidation and state flow are byte-for-byte unchanged.

## New files (3)

    src/components/common/Button.jsx      Button / IconButton + buttonClass()
    src/components/common/Modal.jsx       shared modal shell (esc, scroll lock, focus, motion)
    src/assets/logo-wordmark.png          trimmed lockup for the light theme
    src/assets/logo-wordmark-dark.png     same lockup, wordmark reversed for the dark theme
    src/assets/logo-mark.png              square mark for the collapsed rail / mobile bar

`das_logo_light.png` is untouched — the three files above are derived from it.

## Changed files

    index.html                            Inter + JetBrains Mono webfonts (the config
                                          already asked for Inter; it was never loaded)
    tailwind.config.js                    ink-100/300/600 + surface-750/1000 ramp steps,
                                          shadow-card/raised/pop/overlay, text-2xs
    src/index.css                         token sheet: elevation, skeleton shimmer,
                                          overlay/panel/menu motion, focus ring,
                                          reduced-motion, scrollbars

    src/components/common/                AppLayout, Layout, StatCard, Badge, FormFields,
                                          QueryState, Spinner, TabBar, Pagination,
                                          ConfirmDialog, CopyButton, ErrorBoundary,
                                          ThemeToggle
    src/components/admin/                 CreatePolicyModal, CreateRoleModal, CreateUserModal
    src/components/agent/                 AgentDevicesPanel, PairAgentPanel
    src/components/audit/                 AuditEventDetailModal
    src/components/auth/                  MfaEnrollment
    src/components/jit/                   CreateJitRequestModal
    src/components/resources/             ConnectPanel, CreateResourceModal
    src/components/vault/                 BackupRestorePanel, CreateCredentialModal,
                                          CreateFolderModal, CreateSafeModal,
                                          RevealCredentialModal

    src/pages/                            DashboardPage, SettingsPage, NotFoundPage
    src/pages/auth/                       LoginPage, MfaVerifyPage
    src/pages/admin/                      AdminOverviewPage, AdminAuditPage, AdminJitPage,
                                          IdentityListPage, IdentityDetailPage,
                                          PoliciesPage, RolesPage
    src/pages/audit/                      AuditPage
    src/pages/jit/                        JitPage, JitRequestDetailPage
    src/pages/resources/                  ResourcesPage, ResourceDetailPage
    src/pages/sessions/                   SessionsPage
    src/pages/vault/                      SafesListPage, SafeDetailPage, CredentialDetailPage

Unchanged and therefore NOT in this drop: `src/pages/vault/VaultPage.jsx`,
`src/pages/admin/AdminVaultOpsPage.jsx`, `src/components/resources/ResourceTypeIcon.jsx`,
`src/components/auth/ProtectedRoute.jsx`, `src/components/auth/AdminRoute.jsx`,
and everything under `src/api`, `src/lib`, `src/store`, `src/config`, `src/hooks`.

## Notes

- Palette is untouched — same blue-600 accent, same surface/ink values. The
  config additions are new *steps of the existing ramps*, not new hues.
- `ink-100`, `ink-300` and `ink-600` were already referenced across the app
  but were never defined, so those classes silently rendered as inherited
  colour. They now resolve; that is the one behavioural fix in the drop.
- Sidebar is open by default and its collapsed state persists under the
  `pam_sidebar_collapsed` localStorage key.
- Sidebar title is role-derived from the existing `isAdmin()` selector:
  admin/root sees "IAM Console", everyone else "PAM Console".
- No `npm install` needed — no new dependencies.
