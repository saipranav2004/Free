# Changed files — sidebar, login, KPI system, list infrastructure, Resources

Drop these over your `src/` (and `tailwind.config.js`) at the same paths. **38 files: 11 new, 27 updated.**

Every API call, query key, mutation, payload shape and route in the app is unchanged. No endpoint was added, removed or re-parameterised. Where a feature would have needed an endpoint that doesn't exist, it is either derived from data already fetched or shown disabled with the reason — never faked.

---

## Task 1 — Sidebar cleanup

**`src/components/common/AppLayout.jsx`**

| Removed | Added |
|---|---|
| Top branding box (wordmark plate, shield icon, "IAM Console" title, "PRIVILEGED ACCESS" subtitle) | Plain-text console title at the very bottom — no icon, no box, no border, no background |
| Bottom user-profile block (avatar, `das_admin`, `ROOT` badge, logout arrow, entire `SidebarFooter` component) | Collapse control in the sidebar's **top-right corner** |

- **Console title** is role-dependent: `IAM Console` for admin/root, `PAM Console` for everyone else. One `<p>` with `text-xs`, `text-ink-500`, comfortable padding. Hidden when collapsed (it would truncate to nonsense in a 76px rail).
- **Collapse control** moved from the topbar (previously bottom-right area) to the panel's own top-right corner — where Okta, Entra ID and CyberArk put it, because the affordance should sit on the edge that actually moves. Centres itself in the collapsed rail. 32×32 hit area, `PanelLeftClose`/`PanelLeftOpen` at 1.5 stroke, `aria-pressed`, tooltip, unchanged smooth transition.
- **Logout was not lost** — it still lives in the topbar user menu, which was already the primary location.

---

## Task 2 — KPI system (every page with metrics)

**`src/components/common/KpiStrip.jsx`** *(new)* — exports `KpiStrip` and `KpiCell`.

The pattern is taken from **your own Audit Logs screen** (your second reference image), promoted to a shared component: one bordered instrument divided into cells, no gaps — not four floating cards.

```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│ ▣ LABEL      │ ◔ LABEL      │ ⊘ LABEL      │ ⊕ LABEL      │
│ 1,284        │ 46           │ 17           │ 3            │
│ description  │ description  │ description  │ description  │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

Gapped cards make four unrelated objects out of one reading; a divided strip says *these numbers describe the same thing*. Entra ID, Okta and your audit screen all do it this way.

- 28px semibold tabular figures, letterspaced 11px uppercase labels, one description line.
- Six tones. Attention tones (`amber`, `red`) tint the figure itself — a denied count should read red, as it does on your reference.
- `live` adds a pulsing presence dot; `to`/`onClick` makes a cell a drill-through; `loading` renders a shimmer at the figure's size (no layout shift).
- `columns` for hand-composed strips (`<KpiStrip columns={3}><KpiCell …/></KpiStrip>`).

**No trend arrows, deltas, sparklines or "vs. last month" anywhere.** These endpoints return point-in-time counts with no history, so any trend would be invented. The component has no props for them.

Where a figure can only be computed from the current page (server-paged endpoints), the description says "on this page" rather than implying it covers the whole result set.

Applied to: **Dashboard** (Posture, Your access) · **Admin Overview** (approvals, break-glass, chain) · **Identity** · **Resources** (5 cells) · **Vault/Safes** · **Sessions** · **JIT** · **Admin JIT Approvals** · **Audit** · **Admin Audit & Compliance** · **Roles**

---

## Task 2 — Pagination, selection, bulk actions + the rest

### `src/hooks/useTableState.js` *(new)*
Search, faceted filters, sort, pagination and selection in one hook.

**Client-side, by necessity:** `GET /pam/resources/groups` and `GET /admin/identity/users` take no page parameters — they return whole collections. A fake "page 2" request the server ignores would be worse than honest local paging.

**Shaped like a server pager anyway:** returns `{ page, pageSize, total, totalPages, pageRows }` — the same shape your backend's `paged()` helper already produces. When those endpoints grow `page`/`page_size`, pass `serverMode: true` and every consumer keeps working. That's a seam, not a stopgap.

Details worth knowing:
- Sort comparator handles numbers, ISO dates, booleans and strings; nullish always sorts last in both directions. Copies before sorting, so the react-query cache array is never mutated.
- Third click on a column header clears the sort — back to the API's own order.
- Page clamps when a filter shrinks the set (no "Page 9 of 3").
- Selection clears on filter/search change — a selection that survives a filter applies to rows the user can't see.
- `pageSize`, `sort`, `density` and column visibility persist per table in `localStorage`, guarded so a locked-down profile degrades to "prefs don't stick" rather than throwing.

### `src/components/common/Pagination.jsx` *(rewritten)*
`Showing 1–25 of 1,284` · rows-per-page (10/25/50/100, or 12/24/48/96 for the card grid) · first/prev/**windowed page numbers with ellipses**/next/last. The window is a constant width so the control doesn't resize as you walk pages. Renders the count and page-size selector even on a single page — otherwise a filter that narrows to one page removes "how many are there?" from the screen.

### `src/components/common/BulkActionBar.jsx` *(new)*
Floats over content when anything is ticked (wedging a bar above the table pushes rows away from the cursor).

Two deliberate behaviours:
1. **Scope is explicit.** "12 selected" and "all 1,284 matching your filters" are different claims. When a full page is ticked and more rows match, widening is offered as a separate second click. Internally, all-matching mode stores *exclusions*, so "all 1,284 except these two" is expressible.
2. **Unavailable actions are visible, not hidden.** Per your instruction, destructive bulk actions ship **disabled with a lock icon and the reason** — *"Requires a backend batch endpoint — not available yet."* Enable/disable, rotate credentials and delete are all in this state. **Export selection to CSV is live**, because it needs no endpoint.

### `src/components/common/Checkbox.jsx` *(new)*
Native input (keyboard- and SR-correct) with a drawn box over it. Handles the indeterminate DOM property for header "some selected" state.

### `src/components/common/TableControls.jsx` *(new)*
`SearchField` · `SortHeader` (sticky, `aria-sort`) · `DensityToggle` · `ColumnChooser` (with `required` columns that can't be hidden) · `ExportMenu` · `RefreshControl` · `SavedViewsMenu` + `useSavedViews` · `ActiveFilters` chips.

`RefreshControl` shows *when* the data was fetched and re-renders every 30s so "2m ago" doesn't quietly become a lie — in a security console, "no active sessions" and "no active sessions as of nine minutes ago" are different statements.

### `src/components/common/Drawer.jsx` *(new)*
Row peek without losing your place in a filtered, paged, partially-selected table. Escape closes; footer carries "Open full page".

### `src/lib/exportRows.js` *(new)*
CSV + JSON of any filtered view, assembled from rows already on screen (there is no export endpoint, and only the browser knows the view you built).

Two things most CSV exporters get wrong, handled here:
- **Formula-injection guard** — values starting `=`, `+`, `-`, `@` are prefixed with `'`. This app exports attacker-influenced strings (usernames, resource names, audit detail); without this, `=CMD()` executes when the file opens in Excel.
- **UTF-8 BOM** so Excel renders accented and CJK names instead of mojibake.

### Also delivered on the list pages
Saved views · ⌘K-free keyboard row nav (`j`/`k`, `x` to select, `Enter` to peek, `Esc` to clear — all ignored while typing in a field) · sticky header + frozen select/name columns · column chooser · density toggle · skeleton loading · distinct empty states · last-refreshed stamp.

**Empty states are split by cause:** "no resources registered" (→ register one) is a different situation from "no resources match these filters" (→ clear filters). Offering "register a resource" to someone whose filter is too narrow is a dead end.

---

## Task 3 — Resources list + detail + register form

### `src/pages/resources/ResourcesPage.jsx` *(rewritten)*
Same single `listResourceGroups()` call. The nested platform-group response is flattened once, with the group name carried along as a filterable/sortable field.

- **KPI row** (5 cells): total · JIT-gated · standing · with credential · inactive.
- **Card grid** (your pick) as the default view, **plus a table view** with sortable columns, column chooser and density toggle — the same rows, two readings.
- **Advanced filtering:** search across name/host/description/database/group/type, plus type, group, status, access model and credential-presence facets, with removable active-filter chips.
- **Grouping demoted to an option.** Platform grouping was the old page's mandatory structure; it's now a "Group by platform" toggle. Grouping helps when browsing and gets in the way when you're hunting one host among four hundred.
- **Card design:** type glyph, name, `host:port` in mono, status badges (Active/Inactive · JIT-gated/Standing · Recorded), type + group facts, and a footer with credential state and **inline Quick connect**. The selection checkbox appears on hover/focus or once a selection is in progress — a permanently visible checkbox on every card turns a catalogue into a form.
- Quick connect routes to the detail page's connect panel (`#connect`), so JIT gating and credential checks run through exactly one code path.

### `src/pages/resources/ResourceDetailPage.jsx` *(rewritten)* + `ResourceDetailTabs.jsx` *(new)*
Restructured from two side-by-side cards into the object-with-tabs shape every mature PAM console uses:

**Overview · Connect · Credentials · Sessions · Policies · Audit**

- Identity header with type glyph, status badges and a **click-to-copy resource ID**.
- **Summary rail** — type, endpoint, elevation, recording — so you never open a tab to learn whether a resource is gated, recorded or live.
- `#connect` deep-links straight to the Connect tab, so arriving from a card's Quick connect lands where you asked.
- **Credentials tab** keeps the exact payload remap the backend requires (`username` → `account_name`, `secret` → `credential`) and the same store/rotate mutations. Adds a handling panel stating that secrets never reach the browser.
- **Sessions tab** is labelled "your sessions" — `/sessions/mine` is self-service-scoped and takes no resource parameter, so filtering is local and the heading says so rather than implying org-wide visibility.
- **Audit tab** calls `auditByResource` once with `retry: false`. The wildcard route's shape isn't documented for resource records, so on failure it shows a plain notice and points at the Audit page — never an empty list, which would read as "nothing ever happened here".
- **Policies tab** explains the three rules actually stored on the record (JIT, recording, active), and links to Admin → Policies for role/policy grants it doesn't own.

### `src/components/resources/CreateResourceModal.jsx`
Same eleven fields, same zod schema, same single POST — staged into the three decisions an operator makes, with a review step before the write:

**Identity → Connection → Access → Review**

- Per-step validation via `trigger()`, so a bad host can't be carried to the end.
- Default ports per resource type (5432, 27017, 6379…); typing over the suggestion always wins.
- Access step renders the two policy flags as **decision cards with consequences**, tinted when armed — not two unlabelled checkboxes at the bottom of a form.
- Review step shows the full record plus a note that registration is audit-chained and that the resource brokers sessions only once a credential is attached.

Registering a privileged system is consequential; a flat stack of eleven inputs invites tabbing through without reading.

---

## Login page

**`src/pages/auth/LoginPage.jsx`** — rebuilt to your platform login (`nav.cf.adapid.link`).

- Deep navy field (`#0A1729`) with two soft radial washes and a masked grid texture — depth without a gradient sweep.
- Outlined **ENTERPRISE SECURITY PLATFORM** pill with a cyan dot.
- Heavy tight headline, final word in brand cyan (`#29A8E0`); trust row with emerald check glyphs.
- Floating white credential card (24px radius, deep soft shadow), icon-prefixed field labels, 52px rounded inputs, password eye toggle, right-aligned forgot link, full-width cyan→blue gradient **Sign in securely →** button.

**Deliberately theme-independent.** Your sign-in is a fixed brand surface, not a themed console screen, so it uses literal brand values rather than the app's `surface-*`/`ink-*` tokens — it looks identical regardless of the viewer's light/dark preference.

**Auth logic untouched:** same schema, same `react-hook-form` wiring, same mutation, same `access_token` vs `challenge_token` branch (both arrive on HTTP 200 — `ErrMFARequired` is a success response in `auth_handler.go`), same redirect-to-`from`.

Two notes:
- **Copy is PAM-specific** ("Privileged Access Management", brokered sessions / JIT / tamper-evident audit) rather than the reference's CIRMP wording, since this is the PAM console. Say the word and I'll switch it to verbatim CIRMP copy.
- **Forgot password** has no route in this codebase — administrators issue resets through Identity Management. The link says that in a toast instead of navigating to a dead end. Same for tenant onboarding, which is why it isn't rendered.

---

## Decisions I made on your behalf

You left five answers blank. What I chose, and how to change it:

| Question | Choice | To change |
|---|---|---|
| KPI style | **Segmented strip** everywhere — it's your own Audit Logs pattern, so the redesign matches what you already ship | One component: `KpiStrip.jsx` |
| Trend data | **Omitted** — no history endpoint exists | Add a history endpoint and I'll wire trend slots |
| Pagination | **Client-side, server-shaped** | `serverMode: true` once endpoints take page params |
| Login copy | **PAM-specific**, reference visuals | Ask and I'll switch to verbatim |
| Resource detail | **Drawer for peek, full page for depth** | Both exist and share one status vocabulary |
| Bulk actions enabled | **Export CSV only**; the rest disabled with reasons | Remove `disabled` in `ResourcesPage.jsx`'s `bulkActions` once batch endpoints land |

## Not done

- **Command palette (⌘K)** — you picked it, but it wants a route/action registry spanning every page. It's a clean standalone addition; say the word and it's next.
- **Bulk actions on Identity, Sessions, JIT, Audit** — selection UI is wired on Identity; the action sets there are mostly destructive, so they wait on the same batch endpoints.
