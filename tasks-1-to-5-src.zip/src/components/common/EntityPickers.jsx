/**
 * EntityPickers — API-backed pickers for the two identifiers admins must never
 * type by hand: a principal (user) and a role.
 *
 * Enterprise people-pickers (Entra ID, Okta, GCP IAM) always resolve a human
 * name against the directory rather than asking for a UUID: typing a GUID is
 * slow, unverifiable and the most common source of failed assignments. These
 * wrap the type-ahead combobox around the existing list endpoints — no new
 * API surface, no backend change.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SUPPLYING A DIRECTORY THE PAGE ALREADY HAS
 * ═══════════════════════════════════════════════════════════════════════════
 * Each picker fetches its own copy of the list it offers. That is the right
 * default — a picker dropped into any dialog just works — but it is wasteful
 * wherever the host page has already loaded the same collection to render names
 * in a table: opening the dialog then issued a SECOND identical request, and
 * the user waited on a list the page was already holding.
 *
 * Both pickers now accept an optional `options` array (plus `loading` and
 * `error`) and, when it is supplied, skip their own request entirely. The
 * default is unchanged and every existing call site keeps working untouched —
 * this is purely additive.
 *
 * Option shape: { id, label, description?, badge? }.
 */
import { useMemo } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { loadDirectory, toUserOptions } from '../../lib/directory.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { SearchableCombobox } from '../ui/primitives.jsx';

/** Principal picker. Falls back to a plain hint when the tenant has no users. */
export function UserPicker({
  value,
  onChange,
  label = 'User',
  placeholder = 'Search users by name or email…',
  hint,
  error,
  required,
  multi = false,
  disabled = false,
  className,
  /** Supply these to reuse a directory the host page has already loaded. */
  options: providedOptions,
  loading: providedLoading,
  directoryError: providedError,
}) {
  const { accountId } = useAuth();
  const usesProvided = Array.isArray(providedOptions);

  /* The hook must still run unconditionally, so when the caller supplies the
     directory the fetcher resolves immediately instead of hitting the API. */
  const users = useResource(
    () => {
      if (usesProvided) return Promise.resolve(null);
      /* BUG FIX — this used to call listUsers({ account_id, per_page: 200 })
         with no `page` and a page size the identity route does not accept, so
         the picker came back empty and offered nothing. lib/directory.js holds
         the paged contract the Users page has always used. */
      return accountId ? loadDirectory(accountId) : Promise.resolve({ users: [] });
    },
    [accountId, usesProvided]
  );

  const fetchedOptions = useMemo(() => toUserOptions(users.data?.users || []), [users.data]);

  const options = usesProvided ? providedOptions : fetchedOptions;
  const isLoading = usesProvided ? !!providedLoading : users.loading;
  const loadError = usesProvided
    ? providedError
    : users.error
      ? 'Could not load the user directory.'
      : undefined;

  return (
    <SearchableCombobox
      className={className}
      label={label}
      placeholder={placeholder}
      searchPlaceholder={placeholder}
      options={options}
      value={value}
      onChange={onChange}
      loading={isLoading}
      multi={multi}
      disabled={disabled}
      required={required}
      error={error || loadError}
      hint={hint}
      emptyMessage="No users match that name or email."
    />
  );
}

/** Role picker — used for parent-role inheritance and role assignment. */
export function RolePicker({
  value,
  onChange,
  label = 'Role',
  placeholder = 'Search roles…',
  hint,
  error,
  required,
  multi = false,
  disabled = false,
  excludeId,
  className,
  /** Supply these to reuse a role list the host page has already loaded. */
  options: providedOptions,
  loading: providedLoading,
  directoryError: providedError,
}) {
  const usesProvided = Array.isArray(providedOptions);

  const roles = useResource(
    () => (usesProvided ? Promise.resolve(null) : rbacApi.listRoles()),
    [usesProvided]
  );

  const fetchedOptions = useMemo(() => {
    const list = roles.data?.roles || roles.data || [];
    return (Array.isArray(list) ? list : [])
      .filter((r) => r.role_id !== excludeId)
      .map((r) => ({
        id: r.role_id,
        label: r.role_name,
        description: r.description || undefined,
        badge: r.role_type === 'SYSTEM' ? 'SYSTEM' : undefined,
      }));
  }, [roles.data, excludeId]);

  const options = usesProvided
    ? providedOptions.filter((o) => o.id !== excludeId)
    : fetchedOptions;
  const isLoading = usesProvided ? !!providedLoading : roles.loading;
  const loadError = usesProvided
    ? providedError
    : roles.error
      ? 'Could not load roles.'
      : undefined;

  return (
    <SearchableCombobox
      className={className}
      label={label}
      placeholder={placeholder}
      searchPlaceholder={placeholder}
      options={options}
      value={value}
      onChange={onChange}
      loading={isLoading}
      multi={multi}
      disabled={disabled}
      required={required}
      error={error || loadError}
      hint={hint}
      emptyMessage="No roles match that name."
    />
  );
}
