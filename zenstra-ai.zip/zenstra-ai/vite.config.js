import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: { outDir: 'dist', assetsInlineLimit: 0, sourcemap: false },
  server: { host: '127.0.0.1', port: 5173 },
});
