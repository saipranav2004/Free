import { useRef } from 'react';
import A from '../components/A.jsx';
import Icon from '../components/Icon.jsx';
import Core from '../components/Core.jsx';
import { AgentMapScene, OwnerTreeScene } from '../components/Scenes.jsx';
import { Arrow, NextSteps } from '../components/Sections.jsx';
import { usePageFx, useCore } from '../lib/usePage.js';
import { capabilityPath, useCasePath } from '../content/site.js';

/* Why Zenstra: the case for the category and for Zenstra, told with the product.
   The exposure (the agent map), the answer (an owner and a scope), what changes,
   the core taken apart, what sets Zenstra apart and the platform in four parts. */
const EXPOSURE = [
  { icon: 'user', h: 'Created by anyone', p: 'No-code flows, copilots and coding agents are built by business teams and developers, not provisioned by IT.' },
  { icon: 'key', h: 'Holding real credentials', p: 'Tokens, API keys, OAuth apps, service accounts and MCP connections, many with standing, broad access.' },
  { icon: 'bolt', h: 'Acting without a person', p: 'They decide and act in seconds, inside the systems that move money and member data.' },
];

/* Public incidents involving agents and the access they hold, each with a source.
   The control named is the Zenstra control that applies to that kind of action; it
   is not a claim about what would have happened. */
const INCIDENTS = [
  { d: 'Jun 2025', h: 'Microsoft 365 Copilot · EchoLeak', p: 'Hidden instructions in an email could lead Copilot to disclose internal data with no action from the user. Microsoft fixed it (CVE-2025-32711) and reported no exploitation.', c: ['Intent check on outbound actions', useCasePath('prompt-injection')], src: ['NVD · CVE-2025-32711', 'https://nvd.nist.gov/vuln/detail/CVE-2025-32711'] },
  { d: 'Jul 2025', h: 'A coding agent deletes a production database', p: 'During a code freeze, Replit’s agent ran destructive commands against the production database of a SaaStr founder’s project, despite instructions not to change anything.', c: ['Hold production changes for a person', capabilityPath('runtime-enforcement')], src: ['eWeek', 'https://www.eweek.com/news/replit-ai-coding-assistant-failure/'] },
  { d: 'Jul 2025', h: 'Amazon Q extension ships an injected prompt', p: 'Version 1.84.0 of the VS Code extension contained a prompt telling the agent to wipe systems and cloud resources. A syntax error stopped it from running.', c: ['Contain one agent on one device', useCasePath('coding-agents')], src: ['AWS security bulletin AWS-2025-015', 'https://aws.amazon.com/security/security-bulletins/AWS-2025-015/'] },
  { d: 'Aug 2025', h: 'Salesloft Drift OAuth tokens', p: 'Tokens held by an AI chat integration were used to export Salesforce data from customer instances between 8 and 18 August, and to search it for further credentials.', c: ['Scoped, expiring grants per agent', capabilityPath('agent-identity')], src: ['Arctic Wolf, citing Google Threat Intelligence', 'https://arcticwolf.com/resources/blog/widespread-salesforce-data-theft-via-compromised-salesloft-drift-oauth-tokens/'] },
  { d: 'Sep 2025', h: 'The first malicious MCP server', p: 'An npm package posing as a Postmark MCP server added one line in version 1.0.16 that copied every email an agent sent to the attacker.', c: ['Changed tool servers held for review', useCasePath('tool-poisoning')], src: ['Koi Security', 'https://koi.ai/blog/postmark-mcp-npm-malicious-backdoor-email-theft'] },
];

const BEFORE = [
  'Agents found after an incident, one platform at a time',
  'Standing keys and service accounts with broad scope',
  'Logs that show what happened, after it happened',
  'A separate switch in every vendor to stop one agent',
  'Evidence pulled together by hand for every exam',
];
const AFTER = [
  'One inventory of every agent, each with a named owner',
  'Grants scoped to the task that expire on their own',
  'Every action decided inline, before it runs',
  'One revocation stops an agent everywhere, in seconds',
  'A tamper-evident record, exported as evidence',
];

const APART = [
  { icon: 'gate', h: 'Inline, not after the fact', p: 'Zenstra sits in the path of the action. Allow, hold or block is decided before the tool runs, not flagged in a log afterwards.' },
  { icon: 'search', h: 'Intent, not only identity', p: 'Each action is checked against the task the agent was given, so a hijacked agent holding valid credentials is still stopped.' },
  { icon: 'cloud', h: 'Inside your environment', p: 'The gateway runs in your VPC. Prompts and payloads never leave your cloud, and nothing in your agents is rewritten.' },
  { icon: 'ledger', h: 'Evidence an examiner accepts', p: 'Every decision is chained to the one before it, with the policy version that made it, and exports as a report.' },
];

const PARTS = [
  { slug: 'agent-discovery', icon: 'radar', k: 'Discover', h: 'Every agent, with an owner', p: 'Agents, MCP servers and credentials across your platforms, in one inventory.' },
  { slug: 'runtime-enforcement', icon: 'gate', k: 'Decide', h: 'Every action, before it runs', p: 'Allow, hold for a person, or block, against identity, task and policy.' },
  { slug: 'detection-response', icon: 'pulse', k: 'Detect', h: 'Every anomaly, contained', p: 'Baselines per agent, and one agent stopped on one device in seconds.' },
  { slug: 'decision-record', icon: 'ledger', k: 'Prove', h: 'Every decision, on the record', p: 'A hash-chained record your auditors and examiners can verify.' },
];

export default function WhyZenstra() {
  const ref = useRef(null);
  usePageFx(ref);
  useCore(ref);
  return (
    <main id="main" data-page="why" ref={ref}>
      <section className="why-hero" aria-labelledby="hero-h">
        <div className="wrap">
          <div className="why-panel">
            <span className="eyebrow" data-after="">Why Zenstra</span>
            <h1 className="display" id="hero-h" data-scan="">
              <span className="scanline"><span className="in">Your agents act on their own.</span><i className="bar"></i></span>
              <span className="scanline"><span className="in grad">Someone has to decide first.</span><i className="bar"></i></span>
            </h1>
            <p className="lede" data-after="">AI agents now read your documents, hold your credentials and act in your core systems. Zenstra decides every action before it runs, and keeps the record that proves it.</p>
            <div className="ctas" data-after="">
              <a href="#exposure" className="btn white lg">Why it matters <Arrow /></a>
              <A to="/platform" className="btn glass lg">Platform overview</A>
            </div>
          </div>
        </div>
      </section>

      <section className="sec" id="exposure" aria-labelledby="exp-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">The challenge</span>
            <h2 className="h2" id="exp-h" data-reveal="">Every AI agent is a new identity with real access.</h2>
            <p className="lede" data-reveal="">Agents run in workflows, in your cloud and on laptops, connected to your systems by credentials most identity and data tools never see.</p>
          </div>
          <div className="why-stage" data-reveal=""><AgentMapScene /></div>
          <div className="why-facts">
            {EXPOSURE.map((f, i) => (
              <div className="why-fact" key={f.h} data-reveal="" data-delay={i * 90}>
                <span className="why-ic"><Icon name={f.icon} /></span>
                <h3>{f.h}</h3>
                <p>{f.p}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sec band" aria-labelledby="inc-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">Already happening</span>
            <h2 className="h2" id="inc-h" data-reveal="">Agents act on real access, and attackers have noticed.</h2>
            <p className="lede" data-reveal="">Five public incidents from 2025, each with its source, and the Zenstra control that applies to that kind of action.</p>
          </div>
          <ol className="inc">
            {INCIDENTS.map((x, i) => (
              <li key={x.h} data-reveal="" data-delay={i * 60}>
                <time>{x.d}</time>
                <div className="inc-b">
                  <h3>{x.h}</h3>
                  <p>{x.p}</p>
                  <div className="inc-f">
                    <A to={x.c[1]} className="inc-c"><Icon name="shield" />{x.c[0]}</A>
                    <a className="inc-s" href={x.src[1]} target="_blank" rel="noopener">Source: {x.src[0]}</a>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="sec alt" aria-labelledby="own-h">
        <div className="wrap why-split">
          <div className="why-copy">
            <span className="overline" data-reveal="">Controlled access</span>
            <h2 className="h2" id="own-h" data-reveal="">Agent security starts with an owner and a scope.</h2>
            <p className="lede" data-reveal="">Zenstra ties every agent to the person it acts for, maps every credential it holds, and narrows each grant to the task in front of it.</p>
            <ul className="why-checks" data-reveal="">
              <li><Icon name="check" />Every agent has a named owner who answers for it.</li>
              <li><Icon name="check" />Every credential is mapped to the systems it reaches.</li>
              <li><Icon name="check" />Every grant is scoped to the task and expires on its own.</li>
            </ul>
            <A to={capabilityPath('agent-identity')} className="link" data-reveal="">Agent identity and access <Arrow /></A>
          </div>
          <div className="why-media" data-reveal="" data-delay="120"><OwnerTreeScene /></div>
        </div>
      </section>

      <section className="sec" aria-labelledby="ba-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">Challenge and solution</span>
            <h2 className="h2" id="ba-h" data-reveal="">What changes with Zenstra.</h2>
          </div>
          <div className="ba">
            <div className="ba-card before" data-reveal="">
              <h3>Without Zenstra</h3>
              <ul>{BEFORE.map((t) => <li key={t}><span className="ba-x" aria-hidden="true">✕</span>{t}</li>)}</ul>
            </div>
            <div className="ba-card after" data-reveal="" data-delay="100">
              <h3>With Zenstra</h3>
              <ul>{AFTER.map((t) => <li key={t}><span className="ba-y" aria-hidden="true">✓</span>{t}</li>)}</ul>
            </div>
          </div>
        </div>
      </section>

      <Core />

      <section className="sec" aria-labelledby="apart-h">
        <div className="wrap apart">
          <div className="apart-head">
            <span className="overline" data-reveal="">What sets Zenstra apart</span>
            <h2 className="h2" id="apart-h" data-reveal="">Built to decide, not only to watch.</h2>
            <p className="lede" data-reveal="">Most tools see an agent after it acts. Zenstra is in the path of every action, with the context to tell a helpful agent from a hijacked one.</p>
          </div>
          <ul className="apart-list">
            {APART.map((a, i) => (
              <li key={a.h} data-reveal="" data-delay={i * 70}>
                <span className="apart-ic"><Icon name={a.icon} /></span>
                <div><h3>{a.h}</h3><p>{a.p}</p></div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="sec alt" aria-labelledby="parts-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">One platform</span>
            <h2 className="h2" id="parts-h" data-reveal="">Discover, decide, detect and prove, in one place.</h2>
          </div>
          <div className="parts">
            {PARTS.map((c, i) => (
              <A key={c.slug} to={capabilityPath(c.slug)} className="part" data-reveal="" data-delay={i * 80}>
                <span className="part-k"><Icon name={c.icon} />{c.k}</span>
                <h3>{c.h}</h3>
                <p>{c.p}</p>
                <span className="link">Learn more <Arrow /></span>
              </A>
            ))}
          </div>
        </div>
      </section>

      <NextSteps h="See Zenstra decide on your own agents." />
    </main>
  );
}
