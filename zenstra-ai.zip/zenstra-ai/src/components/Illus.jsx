/* Illustrative dashboards for the platform's capability cards. Not the real console:
   each shows one idea at a glance (after the simplified product images enterprise
   security sites use), a clean window with one or two big figures or a single chart,
   and one floating card that carries the point. The numbers follow the same
   fictional organisation as the scenes (Northbank FCU, 63 agents). */
import { Glyph, Logo } from './Scenes.jsx';

const Win = ({ t, children }) => <div className="il-win"><div className="il-h"><i /><i /><i /><b>{t}</b></div>{children}</div>;
const Pop = ({ tone = '', children }) => <div className={'il-pop ' + tone}>{children}</div>;
const Ok = () => <svg className="il-ok" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="8" /><path d="m4.6 8.3 2.2 2.2 4.6-4.8" /></svg>;

function Donut({ v }) {
  const r = 15.9, c = 2 * Math.PI * r;
  return (
    <svg className="il-donut" viewBox="0 0 40 40" aria-hidden="true">
      <circle cx="20" cy="20" r={r} className="t" />
      <circle cx="20" cy="20" r={r} className="v" strokeDasharray={`${(v / 100) * c} ${c}`} />
    </svg>
  );
}

const ART = {
  'agent-discovery': (
    <>
      <Win t="Agents">
        <div className="il-split">
          <div className="il-big"><b>63</b><span>agents found on 6 platforms</span></div>
          <div className="il-dn"><Donut v={81} /><span><b>81%</b>governed</span></div>
        </div>
      </Win>
      <Pop tone="warn"><b>12 need an owner</b><span className="il-icons"><Logo slug="n8n" size="1.2em" /><Logo slug="zapier" size="1.2em" /><Glyph g="laptop" size="1.2em" /></span></Pop>
    </>
  ),
  'agent-identity': (
    <>
      <Win t="Agent">
        <div className="il-agent"><span className="il-av"><Glyph g="agent" size="1.4em" /></span><span><b>loan-servicing</b><small>Owner · Ravi Shah</small></span></div>
        <span className="il-pill ok"><Ok />Identity verified</span>
      </Win>
      <Pop><span className="il-ring"><svg viewBox="0 0 36 36" aria-hidden="true"><circle cx="18" cy="18" r="15" className="t" /><circle cx="18" cy="18" r="15" className="v" /></svg></span><span><b>loan.write</b><small>one loan · expires in 15 min</small></span></Pop>
    </>
  ),
  'runtime-enforcement': (
    <>
      <Win t="Decisions today">
        <div className="il-three"><span><i className="a" /><b>1,284</b>Allowed</span><span><i className="h" /><b>6</b>Held</span><span><i className="b" /><b>23</b>Blocked</span></div>
        <div className="il-stack"><i className="a" style={{ flex: 1284 }} /><i className="h" style={{ flex: 60 }} /><i className="b" style={{ flex: 120 }} /></div>
      </Win>
      <Pop tone="warn"><span><b>Held for approval</b><small>payments.transfer · $18,400</small></span><span className="il-btn">Approve</span></Pop>
    </>
  ),
  'mcp-security': (
    <>
      <Win t="MCP servers">
        <ul className="il-list">
          <li><Glyph g="bank" size="1.15em" />core-banking<span className="il-pill ok">Approved</span></li>
          <li><Glyph g="doc" size="1.15em" />crm-tools<span className="il-pill ok">Approved</span></li>
          <li><Glyph g="doc" size="1.15em" />kb-sync v2.4<span className="il-pill warn">Held</span></li>
        </ul>
      </Win>
      <Pop tone="bad"><span><b>accounts.transfer</b><small>not in this agent’s grant</small></span><span className="il-pill bad">Blocked</span></Pop>
    </>
  ),
  'detection-response': (
    <>
      <Win t="Detections this week">
        <div className="il-bars">
          {[['Critical', 1, 'b'], ['High', 3, 'b'], ['Medium', 7, 'h'], ['Low', 12, 'n']].map(([l, v, c]) => (
            <span key={l}><i className={c} style={{ height: (v / 12) * 100 + '%' }} /><b>{v}</b><small>{l}</small></span>
          ))}
        </div>
      </Win>
      <Pop tone="ok"><Ok /><span><b>Session contained</b><small>laptop-114 · device stays online</small></span></Pop>
    </>
  ),
  'decision-record': (
    <>
      <Win t="Decision record">
        <ul className="il-list rec">
          <li><span className="mono">#48231</span><span className="il-pill warn">Hold</span><Ok /></li>
          <li><span className="mono">#48232</span><span className="il-pill ok">Allow</span><Ok /></li>
          <li><span className="mono">#48233</span><span className="il-pill bad">Block</span><Ok /></li>
        </ul>
      </Win>
      <Pop tone="ok"><Ok /><span><b>Chain verified</b><small>export as PDF or CSV</small></span></Pop>
    </>
  ),
};

export default function CapIllus({ slug }) {
  return <div className={'il il-' + slug} aria-hidden="true"><div className="il-in">{ART[slug]}</div></div>;
}
