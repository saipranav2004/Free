import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { toast } from 'sonner'
import {
  Boxes, KeyRound, ShieldAlert, ArrowRight, Users, ClipboardList, Lock, Activity,
  ChevronRight, ShieldCheck, Clock, TrendingUp, CheckCircle2, Radio,
  FileKey2, Vault, Plus, ScrollText, Timer,
} from 'lucide-react'
import clsx from 'clsx'
import { useAuthStore } from '../store/authStore'
// verifyAudit is no longer called from this page. Chain verification moved off
// the dashboard masthead and lives on Admin Center > Audit & Compliance, which
// already owns a full Chain tab for it. Left in the comment so nobody assumes
// the call disappeared from the product.
import { getStats, listJitRequests, listAudit, /* verifyAudit, */ approveJitRequest, denyJitRequest } from '../api/admin'
import { listMyGrants, listMyJitRequests } from '../api/jit'
import { listMySessions } from '../api/sessions'
import { searchAudit } from '../api/audit'
import { Card, CardHeader, CardTitle, CardFooter, EmptyState } from '../components/common/Layout'
import { QueryState } from '../components/common/QueryState'
import { Badge, MetaTag } from '../components/common/Badge'
import { Button } from '../components/common/Button'
import { Spinner } from '../components/common/Spinner'
import { SegmentedControl } from '../components/common/SegmentedControl'
import { RefreshControl } from '../components/common/TableControls'
import { ConfirmDialog } from '../components/common/ConfirmDialog'
import { Avatar } from '../components/common/UserMenu'
import { AreaChart, DonutChart, BarList } from '../components/charts/Charts'
import {
  bucketByTime, outcomeBreakdown, topActions, topActors, categoryBreakdown,
  attentionCounts, expiringGrants,
} from '../lib/dashboardMetrics'
import { eventActor, eventTarget, isFailure } from '../components/audit/auditFields'
import { formatDateTime, formatRelativeToNow } from '../lib/format'
import { apiErrorMessage } from '../lib/apiError'
import { JIT_STATUS_BADGE, JIT_STATUS_LABELS, AUDIT_OUTCOME_BADGE } from '../config/constants'

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------
// WHAT WAS STILL WRONG AFTER THE LAST PASS. The page had one masthead and two
// heading levels, which was an improvement, but it still read as a stack of
// widgets rather than an operated console. Four specific failures, and what
// each one is replaced with:
//
//   1. NOTHING SAID HOW FRESH ANY OF IT WAS. Not one timestamp, not one
//      refresh control, on a screen whose entire job is to report live state.
//      A security console that cannot answer "is this current?" is not
//      trustworthy, and every mature one — Datadog, Grafana, the AWS console,
//      Splunk — answers it in the top-right corner before anything else.
//      There is now a console bar with an "updated Ns ago" readout and one
//      refresh that refetches every query the view owns.
//
//   2. THE PAGE HAD NO VERDICT. Five figures with equal weight, and the
//      reader had to do the arithmetic themselves to work out whether
//      anything was wrong. Entra ID's overview, Okta's Tasks widget and
//      Security Hub's summary all lead with a single stated conclusion. The
//      masthead now carries one: a posture plate that says, in words, whether
//      anything needs a human — and escalates to red while break-glass is in
//      force, because that is the one state that is never routine.
//
//   3. THE POSTURE NUMBERS WERE ONE UNDIFFERENTIATED ROW. "Active sessions"
//      and "Pending approvals" are not the same kind of fact: one is the
//      system operating, the other is work assigned to the person reading.
//      They are now two labelled groups inside one instrument — OPERATING NOW
//      and NEEDS A DECISION — which is the grouped-tile pattern Entra and
//      Security Hub use, and it lets the eye skip straight to the half that
//      might contain a task.
//
//   4. ONE SAMPLE, TWO CONTROLS, IN TWO PLACES. The time range lived inside
//      the chart card's header while the sample size sat in the section rule
//      above it, so the two halves of a single question were separated by a
//      card border. Both are now in one toolbar that governs the whole
//      Activity zone, with the sample size stated underneath every chart it
//      feeds.
//
// WHAT DID NOT CHANGE, deliberately: every number still comes from a call this
// page already made, every chart is still computed client-side from audit rows
// (see lib/dashboardMetrics) because the backend has no analytics endpoint,
// and nothing extrapolates, forecasts or compares against a previous period.
// The redesign is hierarchy and instrumentation, not new claims about data.

const EVENT_LIMITS = [
  { key: '200', label: 'Last 200 events', value: 200, scope: 'the 200 most recent audit entries' },
  { key: '500', label: 'Last 500 events', value: 500, scope: 'the 500 most recent audit entries' },
  { key: '1000', label: 'Last 1,000 events', value: 1000, scope: 'the 1,000 most recent audit entries' },
  {
    key: 'all',
    label: 'Last 5,000 events',
    // 5,000 is the practical ceiling. Past this the charts are being computed
    // in the browser from a payload measured in megabytes, over a page walk
    // long enough that the user is waiting on it.
    value: 5000,
    scope: 'the 5,000 most recent audit entries, or every entry held if there are fewer',
  },
]

const DEFAULT_EVENT_LIMIT = '200'

function resolveLimit(key) {
  return EVENT_LIMITS.find((o) => o.key === key) || EVENT_LIMITS[0]
}

// ---------------------------------------------------------------------------
// Assembling the sample
// ---------------------------------------------------------------------------
// WHY THIS IS NOT ONE REQUEST, and why the control used to do nothing above
// 200. Both audit endpoints clamp how many rows a single call may return, and
// they clamp SILENTLY: an over-large ask comes back trimmed, with a 200 OK and
// nothing in the payload saying it was trimmed.
//
//   GET /admin/audit    page_size clamped to 200  (pagingFrom at the HTTP
//                       layer, and again in AuditService.List's normalisePaging)
//   GET /audit/search   limit     clamped to 500  (AuditQueryService.Search)
//
// So "Last 1,000" and "All available" were both being served exactly 200 rows
// on the admin dashboard and exactly 500 on the self-service one. Every chart
// was then recomputed from an identical row set, which is exactly the reported
// symptom: moving the control changed nothing in the activity cards.
//
// The fix is to page. Each helper below walks consecutive pages AT THE
// ENDPOINT'S OWN MAXIMUM and concatenates until it has the requested number of
// rows, the server runs out of history, or a hard request ceiling is hit.
// Requests are sequential and every one carries the query's abort signal, so
// changing the control mid-walk cancels the rest instead of leaving a fan of
// requests in flight.
//
// Rows are de-duplicated by id. The log is ordered newest-first, so an entry
// written between page 1 and page 2 shifts the whole window down and would
// otherwise be counted twice - which would quietly inflate every chart.

const ADMIN_PAGE_CAP = 200   // GET /admin/audit  - page_size ceiling
const SEARCH_PAGE_CAP = 500  // GET /audit/search - limit ceiling
const MAX_SAMPLE_REQUESTS = 30

function eventKey(e) {
  return e?.id ?? e?.sequence_number ?? `${e?.occurred_at || ''}|${e?.action || ''}|${e?.actor_user_id || ''}`
}

function appendUnique(rows, seen, batch) {
  for (const e of batch) {
    const key = eventKey(e)
    if (seen.has(key)) continue
    seen.add(key)
    rows.push(e)
  }
}

// Org-wide sample. Returns the same { events, pagination } shape one listAudit
// call returns, so every consumer of auditQuery.data stays unchanged.
async function fetchAuditSample(target, signal) {
  const rows = []
  const seen = new Set()
  let pagination = null
  for (let page = 1; page <= MAX_SAMPLE_REQUESTS; page += 1) {
    const data = await listAudit({ page, page_size: ADMIN_PAGE_CAP }, signal)
    const batch = data?.events || []
    pagination = data?.pagination || pagination
    appendUnique(rows, seen, batch)
    if (batch.length < ADMIN_PAGE_CAP) break // ran out of history
    if (rows.length >= target) break
    const totalPages = pagination?.total_pages
    if (totalPages && page >= totalPages) break
  }
  return { events: rows.slice(0, target), pagination }
}

// Personal trail. limit/offset rather than page/page_size, so the offset is
// tracked from rows RECEIVED (not rows kept) - otherwise a de-duplicated row
// would make the next request re-read a window it has already seen.
// Returns searchAudit's { items, total } shape.
async function fetchSelfAuditSample(target, signal) {
  const rows = []
  const seen = new Set()
  let offset = 0
  let total = null
  for (let i = 0; i < MAX_SAMPLE_REQUESTS; i += 1) {
    const want = Math.min(SEARCH_PAGE_CAP, target - rows.length)
    if (want <= 0) break
    const data = await searchAudit({ limit: want, offset }, signal)
    const batch = data?.items || []
    total = data?.total ?? total
    appendUnique(rows, seen, batch)
    offset += batch.length
    if (batch.length < want) break
    if (total != null && offset >= total) break
  }
  return { items: rows.slice(0, target), total: total ?? rows.length }
}

function pick(obj, ...keys) {
  if (!obj) return undefined
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null) return obj[k]
  }
  return undefined
}

// Mirrors AdminJitPage's own reader — the field name for "this is a
// break-glass request" is not consistent across the JIT payloads, so both
// screens have to accept all three spellings or they disagree about which
// requests are emergencies.
function isBreakglass(r) {
  return r?.type === 'BREAKGLASS' || r?.request_type === 'BREAKGLASS' || !!r?.is_breakglass
}

const RANGES = [
  { key: '24h', label: '24h', buckets: 24, span: 'hour' },
  { key: '7d', label: '7 days', buckets: 7, span: 'day' },
  { key: '30d', label: '30 days', buckets: 30, span: 'day' },
]

// The freshest of several queries is a lie about the stalest one, so the
// console bar reports the OLDEST fetch backing the view. Returns null while
// nothing has resolved, which RefreshControl renders as "Not refreshed yet".
function oldestUpdate(...timestamps) {
  const known = timestamps.filter((t) => typeof t === 'number' && t > 0)
  return known.length > 0 ? Math.min(...known) : null
}

// ---------------------------------------------------------------------------
// Console bar — scope on the left, freshness and refresh on the right
// ---------------------------------------------------------------------------
// The strip every operations console puts above its content: it says what you
// are looking at, how old it is, and gives you one control to make it current.
// Deliberately OUTSIDE the masthead plate and lighter than it, because it is
// chrome about the page rather than content on it.

function ConsoleBar({ scope, children }) {
  return (
    <div className="mb-4 flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-surface-800 pb-3">
      <span className="flex min-w-0 items-center gap-2">
        <span className="relative flex h-1.5 w-1.5 flex-none rounded-full bg-emerald-500" aria-hidden="true">
          <span className="dot-live absolute inset-0 rounded-full bg-emerald-500" />
        </span>
        <span className="truncate text-2xs font-semibold uppercase tracking-[0.13em] text-ink-500">{scope}</span>
      </span>
      <span className="ml-auto flex flex-wrap items-center gap-2">{children}</span>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Posture plate
// ---------------------------------------------------------------------------

const VERDICT_TONES = {
  emerald: {
    frame: 'border-emerald-600/25 bg-emerald-50/70 dark:bg-emerald-950/20',
    dot: 'bg-emerald-500',
    title: 'text-emerald-800 dark:text-emerald-300',
    body: 'text-emerald-700/85 dark:text-emerald-400/80',
    icon: CheckCircle2,
  },
  amber: {
    frame: 'border-amber-500/30 bg-amber-50/80 dark:bg-amber-950/25',
    dot: 'bg-amber-500',
    title: 'text-amber-800 dark:text-amber-200',
    body: 'text-amber-700/90 dark:text-amber-300/80',
    icon: Clock,
  },
  red: {
    frame: 'border-red-500/35 bg-red-50/80 dark:bg-red-950/25',
    dot: 'bg-red-500',
    title: 'text-red-800 dark:text-red-200',
    body: 'text-red-700/90 dark:text-red-300/85',
    icon: ShieldAlert,
  },
}

// The page's single stated conclusion. One sentence, and the colour is the
// same signal the KPI cells use, so the plate and the numbers agree.
function PostureVerdict({ tone = 'emerald', headline, detail, to, loading }) {
  const t = VERDICT_TONES[tone] || VERDICT_TONES.emerald
  const Icon = t.icon

  if (loading) {
    return <span className="skeleton block h-[4.5rem] w-full rounded-xl lg:w-[21rem]" aria-hidden="true" />
  }

  const body = (
    <>
      <span className="mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-lg bg-white/70 ring-1 ring-inset ring-black/[0.06] dark:bg-white/[0.06] dark:ring-white/10">
        <Icon className={clsx('h-4 w-4', t.title)} strokeWidth={1.9} />
      </span>
      <span className="min-w-0">
        <span className={clsx('block text-sm font-semibold leading-snug', t.title)}>{headline}</span>
        <span className={clsx('mt-1 block text-xs leading-relaxed', t.body)}>{detail}</span>
      </span>
      {to && (
        <ArrowRight
          className={clsx('mt-1 h-3.5 w-3.5 flex-none transition-transform duration-200 group-hover:translate-x-0.5', t.title)}
          strokeWidth={2}
        />
      )}
    </>
  )

  const frame = clsx(
    'flex items-start gap-3 rounded-xl border px-3.5 py-3 lg:w-[21rem]',
    t.frame,
    to && 'group transition-colors duration-150'
  )

  return to ? <Link to={to} className={frame}>{body}</Link> : <div className={frame}>{body}</div>
}

const METRIC_TONES = {
  default: { icon: 'text-ink-500', value: 'text-ink-50', rail: null, dot: 'bg-blue-500' },
  emerald: { icon: 'text-emerald-600 dark:text-emerald-400', value: 'text-ink-50', rail: 'bg-emerald-500/60', dot: 'bg-emerald-500' },
  amber: { icon: 'text-amber-600 dark:text-amber-400', value: 'text-amber-700 dark:text-amber-300', rail: 'bg-amber-500', dot: 'bg-amber-500' },
  red: { icon: 'text-red-600 dark:text-red-400', value: 'text-red-700 dark:text-red-300', rail: 'bg-red-500', dot: 'bg-red-500' },
}

// A posture figure. Local to this page rather than KpiCell from
// components/common/KpiStrip: this one carries a severity rail and a hover
// affordance that only make sense on a landing page, and the shared cell is
// used by four list screens that must not inherit them.
//
// STRICTLY PRESENTATIONAL, same contract as the shared one: `value` renders
// exactly what it is handed, and there is no trend arrow, delta or sparkline
// anywhere in it, because the API returns point-in-time counts with no
// history. A security console must never draw a number the backend did not
// return.
function MetricCell({ label, value, icon: Icon, description, tone = 'default', loading = false, live = false, to }) {
  const t = METRIC_TONES[tone] || METRIC_TONES.default

  const body = (
    <>
      {t.rail && <span aria-hidden="true" className={clsx('absolute inset-y-2 left-0 w-[2px] rounded-r-full', t.rail)} />}

      <span className="flex items-center gap-2">
        {Icon && <Icon className={clsx('h-[0.9rem] w-[0.9rem] flex-none', t.icon)} strokeWidth={1.75} />}
        <span className="truncate text-2xs font-semibold uppercase tracking-[0.1em] text-ink-400">{label}</span>
        {live && (
          <span className={clsx('relative ml-auto flex h-1.5 w-1.5 flex-none rounded-full', t.dot)} aria-hidden="true">
            <span className={clsx('dot-live absolute inset-0 rounded-full', t.dot)} />
          </span>
        )}
      </span>

      <span className="mt-3 flex items-end gap-2">
        {loading ? (
          <span className="skeleton block h-7 w-14 rounded" aria-hidden="true" />
        ) : (
          <span className={clsx('block text-[1.75rem] font-semibold leading-none tracking-tight tabular-nums', t.value)}>
            {value}
          </span>
        )}
        {to && (
          <ChevronRight
            className="mb-0.5 h-3.5 w-3.5 flex-none text-ink-600 opacity-0 transition-all duration-150 group-hover:translate-x-0.5 group-hover:opacity-100"
            strokeWidth={2}
            aria-hidden="true"
          />
        )}
      </span>

      {description && <span className="mt-2 block truncate text-xs leading-relaxed text-ink-500">{description}</span>}
    </>
  )

  const cell = clsx(
    'relative block min-w-0 border-t border-surface-800 px-4 py-3.5 first:border-t-0',
    'sm:border-t-0 sm:border-l sm:first:border-l-0',
    to && 'group cursor-pointer transition-colors duration-150 hover:bg-surface-850'
  )

  return to ? <Link to={to} className={cell}>{body}</Link> : <div className={cell}>{body}</div>
}

// A named group of posture figures. The label is what turns six numbers into
// two answers: "what is the system doing" and "what is waiting on me".
function MetricGroup({ label, note, cells, columns = 3, loading, className }) {
  const cols = { 2: 'sm:grid-cols-2', 3: 'sm:grid-cols-3', 4: 'sm:grid-cols-4' }[columns] || 'sm:grid-cols-3'
  return (
    <div className={clsx('min-w-0', className)}>
      <div className="flex items-center gap-2.5 px-4 pb-1 pt-3">
        <span className="flex-none text-2xs font-semibold uppercase tracking-[0.13em] text-ink-500">{label}</span>
        <span className="h-px flex-1 bg-surface-800" aria-hidden="true" />
        {note && <span className="flex-none text-2xs text-ink-600">{note}</span>}
      </div>
      <div className={clsx('grid grid-cols-1', cols)}>
        {/* `key` is destructured out rather than spread through: React warns
            (correctly) when a key arrives inside a spread object, because it
            is a directive to the reconciler, not a prop the component sees. */}
        {cells.map(({ key, ...cell }) => (
          <MetricCell key={key} {...cell} loading={loading || cell.loading} />
        ))}
      </div>
    </div>
  )
}

function PostureMasthead({ eyebrow, title, description, verdict, groups }) {
  return (
    <section className="edge-lit relative overflow-hidden rounded-2xl border border-surface-700/70 bg-surface-900">
      {/* A faint technical ground behind the heading — structure, not
          gradient, is what makes an enterprise surface read as a drawn object
          rather than a coloured rectangle. Two layers instead of a CSS mask so
          it degrades identically in every browser. */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-44 overflow-hidden">
        <div className="tex-grid h-full w-full opacity-[0.5]" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-surface-900" />
      </div>

      <div className="relative flex flex-col gap-5 px-5 py-5 lg:flex-row lg:items-start lg:justify-between lg:gap-8">
        <div className="min-w-0">
          <p className="text-2xs font-semibold uppercase tracking-[0.13em] text-ink-500">{eyebrow}</p>
          <h1 className="mt-1.5 truncate text-[1.6rem] font-semibold leading-tight tracking-[-0.022em] text-ink-50">
            {title}
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-400">{description}</p>
        </div>
        {verdict && <div className="flex-none">{verdict}</div>}
      </div>

      <div className="relative grid border-t border-surface-800 bg-surface-850/35 lg:grid-cols-2">{groups}</div>
    </section>
  )
}

// ---------------------------------------------------------------------------
// Section headings — three ranks, so the page has a spine
// ---------------------------------------------------------------------------

function SectionLink({ to, children }) {
  return (
    <Link
      to={to}
      className="group inline-flex flex-none items-center gap-1 whitespace-nowrap text-xs font-semibold text-blue-600 transition-colors hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
    >
      {children}
      <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" strokeWidth={2} />
    </Link>
  )
}

// Rank 1: used once per page, for the zone that carries decisions.
function PrimarySection({ title, description, count, action, children }) {
  return (
    <section className="mt-8">
      <div className="mb-3.5 flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5">
            <h2 className="text-[1.0625rem] font-semibold tracking-[-0.014em] text-ink-50">{title}</h2>
            {count > 0 && (
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-2xs font-bold tabular-nums text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
                {count}
              </span>
            )}
          </div>
          {description && <p className="mt-1 text-xs leading-relaxed text-ink-500">{description}</p>}
        </div>
        {action && <div className="flex flex-none items-center gap-3">{action}</div>}
      </div>
      {children}
    </section>
  )
}

// Rank 2: a labelled rule for zones you read rather than act on. The toolbar
// that governs the zone lives in the rule itself, never inside one of the
// cards it controls.
function QuietSection({ label, description, action, children }) {
  return (
    <section className="mt-9">
      <div className="mb-3.5 flex flex-wrap items-center gap-x-3 gap-y-2">
        <h2 className="flex-none text-2xs font-semibold uppercase tracking-[0.12em] text-ink-500">{label}</h2>
        {description && <span className="flex-none text-2xs text-ink-600">{description}</span>}
        <span className="h-px flex-1 bg-surface-800" aria-hidden="true" />
        {action && <div className="flex flex-none flex-wrap items-center gap-3">{action}</div>}
      </div>
      {children}
    </section>
  )
}

function AllClearStrip({ children }) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl border border-emerald-600/25 bg-emerald-50/70 px-4 py-3 dark:bg-emerald-950/15">
      <CheckCircle2 className="h-4 w-4 flex-none text-emerald-600 dark:text-emerald-400" strokeWidth={1.9} />
      <p className="text-sm font-medium text-emerald-800 dark:text-emerald-300">{children}</p>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Activity toolbar
// ---------------------------------------------------------------------------
// ONE control group for one sample. The time range and the sample size answer
// halves of the same question ("which events am I looking at"), so they sit
// together in the section rule rather than being split between a rule and a
// card header the way they were.

function ActivityToolbar({ range, onRangeChange, limitKey, onLimitChange, idSuffix, fetching }) {
  const id = `dashboard-event-sample-${idSuffix}`
  return (
    <>
      <SegmentedControl
        size="sm"
        ariaLabel="Time range"
        value={range}
        onChange={onRangeChange}
        options={RANGES.map((r) => ({ key: r.key, label: r.label }))}
      />
      <span className="flex flex-none items-center gap-2">
        <label htmlFor={id} className="text-2xs font-semibold uppercase tracking-[0.09em] text-ink-500">
          Sample
        </label>
        <select
          id={id}
          value={limitKey}
          onChange={(e) => onLimitChange(e.target.value)}
          className="h-7 cursor-pointer rounded-lg border border-surface-700 bg-surface-900 pl-2.5 pr-7 text-xs font-medium text-ink-100 shadow-sm transition-colors hover:border-surface-600 focus:border-blue-500 focus:outline-none"
        >
          {EVENT_LIMITS.map((o) => (
            <option key={o.key} value={o.key}>
              {o.label}
            </option>
          ))}
        </select>
        {fetching && <Spinner size="h-3 w-3" />}
      </span>
    </>
  )
}

// ---------------------------------------------------------------------------
// Waiting time
// ---------------------------------------------------------------------------
// An approval queue without an age column is a list, not a queue. The tone
// escalates on elapsed time so the row that has been sitting since this
// morning does not look identical to the one raised a minute ago. Thresholds
// are presentation only — this backend has no SLA field to read.

function waitingFor(since) {
  const t = since ? new Date(since).getTime() : NaN
  if (Number.isNaN(t)) return null
  const mins = Math.floor((Date.now() - t) / 60000)
  if (mins < 0) return null
  return {
    mins,
    label: mins < 60 ? `${mins}m` : `${Math.floor(mins / 60)}h ${mins % 60}m`,
    tone: mins >= 240 ? 'red' : mins >= 60 ? 'amber' : 'default',
  }
}

function WaitingChip({ since }) {
  const w = waitingFor(since)
  if (!w) return null
  return (
    <span
      title={`Raised ${formatDateTime(since)}`}
      className={clsx(
        'inline-flex flex-none items-center gap-1 rounded-md px-1.5 py-1 text-2xs font-semibold tabular-nums ring-1 ring-inset',
        w.tone === 'red'
          ? 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25'
          : w.tone === 'amber'
            ? 'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25'
            : 'bg-surface-800 text-ink-400 ring-surface-700'
      )}
    >
      <Timer className="h-3 w-3" strokeWidth={2} />
      {w.label}
    </span>
  )
}

// A severity rail down the left edge of a row. Three pixels of colour is what
// lets an operator scan a list vertically and stop at the one that matters,
// without a status column competing with the content.
function RowRail({ tone }) {
  return (
    <span
      aria-hidden="true"
      className={clsx(
        'absolute inset-y-0 left-0 w-[3px]',
        tone === 'red' ? 'bg-red-500/80' : tone === 'amber' ? 'bg-amber-500/80' : 'bg-surface-600'
      )}
    />
  )
}

// ---------------------------------------------------------------------------
// Analysis (shared by both dashboards)
// ---------------------------------------------------------------------------

function ActivityAnalysis({ events, loading, range, scopeNote, auditHref, extra }) {
  const preset = RANGES.find((r) => r.key === range) || RANGES[0]

  const series = useMemo(
    () => bucketByTime(events, { buckets: preset.buckets, span: preset.span }),
    [events, preset]
  )
  const outcomes = useMemo(() => outcomeBreakdown(events), [events])
  const actions = useMemo(() => topActions(events), [events])
  const categories = useMemo(() => categoryBreakdown(events), [events])
  const counts = useMemo(() => attentionCounts(events), [events])
  const plotted = series.reduce((n, s) => n + s.value, 0)
  const failureRate = counts.total > 0 ? (counts.failed / counts.total) * 100 : 0

  return (
    <>
      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <Card className="overflow-hidden">
          <CardHeader className="flex-wrap gap-y-2">
            <CardTitle icon={TrendingUp}>Activity volume</CardTitle>
            {/* The range control is NOT here any more — it governs this card,
                the donut and all three ranked lists, so it belongs to the
                section, not to one of the things it changes. */}
            <span className="ml-auto flex items-center gap-2">
              <MetaTag>{preset.label}</MetaTag>
              <MetaTag mono>{counts.total.toLocaleString()} sampled</MetaTag>
            </span>
          </CardHeader>
          <div className="px-4 pb-3 pt-4">
            {loading ? (
              <div className="skeleton h-[200px] rounded-lg" />
            ) : (
              <AreaChart points={series} valueLabel="Events" />
            )}
          </div>
          <CardFooter className="justify-between">
            <p className="text-2xs leading-relaxed text-ink-500">
              {plotted.toLocaleString()} of the {counts.total.toLocaleString()} events in this sample
              fall inside the selected window. {scopeNote}
            </p>
            <SectionLink to={auditHref}>Open audit</SectionLink>
          </CardFooter>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle icon={ShieldCheck}>Outcomes</CardTitle>
            {counts.total > 0 && (
              <span className="ml-auto">
                <MetaTag>
                  {failureRate < 0.1 && counts.failed > 0 ? '<0.1' : failureRate.toFixed(1)}% denied or failed
                </MetaTag>
              </span>
            )}
          </CardHeader>
          <div className="p-4">
            {loading ? (
              <div className="skeleton h-[148px] rounded-lg" />
            ) : counts.total === 0 ? (
              <p className="py-12 text-center text-xs text-ink-500">No events recorded yet</p>
            ) : (
              <DonutChart segments={outcomes} centerValue={counts.total.toLocaleString()} centerLabel="events" />
            )}
          </div>
          <CardFooter>
            <p className="text-2xs leading-relaxed text-ink-500">
              Across the {counts.total.toLocaleString()} events in this sample. A denial is not
              necessarily an incident: policy working is the common case.
            </p>
          </CardFooter>
        </Card>
      </div>

      <div className={clsx('mt-4 grid gap-4', extra ? 'lg:grid-cols-2 xl:grid-cols-3' : 'lg:grid-cols-2')}>
        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle icon={Activity}>Most frequent actions</CardTitle>
          </CardHeader>
          <BarList items={actions} mono emptyLabel="No actions recorded yet" />
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle icon={ClipboardList}>By category</CardTitle>
            <span className="ml-auto text-2xs text-ink-500">red = contains a denial</span>
          </CardHeader>
          <BarList items={categories} emptyLabel="No categories recorded yet" />
        </Card>

        {extra}
      </div>
    </>
  )
}

function DeniedList({ events, href }) {
  const denied = (events || []).filter(isFailure)
  const shown = denied.slice(0, 5)

  return (
    <Card className="overflow-hidden">
      <CardHeader>
        <CardTitle icon={ShieldAlert}>Denied &amp; failed</CardTitle>
        <span className="ml-auto flex items-center gap-3">
          <MetaTag>{denied.length.toLocaleString()} in sample</MetaTag>
          <SectionLink to={href}>View all</SectionLink>
        </span>
      </CardHeader>
      <ul className="divide-y divide-surface-800">
        {shown.map((e, i) => (
          <li key={e?.id ?? i} className="relative px-4 py-3 pl-5">
            <RowRail tone="red" />
            <div className="flex flex-wrap items-center gap-2">
              <MetaTag>{e?.category || 'OTHER'}</MetaTag>
              <span className="min-w-0 flex-1 truncate font-mono text-xs font-medium text-ink-100" title={e?.action || undefined}>
                {e?.action || 'unknown action'}
              </span>
              {e?.outcome && <Badge className={AUDIT_OUTCOME_BADGE[e.outcome]}>{e.outcome}</Badge>}
            </div>
            <p className="mt-1 truncate text-2xs text-ink-500">
              {eventActor(e) || 'unknown actor'}
              {eventTarget(e) ? ` · ${eventTarget(e)}` : ''} · {formatDateTime(e?.occurred_at || e?.created_at)}
            </p>
          </li>
        ))}
      </ul>
      {denied.length > shown.length && (
        <CardFooter>
          <p className="text-2xs text-ink-500">
            Showing the {shown.length} most recent of {denied.length.toLocaleString()} denied or failed
            entries in this sample.
          </p>
        </CardFooter>
      )}
    </Card>
  )
}

// ---------------------------------------------------------------------------
// Administration shortcuts
// ---------------------------------------------------------------------------
// A NAV TILE GRID WAS REMOVED FROM THIS PAGE IN AN EARLIER PASS, AND BRINGING
// ONE BACK NEEDS A REASON. The old one was four large cards linking to
// Identity, Roles, Policies and Audit sitting directly under a sidebar
// containing Identity, Roles, Policies and Audit: same destinations, same
// words, twice the height, no extra information. That is filler.
//
// This is a different object, and the difference is the whole justification.
// IT LEADS WITH THE ACTION, NOT THE PAGE. Each row's "+" goes straight to the
// create form (make a user, define a role, write a policy), which is the verb
// an administrator actually arrives wanting. The sidebar can only ever take
// you to a list. That is precisely the split AWS draws between its service nav
// and the console home's task shortcuts, and what Salesforce Setup's shortcut
// rail and Google Cloud's "Quick access" do.
//
// Deliberately NOT here: object counts. They would make the row read like an
// instrument, and GET /admin/stats returns only pending_approvals,
// active_sessions, active_grants, active_breakglass_grants and
// active_resources. There is no user, role, policy or safe total. Firing four
// more list requests on dashboard load to decorate a shortcut is exactly the
// kind of cost that is not worth a number nobody asked for.
//
// Rows of rows, not hero cards: this is bottom-of-page chrome and it is
// weighted like chrome.

function ShortcutRow({ to, icon: Icon, label, description, actionTo, actionLabel }) {
  return (
    // The 1px dividers come from the grid's own `gap-px` over a surface-800
    // ground (see AdminShortcuts), not from per-cell border rules keyed on
    // nth-child. Six cells reflowing across three breakpoints would otherwise
    // need a different "is this the first in its row" rule per breakpoint, and
    // those rules disagree at exactly the sizes nobody tests.
    <div className="group flex items-center gap-3 bg-surface-900 px-4 py-3 transition-colors hover:bg-surface-850">
      <Link to={to} className="flex min-w-0 flex-1 items-center gap-3 outline-none">
        <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg border border-surface-700 bg-surface-850 text-ink-400 transition-colors group-hover:border-surface-600 group-hover:text-ink-200">
          <Icon className="h-4 w-4" strokeWidth={1.7} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-medium text-ink-100">{label}</span>
          <span className="mt-0.5 block truncate text-2xs text-ink-500">{description}</span>
        </span>
      </Link>
      {actionTo && (
        <Link
          to={actionTo}
          title={actionLabel}
          aria-label={actionLabel}
          className="flex h-7 w-7 flex-none items-center justify-center rounded-md border border-surface-700 bg-surface-900 text-ink-500 opacity-0 transition-all duration-150 hover:border-blue-500/50 hover:text-blue-600 focus-visible:opacity-100 group-hover:opacity-100 dark:hover:text-blue-300"
        >
          <Plus className="h-3.5 w-3.5" strokeWidth={2.2} />
        </Link>
      )}
    </div>
  )
}

const ADMIN_SHORTCUTS = [
  {
    to: '/admin/identity',
    icon: Users,
    label: 'Identity',
    description: 'Accounts, status and effective access',
    actionTo: '/admin/identity?new=1',
    actionLabel: 'Create a user',
  },
  {
    to: '/admin/roles',
    icon: ShieldCheck,
    label: 'Roles',
    description: 'Bundles of policy, assigned to people',
    actionTo: '/admin/roles?new=1',
    actionLabel: 'Create a role',
  },
  {
    to: '/admin/policies',
    icon: FileKey2,
    label: 'Policies',
    description: 'The allow and deny rules themselves',
    actionTo: '/admin/policies?new=1',
    actionLabel: 'Write a policy',
  },
  {
    to: '/admin/jit',
    icon: KeyRound,
    label: 'JIT Approvals',
    description: 'Decide requests, revoke standing grants',
  },
  {
    to: '/admin/audit',
    icon: ScrollText,
    label: 'Audit & Compliance',
    description: 'The full trail, reports and chain integrity',
  },
  {
    to: '/admin/vault-ops',
    icon: Vault,
    label: 'Vault Operations',
    description: 'Rotation, backup and restore',
  },
]

function AdminShortcuts() {
  return (
    <div className="edge-lit grid gap-px overflow-hidden rounded-xl border border-surface-700/70 bg-surface-800 sm:grid-cols-2 xl:grid-cols-3">
      {ADMIN_SHORTCUTS.map((s) => (
        <ShortcutRow key={s.to} {...s} />
      ))}
    </div>
  )
}

// ---------------------------------------------------------------------------
// Admin
// ---------------------------------------------------------------------------

function AdminDashboard({ user }) {
  const queryClient = useQueryClient()
  const [range, setRange] = useState('24h')
  // Scoped to this view. The self-service dashboard below keeps its own,
  // because "how much of my own trail" and "how much of the org's trail" are
  // different questions with different costs.
  const [limitKey, setLimitKey] = useState(DEFAULT_EVENT_LIMIT)
  const sample = resolveLimit(limitKey)
  const [approveTarget, setApproveTarget] = useState(null)
  const [denyTarget, setDenyTarget] = useState(null)

  const statsQuery = useQuery({ queryKey: ['admin', 'stats'], queryFn: ({ signal }) => getStats(signal) })

  // One sample serves every chart AND the denied list. The chosen size is part
  // of the key, so switching it refetches instead of re-slicing stale rows,
  // and placeholderData keeps the previous charts on screen while it does.
  // fetchAuditSample, not a bare listAudit: the endpoint caps one call at 200
  // rows, so anything larger has to be walked a page at a time.
  const auditQuery = useQuery({
    queryKey: ['admin', 'audit', 'dashboard-sample', sample.value],
    queryFn: ({ signal }) => fetchAuditSample(sample.value, signal),
    placeholderData: (prev) => prev,
    retry: false,
  })

  const pendingQuery = useQuery({
    queryKey: ['admin', 'jit-requests', 'pending-list'],
    queryFn: ({ signal }) => listJitRequests({ page: 1, page_size: 5, status: 'PENDING' }, signal),
  })

  const invalidatePending = () => queryClient.invalidateQueries({ queryKey: ['admin', 'jit-requests'] })

  const approveMutation = useMutation({
    mutationFn: ({ id, reason }) => approveJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request approved')
      setApproveTarget(null)
      invalidatePending()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setApproveTarget(null)
    },
  })

  const denyMutation = useMutation({
    mutationFn: ({ id, reason }) => denyJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request denied')
      setDenyTarget(null)
      invalidatePending()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDenyTarget(null)
    },
  })

  const s = statsQuery.data
  const events = useMemo(() => auditQuery.data?.events || [], [auditQuery.data])
  const actors = useMemo(() => topActors(events), [events])
  const pending = pendingQuery.data?.requests || []
  const denied = useMemo(() => events.filter(isFailure), [events])
  const isMutatingJit = approveMutation.isPending || denyMutation.isPending

  const breakglassCount = pick(s, 'active_breakglass_grants') ?? 0
  const pendingCount = pick(s, 'pending_approvals') ?? pending.length

  const loadingAttention = pendingQuery.isLoading || auditQuery.isLoading
  const nothingWaiting = !loadingAttention && pending.length === 0 && denied.length === 0

  // ONE stated conclusion for the whole page, and it escalates in the order an
  // operator cares about: emergency access in force outranks a queue, which
  // outranks refusals worth a look.
  const verdict = useMemo(() => {
    if (breakglassCount > 0) {
      return {
        tone: 'red',
        headline: `Break-glass access is active (${breakglassCount})`,
        detail: 'Emergency elevation is in force right now. Review the grant and close it out as soon as the incident allows.',
        to: '/admin/jit',
      }
    }
    if (pending.length > 0) {
      return {
        tone: 'amber',
        headline: `${pending.length} approval${pending.length === 1 ? '' : 's'} waiting on you`,
        detail: 'Nobody else can act on these — a JIT request sits unusable until it is decided.',
        to: '/admin/jit',
      }
    }
    if (denied.length > 0) {
      return {
        tone: 'amber',
        headline: `${denied.length.toLocaleString()} denied or failed in the current sample`,
        detail: 'Usually policy working as intended. Worth a look when the same account keeps hitting the same refusal.',
        to: '/admin/audit',
      }
    }
    return {
      tone: 'emerald',
      headline: 'Nothing is waiting on you',
      detail: 'The approval queue is clear, no emergency access is in force, and nothing has been denied in the current sample.',
      to: null,
    }
  }, [breakglassCount, pending.length, denied.length])

  const refreshAll = () => {
    statsQuery.refetch()
    auditQuery.refetch()
    pendingQuery.refetch()
  }

  return (
    <div>
      <ConsoleBar scope="Control plane · organization-wide">
        <RefreshControl
          onRefresh={refreshAll}
          isFetching={statsQuery.isFetching || auditQuery.isFetching || pendingQuery.isFetching}
          updatedAt={oldestUpdate(statsQuery.dataUpdatedAt, auditQuery.dataUpdatedAt, pendingQuery.dataUpdatedAt)}
        />
      </ConsoleBar>

      <PostureMasthead
        eyebrow="Security posture"
        title={`Good to see you${user?.username ? `, ${user.username}` : ''}`}
        description="Everything below is org-wide. The plate states what the system is doing and what is waiting on a decision from you."
        verdict={<PostureVerdict {...verdict} loading={statsQuery.isLoading && pendingQuery.isLoading} />}
        groups={
          <>
            <MetricGroup
              label="Operating now"
              note="Point-in-time"
              loading={statsQuery.isLoading}
              cells={[
                {
                  key: 'sessions',
                  label: 'Active sessions',
                  icon: Activity,
                  tone: 'emerald',
                  live: true,
                  value: pick(s, 'active_sessions') ?? 'n/a',
                  description: 'Connections open right now',
                  to: '/sessions',
                },
                {
                  key: 'grants',
                  label: 'Active grants',
                  icon: Lock,
                  tone: 'emerald',
                  value: pick(s, 'active_grants') ?? 'n/a',
                  description: 'Elevation in force',
                  to: '/admin/jit',
                },
                {
                  key: 'resources',
                  label: 'Resources',
                  icon: Boxes,
                  value: pick(s, 'active_resources') ?? 'n/a',
                  description: 'Registered and reachable',
                  to: '/resources',
                },
              ]}
            />
            <MetricGroup
              className="border-t border-surface-800 lg:border-l lg:border-t-0"
              label="Needs a decision"
              note="Assigned to you"
              cells={[
                {
                  key: 'pending',
                  label: 'Pending approvals',
                  icon: KeyRound,
                  tone: pendingCount > 0 ? 'amber' : 'default',
                  loading: statsQuery.isLoading,
                  value: pick(s, 'pending_approvals') ?? 'n/a',
                  description: pendingCount > 0 ? 'Waiting on your call' : 'Queue is clear',
                  to: '/admin/jit',
                },
                {
                  key: 'breakglass',
                  label: 'Break-glass',
                  icon: ShieldAlert,
                  tone: breakglassCount > 0 ? 'red' : 'default',
                  loading: statsQuery.isLoading,
                  value: pick(s, 'active_breakglass_grants') ?? 'n/a',
                  description: breakglassCount > 0 ? 'Emergency access in force' : 'None in force',
                  to: '/admin/jit',
                },
                {
                  key: 'denied',
                  label: 'Denied & failed',
                  icon: ShieldAlert,
                  tone: denied.length > 0 ? 'amber' : 'default',
                  loading: auditQuery.isLoading,
                  value: denied.length.toLocaleString(),
                  // Said explicitly, because this is the one figure on the
                  // plate that is NOT a point-in-time server count — it is
                  // measured from the audit sample the Activity zone below is
                  // computed from, and it moves when that control moves.
                  description: `Of ${events.length.toLocaleString()} sampled events`,
                  to: '/admin/audit',
                },
              ]}
            />
          </>
        }
      />

      {/* Good news is small. Two large empty cards saying "nothing here" used
          to eat half the fold; the verdict plate above already states the
          all-clear, so this is one line confirming it. */}
      {nothingWaiting ? (
        <div className="mt-8">
          <AllClearStrip>
            Nothing is waiting on you. The approval queue is clear and no action has been denied
            recently.
          </AllClearStrip>
        </div>
      ) : (
        <PrimarySection
          title="Needs your attention"
          description="Decisions only you can make, and the refusals worth a second look."
          count={pending.length}
        >
          <div className={clsx('grid gap-4', pending.length > 0 && denied.length > 0 && 'lg:grid-cols-2')}>
            {pending.length > 0 && (
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle icon={KeyRound}>Approval queue</CardTitle>
                  <span className="ml-auto">
                    <SectionLink to="/admin/jit">View all</SectionLink>
                  </span>
                </CardHeader>
                <QueryState
                  query={pendingQuery}
                  empty={(d) => !d?.requests || d.requests.length === 0}
                  emptyTitle="Queue clear"
                  emptyMessage="No JIT or break-glass requests are waiting on a decision."
                  skeletonRows={3}
                >
                  {() => (
                    <ul className="divide-y divide-surface-800">
                      {pending.map((r) => {
                        const emergency = isBreakglass(r)
                        const wait = waitingFor(r?.created_at)
                        const requester =
                          r?.requester_username || r?.username || r?.requested_by || r?.user_id || 'unknown requester'
                        return (
                          <li
                            key={r.id}
                            className="relative flex flex-col gap-3 py-3 pl-5 pr-4 sm:flex-row sm:items-center sm:justify-between"
                          >
                            {/* Emergency requests are always red; ordinary ones
                                take the colour of how long they have waited. */}
                            <RowRail tone={emergency ? 'red' : wait?.tone} />
                            <div className="flex min-w-0 items-center gap-3">
                              <Avatar name={requester} size="sm" />
                              <div className="min-w-0">
                                <p className="flex items-center gap-2 truncate text-sm font-medium text-ink-100">
                                  <span className="truncate">
                                    {r?.resource_name || r?.resource_id || 'Unnamed resource'}
                                  </span>
                                  {emergency && (
                                    <Badge className="bg-red-100 text-red-700 ring-red-600/20 dark:bg-red-500/15 dark:text-red-300 dark:ring-red-500/30">
                                      Break-glass
                                    </Badge>
                                  )}
                                </p>
                                <p className="mt-0.5 truncate text-xs text-ink-500">
                                  {requester} · raised {formatRelativeToNow(r?.created_at)}
                                  {r?.reason ? ` · ${r.reason}` : ''}
                                </p>
                              </div>
                            </div>
                            <div className="flex flex-none flex-wrap items-center gap-2">
                              <WaitingChip since={r?.created_at} />
                              {/* Every row in this card is PENDING by
                                  construction, so a "Pending approval" chip on
                                  each one is three words of nothing next to the
                                  buttons that decide it. Only an unexpected
                                  status earns a badge. */}
                              {r?.status && r.status !== 'PENDING' && (
                                <Badge className={JIT_STATUS_BADGE[r.status]}>
                                  {JIT_STATUS_LABELS[r.status] || r.status}
                                </Badge>
                              )}
                              <Button size="xs" variant="primary" disabled={isMutatingJit} onClick={() => setApproveTarget(r)}>
                                Approve
                              </Button>
                              <Button size="xs" variant="dangerGhost" disabled={isMutatingJit} onClick={() => setDenyTarget(r)}>
                                Deny
                              </Button>
                            </div>
                          </li>
                        )
                      })}
                    </ul>
                  )}
                </QueryState>
                <CardFooter>
                  <p className="text-2xs leading-relaxed text-ink-500">
                    Approving requires an MFA-verified session, and an approver may never decide their
                    own request. Both decisions are written to the audit trail with your name against
                    them.
                  </p>
                </CardFooter>
              </Card>
            )}

            {denied.length > 0 && <DeniedList events={events} href="/admin/audit" />}
          </div>
        </PrimarySection>
      )}

      <QuietSection
        label="Activity"
        description="Computed in the browser from the audit sample below"
        action={
          <ActivityToolbar
            range={range}
            onRangeChange={setRange}
            limitKey={limitKey}
            onLimitChange={setLimitKey}
            idSuffix="admin"
            fetching={auditQuery.isFetching}
          />
        }
      >
        <ActivityAnalysis
          events={events}
          loading={auditQuery.isLoading}
          range={range}
          auditHref="/admin/audit"
          scopeNote={`Organization-wide, computed from ${sample.scope}.`}
          extra={
            <Card className="overflow-hidden">
              <CardHeader>
                <CardTitle icon={Users}>Most active accounts</CardTitle>
              </CardHeader>
              <BarList items={actors} emptyLabel="No actor activity in the sample" />
              <CardFooter>
                <p className="text-2xs leading-relaxed text-ink-500">
                  High volume is not itself suspicious. An automation account should be here.
                </p>
              </CardFooter>
            </Card>
          }
        />
      </QuietSection>

      <QuietSection label="Administration" description="Jump to a surface, or straight to its create form">
        <AdminShortcuts />
      </QuietSection>

      <ConfirmDialog
        open={!!approveTarget}
        title={`Approve request for "${approveTarget?.resource_name || approveTarget?.resource_id || 'this resource'}"?`}
        description="This grants time-boxed access immediately."
        confirmLabel="Approve"
        reasonLabel="Reason (optional)"
        isLoading={approveMutation.isPending}
        onConfirm={(reason) => approveMutation.mutate({ id: approveTarget.id, reason })}
        onCancel={() => setApproveTarget(null)}
      />

      <ConfirmDialog
        open={!!denyTarget}
        title={`Deny request for "${denyTarget?.resource_name || denyTarget?.resource_id || 'this resource'}"?`}
        description="This rejects the request. The requester will need to submit a new one if access is still needed."
        confirmLabel="Deny"
        destructive
        requireReason
        reasonLabel="Reason for denial (required for the audit record)"
        isLoading={denyMutation.isPending}
        onConfirm={(reason) => denyMutation.mutate({ id: denyTarget.id, reason })}
        onCancel={() => setDenyTarget(null)}
      />
    </div>
  )
}

// ---------------------------------------------------------------------------
// Self-service
// ---------------------------------------------------------------------------
// Same grammar as the admin view — console bar, posture plate with a stated
// verdict, grouped figures, one toolbar for the activity zone — so the two
// dashboards read as one product rather than two screens that happen to share
// a route. What differs is only the subject: your own access, not the org's.

function UserDashboard({ user }) {
  const [range, setRange] = useState('7d')
  const [limitKey, setLimitKey] = useState(DEFAULT_EVENT_LIMIT)
  const sample = resolveLimit(limitKey)

  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMyGrants({ activeOnly: true, pageSize: 25, signal }),
  })
  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', 'mine', { status: 'PENDING', dashboard: true }],
    queryFn: ({ signal }) => listMyJitRequests({ status: 'PENDING', pageSize: 5, signal }),
  })
  const sessionsQuery = useQuery({
    queryKey: ['sessions', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMySessions({ activeOnly: true, pageSize: 5, signal }),
  })
  // Walked in pages of 500, the ceiling /audit/search enforces on limit.
  const auditQuery = useQuery({
    queryKey: ['audit', 'dashboard-sample', sample.value],
    queryFn: ({ signal }) => fetchSelfAuditSample(sample.value, signal),
    placeholderData: (prev) => prev,
    retry: false,
  })

  const events = useMemo(() => auditQuery.data?.items || [], [auditQuery.data])
  // Memoised rather than `?? []` inline: a fresh array literal on every render
  // makes the expiringGrants memo below re-run on every render too, which is
  // the one place on this page that does per-grant date arithmetic.
  const grants = useMemo(() => grantsQuery.data?.grants || [], [grantsQuery.data])
  const expiring = useMemo(() => expiringGrants(grants), [grants])
  const pendingRequests = requestsQuery.data?.requests ?? []

  const loadingAttention = grantsQuery.isLoading || requestsQuery.isLoading
  const nothingWaiting = !loadingAttention && expiring.length === 0 && pendingRequests.length === 0
  const urgent = expiring.some((e) => e.tone === 'red')

  const verdict = useMemo(() => {
    if (urgent) {
      return {
        tone: 'red',
        headline: 'Access is about to expire',
        detail: 'At least one grant runs out within the half hour. Re-request now if the work is not finished.',
        to: '/jit',
      }
    }
    if (expiring.length > 0) {
      return {
        tone: 'amber',
        headline: `${expiring.length} grant${expiring.length === 1 ? '' : 's'} expiring soon`,
        detail: 'Expiry is silent — the connection simply stops working when the clock runs out.',
        to: '/jit',
      }
    }
    if (pendingRequests.length > 0) {
      return {
        tone: 'amber',
        headline: `${pendingRequests.length} request${pendingRequests.length === 1 ? '' : 's'} awaiting a decision`,
        detail: 'An approver has to act before this access exists. Nothing further is needed from you.',
        to: '/jit',
      }
    }
    return {
      tone: 'emerald',
      headline: 'Nothing needs you',
      detail: 'No grant expires in the next 12 hours and no request is waiting on an approver.',
      to: null,
    }
  }, [urgent, expiring.length, pendingRequests.length])

  const refreshAll = () => {
    grantsQuery.refetch()
    requestsQuery.refetch()
    sessionsQuery.refetch()
    auditQuery.refetch()
  }

  return (
    <div>
      <ConsoleBar scope="Your access">
        <RefreshControl
          onRefresh={refreshAll}
          isFetching={
            grantsQuery.isFetching || requestsQuery.isFetching || sessionsQuery.isFetching || auditQuery.isFetching
          }
          updatedAt={oldestUpdate(
            grantsQuery.dataUpdatedAt,
            requestsQuery.dataUpdatedAt,
            sessionsQuery.dataUpdatedAt,
            auditQuery.dataUpdatedAt
          )}
        />
      </ConsoleBar>

      <PostureMasthead
        eyebrow="Privileged access"
        title={`Welcome${user?.username ? `, ${user.username}` : ''}`}
        description="Elevation in force, requests in flight, live sessions, and what you have been doing."
        verdict={<PostureVerdict {...verdict} loading={loadingAttention} />}
        groups={
          <>
            <MetricGroup
              label="In force now"
              note="Point-in-time"
              columns={2}
              cells={[
                {
                  key: 'grants',
                  label: 'Active grants',
                  icon: Lock,
                  tone: 'emerald',
                  loading: grantsQuery.isLoading,
                  value: grantsQuery.data?.pagination?.total ?? grants.length,
                  description: 'Elevation available to you',
                  to: '/jit',
                },
                {
                  key: 'sessions',
                  label: 'Active sessions',
                  icon: Radio,
                  live: true,
                  loading: sessionsQuery.isLoading,
                  value: sessionsQuery.data?.pagination?.total ?? sessionsQuery.data?.sessions?.length ?? 0,
                  description: 'Connections open in your name',
                  to: '/sessions',
                },
              ]}
            />
            <MetricGroup
              className="border-t border-surface-800 lg:border-l lg:border-t-0"
              label="On the clock"
              note="Needs you"
              columns={2}
              cells={[
                {
                  key: 'expiring',
                  label: 'Expiring soon',
                  icon: Clock,
                  tone: urgent ? 'red' : expiring.length > 0 ? 'amber' : 'default',
                  loading: grantsQuery.isLoading,
                  value: expiring.length,
                  description: 'Within the next 12 hours',
                  to: '/jit',
                },
                {
                  key: 'requests',
                  label: 'Pending requests',
                  icon: KeyRound,
                  tone: pendingRequests.length > 0 ? 'amber' : 'default',
                  loading: requestsQuery.isLoading,
                  value: requestsQuery.data?.pagination?.total ?? pendingRequests.length,
                  description: 'Waiting on an approver',
                  to: '/jit',
                },
              ]}
            />
          </>
        }
      />

      {nothingWaiting ? (
        <div className="mt-8">
          <AllClearStrip>
            Nothing needs you. No grant expires in the next 12 hours and no request is waiting on an
            approver.
          </AllClearStrip>
        </div>
      ) : (
        <PrimarySection
          title="Needs your attention"
          description="Access running out, and requests still with an approver."
          count={expiring.length + pendingRequests.length}
        >
          <div className={clsx('grid gap-4', expiring.length > 0 && pendingRequests.length > 0 && 'lg:grid-cols-2')}>
            {(expiring.length > 0 || loadingAttention) && (
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle icon={Clock}>Access expiring soon</CardTitle>
                  <span className="ml-auto">
                    <SectionLink to="/jit">All grants</SectionLink>
                  </span>
                </CardHeader>
                {grantsQuery.isLoading ? (
                  <div className="space-y-2 p-4">
                    {[0, 1].map((i) => (
                      <div key={i} className="skeleton h-10 rounded-lg" />
                    ))}
                  </div>
                ) : expiring.length === 0 ? (
                  <EmptyState
                    icon={CheckCircle2}
                    title="Nothing expiring in the next 12 hours"
                    className="py-8"
                  />
                ) : (
                  <ul className="divide-y divide-surface-800">
                    {expiring.slice(0, 5).map(({ grant, label, tone }) => (
                      <li key={grant.id} className="relative flex items-center justify-between gap-4 py-3 pl-5 pr-4">
                        <RowRail tone={tone} />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-ink-100">
                            {grant.resource_name || grant.resource_id || 'Unnamed resource'}
                          </p>
                          <p className="mt-0.5 truncate text-xs text-ink-500">
                            Expires {formatDateTime(grant.expires_at)}
                          </p>
                        </div>
                        <span
                          className={clsx(
                            'flex-none rounded-md px-2 py-1 text-2xs font-semibold tabular-nums ring-1 ring-inset',
                            tone === 'red'
                              ? 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25'
                              : tone === 'amber'
                                ? 'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25'
                                : 'bg-surface-800 text-ink-400 ring-surface-700'
                          )}
                        >
                          {label}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            )}

            {pendingRequests.length > 0 && (
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle icon={KeyRound}>Requests in flight</CardTitle>
                  <span className="ml-auto">
                    <SectionLink to="/jit">View all</SectionLink>
                  </span>
                </CardHeader>
                <ul className="divide-y divide-surface-800">
                  {pendingRequests.map((r) => (
                    <li key={r.id}>
                      <Link
                        to={`/jit/requests/${r.id}`}
                        className="group flex items-center justify-between gap-4 px-4 py-3 transition-colors hover:bg-surface-850"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-ink-100">
                            {r.resource_name || r.resource_id || 'Unnamed resource'}
                          </p>
                          <p className="mt-0.5 text-xs text-ink-500">Requested {formatRelativeToNow(r.created_at)}</p>
                        </div>
                        <div className="flex flex-none items-center gap-2.5">
                          <WaitingChip since={r.created_at} />
                          <Badge className={JIT_STATUS_BADGE[r.status]}>
                            {JIT_STATUS_LABELS[r.status] || r.status}
                          </Badge>
                          <ChevronRight
                            className="h-4 w-4 text-ink-600 transition-transform duration-200 group-hover:translate-x-0.5"
                            strokeWidth={1.5}
                          />
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </Card>
            )}
          </div>
        </PrimarySection>
      )}

      <QuietSection
        label="Your activity"
        description="Computed in the browser from your own audit trail"
        action={
          <ActivityToolbar
            range={range}
            onRangeChange={setRange}
            limitKey={limitKey}
            onLimitChange={setLimitKey}
            idSuffix="self"
            fetching={auditQuery.isFetching}
          />
        }
      >
        <ActivityAnalysis
          events={events}
          loading={auditQuery.isLoading}
          range={range}
          auditHref="/audit"
          scopeNote={`Your own trail, computed from ${sample.scope}.`}
        />
      </QuietSection>
    </div>
  )
}

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  return isAdmin ? <AdminDashboard user={user} /> : <UserDashboard user={user} />
}
