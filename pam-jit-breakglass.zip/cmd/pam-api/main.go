package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/yourorg/pam/internal/api/handlers"
	"github.com/yourorg/pam/internal/config"
	"github.com/yourorg/pam/internal/database"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
	"github.com/yourorg/pam/pkg/iamclient"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
	"go.uber.org/zap"
)

func main() {
	// ── Load .env file into OS environment (Go doesn't do this automatically) ──
	// Try: current dir → parent (project root) → ../..
	godotenv.Load()
	godotenv.Load("../.env")
	godotenv.Load("../../.env")

	// ── Logger ──
	var logger *zap.Logger
	var err error
	if os.Getenv("PAM_SERVER_ENV") == "production" {
		logger, _ = zap.NewProduction()
		gin.SetMode(gin.ReleaseMode)
	} else {
		logger, _ = zap.NewDevelopment()
	}
	defer logger.Sync()

	// ── Config ──
	cfg, err := config.Load()
	if err != nil {
		logger.Fatal("config.load.fail", zap.Error(err))
	}

	// ── Database ──
	db, err := database.Connect(cfg.Database)
	if err != nil {
		logger.Fatal("db.connect.fail", zap.Error(err))
	}

	// AutoMigrate PAM-specific tables (not iam_users — that's IAM's table).
	if !cfg.IsProduction() {
		if err := db.AutoMigrate(
			&models.PAMMFA{},
			&models.PAMResource{},
			&models.VaultEntry{},
			&models.ConnectionSession{},
			// JIT access workflow + time-boxed grants
			&models.JITRequest{},
			&models.AccessGrant{},
			// Tamper-evident audit + recording metadata
			&models.AuditLog{},
			&models.SessionRecording{},
		); err != nil {
			// A failed migration leaves the schema in an unknown state — refuse
			// to serve rather than fail later on the first privileged request.
			logger.Fatal("db.migrate.fail", zap.Error(err))
		}
		logger.Info("db.migrated.pam_tables")
	}

	// ── PAM JWT Issuer (HS256, self-signed — separate from IAM's RS256) ──
	jwtIssuer := pamjwt.New(
		cfg.JWT.SecretKey,
		"pam.yourorg.com", // PAM's own issuer
		cfg.JWT.AccessTTLMin,
		cfg.JWT.RefreshTTLDays,
	)

	// ── IAM Client (for authz/check — PDP only, NOT auth) ──
	iamClient := iamclient.New(cfg.IAM, logger)

	// ── Services ──
	authService := services.NewAuthService(
		db, jwtIssuer, cfg.Vault.EncryptionKey,
		cfg.Security.MaxLoginAttempts,
		cfg.Security.LockoutMinutes,
		logger,
	)
	resourceService := services.NewResourceService(db, cfg.Vault.EncryptionKey, logger)

	// Audit must exist before JIT: every JIT state change writes through it,
	// inside the same transaction as the state change itself.
	auditService := services.NewAuditService(db, logger)
	jitService := services.NewJITService(db, auditService, resourceService, iamClient, cfg.JIT, logger)

	// ── Handlers ──
	authHandler := handlers.NewAuthHandler(authService, logger)
	resourceHandler := handlers.NewResourceHandler(resourceService, logger)
	jitHandler := handlers.NewJITHandler(jitService, logger)
	sessionHandler := handlers.NewSessionHandler(resourceService, auditService, logger)
	adminHandler := handlers.NewAdminHandler(jitService, resourceService, auditService, logger)

	// ── Auto-revocation worker (expiry, break-glass activation) ──
	sweeperCtx, stopSweeper := context.WithCancel(context.Background())
	defer stopSweeper()
	sweeper := services.NewSweeper(jitService,
		time.Duration(cfg.JIT.SweepIntervalSec)*time.Second, logger)
	if cfg.JIT.SweeperEnabled {
		sweeper.Start(sweeperCtx)
	} else {
		logger.Warn("sweeper.disabled",
			zap.String("impact", "grants will not auto-expire and break-glass will never activate"))
	}

	// ── Gin Engine ──
	r := gin.New()
	r.Use(gin.Recovery())

	// CORS
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", cfg.Server.AllowedOrigins)
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers",
			"Origin, Content-Type, Accept, Authorization, X-IAM-Service-Token")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// ── Public health (no auth) ──
	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "PAM", "version": "1.0.0"})
	})

	// ═════════════════════════════════════════════════════════════
	//  AUTH ROUTES (PAM owns its own auth — NOT IAM JWT)
	// ═════════════════════════════════════════════════════════════

	// Public (no token required)
	pub := r.Group("/api/v1/auth")
	{
		pub.POST("/login", authHandler.Login)
		pub.POST("/mfa/verify", authHandler.MFAVerify)
	}

	// Protected (require PAM JWT)
	authed := r.Group("/api/v1/auth")
	authed.Use(middleware.PAMAuth(jwtIssuer, logger))
	{
		authed.GET("/me", authHandler.Me)
		authed.POST("/logout", authHandler.Logout)
		authed.GET("/health", authHandler.Health)

		// MFA setup (requires login first, then enroll TOTP)
		authed.POST("/mfa/setup/initiate", authHandler.MFASetupInitiate)
		authed.POST("/mfa/setup/verify", authHandler.MFASetupVerify)
	}

	// ═════════════════════════════════════════════════════════════
	//  PAM FEATURE ROUTES (require PAM JWT + IAM authz/check)
	//  Every route: PAMAuth → RequirePermission → handler
	// ═════════════════════════════════════════════════════════════
	res := r.Group("/api/v1/pam")
	res.Use(middleware.PAMAuth(jwtIssuer, logger))
	{
		// ── Resources ──
		res.GET("/resources/groups",
			middleware.RequirePermission(iamClient, "pam:resource:List",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.ListGroups)

		res.GET("/resources",
			middleware.RequirePermission(iamClient, "pam:resource:List",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.List)

		res.GET("/resources/:id",
			middleware.RequirePermission(iamClient, "pam:resource:Read",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.Get)

		res.POST("/resources",
			middleware.RequirePermission(iamClient, "pam:resource:Create",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.Create)

		res.DELETE("/resources/:id",
			middleware.RequirePermission(iamClient, "pam:resource:Delete",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.Delete)

		// ── Vault (credential management) ──
		res.POST("/resources/:id/credential",
			middleware.RequirePermission(iamClient, "pam:vault:Store",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.StoreCredential)

		res.POST("/resources/:id/rotate",
			middleware.RequirePermission(iamClient, "pam:vault:Rotate",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.RotateCredential)

		// ── Connection ──
		// Two enforcement layers: IAM/OPA decides whether the principal may
		// ever connect; RequireActiveGrant decides whether they may connect
		// RIGHT NOW. The second is a no-op for resources with requires_jit=false.
		res.GET("/resources/:id/connect-info",
			middleware.RequirePermission(iamClient, "pam:resource:Connect",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			middleware.RequireActiveGrant(jitService, resourceService,
				func(c *gin.Context) string { return c.Param("id") }, logger),
			resourceHandler.ConnectInfo)

		// Open a tracked session. The session is bound to the grant that
		// authorised it, which is what makes cascading auto-revoke possible.
		res.POST("/resources/:id/sessions",
			middleware.RequireMFA(),
			middleware.RequirePermission(iamClient, "pam:session:Start",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			middleware.RequireActiveGrant(jitService, resourceService,
				func(c *gin.Context) string { return c.Param("id") }, logger),
			sessionHandler.Start)

		// ── Sessions (admin monitoring) ──
		res.GET("/sessions",
			middleware.RequirePermission(iamClient, "pam:session:List",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.ListSessions)

		res.POST("/sessions/:id/kill",
			middleware.RequirePermission(iamClient, "pam:session:Kill",
				func(c *gin.Context) string { return fmt.Sprintf("pam:session/%s", c.Param("id")) }, logger),
			resourceHandler.KillSession)

		res.GET("/sessions/mine", sessionHandler.Mine)

		res.POST("/sessions/:id/end", sessionHandler.End)

		// ══════════════════════════════════════════════════════════
		//  JIT ACCESS REQUEST WORKFLOW  (task 29)
		// ══════════════════════════════════════════════════════════
		res.POST("/jit/requests",
			middleware.RequirePermission(iamClient, "pam:jit:Request",
				func(c *gin.Context) string { return "pam:*" }, logger),
			jitHandler.Create)

		res.GET("/jit/requests", jitHandler.List)
		res.GET("/jit/requests/:id", jitHandler.Get)
		res.POST("/jit/requests/:id/cancel", jitHandler.Cancel)

		// Approver actions performed by an admin logged into PAM itself.
		// The IAM console uses /admin/actions/... with the service token.
		res.POST("/jit/requests/:id/approve",
			middleware.RequireMFA(),
			middleware.RequirePermission(iamClient, "pam:jit:Approve",
				func(c *gin.Context) string { return fmt.Sprintf("pam:jit/%s", c.Param("id")) }, logger),
			jitHandler.Approve)

		res.POST("/jit/requests/:id/deny",
			middleware.RequirePermission(iamClient, "pam:jit:Deny",
				func(c *gin.Context) string { return fmt.Sprintf("pam:jit/%s", c.Param("id")) }, logger),
			jitHandler.Deny)

		// ══════════════════════════════════════════════════════════
		//  BREAK-GLASS / EMERGENCY ACCESS  (task 114)
		//  MFA is mandatory: emergency access must never be reachable
		//  with a stolen password alone.
		// ══════════════════════════════════════════════════════════
		res.POST("/jit/breakglass",
			middleware.RequireMFA(),
			middleware.RequirePermission(iamClient, "pam:breakglass:Use",
				func(c *gin.Context) string { return "pam:*" }, logger),
			jitHandler.Breakglass)

		// ══════════════════════════════════════════════════════════
		//  TIME-BOXED GRANTS  (task 32)
		// ══════════════════════════════════════════════════════════
		res.GET("/jit/grants", jitHandler.ListGrants)

		res.POST("/jit/grants/:id/revoke",
			middleware.RequirePermission(iamClient, "pam:jit:Revoke",
				func(c *gin.Context) string { return fmt.Sprintf("pam:grant/%s", c.Param("id")) }, logger),
			jitHandler.RevokeGrant)
	}

	// ═════════════════════════════════════════════════════════════
	//  IAM ADMIN DASHBOARD ENDPOINTS (server-to-server)
	//
	//  Authenticated with the shared service token, NOT a user JWT.
	//  These endpoints do not call IAM /authz/check: doing so would be
	//  circular (IAM asking IAM for permission to read PAM).
	// ═════════════════════════════════════════════════════════════
	admin := r.Group("/api/v1/pam/admin")
	admin.Use(middleware.RequireServiceToken(cfg.IAM.ServiceToken, logger))
	{
		// ── READ-ONLY ──
		admin.GET("/jit-requests", adminHandler.ListJITRequests)
		admin.GET("/jit-requests/:id", adminHandler.GetJITRequest)
		admin.GET("/grants", adminHandler.ListGrants)
		admin.GET("/sessions", adminHandler.ListSessions)
		admin.GET("/recordings", adminHandler.ListRecordings)
		admin.GET("/audit", adminHandler.ListAudit)
		admin.GET("/audit/verify", adminHandler.VerifyAudit)
		admin.GET("/breakglass", adminHandler.ListBreakglass)
		admin.GET("/breakglass/:grant_id/report", adminHandler.BreakglassReport)
		admin.GET("/stats", adminHandler.Stats)

		// ── ACTIONS (attributable writes) ──
		// Require X-Admin-User-Id so the audit record names a human,
		// not the IAM service account.
		actions := admin.Group("/actions")
		actions.Use(middleware.IAMAdminIdentity())
		{
			actions.POST("/jit-requests/:id/approve", jitHandler.Approve)
			actions.POST("/jit-requests/:id/deny", jitHandler.Deny)
			actions.POST("/grants/:id/revoke", jitHandler.RevokeGrant)
			actions.POST("/sessions/:id/kill", adminHandler.KillSession)
		}
	}

	// ── Server ──
	srv := &http.Server{
		Addr:         ":" + cfg.Server.Port,
		Handler:      r,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		logger.Info("server.start", zap.String("port", cfg.Server.Port))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Fatal("server.fail", zap.Error(err))
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("server.shutdown")

	// Stop the sweeper first so no new revocation work starts while the
	// HTTP server drains; give it a bounded window to finish its pass.
	if cfg.JIT.SweeperEnabled {
		sweeper.Stop(10 * time.Second)
	}

	ctx, cancel := context.WithTimeout(context.Background(),
		time.Duration(cfg.Server.ShutdownTimeout)*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		logger.Error("server.shutdown.fail", zap.Error(err))
	}
	logger.Info("server.stopped")
}
