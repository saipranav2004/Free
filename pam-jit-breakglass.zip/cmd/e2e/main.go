package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"time"

	"github.com/yourorg/pam/internal/config"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
	"github.com/yourorg/pam/pkg/iamclient"
	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	glogger "gorm.io/gorm/logger"
)

var failures int

func check(name string, cond bool, extra ...interface{}) {
	if cond {
		fmt.Printf("  PASS  %s\n", name)
	} else {
		failures++
		fmt.Printf("  FAIL  %s %v\n", name, extra)
	}
}

func must(err error, what string) {
	if err != nil {
		failures++
		fmt.Printf("  FAIL  %s: %v\n", what, err)
	}
}

func main() {
	log, _ := zap.NewDevelopment(zap.IncreaseLevel(zap.ErrorLevel))

	// SAFETY: this harness TRUNCATES PAM tables. It refuses to run without an
	// explicit confirmation and an explicit throwaway DSN.
	if os.Getenv("PAM_E2E_CONFIRM") != "yes-destroy-my-data" {
		fmt.Println("refusing to run: set PAM_E2E_CONFIRM=yes-destroy-my-data and PAM_E2E_DSN to a THROWAWAY database")
		fmt.Println(`example: PAM_E2E_DSN="host=127.0.0.1 port=5432 user=postgres password=pw dbname=pam_test sslmode=disable search_path=public"`)
		os.Exit(2)
	}
	dsn := os.Getenv("PAM_E2E_DSN")
	if dsn == "" {
		fmt.Println("PAM_E2E_DSN is required")
		os.Exit(2)
	}
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: glogger.Default.LogMode(glogger.Silent)})
	if err != nil {
		fmt.Println("connect fail:", err)
		os.Exit(1)
	}

	fmt.Println("== 1. AutoMigrate ==")
	must(db.AutoMigrate(
		&models.PAMMFA{}, &models.PAMResource{}, &models.VaultEntry{},
		&models.ConnectionSession{}, &models.JITRequest{}, &models.AccessGrant{},
		&models.AuditLog{}, &models.SessionRecording{},
	), "automigrate")
	fmt.Println("  PASS  all 8 models migrated")

	// Fresh slate
	db.Exec("TRUNCATE pam_audit_log, pam_access_grants, pam_jit_requests, pam_session_recordings, pam_connection_sessions, pam_vault_entries, pam_resources RESTART IDENTITY CASCADE")

	jitCfg := config.JITConfig{
		DefaultDurationMin: 60, MaxDurationMin: 480, RequestTTLMin: 1440,
		MinReasonLength: 10, RequireSeparationOfDuty: true,
		BreakglassWaitMin: 15, BreakglassMaxDurationMin: 60,
		BreakglassActivationWindowMin: 60,
		SweepIntervalSec:              1, SweepBatchSize: 200, SweeperEnabled: true,
	}
	iam := iamclient.New(config.IAMConfig{
		BaseURL: "http://127.0.0.1:59999", AuthzCheckURL: "/api/v1/authz/check",
		TimeoutSec: 1, MaxRetries: 0, RetryBackoffMs: 10,
	}, log)

	audit := services.NewAuditService(db, log)
	res := services.NewResourceService(db, "MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWY=", log)
	jit := services.NewJITService(db, audit, res, iam, jitCfg, log)
	sweeper := services.NewSweeper(jit, time.Second, log)
	ctx := context.Background()

	// ── fixtures ──
	resource := &models.PAMResource{
		Name: "prod-db-01", ResourceType: "postgresql", Host: "10.0.0.5", Port: 5432,
		IsActive: true, RequiresJIT: true, CreatedBy: "seed-admin",
	}
	must(db.Create(resource).Error, "create resource")

	plainResource := &models.PAMResource{
		Name: "dev-redis", ResourceType: "redis", Host: "10.0.0.9", Port: 6379,
		IsActive: true, RequiresJIT: false, CreatedBy: "seed-admin",
	}
	must(db.Create(plainResource).Error, "create non-jit resource")

	fmt.Println("\n== 2. Fail-closed PEP (IAM unreachable) ==")
	resp, err := iam.CheckAuthz(iamclient.AuthzRequest{UserID: "u1", Action: "pam:resource:Connect", ResourceARN: "pam:*"})
	check("IAM unreachable denies", resp != nil && !resp.Data.Allowed, resp)
	check("IAM unreachable returns error", err != nil)
	check("deny reason is iam_unreachable", resp.Data.Reason == "iam_unreachable", resp.Data.Reason)

	fmt.Println("\n== 3. JIT request validation ==")
	_, err = jit.CreateRequest(ctx, services.CreateRequestInput{
		RequesterUserID: "user-alice", RequesterUsername: "alice",
		ResourceID: resource.ID, Reason: "short",
	})
	check("short reason rejected", errors.Is(err, services.ErrReasonTooShort), err)

	_, err = jit.CreateRequest(ctx, services.CreateRequestInput{
		RequesterUserID: "user-alice", RequesterUsername: "alice",
		ResourceID: resource.ID, Reason: "valid justification here", DurationMinutes: 99999,
	})
	check("over-long duration rejected", errors.Is(err, services.ErrDurationExceeded), err)

	req, err := jit.CreateRequest(ctx, services.CreateRequestInput{
		RequesterUserID: "user-alice", RequesterUsername: "alice",
		ResourceID: resource.ID, Reason: "incident INC-4412 investigation",
		DurationMinutes: 30, TicketRef: "INC-4412", IdempotencyKey: "idem-1",
	})
	must(err, "create request")
	check("request PENDING", req != nil && req.Status == models.JITStatusPending)

	dup, err := jit.CreateRequest(ctx, services.CreateRequestInput{
		RequesterUserID: "user-alice", RequesterUsername: "alice",
		ResourceID: resource.ID, Reason: "incident INC-4412 investigation",
		IdempotencyKey: "idem-1",
	})
	check("idempotency replay returns same request", err == nil && dup != nil && dup.ID == req.ID, err)

	_, err = jit.CreateRequest(ctx, services.CreateRequestInput{
		RequesterUserID: "user-alice", RequesterUsername: "alice",
		ResourceID: resource.ID, Reason: "another different reason entirely",
	})
	check("duplicate open request rejected", errors.Is(err, services.ErrDuplicateRequest), err)

	fmt.Println("\n== 4. Separation of duty ==")
	_, _, err = jit.Approve(ctx, services.DecisionInput{
		RequestID: req.ID, ApproverUserID: "user-alice", ApproverUsername: "alice",
	})
	check("self-approval blocked", errors.Is(err, services.ErrSelfApproval), err)

	fmt.Println("\n== 5. Approve → time-boxed grant ==")
	approved, grant, err := jit.Approve(ctx, services.DecisionInput{
		RequestID: req.ID, ApproverUserID: "user-bob", ApproverUsername: "bob", Reason: "verified with on-call",
	})
	must(err, "approve")
	check("request APPROVED", approved != nil && approved.Status == models.JITStatusApproved)
	check("grant ACTIVE", grant != nil && grant.Status == models.GrantStatusActive)
	check("grant window ~30min", grant != nil && int(grant.ExpiresAt.Sub(grant.GrantedAt).Minutes()) == 30,
		grant.ExpiresAt.Sub(grant.GrantedAt))
	check("iam sync SKIPPED (no grant_url)", grant.IAMSyncStatus == models.IAMSyncSkipped, grant.IAMSyncStatus)

	_, _, err = jit.Approve(ctx, services.DecisionInput{
		RequestID: req.ID, ApproverUserID: "user-bob", ApproverUsername: "bob",
	})
	check("double-approve blocked", errors.Is(err, services.ErrInvalidState), err)

	fmt.Println("\n== 6. Grant lookup (PEP layer 2) ==")
	g, err := jit.ActiveGrantFor("user-alice", resource.ID)
	check("alice has active grant", err == nil && g != nil && g.ID == grant.ID, err)
	_, err = jit.ActiveGrantFor("user-carol", resource.ID)
	check("carol has no grant", errors.Is(err, services.ErrGrantNotFound), err)

	fmt.Println("\n== 7. Tracked session bound to grant ==")
	sess, rec, err := res.StartTrackedSession(services.StartSessionInput{
		UserID: "user-alice", Username: "alice", ResourceID: resource.ID,
		SourceIP: "10.1.2.3", GrantID: grant.ID, JITRequestID: req.ID,
	})
	must(err, "start session")
	check("session ACTIVE", sess != nil && sess.Status == "ACTIVE")
	check("session bound to grant", sess.GrantID != nil && *sess.GrantID == grant.ID)
	check("no recording obligation for standard grant", rec == nil)

	fmt.Println("\n== 8. Expiry → auto-revoke kills session ==")
	must(db.Model(&models.AccessGrant{}).Where("id = ?", grant.ID).
		Update("expires_at", time.Now().UTC().Add(-time.Minute)).Error, "backdate grant")
	sr := sweeper.RunOnce(ctx)
	check("1 grant expired", sr.GrantsExpired == 1, sr)
	check("1 session killed", sr.SessionsKilled == 1, sr)

	var reloaded models.AccessGrant
	db.Where("id = ?", grant.ID).First(&reloaded)
	check("grant status EXPIRED", reloaded.Status == models.GrantStatusExpired, reloaded.Status)
	check("sessions_killed recorded", reloaded.SessionsKille == 1, reloaded.SessionsKille)

	var deadSess models.ConnectionSession
	db.Where("id = ?", sess.ID).First(&deadSess)
	check("session KILLED", deadSess.Status == "KILLED", deadSess.Status)
	check("duration is sane (0..120s)", deadSess.DurationSeconds >= 0 && deadSess.DurationSeconds < 120, deadSess.DurationSeconds)
	check("ended_at set", deadSess.EndedAt != nil)

	_, err = jit.ActiveGrantFor("user-alice", resource.ID)
	check("expired grant no longer usable", errors.Is(err, services.ErrGrantNotFound), err)

	fmt.Println("\n== 9. Break-glass ==")
	_, err = jit.RequestBreakglass(ctx, services.CreateRequestInput{
		RequesterUserID: "user-dave", RequesterUsername: "dave",
		ResourceID: resource.ID, Reason: "SEV1 outage, primary on-call unreachable",
	})
	check("break-glass rejected without break-glass credential", errors.Is(err, services.ErrNotBreakglassEligible), err)

	must(db.Create(&models.VaultEntry{
		ResourceID: resource.ID, AccountName: "emergency_root", CredentialType: "password",
		CredentialEnc: "x", IsBreakglass: true, BreakglassNote: "SEV1 only",
	}).Error, "create breakglass vault entry")

	bg, err := jit.RequestBreakglass(ctx, services.CreateRequestInput{
		RequesterUserID: "user-dave", RequesterUsername: "dave",
		ResourceID: resource.ID, Reason: "SEV1 outage, primary on-call unreachable",
		DurationMinutes: 45,
	})
	must(err, "breakglass request")
	check("break-glass WAITING", bg != nil && bg.Status == models.JITStatusWaiting, bg.Status)
	check("available_at ~15min out", bg.AvailableAt != nil &&
		int(bg.AvailableAt.Sub(bg.RequestedAt).Minutes()) == 15, bg.AvailableAt)

	sr = sweeper.RunOnce(ctx)
	check("not activated before waiting period", sr.BreakglassActivated == 0, sr)
	_, err = jit.ActiveGrantFor("user-dave", resource.ID)
	check("dave has no access during waiting period", errors.Is(err, services.ErrGrantNotFound), err)

	must(db.Model(&models.JITRequest{}).Where("id = ?", bg.ID).
		Update("available_at", time.Now().UTC().Add(-time.Second)).Error, "backdate available_at")
	sr = sweeper.RunOnce(ctx)
	check("break-glass activated after wait", sr.BreakglassActivated == 1, sr)

	bgGrant, err := jit.ActiveGrantFor("user-dave", resource.ID)
	must(err, "breakglass grant lookup")
	check("break-glass grant flagged", bgGrant != nil && bgGrant.IsBreakglass)
	check("recording forced", bgGrant != nil && bgGrant.RecordingRequired)
	check("break-glass window 45min", int(bgGrant.ExpiresAt.Sub(bgGrant.GrantedAt).Minutes()) == 45)

	bgSess, bgRec, err := res.StartTrackedSession(services.StartSessionInput{
		UserID: "user-dave", Username: "dave", ResourceID: resource.ID,
		GrantID: bgGrant.ID, JITRequestID: bg.ID, IsBreakglass: true,
		RecordingRequired: bgGrant.RecordingRequired,
	})
	must(err, "breakglass session")
	check("recording obligation created", bgRec != nil && bgRec.Status == models.RecordingStatusPending)
	check("session links recording", bgSess.RecordingID != nil)

	fmt.Println("\n== 10. Force revoke ==")
	revoked, killed, err := jit.RevokeGrant(ctx, bgGrant.ID, "user-bob", "bob", "SEV1 resolved", "10.0.0.1")
	must(err, "revoke")
	check("grant REVOKED", revoked != nil && revoked.Status == models.GrantStatusRevoked)
	check("session killed on revoke", killed == 1, killed)

	var bgRecReloaded models.SessionRecording
	db.Where("id = ?", bgRec.ID).First(&bgRecReloaded)
	check("recording closed on kill", bgRecReloaded.Status == models.RecordingStatusCompleted, bgRecReloaded.Status)

	_, _, err = jit.RevokeGrant(ctx, bgGrant.ID, "user-bob", "bob", "again", "")
	check("double-revoke blocked", errors.Is(err, services.ErrInvalidState), err)

	fmt.Println("\n== 11. Break-glass report ==")
	time.Sleep(600 * time.Millisecond) // let the async report goroutine finish
	report, err := jit.BuildBreakglassReport(bgGrant.ID)
	must(err, "report")
	check("report has the session", report != nil && len(report.Sessions) == 1)
	check("report has the recording", report != nil && len(report.Recordings) == 1)
	check("report has audit trail", report != nil && len(report.AuditTrail) >= 3, len(report.AuditTrail))
	check("report flags force-revocation", report != nil && len(report.Findings) > 0, report.Findings)
	check("access seconds sane", report.AccessSeconds >= 0 && report.AccessSeconds < 120, report.AccessSeconds)

	fmt.Println("\n== 12. Stale request expiry ==")
	stale, err := jit.CreateRequest(ctx, services.CreateRequestInput{
		RequesterUserID: "user-erin", RequesterUsername: "erin",
		ResourceID: plainResource.ID, Reason: "routine access for maintenance",
	})
	must(err, "stale request")
	must(db.Model(&models.JITRequest{}).Where("id = ?", stale.ID).
		Update("request_expires_at", time.Now().UTC().Add(-time.Hour)).Error, "backdate ttl")
	sr = sweeper.RunOnce(ctx)
	check("stale request expired", sr.RequestsExpired == 1, sr)
	got, _ := jit.GetRequest(stale.ID)
	check("status EXPIRED", got != nil && got.Status == models.JITStatusExpired, got.Status)

	fmt.Println("\n== 13. Audit chain integrity ==")
	v, err := audit.VerifyChain(10000)
	must(err, "verify chain")
	check("chain valid", v != nil && v.Valid, v)
	fmt.Printf("        (%d audit rows verified)\n", v.RowsChecked)

	var critical int64
	db.Model(&models.AuditLog{}).Where("severity = ?", models.AuditSeverityCritical).Count(&critical)
	check("CRITICAL events recorded for break-glass", critical >= 3, critical)

	// Tamper with one row and prove detection.
	db.Exec("UPDATE pam_audit_log SET details = '{\"tampered\":true}' WHERE seq = (SELECT MIN(seq) FROM pam_audit_log)")
	v2, _ := audit.VerifyChain(10000)
	check("tampering detected", v2 != nil && !v2.Valid && v2.BrokenAtSeq != nil, v2)
	fmt.Printf("        (break detected at seq %v: %s)\n", derefSeq(v2), v2.Detail)

	fmt.Println("\n== 14. Paginated admin reads ==")
	rows, total, err := audit.List(services.AuditFilter{Severity: models.AuditSeverityCritical, Page: 1, PageSize: 2})
	must(err, "audit list")
	check("pagination caps page size", len(rows) <= 2, len(rows))
	check("total >= returned", total >= int64(len(rows)))

	sessions, stotal, err := res.ListSessions(services.SessionFilter{Page: 1, PageSize: 10})
	must(err, "session list")
	check("sessions listed", stotal == 2 && len(sessions) == 2, stotal)

	pend, err := jit.PendingApprovalCount()
	must(err, "pending count")
	check("no pending approvals left", pend == 0, pend)

	fmt.Printf("\n=================================\n")
	if failures == 0 {
		fmt.Println("ALL CHECKS PASSED")
	} else {
		fmt.Printf("%d CHECK(S) FAILED\n", failures)
		os.Exit(1)
	}
}

func derefSeq(v *services.ChainVerification) interface{} {
	if v == nil || v.BrokenAtSeq == nil {
		return nil
	}
	return *v.BrokenAtSeq
}
