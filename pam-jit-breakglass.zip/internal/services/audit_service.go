// pam/internal/services/audit_service.go
//
// Tamper-evident audit trail.
//
// Every security-relevant event is appended to pam_audit_log with the SHA-256
// of the previous row folded into its own hash. Deleting or editing any row
// breaks the chain from that point forward, which VerifyChain detects.
//
// Concurrency: the chain requires a total order. Appends take a Postgres
// transaction-scoped advisory lock, so concurrent writers serialise on the
// chain tail instead of racing and producing two rows with the same PrevHash.
package services

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/yourorg/pam/internal/models"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

// auditChainLockKey is the advisory-lock key that serialises chain appends.
// Any constant works as long as nothing else in the database uses it.
const auditChainLockKey int64 = 7_260_114_029

// AuditEntry is the input to an audit write. Hash/PrevHash/Seq are computed.
type AuditEntry struct {
	ActorUserID   string
	ActorUsername string
	ActorType     string // USER | SYSTEM | IAM ("USER" if empty)

	Action   string
	Outcome  string // SUCCESS | FAILURE | DENIED ("SUCCESS" if empty)
	Severity string // INFO | WARN | CRITICAL ("INFO" if empty)

	ResourceType string
	ResourceID   string
	ResourceName string

	RequestID string
	GrantID   string
	SessionID string

	SourceIP        string
	UserAgent       string
	AuthzDecisionID string

	Details map[string]interface{}
}

// AuditFilter drives the read-only audit query used by the IAM admin console.
type AuditFilter struct {
	ActorUserID string
	Action      string
	Outcome     string
	Severity    string
	ResourceID  string
	GrantID     string
	RequestID   string
	SessionID   string
	From        *time.Time
	To          *time.Time
	Search      string
	Page        int
	PageSize    int
}

// AuditService writes and reads the immutable audit log.
type AuditService struct {
	db     *gorm.DB
	logger *zap.Logger
}

func NewAuditService(db *gorm.DB, logger *zap.Logger) *AuditService {
	return &AuditService{db: db, logger: logger}
}

// DB exposes the handle for callers that need to compose transactions.
func (s *AuditService) DB() *gorm.DB { return s.db }

// WriteTx appends an audit record inside an existing transaction. Use this for
// anything that mutates state: the audit row and the state change then commit
// or roll back together, so there is no "action happened but was not logged"
// window.
func (s *AuditService) WriteTx(tx *gorm.DB, e AuditEntry) error {
	row, err := s.build(tx, e)
	if err != nil {
		return err
	}
	return tx.Create(row).Error
}

// Write appends an audit record in its own transaction. Best-effort: failures
// are logged loudly but not returned, for call sites (background sweeper
// notifications, read-only events) where losing the request is worse than
// losing the log line. Prefer WriteTx wherever state changes.
func (s *AuditService) Write(e AuditEntry) {
	err := s.db.Transaction(func(tx *gorm.DB) error {
		return s.WriteTx(tx, e)
	})
	if err != nil {
		s.logger.Error("audit.write.fail",
			zap.String("action", e.Action),
			zap.String("actor", e.ActorUserID),
			zap.Error(err),
		)
	}
}

// build locks the chain tail, computes the hash and returns the row to insert.
func (s *AuditService) build(tx *gorm.DB, e AuditEntry) (*models.AuditLog, error) {
	// Serialise chain appends for the lifetime of this transaction.
	if err := tx.Exec("SELECT pg_advisory_xact_lock(?)", auditChainLockKey).Error; err != nil {
		return nil, fmt.Errorf("audit chain lock: %w", err)
	}

	var prevHash string
	// Raw scan (not First) so an empty table is not an error.
	if err := tx.Raw(`SELECT hash FROM pam_audit_log ORDER BY seq DESC LIMIT 1`).
		Scan(&prevHash).Error; err != nil {
		return nil, fmt.Errorf("audit chain tail: %w", err)
	}

	detailsJSON := ""
	if len(e.Details) > 0 {
		b, err := json.Marshal(e.Details)
		if err != nil {
			return nil, fmt.Errorf("audit details marshal: %w", err)
		}
		detailsJSON = string(b)
	}

	row := &models.AuditLog{
		ID: uuid.NewString(),
		// Truncated to microseconds: PostgreSQL timestamptz stores microsecond
		// precision, so a nanosecond-precision value would hash differently after
		// a round trip and every chain verification would report a false break.
		OccurredAt:      time.Now().UTC().Truncate(time.Microsecond),
		ActorUserID:     e.ActorUserID,
		ActorUsername:   e.ActorUsername,
		ActorType:       defaultStr(e.ActorType, "USER"),
		Action:          e.Action,
		Outcome:         defaultStr(e.Outcome, models.AuditOutcomeSuccess),
		Severity:        defaultStr(e.Severity, models.AuditSeverityInfo),
		ResourceType:    e.ResourceType,
		ResourceID:      e.ResourceID,
		ResourceName:    e.ResourceName,
		RequestID:       e.RequestID,
		GrantID:         e.GrantID,
		SessionID:       e.SessionID,
		SourceIP:        e.SourceIP,
		UserAgent:       truncateStr(e.UserAgent, 512),
		AuthzDecisionID: e.AuthzDecisionID,
		Details:         detailsJSON,
		PrevHash:        prevHash,
	}
	row.Hash = chainHash(prevHash, row)
	return row, nil
}

// chainHash computes SHA-256 over prev_hash + the canonical field set.
// The field list and order are part of the audit contract: changing them
// invalidates verification of previously written rows.
func chainHash(prevHash string, r *models.AuditLog) string {
	var sb strings.Builder
	write := func(parts ...string) {
		for _, p := range parts {
			sb.WriteString(p)
			sb.WriteByte(0x1f) // unit separator — cannot appear in our values
		}
	}
	write(
		prevHash,
		r.ID,
		r.OccurredAt.UTC().Format(time.RFC3339Nano),
		r.ActorUserID,
		r.ActorUsername,
		r.ActorType,
		r.Action,
		r.Outcome,
		r.Severity,
		r.ResourceType,
		r.ResourceID,
		r.ResourceName,
		r.RequestID,
		r.GrantID,
		r.SessionID,
		r.SourceIP,
		r.AuthzDecisionID,
		r.Details,
	)
	sum := sha256.Sum256([]byte(sb.String()))
	return hex.EncodeToString(sum[:])
}

// ──────────────────────────────────────────────────────────────────────────
// READ (IAM admin console)
// ──────────────────────────────────────────────────────────────────────────

// List returns a page of audit records plus the total row count for the filter.
func (s *AuditService) List(f AuditFilter) ([]models.AuditLog, int64, error) {
	page, size := normalisePaging(f.Page, f.PageSize)

	q := s.db.Model(&models.AuditLog{})
	if f.ActorUserID != "" {
		q = q.Where("actor_user_id = ?", f.ActorUserID)
	}
	if f.Action != "" {
		q = q.Where("action = ?", f.Action)
	}
	if f.Outcome != "" {
		q = q.Where("outcome = ?", f.Outcome)
	}
	if f.Severity != "" {
		q = q.Where("severity = ?", f.Severity)
	}
	if f.ResourceID != "" {
		q = q.Where("resource_id = ?", f.ResourceID)
	}
	if f.GrantID != "" {
		q = q.Where("grant_id = ?", f.GrantID)
	}
	if f.RequestID != "" {
		q = q.Where("request_id = ?", f.RequestID)
	}
	if f.SessionID != "" {
		q = q.Where("session_id = ?", f.SessionID)
	}
	if f.From != nil {
		q = q.Where("occurred_at >= ?", *f.From)
	}
	if f.To != nil {
		q = q.Where("occurred_at <= ?", *f.To)
	}
	if f.Search != "" {
		like := "%" + strings.ToLower(f.Search) + "%"
		q = q.Where(
			"LOWER(actor_username) LIKE ? OR LOWER(action) LIKE ? OR LOWER(resource_name) LIKE ? OR LOWER(details) LIKE ?",
			like, like, like, like,
		)
	}

	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var rows []models.AuditLog
	err := q.Order("seq DESC").Limit(size).Offset((page - 1) * size).Find(&rows).Error
	return rows, total, err
}

// ChainVerification is the result of a tamper check.
type ChainVerification struct {
	Valid       bool   `json:"valid"`
	RowsChecked int    `json:"rows_checked"`
	FirstSeq    int64  `json:"first_seq"`
	LastSeq     int64  `json:"last_seq"`
	BrokenAtSeq *int64 `json:"broken_at_seq,omitempty"`
	Detail      string `json:"detail,omitempty"`
}

// VerifyChain recomputes the hash chain over the most recent `limit` rows.
// A break means a row was deleted or mutated after it was written.
func (s *AuditService) VerifyChain(limit int) (*ChainVerification, error) {
	if limit <= 0 || limit > 100000 {
		limit = 5000
	}

	// Pull the newest `limit` rows, then walk them oldest → newest.
	var desc []models.AuditLog
	if err := s.db.Order("seq DESC").Limit(limit).Find(&desc).Error; err != nil {
		return nil, err
	}
	if len(desc) == 0 {
		return &ChainVerification{Valid: true, Detail: "audit log is empty"}, nil
	}

	rows := make([]models.AuditLog, len(desc))
	for i := range desc {
		rows[len(desc)-1-i] = desc[i]
	}

	res := &ChainVerification{
		Valid:       true,
		RowsChecked: len(rows),
		FirstSeq:    rows[0].Seq,
		LastSeq:     rows[len(rows)-1].Seq,
	}

	for i, r := range rows {
		row := r
		if want := chainHash(row.PrevHash, &row); want != row.Hash {
			seq := row.Seq
			res.Valid = false
			res.BrokenAtSeq = &seq
			res.Detail = "row hash does not match its content"
			return res, nil
		}
		if i > 0 && row.PrevHash != rows[i-1].Hash {
			seq := row.Seq
			res.Valid = false
			res.BrokenAtSeq = &seq
			res.Detail = "row does not link to its predecessor (row deleted or reordered)"
			return res, nil
		}
	}
	return res, nil
}

// ── small helpers ─────────────────────────────────────────────────────────

func defaultStr(v, fallback string) string {
	if strings.TrimSpace(v) == "" {
		return fallback
	}
	return v
}

func truncateStr(v string, max int) string {
	if len(v) > max {
		return v[:max]
	}
	return v
}

// normalisePaging clamps page/page_size to sane bounds (1-based pages).
func normalisePaging(page, size int) (int, int) {
	if page < 1 {
		page = 1
	}
	if size <= 0 {
		size = 50
	}
	if size > 200 {
		size = 200
	}
	return page, size
}
