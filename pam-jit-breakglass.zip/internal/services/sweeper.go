// pam/internal/services/sweeper.go
//
// Auto-revocation worker.
//
// Deliberately built on time.Ticker rather than robfig/cron or go-co-op/gocron:
// the schedule is a fixed short interval, not a crontab, so a cron parser adds
// a dependency and a failure mode without adding capability. Multi-replica
// safety comes from FOR UPDATE SKIP LOCKED in the queries, not from the timer.
//
// Guarantees:
//   - a panic in one pass does not kill the worker (each pass is recovered)
//   - passes never overlap (the ticker body runs synchronously)
//   - shutdown is cooperative via context; Stop() waits for the in-flight pass
package services

import (
	"context"
	"sync"
	"time"

	"go.uber.org/zap"
)

// Sweeper periodically expires grants and requests and activates break-glass.
type Sweeper struct {
	jit      *JITService
	interval time.Duration
	logger   *zap.Logger

	stopOnce sync.Once
	done     chan struct{}
	cancel   context.CancelFunc
}

// NewSweeper builds the worker. interval <= 0 falls back to 30s.
func NewSweeper(jit *JITService, interval time.Duration, logger *zap.Logger) *Sweeper {
	if interval <= 0 {
		interval = 30 * time.Second
	}
	return &Sweeper{
		jit:      jit,
		interval: interval,
		logger:   logger,
		done:     make(chan struct{}),
	}
}

// Start runs the worker until Stop is called or the parent context is done.
func (s *Sweeper) Start(parent context.Context) {
	ctx, cancel := context.WithCancel(parent)
	s.cancel = cancel

	go func() {
		defer close(s.done)
		ticker := time.NewTicker(s.interval)
		defer ticker.Stop()

		s.logger.Info("sweeper.started", zap.Duration("interval", s.interval))

		// Run one pass immediately so a restart does not leave expired grants
		// live for a whole interval.
		s.RunOnce(ctx)

		for {
			select {
			case <-ctx.Done():
				s.logger.Info("sweeper.stopped")
				return
			case <-ticker.C:
				s.RunOnce(ctx)
			}
		}
	}()
}

// Stop signals the worker and waits for the current pass to finish.
func (s *Sweeper) Stop(timeout time.Duration) {
	s.stopOnce.Do(func() {
		if s.cancel != nil {
			s.cancel()
		}
	})
	select {
	case <-s.done:
	case <-time.After(timeout):
		s.logger.Warn("sweeper.stop.timeout", zap.Duration("timeout", timeout))
	}
}

// RunOnce executes a single sweep pass. Exported so it can be triggered
// manually (tests, admin "force sweep" tooling) without waiting for the tick.
func (s *Sweeper) RunOnce(ctx context.Context) SweepResult {
	var res SweepResult

	defer func() {
		if r := recover(); r != nil {
			s.logger.Error("sweeper.panic", zap.Any("recovered", r))
		}
	}()

	started := time.Now()

	// Order matters: activate first so a break-glass grant that is due now is
	// not created and immediately expired in the same pass by a stale clock.
	activated, errs := s.jit.ActivateDueBreakglass(ctx)
	res.BreakglassActivated = activated
	res.Errors += errs

	expired, killed, errs := s.jit.ExpireDueGrants(ctx)
	res.GrantsExpired = expired
	res.SessionsKilled = killed
	res.Errors += errs

	staleReqs, errs := s.jit.ExpireStaleRequests(ctx)
	res.RequestsExpired = staleReqs
	res.Errors += errs

	if res.GrantsExpired > 0 || res.RequestsExpired > 0 || res.BreakglassActivated > 0 || res.Errors > 0 {
		s.logger.Info("sweeper.pass",
			zap.Int("grants_expired", res.GrantsExpired),
			zap.Int("sessions_killed", res.SessionsKilled),
			zap.Int("requests_expired", res.RequestsExpired),
			zap.Int("breakglass_activated", res.BreakglassActivated),
			zap.Int("errors", res.Errors),
			zap.Duration("took", time.Since(started)),
		)
	}
	return res
}
