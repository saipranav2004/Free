// pam/internal/models/audit.go
//
// pam_audit_log        — append-only, hash-chained (tamper-evident) audit trail
// pam_session_recordings — metadata for session recordings (the bytes live in S3)
//
// The audit table intentionally has NO UpdatedAt and NO DeletedAt: rows are
// never updated and never soft-deleted. Each row carries the SHA-256 of the
// previous row, so any deletion or mutation breaks the chain and is detectable
// (see AuditService.VerifyChain).
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// Audit outcomes.
const (
	AuditOutcomeSuccess = "SUCCESS"
	AuditOutcomeFailure = "FAILURE"
	AuditOutcomeDenied  = "DENIED"
)

// Audit severities. CRITICAL is reserved for break-glass and forced revocation.
const (
	AuditSeverityInfo     = "INFO"
	AuditSeverityWarn     = "WARN"
	AuditSeverityCritical = "CRITICAL"
)

// Canonical audit action names (kept as constants so the IAM console can filter
// on stable strings instead of free text).
const (
	AuditJITRequested          = "JIT_REQUEST_CREATED"
	AuditJITApproved           = "JIT_REQUEST_APPROVED"
	AuditJITDenied             = "JIT_REQUEST_DENIED"
	AuditJITCancelled          = "JIT_REQUEST_CANCELLED"
	AuditJITExpired            = "JIT_REQUEST_EXPIRED"
	AuditGrantCreated          = "ACCESS_GRANT_CREATED"
	AuditGrantExpired          = "ACCESS_GRANT_EXPIRED"
	AuditGrantRevoked          = "ACCESS_GRANT_REVOKED"
	AuditGrantIAMSync          = "ACCESS_GRANT_IAM_SYNC"
	AuditBreakglassRequested   = "BREAKGLASS_REQUESTED"
	AuditBreakglassActivated   = "BREAKGLASS_ACTIVATED"
	AuditBreakglassReportBuilt = "BREAKGLASS_REPORT_GENERATED"
	AuditSessionStarted        = "SESSION_STARTED"
	AuditSessionEnded          = "SESSION_ENDED"
	AuditSessionKilled         = "SESSION_KILLED"
	AuditAuthzDenied           = "AUTHZ_DENIED"
)

// AuditLog is one immutable audit record.
type AuditLog struct {
	// Seq is the chain ordinal (bigserial). It is the primary key so the
	// hash chain has a total order that Postgres itself guarantees.
	Seq int64 `gorm:"primaryKey;autoIncrement" json:"seq"`

	ID string `gorm:"type:varchar(36);not null;uniqueIndex" json:"id"`

	OccurredAt time.Time `gorm:"not null;index" json:"occurred_at"`

	ActorUserID   string `gorm:"type:varchar(36);index" json:"actor_user_id,omitempty"`
	ActorUsername string `gorm:"type:varchar(150)" json:"actor_username,omitempty"`
	ActorType     string `gorm:"type:varchar(20);default:'USER'" json:"actor_type"` // USER | SYSTEM | IAM

	Action   string `gorm:"type:varchar(100);not null;index" json:"action"`
	Outcome  string `gorm:"type:varchar(20);not null;default:'SUCCESS';index" json:"outcome"`
	Severity string `gorm:"type:varchar(20);not null;default:'INFO';index" json:"severity"`

	ResourceType string `gorm:"type:varchar(50);index" json:"resource_type,omitempty"`
	ResourceID   string `gorm:"type:varchar(36);index" json:"resource_id,omitempty"`
	ResourceName string `gorm:"type:varchar(255)" json:"resource_name,omitempty"`

	RequestID string `gorm:"type:varchar(36);index" json:"request_id,omitempty"`
	GrantID   string `gorm:"type:varchar(36);index" json:"grant_id,omitempty"`
	SessionID string `gorm:"type:varchar(36);index" json:"session_id,omitempty"`

	SourceIP        string `gorm:"type:varchar(45)" json:"source_ip,omitempty"`
	UserAgent       string `gorm:"type:varchar(512)" json:"user_agent,omitempty"`
	AuthzDecisionID string `gorm:"type:varchar(255);index" json:"authz_decision_id,omitempty"`

	// Details is a JSON document (stored as text for portability).
	Details string `gorm:"type:text" json:"details,omitempty"`

	// Tamper-evidence.
	PrevHash string `gorm:"type:varchar(64)" json:"prev_hash,omitempty"`
	Hash     string `gorm:"type:varchar(64);index" json:"hash"`

	CreatedAt time.Time `gorm:"autoCreateTime" json:"created_at"`
}

func (AuditLog) TableName() string { return "pam_audit_log" }

func (a *AuditLog) BeforeCreate(tx *gorm.DB) error {
	if a.ID == "" {
		a.ID = uuid.NewString()
	}
	return nil
}

// Recording lifecycle.
const (
	RecordingStatusPending   = "PENDING"
	RecordingStatusRecording = "RECORDING"
	RecordingStatusCompleted = "COMPLETED"
	RecordingStatusFailed    = "FAILED"
)

// SessionRecording is metadata about a recorded session. The recording bytes
// themselves live in S3/MinIO under StorageBucket/StorageKey.
//
// NOTE: this repository does not yet contain a capture pipeline (no SSH/RDP
// proxy exists). Rows are created in PENDING state whenever a session is opened
// under a grant that mandates recording, so the obligation is at least
// auditable and the IAM console has a real surface to read.
type SessionRecording struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	SessionID string  `gorm:"type:varchar(36);not null;index" json:"session_id"`
	GrantID   *string `gorm:"type:varchar(36);index" json:"grant_id,omitempty"`

	UserID       string `gorm:"type:varchar(36);not null;index" json:"user_id"`
	Username     string `gorm:"type:varchar(150)" json:"username"`
	ResourceID   string `gorm:"type:varchar(36);not null;index" json:"resource_id"`
	ResourceName string `gorm:"type:varchar(255)" json:"resource_name"`

	IsBreakglass bool `gorm:"not null;default:false;index" json:"is_breakglass"`

	Format        string `gorm:"type:varchar(30);default:'asciicast'" json:"format"`
	StorageBucket string `gorm:"type:varchar(255)" json:"storage_bucket,omitempty"`
	StorageKey    string `gorm:"type:varchar(512)" json:"storage_key,omitempty"`
	SizeBytes     int64  `gorm:"default:0" json:"size_bytes"`
	SHA256        string `gorm:"column:sha256;type:varchar(64)" json:"sha256,omitempty"`

	Status string `gorm:"type:varchar(20);not null;default:'PENDING';index" json:"status"`

	StartedAt       time.Time  `gorm:"not null;index" json:"started_at"`
	EndedAt         *time.Time `json:"ended_at,omitempty"`
	DurationSeconds int        `gorm:"default:0" json:"duration_seconds"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (SessionRecording) TableName() string { return "pam_session_recordings" }

func (r *SessionRecording) BeforeCreate(tx *gorm.DB) error {
	if r.ID == "" {
		r.ID = uuid.NewString()
	}
	return nil
}
