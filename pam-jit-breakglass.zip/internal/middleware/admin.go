// pam/internal/middleware/admin.go
//
// Identity propagation for server-to-server calls from the IAM admin console.
//
// The console authenticates to PAM with the shared service token
// (RequireServiceToken), which proves "IAM is calling" but says nothing about
// WHICH human clicked the button. Every approval, denial and revocation must be
// attributable to a person, so the console additionally forwards the acting
// admin's identity in headers, and PAM refuses write actions without it.
//
// Read-only admin endpoints do not need this middleware — only the action ones.
package middleware

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

// Headers the IAM console must send on admin action calls.
const (
	HeaderAdminUserID   = "X-Admin-User-Id"
	HeaderAdminUsername = "X-Admin-Username"
)

// Context keys set by IAMAdminIdentity.
const (
	CtxAdminUserID   = "admin_user_id"
	CtxAdminUsername = "admin_username"
)

// IAMAdminIdentity requires and extracts the acting admin's identity.
// Use it ONLY behind RequireServiceToken.
func IAMAdminIdentity() gin.HandlerFunc {
	return func(c *gin.Context) {
		adminID := strings.TrimSpace(c.GetHeader(HeaderAdminUserID))
		if adminID == "" {
			c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
				"success": false,
				"error":   "X-Admin-User-Id header is required so the action can be attributed to a person",
				"code":    "admin_identity_required",
			})
			return
		}
		adminName := strings.TrimSpace(c.GetHeader(HeaderAdminUsername))
		if adminName == "" {
			adminName = adminID
		}

		c.Set(CtxAdminUserID, adminID)
		c.Set(CtxAdminUsername, adminName)
		c.Next()
	}
}

// AdminIdentityFromContext returns the acting admin, falling back to the
// authenticated PAM user when the request came through the normal JWT path.
func AdminIdentityFromContext(c *gin.Context) (userID, username string) {
	if v, ok := c.Get(CtxAdminUserID); ok {
		if s, _ := v.(string); s != "" {
			userID = s
		}
	}
	if v, ok := c.Get(CtxAdminUsername); ok {
		if s, _ := v.(string); s != "" {
			username = s
		}
	}
	if userID == "" {
		if v, ok := c.Get("user_id"); ok {
			userID, _ = v.(string)
		}
	}
	if username == "" {
		if v, ok := c.Get("username"); ok {
			username, _ = v.(string)
		}
	}
	return userID, username
}
