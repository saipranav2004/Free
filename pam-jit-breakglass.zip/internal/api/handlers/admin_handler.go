// pam/internal/api/handlers/admin_handler.go
//
// The surface the IAM admin console reads from PAM.
//
// Two clearly separated groups:
//
//	/api/v1/pam/admin/...          READ-ONLY. Service token only. No mutations.
//	/api/v1/pam/admin/actions/...  WRITE. Service token + X-Admin-User-Id, so
//	                               every approval/denial/revocation/kill is
//	                               attributable to a named human, not to "IAM".
//
// The task specified read-only endpoints; the action group is a deliberate
// addition, because "the approver sees it in the IAM admin console" is only
// useful if the console can also act on it. Keeping the two groups apart means
// the read surface can be granted to reporting/SIEM integrations without
// handing them the ability to mutate access.
package handlers

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/response"
	"github.com/yourorg/pam/internal/services"
	"go.uber.org/zap"
)

type AdminHandler struct {
	jit    *services.JITService
	res    *services.ResourceService
	audit  *services.AuditService
	logger *zap.Logger
}

func NewAdminHandler(
	jit *services.JITService,
	res *services.ResourceService,
	audit *services.AuditService,
	logger *zap.Logger,
) *AdminHandler {
	return &AdminHandler{jit: jit, res: res, audit: audit, logger: logger}
}

// ──────────────────────────────────────────────────────────────────────────
// READ-ONLY
// ──────────────────────────────────────────────────────────────────────────

// ListJITRequests handles GET /api/v1/pam/admin/jit-requests
// Query: status, type, resource_id, requester_user_id, q, page, page_size
func (h *AdminHandler) ListJITRequests(c *gin.Context) {
	page, size := pagingFrom(c)
	rows, total, err := h.jit.ListRequests(services.RequestFilter{
		RequesterUserID: c.Query("requester_user_id"),
		Status:          c.Query("status"),
		RequestType:     c.Query("type"),
		ResourceID:      c.Query("resource_id"),
		Search:          c.Query("q"),
		Page:            page,
		PageSize:        size,
	})
	if err != nil {
		h.logger.Error("admin.jit.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch JIT requests")
		return
	}
	response.Success(c, paged(rows, total, page, size, "requests"), "JIT requests fetched")
}

// GetJITRequest handles GET /api/v1/pam/admin/jit-requests/:id
func (h *AdminHandler) GetJITRequest(c *gin.Context) {
	req, err := h.jit.GetRequest(c.Param("id"))
	if err != nil {
		response.Error(c, http.StatusNotFound, "JIT request not found")
		return
	}

	payload := gin.H{"request": req}
	if req.GrantID != nil {
		if g, err := h.jit.GetGrant(*req.GrantID); err == nil {
			payload["grant"] = g
		}
	}
	// The decision trail for this request, oldest first.
	trail, _, err := h.audit.List(services.AuditFilter{RequestID: req.ID, PageSize: 200})
	if err == nil {
		payload["audit_trail"] = trail
	}
	response.Success(c, payload, "JIT request fetched")
}

// ListGrants handles GET /api/v1/pam/admin/grants
// Query: user_id, resource_id, status, active=true, breakglass=true|false
func (h *AdminHandler) ListGrants(c *gin.Context) {
	page, size := pagingFrom(c)
	rows, total, err := h.jit.ListGrants(services.GrantFilter{
		UserID:       c.Query("user_id"),
		ResourceID:   c.Query("resource_id"),
		Status:       c.Query("status"),
		IsBreakglass: boolQuery(c, "breakglass"),
		ActiveOnly:   c.Query("active") == "true",
		Page:         page,
		PageSize:     size,
	})
	if err != nil {
		h.logger.Error("admin.grants.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch access grants")
		return
	}
	response.Success(c, paged(rows, total, page, size, "grants"), "Access grants fetched")
}

// ListSessions handles GET /api/v1/pam/admin/sessions
// Query: user_id, resource_id, grant_id, status, active=true, breakglass, from, to, q
func (h *AdminHandler) ListSessions(c *gin.Context) {
	page, size := pagingFrom(c)
	from, to := timeRange(c)

	rows, total, err := h.res.ListSessions(services.SessionFilter{
		UserID:       c.Query("user_id"),
		ResourceID:   c.Query("resource_id"),
		GrantID:      c.Query("grant_id"),
		Status:       strings.ToUpper(c.Query("status")),
		ActiveOnly:   c.Query("active") == "true",
		IsBreakglass: boolQuery(c, "breakglass"),
		From:         from,
		To:           to,
		Search:       c.Query("q"),
		Page:         page,
		PageSize:     size,
	})
	if err != nil {
		h.logger.Error("admin.sessions.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch sessions")
		return
	}
	response.Success(c, paged(rows, total, page, size, "sessions"), "Sessions fetched")
}

// ListRecordings handles GET /api/v1/pam/admin/recordings
//
// Returns recording METADATA only. Playback bytes are not served here: the
// capture pipeline (SSH/RDP proxy → S3) is not part of this repository yet, so
// rows describe the recording obligation and its lifecycle state.
func (h *AdminHandler) ListRecordings(c *gin.Context) {
	page, size := pagingFrom(c)
	rows, total, err := h.res.ListRecordings(services.RecordingFilter{
		UserID:       c.Query("user_id"),
		ResourceID:   c.Query("resource_id"),
		SessionID:    c.Query("session_id"),
		GrantID:      c.Query("grant_id"),
		Status:       c.Query("status"),
		IsBreakglass: boolQuery(c, "breakglass"),
		Page:         page,
		PageSize:     size,
	})
	if err != nil {
		h.logger.Error("admin.recordings.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch recordings")
		return
	}
	response.Success(c, paged(rows, total, page, size, "recordings"), "Recordings fetched")
}

// ListAudit handles GET /api/v1/pam/admin/audit
// Query: actor_user_id, action, outcome, severity, resource_id, grant_id,
//
//	request_id, session_id, from, to, q, page, page_size
func (h *AdminHandler) ListAudit(c *gin.Context) {
	page, size := pagingFrom(c)
	from, to := timeRange(c)

	rows, total, err := h.audit.List(services.AuditFilter{
		ActorUserID: c.Query("actor_user_id"),
		Action:      c.Query("action"),
		Outcome:     strings.ToUpper(c.Query("outcome")),
		Severity:    strings.ToUpper(c.Query("severity")),
		ResourceID:  c.Query("resource_id"),
		GrantID:     c.Query("grant_id"),
		RequestID:   c.Query("request_id"),
		SessionID:   c.Query("session_id"),
		From:        from,
		To:          to,
		Search:      c.Query("q"),
		Page:        page,
		PageSize:    size,
	})
	if err != nil {
		h.logger.Error("admin.audit.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch audit log")
		return
	}
	response.Success(c, paged(rows, total, page, size, "events"), "Audit events fetched")
}

// VerifyAudit handles GET /api/v1/pam/admin/audit/verify
// Recomputes the hash chain and reports the first break, if any.
func (h *AdminHandler) VerifyAudit(c *gin.Context) {
	limit := 5000
	if v := c.Query("limit"); v != "" {
		if n, err := parseIntSafe(v); err == nil {
			limit = n
		}
	}
	res, err := h.audit.VerifyChain(limit)
	if err != nil {
		h.logger.Error("admin.audit.verify.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to verify audit chain")
		return
	}
	msg := "Audit chain intact"
	if !res.Valid {
		msg = "AUDIT CHAIN BROKEN — records were altered or deleted"
	}
	response.Success(c, gin.H{"verification": res}, msg)
}

// ListBreakglass handles GET /api/v1/pam/admin/breakglass
// Emergency requests and their grants in one payload for the console panel.
func (h *AdminHandler) ListBreakglass(c *gin.Context) {
	page, size := pagingFrom(c)

	requests, total, err := h.jit.ListRequests(services.RequestFilter{
		RequestType: models.JITTypeBreakglass,
		Status:      c.Query("status"),
		Page:        page,
		PageSize:    size,
	})
	if err != nil {
		h.logger.Error("admin.breakglass.list.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch break-glass requests")
		return
	}

	bg := true
	grants, _, err := h.jit.ListGrants(services.GrantFilter{
		IsBreakglass: &bg,
		Page:         1,
		PageSize:     size,
	})
	if err != nil {
		h.logger.Error("admin.breakglass.grants.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to fetch break-glass grants")
		return
	}

	payload := paged(requests, total, page, size, "requests")
	payload["grants"] = grants
	response.Success(c, payload, "Break-glass activity fetched")
}

// BreakglassReport handles GET /api/v1/pam/admin/breakglass/:grant_id/report
// The auto-generated emergency-access report an auditor asks for.
func (h *AdminHandler) BreakglassReport(c *gin.Context) {
	report, err := h.jit.BuildBreakglassReport(c.Param("grant_id"))
	if err != nil {
		response.Error(c, http.StatusNotFound, "Break-glass grant not found")
		return
	}
	response.Success(c, gin.H{"report": report}, "Break-glass report generated")
}

// Stats handles GET /api/v1/pam/admin/stats — dashboard tiles.
func (h *AdminHandler) Stats(c *gin.Context) {
	pending, err := h.jit.PendingApprovalCount()
	if err != nil {
		h.logger.Error("admin.stats.pending.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to compute stats")
		return
	}
	activeSessions, err := h.res.CountActiveSessions()
	if err != nil {
		h.logger.Error("admin.stats.sessions.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to compute stats")
		return
	}
	resources, err := h.res.CountResources()
	if err != nil {
		h.logger.Error("admin.stats.resources.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to compute stats")
		return
	}

	_, activeGrants, err := h.jit.ListGrants(services.GrantFilter{ActiveOnly: true, PageSize: 1})
	if err != nil {
		h.logger.Error("admin.stats.grants.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to compute stats")
		return
	}
	bg := true
	_, activeBreakglass, err := h.jit.ListGrants(services.GrantFilter{ActiveOnly: true, IsBreakglass: &bg, PageSize: 1})
	if err != nil {
		h.logger.Error("admin.stats.breakglass.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to compute stats")
		return
	}

	response.Success(c, gin.H{
		"pending_approvals":        pending,
		"active_sessions":          activeSessions,
		"active_grants":            activeGrants,
		"active_breakglass_grants": activeBreakglass,
		"active_resources":         resources,
		"generated_at":             time.Now().UTC(),
	}, "PAM statistics fetched")
}

// ──────────────────────────────────────────────────────────────────────────
// ACTIONS (attributable writes)
// ──────────────────────────────────────────────────────────────────────────

// KillSession handles POST /api/v1/pam/admin/actions/sessions/:id/kill
func (h *AdminHandler) KillSession(c *gin.Context) {
	var body struct {
		Reason string `json:"reason"`
	}
	_ = c.ShouldBindJSON(&body)
	if strings.TrimSpace(body.Reason) == "" {
		response.Error(c, http.StatusBadRequest, "A reason is required for the audit record")
		return
	}

	actorID, actorName := middleware.AdminIdentityFromContext(c)
	sessionID := c.Param("id")

	session, err := h.res.GetSession(sessionID)
	if err != nil {
		response.Error(c, http.StatusNotFound, "Session not found")
		return
	}
	if err := h.res.KillSession(sessionID, actorID, body.Reason); err != nil {
		h.logger.Error("admin.session.kill.fail", zap.Error(err))
		response.Error(c, http.StatusInternalServerError, "Failed to kill session")
		return
	}

	grantID := ""
	if session.GrantID != nil {
		grantID = *session.GrantID
	}
	h.audit.Write(services.AuditEntry{
		ActorUserID:   actorID,
		ActorUsername: actorName,
		ActorType:     "IAM",
		Action:        models.AuditSessionKilled,
		Severity:      models.AuditSeverityCritical,
		ResourceType:  session.ResourceType,
		ResourceID:    session.ResourceID,
		ResourceName:  session.ResourceName,
		SessionID:     session.ID,
		GrantID:       grantID,
		SourceIP:      c.ClientIP(),
		Details: map[string]interface{}{
			"reason":      body.Reason,
			"target_user": session.Username,
		},
	})

	response.Success(c, gin.H{"session_id": sessionID}, "Session terminated")
}

// ──────────────────────────────────────────────────────────────────────────
// QUERY HELPERS
// ──────────────────────────────────────────────────────────────────────────

// boolQuery returns nil when the param is absent, so "unset" and "false" are
// distinguishable in filters.
func boolQuery(c *gin.Context, key string) *bool {
	v, ok := c.GetQuery(key)
	if !ok || v == "" {
		return nil
	}
	b := v == "true" || v == "1"
	return &b
}

// timeRange parses RFC3339 `from` / `to` query params.
func timeRange(c *gin.Context) (*time.Time, *time.Time) {
	var from, to *time.Time
	if v := c.Query("from"); v != "" {
		if t, err := time.Parse(time.RFC3339, v); err == nil {
			from = &t
		}
	}
	if v := c.Query("to"); v != "" {
		if t, err := time.Parse(time.RFC3339, v); err == nil {
			to = &t
		}
	}
	return from, to
}

func parseIntSafe(v string) (int, error) {
	return strconv.Atoi(v)
}
