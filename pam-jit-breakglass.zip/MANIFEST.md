# Delivery manifest — JIT / time-boxed access / break-glass / PEP / IAM admin API

Extract this archive **over your repository root** (`PAM-Backend-Pranav/`). Paths match the
existing project structure exactly, so files land in place.

```bash
cd C:\Users\Pranav\Desktop\PAM-Backend-Pranav
# unzip -o pam-jit-breakglass.zip
go build ./...
go run cmd/pam-api/main.go
```

`go.mod` and `go.sum` are **not** included — this change adds **zero new dependencies**.
No `go get` / `go mod tidy` needed.

---

## NEW files (11)

| Path | Purpose |
|---|---|
| `internal/models/jit.go` | `pam_jit_requests` + `pam_access_grants` |
| `internal/models/audit.go` | `pam_audit_log` (hash-chained) + `pam_session_recordings` |
| `internal/services/audit_service.go` | Tamper-evident append + chain verification |
| `internal/services/jit_service.go` | Request → approve/deny → grant → revoke; break-glass |
| `internal/services/session_service.go` | Grant-bound session lifecycle, kill-by-grant, reads |
| `internal/services/sweeper.go` | Auto-revoke worker (native ticker, no cron dependency) |
| `internal/middleware/grant.go` | `RequireActiveGrant` — PEP layer 2 (JIT) |
| `internal/middleware/admin.go` | `IAMAdminIdentity` — attributes console writes to a human |
| `internal/api/handlers/jit_handler.go` | JIT + break-glass + grant endpoints |
| `internal/api/handlers/session_handler.go` | Session start / end / mine |
| `internal/api/handlers/admin_handler.go` | IAM console read-only + action endpoints |

## UPDATED files (6)

| Path | What changed |
|---|---|
| `cmd/pam-api/main.go` | AutoMigrate 4 new models (now fatal on error); wire audit/JIT services, sweeper, 3 handlers; ~30 new routes; sweeper stopped before HTTP drain on shutdown |
| `internal/config/config.go` | New `JITConfig`; IAM retries/backoff/cache/grant/revoke/alert fields; `normaliseJIT()` clamps unsafe values |
| `pkg/iamclient/client.go` | Rewritten: context + timeouts, bounded retries (network/5xx only), optional ALLOW-only cache (default **off**), connection pooling, `PushGrant`/`RevokeGrant`/`SendAlert`. **`CheckAuthz(req)` signature preserved** — existing `authz.go` is untouched and still compiles |
| `internal/models/resource.go` | `PAMResource.requires_jit`, `always_record`; `VaultEntry.is_breakglass`, `breakglass_note`; `ConnectionSession.grant_id`, `jit_request_id`, `is_breakglass`, `recording_required`, `recording_id`. All default false/NULL → **existing rows behave exactly as before** |
| `internal/services/resource_service.go` | **Bugfix:** `EndSession` duration was `now.Sub(time.Time{})` (~6.4×10¹⁰ s on every row) → now computed in SQL from `started_at`. **Bugfix:** `KillSession` never set duration → now does. Kill semantics documented |
| `configs/config.yaml` | `jit:` block + new `iam:` keys, all commented |

## SUPPORTING (2)

| Path | Purpose |
|---|---|
| `docs/JIT_BREAKGLASS_FLOW.md` | Investigation, gap analysis, research findings with platform citations, architecture, full API reference, env vars, curl walkthrough, **7 known limitations** |
| `cmd/e2e/main.go` | 60-assertion verification harness. Refuses to run without `PAM_E2E_CONFIRM=yes-destroy-my-data` + `PAM_E2E_DSN`, because it TRUNCATEs PAM tables. Delete it if you do not want it in the repo |

---

## Files deliberately NOT touched

`internal/middleware/auth.go`, `internal/middleware/authz.go`, `internal/services/auth_service.go`,
`internal/api/handlers/auth_handler.go`, `internal/api/handlers/resource_handler.go`,
`internal/models/user.go`, `internal/models/user_session.go`, `internal/models/pam_mfa.go`,
`internal/database/postgres.go`, `internal/response/response.go`, `pkg/jwt`, `pkg/crypto`,
`pkg/argon2`, `pkg/totp`, `go.mod`, `go.sum`, `Makefile`.

---

## Verification performed before delivery

| Check | Result |
|---|---|
| `go build ./...` (Go 1.22.2) | pass |
| `go vet`, `gofmt` on all new files | clean |
| 44-route table on a real `gin.Engine` | no conflicts |
| `AutoMigrate` of all 8 models on PostgreSQL 16 | pass |
| 60-assertion end-to-end harness | all passed |
| 5 concurrent sweepers × 5 passes over 40 expired grants | 40 expired, 0 duplicates, 0 errors |
| Live boot: health, admin token gate (401), admin-identity gate (400), JWT gate (401), audit verify | pass |
| SIGTERM graceful shutdown (sweeper → HTTP drain) | pass |
| Audit tamper detection (mutate one row) | break caught at exact `seq` |

---

## Before production — three gaps

1. **Write SQL migrations** `migrations/007_create_jit_tables.sql` and `008_create_audit_tables.sql`.
   `AutoMigrate` runs only when `PAM_SERVER_ENV != production`, so production would start against a
   schema missing every table added here.
2. **Set `PAM_IAM_ALERT_URL`.** Without an alert sink, CRITICAL break-glass events land only in the
   audit table — the 15-minute delay exists so a human can intervene, and nobody is being told.
3. **Hook `RotateCredential` into `afterGrantTerminated`.** CyberArk and Delinea both rotate the
   break-glass password on check-in. The function exists; it is not wired.

Full limitation list (including why session kill is logical rather than physical) is in
`docs/JIT_BREAKGLASS_FLOW.md` §8.
