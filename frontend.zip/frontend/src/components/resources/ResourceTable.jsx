import { Link } from 'react-router-dom'
import {
  KeyRound,
  Video,
  Trash2,
  ExternalLink,
  KeySquare,
} from 'lucide-react'

import {
  DataTable,
  Th,
  SortTh,
  Tr,
  Td,
  Trunc,
  RowActions,
} from '../ui/grid'

import {
  Menu,
  RowMenu,
  MenuItem,
  MenuLabel,
} from '../ui/menu'

import { StatusDot, Meta } from '../ui/bits'
import { ResourceTypeIcon } from './ResourceTypeIcon'
import { resourceTypeLabel } from './ResourceCard'
import { ConnectMenuItems } from './ConnectMenuItems'

// ---------------------------------------------------------------------------
// Resources grid
// ---------------------------------------------------------------------------

export const RESOURCE_COLUMNS = [
  { key: 'name', label: 'Resource', required: true },
  { key: 'resource_type', label: 'Type' },
  { key: 'host', label: 'Host' },
  { key: 'port', label: 'Port', defaultHidden: true },
  { key: 'controls', label: 'Controls' },
  { key: 'credential', label: 'Credential' },
]

// ---------------------------------------------------------------------------
// Columns differ by role.
//
// Admin:
//   Resource | Type | Host | Port | Controls | Credential | Actions
//
// Normal user:
//   Resource | Type | Actions
//
// Host, Port, Controls, and Credential are hidden for normal users.
// ---------------------------------------------------------------------------

export function resourceColumnsFor(isAdmin) {
  if (isAdmin) return RESOURCE_COLUMNS

  return RESOURCE_COLUMNS.filter(
    (c) =>
      c.key !== 'host' &&
      c.key !== 'port' &&
      c.key !== 'controls' &&
      c.key !== 'credential'
  )
}

// ---------------------------------------------------------------------------
// Primary row action
// ---------------------------------------------------------------------------

const ACTION_CLASS =
  'whitespace-nowrap rounded px-1 py-0.5 text-sm font-semibold text-accent transition-colors hover:text-accent-hover hover:underline'

function RowAction({
  resource,
  onConnect,
  onRequestAccess,
  onOpenCli,
  access,
  isAdmin,
}) {
  if (!resource.is_active) {
    return <Meta>Inactive</Meta>
  }

  // Pending / partial access request
  if (
    access?.state === 'pending' ||
    access?.state === 'partial'
  ) {
    return (
      <span
        className="whitespace-nowrap text-sm text-warn"
        title={access.title}
      >
        {access.state === 'partial'
          ? 'Awaiting 2nd approval'
          : 'Request pending'}
      </span>
    )
  }

  const gated =
    resource.requires_jit && !access?.canConnect

  if (gated) {
    return (
      <button
        type="button"
        onClick={() => onRequestAccess(resource)}
        className={ACTION_CLASS}
      >
        Request access
      </button>
    )
  }

  // Normal users get the Connect menu.
  if (!isAdmin) {
    return (
      <Menu
        label={`Connect to ${resource.name}`}
        width="w-60"
        trigger={
          <span className={ACTION_CLASS}>
            Connect
          </span>
        }
      >
        <ConnectMenuItems
          resource={resource}
          onRequestAccess={onRequestAccess}
          onOpenCli={onOpenCli}
        />
      </Menu>
    )
  }

  // Admins connect directly.
  return (
    <button
      type="button"
      onClick={() => onConnect(resource)}
      className={ACTION_CLASS}
    >
      Connect
    </button>
  )
}

// ---------------------------------------------------------------------------
// Resource table
// ---------------------------------------------------------------------------

export function ResourceTable({
  rows,
  sort,
  onSort,
  visibleColumns,
  onPeek,
  onConnect,
  onRequestAccess,
  onStoreCredential,
  onOpenCli,
  onDelete,
  isAdmin,
  accessFor,
  focusedId,
}) {
  // A column must:
  // 1. Be allowed for the current role.
  // 2. Be enabled in the user's visible-column preferences.
  const allowed = new Set(
    resourceColumnsFor(isAdmin).map((c) => c.key)
  )

  const show = (key) =>
    allowed.has(key) &&
    (!visibleColumns || visibleColumns.includes(key))

  return (
    <DataTable
      className={
        isAdmin
          ? 'min-w-[60rem]'
          : 'w-full min-w-0 table-fixed'
      }
    >
      {/* ----------------------------------------------------------------- */}
      {/* Column sizing                                                     */}
      {/* ----------------------------------------------------------------- */}

      <colgroup>
        {/* Resource */}
        {show('name') && (
          <col
            className={
              isAdmin
                ? 'w-[17rem]'
                : 'w-auto'
            }
          />
        )}

        {/* Type */}
        {show('resource_type') && (
          <col
            className={
              isAdmin
                ? 'w-[9rem]'
                : 'w-[10rem]'
            }
          />
        )}

        {/* Host */}
        {show('host') && (
          <col className="w-[17rem]" />
        )}

        {/* Port */}
        {show('port') && (
          <col className="w-[5.5rem]" />
        )}

        {/* Controls */}
        {show('controls') && (
          <col className="w-[7.5rem]" />
        )}

        {/* Credential */}
        {show('credential') && (
          <col className="w-[8.5rem]" />
        )}

        {/* Actions */}
        <col
          className={
            isAdmin
              ? 'w-[11rem]'
              : 'w-[7rem]'
          }
        />
      </colgroup>

      {/* ----------------------------------------------------------------- */}
      {/* Header                                                             */}
      {/* ----------------------------------------------------------------- */}

      <thead>
        <tr>
          {show('name') && (
            <SortTh
              columnKey="name"
              sort={sort}
              onSort={onSort}
              sticky
              edge
            >
              Resource
            </SortTh>
          )}

          {show('resource_type') && (
            <SortTh
              columnKey="resource_type"
              sort={sort}
              onSort={onSort}
            >
              Type
            </SortTh>
          )}

          {show('host') && (
            <SortTh
              columnKey="host"
              sort={sort}
              onSort={onSort}
            >
              Host
            </SortTh>
          )}

          {show('port') && (
            <SortTh
              columnKey="port"
              sort={sort}
              onSort={onSort}
              align="right"
            >
              Port
            </SortTh>
          )}

          {show('controls') && (
            <Th>Controls</Th>
          )}

          {show('credential') && (
            <SortTh
              columnKey="vault_entry_id"
              sort={sort}
              onSort={onSort}
            >
              Credential
            </SortTh>
          )}

          {/* Actions header */}
          <Th
            align="right"
            className="w-[7rem] whitespace-nowrap"
          >
            <span className="sr-only">
              Actions
            </span>
          </Th>
        </tr>
      </thead>

      {/* ----------------------------------------------------------------- */}
      {/* Body                                                               */}
      {/* ----------------------------------------------------------------- */}

      <tbody>
        {rows.map((r) => (
          <Tr
            key={r.id}
            onClick={
              isAdmin
                ? () => onPeek(r)
                : undefined
            }
            className={
              focusedId === r.id
                ? 'ring-1 ring-inset ring-accent/40'
                : undefined
            }
          >
            {/* ----------------------------------------------------------- */}
            {/* Resource                                                      */}
            {/* ----------------------------------------------------------- */}

            {show('name') && (
              <Td
                sticky
                edge
                className="min-w-0"
              >
                <div className="flex min-w-0 items-center gap-2.5">
                  <ResourceTypeIcon
                    type={r.resource_type}
                    className="h-4 w-4 flex-none text-tertiary"
                  />

                  <div className="min-w-0 flex-1">
                    {isAdmin ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          onPeek(r)
                        }}
                        title={r.name}
                        className="block max-w-full truncate text-left text-sm font-medium text-primary transition-colors hover:text-accent"
                      >
                        {r.name}
                      </button>
                    ) : (
                      <span
                        title={r.name}
                        className="block max-w-full truncate text-sm font-medium text-primary"
                      >
                        {r.name}
                      </span>
                    )}
                  </div>

                  {!r.is_active && (
                    <Meta>
                      inactive
                    </Meta>
                  )}
                </div>
              </Td>
            )}

            {/* ----------------------------------------------------------- */}
            {/* Type                                                          */}
            {/* ----------------------------------------------------------- */}

            {show('resource_type') && (
              <Td className="min-w-0">
                <Trunc
                  value={resourceTypeLabel(
                    r.resource_type
                  )}
                  muted
                />
              </Td>
            )}

            {/* ----------------------------------------------------------- */}
            {/* Host                                                          */}
            {/* ----------------------------------------------------------- */}

            {show('host') && (
              <Td className="min-w-0">
                <Trunc
                  value={
                    isAdmin && r.port
                      ? `${r.host}:${r.port}`
                      : r.host
                  }
                  title={
                    r.database_name
                      ? `${r.host} (${r.database_name})`
                      : undefined
                  }
                  mono
                />
              </Td>
            )}

            {/* ----------------------------------------------------------- */}
            {/* Port                                                          */}
            {/* ----------------------------------------------------------- */}

            {show('port') && (
              <Td align="right">
                <span className="whitespace-nowrap font-mono text-xs text-secondary">
                  {r.port || '-'}
                </span>
              </Td>
            )}

            {/* ----------------------------------------------------------- */}
            {/* Controls                                                      */}
            {/* ----------------------------------------------------------- */}

            {show('controls') && (
              <Td>
                <span className="flex items-center gap-3 whitespace-nowrap">
                  {r.requires_jit && (
                    <span
                      className="inline-flex items-center gap-1 text-xs text-warn"
                      title="Needs an approved just in time request before you can connect"
                    >
                      <KeyRound
                        className="h-3.5 w-3.5"
                        strokeWidth={1.75}
                      />
                      JIT
                    </span>
                  )}

                  {(r.always_record ||
                    r.recording_required) && (
                    <span
                      className="inline-flex items-center gap-1 text-xs text-secondary"
                      title="Every session on this resource is recorded"
                    >
                      <Video
                        className="h-3.5 w-3.5"
                        strokeWidth={1.75}
                      />
                      Rec
                    </span>
                  )}

                  {!r.requires_jit &&
                    !r.always_record &&
                    !r.recording_required && (
                      <Meta>none</Meta>
                    )}
                </span>
              </Td>
            )}

            {/* ----------------------------------------------------------- */}
            {/* Credential                                                     */}
            {/* ----------------------------------------------------------- */}

            {show('credential') && (
              <Td>
                {r.vault_entry_id ? (
                  <StatusDot
                    tone="ok"
                    label="Stored"
                  />
                ) : (
                  <StatusDot
                    tone="warn"
                    label="Missing"
                    title="No credential is stored for this resource"
                  />
                )}
              </Td>
            )}

            {/* ----------------------------------------------------------- */}
            {/* Actions                                                        */}
            {/* ----------------------------------------------------------- */}

            <Td
              align="right"
              className="whitespace-nowrap"
            >
              <RowActions>
                <RowAction
                  resource={r}
                  isAdmin={isAdmin}
                  onConnect={onConnect}
                  onRequestAccess={
                    onRequestAccess
                  }
                  onOpenCli={onOpenCli}
                  access={accessFor?.(r)}
                />

                {isAdmin && (
                  <RowMenu
                    label={`Actions for ${r.name}`}
                  >
                    <MenuItem icon={ExternalLink}>
                      <Link
                        to={`/resources/${r.id}`}
                        className="block"
                        onClick={(e) =>
                          e.stopPropagation()
                        }
                      >
                        Open resource
                      </Link>
                    </MenuItem>

                    <MenuLabel>
                      Administration
                    </MenuLabel>

                    <MenuItem
                      icon={KeySquare}
                      onClick={() =>
                        onStoreCredential(r)
                      }
                    >
                      {r.vault_entry_id
                        ? 'Replace credential'
                        : 'Store a credential'}
                    </MenuItem>

                    <MenuItem
                      icon={Trash2}
                      danger
                      onClick={() =>
                        onDelete(r)
                      }
                    >
                      Delete resource
                    </MenuItem>
                  </RowMenu>
                )}
              </RowActions>
            </Td>
          </Tr>
        ))}
      </tbody>
    </DataTable>
  )
}
