import { http } from '../lib/http'

// POST /api/v1/auth/login
// Returns either a full session ({access_token, refresh_token, expires_at,
// user...}) or an MFA challenge ({challenge_token}), auth_service.go's
// LoginResult omits fields with `omitempty`, so the caller must check which
// shape came back rather than assuming access_token is always present.
export async function login(identifier, password) {
  const { data } = await http.post('/api/v1/auth/login', { identifier, password })
  return data.data
}

export async function verifyMfa(challengeToken, code) {
  const { data } = await http.post('/api/v1/auth/mfa/verify', {
    challenge_token: challengeToken,
    code,
  })
  return data.data
}

/**
 * A backup code goes to its OWN endpoint, not to /mfa/verify.
 *
 * /mfa/verify validates a TOTP code against the enrolled device's shared
 * secret; a recovery code is a stored single-use hash and has nothing to do
 * with the device. Sending one to /mfa/verify does not fail because the code
 * is wrong, it fails because the endpoint was never asked the right question,
 * which is exactly why every backup code was being rejected.
 *
 * Field name matters too: this route binds `backup_code`, not `code`, and
 * rejects the body with 400 if it is missing.
 */
export async function recoverWithBackupCode(challengeToken, backupCode) {
  const { data } = await http.post('/api/v1/auth/mfa/recover', {
    challenge_token: challengeToken,
    backup_code: backupCode,
  })
  return data.data
}

export async function me(signal) {
  const { data } = await http.get('/api/v1/auth/me', { signal })
  return data.data
}

export async function logout() {
  const { data } = await http.post('/api/v1/auth/logout')
  return data.data
}

export async function mfaSetupInitiate() {
  const { data } = await http.post('/api/v1/auth/mfa/setup/initiate')
  return data.data // { mfa_device_id, secret, qr_code_base64 }
}

export async function mfaSetupVerify(mfaDeviceId, code) {
  const { data } = await http.post('/api/v1/auth/mfa/setup/verify', {
    mfa_device_id: mfaDeviceId,
    code,
  })
  return data.data // { backup_codes, message }
}

// Fresh single-use recovery codes, voiding the previous set. Behind
// RequireMFA on the server: only a session that actually presented a second
// factor may mint new recovery material.
export async function regenerateBackupCodes() {
  const { data } = await http.post('/api/v1/auth/mfa/backup-codes/regenerate')
  return data.data // { backup_codes, count }
}
