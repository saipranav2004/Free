# pam-agent — enterprise multi-tool + installer platform: what changed

Scope of this round of work: turn `pam-agent` from "supports 3 hardcoded
resource types, ship the binary yourself" into an installable,
enterprise-ready platform that (a) tries a GUI fallback when the obvious CLI
tool isn't installed, (b) supports 9 resource types end to end, (c) can be
handed to a client as a single one-click setup script or a real OS package,
and (d) logs its own behavior properly. No change here weakens the existing
security model (Ed25519 device identity, one-time launch tokens, the
backend still resolving every credential fresh at launch time) — see
README.md's "Security model" section, unchanged in substance.

## New packages

- **`internal/logging`** — leveled logger (stderr + `<config dir>/logs/
  agent.log`, simple size-based rotation) built entirely on `log/slog`
  (stdlib since Go 1.21). Zero new dependencies. Wired into every
  subcommand in `cmd/pam-agent/main.go`; verbosity controlled by
  `PAM_AGENT_LOG_LEVEL` (debug/info/warn/error, default info).
- **`internal/discovery`** — finds locally-installed tools via PATH, the
  Windows `App Paths` registry (shells out to `reg.exe`, no registry
  package linked), OS-specific absolute install-path globs (with
  version-folder wildcard support), and macOS `.app` bundle names. Fully
  unit-tested (`internal/discovery/discovery_test.go`), including the
  registry-output parser tested at the string level so it runs on any OS.

## Reworked: `internal/launcher`

- `Template` (one fixed tool per resource type) → `Candidate` (an ordered
  list per resource type, each with its own `Kind` — `cli`/`gui`/`browser`
  — and its own `discovery.Spec`). `launch-templates.json`'s schema changed
  from `map[string]Template` to `map[string][]Candidate` accordingly —
  **this is a breaking config-file format change**; a `launch-templates.json`
  from before this round of work will fail to parse and needs regenerating
  (delete it and let `pam-agent launch` recreate the new default, or hand-
  edit to the new array-of-candidates shape).
- `SelectAndBuildCommand` (replacing the old direct `BuildCommand` call in
  `main.go`) walks a resource type's candidate list, reordered first by any
  `preferred_tool` hint in the resource's `extra_config` (soft hint only —
  see README's "Multi-tool candidates & discovery"), and returns the first
  one whose tool is actually usable — a `browser`-kind candidate always is;
  anything else only if `discovery.Locate` finds it. Fully unit-tested
  (`internal/launcher/templates_test.go`): fallback behavior, the
  nothing-found error naming every tried candidate, `preferred_tool`
  reordering and its "still falls back if unavailable" property, and
  browser-kind selection/`console_url` validation.
- New credential injection modes: `clickhouse_config_file` (temp XML config
  for `clickhouse-client`, properly escaped —
  `internal/launcher/credential.go`) and `pgadmin_preseed` (best-effort
  host/port/database/username-only preseed for pgAdmin4 via its own
  `--load-servers` mechanism — `internal/launcher/pgadmin_preseed.go`, never
  the password). Both unit-tested for exact content, including that the
  pgAdmin4 preseed file provably never contains the password.
- New `browser.go` (`OpenBrowser`) — opens the OS default browser to a URL;
  the entire implementation of the new `browser` launch kind used by MinIO
  Console/Qdrant dashboard/Langfuse/Metabase.
- Per-OS `Spawn` (`spawn_windows.go`/`spawn_darwin.go`/`spawn_linux.go`) now
  branches on `Mode`: `"gui"` execs the tool directly (no terminal window,
  non-blocking) instead of always going through the terminal/`cmd start`
  path that only ever suited CLI tools before. macOS's GUI path additionally
  handles an `.app`-bundle-only discovery hit via `open -a`.

## `internal/apiclient`

- `ResolvedLaunch` gained a `ConsoleURL` field, populated from the backend's
  `console_url` (already existed on `PAMResource`/`ConnectionInfo` — no
  backend schema change, just wiring it through the one response that was
  missing it).

## `cmd/pam-agent/main.go`

- Logging wired in for every subcommand (`install`/`uninstall`/`pair`/
  `launch`/`devices`), not just errors — install/pair/launch each log their
  key milestones (start, resolved, candidate selected, spawn result,
  session-end report) per the "add proper loggers wherever required"
  requirement.
- `cmdLaunch` rewritten around `SelectAndBuildCommand`; handles the new
  `browser` mode (calls `OpenBrowser`, skips the temp-file cleanup/spawn
  path entirely) and the pgAdmin4 preseed pre-step (`RunPgAdminPreseed`,
  best-effort, logged not fatal).

## New: `install/`

- `install/linux/build-deb.sh` — builds a real `.deb` via `dpkg-deb`. Places
  only the binary at `/usr/bin/pam-agent`; deliberately does NOT try to run
  `pam-agent install`/`pair` from the root-run `postinst`, since both are
  per-user operations (see `internal/register`'s per-OS `Register`
  functions) — root doing them would silently register for the wrong
  account. **Built, inspected, installed, and removed for real** in this
  sandbox (see "Verification" below).
- `install/generate-onboarding-script.sh` + `install/templates/
  onboard-unix.sh.tmpl` / `onboard-windows.ps1.tmpl` — produces a
  self-contained, single-file "one-click setup" script per OS: embeds the
  actual `pam-agent` binary (base64) plus a one-time pairing code, so
  running it does `install` + `pair` in one step, no package manager, no
  admin rights, on Linux/macOS/Windows alike. This is the concrete
  implementation of "installer embeds a one-time setup token so
  install+pair happen automatically in one step." **Generated and actually
  run end-to-end** against a mock PAM server (see "Verification" below).
  Intended integration: the PAM backend's "Download agent installer" UI
  action calls `POST /api/v1/pam/agent/pair/init` with a longer
  `ttl_minutes` (see the backend changes below), then invokes this script
  with that code and serves the result as a download.
- `install/windows/pam-agent.wxs` + `build-msi.ps1` — WiX v3 source for a
  **per-user** MSI (`InstallScope="perUser"`, `ALLUSERS=2`) with a custom
  UI dialog collecting server URL/pairing code/device name and a deferred,
  impersonated custom action running `install`+`pair` automatically. Complete,
  reviewed source; **not build-verified** — no WiX Toolset or Windows
  machine in this sandbox. The per-user install scope is a deliberate
  choice, not a default left alone: a per-machine MSI's deferred custom
  actions run as SYSTEM even with `Impersonate="yes"` set, which would
  silently register the URL handler for the wrong (SYSTEM) account instead
  of the actual operator — documented at length in the `.wxs` file itself.
- `install/macos/build-pkg.sh` — `pkgbuild`/`productbuild` source producing
  a real `.pkg`, with a `postinstall` script that resolves the actual
  logged-in console user (`stat -f%Su /dev/console`) and runs `install`/
  tells the operator to pair as THAT user rather than as root. Complete,
  reviewed source; **not build-verified** — no macOS machine, Xcode
  tooling, or `pkgbuild`/`productbuild` binaries in this sandbox.

## Backend (`pam-verify`): small, targeted changes

- `internal/services/agent_service.go`: `InitPairing(userID string)` →
  `InitPairing(userID string, ttl time.Duration)`. A zero `ttl` keeps the
  existing 5-minute default; a caller-requested TTL above the new
  `pairingCodeMaxTTL` (24h) is silently capped, not rejected. This exists
  specifically so an installer-embedded pairing code (see
  `generate-onboarding-script.sh` above) can outlive the default 5 minutes
  — a code baked into a downloadable setup script needs to survive
  however long it sits before the operator actually runs it.
- `internal/api/handlers/agent_handler.go`:
  - `PairInit` now accepts an optional JSON body `{"ttl_minutes": N}` — a
    plain POST with no body still works exactly as before (falls back to
    the zero-value default). This is the only new surface exposed to
    callers; there is no way to request an unbounded TTL.
  - `ResolveLaunch`'s response gained a `console_url` field (the data
    already existed on `ConnectionInfo`/`PAMResource` — this just adds it to
    the explicit `gin.H` map that response is built from, matching
    `apiclient.ResolvedLaunch`'s new `ConsoleURL` field on the agent side).
  - No other behavior changed; the "explicit map, not a struct marshal" note
    on this handler (so `Password` — tagged `json:"-"` on `ConnectionInfo`
    — can be deliberately included) still applies unchanged.
- No new backend files, no schema migration, no new route registered.

## Verification performed

The zero-dependency `pam-agent` module has no network-proxy limitation
(unlike the `gin`/`gorm`-based backend — see below), so it got the full
treatment again:

```
cd pam-agent
gofmt -l .                                    # clean
go build ./... && go vet ./...                # clean, native linux/amd64
go test ./...                                 # all packages pass, including
                                               # every new *_test.go file
GOOS=windows GOARCH=amd64 go build/vet ./...  # clean
GOOS=darwin  GOARCH=amd64 go build/vet ./...  # clean
GOOS=darwin  GOARCH=arm64 go build/vet ./...  # clean
```

Functional end-to-end tests against the same mock PAM server used before
(real Ed25519 keygen/sign/verify, no mocked crypto), extended with new
resource fixtures for this round:

- **Candidate fallback on a real machine**: `redis`/`postgresql` correctly
  selected `redis-cli`/`psql` (both genuinely installed on the build
  machine, confirmed via `which`); `mongodb`/`clickhouse`/`oracle` (nothing
  installed for any of them) correctly failed with
  `no installed tool found for resource type "X" — tried: a, b, c`, naming
  every candidate.
- **`preferred_tool` soft-hint fallback**: a resource with
  `extra_config = {"preferred_tool": "pgadmin4"}` was confirmed (via
  `PAM_AGENT_LOG_LEVEL=debug`) to try `pgadmin4` first
  (`launch.candidate.not_found candidate=pgadmin4`), then correctly fall
  back to `psql` — proving the hint reorders but never hard-requires.
- **Browser kind**: a `minio` resource with `console_url` set correctly
  selected the browser candidate and invoked `xdg-open` (which itself fails
  in this headless sandbox with no browser/display — expected and
  documented, exactly like `xterm` failing for the same reason on the CLI
  paths, not a bug in the selection/dispatch logic being tested). A `minio`
  resource with `console_url` **unset** correctly errored with "an admin
  needs to set console_url" *before* attempting to open anything.
- **pgAdmin4 preseed**: using `fake_tool.sh` (a shell stand-in that logs its
  own argv/env/file-arg contents) wired in as the `pgadmin4` candidate via a
  temporary `launch-templates.json` override, confirmed the `--load-servers`
  pre-step really ran with a JSON file containing exactly
  `{Host, Port, MaintenanceDB, Username}` and **no password field anywhere**,
  and that the GUI itself was launched afterward (`waited=false`, matching
  the documented non-blocking GUI behavior).
- **ClickHouse config file**: covered by a permanent unit test
  (`TestWriteClickhouseConfigFile`) rather than the mock-server flow, since
  `clickhouse-client` isn't installed in this sandbox and the "cli" mode's
  terminal-launch path (`xterm`) can't be observed from outside in a
  headless sandbox anyway — the unit test asserts the written file is valid
  XML, the credential round-trips exactly through XML escaping (tested with
  a password containing `<`, `>`, and `&`), and that the raw file never
  contains the unescaped password string.
- **One-click onboarding script, full end-to-end**: built a real
  `pam-agent` binary, ran
  `install/generate-onboarding-script.sh linux <binary> http://127.0.0.1:8080 TESTCODE ci-test-laptop 60`
  to produce a real ~209K-line self-extracting script, then ran that script
  (nothing else) in a completely clean, empty `$HOME`:
  - the extracted `~/.local/bin/pam-agent` is byte-identical to the
    original binary (`diff` — the base64 round-trip lost nothing)
  - `pam-agent install` ran automatically and wrote a correct
    `pam-agent.desktop` file
  - `pam-agent pair --code TESTCODE ...` ran automatically and completed a
    real Ed25519 pairing handshake — confirmed by `pam-agent devices`
    listing the paired server and device ID afterward
  - all of this from ONE command, no manual follow-up
- **Linux `.deb`**: built with `install/linux/build-deb.sh 1.0.0 amd64`,
  inspected with `dpkg-deb --info`/`dpkg -c` (correct control metadata,
  correct file list, correct `postinst`/`prerm` scripts), then really
  installed with `dpkg -i` (binary landed at `/usr/bin/pam-agent`, ran
  successfully, `postinst` printed the correct next-steps message) and
  removed with `dpkg -r` (correct `prerm` warning, binary gone afterward).

Backend (`pam-verify`) changes: same disclosed limitation as the previous
round — the Go module proxy is unreachable from this sandbox, so
`gin`/`gorm`-based `go build` isn't possible here. Both edited files
(`agent_service.go`, `agent_handler.go`) are `gofmt`-clean, and were
manually reviewed for signature consistency (confirmed the only call site
of `InitPairing` — the one in `agent_handler.go` — was updated to match the
new signature). **Please run `go build ./... && go vet ./...` on the
backend yourself** before deploying, same recommendation as last time.

## Known follow-ups (called out, not silently skipped)

- The Windows `.msi` and macOS `.pkg` installer sources are complete but
  not build-verified — see README's "Known limitations" for exactly what to
  check on a real build.
- `launch-templates.json`'s schema change (array-of-candidates instead of a
  single template) is a breaking change for anyone who hand-edited the old
  file — see "Reworked: internal/launcher" above.
- The `minio` resource type's default candidate list is browser-only (no
  `mc` CLI fallback) — deliberate, matching the product decision that MinIO/
  Qdrant/Langfuse/Metabase should open in the browser, but an admin who
  wants an `mc`-based CLI fallback can add one to `launch-templates.json`
  (the `Candidate`/`discovery.Spec` schema supports it; it just isn't
  shipped as a default since `mc` needs an `alias set` step first that
  doesn't fit the existing credential-injection modes cleanly).
- No integration between `ttl_minutes` and an actual "Download agent
  installer" button in the PAM frontend yet — the backend support and the
  onboarding-script generator both exist and are verified independently,
  but nothing wires them together end-to-end from the UI. Flagging so it
  doesn't get missed.

## Bug fix: Windows `"cli"` launch — console flashed open/closed, target tool never ran

Reported from a real Windows machine (the first real-world run of this
platform — everything before this had only been cross-compiled and
`go vet`'d, never executed on actual Windows): running `pam-agent launch`
against a `"cli"`-mode resource (e.g. `psql`) opened a `cmd` window that
closed again within about a second, and the target tool never appeared.

**Root cause**: `spawn_windows.go`'s `"cli"` branch shelled out via
`cmd /C start /wait "<title>" <Exec> <Args...>` — no explicit title before
the `/wait` switch. cmd.exe's `start` builtin decides whether the first
token after `start` is a window title or the command to run using its own
internal heuristic, and that heuristic is well known to misfire once a
switch like `/wait` shows up before a title is actually given. The result:
`start` failed to correctly identify and launch the target executable,
returned "success" anyway (as it always does, even when what it tried to
start failed to spawn), and the wrapping `cmd` window closed immediately
after — exactly the reported symptom, with no error surfaced anywhere.

**First fix attempt (not shipped)**: dropped `cmd.exe` entirely in favor of
calling `CreateProcess` directly via
`syscall.SysProcAttr{CreationFlags: CREATE_NEW_CONSOLE}` (declared locally
as a raw hex constant — no new dependency). This built, vetted, and passed
tests, but a closer read of Go's own stdlib source
(`$GOROOT/src/syscall/exec_windows.go`, `$GOROOT/src/os/exec/exec.go`)
turned up a second, worse bug it would have introduced: Go's `os/exec`
unconditionally sets `STARTF_USESTDHANDLES` for every Windows child, and
since `Cmd.Stdin`/`Stdout`/`Stderr` were left `nil`, it would have silently
wired the new console's process to `os.DevNull` instead of to the new
console's real handles — a blank, non-interactive window, with interactive
tools like `psql` likely reading instant EOF on stdin and exiting
immediately. Same user-visible symptom, worse cause. Caught before
shipping; never delivered.

**Actual fix**: keep going through `cmd.exe`/`start` (it does its own
`CreateProcess` call for whatever it launches, which does not inherit Go's
forced devnull wiring — going around it, not through it, was the mistake),
but fix the two real problems:

1. Always pass an explicit title — an empty `""` — as the very first token
   after `start`, removing the ambiguity that caused the original bug,
   regardless of whether the target exe's path contains spaces (e.g.
   `C:\Program Files\PostgreSQL\16\bin\psql.exe`).
2. Target a nested `cmd /K "<Exec>" <Args...>` instead of the exe directly,
   so the window stays open with a normal prompt after the tool exits
   (whether normally or via an instant failure) — the operator can actually
   read what happened instead of the window flashing shut.

Final command: `cmd /C start "" /wait cmd /K <Exec> <Args...>`. Go's own
argument escaping (each `[]string` element quoted automatically if it
contains spaces) is left to do its job — no hand-added quotes around
`Exec`/`Args`, which would double-quote and reintroduce the exact ambiguity
this fix removes.

**UX trade-off, disclosed, not hidden**: the console window no longer
auto-closes. The operator types `exit` or closes it manually when the tool
is done. `Spawn`'s `c.Run()` blocks until then, so session-end reporting
stays accurate but now reflects "window closed" rather than "tool process
exited" — a minor, deliberate shift in exchange for actually seeing errors
instead of a window flashing shut with no explanation.

**Verification**: `gofmt -l .` clean; native `go build ./... && go vet ./...
&& go test ./...` clean; `GOOS=windows GOARCH=amd64` and
`GOOS=windows GOARCH=arm64` both `go build`/`go vet` clean;
`go.mod` still has zero `require` lines (module invariant unchanged). Not
yet re-verified on a real Windows machine — that verification is the next
step, from the user who filed the original report.
