//go:build windows

package main

import "fmt"

// On Windows `launch` allocates its own console and relays in-process, so
// there is no separate relay step to invoke. Answering with a clear error
// beats a silent no-op if something ever calls it.
func cmdRelayDispatch(_ []string) error {
	return fmt.Errorf("relay is not used on Windows — launch relays in-process via ConPTY")
}
