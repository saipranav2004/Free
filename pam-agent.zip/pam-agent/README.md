# pam-agent

`pam-agent` is the local companion binary for the PAM web application. It is
what makes "click Open in Desktop App on a Resource" actually pop open a real
local client — CLI or GUI — on the operator's own machine, already
authenticated — no credential ever typed, pasted, or even seen by the
person launching it. It supports Redis, PostgreSQL, MongoDB, Oracle,
ClickHouse, MinIO, Qdrant, Langfuse, and Metabase out of the box (see
"Supported resource types" below), and doesn't hard-require any one
specific tool per resource type — if the obvious CLI isn't installed, it
tries a documented list of GUI fallbacks before giving up.

It is a single static binary. **Zero third-party Go dependencies** — only
the Go standard library — by deliberate design, so it's trivial to build,
audit, and ship without pulling in a dependency tree. (This includes the new
`internal/logging` package, built on `log/slog` — stdlib since Go 1.21 — not
zap/logrus, and `internal/discovery`'s Windows registry lookups, which shell
out to `reg.exe` rather than linking a registry-access package.)

**Installable, one-click setup.** See "Installing" below — a single
generated script embeds both the agent binary and a one-time pairing code,
so handing it to a client does `install` + `pair` in one step, no manual
follow-up command required.

## What it does

```
pam-agent install                             register this OS's pam-agent:// URL handler
pam-agent pair --code XXXX --server <url>     pair this machine to a PAM account (run once per server)
pam-agent launch <pam-agent://... URL>        redeem a launch token and open the local tool
                                               (normally invoked by the OS, not typed by hand)
pam-agent devices                             list PAM servers this machine has paired against
pam-agent uninstall                           remove the URL handler registration
```

Two more exist but are never typed by an operator — `launch` arranges for them:

```
pam-agent relay --session … --server … [--policy JSON] [--record] -- <tool> [args…]
                                              macOS/Linux: hold a pty with the tool inside it,
                                              record it, enforce the policy, report its end
pam-agent report-end --session … --server … --exit N
                                              fallback lifecycle report, used only when the
                                              relay could not be started
```

## Installing

**One-click (recommended):** your PAM administrator generates a
self-contained setup script for you with
`install/generate-onboarding-script.sh <linux|darwin|windows> <binary> <server-url> <pairing-code>`
(see that script's own header comment). The generated script embeds both
the agent binary (as base64) and a one-time pairing code, so running it —
`sh pam-agent-setup.sh` on Linux/macOS, or
`powershell -ExecutionPolicy Bypass -File pam-agent-setup.ps1` on Windows —
does `pam-agent install` **and** `pam-agent pair` in one step. Nothing here
weakens the trust model described below: the agent still calls the PAM
server at every launch to resolve a fresh, vaulted credential — this only
automates the one-time enrollment handshake, and the embedded code is
single-use and expires (default 60 minutes, capped at 24h server-side; see
`ttl_minutes` on `POST /api/v1/pam/agent/pair/init`). This exact flow —
binary embed, extraction, install, pair — was run end-to-end against a real
mock PAM server as part of verifying this feature; see CHANGES.md.

**Packaged install:** a real, build-verified Debian package is at
`install/linux/build-deb.sh` (produces `pam-agent_<version>_<arch>.deb` via
`dpkg-deb`; only places the binary at `/usr/bin/pam-agent` — pairing is
still a separate, per-user step, since `dpkg`'s postinst runs as root and
pairing must not). Windows (`install/windows/`, WiX Toolset) and macOS
(`install/macos/`, `pkgbuild`/`productbuild`) installer sources are
provided too, complete and reviewed, but **not build-verified** in this
project's sandbox (Linux-only, no WiX/Xcode tooling available) — see the
header comment in each build script for exactly what to check after a real
build on that OS.

**Manual (no installer at all):** copy the binary anywhere and run the two
commands below yourself.

## End-to-end flow

1. **Install.** `pam-agent install` registers `pam-agent://` as a URL
   scheme with the OS (Windows: `HKCU\Software\Classes`; macOS: a tiny
   `.app` bundle + `lsregister`; Linux: a `.desktop` file + `xdg-mime`) so
   the browser can hand off to it later. Entirely per-user, no admin rights
   needed on any OS — see the one-click installer note above for why that
   matters for automated setup.

2. **Pair.** From an authenticated PAM browser session, the user requests a
   pairing code (`POST /api/v1/pam/agent/pair/init`, MFA-gated) — a short,
   human-typed code, good for 5 minutes by default (a caller can request up
   to 24h via `ttl_minutes` in the request body, e.g. for an installer
   embedding the code — see "Installing" above). They run
   `pam-agent pair --code XXXX --server https://pam.company.com`. The agent
   generates an Ed25519 keypair **locally** and sends only the **public**
   half to PAM along with the code. PAM never sees, and the network never
   carries, the private key.

3. **Launch.** The user clicks "Open in Desktop App" on a Resource in the
   PAM UI. The browser calls `POST /resources/:id/launch` (gated by the
   exact same `pam:resource:Connect` IAM check as the in-browser terminal),
   gets back a `pam-agent://launch?token=...&server=...` URL, and navigates
   to it. The OS routes that to the installed agent, which:
   - loads its paired identity for that server,
   - signs the token with its private key,
   - redeems it against `POST /api/v1/pam/agent/launch/resolve`,
   - gets back the resolved host/port/account/**password**/`console_url`
     (the one endpoint in the whole API allowed to carry a raw credential —
     it never touches a browser),
   - picks the first candidate tool for that resource type that's actually
     installed on this machine (see "Multi-tool candidates & discovery"
     below), renders its launch template, injects the credential the way
     that tool expects, and spawns it — or, for a browser-kind candidate,
     just opens `console_url` in the default browser with no credential at
     all.

4. **Session end (best-effort).** If the OS/terminal combination lets the
   agent actually observe the process exiting, it reports that back via
   `POST /api/v1/pam/agent/launch/:session_id/end` (also Ed25519-signed) so
   the PAM audit record closes with a real duration instead of sitting
   "ACTIVE" forever. See the per-OS caveats below — this isn't reliable
   everywhere, and PAM shows a real gap here rather than a false answer.
   Browser-kind launches can never be tracked this way — a browser tab
   isn't a process this agent spawned or can watch — so those always show
   ACTIVE until an admin ends the session.

## Multi-tool candidates & discovery

Each resource type in `launch-templates.json` maps to an **ordered list of
candidates**, not one fixed tool — e.g. PostgreSQL tries `psql` first and
falls back to pgAdmin4 if `psql` isn't installed. `pam-agent launch` walks
the list and uses the first candidate whose tool `internal/discovery` can
actually find on this machine:

1. `PATH` (`exec.LookPath`) — the common case for CLI tools.
2. **Windows only:** the `HKCU`/`HKLM` `...\App Paths\` registry, which is
   how most Windows GUI installers register themselves even when they don't
   touch `PATH` (shells out to `reg.exe` — no registry-access package
   linked, keeping the zero-dependency invariant).
3. OS-specific absolute install-path globs (version-folder wildcards
   supported, e.g. `C:\Program Files\pgAdmin 4\*\pgAdmin4.exe` — the
   lexicographically-last existing match wins).
4. **macOS only:** common `.app` bundle names under `/Applications` and
   `~/Applications`.

If nothing in the list is found, `pam-agent` fails with a clear error
naming every candidate it tried — never a silent no-op, and never a guess
at some other tool nobody configured.

A PAM admin can steer this per-resource without any agent config change at
all: setting `extra_config: {"preferred_tool": "pgadmin4"}` on a Resource
(reusing the existing `ExtraConfig` column — no backend schema change)
moves that candidate ID to the front of the list for launches of that
resource. This is a **soft hint, not a hard requirement or an arbitrary
command**: it can only reorder candidate IDs already baked into this
machine's own `launch-templates.json`; if the preferred one still isn't
actually installed, selection falls through to whatever else is, exactly as
if no hint had been set. The backend has no way to make the agent run
something that isn't already a configured candidate — a deliberate security
boundary.

## Supported resource types (defaults)

| Resource type | Candidates tried, in order | Notes |
|---|---|---|
| `redis` | `redis-cli` (CLI) → RedisInsight (GUI) | RedisInsight has no scriptable preseed; operator enters connection details by hand |
| `postgresql` | `psql` (CLI) → pgAdmin4 (GUI) | pgAdmin4 gets a best-effort host/port/username preseed — see below |
| `mongodb` | `mongosh` (CLI) → MongoDB Compass (GUI) | Compass gets a full connection string (see `connection_string_arg`) |
| `oracle` | `sqlplus` → SQLcl (`sql`) → SQL Developer (GUI) | SQL Developer's GUI doesn't accept a connect string as a launch arg at all — opened with no credential, operator connects manually |
| `clickhouse` | `clickhouse-client` (CLI) | No ubiquitous cross-platform ClickHouse GUI shipped by default; add one to `launch-templates.json` if your fleet has one |
| `minio` | opens `console_url` in the browser | MinIO Console is a full-featured web UI; no local credential ever leaves the vault |
| `qdrant` | opens `console_url` in the browser | Qdrant's own dashboard is web-based |
| `langfuse` | opens `console_url` in the browser | |
| `metabase` | opens `console_url` in the browser | |

Every row is just the shipped default in `launch-templates.default.json` —
edit the copy at your config dir to add candidates, change discovery paths,
or point at a differently-installed binary, all without recompiling. A
resource type not in this table (or a browser-kind entry with no
`console_url` set on the Resource) fails with a clear, actionable error
rather than guessing.

### pgAdmin4 preseed (best-effort)

When pgAdmin4 is the chosen candidate, `pam-agent` first runs
`pgadmin4 --load-servers <temp-file>` — a documented pgAdmin4 mechanism
([import/export servers](https://www.pgadmin.org/docs/pgadmin4/latest/import_export_servers.html))
— with a JSON file containing **only host/port/database/username**, never
the password (pgAdmin4 always prompts for that on first connect regardless
of how the server entry was created). This step is genuinely best-effort:
pgAdmin4's exact CLI surface differs across install types (desktop/Electron
build vs. the `pip install pgadmin4` package vs. server-mode deployments),
so a failure here is logged and swallowed, never fatal — the GUI still
opens, the operator just adds the connection by hand instead of it being
pre-filled.

## Security model

- **No bearer secret.** The one thing that would be catastrophic to leak —
  a copyable credential that proves "I am this device" — doesn't exist.
  Identity is an Ed25519 keypair; only signatures cross the network, and a
  signature is worthless without the private key that made it.
- **Launch tokens are one-time and short-lived (60s).** They're scoped to
  exactly one resource + one user at issuance time, and the server checks at
  redemption time that the redeeming device belongs to that same user.
- **Same authorization check, same enforcement point.** The native-launch
  path is gated by the identical `pam:resource:Connect` IAM policy check as
  the browser session gateway. There is no separate, weaker authz path for
  "opening the desktop app."
- **The password never appears on any command line.** Every credential
  injection mode below was chosen specifically to keep the password out of
  `ps`/Task Manager/`/proc`, *except* `connection_string_arg`, which is
  flagged clearly as the one mode that can't avoid it — used only for GUI
  tools (e.g. MongoDB Compass) that require a connection string as their
  literal first argument.
- **Local key storage is 0600, not encrypted-at-rest.** The private key
  file is protected by OS file permissions (stops other OS accounts on a
  shared machine), but not by anything stronger — see the doc comment in
  `internal/keystore/keystore.go`. Wrapping this with the OS's native secret
  store (Windows DPAPI / macOS Keychain / a Linux Secret Service provider)
  is flagged there as the natural next hardening step, not silently claimed
  as already done. Disk encryption (BitLocker/FileVault/LUKS) — which most
  managed enterprise fleets already require — covers a large part of this
  risk in the meantime.

## Credential injection modes

Configured per resource type in `launch-templates.json` (see below):

| Mode | How the credential reaches the tool | Used for |
|---|---|---|
| `env` | Environment variable on the spawned process only | Redis (`REDISCLI_AUTH`) |
| `pgpass` | Throwaway `.pgpass` file (0600) in a per-session temp dir, `PGPASSFILE` env var | PostgreSQL (`psql`) |
| `mongo_init_file` | Throwaway mongosh init script (0600) building the authenticated connection, passed via `--shell` | MongoDB (`mongosh`) |
| `connection_string_arg` | Full `scheme://user:pass@host/db` connection string as a CLI argument | GUI tools that require it (e.g. MongoDB Compass) — **the one mode where the password is briefly visible to anything that can read this process's argv** |
| `oracle_connect_string` | Oracle's own `user/password@host:port/service_name` EZCONNECT logon string as a CLI argument | `sqlplus`/SQLcl (Oracle's real command-line tools — **not** the SQL Developer GUI, which doesn't accept a connect string as a launch argument at all). Same argv-visibility trade-off as `connection_string_arg`, plus: EZCONNECT has no escaping, so this mode refuses outright (returns an error instead of launching) if the stored account name/password contains `@`, `/`, or whitespace, rather than silently connecting as the wrong identity |
| `clickhouse_config_file` | Throwaway `clickhouse-client` XML config (0600), `--config-file` argument | ClickHouse (`clickhouse-client`) — properly XML-escaped, so a credential containing `&`/`<`/etc. can't corrupt the file or get truncated |
| `pgadmin_preseed` | Best-effort: host/port/database/username (never the password) seeded via pgAdmin4's own `--load-servers` mechanism | pgAdmin4 — see "pgAdmin4 preseed" above |
| `none` | Nothing injected — for tools that don't need one, or that will prompt interactively | Redis with no auth configured, RedisInsight, SQL Developer, every `browser`-kind candidate |

Every throwaway credential file lives under a per-session directory in the
OS temp dir and is deleted immediately after the tool exits (or, for
non-blocking spawns, a few seconds after launch — long enough for the tool
to have opened it).

## `launch-templates.json`

The first time `pam-agent launch` runs, it writes a default template file to
the OS's per-user config directory (`%AppData%\pam-agent`,
`~/Library/Application Support/pam-agent`, or `~/.config/pam-agent`) and
reads it on every subsequent launch — so you can add resource types,
reorder or add candidates, point at a differently-installed binary, change
discovery paths, or change arguments without recompiling anything. Ships
with all 9 resource types in the "Supported resource types" table above
(see `internal/launcher/launch-templates.default.json`) — each one an
ordered **array of candidates**, not a single fixed entry.
`Args`/browser-kind `Command` entries are `text/template` strings; the
available placeholders are `{{.Host}}`, `{{.Port}}`, `{{.DatabaseName}}`,
`{{.AccountName}}`, `{{.ConsoleURL}}` — deliberately **not**
`{{.Password}}`, so a template-authoring mistake can never leak the
credential into a rendered argument.

## Per-OS terminal/GUI launch notes

- **Windows:** `cmd /C start "" /wait cmd /K <exe> <args>` — an explicit
  empty title before `/wait` (required so `start` never has to guess
  whether the first token is a title or the command — see `spawn_windows.go`
  for the two broken designs that preceded this one), and a nested `cmd /K`
  so the console window stays open with a normal prompt after the tool
  exits, instead of auto-closing. This means the operator sees any error
  text the tool printed, but it also means **the window no longer closes on
  its own** — type `exit` or close it manually when done. `c.Run()` doesn't
  return until then, so session-end reporting is accurate but reflects
  "window closed," not "tool exited."
- **macOS:** opens `Terminal.app` via `open -a Terminal`, running a 0700
  wrapper script. `open` returns immediately regardless of when the shell
  session ends, so nothing the `launch` process could do would tell it when
  the session was over — which is why the wrapper does not run the tool
  directly. It runs `pam-agent relay -- <tool>`, and **that** process holds a
  pty with the tool inside it. Because the relay owns the child it sees the
  exit, so session-end is exact; because every byte passes through it, the
  session is recorded; and because it is in the data path, the clipboard and
  command controls apply. See `internal/launcher/relay_unix.go`.
- **Linux:** tries `xterm`, then `x-terminal-emulator`, `gnome-terminal`,
  `konsole`, `xfce4-terminal`. Which one is found no longer affects what PAM
  sees: every emulator runs the same wrapper, the wrapper runs
  `pam-agent relay`, and the relay reports the session itself from inside the
  window. That was the point of moving the reporting there — the older design
  depended on whether the emulator's own CLI blocked, which `xterm` does and
  the client/server emulators do not, so session-end accuracy varied by
  whatever happened to be installed on the operator's desktop.
- **GUI tools** (mode `"gui"`, e.g. pgAdmin4, MongoDB Compass, RedisInsight)
  are spawned directly, not inside a terminal, on every OS — same "can't
  observe exit" caveat applies. On macOS, a GUI candidate found as an
  `.app` bundle (rather than a bare binary) is launched via `open -a`.
- **`browser` kind** (MinIO Console, Qdrant dashboard, Langfuse, Metabase):
  opens the OS default browser (`start` on Windows, `open` on macOS,
  `xdg-open` on Linux) to the resource's `console_url`. Never blocks, never
  tracked for session-end — a browser tab isn't a process this agent
  spawned.

## Building

```bash
go build ./cmd/pam-agent            # native
GOOS=windows GOARCH=amd64 go build -o pam-agent.exe ./cmd/pam-agent
GOOS=darwin  GOARCH=amd64 go build -o pam-agent-mac-intel ./cmd/pam-agent
GOOS=darwin  GOARCH=arm64 go build -o pam-agent-mac-arm ./cmd/pam-agent
```

No `go mod tidy`, no network access, and no external dependencies required
— `go.mod` has zero `require` lines on purpose. `gofmt -l .`, `go build
./...`, and `go vet ./...` all pass clean on Linux (native) and cross-compiled
for `windows/amd64`, `darwin/amd64`, and `darwin/arm64` — this was verified
directly, not assumed, precisely because the OS-specific files
(`spawn_*.go`, `register_*.go`) are behind build tags and each one only gets
type-checked when its GOOS is the build target.

Permanent, regression-guarding unit tests (not just a one-off manual check)
cover: Oracle EZCONNECT string building and its unescapable-character
refusal; ClickHouse config-file XML encoding (including that special
characters survive round-trip and never appear unescaped in the raw file);
the pgAdmin4 servers-preseed JSON (asserts the password is NEVER present in
that file); `internal/discovery`'s PATH/absolute-glob/version-ordering/
GOOS-scoping logic and its Windows registry output parser (string-level,
runs on any OS); and `SelectAndBuildCommand`'s candidate fallback,
`preferred_tool` reordering (including that an unavailable preferred
candidate still falls through rather than failing the whole launch), and
browser-kind selection/`console_url` validation. Run with `go test ./...`.

The agent was also exercised **functionally end-to-end**, against a mock
implementation of the three PAM agent endpoints (real Ed25519 keygen/sign/
verify, no mocked crypto) covering, this time, every new code path added in
this round of work — not just the original three resource types:

- Candidate selection actually walking the fallback chain on a real
  machine: `redis`/`postgresql` correctly picked `redis-cli`/`psql` (both
  genuinely on this test machine's `PATH`); `mongodb`/`clickhouse`/`oracle`
  (nothing installed) correctly failed with an error naming every candidate
  tried, instead of a silent no-op or a wrong guess.
- `preferred_tool` reordering: a resource with
  `extra_config.preferred_tool = "pgadmin4"` correctly tried pgAdmin4 first,
  then (since it wasn't installed) correctly fell back to `psql` — the soft-
  hint, not-a-hard-requirement behavior worked exactly as designed.
- `browser`-kind candidates: MinIO/Qdrant resources with `console_url` set
  correctly selected the browser candidate and invoked the OS opener
  (`xdg-open`); the same resource type with `console_url` **unset**
  correctly failed with a clear "an admin needs to set console_url" error
  *before* attempting to open anything.
- pgAdmin4 preseed: using a stand-in binary in place of the real pgAdmin4,
  confirmed the `--load-servers` pre-step actually ran with a real
  host/port/database/username JSON file, then confirmed the GUI itself was
  still launched afterward (non-blocking, as documented).
- The full **one-click onboarding flow**: generated a real setup script
  with `install/generate-onboarding-script.sh`, ran it in a clean fake
  `$HOME` with no prior pam-agent state at all, and confirmed: the extracted
  binary is byte-identical to the original (round-tripped through base64
  correctly), `pam-agent install` registered the `.desktop` file correctly,
  and `pam-agent pair` completed a real Ed25519 pairing handshake against
  the mock server — all from that single generated script, zero manual
  follow-up commands.
- The Linux `.deb` package: built with `dpkg-deb`, inspected with
  `dpkg -c`/`dpkg-deb --info`, then actually installed with `dpkg -i`
  (binary landed at `/usr/bin/pam-agent`, ran correctly), and removed with
  `dpkg -r` (correct `prerm` warning about per-user state surviving package
  removal).

See `CHANGES.md` for the exact commands, in case you want to rerun any of
this yourselves.

## Known limitations / next steps

- Session end, session recording and the data-protection controls now work
  on all three platforms for **`cli`-kind launches**: Windows relays through
  ConPTY inside the `launch` process, macOS and Linux through
  `pam-agent relay` inside the terminal window. What is still not covered:
  - **`gui`-kind launches** (pgAdmin4, MongoDB Compass, RedisInsight). There
    is no terminal to relay, and the app is not a process this agent can
    watch to completion, so session end stays best-effort and there is no
    recording. A GUI app's traffic also never passes through the agent.
  - **`browser`-kind launches** (MinIO Console, Qdrant dashboard, Langfuse,
    Metabase). A browser tab is not a process this agent spawned. Use the
    brokered web proxy for these instead — PAM is in the data path there, so
    it can record and enforce properly, which the agent fundamentally cannot.
- If the agent binary is missing at launch time (moved, upgraded, unmounted
  disk), the wrapper refuses to open a session that is recorded or has an
  active policy, rather than opening it unsupervised — a session that looks
  supervised and is not is worse than one that did not open. Sessions with
  neither obligation fall back to running the tool and reporting via
  `report-end`.
- `connection_string_arg`/`oracle_connect_string` (used for GUI/CLI tools
  with no other option) put the credential briefly on the process's own
  argument list — documented above, not hidden. Prefer the other injection
  modes wherever the target tool supports them.
- pgAdmin4 preseed is best-effort and version-dependent — see "pgAdmin4
  preseed" above. It never blocks the GUI from opening if it fails.
- The private key at rest is file-permission-protected, not encrypted —
  see the Security model section. OS-native secret-store integration is the
  natural hardening step if you need to close that gap.
- No auto-update mechanism — rolling out a new `pam-agent` build to already-
  installed machines is a manual redistribution today.
- The Windows `.msi` (WiX) and macOS `.pkg` installer sources in `install/`
  are complete and reviewed but **not build-verified** — this project's
  sandbox is Linux-only, with neither WiX Toolset nor Xcode command-line
  tools available to actually run `candle`/`light` or `pkgbuild`/
  `productbuild`. The Linux `.deb` and the cross-platform one-click
  onboarding script (which covers macOS too, using the identical,
  already-verified shell logic — only the embedded binary differs) do not
  have this limitation. Run a real build + install/uninstall cycle on each
  OS before shipping the MSI/pkg to a client — see the verification steps
  in each build script's header comment.
