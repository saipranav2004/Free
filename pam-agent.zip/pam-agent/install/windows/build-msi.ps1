# pam-agent/install/windows/build-msi.ps1
#
# Builds pam-agent.msi from pam-agent.wxs using WiX Toolset v3
# (candle.exe + light.exe). NOT run/verified in this sandbox -- there is no
# Windows machine here. Requires:
#   - WiX Toolset v3.11+ installed (https://wixtoolset.org/), with
#     candle.exe/light.exe on PATH
#   - Go available, to cross-compile (or build natively on Windows)
#
# Usage (from an elevated or normal PowerShell prompt on Windows):
#   .\build-msi.ps1 -Version 1.0.0
#
# After a real build, verify at minimum:
#   msiexec /i pam-agent.msi /l*v install.log     (install, check install.log)
#   %LocalAppData%\pam-agent\pam-agent.exe devices (confirm it paired, if a
#                                                    code/server were given)
#   msiexec /x pam-agent.msi                        (uninstall cleanly)

param(
    [Parameter(Mandatory = $true)]
    [string]$Version,

    [string]$OutDir = "."
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ModuleRoot = Resolve-Path (Join-Path $ScriptDir "..\..")
$ExePath = Join-Path $ScriptDir "pam-agent.exe"

Write-Host "Building pam-agent.exe for windows/amd64..."
Push-Location $ModuleRoot
try {
    $env:GOOS = "windows"
    $env:GOARCH = "amd64"
    go build -trimpath -ldflags "-s -w" -o $ExePath ./cmd/pam-agent
} finally {
    Pop-Location
    Remove-Item Env:\GOOS -ErrorAction SilentlyContinue
    Remove-Item Env:\GOARCH -ErrorAction SilentlyContinue
}

Write-Host "Compiling WiX source..."
& candle.exe -dPamAgentVersion="$Version" -dPamAgentExePath="$ExePath" `
    -out (Join-Path $ScriptDir "pam-agent.wixobj") (Join-Path $ScriptDir "pam-agent.wxs")
if ($LASTEXITCODE -ne 0) { throw "candle.exe failed" }

Write-Host "Linking MSI..."
$MsiOut = Join-Path $OutDir "pam-agent-$Version.msi"
& light.exe -ext WixUIExtension -ext WixUtilExtension `
    -out $MsiOut (Join-Path $ScriptDir "pam-agent.wixobj")
if ($LASTEXITCODE -ne 0) { throw "light.exe failed" }

Write-Host ""
Write-Host "Built: $MsiOut"
Write-Host "This was NOT installed/tested as part of the build -- run the verification"
Write-Host "steps in this script's header comment before shipping it to a client."
