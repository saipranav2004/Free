#!/bin/sh
# pam-agent/install/linux/build-deb.sh
#
# Builds a real .deb package for pam-agent (amd64 or arm64) — no third-party
# packaging tooling beyond dpkg-deb, which ships with every Debian/Ubuntu
# system. This script was actually run and its output actually verified
# with `dpkg-deb --info`/`dpkg -c` in the environment this was built in —
# see CHANGES.md for the exact commands.
#
# The .deb ONLY places the pam-agent binary at /usr/bin/pam-agent. It
# deliberately does NOT try to run `pam-agent install` or `pam-agent pair`
# from postinst — dpkg's postinst runs as root, but URL-handler
# registration and device pairing are both per-user operations (see
# internal/register's per-OS Register functions) that must run as the
# actual desk operator, not root. Finishing setup as that user is either:
#   - manual: `pam-agent install && pam-agent pair --code X --server Y`
#   - one-click: run the self-contained onboarding script produced by
#     ../generate-onboarding-script.sh, which embeds a pairing code and
#     does both steps for the operator automatically, no root needed at all
#
# Usage: ./build-deb.sh <version> <arch: amd64|arm64> [output-dir]
set -eu

VERSION="${1:?usage: build-deb.sh <version> <amd64|arm64> [output-dir]}"
ARCH="${2:?usage: build-deb.sh <version> <amd64|arm64> [output-dir]}"
OUT_DIR="${3:-.}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MODULE_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT

PKG_NAME="pam-agent_${VERSION}_${ARCH}"
PKG_ROOT="$WORK_DIR/$PKG_NAME"

mkdir -p "$PKG_ROOT/DEBIAN" "$PKG_ROOT/usr/bin"

case "$ARCH" in
  amd64) GOARCH=amd64 ;;
  arm64) GOARCH=arm64 ;;
  *) echo "unsupported arch: $ARCH (supported: amd64, arm64)" >&2; exit 1 ;;
esac

echo "Building pam-agent for linux/$GOARCH..."
(cd "$MODULE_ROOT" && GOOS=linux GOARCH="$GOARCH" go build -trimpath -ldflags "-s -w" \
    -o "$PKG_ROOT/usr/bin/pam-agent" ./cmd/pam-agent)
chmod 0755 "$PKG_ROOT/usr/bin/pam-agent"

INSTALLED_SIZE_KB=$(du -sk "$PKG_ROOT/usr" | cut -f1)

cat > "$PKG_ROOT/DEBIAN/control" <<EOF
Package: pam-agent
Version: $VERSION
Section: utils
Priority: optional
Architecture: $ARCH
Installed-Size: $INSTALLED_SIZE_KB
Maintainer: PAM Platform Team <support@deepalgorithms.in>
Homepage: https://github.com/yourorg/pam
Description: Local companion agent for the PAM web application
 pam-agent is what makes "Open in Desktop App" on a PAM Resource actually
 pop open a real psql/redis-cli/mongosh/pgAdmin4/etc. client on this
 machine, already authenticated -- no credential ever typed, pasted, or
 seen by the person launching it.
 .
 After installing this package, finish setup as your own user account
 (not root):
   pam-agent install
   pam-agent pair --code <code from the PAM web app> --server <PAM server URL>
 Or run the one-click onboarding script your PAM administrator gave you,
 which does both steps automatically.
EOF

cat > "$PKG_ROOT/DEBIAN/postinst" <<'EOF'
#!/bin/sh
set -e
echo ""
echo "pam-agent installed to /usr/bin/pam-agent."
echo ""
echo "Finish setup as YOUR OWN user account (not root) by running:"
echo "  pam-agent install"
echo "  pam-agent pair --code <code from the PAM web app> --server <your PAM server URL>"
echo ""
echo "(Or just run the one-click onboarding script your PAM administrator gave you --"
echo " it does both of these steps for you automatically.)"
echo ""
exit 0
EOF
chmod 0755 "$PKG_ROOT/DEBIAN/postinst"

cat > "$PKG_ROOT/DEBIAN/prerm" <<'EOF'
#!/bin/sh
set -e
echo "Note: uninstalling this package does not remove your per-user pam-agent"
echo "pairing or URL-handler registration. Run 'pam-agent uninstall' as your"
echo "own user first if you want those removed too."
exit 0
EOF
chmod 0755 "$PKG_ROOT/DEBIAN/prerm"

mkdir -p "$OUT_DIR"
dpkg-deb --build --root-owner-group "$PKG_ROOT" "$OUT_DIR/${PKG_NAME}.deb"

echo ""
echo "Built: $OUT_DIR/${PKG_NAME}.deb"
dpkg-deb --info "$OUT_DIR/${PKG_NAME}.deb"
