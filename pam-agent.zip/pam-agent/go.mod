module github.com/yourorg/pam-agent

go 1.22
