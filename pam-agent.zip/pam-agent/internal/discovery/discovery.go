// Package discovery finds locally-installed tools without ever requiring
// the operator to have the "obvious" one (e.g. psql) — it also tries
// well-known GUI alternatives (e.g. pgAdmin4) so pam-agent keeps working on
// a machine that only has the GUI client installed.
//
// Zero third-party dependencies, by the same invariant as the rest of this
// module: Windows registry lookups shell out to reg.exe (built into every
// Windows install) instead of linking golang.org/x/sys/windows/registry or
// similar.
package discovery

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
)

// Spec describes every place Locate should look for one candidate tool.
// Every field is optional and OS-scoped fields are only consulted on their
// matching runtime.GOOS — a Spec is safe to share verbatim across all three
// platforms in launch-templates.json.
type Spec struct {
	// BinaryNames are tried on PATH first, in order, via exec.LookPath —
	// the fast, common case on any OS where the tool installer put itself
	// on PATH (true for most CLI tools: psql, redis-cli, mongosh, ...).
	BinaryNames []string `json:"binary_names,omitempty"`

	// WindowsAppPaths are registry value names under both
	// HKLM/HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\ — the
	// mechanism most Windows GUI installers (including pgAdmin4's) register
	// themselves under even when they don't touch PATH. Only consulted when
	// GOOS is windows.
	WindowsAppPaths []string `json:"windows_app_paths,omitempty"`

	// AbsolutePathGlobs are last-resort, OS-specific install locations,
	// keyed by runtime.GOOS ("windows" | "darwin" | "linux"). Glob patterns
	// may contain a version-folder wildcard (e.g.
	// `C:\Program Files\pgAdmin 4\*\pgAdmin4.exe"`) — matches are sorted
	// and the lexicographically last (typically newest version) one that
	// actually exists on disk wins.
	AbsolutePathGlobs map[string][]string `json:"absolute_path_globs,omitempty"`

	// MacAppBundles are `.app` bundle names (e.g. "pgAdmin 4.app") checked
	// under /Applications and ~/Applications. Only consulted when GOOS is
	// darwin. A hit here is launched via `open`, not by exec-ing a binary
	// path directly — see launcher's darwin Spawn for why.
	MacAppBundles []string `json:"mac_app_bundles,omitempty"`
}

// Result is what Locate found — exactly one of Path or AppBundle is set
// when Found() is true.
type Result struct {
	// Path is a directly-executable binary path (from PATH, the Windows
	// registry, or an absolute-path glob).
	Path string
	// AppBundle is a macOS .app bundle directory — launch it with
	// `open -a <AppBundle>`, not by exec-ing something inside it directly.
	AppBundle string
}

func (r Result) Found() bool { return r.Path != "" || r.AppBundle != "" }

// Locate tries, in order: PATH, the Windows "App Paths" registry,
// OS-specific absolute install locations, then (macOS only) common
// /Applications bundle names. Returns the zero Result if nothing matched.
func Locate(spec Spec) Result {
	for _, name := range spec.BinaryNames {
		if name == "" {
			continue
		}
		if p, err := exec.LookPath(name); err == nil {
			return Result{Path: p}
		}
	}

	if runtime.GOOS == "windows" {
		for _, key := range spec.WindowsAppPaths {
			if p, ok := queryWindowsAppPath(key); ok {
				return Result{Path: p}
			}
		}
	}

	if globs, ok := spec.AbsolutePathGlobs[runtime.GOOS]; ok {
		if p, ok := globLatestExisting(globs); ok {
			return Result{Path: p}
		}
	}

	if runtime.GOOS == "darwin" {
		for _, bundle := range spec.MacAppBundles {
			if p, ok := findMacAppBundle(bundle); ok {
				return Result{AppBundle: p}
			}
		}
	}

	return Result{}
}

// globLatestExisting expands every glob pattern, sorts all matches
// descending, and returns the first one that stats as a regular file —
// version-folder globs (".../v*/pgAdmin4.exe") sort so a newer version
// folder is preferred over an older one left behind by an upgrade.
func globLatestExisting(patterns []string) (string, bool) {
	var all []string
	for _, pattern := range patterns {
		matches, err := filepath.Glob(pattern)
		if err != nil {
			continue
		}
		all = append(all, matches...)
	}
	sort.Sort(sort.Reverse(sort.StringSlice(all)))
	for _, m := range all {
		if fi, err := os.Stat(m); err == nil && !fi.IsDir() {
			return m, true
		}
	}
	return "", false
}

func findMacAppBundle(name string) (string, bool) {
	candidates := []string{filepath.Join("/Applications", name)}
	if home, err := os.UserHomeDir(); err == nil && home != "" {
		candidates = append(candidates, filepath.Join(home, "Applications", name))
	}
	for _, c := range candidates {
		if fi, err := os.Stat(c); err == nil && fi.IsDir() {
			return c, true
		}
	}
	return "", false
}

// queryWindowsAppPath shells out to reg.exe (present on every Windows
// install) rather than linking a registry-access package, preserving this
// module's zero-third-party-dependency invariant. Tries HKLM then HKCU —
// a per-machine install typically registers under HKLM, a per-user install
// (common for things users install without admin rights) under HKCU.
func queryWindowsAppPath(exeName string) (string, bool) {
	for _, root := range []string{"HKLM", "HKCU"} {
		key := fmt.Sprintf(`%s\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\%s`, root, exeName)
		out, err := exec.Command("reg", "query", key, "/ve").Output()
		if err != nil {
			continue
		}
		if p, ok := parseRegDefaultValue(string(out)); ok {
			return p, true
		}
	}
	return "", false
}

// parseRegDefaultValue pulls the path out of `reg query <key> /ve` output:
//
//	HKEY_LOCAL_MACHINE\...\App Paths\pgAdmin4.exe
//	    (Default)    REG_SZ    C:\Program Files\pgAdmin 4\8\pgAdmin4.exe
func parseRegDefaultValue(out string) (string, bool) {
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		idx := strings.Index(line, "REG_SZ")
		if idx == -1 {
			continue
		}
		val := strings.TrimSpace(line[idx+len("REG_SZ"):])
		val = strings.Trim(val, `"`)
		if val != "" && val != "(value not set)" {
			return val, true
		}
	}
	return "", false
}
