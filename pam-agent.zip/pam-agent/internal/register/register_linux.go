//go:build linux

// pam-agent/internal/register/register_linux.go
package register

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
)

const desktopFileName = "pam-agent.desktop"

// Register writes a per-user .desktop file declaring pam-agent as the
// handler for x-scheme-handler/pam-agent, then tells the desktop database
// and xdg-mime about it. Entirely per-user (~/.local/share/applications),
// no root required. xdg-mime/update-desktop-database are near-universal on
// desktop Linux but may be absent on minimal/headless installs — Register
// reports that clearly rather than silently no-op'ing.
func Register(execPath string) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return fmt.Errorf("could not determine home directory: %w", err)
	}
	appsDir := filepath.Join(home, ".local", "share", "applications")
	if err := os.MkdirAll(appsDir, 0o755); err != nil {
		return fmt.Errorf("failed to create %s: %w", appsDir, err)
	}

	desktopFile := fmt.Sprintf(`[Desktop Entry]
Type=Application
Name=PAM Agent
Comment=Handles pam-agent:// links from the PAM web application
Exec=%s launch %%u
Terminal=false
NoDisplay=true
StartupNotify=false
MimeType=x-scheme-handler/pam-agent;
`, execPath)

	desktopPath := filepath.Join(appsDir, desktopFileName)
	if err := os.WriteFile(desktopPath, []byte(desktopFile), 0o644); err != nil {
		return fmt.Errorf("failed to write %s: %w", desktopPath, err)
	}

	if _, err := exec.LookPath("update-desktop-database"); err == nil {
		if out, err := exec.Command("update-desktop-database", appsDir).CombinedOutput(); err != nil {
			return fmt.Errorf("update-desktop-database failed: %w (%s)", err, string(out))
		}
	}

	if _, err := exec.LookPath("xdg-mime"); err == nil {
		if out, err := exec.Command("xdg-mime", "default", desktopFileName, "x-scheme-handler/pam-agent").CombinedOutput(); err != nil {
			return fmt.Errorf("xdg-mime failed: %w (%s)", err, string(out))
		}
	} else {
		return fmt.Errorf("wrote %s but xdg-mime is not installed, so pam-agent:// links won't be routed here automatically — install xdg-utils, or invoke `pam-agent launch <url>` manually", desktopPath)
	}

	return nil
}

// Unregister removes the .desktop file this agent installed.
func Unregister() error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	return os.Remove(filepath.Join(home, ".local", "share", "applications", desktopFileName))
}
