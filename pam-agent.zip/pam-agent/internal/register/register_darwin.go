//go:build darwin

// pam-agent/internal/register/register_darwin.go
package register

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
)

const bundleName = "PAMAgent.app"

// lsregisterPath is the standard location of the Launch Services registration
// tool on macOS — stable across recent macOS versions.
const lsregisterPath = "/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister"

// Register makes macOS recognize pam-agent:// URLs by wrapping execPath in a
// minimal per-user .app bundle (custom URL schemes require a proper bundle —
// a bare Mach-O binary can't be registered with Launch Services) and force-
// registering it with lsregister. Installed under ~/Applications, so no
// admin rights are required.
func Register(execPath string) error {
	home, err := os.UserHomeDir()
	if err != nil {
		return fmt.Errorf("could not determine home directory: %w", err)
	}
	bundlePath := filepath.Join(home, "Applications", bundleName)
	macOSDir := filepath.Join(bundlePath, "Contents", "MacOS")

	if err := os.MkdirAll(macOSDir, 0o755); err != nil {
		return fmt.Errorf("failed to create app bundle directories: %w", err)
	}

	if err := copyFile(execPath, filepath.Join(macOSDir, "pam-agent")); err != nil {
		return fmt.Errorf("failed to copy agent binary into bundle: %w", err)
	}
	if err := os.Chmod(filepath.Join(macOSDir, "pam-agent"), 0o755); err != nil {
		return fmt.Errorf("failed to make bundled agent binary executable: %w", err)
	}

	plist := `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleName</key><string>PAM Agent</string>
	<key>CFBundleIdentifier</key><string>com.yourorg.pam-agent</string>
	<key>CFBundleVersion</key><string>1.0</string>
	<key>CFBundleExecutable</key><string>pam-agent</string>
	<key>CFBundlePackageType</key><string>APPL</string>
	<key>LSUIElement</key><true/>
	<key>CFBundleURLTypes</key>
	<array>
		<dict>
			<key>CFBundleURLName</key><string>com.yourorg.pam-agent</string>
			<key>CFBundleURLSchemes</key>
			<array><string>pam-agent</string></array>
		</dict>
	</array>
</dict>
</plist>
`
	if err := os.WriteFile(filepath.Join(bundlePath, "Contents", "Info.plist"), []byte(plist), 0o644); err != nil {
		return fmt.Errorf("failed to write Info.plist: %w", err)
	}

	// Force Launch Services to pick up the new/updated bundle immediately,
	// rather than waiting for it to notice on its own schedule.
	if out, err := exec.Command(lsregisterPath, "-f", bundlePath).CombinedOutput(); err != nil {
		return fmt.Errorf("lsregister failed: %w (%s)", err, string(out))
	}
	return nil
}

// Unregister removes the app bundle. macOS's URL-scheme registration itself
// has no simple "unregister" call; removing the bundle it points at is the
// practical equivalent, since Launch Services drops routes to bundles that
// no longer exist.
func Unregister() error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}
	return os.RemoveAll(filepath.Join(home, "Applications", bundleName))
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()

	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()

	_, err = io.Copy(out, in)
	return err
}
