package launcher

import (
	"reflect"
	"testing"
)

func TestLineAccumulator(t *testing.T) {
	tests := []struct {
		name  string
		feeds []string
		want  []string
	}{
		{
			name:  "simple line",
			feeds: []string{"select 1;\r"},
			want:  []string{"select 1;"},
		},
		{
			name:  "split across feeds",
			feeds: []string{"select ", "1;\r"},
			want:  []string{"select 1;"},
		},
		{
			name:  "backspace correction",
			feeds: []string{"select 2\x7f1;\r"},
			want:  []string{"select 1;"},
		},
		{
			name:  "backspace does not underflow empty buffer",
			feeds: []string{"\x7f\x7fecho hi\r"},
			want:  []string{"echo hi"},
		},
		{
			name:  "arrow key escape sequence is stripped",
			feeds: []string{"echo\x1b[Ahi\r"},
			want:  []string{"echohi"},
		},
		{
			name:  "osc sequence is stripped",
			feeds: []string{"\x1b]0;title\x07echo hi\r"},
			want:  []string{"echo hi"},
		},
		{
			name:  "blank enter presses are not emitted",
			feeds: []string{"\r\r\recho hi\r\r"},
			want:  []string{"echo hi"},
		},
		{
			name:  "multiple commands in one session",
			feeds: []string{"select 1;\rselect 2;\r"},
			want:  []string{"select 1;", "select 2;"},
		},
		{
			name:  "tab is preserved literally",
			feeds: []string{"a\tb\r"},
			want:  []string{"a\tb"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var got []string
			acc := newLineAccumulator(func(line string) { got = append(got, line) })
			for _, f := range tt.feeds {
				acc.Feed([]byte(f))
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Fatalf("got %q, want %q", got, tt.want)
			}
		})
	}
}
