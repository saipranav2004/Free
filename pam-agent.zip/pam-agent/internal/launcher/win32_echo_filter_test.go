//go:build windows

package launcher

import "testing"

func TestWin32EchoFilter(t *testing.T) {
	tests := []struct {
		name  string
		feeds []string
		want  string
	}{
		{
			name:  "plain text passes through unchanged",
			feeds: []string{"cirmdb=> select 1;\r\n"},
			want:  "cirmdb=> select 1;\r\n",
		},
		{
			name:  "win32-input-mode echo is dropped, literal char kept",
			feeds: []string{"\x1b[83;31;115;1;0;1_s\x1b[83;31;115;0;0;1_"},
			want:  "s",
		},
		{
			name:  "standard cursor-move CSI sequence is kept",
			feeds: []string{"\x1b[5;10H"},
			want:  "\x1b[5;10H",
		},
		{
			name:  "clear screen and color codes are kept",
			feeds: []string{"\x1b[2J\x1b[m\x1b[H"},
			want:  "\x1b[2J\x1b[m\x1b[H",
		},
		{
			name:  "win32-input-mode marker split across two chunks",
			feeds: []string{"\x1b[83;31;1", "15;1;0;1_s"},
			want:  "s",
		},
		{
			name:  "mixed real transcript",
			feeds: []string{"cirmdb=> \x1b[83;31;115;1;0;1_s\x1b[83;31;115;0;0;1_elect 1;\r\n?column?\n----------\n        1\n(1 row)\n"},
			want:  "cirmdb=> select 1;\r\n?column?\n----------\n        1\n(1 row)\n",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var f win32EchoFilter
			var got []byte
			for _, feed := range tt.feeds {
				got = append(got, f.filter([]byte(feed))...)
			}
			if string(got) != tt.want {
				t.Fatalf("got %q, want %q", string(got), tt.want)
			}
		})
	}
}
