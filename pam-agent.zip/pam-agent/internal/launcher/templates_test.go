package launcher

import (
	"io"
	"log/slog"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/discovery"
)

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

// notFoundSpec never resolves to anything on this machine — used to force
// SelectAndBuildCommand to fall through to the next candidate.
func notFoundSpec() discovery.Spec {
	return discovery.Spec{BinaryNames: []string{"definitely-not-a-real-binary-xyz-123"}}
}

func TestSelectAndBuildCommandFallsBackToNextCandidate(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{ResourceType: "postgresql", Host: "h", Port: 5432, AccountName: "u", Password: "p"}
	candidates := []Candidate{
		{ID: "missing-tool", Kind: "cli", Command: "missing-tool", CredentialInjection: "none", Discovery: notFoundSpec()},
		{ID: "go-fallback", Kind: "cli", Command: "go", CredentialInjection: "none", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}

	cmd, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if chosen.ID != "go-fallback" {
		t.Fatalf("chosen candidate = %q, want %q", chosen.ID, "go-fallback")
	}
	if cmd.Exec == "" {
		t.Fatal("expected a resolved Exec path")
	}
}

func TestSelectAndBuildCommandErrorsWhenNothingFound(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{ResourceType: "oracle"}
	candidates := []Candidate{
		{ID: "sqlplus", Kind: "cli", Discovery: notFoundSpec()},
		{ID: "sqlcl", Kind: "cli", Discovery: notFoundSpec()},
	}
	_, _, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err == nil {
		t.Fatal("expected an error when no candidate is found")
	}
	if !strings.Contains(err.Error(), "sqlplus") || !strings.Contains(err.Error(), "sqlcl") {
		t.Fatalf("expected error to name every tried candidate, got: %v", err)
	}
}

func TestSelectAndBuildCommandBrowserKindNeedsNoDiscovery(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{ResourceType: "minio", ConsoleURL: "https://minio.example.com/browser"}
	candidates := []Candidate{
		{ID: "minio-console", Kind: "browser", Command: "{{.ConsoleURL}}"},
	}
	cmd, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if chosen.ID != "minio-console" {
		t.Fatalf("chosen = %q", chosen.ID)
	}
	if cmd.Exec != resolved.ConsoleURL {
		t.Fatalf("Exec = %q, want the rendered console URL %q", cmd.Exec, resolved.ConsoleURL)
	}
	if cmd.Mode != "browser" {
		t.Fatalf("Mode = %q, want %q", cmd.Mode, "browser")
	}
	if cmd.CopyPasswordToClipboard {
		t.Fatal("expected CopyPasswordToClipboard = false when credential_injection is unset")
	}
}

// TestSelectAndBuildCommandPgAdminCopiesPasswordToClipboard covers the real
// "pgadmin4" entry from launch-templates.default.json: alongside the
// --load-servers preseed (host/port/username, never the password),
// CopyPasswordToClipboard must come back true. A PGPASSFILE-based headless
// attempt (mirroring psql's own "pgpass" case) was tried and confirmed LIVE
// not to work — pgAdmin4's "Connect to Server" dialog is its own UI-level
// gate shown before any real libpq connection is attempted, so PGPASSFILE is
// never consulted — see buildCommand's "pgadmin_preseed" case. Discovery
// targets "go" as a stand-in for pgAdmin4 (same trick used elsewhere in this
// file) since this test can't assume pgAdmin4 is actually installed on the
// machine running it.
func TestSelectAndBuildCommandPgAdminCopiesPasswordToClipboard(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "h", Port: 5432, DatabaseName: "mydb",
		AccountName: "postgres", Password: "s3cret",
	}
	candidates := []Candidate{
		{ID: "pgadmin4", Kind: "gui", Command: "go", CredentialInjection: "pgadmin_preseed", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}
	cmd, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if chosen.ID != "pgadmin4" {
		t.Fatalf("chosen = %q, want pgadmin4", chosen.ID)
	}
	if cmd.PreseedLoadServersPath == "" {
		t.Fatal("expected a non-empty PreseedLoadServersPath")
	}
	if !cmd.CopyPasswordToClipboard {
		t.Fatal("expected CopyPasswordToClipboard = true for credential_injection \"pgadmin_preseed\"")
	}
}

// TestSelectAndBuildCommandBrowserClipboard covers MinIO's actual
// launch-templates.default.json entry: a "browser" candidate with
// credential_injection "clipboard" must come back with
// CopyPasswordToClipboard set, so cmdLaunch knows to copy the password
// before opening the console URL (see buildBrowserCommand's doc comment for
// why MinIO's console has no auto-login path this agent can drive instead).
func TestSelectAndBuildCommandBrowserClipboard(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "minio",
		ConsoleURL:   "http://13.206.221.6:9001",
		AccountName:  "minioadmin",
		Password:     "DasAdmin@123",
	}
	candidates := []Candidate{
		{ID: "minio-console", Kind: "browser", Command: "{{.ConsoleURL}}", CredentialInjection: "clipboard"},
	}
	cmd, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if chosen.ID != "minio-console" {
		t.Fatalf("chosen = %q", chosen.ID)
	}
	if !cmd.CopyPasswordToClipboard {
		t.Fatal("expected CopyPasswordToClipboard = true for credential_injection \"clipboard\"")
	}
	if cmd.Exec != resolved.ConsoleURL {
		t.Fatalf("Exec = %q, want %q", cmd.Exec, resolved.ConsoleURL)
	}
}

func TestSelectAndBuildCommandBrowserKindRequiresConsoleURL(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{ResourceType: "minio", ConsoleURL: ""}
	candidates := []Candidate{{ID: "minio-console", Kind: "browser", Command: "{{.ConsoleURL}}"}}
	_, _, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err == nil {
		t.Fatal("expected an error when console_url is empty")
	}
	if !strings.Contains(err.Error(), "console_url") {
		t.Fatalf("expected error to mention console_url, got: %v", err)
	}
}

func TestReorderByPreferredMovesMatchToFront(t *testing.T) {
	candidates := []Candidate{{ID: "a"}, {ID: "b"}, {ID: "c"}}
	ordered := reorderByPreferred(candidates, map[string]interface{}{"preferred_tool": "c"})
	got := []string{ordered[0].ID, ordered[1].ID, ordered[2].ID}
	want := []string{"c", "a", "b"}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("got order %v, want %v", got, want)
		}
	}
}

func TestReorderByPreferredNoOpWhenHintMissingOrUnknown(t *testing.T) {
	candidates := []Candidate{{ID: "a"}, {ID: "b"}}

	ordered := reorderByPreferred(candidates, nil)
	if ordered[0].ID != "a" || ordered[1].ID != "b" {
		t.Fatalf("expected unchanged order with no hint, got %+v", ordered)
	}

	ordered = reorderByPreferred(candidates, map[string]interface{}{"preferred_tool": "not-a-real-candidate"})
	if ordered[0].ID != "a" || ordered[1].ID != "b" {
		t.Fatalf("expected unchanged order with an unknown hint, got %+v", ordered)
	}
}

// TestSelectAndBuildCommandPreferredToolStillFallsBackWhenUnavailable proves
// the security boundary documented on reorderByPreferred: the backend hint
// can only reorder candidate IDs already baked into this machine's
// launch-templates.json, and if THAT preferred one isn't actually
// installed, selection still falls through to whatever else is — it can
// never force a launch to fail just because its top pick is missing, nor
// can it introduce a candidate that wasn't already configured locally.
func TestSelectAndBuildCommandPreferredToolStillFallsBackWhenUnavailable(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "h", Port: 5432, AccountName: "u", Password: "p",
		ExtraConfig: map[string]interface{}{"preferred_tool": "pgadmin4"},
	}
	candidates := []Candidate{
		{ID: "psql", Kind: "cli", Command: "go", CredentialInjection: "none", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
		{ID: "pgadmin4", Kind: "gui", Discovery: notFoundSpec()},
	}
	_, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if chosen.ID != "psql" {
		t.Fatalf("expected fallback to psql when preferred pgadmin4 isn't installed, got %q", chosen.ID)
	}
}

// TestSelectAndBuildCommandMinIOShell exercises the real "minio" entry from
// launch-templates.default.json end to end: mc has no interactive REPL to
// exec directly (see resolveInteractiveShell's doc comment), so a resolved
// mc-shell candidate must come back with Exec overridden to the operator's
// own shell (never left as the discovered mc path) and MC_HOST_pam set in
// Env with the resolved host/account/password/scheme baked in — exactly what
// the operator's shell needs to run `mc ls pam/...` already authenticated.
// Discovery targets "go" as a stand-in for "mc" (same trick as the
// go-fallback candidate above) since this test can't assume mc is actually
// installed on the machine running it.
func TestSelectAndBuildCommandMinIOShell(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "minio",
		Host:         "13.206.221.6",
		Port:         9000,
		AccountName:  "minioadmin",
		Password:     "DasAdmin@123",
		ExtraConfig:  map[string]interface{}{"use_ssl": false},
		ConsoleURL:   "http://13.206.221.6:9001",
	}
	candidates := []Candidate{
		{ID: "mc-shell", Kind: "cli", Command: "mc", CredentialInjection: "minio_mc_shell", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
		{ID: "minio-console", Kind: "browser", Command: "{{.ConsoleURL}}"},
	}

	cmd, chosen, err := SelectAndBuildCommand(resolved, candidates, t.TempDir(), testLogger())
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if chosen.ID != "mc-shell" {
		t.Fatalf("chosen = %q, want mc-shell", chosen.ID)
	}
	if cmd.Exec == "" {
		t.Fatal("expected a resolved shell Exec path")
	}
	if strings.Contains(strings.ToLower(cmd.Exec), "go.exe") || strings.HasSuffix(cmd.Exec, string("go")) {
		t.Fatalf("Exec = %q — must be overridden to the operator's shell, not left as the discovered mc stand-in", cmd.Exec)
	}
	// Raw, not percent-encoded — see buildMinIOAliasEnv's bugfix comment.
	wantEnv := "MC_HOST_pam=" + "http://minioadmin:DasAdmin@123@13.206.221.6:9000"
	found := false
	for _, e := range cmd.Env {
		if e == wantEnv {
			found = true
		}
	}
	if !found {
		t.Fatalf("Env = %v, want it to contain %q", cmd.Env, wantEnv)
	}
	if len(cmd.Args) != 0 {
		t.Fatalf("Args = %v, want empty — the shell takes no arguments", cmd.Args)
	}
}
