// pam-agent/internal/launcher/guard.go
//
// Data-protection enforcement inside a native CLI session.
//
// WHERE THIS SITS, and why it can do anything at all. The agent relays every
// input byte in and every output byte out of the tool's terminal, which is
// also how agent-path recordings work. Being in that relay is what makes it
// possible to drop a paste, cancel a command before it is submitted, and stop
// a session that has pulled too much.
//
// All three platforms are now in that position, by two different routes:
//
//   - Windows: `launch` allocates its own console (AllocConsole) and runs the
//     tool inside a ConPTY it created, all in one process — spawn_windows.go.
//   - macOS/Linux: `launch` has no terminal to relay (the desktop starts it
//     from a pam-agent:// URL), so it asks a terminal emulator for a window
//     and has that window run `pam-agent relay`, which holds a pty with the
//     tool inside it — relay_unix.go.
//
// The guard itself is pure logic with no platform code, which is why the same
// file serves both.
//
// WHAT THIS IS, stated plainly because it must not be oversold. The agent runs
// as the operator, on the operator's machine, holding a credential PAM already
// gave them. They can close it and run psql directly. So everything here is
// FRICTION plus ATTRIBUTION: it stops casual copying and bulk extraction, and
// it records every attempt. It is not prevention, and the only thing that
// makes it prevention is putting PAM back in the data path (a local tunnel
// instead of a credential hand-off) or closing this connect method for the
// resource entirely.
//
// The ordering of the three controls is deliberate. Clipboard blocking is the
// one clients ask for and the weakest thing here; the output budget is the one
// that actually bounds a worst case, because it holds no matter which command
// or trick is used.
package launcher

import (
	"fmt"
	"strings"
	"sync"
	"unicode"
)

// Policy is the server's data-protection decision for this session, mirroring
// models.DataProtection on the PAM side. Resolved centrally and sent with the
// launch, never decided locally — an agent that chose its own policy would be
// asking the operator's machine how restricted the operator should be.
type Policy struct {
	BlockClipboard bool     `json:"block_clipboard"`
	MaxEgressBytes int64    `json:"max_egress_bytes"`
	DeniedCommands []string `json:"denied_commands"`
}

// Active reports whether anything needs enforcing, so the relay can skip the
// guard entirely on an unrestricted session.
func (p Policy) Active() bool {
	return p.BlockClipboard || p.MaxEgressBytes > 0 || len(p.DeniedCommands) > 0
}

const (
	// pasteBurstBytes is the threshold above which one console read is treated
	// as a paste rather than typing.
	//
	// This is a HEURISTIC and worth being honest about. A legacy Windows
	// console does not mark pasted input the way a bracketed-paste-aware
	// terminal does — conhost injects the clipboard as ordinary input records,
	// indistinguishable in kind from keystrokes. What separates them is shape:
	// a keypress arrives as one to three bytes, the longest VT escape a key
	// can produce is well under this threshold, and even key-repeat arrives as
	// a stream of small reads rather than one large one. A paste arrives as a
	// single large read.
	//
	// Set well above the longest escape sequence and well below any plausible
	// paste, so both error directions are unlikely rather than balanced.
	pasteBurstBytes = 24

	// killLine is Ctrl+U — "erase the whole line" in readline, which psql,
	// mongosh, redis-cli and any shell reached over SSH all use.
	//
	// Chosen over Ctrl+C (0x03) deliberately: by the time a full command is
	// recognised its characters have already been relayed to the tool as they
	// were typed, so something has to unwind them. Ctrl+C would also work in a
	// REPL but escalates to SIGINT in a non-REPL child, which could kill the
	// operator's session over a blocked command rather than just refusing it.
	// Ctrl+U discards the pending line and nothing else.
	killLine = 0x15
)

// BlockedCommand is one refused command, for the session's command log.
type BlockedCommand struct {
	Command string `json:"command"`
	Pattern string `json:"pattern"`
}

// Guard enforces a Policy across a session's input and output streams.
//
// Not safe for concurrent use. The ConPTY relay calls OnInput from its input
// goroutine and OnOutput from its output goroutine, which touch disjoint
// fields — the counters each side owns are never read by the other until the
// session ends and both goroutines have finished.
type Guard struct {
	// Both relays drive a Guard from two goroutines at once — one carrying
	// keystrokes to the tool, one carrying output back — and Summary() reads
	// everything both of them write, after the session ends but while the
	// input goroutine can still be blocked in a read. The two directions touch
	// disjoint fields, so nothing was ever miscounted in practice, but it is
	// still a data race, and `go test -race` is right to call it one.
	mu sync.Mutex

	policy Policy

	// line is the command as typed so far, reconstructed the same way
	// lineAccumulator does it, because a command can only be judged once it is
	// complete and it arrives one keystroke at a time.
	line []rune

	pasteBlocked int
	blocked      []BlockedCommand
	outputBytes  int64
	capped       bool
}

func NewGuard(p Policy) *Guard { return &Guard{policy: p} }

// InputAction is what the relay should do with a chunk of console input.
type InputAction struct {
	// Forward is what to write to the child. Empty means write nothing.
	Forward []byte
	// Notice is text to show the operator on their own console, so a refusal
	// is visible rather than looking like the terminal swallowed a keystroke.
	Notice string
	// BlockedPaste / BlockedCommand record what happened, for auditing.
	BlockedPaste   bool
	BlockedCommand string
}

// OnInput decides what to do with one console read.
func (g *Guard) OnInput(chunk []byte) InputAction {
	if len(chunk) == 0 {
		return InputAction{}
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	if !g.policy.Active() {
		return InputAction{Forward: chunk}
	}

	// A paste is dropped whole, including any Enter inside it — forwarding the
	// text and only refusing the newline would leave a half-typed command on
	// the operator's prompt, which reads as a glitch rather than a decision.
	if g.policy.BlockClipboard && len(chunk) >= pasteBurstBytes {
		g.pasteBlocked++
		return InputAction{
			BlockedPaste: true,
			Notice:       "\r\n\x1b[33m[PAM] Paste is disabled for this session.\x1b[0m\r\n",
		}
	}

	if len(g.policy.DeniedCommands) == 0 {
		g.trackLine(chunk)
		return InputAction{Forward: chunk}
	}

	// Split at the first line terminator: everything before it completes the
	// current command, and the decision has to happen before that terminator
	// reaches the child.
	idx := indexAnyByte(chunk, '\r', '\n')
	if idx < 0 {
		g.trackLine(chunk)
		return InputAction{Forward: chunk}
	}

	g.trackLine(chunk[:idx])
	command := strings.TrimSpace(string(g.line))
	g.line = g.line[:0]

	if pattern, denied := g.deniedBy(command); denied {
		g.blocked = append(g.blocked, BlockedCommand{Command: command, Pattern: pattern})
		// Erase the pending line instead of submitting it. The characters were
		// already relayed as they were typed, so refusing the Enter alone
		// would leave the command sitting on the prompt ready to be submitted
		// by pressing Enter again.
		return InputAction{
			Forward: []byte{killLine},
			Notice: fmt.Sprintf(
				"\r\n\x1b[31m[PAM] Blocked: this command is not permitted on this resource (%s).\x1b[0m\r\n",
				pattern),
			BlockedCommand: command,
		}
	}

	return InputAction{Forward: chunk}
}

// OnOutput meters the child's output against the session's budget.
//
// Returns the bytes the relay may still show and whether the session has hit
// its limit. The cap is enforced on the way to the operator's screen, which is
// the last point the agent controls — anything already written is gone.
func (g *Guard) OnOutput(chunk []byte) (forward []byte, capped bool, notice string) {
	g.mu.Lock()
	defer g.mu.Unlock()

	if g.capped {
		return nil, true, ""
	}
	if g.policy.MaxEgressBytes <= 0 {
		g.outputBytes += int64(len(chunk))
		return chunk, false, ""
	}

	remaining := g.policy.MaxEgressBytes - g.outputBytes
	if remaining <= 0 {
		g.capped = true
		return nil, true, g.capNotice()
	}
	if int64(len(chunk)) <= remaining {
		g.outputBytes += int64(len(chunk))
		return chunk, false, ""
	}

	// Truncate at the boundary rather than letting the whole chunk through:
	// a budget that can be overshot by one read of arbitrary size is not a
	// budget.
	g.outputBytes = g.policy.MaxEgressBytes
	g.capped = true
	return chunk[:remaining], true, g.capNotice()
}

func (g *Guard) capNotice() string {
	return fmt.Sprintf(
		"\r\n\x1b[31m[PAM] Output limit reached (%d bytes). This session has been closed.\x1b[0m\r\n",
		g.policy.MaxEgressBytes)
}

// trackLine reconstructs the command being typed, handling the editing keys
// that would otherwise make the reconstruction wrong.
//
// Deliberately simple, and the limits are the same ones lineAccumulator
// documents: it cannot know what a tab-completion expanded to or what history
// recall pulled in. That matters here, because a command assembled by those
// means may not be recognised. It is a real gap, not a rounding error — and
// the reason the output budget rather than the deny list is the control that
// bounds the worst case.
func (g *Guard) trackLine(chunk []byte) {
	for _, r := range string(chunk) {
		switch {
		case r == 0x7F || r == 0x08: // backspace / delete
			if len(g.line) > 0 {
				g.line = g.line[:len(g.line)-1]
			}
		case r == killLine: // the operator erasing their own line
			g.line = g.line[:0]
		case r == 0x1B: // start of an escape sequence: arrow keys, tab expansion
			// Not modelled. Anything after this in the same chunk is dropped
			// from the reconstruction rather than corrupting it with control
			// bytes that were never characters of the command.
			return
		case r == '\r' || r == '\n':
			g.line = g.line[:0]
		case unicode.IsPrint(r):
			g.line = append(g.line, r)
		}
	}
}

// deniedBy reports which pattern refuses a command, if any.
//
// Matching is case-insensitive and anchored to a token boundary, because a
// bare substring test refuses far too much: a resource with a column named
// "copy" would make every SELECT that mentions it unrunnable, and a control
// that blocks legitimate work gets switched off.
func (g *Guard) deniedBy(command string) (string, bool) {
	if command == "" {
		return "", false
	}
	lower := strings.ToLower(command)
	for _, raw := range g.policy.DeniedCommands {
		pattern := strings.ToLower(strings.TrimSpace(raw))
		if pattern == "" {
			continue
		}
		if matchesAtTokenBoundary(lower, pattern) {
			return strings.TrimSpace(raw), true
		}
	}
	return "", false
}

// matchesAtTokenBoundary finds pattern in line only where it forms a whole
// token — bounded on BOTH sides.
//
// Checking only the leading side is not enough, and the failure is the kind
// that gets a control switched off: with "copy" in the deny list, a perfectly
// ordinary "select copy_count from stats" was refused, because the match was
// preceded by a space and nothing looked at what followed it. The same held
// for pg_dump against a table called pg_dumpster. Both edges have to be a
// break, or the pattern is a prefix of a longer identifier rather than the
// command itself.
func matchesAtTokenBoundary(line, pattern string) bool {
	from := 0
	for {
		i := strings.Index(line[from:], pattern)
		if i < 0 {
			return false
		}
		at := from + i
		end := at + len(pattern)

		startOK := at == 0 || isTokenBreak(rune(line[at-1]))
		endOK := end >= len(line) || isTokenBreak(rune(line[end]))
		if startOK && endOK {
			return true
		}

		from = at + 1
		if from >= len(line) {
			return false
		}
	}
}

// isTokenBreak is what separates one token from the next. Quotes and
// redirection characters count, because the commands being matched are
// routinely written straight against them — \o'/tmp/x' and copy>file both
// need their pattern to end at a break.
func isTokenBreak(r rune) bool {
	if unicode.IsSpace(r) {
		return true
	}
	switch r {
	case ';', '(', ')', ',', '|', '&', '\'', '"', '>', '<', '=':
		return true
	}
	return false
}

func indexAnyByte(b []byte, targets ...byte) int {
	for i, c := range b {
		for _, t := range targets {
			if c == t {
				return i
			}
		}
	}
	return -1
}

// ── Session summary, reported to PAM at the end of the launch ─────────────

// Summary is what the agent tells PAM about enforcement for this session.
//
// Sent at session end rather than per event: the agent is a short-lived local
// process on someone's laptop, and a chatty violation endpoint would be both
// unreliable and a way to have the operator's machine drive load on the API.
// The blocked commands land in the session's own command log, which is where
// an investigator already looks.
type Summary struct {
	Enforced        bool             `json:"enforced"`
	PasteBlocked    int              `json:"paste_blocked"`
	CommandsBlocked []BlockedCommand `json:"commands_blocked"`
	OutputBytes     int64            `json:"output_bytes"`
	OutputCapped    bool             `json:"output_capped"`
}

func (g *Guard) Summary() Summary {
	if g == nil {
		return Summary{}
	}
	g.mu.Lock()
	defer g.mu.Unlock()

	return Summary{
		Enforced:        g.policy.Active(),
		PasteBlocked:    g.pasteBlocked,
		CommandsBlocked: g.blocked,
		OutputBytes:     g.outputBytes,
		OutputCapped:    g.capped,
	}
}

// DefaultDeniedCommands is the fallback deny list per resource type, used when
// a resource enables command blocking without naming its own patterns.
//
// These are the bulk-extraction verbs for each tool — the ones that move a
// whole table or bucket somewhere the agent cannot see. Deliberately short:
// every entry costs an operator some legitimate capability, so the list holds
// only commands whose main purpose is exfiltration.
var DefaultDeniedCommands = map[string][]string{
	"postgresql": {`\copy`, "copy", "pg_dump", `\o`, `\out`},
	"mysql":      {"mysqldump", "into outfile", "into dumpfile"},
	"mongodb":    {"mongoexport", "mongodump"},
	"redis":      {"save", "bgsave", "debug reload", "keys *"},
	"minio":      {"mirror", "cp --recursive"},
	"ssh":        {"tar", "scp", "base64", "dd"},
}
