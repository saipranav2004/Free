//go:build darwin

// pam-agent/internal/launcher/spawn_darwin.go
package launcher

import (
	"fmt"
	"os"
	"os/exec"
	"strings"

	"github.com/yourorg/pam-agent/internal/recorder"
)

// Spawn dispatches on pc.Mode:
//
//   - "gui": launches the GUI tool directly — via `open -a <bundle>` when
//     discovery found it as a .app bundle (pc.AppBundle set), or a direct
//     exec when it's a plain binary path. No Terminal.app involved.
//     Session-end tracking isn't available here, same as the "cli" path
//     below.
//   - "cli" (default): opens a new Terminal.app window running the
//     command. Terminal's "do script" starts a brand-new login shell that
//     does NOT inherit this process's environment, so pc.Env entries are
//     folded into a generated wrapper script instead (as `export
//     KEY=VALUE` lines) — only the wrapper script's file PATH ever appears
//     in the AppleScript/osascript argument list, never the credential.
//     The wrapper is a 0700 temp file added to pc.CleanupFiles for the
//     caller to remove shortly after this returns.
//
// Neither path blocks until the window/app actually closes — osascript
// returns as soon as it hands the script to Terminal, and `open`/a direct
// GUI exec return immediately too. That is why this function does not report
// the session end and sets EndReportedByWrapper instead: the exact end is
// known inside the window, not out here.
//
// rec is ignored here, but the session IS recorded: the capture belongs to
// `pam-agent relay`, which the wrapper runs inside the terminal this function
// opens. It has to live there rather than in this process, because this
// process has no terminal to relay — the whole reason a terminal emulator is
// being asked for at all. The relay holds a pty with the tool inside it and
// uploads the asciicast itself when the tool exits, so `launch` deliberately
// skips its own upload for these platforms (see cmd/pam-agent/main.go).
func Spawn(pc *PreparedCommand, rec *recorder.Cast) (waited bool, enforcement Summary, err error) {
	if pc.Mode == "gui" {
		if pc.AppBundle != "" {
			args := append([]string{"-a", pc.AppBundle, "--args"}, pc.Args...)
			c := exec.Command("open", args...)
			c.Env = append(os.Environ(), pc.Env...)
			return false, enforcement, c.Start()
		}
		c := exec.Command(pc.Exec, pc.Args...)
		c.Env = append(os.Environ(), pc.Env...)
		return false, enforcement, c.Start()
	}

	// The wrapper now also reports this session's end, because osascript
	// returns as soon as Terminal.app accepts the script and nothing else is
	// left alive to notice the window closing.
	wrapperPath, err := writeSessionWrapper(pc, EndReport{
		AgentPath: pc.AgentPath, ServerURL: pc.ServerURL, SessionID: pc.SessionID,
		PolicyJSON: pc.PolicyJSON, Record: pc.Record,
		RelayRequired: pc.Record || pc.Policy.Active(),
	})
	if err != nil {
		return false, enforcement, err
	}
	pc.CleanupFiles = append(pc.CleanupFiles, wrapperPath)
	pc.EndReportedByWrapper = true

	script := fmt.Sprintf(`tell application "Terminal" to do script "/bin/bash %s"`, appleScriptQuote(wrapperPath))
	c := exec.Command("osascript", "-e", script)
	err = c.Run()
	return false, enforcement, err
}

func appleScriptQuote(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	return s
}
