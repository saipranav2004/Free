//go:build darwin

// pam-agent/internal/launcher/pty_darwin.go
//
// Pseudo-terminal allocation on macOS. Same contract as pty_linux.go; the
// ioctls differ, which is the only reason the two are separate files.
//
// macOS has no TIOCGPTN — instead of returning an index to build a path from,
// it hands back the slave's name directly via TIOCPTYGNAME, and grant and
// unlock are two distinct calls rather than one lock flag.
package launcher

import (
	"bytes"
	"fmt"
	"os"
	"syscall"
	"unsafe"
)

// openPTY returns the master and the slave of a fresh pseudo-terminal pair.
func openPTY() (master, slave *os.File, err error) {
	m, err := os.OpenFile("/dev/ptmx", os.O_RDWR, 0)
	if err != nil {
		return nil, nil, fmt.Errorf("open /dev/ptmx: %w", err)
	}
	defer func() {
		if err != nil {
			m.Close()
		}
	}()

	// grant then unlock, in that order: grant fixes the slave's ownership and
	// permissions to the calling user, unlock makes it openable.
	if e := ioctl(m.Fd(), syscall.TIOCPTYGRANT, 0); e != nil {
		return nil, nil, fmt.Errorf("grant pty: %w", e)
	}
	if e := ioctl(m.Fd(), syscall.TIOCPTYUNLK, 0); e != nil {
		return nil, nil, fmt.Errorf("unlock pty: %w", e)
	}

	// 128 bytes is the size the darwin ioctl expects to write into; a shorter
	// buffer is a memory-corruption bug rather than a truncated string.
	name := make([]byte, 128)
	if e := ioctl(m.Fd(), syscall.TIOCPTYGNAME, uintptr(unsafe.Pointer(&name[0]))); e != nil {
		return nil, nil, fmt.Errorf("get pty name: %w", e)
	}
	if i := bytes.IndexByte(name, 0); i >= 0 {
		name = name[:i]
	}

	// O_NOCTTY: the slave must not become THIS process's controlling terminal.
	// The child claims it with TIOCSCTTY after setsid (see relay_unix.go).
	s, err := os.OpenFile(string(name), os.O_RDWR|syscall.O_NOCTTY, 0)
	if err != nil {
		return nil, nil, fmt.Errorf("open pty slave %q: %w", name, err)
	}
	return m, s, nil
}

func getTermios(fd uintptr) (syscall.Termios, error) {
	var t syscall.Termios
	if err := ioctl(fd, syscall.TIOCGETA, uintptr(unsafe.Pointer(&t))); err != nil {
		return t, err
	}
	return t, nil
}

func setTermios(fd uintptr, t syscall.Termios) error {
	return ioctl(fd, syscall.TIOCSETA, uintptr(unsafe.Pointer(&t)))
}
