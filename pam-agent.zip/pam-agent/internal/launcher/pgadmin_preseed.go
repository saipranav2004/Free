// pam-agent/internal/launcher/pgadmin_preseed.go
//
// Best-effort pre-fill for pgAdmin4: host/port/username only — NEVER the
// password, which pgAdmin4 always prompts for on first connect regardless
// of how the server entry was created. This directly implements the
// product decision that GUI auto-login should pre-fill connection details
// and let the operator enter the password once themselves.
package launcher

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

// pgAdminServersFile mirrors the shape pgAdmin4's own `--load-servers`
// switch expects (a top-level "Servers" object keyed by an arbitrary
// integer ID). Documented at
// https://www.pgadmin.org/docs/pgadmin4/latest/import_export_servers.html
// — this is pgAdmin4's own supported mechanism, not something reverse
// engineered.
type pgAdminServersFile struct {
	Servers map[string]pgAdminServerEntry `json:"Servers"`
}

type pgAdminServerEntry struct {
	Name          string `json:"Name"`
	Group         string `json:"Group"`
	Host          string `json:"Host"`
	Port          int    `json:"Port"`
	MaintenanceDB string `json:"MaintenanceDB"`
	Username      string `json:"Username"`
	SSLMode       string `json:"SSLMode"`
}

// writePgAdminServersFile writes a pgAdmin4 servers-import JSON (0600, temp
// dir) containing only host/port/database/username for the resolved
// resource — never the password.
func writePgAdminServersFile(tempDir string, resolved *apiclient.ResolvedLaunch, dbName string) (string, error) {
	if dbName == "" {
		dbName = "postgres"
	}

	doc := pgAdminServersFile{
		Servers: map[string]pgAdminServerEntry{
			"1": {
				Name:          fmt.Sprintf("PAM - %s", resolved.Host),
				Group:         "PAM",
				Host:          resolved.Host,
				Port:          resolved.Port,
				MaintenanceDB: dbName,
				Username:      resolved.AccountName,
				SSLMode:       "prefer",
			},
		},
	}

	raw, err := json.MarshalIndent(doc, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to encode pgAdmin4 servers file: %w", err)
	}

	f, err := os.CreateTemp(tempDir, "pam-agent-*.pgadmin-servers.json")
	if err != nil {
		return "", fmt.Errorf("failed to create temp pgAdmin4 servers file: %w", err)
	}
	defer f.Close()
	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp pgAdmin4 servers file: %w", err)
	}
	if _, err := f.Write(raw); err != nil {
		return "", fmt.Errorf("failed to write temp pgAdmin4 servers file: %w", err)
	}
	return f.Name(), nil
}

// RunPgAdminPreseed invokes `<pgAdminExec> --load-servers <path>` as a
// best-effort pre-step before the GUI itself is spawned. This is
// deliberately non-fatal and swallows its own error (returning it only for
// logging) — pgAdmin4's exact CLI surface for this varies across install
// types (desktop/Electron build vs. the Python `pip install pgadmin4`
// package vs. server-mode deployments), so a failure here just means the
// operator adds the connection by hand in pgAdmin4 instead of it being
// pre-filled; it must never block the GUI from opening at all.
func RunPgAdminPreseed(execPath, appBundle, serversFilePath string) error {
	target := execPath
	if target == "" && appBundle != "" {
		// macOS app bundle: run its preseed via `open -a <bundle> --args ...`
		// so pgAdmin4 sees the same argv it would from a direct exec.
		c := exec.Command("open", "-a", appBundle, "-W", "--args", "--load-servers", serversFilePath)
		return c.Run()
	}
	if target == "" {
		return fmt.Errorf("no executable path resolved for pgAdmin4 preseed")
	}
	return exec.Command(target, "--load-servers", serversFilePath).Run()
}
