// pam-agent/internal/launcher/keylog.go
//
// lineAccumulator reconstructs typed "lines" (commands) from a raw
// keystroke byte stream — the input half of a ConPTY relay carries no
// concept of "one command" the way the browser gateway's line-based
// protocol runners do (they read one full WS message per submitted line);
// here it's just bytes as the operator types them, one keystroke at a
// time, including editing (backspace) and special keys (arrow keys, tab
// completion) encoded as VT escape sequences since the console is in raw
// input mode (see setRawConsoleMode in conpty_windows.go).
//
// This is deliberately a best-effort reconstruction, not a faithful one:
// it strips escape sequences and applies simple backspace handling, but it
// cannot know what a tab-completion actually expanded to, or what
// arrow-key history recall pulled in — those interactions are invisible to
// a plain "printable bytes + backspace + enter" model. It exists so the
// structured, searchable command log (models.SessionRecordingCommand) isn't
// simply empty for native-agent sessions; the byte-for-byte replay in the
// uploaded cast is still the authoritative record of what actually
// happened on screen.
package launcher

// lineAccumulator processes a raw input byte stream incrementally and
// emits one string each time the operator presses Enter, via onLine. Not
// safe for concurrent Feed calls — the ConPTY input-relay goroutine is the
// only caller, one call at a time, which matches how it's used.
type lineAccumulator struct {
	buf      []rune
	inEscape bool
	escKind  rune // 0 (not yet determined), '[' (CSI) or ']' (OSC) — the two kinds terminate differently, see feedRune
	onLine   func(line string)
}

func newLineAccumulator(onLine func(line string)) *lineAccumulator {
	return &lineAccumulator{onLine: onLine}
}

// Feed processes one chunk of raw input bytes (exactly what was just read
// from the console and is about to be relayed into the ConPTY). UTF-8
// multi-byte sequences split across two Feed calls are handled correctly
// as long as each call's bytes are appended before decoding — accumulating
// into a []byte first, rather than converting per-call, is what makes that
// safe.
func (a *lineAccumulator) Feed(chunk []byte) {
	for _, r := range string(chunk) {
		a.feedRune(r)
	}
}

func (a *lineAccumulator) feedRune(r rune) {
	if a.inEscape {
		if a.escKind == 0 {
			// Only CSI (ESC '[') and OSC (ESC ']') sequences are expected
			// from a console in VT input mode; anything else ends the
			// escape immediately rather than risk consuming the rest of
			// the line waiting for a terminator that will never come.
			if r == '[' || r == ']' {
				a.escKind = r
				return
			}
			a.inEscape = false
			return
		}
		switch a.escKind {
		case '[':
			// CSI final byte: an ASCII letter/symbol in 0x40-0x7E ends the
			// sequence — everything in between (parameters like "1;5") is
			// discarded, never added to the reconstructed line.
			if r >= 0x40 && r <= 0x7e {
				a.inEscape = false
			}
		case ']':
			// OSC is terminated by BEL, not a CSI-style final byte — an
			// OSC payload (e.g. a window-title string) can itself contain
			// letters, which would end a CSI sequence but must NOT end an
			// OSC one. A second ESC (starting the alternate "ESC \" String
			// Terminator form) is treated the same way, as a safety net
			// against getting stuck if BEL never arrives.
			if r == 0x07 || r == 0x1b {
				a.inEscape = false
			}
		}
		return
	}

	switch r {
	case 0x1b: // ESC — start of a special-key sequence, see above.
		a.inEscape = true
		a.escKind = 0
	case '\r', '\n':
		a.emit()
	case 0x08, 0x7f: // backspace / DEL
		if len(a.buf) > 0 {
			a.buf = a.buf[:len(a.buf)-1]
		}
	default:
		if r == '\t' || r >= 0x20 {
			a.buf = append(a.buf, r)
		}
		// Other C0 control bytes (bell, etc.) are dropped — never
		// meaningful content for a reconstructed command line.
	}
}

func (a *lineAccumulator) emit() {
	if len(a.buf) == 0 {
		return
	}
	line := string(a.buf)
	a.buf = a.buf[:0]
	if a.onLine != nil {
		a.onLine(line)
	}
}
