package launcher

import (
	"encoding/json"
	"os"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

func TestWritePgAdminServersFile(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql",
		Host:         "10.0.3.30",
		Port:         5433,
		AccountName:  "app_reader",
		Password:     "should-never-appear-anywhere",
	}

	path, err := writePgAdminServersFile(tempDir, resolved, "appdb")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	fi, err := os.Stat(path)
	if err != nil {
		t.Fatalf("temp file not created: %v", err)
	}
	if perm := fi.Mode().Perm(); perm != 0o600 {
		t.Fatalf("got permissions %o, want 0600", perm)
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	// The password must not appear ANYWHERE in this file — pgAdmin4 always
	// prompts for it on first connect, by design (see the package doc
	// comment): this preseed mechanism only ever carries host/port/
	// database/username.
	if strings.Contains(string(raw), resolved.Password) {
		t.Fatal("password leaked into the pgAdmin4 servers preseed file — this must only ever contain host/port/database/username")
	}

	var doc pgAdminServersFile
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatalf("written file is not valid JSON: %v\ncontent: %s", err, raw)
	}
	entry, ok := doc.Servers["1"]
	if !ok {
		t.Fatal(`expected a "1" entry under "Servers"`)
	}
	if entry.Host != resolved.Host {
		t.Errorf("host = %q, want %q", entry.Host, resolved.Host)
	}
	if entry.Port != resolved.Port {
		t.Errorf("port = %d, want %d", entry.Port, resolved.Port)
	}
	if entry.Username != resolved.AccountName {
		t.Errorf("username = %q, want %q", entry.Username, resolved.AccountName)
	}
	if entry.MaintenanceDB != "appdb" {
		t.Errorf("maintenance db = %q, want %q", entry.MaintenanceDB, "appdb")
	}
}

func TestWritePgAdminServersFileDefaultsMaintenanceDB(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{Host: "10.0.3.30", Port: 5432, AccountName: "app_reader"}

	path, err := writePgAdminServersFile(tempDir, resolved, "")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	raw, _ := os.ReadFile(path)
	var doc pgAdminServersFile
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if doc.Servers["1"].MaintenanceDB != "postgres" {
		t.Errorf("expected default maintenance db %q, got %q", "postgres", doc.Servers["1"].MaintenanceDB)
	}
}
