//go:build !windows

// pam-agent/internal/launcher/shutdown_other.go
package launcher

// SignalShutdownComplete is a no-op on Linux/macOS: only the Windows
// ConPTY path (see conpty_windows.go) has a console-close handler waiting
// on this. Exists here purely so cmd/pam-agent/main.go can call it
// unconditionally without a per-OS build tag of its own.
func SignalShutdownComplete() {}
