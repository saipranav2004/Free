package launcher

import (
	"encoding/xml"
	"os"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

func TestBuildOracleConnectString(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "oracle",
		Host:         "10.0.1.50",
		Port:         1521,
		DatabaseName: "ORCLPDB1",
		AccountName:  "scott",
		Password:     "tiger123",
	}

	got, err := buildOracleConnectString(resolved, resolved.DatabaseName)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	want := "scott/tiger123@10.0.1.50:1521/ORCLPDB1"
	if got != want {
		t.Fatalf("got %q, want %q", got, want)
	}
}

func TestBuildOracleConnectStringRequiresServiceName(t *testing.T) {
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "oracle",
		Host:         "10.0.1.50",
		Port:         1521,
		AccountName:  "scott",
		Password:     "tiger123",
	}
	if _, err := buildOracleConnectString(resolved, ""); err == nil {
		t.Fatal("expected an error when database_name/service name is empty")
	}
}

func TestBuildOracleConnectStringRefusesUnescapableCredential(t *testing.T) {
	cases := []struct {
		name     string
		password string
	}{
		{"at-sign", "ti@ger"},
		{"slash", "ti/ger"},
		{"whitespace", "ti ger"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			resolved := &apiclient.ResolvedLaunch{
				Host: "10.0.1.50", Port: 1521, DatabaseName: "ORCLPDB1",
				AccountName: "scott", Password: tc.password,
			}
			_, err := buildOracleConnectString(resolved, resolved.DatabaseName)
			if err == nil {
				t.Fatalf("expected an error for password %q", tc.password)
			}
			if !strings.Contains(err.Error(), "cannot escape") {
				t.Fatalf("unexpected error message: %v", err)
			}
		})
	}
}

func TestBuildMinIOAliasEnv(t *testing.T) {
	cases := []struct {
		name   string
		useSSL interface{}
		want   string
	}{
		// Raw, NOT percent-encoded — mc's own MC_HOST_<alias> parser splits on
		// the last '@' and first ':' and never URL-decodes, so the '@' in
		// this password must survive verbatim (see buildMinIOAliasEnv's
		// bugfix comment; this exact case reproduces a live
		// SignatureDoesNotMatch caused by encoding it).
		{"plain http default", nil, "MC_HOST_pam=http://minioadmin:DasAdmin@123@13.206.221.6:9000"},
		{"explicit http", false, "MC_HOST_pam=http://minioadmin:DasAdmin@123@13.206.221.6:9000"},
		{"explicit https", true, "MC_HOST_pam=https://minioadmin:DasAdmin@123@13.206.221.6:9000"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			resolved := &apiclient.ResolvedLaunch{
				ResourceType: "minio",
				Host:         "13.206.221.6",
				Port:         9000,
				AccountName:  "minioadmin",
				Password:     "DasAdmin@123",
				ExtraConfig:  map[string]interface{}{},
			}
			if tc.useSSL != nil {
				resolved.ExtraConfig["use_ssl"] = tc.useSSL
			}
			got := buildMinIOAliasEnv(resolved)
			if got != tc.want {
				t.Fatalf("got %q, want %q", got, tc.want)
			}
		})
	}
}

func TestResolveInteractiveShellFindsSomething(t *testing.T) {
	// Every CI/dev machine this runs on has SOME shell reachable — on
	// Windows that's cmd.exe (always on PATH), on Unix at minimum /bin/sh.
	// This doesn't assert a specific path (that's host-dependent) — only
	// that resolution actually succeeds, matching what minio_mc_shell's
	// buildCommand case depends on.
	path, err := resolveInteractiveShell()
	if err != nil {
		t.Fatalf("expected to resolve an interactive shell on this machine, got error: %v", err)
	}
	if path == "" {
		t.Fatal("expected a non-empty shell path")
	}
}

// TestCopyToClipboard is best-effort by design, matching CopyToClipboard's
// own contract: clipboard access can legitimately fail in a headless/no-
// desktop-session CI runner (no clip.exe-equivalent session, a Linux runner
// with none of xclip/xsel/wl-copy installed), which is not a code defect —
// skip rather than fail in that case. On a real desktop session (like the
// one this was verified against), it should succeed.
func TestCopyToClipboard(t *testing.T) {
	want := "pam-clipboard-test-DasAdmin@123"
	if err := CopyToClipboard(want); err != nil {
		t.Skipf("no clipboard mechanism available in this environment: %v", err)
	}
}

func TestWriteClickhouseConfigFile(t *testing.T) {
	tempDir := t.TempDir()
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "clickhouse",
		Host:         "10.0.2.20",
		Port:         9000,
		DatabaseName: "analytics",
		AccountName:  "chuser",
		Password:     "sup3r<secret>&pw",
	}

	path, err := writeClickhouseConfigFile(tempDir, resolved)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	fi, err := os.Stat(path)
	if err != nil {
		t.Fatalf("temp file not created: %v", err)
	}
	if perm := fi.Mode().Perm(); perm != 0o600 {
		t.Fatalf("got permissions %o, want 0600", perm)
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}

	var got clickhouseConfigXML
	if err := xml.Unmarshal(raw, &got); err != nil {
		t.Fatalf("written file is not valid XML: %v\ncontent: %s", err, raw)
	}
	if got.User != resolved.AccountName {
		t.Errorf("user = %q, want %q", got.User, resolved.AccountName)
	}
	if got.Password != resolved.Password {
		t.Errorf("password = %q, want %q — special characters must round-trip through XML escaping intact", got.Password, resolved.Password)
	}
	if got.Host != resolved.Host {
		t.Errorf("host = %q, want %q", got.Host, resolved.Host)
	}
	if got.Port != resolved.Port {
		t.Errorf("port = %d, want %d", got.Port, resolved.Port)
	}
	if got.Database != resolved.DatabaseName {
		t.Errorf("database = %q, want %q", got.Database, resolved.DatabaseName)
	}

	// The credential must never appear in plaintext anywhere BUT inside a
	// properly-escaped XML text node — spot check that the raw '&' and '<'
	// weren't written verbatim (which would corrupt the document or, worse,
	// silently truncate the password when a naive parser hit the '<').
	if strings.Contains(string(raw), "sup3r<secret>&pw") {
		t.Fatal("password appears unescaped in the raw XML — special characters were not encoded")
	}
}
