// pam-agent/internal/recorder/cast.go
//
// Cast builds an asciicast v2 stream — a JSON header line followed by one
// JSON array per event ([relative_time_seconds, "i"|"o", data]) — out of the
// raw bytes relayed through a ConPTY-backed local launch (see
// internal/launcher/spawn_windows.go). This is a deliberate, small
// reimplementation of the exact same format the PAM server's own
// internal/recorder/cast.go produces for browser-terminal sessions, not a
// shared dependency: that package is internal to the pam module and
// physically can't be imported from this one, and pam-agent's own
// zero-third-party-dependency invariant (see README) rules out reaching for
// an asciicast library instead. Reusing the format itself (rather than
// inventing a new one) is what lets the existing PAM admin recording player
// replay an agent-captured session with no changes on that side at all.
package recorder

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

type castHeader struct {
	Version   int    `json:"version"`
	Width     int    `json:"width"`
	Height    int    `json:"height"`
	Timestamp int64  `json:"timestamp"`
	Title     string `json:"title,omitempty"`
}

// Command is one line the input relay's line-accumulator (see
// internal/launcher/keylog.go) reconstructed from raw keystrokes.
// OffsetMs is milliseconds since the recording started, mirroring the
// asciicast events' own relative timestamps — the PAM server uses it to
// approximate this line's OccurredAt, since there is no other per-line
// timestamp signal available from a raw keystroke stream.
type Command struct {
	Input    string `json:"input"`
	OffsetMs int64  `json:"offset_ms"`
}

// Cast incrementally builds an asciicast v2 recording. Safe for concurrent
// use — the two relay goroutines in spawn_windows.go (console-in-to-ConPTY,
// ConPTY-out-to-console) both write into the same Cast concurrently.
type Cast struct {
	mu       sync.Mutex
	buf      bytes.Buffer
	started  time.Time
	commands []Command
}

// NewCast starts a new recording. width/height are cosmetic metadata only,
// matching whatever the real console happened to be sized to at launch —
// a replay player just uses it to size its viewport.
func NewCast(width, height int, title string) *Cast {
	c := &Cast{started: time.Now()}
	hdr := castHeader{Version: 2, Width: width, Height: height, Timestamp: c.started.Unix(), Title: title}
	hdrJSON, _ := json.Marshal(hdr)
	c.buf.Write(hdrJSON)
	c.buf.WriteByte('\n')
	return c
}

// Input records bytes the operator typed (relayed from the real console
// into the ConPTY's input pipe).
func (c *Cast) Input(data []byte) { c.record("i", data) }

// Output records bytes the launched tool printed (relayed from the
// ConPTY's output pipe to the real console).
func (c *Cast) Output(data []byte) { c.record("o", data) }

// Command records one line the input relay's line-accumulator
// reconstructed from raw keystrokes — the structured, searchable
// counterpart to the raw byte-for-byte replay Input/Output build. See
// package doc comment on keylog.go for why this is best-effort.
func (c *Cast) Command(text string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.commands = append(c.commands, Command{Input: text, OffsetMs: time.Since(c.started).Milliseconds()})
}

// Commands returns every line captured via Command so far, in order.
func (c *Cast) Commands() []Command {
	c.mu.Lock()
	defer c.mu.Unlock()
	return append([]Command(nil), c.commands...)
}

func (c *Cast) record(stream string, data []byte) {
	if len(data) == 0 {
		return
	}
	event, err := json.Marshal([]interface{}{time.Since(c.started).Seconds(), stream, string(data)})
	if err != nil {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	c.buf.Write(event)
	c.buf.WriteByte('\n')
}

// Finalize returns the gzip-compressed cast bytes — the exact shape the PAM
// server's AttachRecordingArtifact/UploadLaunchRecording expects to receive
// and store as-is. Call once, after the launched process has exited.
func (c *Cast) Finalize() ([]byte, error) {
	c.mu.Lock()
	raw := append([]byte(nil), c.buf.Bytes()...)
	c.mu.Unlock()

	var gz bytes.Buffer
	w := gzip.NewWriter(&gz)
	if _, err := w.Write(raw); err != nil {
		return nil, fmt.Errorf("gzip write: %w", err)
	}
	if err := w.Close(); err != nil {
		return nil, fmt.Errorf("gzip close: %w", err)
	}
	return gz.Bytes(), nil
}
