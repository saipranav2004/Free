// Package logging gives pam-agent structured, leveled logs (stderr + a
// per-user log file) using nothing but the standard library's log/slog
// (stdlib since Go 1.21) — preserving the module's zero-third-party-Go-
// dependency invariant. No zap, no logrus: slog already gives us levels,
// structured key/value fields, and a stable text format for free.
package logging

import (
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
)

// maxLogFileBytes bounds how large agent.log is allowed to get before this
// process rotates it on startup. There's no background rotation goroutine
// and no third-party lumberjack-style dependency — pam-agent is a
// short-lived CLI process invoked once per action, so "rotate on startup if
// too big" is sufficient and keeps this file dependency-free.
const maxLogFileBytes = 5 * 1024 * 1024 // 5MB

// New creates a logger that writes every record to both stderr (so the
// operator sees it in their terminal / the OS routes it to a console
// window) and to <configDir>/logs/agent.log (so a support engineer can ask
// for the file after the fact — the OS-launched, non-terminal invocations,
// like a double-clicked pam-agent:// URL, have no visible stderr at all,
// which is exactly when the log file matters most).
//
// Returns a close func the caller should defer — it flushes/closes the
// underlying log file handle. If the log file can't be opened (e.g. a
// read-only config dir), New falls back to stderr-only logging rather than
// failing the whole command over a logging problem.
func New(configDir string, level slog.Level) (*slog.Logger, func()) {
	logDir := filepath.Join(configDir, "logs")
	logPath := filepath.Join(logDir, "agent.log")

	if err := os.MkdirAll(logDir, 0o700); err != nil {
		fmt.Fprintf(os.Stderr, "pam-agent: warning: could not create log directory %s: %v (logging to stderr only)\n", logDir, err)
		return stderrOnly(level), func() {}
	}

	rotateIfLarge(logPath, maxLogFileBytes)

	f, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		fmt.Fprintf(os.Stderr, "pam-agent: warning: could not open log file %s: %v (logging to stderr only)\n", logPath, err)
		return stderrOnly(level), func() {}
	}

	handler := slog.NewTextHandler(io.MultiWriter(os.Stderr, f), &slog.HandlerOptions{Level: level})
	logger := slog.New(handler)
	return logger, func() { _ = f.Close() }
}

func stderrOnly(level slog.Level) *slog.Logger {
	return slog.New(slog.NewTextHandler(os.Stderr, &slog.HandlerOptions{Level: level}))
}

// rotateIfLarge renames an oversized log file to agent.log.1 (clobbering
// any previous .1) before the new file handle is opened, bounding total
// on-disk log usage to roughly 2x maxLogFileBytes.
func rotateIfLarge(path string, maxBytes int64) {
	fi, err := os.Stat(path)
	if err != nil || fi.Size() < maxBytes {
		return
	}
	_ = os.Rename(path, path+".1")
}

// LevelFromString parses the PAM_AGENT_LOG_LEVEL environment variable
// ("debug" | "info" | "warn" | "error", case-insensitive), defaulting to
// Info so operators can turn up verbosity for a support session without a
// rebuild: PAM_AGENT_LOG_LEVEL=debug pam-agent launch "pam-agent://...".
func LevelFromString(s string) slog.Level {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "debug":
		return slog.LevelDebug
	case "warn", "warning":
		return slog.LevelWarn
	case "error":
		return slog.LevelError
	default:
		return slog.LevelInfo
	}
}
