# PAM — changed files from this session

Source only. **`backend_upd/.env` is deliberately not in this archive**: it holds
live RDS, MinIO, JWT, audit-HMAC and root-password values. Those should be
rotated and the file removed from version control. The compiled agent binaries
under `backend_upd/agents/` are left out too — they are build output that this
session's runs rebuilt, not changes to review; rebuild them from
`agent/pam-agent/`.

Everything below was driven against a running stack — Postgres, the API, the
built console in a real browser, the agent binary, and the web proxy — not
reasoned about. Numbers quoted are from those runs.

---

## Bugs found and fixed

### 1. Vaulted credentials could not be decrypted (the big one)
The vault moved to envelope encryption: the stored column became a JSON
document with the data key wrapped by the KMS and the row's identity bound in
as AAD. Everything that **writes** a credential moved with it. `ResourceService`,
which **reads** them to inject into a session, did not — it still called the raw
base64 AES path, so every credential written by the current vault failed at the
first character: `illegal base64 data at input byte 0`, because `{` is not base64.

One cause, three symptoms that each looked like their own bug:
brokered web sessions that would not open, native launches with no password,
and an agent flow that appeared to do nothing after the vault update.

Fixed in `internal/services/resource_service.go` (`decryptCredential`, plus
`WithKMS`, wired in `cmd/pam-api/main.go`). Legacy raw-AES rows still open.
Four tests in `credential_decrypt_test.go`, including one proving a ciphertext
moved to another row does **not** decrypt — the AAD binding is real.

### 2. MinIO object list spun forever (websocket 403)
Already fixed in this tree, by a different mechanism than "pass Host through":
the Director rewrites **Origin** to the target's own, so gorilla's default
`CheckOrigin` (`origin.Host == r.Host`) passes while `Host` stays the target's —
which is what apps that virtual-host route or build absolute URLs need.

Passing the browser Host through instead would also work, and preserves the
target's own CSRF check. Here that check is redundant: the proxy cookie is
`SameSite=Lax`, so a cross-site state-changing request never arrives with
credentials at all. Both were considered; the Origin rewrite is the one that
does not risk the apps.

New `websocket_upgrade_test.go` completes a **real 101 handshake** through the
proxy against an upstream applying gorilla's rule verbatim, with a negative
control proving that rule is actually in force.

### 3. Rows-per-page said 10 and served 20
`DEFAULT_PAGE_SIZE` was 20; the options were `[10, 25, 50, 100]`. A controlled
`<select>` whose value matches no option silently renders the **first** one — so
the control displayed "10" while fetching 20. And it was stuck: choosing "10"
from a select already showing "10" fires no change event. Affected Audit,
Recordings and JIT.

Fixed at the root (`withCurrent()` in `Pagination.jsx`) so the control can never
misreport what is being fetched, plus the default aligned to the ladder.

### 4. The console told operators to run a command that does not exist
The Devices screen said `pam-connector pair --code …`. The shipped binary is
**`pam-agent`**. Corrected in four places.

### 5. Two pairing panels, each minting a one-time code
`AgentDevicesPanel` rendered `PairAgentPanel` twice — once directly, once inside
a disclosure. A pairing code is single-use, so the code on screen could be the
dead one. This is the "same buttons repeating" report, and it was functional,
not cosmetic. Also removed the doubled section headings, and fixed
`undefined machines paired` (the payload is `{devices, count}`, not an array).

### 6. A table column that could never say anything
The safes table had a **Credentials** column and the endpoint never returned a
count, so every row read `-`. Added `ListSafesWithCounts` (one grouped query, no
per-row fan-out). Then removed the "Secrets held, by safe" insight card that was
only compensating for it — see *Analytics* below.

### Also caught, before shipping
Three bugs in the new insights service, each invisible to the compiler:
`occurred_at` written as `timestamp`; reveal counts keyed on audit actions
nothing emits (a confident flat zero); and `Group("1")`, which GORM quotes into
`GROUP BY "1"` — an identifier, not an ordinal — breaking every aggregate.

---

## Web-application resource type
`Web Application` is gone from the create form. It was a catch-all with no
integration behind it. Existing rows of that type still render their proper
label: `RESOURCE_TYPES` (creatable) and `RESOURCE_TYPE_LABELS` (displayable) are
now separate, because deriving the label map from the creatable list silently
downgrades retired rows to a raw enum.

## Analytics — asked of every page
The test applied was *can the table beneath this already say it?*

- **Sessions** — kept, and moved server-side. These counts were computed over
  the loaded rows against a 200-row cap, so past the cap they stopped being true
  while still looking like answers.
- **Service identities** — kept. "Ready" (a live token **and** a live grant) is
  the one thing a list showing everything as "active" cannot say.
- **Audit** — kept, and now follows the filter bar's own range, so one window
  describes both cards and table. Two plates that said "On this page" are gone.
- **Vault** — **one card removed.** With the Credentials column fixed, "Secrets
  held, by safe" was a worse copy of the row below it.

## Channels — all nine resource types
Driven against the live API; every type returns exactly the matrix it declares,
with `allowed` (policy) and `available` (device capability) reported separately.

## Web session recording
Verified end to end, not assumed: rrweb is injected under a strict
`script-src 'self'`, captures typing and DOM mutation, and lands as a replayable
`rrweb` recording served back for playback.

## Standard-user review
A real non-admin account was created and driven. All nine admin endpoints refuse
it; Admin Center is absent from navigation; a typed admin URL says so; its pages
render with **zero** refused requests — no controls offered that the server
rejects. Audit insights scoped server-side name only that user.

## Command palette, away digest, evidence export

### Command palette knows the verbs, not just the pages
`src/lib/actionRegistry.js` adds actions to global search: a registry of verbs
with the role each needs. Typing "revoke" now surfaces "Revoke a service token"
alongside the pages. The safety property is the one worth stating: **a
destructive verb never executes from the search box.** Selecting one navigates
to the screen that owns it, carrying an `intent=` parameter, and that screen's
own confirmation performs it. A search field is a control you use without
looking, which is the wrong input for "disable identity". Admin-only verbs are
not offered to an operator at all. Proven: selecting every destructive verb in
the registry fired **zero** POST/PATCH/DELETE requests.

### "While you were away"
The question every operator opens a console with had no answer anywhere in the
product. The bell answers a different one — a notification is addressed *to*
you, which is a much smaller set than what *happened*.

`GET /pam/insights/away` reads the audit chain against a per-account anchor
(`pam_users.digest_seen_at`), and `POST /pam/insights/away/seen` moves it. Four
decisions carry the feature:

- **Reading it does not clear it.** A dashboard that mounts three times before
  anybody looks would otherwise blank its own card. The anchor moves only on an
  explicit dismissal, stamped server-side — a fast client clock would skip a
  window nobody read.
- **It reports what HAPPENED, not who was LOOKING.** This is the difference
  between a digest and a hit counter. The request auditor files a row for every
  authenticated call, so over a live six-hour window **752 of 960 rows were
  generic request audits** and another 248 were list/read permission checks the
  console fired by being open. A card saying "960 events since you were away"
  reports that somebody had a browser tab open. The rule is now: an event
  belongs in the digest if it **changed something or was refused** — plus secret
  reads, because somebody *seeing* a credential is the one read this product
  exists to record.
- **It must not count itself.** Dismissing the card is an audited write, so the
  first working build left "1 event" behind — the dismissal — and the card came
  straight back. Found live, fixed, and pinned by a test.
- **Counts for the routine, names for the serious.** "3 critical events" is the
  one number nobody can act on, so break-glass use and refusals are listed
  individually with actor and target, each one a link.

A first visit gets a bounded seven-day window rather than all of history, and a
very old anchor is clamped the same way — "1,400 events since the beginning of
time" is not a digest. An operator's digest is scoped to their own activity and
never names another account.

The column is added by `database.EnsureUserDigestColumn`, which runs in **every**
environment including production — `AutoMigrate` is dev-only, so nothing else
would ever create it and the first request would fail with "column
digest_seen_at does not exist".

### PDF evidence export
Confirmed working end to end rather than rebuilt: `POST /pam/audit/report` with
`format: "pdf"` returns a real 294 KB PDF carrying the summary by user, the
event detail table, and the chain-integrity footer naming the last `EntryHash`
in range. The route is MFA-gated and scoped — a standard user asking for an
org-wide compliance file gets their own rows.

## Agent version floor
`internal/services/agent_version.go` lets the server refuse a launch from an
agent below a configured minimum (`agent.min_version`, default empty = off).
The refusal happens **before** the launch token is consumed, so a refused
attempt does not burn a single-use token, and it returns 426 with a reason that
names the fix. It **refuses what it cannot verify**: an agent reporting no
version at all is `unknown`, not `ok`. Five tests cover ordering (including
zero-padded components), antisymmetry, the no-floor no-op, and the refusal text.

## MinIO, for real

`web-recording.mjs` drives a stub shaped like the Object Browser. That proves
the proxy, the recorder and the storage path, and it proves nothing about
MinIO — its real CSP, its real websockets, its real login. The reported bug
("the object list spins forever") lived exactly in that gap, so
`minio-real.mjs` runs the same journey against **a MinIO server built from
source**, with its Console UI embedded. `harness/start-minio.sh` builds and
seeds it; the suite skips cleanly when no MinIO is listening.

Seventeen checks, and the ones that matter:

- **The operator is never shown a login form.** PAM logs into MinIO
  server-side with the vaulted credential (`auth_strategy: minio_console`) and
  hands over an authenticated session. The test asserts the secret appears
  nowhere in the delivered page.
- That credential is stored in **envelope form** — the exact shape that used
  to fail with `illegal base64 data at input byte 0`. A successful auto-login
  exercises this session's decryption fix against a real target rather than a
  fixture.
- **Every websocket the Console opens is accepted**, and a write through the
  brokered session (creating a bucket) reaches MinIO and comes back in the
  list. No 403, no spinner.
- The session records as **rrweb**, ~450 KB of real frames. Worth noting what
  the recorder stores for the login form: the access key in clear, the secret
  key as `**********************`. A session recorder should show you who
  signed in, not their password.

One finding from this run was in the HARNESS, not the product, and is worth
knowing if you run these yourself: a container that exports `HTTPS_PROXY`
whose `NO_PROXY` does not cover `*.pam.local` makes Chromium route brokered
WebSocket upgrades through that proxy, which answers **502** — plain HTTP to
the same host still works, so the page loads, login succeeds, and only the
WebSocket fails. That is an exact imitation of the bug under test, produced
entirely by the environment. Every browser suite now launches with
`--no-proxy-server`.

---

## Test suites (`test-harness/`)

`harness/up.sh` brings the stack back after a restart; `harness/login.sh` mints a
token (60-minute TTL). Seed scripts create the fixtures each suite needs.

| Suite | Checks | Covers |
|---|---|---|
| `insights.mjs` | 43 | Cards on every page, against server truth |
| `paging.mjs` | 24 | Server paging, sort allowlist, debounce, prefetch |
| `optimistic.mjs` | 6 | Optimistic reads **and** the privileged carve-out |
| `reported-bugs.mjs` | 17 | Resource type removal, rows-per-page |
| `standard-user.mjs` | 27 | Non-admin: leaks and dead controls |
| `devices-page.mjs` | 9 | CLI name, single pairing panel, one code |
| `vault-tree.mjs` | 9 | Hierarchy, one request, ARIA tree |
| `web-recording.mjs` | 11 | Brokered session screen capture |
| `command-palette.mjs` | 9 | Action verbs; destructive ones never execute |
| `away-digest.mjs` | 16 | Digest window, dismissal, scoping, self-count |
| `minio-real.mjs` | 17 | Real MinIO: auto-login, websockets, recording |

**265 checks across eighteen suites, all passing**, Go: every package green (13), including live-Postgres
insights and away-digest suites. Agent: builds and tests green.

## Known, and deliberately not touched
- `src/components/resources/ConnectPanel.jsx` is **dead code with a syntax
  error** (a ternary whose else-branch was commented out). Nothing imports it
  and the build excludes it. Deleting someone's file is the owner's call — but
  it should go.
- `pages/audit/AuditPage.jsx` is likewise unreachable: `/audit` redirects, and
  the live screen is `pages/admin/AdminAuditPage.jsx`.
- Windows and macOS agent behaviour cannot be validated here; this container is
  Linux only.
