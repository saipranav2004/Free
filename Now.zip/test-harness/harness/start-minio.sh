#!/bin/bash
# A real MinIO for e2e/minio-real.mjs.
#
# e2e/web-recording.mjs drives a stub shaped like the Object Browser, which is
# fast and always available. It cannot tell you anything about MinIO itself —
# its real CSP, its real websockets, its real login — and the bug that started
# this ("the object list spins forever") lived exactly there. So this brings up
# the genuine article.
#
# The upstream project is archived and dl.min.io now answers 410, so the binary
# is built from source. That takes a while the first time and is cached after.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
BIN=${MINIO_BIN:-/tmp/minio-real}
SRC=${MINIO_SRC:-/home/user/minio/minio}

if [ ! -x "$BIN" ]; then
  [ -d "$SRC" ] || git clone --depth 1 https://github.com/minio/minio "$SRC"
  echo "building minio (several minutes, once)…"
  (cd "$SRC" && CGO_ENABLED=0 go build -o "$BIN" ./)
fi

if ! curl -s --noproxy '*' -o /dev/null --max-time 2 http://127.0.0.1:9001/; then
  rm -rf /tmp/miniodata && mkdir -p /tmp/miniodata
  MINIO_ROOT_USER=pamtestadmin MINIO_ROOT_PASSWORD=pamtest-local-only-123 \
    nohup "$BIN" server /tmp/miniodata \
      --address 127.0.0.1:9000 --console-address 127.0.0.1:9001 \
      > /tmp/minio.log 2>&1 &
  for i in $(seq 1 30); do
    curl -s --noproxy '*' -o /dev/null --max-time 2 http://127.0.0.1:9001/ && break
    sleep 1
  done
fi
echo "minio console: $(curl -s --noproxy '*' -o /dev/null -w '%{http_code}' http://127.0.0.1:9001/)"

# The resource + its vaulted credential. Stored through the vault API, so the
# secret lands in ENVELOPE form — which is the point: the brokered session's
# auto-login then exercises the same decryption path production uses.
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
RID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "
DELETE FROM pam.pam_credentials WHERE resource_id='minio-real';
DELETE FROM pam.pam_resources   WHERE id='minio-real';
INSERT INTO pam.pam_resources (id,name,description,resource_type,host,port,connect_mode,console_url,is_active,always_record,created_by,created_at,updated_at)
VALUES ('minio-real','minio-real','Real MinIO for brokered-session tests','minio','127.0.0.1',9001,'embed_redirect','http://127.0.0.1:9001',true,true,'$RID',NOW(),NOW());"

T=$(cat /tmp/tok)
SAFE=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT id FROM pam.pam_safes ORDER BY created_at LIMIT 1;")
CID=$(curl -s --noproxy '*' -X POST -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
  -d '{"name":"minio-real-root","account_name":"pamtestadmin","secret_plaintext":"pamtest-local-only-123","credential_type":"password","resource_id":"minio-real","description":"Local MinIO root"}' \
  "http://127.0.0.1:8080/api/v1/pam/safes/$SAFE/credentials" \
  | python3 -c "import sys,json;print((json.load(sys.stdin).get('data') or {}).get('id',''))")

if [ -z "$CID" ]; then echo "could not vault the credential — is /tmp/tok fresh?" >&2; exit 1; fi
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c \
  "UPDATE pam.pam_resources SET vault_entry_id='$CID', extra_config=NULL WHERE id='minio-real';"
echo "seeded resource minio-real with vaulted credential $CID (auth strategy: minio_console)"
