import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

// The Devices screen: the reported "same buttons repeating", and the thing
// underneath it that was not cosmetic at all.
const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'
const me = (await (await fetch(`${API}/api/v1/auth/me`, { headers: { Authorization: 'Bearer ' + token } })).json()).data

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server'],
})
const page = await (await browser.newContext({ viewport: { width: 1440, height: 1100 } })).newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
const pairInits = []
page.on('request', (r) => { if (r.url().includes('/agent/pair/init')) pairInits.push(r.url()) })

await page.goto(APP, { waitUntil: 'domcontentloaded' })
await page.evaluate(([t, u]) => sessionStorage.setItem('pam_session', JSON.stringify({
  accessToken: t, refreshToken: null,
  expiresAt: new Date(Date.now() + 36e5).toISOString(), user: u,
})), [token, { user_id: me.user_id, username: me.username, roles: me.roles, email: me.email }])

await page.goto(APP + '/settings?tab=devices', { waitUntil: 'networkidle' })
await page.waitForTimeout(1500)
const body = await page.locator('main').innerText()

// ── The command an operator is told to run must be the one that exists ────
console.log('=== the CLI name ===')
check('the screen never tells anyone to run "pam-connector"', !body.includes('pam-connector'),
  'the shipped binary is pam-agent; pam-connector is not a command that exists')
check('the screen names the real binary, pam-agent', body.includes('pam-agent'))

// ── One heading per section, not two ──────────────────────────────────────
console.log('\n=== repetition ===')
const occurrences = (s, sub) => s.split(sub).length - 1
check('"Paired devices" appears once, not twice',
  occurrences(body, 'Paired devices') === 1, `${occurrences(body, 'Paired devices')} times`)

// ── One pairing panel, not two ────────────────────────────────────────────
// The count sentence must be a number, not the word "undefined" — the
// payload is { devices, count }, and reading .length off the object produces
// exactly that, rendered into a sentence.
check('the paired-machine count is a number, not "undefined"',
  !/undefined machine/i.test(body),
  body.split('\n').find((l) => /machine/i.test(l))?.trim().slice(0, 80) || '')

pairInits.length = 0
await page.getByRole('button', { name: /pair a device/i }).first().click()
await page.waitForTimeout(1200)
// Actually mint one. Without this the next two checks pass on zero codes,
// which proves nothing about how many panels would mint them.
const gen = page.getByRole('button', { name: /generate pairing code/i })
const genCount = await gen.count()
check('exactly one "Generate pairing code" control is offered', genCount === 1, `${genCount} found`)
if (genCount > 0) {
  await gen.first().click()
  await page.waitForTimeout(2500)
}

const codeBlocks = await page.locator('main code').allInnerTexts()
const pairCommands = codeBlocks.filter((t) => t.includes('pair --code'))
check('only one pairing command is shown', pairCommands.length <= 1,
  `${pairCommands.length} shown`)
// The real hazard: two panels each mint a one-time code, and a code is
// single-use — so the one on screen could be the dead one.
// A pairing code is SINGLE USE. Two panels each minting one means the code on
// screen can be the dead one — which is why the duplicate panel was a bug and
// not just clutter.
check('generating a code issues exactly one', pairInits.length === 1,
  `${pairInits.length} pairing/init requests`)

const opened = await page.locator('main').innerText()
check('the command shown is a pam-agent command',
  !pairCommands.length || pairCommands[0].trim().startsWith('pam-agent'),
  pairCommands[0]?.trim().slice(0, 70) || 'none rendered')
check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))

await page.screenshot({ path: '/tmp/devices-after.png', fullPage: false })
await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
