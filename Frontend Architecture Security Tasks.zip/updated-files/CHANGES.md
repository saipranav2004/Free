# Updated frontend files — 7 tasks

Drop these files over your project root (they mirror the original `src/` paths).
**Only changed/new files are included.** Nothing in a backend folder was touched and no git command was run.

| # | File | Change |
|---|------|--------|
| 1 | `src/context/AuthContext.jsx` | Fetches the logged-in principal with the exact endpoint `GET /api/v1/identity/accounts/<account_id>/users/<user_id>`, reads **`data.account_type`** verbatim and exposes `accountType`, `accountTypeLoading`, `isAdminAccount`, `refreshAccountType`. Cleared on sign-out. |
| 1 | `src/utils/permissions.js` | New single source of truth: `isAdminAccountType(accountType)` and `accountTypeDisplayLabel(accountType)` → `"Admin"` / `"User"`. Legacy `accountTypeLabel` marked deprecated (no longer imported anywhere). |
| 1 | `src/components/layout/Topbar.jsx` | Profile chip (header + menu) is driven 100% by `account_type`; no hardcoded role text, and the chip is a skeleton until the value resolves. IDP tab **no longer hidden** for non-admins. PAM tab → `/pam/audit-logs`, bell → `/pam/alerts`. |
| 1 | `src/components/layout/RequireAdmin.jsx` | Gate now decides on `account_type === 'admin'` only, and renders a clean enterprise **“Access Restricted”** panel (never a redirect, never a hidden menu). |
| 2 | `src/routes/AppRoutes.jsx` | Delegations + Groups (list & detail) imports and routes commented out with restore notes; PAM routes split. |
| 2 | `src/components/layout/Sidebar.jsx` | Delegations and Groups (RBAC) items commented out. |
| 2 | `src/components/common/CommandPalette.jsx` | Groups/Delegations commands, the groups inventory fetch and the group result block commented out; PAM resolves as two commands. |
| 2 | `src/pages/identity/UserDetailPage.jsx` | “Groups” tab, its handlers, modals, confirm dialog and the group directory request commented out (state kept so restoring is a pure uncomment). |
| 2, 6 | `src/pages/DashboardPage.jsx` | Groups/Delegations resources, KPI tiles, posture half and delegation finding commented out; **“Access Footprint” section commented out** (task 6). Account panel + admin action now use `account_type`. PAM links updated. |
| 3 | `src/pages/pbac/PolicyEditorPage.jsx` | Policy detail is **one continuous view**: no metric cards, no tabs. Sections: Policy information · Identifiers & shape (the old tile figures as a quiet key/value list) · What this policy grants · Statements · Policy document · Attached entities. Same API calls, validation, document builder and sticky save bar. |
| 4 | `src/pages/rbac/RoleDetailPage.jsx` | Assigned users fixed for **every** role: all assignment sources merged (was first-source-wins), the tenant directory paged through completely, and a bounded reconciliation via `GET /api/v1/authz/users/<id>/roles` when the role-scoped endpoints answer empty. Count is the resolved list length once loading settles; revoke falls back to the assignment route; `reloadAll()` re-runs every source including the reconciliation. |
| 5 | `src/pages/pam/parts.jsx` *(new)* | The two PAM surfaces (audit investigation + denial analytics), unchanged behaviour, shared by the pages. |
| 5 | `src/pages/pam/AuditLogsPage.jsx` *(new)* | `/pam/audit-logs`, accepts `?search=&decision=` drill-through from Alerts. |
| 5 | `src/pages/pam/AlertsPage.jsx` *(new)* | `/pam/alerts`, ranked rows drill through to the audit page. |
| 5 | `src/pages/pam/PamPage.jsx` | Now a redirect shell: `/pam` → `/pam/audit-logs`, legacy `/pam?tab=alerts` → `/pam/alerts`. |
| 5 | `src/components/layout/Sidebar.jsx` | Separate sidebars: IAM (Dashboard · Users · Resources · Roles · Policies) and PAM (Audit Logs · Alerts); IDP stays a Topbar dropdown with its contextual section. |
| 7 | `src/pages/identity/UsersPage.jsx` | First/Last name accept **letters only (A–Z, a–z)** — validated as typed, on blur and on submit, with distinct messages for spaces, numbers and symbols; shown on the field and in the error summary. |

## State / flow verification performed

* Every file parses cleanly (Babel, React preset) and no stale identifier remains live — the disabled Groups/Delegations code is inside comments only, verified by a comment-stripping scan.
* Counts everywhere derive from resolved lists (`extractList`), so Roles list ↔ Role detail ↔ Dashboard can no longer disagree.
* Role detail: assign / revoke / attach / detach all call `reloadAll()`, which reloads the role graph, the policy list, the tenant directory **and** re-runs the assigned-user reconciliation.
* Users page: create / enable / disable / offboard / bulk actions still call `users.reload()`; dashboard directory totals come from the same `listUsers` contract.
* Policy page: save/attach unchanged; the statement summary, wildcard warning and sticky save bar all re-derive from live editor state.
* PAM: both pages keep their own polling, paging, search and CSV export; the bell's unread baseline still clears via the `iam:alerts-read` event dispatched by the Alerts page.
* No design tokens, palette values or shared primitives were modified.
