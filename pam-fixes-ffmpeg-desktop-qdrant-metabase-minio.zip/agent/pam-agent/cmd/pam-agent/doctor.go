// pam-agent/cmd/pam-agent/doctor.go
//
// `pam-agent doctor` — everything about this machine that decides whether a
// click in the PAM console opens anything, answered on the machine, in one
// command.
//
// WHY THIS EXISTS. Every support round on the agent started the same way: an
// operator says "the button does nothing", and there are at least six
// distinct reasons for that, none of which the browser can tell apart —
// the URL handler is not registered (or was taken over by another
// application), the machine is not paired, it is paired to a DIFFERENT
// server, the device has been revoked, the tool the resource needs is not
// installed, or ffmpeg is missing on a resource that requires recording.
// Finding out which meant asking the operator to read a log file, on the day
// they were already blocked. Six questions, one command, and the answers are
// phrased as what to do next rather than as internal state.
//
// It is READ-ONLY by design: doctor never registers a handler, never pairs,
// never installs anything. A diagnostic that changes the thing it is
// diagnosing cannot be run twice, and cannot be run by someone who has not
// yet decided what they want to change.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"

	"github.com/yourorg/pam-agent/internal/keystore"
	"github.com/yourorg/pam-agent/internal/launcher"
	"github.com/yourorg/pam-agent/internal/recorder"
	"github.com/yourorg/pam-agent/internal/register"
	"github.com/yourorg/pam-agent/internal/toolpaths"
)

// serverProbeTimeout bounds the reachability check. Short on purpose: doctor
// is run by someone who is already waiting, and "the server did not answer
// within three seconds" is the same diagnosis as "the server did not answer".
const serverProbeTimeout = 3 * time.Second

// DoctorReport is the whole diagnosis. Printed for a person by default and
// emitted as JSON under --json, so a fleet tool can collect it from many
// machines without screen-scraping.
type DoctorReport struct {
	AgentVersion string `json:"agent_version"`
	OS           string `json:"os"`
	Arch         string `json:"arch"`
	Hostname     string `json:"hostname,omitempty"`
	ExecPath     string `json:"exec_path,omitempty"`
	ConfigDir    string `json:"config_dir,omitempty"`
	LogPath      string `json:"log_path,omitempty"`

	URLHandler register.Registration `json:"url_handler"`

	Servers []ServerDiagnosis `json:"servers"`

	ScreenRecorder ScreenRecorderDiagnosis `json:"screen_recorder"`

	// Capabilities is the same report the console is given at pairing and on
	// every launch. Included verbatim so that "what doctor says this machine
	// can open" and "what the console says this machine can open" can never
	// drift into two different answers.
	Capabilities *launcher.DeviceCapabilities `json:"capabilities,omitempty"`

	// ToolPaths is the operator's own overrides, which are invisible in the
	// console and are the reason a machine can open something discovery
	// cannot find.
	ToolPaths map[string]string `json:"tool_paths,omitempty"`

	// Problems is what is wrong, in the words doctor prints. Empty means
	// nothing here would stop a launch.
	Problems []string `json:"problems"`
}

// ServerDiagnosis is one paired server: who this machine is to it, and
// whether it can be reached from here at all.
type ServerDiagnosis struct {
	ServerURL     string `json:"server_url"`
	AgentDeviceID string `json:"agent_device_id,omitempty"`
	Reachable     bool   `json:"reachable"`
	Detail        string `json:"detail,omitempty"`
}

// ScreenRecorderDiagnosis answers whether a DESKTOP session on a
// record-required resource could be opened here.
type ScreenRecorderDiagnosis struct {
	Available bool   `json:"available"`
	Tool      string `json:"tool"`
	Backend   string `json:"backend,omitempty"`
	Display   string `json:"display,omitempty"`
	Detail    string `json:"detail,omitempty"`
}

func cmdDoctor(args []string, configDir string, configDirErr error) error {
	fs := flag.NewFlagSet("doctor", flag.ContinueOnError)
	asJSON := fs.Bool("json", false, "emit the diagnosis as JSON instead of text")
	if err := fs.Parse(args); err != nil {
		return err
	}

	report := buildDoctorReport(configDir, configDirErr, probeServer)

	if *asJSON {
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "  ")
		if err := enc.Encode(report); err != nil {
			return err
		}
	} else {
		printDoctorReport(os.Stdout, report)
	}

	// Debug, not Info: this command's whole output is meant to be read, and
	// the agent's logger writes to stderr as well as to the log file — an
	// Info line here lands underneath the diagnosis as a last line of
	// machine noise.
	log.Debug("doctor.ok", "problems", len(report.Problems))
	if len(report.Problems) > 0 {
		// A non-zero exit so this is usable from a script or an MDM check
		// without parsing the output. The problems are already printed; a
		// second error line would say them twice.
		os.Exit(1)
	}
	return nil
}

// probeServer reports whether a PAM server answers HTTP at all.
//
// Deliberately NOT an authenticated call. The question here is "can this
// machine reach the server", and an unauthenticated request answers it
// without needing a session, without logging a failed authentication against
// the operator, and without doctor being able to do anything privileged. Any
// HTTP status counts as reachable — a 401 or a 404 still proves the network
// path, the DNS, the TLS and the proxy all work, which is what a person
// running doctor needs to know.
func probeServer(serverURL string) (bool, string) {
	client := &http.Client{Timeout: serverProbeTimeout}
	// /api/health, not a /api/v1/ path: it is PAM's only route that is both
	// unauthenticated AND exempt from the network allowlist, which is exactly
	// what a reachability probe needs — a machine on a network the allowlist
	// does not cover must still be able to tell "I can reach the server" from
	// "I cannot".
	resp, err := client.Get(strings.TrimRight(serverURL, "/") + "/api/health")
	if err != nil {
		return false, err.Error()
	}
	defer resp.Body.Close()

	detail := fmt.Sprintf("HTTP %d", resp.StatusCode)
	// The server names itself and its version here. Worth printing: half of
	// "my launches fail" turns out to be a machine paired against staging
	// while the operator is clicking in production.
	var health struct {
		Service string `json:"service"`
		Version string `json:"version"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 4<<10)).Decode(&health); err == nil {
		if health.Service != "" || health.Version != "" {
			detail = strings.TrimSpace(fmt.Sprintf("%s — %s %s", detail, health.Service, health.Version))
		}
	}
	return true, detail
}

// buildDoctorReport gathers the diagnosis. The server probe is injected so a
// test can drive both the reachable and the unreachable case without a
// network.
func buildDoctorReport(configDir string, configDirErr error, probe func(string) (bool, string)) DoctorReport {
	host, _ := os.Hostname()
	exe, _ := os.Executable()

	report := DoctorReport{
		AgentVersion: version,
		OS:           runtime.GOOS,
		Arch:         runtime.GOARCH,
		Hostname:     host,
		ExecPath:     exe,
		Problems:     []string{},
	}

	if configDirErr != nil {
		report.Problems = append(report.Problems,
			fmt.Sprintf("This machine has no usable agent config directory (%v), so nothing can be paired or remembered here.", configDirErr))
	} else {
		report.ConfigDir = configDir
		report.LogPath = filepath.Join(configDir, "logs", "agent.log")
	}

	// ── The URL handler ──
	report.URLHandler = register.Status()
	if !report.URLHandler.Registered {
		detail := report.URLHandler.Detail
		if detail == "" {
			detail = "run: pam-agent install"
		}
		report.Problems = append(report.Problems,
			"pam-agent:// links will not open on this machine: "+detail)
	} else if report.URLHandler.Target != "" && exe != "" && !sameFile(report.URLHandler.Target, exe) {
		// Not a problem — it works — but it is the reason an upgrade can
		// appear to have no effect.
		report.URLHandler.Detail = strings.TrimSpace(report.URLHandler.Detail + fmt.Sprintf(
			" (links open %s, which is not the binary you just ran, %s)", report.URLHandler.Target, exe))
	}

	// ── Pairing ──
	servers, err := keystore.List()
	if err != nil {
		report.Problems = append(report.Problems, fmt.Sprintf("Could not read this machine's paired servers: %v", err))
	}
	for _, s := range servers {
		diag := ServerDiagnosis{ServerURL: s}
		if identity, err := keystore.Load(s); err != nil {
			diag.Detail = fmt.Sprintf("the stored identity could not be loaded: %v", err)
			report.Problems = append(report.Problems,
				fmt.Sprintf("The identity for %s is unreadable, so launches from it will fail: %v", s, err))
		} else {
			diag.AgentDeviceID = identity.AgentDeviceID
		}
		if probe != nil {
			reachable, detail := probe(s)
			diag.Reachable = reachable
			if diag.Detail == "" {
				diag.Detail = detail
			}
			if !reachable {
				report.Problems = append(report.Problems,
					fmt.Sprintf("%s cannot be reached from this machine (%s), so a launch cannot be redeemed.", s, detail))
			}
		}
		report.Servers = append(report.Servers, diag)
	}
	if len(servers) == 0 {
		report.Problems = append(report.Problems,
			"This machine is not paired with any PAM server. Run: pam-agent pair --code <code> --server <url>")
	}

	// ── Screen recording ──
	report.ScreenRecorder = ScreenRecorderDiagnosis{
		Available: recorder.ScreenRecorderAvailable(),
		Tool:      recorder.ScreenRecorderName,
		Backend:   recorder.CaptureBackend(runtime.GOOS),
	}
	if runtime.GOOS == "linux" {
		report.ScreenRecorder.Display = os.Getenv("DISPLAY")
	}
	ffmpegPath, foundVia := recorder.ResolvedFrom()
	switch {
	case !report.ScreenRecorder.Available:
		report.ScreenRecorder.Detail = "ffmpeg was not found on PATH or in any standard install location, " +
			"so a desktop session on a resource that requires recording will be refused"
		// Not listed as a problem unconditionally: a machine that only ever
		// opens CLI sessions records those through the PTY and needs no
		// ffmpeg at all. It is stated plainly in the output instead.
	case report.ScreenRecorder.Backend == "":
		report.ScreenRecorder.Detail = fmt.Sprintf("desktop recording is not supported on %s", runtime.GOOS)
	case runtime.GOOS == "linux" && report.ScreenRecorder.Display == "":
		report.ScreenRecorder.Detail = "ffmpeg is present but no X display is set ($DISPLAY is empty), so there is no desktop to capture"
	default:
		// Says WHICH ffmpeg, and how it was found. That is the question an
		// operator is actually left with when the console reports this
		// machine as able to record and a launch disagrees: the two can only
		// differ over the environment, so naming the resolution settles it
		// without anyone having to guess at PATH.
		report.ScreenRecorder.Detail = fmt.Sprintf("ffmpeg at %s, found via %s", ffmpegPath, foundVia)
	}
	// A configured-but-broken override is worth naming outright: the machine
	// has been deliberately pointed somewhere, and the pointer is wrong.
	if problem := recorder.OverrideProblem(); problem != "" {
		report.Problems = append(report.Problems, problem)
	}

	// ── What this machine can open ──
	if configDirErr == nil {
		overrides := toolpaths.Open(configDir).All()
		if len(overrides) > 0 {
			report.ToolPaths = overrides
		}
		templates, err := launcher.LoadTemplates(configDir)
		if err != nil {
			report.Problems = append(report.Problems,
				fmt.Sprintf("The launch templates could not be read (%v), so this machine cannot say what it is able to open.", err))
		} else {
			caps := launcher.Capabilities(templates, version, report.ScreenRecorder.Available, overrides)
			report.Capabilities = &caps
		}
	}

	return report
}

// sameFile compares two paths through the filesystem rather than as strings,
// so a symlink, a relative path or a trailing slash does not read as a
// different binary.
func sameFile(a, b string) bool {
	ai, err := os.Stat(a)
	if err != nil {
		return false
	}
	bi, err := os.Stat(b)
	if err != nil {
		return false
	}
	return os.SameFile(ai, bi)
}

// printDoctorReport writes the human form.
//
// Formatted for someone reading it under pressure: a mark per line so the
// broken line is findable without reading the rest, and every problem
// repeated at the bottom with the command that fixes it. Plain ASCII marks —
// this is read in cmd.exe and in PowerShell as often as in a Unix terminal,
// and neither renders a check mark reliably in every code page.
func printDoctorReport(w *os.File, r DoctorReport) {
	p := func(format string, args ...interface{}) { fmt.Fprintf(w, format+"\n", args...) }
	mark := func(ok bool) string {
		if ok {
			return "[ok]"
		}
		return "[!!]"
	}

	p("pam-agent doctor")
	p("")
	p("This agent")
	p("  version      %s", r.AgentVersion)
	p("  platform     %s/%s", r.OS, r.Arch)
	if r.Hostname != "" {
		p("  hostname     %s", r.Hostname)
	}
	if r.ExecPath != "" {
		p("  binary       %s", r.ExecPath)
	}
	if r.ConfigDir != "" {
		p("  config       %s", r.ConfigDir)
	}
	if r.LogPath != "" {
		p("  log          %s", r.LogPath)
	}

	p("")
	p("%s pam-agent:// URL handler", mark(r.URLHandler.Registered))
	if r.URLHandler.Handler != "" {
		p("  registration %s", r.URLHandler.Handler)
	}
	if r.URLHandler.Target != "" {
		p("  opens        %s", r.URLHandler.Target)
	}
	if r.URLHandler.Detail != "" {
		p("  note         %s", r.URLHandler.Detail)
	}

	p("")
	if len(r.Servers) == 0 {
		p("[!!] Paired servers")
		p("  none — run: pam-agent pair --code <code> --server <url>")
	} else {
		for _, s := range r.Servers {
			p("%s %s", mark(s.Reachable), s.ServerURL)
			if s.AgentDeviceID != "" {
				p("  device id    %s", s.AgentDeviceID)
			}
			if s.Detail != "" {
				p("  reachability %s", s.Detail)
			}
		}
	}

	p("")
	p("%s Desktop screen recording", mark(r.ScreenRecorder.Available))
	p("  tool         %s%s", r.ScreenRecorder.Tool, map[bool]string{true: " (found)", false: " (not on PATH)"}[r.ScreenRecorder.Available])
	if r.ScreenRecorder.Backend != "" {
		p("  capture      %s", r.ScreenRecorder.Backend)
	}
	if r.OS == "linux" {
		p("  display      %s", orDash(r.ScreenRecorder.Display))
	}
	if r.ScreenRecorder.Detail != "" {
		p("  note         %s", r.ScreenRecorder.Detail)
	}

	if len(r.ToolPaths) > 0 {
		p("")
		p("Tool paths you have set on this machine")
		ids := make([]string, 0, len(r.ToolPaths))
		for id := range r.ToolPaths {
			ids = append(ids, id)
		}
		sort.Strings(ids)
		for _, id := range ids {
			p("  %-14s %s", id, r.ToolPaths[id])
		}
	}

	if r.Capabilities != nil {
		p("")
		p("What this machine can open")
		for _, t := range r.Capabilities.Types {
			kinds := strings.Join(t.Kinds, ", ")
			if kinds == "" {
				kinds = "nothing installed"
			}
			p("%s %-12s %s", mark(t.Supported()), t.ResourceType, kinds)
			if len(t.Tools) > 0 {
				p("     found      %s", strings.Join(t.Tools, ", "))
			}
			for _, m := range t.Missing {
				hint := m.InstallHint
				if hint == "" {
					hint = "not installed"
				}
				p("     missing    %s (%s) — %s", m.ID, m.Kind, hint)
			}
		}
		p("")
		p("  A tool installed after this runs is not known to the console until the")
		p("  next launch, which is when the agent reports its capabilities again.")
	}

	p("")
	if len(r.Problems) == 0 {
		p("Nothing here would stop a launch.")
		return
	}
	p("Problems found (%d)", len(r.Problems))
	for i, prob := range r.Problems {
		p("  %d. %s", i+1, prob)
	}
}

func orDash(s string) string {
	if strings.TrimSpace(s) == "" {
		return "(not set)"
	}
	return s
}
