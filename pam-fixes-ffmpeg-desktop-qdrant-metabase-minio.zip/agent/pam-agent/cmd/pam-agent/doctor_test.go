package main

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/keystore"
)

// doctor's value is entirely in WHAT IT SAYS when something is wrong, so
// these drive the wrong cases and read the problems back.

func unreachable(string) (bool, string) { return false, "dial tcp 10.0.0.1:443: i/o timeout" }
func reachable(string) (bool, string)   { return true, "HTTP 200 — PAM 2.0.0" }

func problemsContaining(t *testing.T, problems []string, substr string) {
	t.Helper()
	for _, p := range problems {
		if strings.Contains(p, substr) {
			return
		}
	}
	t.Errorf("no problem mentioning %q; got %v", substr, problems)
}

func noProblemContaining(t *testing.T, problems []string, substr string) {
	t.Helper()
	for _, p := range problems {
		if strings.Contains(p, substr) {
			t.Errorf("unexpected problem mentioning %q: %s", substr, p)
		}
	}
}

// A machine that was never paired is the single most common cause of "the
// button does nothing", and it has to be named as such — with the command
// that fixes it, because the operator running doctor is the person who has
// to run that command.
func TestDoctorSaysWhenNothingIsPaired(t *testing.T) {
	dir := t.TempDir()
	// keystore reads the per-user config dir from the environment, so point
	// the whole home at a temp dir: no pairing exists under it.
	t.Setenv("HOME", dir)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(dir, ".config"))

	r := buildDoctorReport(filepath.Join(dir, ".config", "pam-agent"), nil, reachable)

	if len(r.Servers) != 0 {
		t.Fatalf("expected no paired servers, got %v", r.Servers)
	}
	problemsContaining(t, r.Problems, "not paired")
	problemsContaining(t, r.Problems, "pam-agent pair")
}

// A config dir that cannot be used at all: doctor must still run and still
// say why, rather than crashing on the machine whose state is worst.
func TestDoctorSurvivesAnUnusableConfigDir(t *testing.T) {
	t.Setenv("HOME", t.TempDir())
	r := buildDoctorReport("", errors.New("permission denied"), reachable)

	problemsContaining(t, r.Problems, "no usable agent config directory")
	if r.ConfigDir != "" || r.LogPath != "" {
		t.Errorf("no config dir should be reported when there is none: %q %q", r.ConfigDir, r.LogPath)
	}
	// And it must not claim to know what the machine can open.
	if r.Capabilities != nil {
		t.Error("capabilities cannot be known without a config dir to read templates from")
	}
}

// An unreachable server is a different failure from an unpaired machine, and
// the difference is what tells an operator whether to fix their VPN or run a
// pairing command. The detail carries the transport error verbatim.
func TestDoctorReportsAnUnreachableServer(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("HOME", dir)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(dir, ".config"))
	writeFakePairing(t, dir, "https://pam.example.com", "device-abc")

	r := buildDoctorReport(filepath.Join(dir, ".config", "pam-agent"), nil, unreachable)

	if len(r.Servers) != 1 {
		t.Fatalf("expected the one paired server, got %v", r.Servers)
	}
	if r.Servers[0].Reachable {
		t.Error("the server must be reported unreachable")
	}
	if r.Servers[0].AgentDeviceID != "device-abc" {
		t.Errorf("device id = %q, want device-abc", r.Servers[0].AgentDeviceID)
	}
	problemsContaining(t, r.Problems, "cannot be reached")
	problemsContaining(t, r.Problems, "i/o timeout")
	noProblemContaining(t, r.Problems, "not paired")
}

// The reachable case must be quiet about the server. A diagnostic that lists
// a problem for a healthy machine teaches people to ignore its output.
func TestDoctorIsQuietWhenTheServerAnswers(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("HOME", dir)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(dir, ".config"))
	writeFakePairing(t, dir, "https://pam.example.com", "device-abc")

	r := buildDoctorReport(filepath.Join(dir, ".config", "pam-agent"), nil, reachable)

	noProblemContaining(t, r.Problems, "cannot be reached")
	if !r.Servers[0].Reachable {
		t.Error("the server must be reported reachable")
	}
	if !strings.Contains(r.Servers[0].Detail, "PAM 2.0.0") {
		t.Errorf("the probe detail should name the server version, got %q", r.Servers[0].Detail)
	}
}

// ffmpeg being absent is NOT a problem in its own right — a machine that only
// opens CLI sessions records them through the PTY and never needs it. It is
// stated in the output, and it must not be the reason doctor exits non-zero
// on an otherwise healthy laptop.
func TestDoctorDoesNotTreatAMissingRecorderAsAProblem(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("HOME", dir)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(dir, ".config"))
	// An empty PATH makes every tool the agent LAUNCHES undiscoverable.
	//
	// It no longer hides ffmpeg, and deliberately so: the recorder is now
	// looked for in the standard install locations as well as on PATH,
	// because a launch started from the browser's URL handler inherits an
	// environment the operator never curated and was refusing to record on
	// machines that had ffmpeg installed all along. So this asserts what the
	// test is really named for — that whichever answer the recorder gives,
	// doctor EXPLAINS it and does not turn it into a problem on an otherwise
	// healthy laptop.
	t.Setenv("PATH", "")
	writeFakePairing(t, dir, "https://pam.example.com", "device-abc")

	r := buildDoctorReport(filepath.Join(dir, ".config", "pam-agent"), nil, reachable)

	if r.ScreenRecorder.Detail == "" {
		t.Error("the recorder's state must be explained, not left blank")
	}
	noProblemContaining(t, r.Problems, "ffmpeg")
}

// Capabilities in the report have to be the SAME structure the console is
// given, so the two can never answer the same question differently.
func TestDoctorReportsCapabilitiesIncludingMissingTools(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("HOME", dir)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(dir, ".config"))
	t.Setenv("PATH", "") // nothing is installed, so everything is missing
	configDir := filepath.Join(dir, ".config", "pam-agent")
	if err := os.MkdirAll(configDir, 0o700); err != nil {
		t.Fatal(err)
	}

	r := buildDoctorReport(configDir, nil, reachable)

	if r.Capabilities == nil {
		t.Fatal("capabilities should be reported when templates are readable")
	}
	var sawMissing bool
	for _, tc := range r.Capabilities.Types {
		if len(tc.Missing) > 0 {
			sawMissing = true
			for _, m := range tc.Missing {
				if m.ID == "" {
					t.Error("a missing tool must name itself, or the operator cannot install it")
				}
			}
		}
	}
	if !sawMissing {
		t.Error("with an empty PATH at least one tool must be reported missing")
	}
}

// The printed form is what people actually read; it must contain the marks
// and the problem list, and it must not panic on a report full of zero
// values.
func TestDoctorPrintsReadableOutput(t *testing.T) {
	out, err := os.CreateTemp(t.TempDir(), "doctor")
	if err != nil {
		t.Fatal(err)
	}
	defer out.Close()

	printDoctorReport(out, DoctorReport{
		AgentVersion: "2026.09.17.2",
		OS:           "windows",
		Arch:         "amd64",
		Problems:     []string{"pam-agent:// links will not open on this machine: run: pam-agent install"},
	})

	body, err := os.ReadFile(out.Name())
	if err != nil {
		t.Fatal(err)
	}
	text := string(body)
	for _, want := range []string{"pam-agent doctor", "2026.09.17.2", "windows/amd64", "[!!]", "Problems found (1)", "pam-agent install"} {
		if !strings.Contains(text, want) {
			t.Errorf("printed output is missing %q:\n%s", want, text)
		}
	}
}

func TestDoctorPrintsTheAllClear(t *testing.T) {
	out, err := os.CreateTemp(t.TempDir(), "doctor")
	if err != nil {
		t.Fatal(err)
	}
	defer out.Close()

	printDoctorReport(out, DoctorReport{AgentVersion: "dev", OS: "linux", Arch: "arm64"})
	body, _ := os.ReadFile(out.Name())
	if !strings.Contains(string(body), "Nothing here would stop a launch.") {
		t.Errorf("a clean report must say so plainly:\n%s", body)
	}
}

// writeFakePairing lays down a real pairing on disk, so the pairing branches
// are tested against the format keystore actually reads rather than against a
// fixture that could drift from it.
func writeFakePairing(t *testing.T, home, serverURL, deviceID string) {
	t.Helper()
	id, err := keystore.Generate(serverURL)
	if err != nil {
		t.Fatal(err)
	}
	id.AgentDeviceID = deviceID
	if err := keystore.Save(id); err != nil {
		t.Fatal(err)
	}
}
