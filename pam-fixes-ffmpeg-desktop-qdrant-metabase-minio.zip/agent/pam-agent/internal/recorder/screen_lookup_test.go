package recorder

import (
	"errors"
	"os"
	"strings"
	"testing"
	"time"
)

// fakeInfo is a minimal os.FileInfo so these tests can describe a filesystem
// without creating one — the Windows paths under test cannot exist here.
type fakeInfo struct{ dir bool }

func (f fakeInfo) Name() string       { return "ffmpeg" }
func (f fakeInfo) Size() int64        { return 1 }
func (f fakeInfo) Mode() os.FileMode  { return 0o755 }
func (f fakeInfo) ModTime() time.Time { return time.Time{} }
func (f fakeInfo) IsDir() bool        { return f.dir }
func (f fakeInfo) Sys() any           { return nil }

// fs builds a stat func over a set of paths that exist as files.
func fs(files ...string) func(string) (os.FileInfo, error) {
	set := map[string]bool{}
	for _, f := range files {
		set[f] = true
	}
	return func(p string) (os.FileInfo, error) {
		if set[p] {
			return fakeInfo{}, nil
		}
		return nil, errors.New("no such file")
	}
}

func envOf(kv map[string]string) func(string) string {
	return func(k string) string { return kv[k] }
}

func noPath() func(string) (string, error) {
	return func(string) (string, error) { return "", errors.New("not on PATH") }
}

func onPath(p string) func(string) (string, error) {
	return func(string) (string, error) { return p, nil }
}

// THE REGRESSION THIS PINS. A Windows operator installs ffmpeg and adds it to
// PATH. Their shell sees it, so `pam-agent pair` reports "can record" and the
// console shows it. Their browser does NOT see it — it was running before the
// edit — so the launch it spawns inherits the old PATH and every recorded
// desktop session is refused as "ffmpeg is not installed". Both answers came
// from the same bare exec.LookPath, and both were locally correct.
func TestWindowsLaunchWithAStalePathStillFindsAnInstalledFfmpeg(t *testing.T) {
	// The browser-spawned launch: nothing on PATH.
	env := envOf(map[string]string{
		"LOCALAPPDATA": `C:\Users\op\AppData\Local`,
		"ProgramFiles": `C:\Program Files`,
		"ProgramData":  `C:\ProgramData`,
		"USERPROFILE":  `C:\Users\op`,
	})

	cases := map[string]string{
		"winget":               `C:\Users\op\AppData\Local\Microsoft\WinGet\Links\ffmpeg.exe`,
		"chocolatey":           `C:\ProgramData\chocolatey\bin\ffmpeg.exe`,
		"scoop":                `C:\Users\op\scoop\shims\ffmpeg.exe`,
		"the documented unzip": `C:\ffmpeg\bin\ffmpeg.exe`,
		"Program Files":        `C:\Program Files\ffmpeg\bin\ffmpeg.exe`,
	}
	for name, installed := range cases {
		got := resolveOn("windows", env, noPath(), fs(installed))
		if got != installed {
			t.Errorf("%s install: resolveOn = %q, want %q — a launch would be refused on a machine that HAS ffmpeg",
				name, got, installed)
		}
	}
}

func TestPathIsPreferredWhenItWorks(t *testing.T) {
	// The ordinary case must stay cheap and must not start guessing.
	got := resolveOn("windows", envOf(nil), onPath(`C:\tools\ffmpeg.exe`), fs())
	if got != `C:\tools\ffmpeg.exe` {
		t.Fatalf("resolveOn = %q, want the PATH answer", got)
	}
}

func TestAnExplicitOverrideBeatsEverything(t *testing.T) {
	override := `D:\vendored\ffmpeg.exe`
	got := resolveOn("windows",
		envOf(map[string]string{OverrideEnv: override}),
		onPath(`C:\tools\ffmpeg.exe`),
		fs(override, `C:\tools\ffmpeg.exe`))
	if got != override {
		t.Fatalf("resolveOn = %q, want the override %q", got, override)
	}
}

func TestABrokenOverrideFallsBackRatherThanBreakingTheLaunch(t *testing.T) {
	// Set-but-wrong must not strand an operator whose machine is otherwise
	// fine. OverrideProblem is what tells them; the launch still works.
	got := resolveOn("windows",
		envOf(map[string]string{OverrideEnv: `D:\gone\ffmpeg.exe`}),
		onPath(`C:\tools\ffmpeg.exe`),
		fs(`C:\tools\ffmpeg.exe`))
	if got != `C:\tools\ffmpeg.exe` {
		t.Fatalf("resolveOn = %q, want the working PATH copy", got)
	}
}

func TestAnOverridePointingAtAFolderIsNotAccepted(t *testing.T) {
	dir := `D:\ffmpeg`
	statDir := func(p string) (os.FileInfo, error) {
		if p == dir {
			return fakeInfo{dir: true}, nil
		}
		return nil, errors.New("no such file")
	}
	if got := resolveOn("windows", envOf(map[string]string{OverrideEnv: dir}), noPath(), statDir); got != "" {
		t.Fatalf("resolveOn = %q, want empty — a directory is not something we can exec", got)
	}
}

func TestMacAndLinuxInstallLocations(t *testing.T) {
	cases := []struct{ goos, installed string }{
		{"darwin", "/opt/homebrew/bin/ffmpeg"}, // Apple Silicon
		{"darwin", "/usr/local/bin/ffmpeg"},    // Intel
		{"darwin", "/opt/local/bin/ffmpeg"},    // MacPorts
		{"linux", "/usr/bin/ffmpeg"},
		{"linux", "/snap/bin/ffmpeg"},
	}
	for _, c := range cases {
		if got := resolveOn(c.goos, envOf(nil), noPath(), fs(c.installed)); got != c.installed {
			t.Errorf("%s: resolveOn = %q, want %q", c.goos, got, c.installed)
		}
	}
}

func TestWindowsLooksForTheExeNotTheBareName(t *testing.T) {
	// A file literally named "ffmpeg" with no extension is not runnable on
	// Windows, and matching it would resolve to something that cannot start.
	if got := resolveOn("windows", envOf(nil), noPath(), fs(`C:\ffmpeg\bin\ffmpeg`)); got != "" {
		t.Fatalf("resolveOn = %q, want empty", got)
	}
}

func TestAnUnsetEnvironmentVariableNeverProducesARelativePath(t *testing.T) {
	// filepath.Join("", "Microsoft", "WinGet") is "Microsoft\WinGet" — a
	// RELATIVE path that would resolve against whatever directory the
	// browser happened to be in, and could match a file that is not ffmpeg.
	// Checked with isAbsOn, not filepath.IsAbs: filepath is fixed to the
	// BUILD platform, so on this Linux host it would call every correct
	// Windows path relative and the test would be asserting the opposite of
	// what it means.
	for _, dir := range wellKnownDirs("windows", envOf(nil)) {
		if !isAbsOn("windows", dir) {
			t.Errorf("wellKnownDirs produced the relative path %q with no environment set", dir)
		}
	}
	for _, dir := range wellKnownDirs("linux", envOf(nil)) {
		if !isAbsOn("linux", dir) {
			t.Errorf("wellKnownDirs produced the relative path %q on linux", dir)
		}
	}
}

func TestTheMachineThisRunsOnIsAnsweredConsistently(t *testing.T) {
	// Whatever this host has, the capability report and the launch check must
	// agree — that agreement is the entire point of the change.
	if ScreenRecorderAvailable() != (Resolve() != "") {
		t.Fatal("ScreenRecorderAvailable disagrees with Resolve on this machine")
	}
}

func TestTheWindowsHintDoesNotJustSayCheckYourPath(t *testing.T) {
	// The advice that sent the reporting operator in a circle. The Windows
	// hint has to name the stale-environment case, because on a machine where
	// the console says "detected" that IS the cause.
	hint := windowsHintForTest()
	if !strings.Contains(strings.ToLower(hint), "reopen") {
		t.Fatalf("the Windows hint never mentions restarting the browser: %q", hint)
	}
	if !strings.Contains(hint, OverrideEnv) {
		t.Fatalf("the Windows hint never offers the override as a way out: %q", hint)
	}
}
