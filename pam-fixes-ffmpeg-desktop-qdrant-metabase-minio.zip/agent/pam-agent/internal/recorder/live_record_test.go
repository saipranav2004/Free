package recorder

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// The end of the reported failure, proved against a real display and a real
// ffmpeg: a desktop session recorded from the environment a browser-spawned
// launch actually gets — nothing on PATH — produces a playable video.
//
// Before the lookup change this returned ErrScreenRecorderMissing here and
// the launch was refused, while the console went on reporting the machine as
// able to record. Skips rather than fails where there is no display or no
// ffmpeg, so it is a no-op on a machine that legitimately cannot run it.
func TestLiveDesktopRecordingFromABrowserSpawnedEnvironment(t *testing.T) {
	if os.Getenv("DISPLAY") == "" {
		t.Skip("no X display; this one needs a real screen to capture")
	}
	if Resolve() == "" {
		t.Skip("no ffmpeg on this machine")
	}
	ffmpeg := Resolve()

	// Exactly the environment the bug happens in: PATH carries nothing.
	t.Setenv("PATH", "/nonexistent")
	if _, err := exec.LookPath("ffmpeg"); err == nil {
		t.Fatal("PATH was not actually stripped; the test would prove nothing")
	}
	if !ScreenRecorderAvailable() {
		t.Fatal("ScreenRecorderAvailable is false on a machine with ffmpeg installed — the reported bug")
	}

	screen, err := StartScreen(t.TempDir(), ScreenOptions{})
	if err != nil {
		t.Fatalf("StartScreen refused a machine that HAS ffmpeg: %v", err)
	}
	time.Sleep(4 * time.Second)

	data, err := screen.Stop()
	if err != nil {
		t.Fatalf("Stop: %v", err)
	}
	if len(data) < 1000 {
		t.Fatalf("recording is %d bytes — not a real capture", len(data))
	}

	// It has to be something a player will open, not just bytes on disk.
	out := filepath.Join(t.TempDir(), "session"+screen.Encoding().Extension)
	if err := os.WriteFile(out, data, 0o600); err != nil {
		t.Fatal(err)
	}
	probe := exec.Command(filepath.Join(filepath.Dir(ffmpeg), "ffprobe"),
		"-v", "error", "-show_entries", "stream=codec_name,width,height",
		"-of", "default=noprint_wrappers=1", out)
	probed, probeErr := probe.CombinedOutput()
	if probeErr != nil {
		t.Logf("recorded %d bytes as %s (ffprobe unavailable: %v)", len(data), screen.Encoding().Extension, probeErr)
		return
	}
	t.Logf("recorded %d bytes as %s\n%s", len(data), screen.Encoding().Extension, probed)
	if !strings.Contains(string(probed), "codec_name") {
		t.Fatalf("the artifact has no decodable video stream:\n%s", probed)
	}
}
