// pam-agent/internal/recorder/screen_lookup.go
//
// Finding ffmpeg, robustly enough that the answer does not depend on WHICH
// process asked.
//
// THE BUG THIS EXISTS FOR, measured on a Windows operator's machine: the
// Devices panel reported "Can record desktop sessions" while every desktop
// launch on a record-required resource was refused with "ffmpeg is not
// installed". Both answers came from the same function. Both were correct at
// the moment they were taken — and that is the whole problem.
//
// ScreenRecorderAvailable was a bare exec.LookPath, which reads the PATH of
// the CALLING PROCESS. The agent runs in two very different processes:
//
//	pam-agent pair / doctor   started by the operator in a shell. A shell
//	                          opened after installing ffmpeg has the new PATH.
//	pam-agent launch          started by the OS from the pam-agent:// URL
//	                          handler, so it inherits the BROWSER's
//	                          environment — and on Windows a process started
//	                          before the PATH was edited keeps the old block
//	                          for its whole life, handing that stale copy to
//	                          everything it spawns.
//
// So the operator installs ffmpeg, adds it to PATH, runs the agent once from
// a terminal (which reports "detected", and that is what the console keeps
// showing), and then every launch from their already-running browser cannot
// see it. Nothing is misconfigured; the two processes genuinely have
// different PATHs, and the product reported both truthfully and looked
// broken doing it.
//
// THE FIX is to stop treating PATH as the only place ffmpeg can be. The
// agent already does this properly for every GUI tool it launches —
// internal/discovery walks PATH, then per-OS well-known install locations,
// then a remembered override — and ffmpeg was the one tool left out of that
// treatment. This brings it in line: PATH first (cheap, correct when it
// works), then the standard install locations of every mainstream installer
// on each OS, then an explicit override an operator can set once.
//
// Everything that needs ffmpeg resolves through Resolve here, so the
// capability report and the launch-time refusal are answering the same
// question against the same evidence and cannot disagree again.
package recorder

import (
	"os"
	"os/exec"
	"runtime"
	"strings"
)

// OverrideEnv lets an operator name the ffmpeg to use when it is somewhere
// none of the standard locations cover — an unpacked build on a share, a
// bundled copy beside a vendored application.
//
// Read from the environment rather than the agent's config file because the
// case it exists for is exactly the one where the launching process has an
// environment nobody curated: a machine-wide setting an administrator can
// push once reaches the browser-spawned agent the same way PATH would.
const OverrideEnv = "PAM_AGENT_FFMPEG"

// wellKnownDirs returns the directories each platform's mainstream ffmpeg
// installers actually write to, in the order worth trying.
//
// Deliberately not a glob walk of the filesystem: this runs on the launch
// path, before the operator sees anything, and a scan of Program Files costs
// more than the problem is worth. These are the locations the installers
// documented for winget, Chocolatey, Scoop, Homebrew and the distributions —
// i.e. where ffmpeg IS, not where it might be.
func wellKnownDirs(goos string, env func(string) string) []string {
	switch goos {
	case "windows":
		local := env("LOCALAPPDATA")
		programFiles := env("ProgramFiles")
		programData := env("ProgramData")
		userProfile := env("USERPROFILE")

		dirs := []string{
			// winget shims, and the package's own unpack location.
			winJoin(local, "Microsoft", "WinGet", "Links"),
			winJoin(local, "Microsoft", "WinGet", "Packages"),
			// Chocolatey puts a shim on the machine-wide bin.
			winJoin(programData, "chocolatey", "bin"),
			// Scoop, per-user by default and machine-wide when configured.
			winJoin(userProfile, "scoop", "shims"),
			winJoin(programData, "scoop", "shims"),
			// The "download the zip and unpack it" path, which is still the
			// most common way ffmpeg arrives on Windows. C:\ffmpeg\bin is
			// what ffmpeg's own Windows instructions use.
			`C:\ffmpeg\bin`,
			winJoin(programFiles, "ffmpeg", "bin"),
		}
		return withoutEmptyRoots(goos, dirs)

	case "darwin":
		return []string{
			"/opt/homebrew/bin", // Apple Silicon Homebrew
			"/usr/local/bin",    // Intel Homebrew, and hand-installed builds
			"/opt/local/bin",    // MacPorts
			"/usr/bin",
		}

	default: // linux and the other unixes
		return []string{
			"/usr/bin",
			"/usr/local/bin",
			"/bin",
			"/snap/bin",
			"/var/lib/flatpak/exports/bin",
		}
	}
}

// winJoin builds a Windows path with explicit separators rather than
// filepath.Join.
//
// filepath is fixed to the BUILD platform: on a Linux builder it joins with
// "/" and filepath.IsAbs(`C:\x`) is false, so every Windows location here
// would be silently discarded — and the only machines that would notice are
// the Windows ones this code exists for, where no test runs. The agent's
// tool discovery already treats Windows paths as literals for the same
// reason (internal/discovery reads them verbatim out of the templates).
//
// Returns "" when the root is empty so withoutEmptyRoots can drop it.
func winJoin(root string, parts ...string) string {
	if strings.TrimSpace(root) == "" {
		return ""
	}
	return strings.TrimRight(root, `\`) + `\` + strings.Join(parts, `\`)
}

// isAbsOn answers "is this rooted" for the TARGET platform rather than the
// build platform, for the same reason winJoin exists.
func isAbsOn(goos, p string) bool {
	if p == "" {
		return false
	}
	if goos != "windows" {
		return strings.HasPrefix(p, "/")
	}
	// A drive-rooted path (C:\...) or a UNC share (\\server\share).
	if strings.HasPrefix(p, `\\`) {
		return true
	}
	return len(p) >= 3 && p[1] == ':' && (p[2] == '\\' || p[2] == '/')
}

// withoutEmptyRoots drops entries built from an environment variable that
// was not set. winJoin returns "" for those, and an empty or relative entry
// would otherwise resolve against whatever directory the launching process
// happened to be in — which could match a file that is not ffmpeg at all.
func withoutEmptyRoots(goos string, dirs []string) []string {
	out := make([]string, 0, len(dirs))
	for _, d := range dirs {
		if !isAbsOn(goos, d) {
			continue
		}
		out = append(out, d)
	}
	return out
}

// executableNames is what the binary is called on each platform.
func executableNames(goos string) []string {
	if goos == "windows" {
		return []string{ScreenRecorderName + ".exe"}
	}
	return []string{ScreenRecorderName}
}

// resolveOn is Resolve with the platform and environment injected, so the
// Windows and macOS branches are testable from any machine — the same reason
// internal/discovery takes a goos.
func resolveOn(goos string, env func(string) string, lookPath func(string) (string, error), stat func(string) (os.FileInfo, error)) string {
	// 1. An explicit override always wins. An operator who has set this has
	//    told us something we cannot work out for ourselves.
	if override := strings.TrimSpace(env(OverrideEnv)); override != "" {
		if usable(override, stat) {
			return override
		}
		// A set-but-wrong override is NOT a silent fallback to search: it
		// means the machine has been configured and the configuration is
		// broken, which the operator needs to find out. Fall through so the
		// launch can still work, but the doctor report names it — see
		// OverrideProblem.
	}

	// 2. PATH, which is right whenever the process has a sane environment.
	for _, name := range executableNames(goos) {
		if p, err := lookPath(name); err == nil && p != "" {
			return p
		}
	}

	// 3. The locations the installers use. This is the branch that rescues a
	//    browser-spawned launch on Windows.
	for _, dir := range wellKnownDirs(goos, env) {
		for _, name := range executableNames(goos) {
			candidate := dir + "/" + name
			if goos == "windows" {
				candidate = winJoin(dir, name)
			}
			if usable(candidate, stat) {
				return candidate
			}
		}
	}
	return ""
}

// usable reports whether a path is a real file we could execute. Directories
// are rejected explicitly: a folder named "ffmpeg" is a perfectly ordinary
// thing to find next to an unpacked build, and exec-ing one fails with an
// error that reads like a corrupt install rather than a wrong path.
func usable(path string, stat func(string) (os.FileInfo, error)) bool {
	info, err := stat(path)
	if err != nil || info.IsDir() {
		return false
	}
	return true
}

// Resolve returns the absolute path to ffmpeg, or "" when this machine has
// none. Every caller that needs the recorder goes through this.
func Resolve() string {
	return resolveOn(runtime.GOOS, os.Getenv, exec.LookPath, os.Stat)
}

// OverrideProblem describes a PAM_AGENT_FFMPEG that is set but does not point
// at a usable file, for the doctor report. Empty when there is nothing wrong
// — either because no override is set, or because it works.
func OverrideProblem() string {
	override := strings.TrimSpace(os.Getenv(OverrideEnv))
	if override == "" || usable(override, os.Stat) {
		return ""
	}
	return OverrideEnv + " is set to " + override + ", which is not a file this agent can run — " +
		"unset it, or point it at the ffmpeg executable itself rather than its folder"
}

// ResolvedFrom explains WHERE the ffmpeg in use was found, for the doctor
// report and the launch log. An operator debugging "it says installed but the
// launch disagrees" needs to know which of the three answers they got.
func ResolvedFrom() (path, how string) {
	path = Resolve()
	if path == "" {
		return "", "not found"
	}
	if override := strings.TrimSpace(os.Getenv(OverrideEnv)); override != "" && override == path {
		return path, "the " + OverrideEnv + " override"
	}
	for _, name := range executableNames(runtime.GOOS) {
		if p, err := exec.LookPath(name); err == nil && p == path {
			return path, "PATH"
		}
	}
	return path, "a standard install location (not on this process's PATH)"
}
