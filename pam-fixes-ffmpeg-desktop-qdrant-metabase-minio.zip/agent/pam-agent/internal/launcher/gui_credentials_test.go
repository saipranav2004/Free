package launcher

import (
	"encoding/json"
	"os"
	"testing"
)

// What each DESKTOP client is actually handed, stated in one place.
//
// The report behind this: "all 4 desktop applications open without the stored
// credentials — only the mongo one arrives connected." That is accurate, and
// this pins exactly how much of it is fixable. Two of these tools cannot be
// handed a credential at all — they have no command line that takes one and
// they always prompt — so the closest thing to "already logged in" is landing
// on their own prompt with the password one paste away. RedisInsight was
// getting nothing whatsoever, which was the one real gap.
func TestEveryDesktopClientGetsTheBestCredentialHandoffItSupports(t *testing.T) {
	raw, err := os.ReadFile("launch-templates.default.json")
	if err != nil {
		t.Fatal(err)
	}
	var templates map[string][]struct {
		ID                  string `json:"id"`
		Kind                string `json:"kind"`
		CredentialInjection string `json:"credential_injection"`
	}
	if err := json.Unmarshal(raw, &templates); err != nil {
		t.Fatal(err)
	}

	want := map[string]string{
		// Compass takes the whole connection string on its command line, so
		// it opens genuinely connected. This is the one the report saw work.
		"mongodb-compass": "connection_string_arg",
		// pgAdmin4's server tree is pre-registered with host/port/user, and
		// the password goes to the clipboard: its "Connect to Server" dialog
		// is a UI gate shown before any libpq connection is attempted, so
		// PGPASSFILE is never consulted. Confirmed live; see templates.go.
		"pgadmin4": "pgadmin_preseed",
		// SQL Developer takes no connection on its command line at all.
		"sqldeveloper": "clipboard",
		// RedisInsight is the same shape — no connection argument, always its
		// own dialog — and was the one getting "none": no preseed, no
		// clipboard, nothing. An operator had to go and find the password.
		"redisinsight": "clipboard",
	}

	seen := map[string]string{}
	for _, cands := range templates {
		for _, c := range cands {
			if c.Kind == "gui" {
				seen[c.ID] = c.CredentialInjection
			}
		}
	}

	for id, expected := range want {
		got, ok := seen[id]
		if !ok {
			t.Errorf("no gui template for %s", id)
			continue
		}
		if got != expected {
			t.Errorf("%s: credential_injection = %q, want %q", id, got, expected)
		}
	}

	// The real assertion: nothing that opens a desktop client leaves the
	// operator with no way to authenticate.
	for id, mode := range seen {
		if mode == "" || mode == "none" {
			t.Errorf("%s hands the operator nothing at all — no argument, no preseed, no clipboard", id)
		}
	}
}
