# This round — the five things you raised

Only the files touched answering those five. Apply on top of the
`pam-complete.zip` tree. `proof/` holds the screenshots and video referenced
below.

---

## 1. "ffmpeg is installed and on PATH, Settings says detected, but a desktop launch says it is not installed"

**Real bug, found and fixed.** Both answers were produced by the same
function, and both were correct at the moment they were taken — which is the
whole problem.

`ScreenRecorderAvailable` was a bare `exec.LookPath`, which reads the PATH of
**the calling process**. The agent runs in two very different processes:

| process | started by | PATH it sees |
|---|---|---|
| `pam-agent pair` / `doctor` | you, in a shell | a shell opened after installing ffmpeg has the new PATH |
| `pam-agent launch` | the OS, from the `pam-agent://` URL handler | it inherits **the browser's** environment |

On Windows a process started before PATH was edited keeps the old environment
block for its whole life and hands that stale copy to everything it spawns. So
you installed ffmpeg, ran the agent once from a terminal — which is the report
the console is still showing — and every launch from your already-running
browser genuinely could not see it. Nothing was misconfigured.

**Fixed** in `internal/recorder/screen_lookup.go` (new): ffmpeg is now resolved
the way the agent already resolves every GUI tool it launches — PATH first,
then the standard install locations of every mainstream installer per OS
(winget, Chocolatey, Scoop, `C:\ffmpeg\bin`, Homebrew, MacPorts, apt, snap),
then an explicit `PAM_AGENT_FFMPEG` override. The capability report and the
launch-time check now resolve through the same function and cannot disagree
again.

**Proof**, same machine, same command, PATH stripped to simulate the
browser-spawned launch:

```
OLD binary:  [!!] ffmpeg (not on PATH)   ← your symptom
NEW binary:  [ok] ffmpeg (found)
```

And a real capture from that same stripped environment, against a real
display: **2757 bytes, VP9/WebM, 1920x1080, decodable** — where the old build
returned `ErrScreenRecorderMissing` and refused the launch.

`pam-agent doctor` now also names *which* ffmpeg it resolved and *how*, which
is the question you were left with:

```
note   ffmpeg at /usr/bin/ffmpeg, found via a standard install location (not on this process's PATH)
```

A `PAM_AGENT_FFMPEG` that is set but wrong is now reported as a problem rather
than silently ignored.

**Also on your Windows box:** the old advice ("make sure ffmpeg.exe is on
PATH") sent you to check the one thing that was already true. The hint now
leads with the real cause — close and reopen the browser so the agent it
launches inherits the current PATH.

---

## 2. "All four desktop apps open without credentials; only the mongo one is logged in"

**Your observation is exactly right, and it is three different situations.**
Here is the honest breakdown:

| resource | desktop client | what it gets | why |
|---|---|---|---|
| mongodb | MongoDB Compass | **fully connected** | Compass takes the whole connection string on its command line |
| postgresql | pgAdmin 4 | server pre-registered (host/port/user), password on clipboard | pgAdmin 4's "Connect to Server" dialog is its own UI gate, shown *before* it attempts any libpq connection — `PGPASSFILE` is never consulted. Confirmed live; it is a limit of pgAdmin 4, not of PAM |
| oracle | SQL Developer | password on clipboard | SQL Developer takes no connection on its command line at all |
| redis | RedisInsight | **was getting nothing** → now clipboard | **this was the real gap** |

RedisInsight's template had `credential_injection: "none"` — no argument, no
preseed, no clipboard. You had to go and find the password yourself. It now
gets the same clipboard handoff Oracle already had, so you land on its own
dialog with the password one paste away.

`gui_credentials_test.go` (new) pins all four and fails if any desktop client
is ever left handing the operator nothing again.

**Being straight with you:** pgAdmin 4 and SQL Developer cannot be made to
open *already logged in* from outside. Neither accepts a credential
headlessly. The CLI path (psql, sqlplus) is the genuinely headless one, which
is why it works the way you described. If "open in desktop must land connected"
is a hard requirement for those two, that needs a different mechanism than the
agent has today, and I would rather say so than imply it is a small fix.

The **no recording** half of this item was the same root cause as #1 — ffmpeg
not resolving at launch — and is fixed by the same change.

---

## 3. "Qdrant has an API key and no username, but PAM demands a username"

**Real bug.** Both layers required it unconditionally:

- backend: `AccountName string \`binding:"required"\``
- console: `username: z.string().trim().min(1, 'Required')`

So storing a Qdrant credential meant typing something untrue into the vault —
and that fabricated principal then rides along on every audit row that
credential ever appears in.

**Fixed.** Account name is now required only for credential types that
authenticate *as* a named account (password, SSH key, X.509, Kerberos keytab)
and optional for the types that *are* the identity (API key, OAuth/OIDC token,
connection string). The console field stops showing "(required)" and explains
why. The backend enforces the same rule — `accountNameRequiredFor` in
`resource_handler.go` is the enforcing copy, the console one only decides what
the form asks for.

**Proof**, live against the running server:

```
api_key,  no account name  → 201 Created     (the Qdrant case)
token,    no account name  → 201 Created
password, no account name  → 400 "account_name is required for a password
                                   credential, which authenticates as a named account"
password, account "   "    → 400  (a blank principal is not accepted either)
```

**On "how did you test it":** fairly asked. Qdrant only has a `browser`
template, so my earlier testing drove it through the brokered web session, and
the harness seeded its credential directly through the API with a placeholder
account name. I never stored a Qdrant credential through the form the way you
did, which is exactly why this survived. That gap is now covered by the four
cases above.

---

## 4. "Check Metabase, test it completely"

**Found a gap.** Metabase had no inferred auth strategy, so it fell to
`strategyNone`: the proxy worked and the session was recorded, but the
operator still had to know a Metabase password — the one thing a privileged
access product exists to remove. (MinIO had its own strategy; Metabase simply
never got one.)

**Fixed** — `authenticator_metabase.go` (new) speaks Metabase's documented
session API (`POST /api/session` → `metabase.SESSION` cookie), including older
builds that return the session id in the body instead of setting a cookie.
An explicit `web_auth_strategy` on the resource still overrides it, so a
Metabase behind SSO can turn it off.

**Tested completely**, end to end through the real proxy — `e2e/metabase.mjs`,
**12/12**:

- opens a brokered session and picks `metabase_session`, not `none`
- the operator lands **signed in**, not on the login form
- the signed-in identity is the vaulted account
- Metabase content renders through the proxy
- **the password never reaches the browser** — not in the DOM, not in
  `document.cookie`, not in local/session storage
- the upstream session cookie is not exposed to page script
- the browser delivered rrweb batches, and the session left a **visual**
  recording
- wrong password is blamed on the credential; a non-Metabase target is blamed
  on `console_url`, not on the vault

---

## 5. MinIO — the bucket opens but the file list spins forever

**You were right, and my earlier testing was checking the wrong thing.**

The bucket **list** is a plain REST call and was never broken. The file list
**inside** a bucket is not — MinIO Console fetches it over
`/ws/objectManager`. Every suite I had stopped one click short of that, so
they reported green while the thing you were looking at was broken.

`e2e/minio-objects.mjs` (new) makes that click, and
`e2e/minio-objects-ingress.mjs` (new) drives it through a real TLS ingress in
the two shapes that decide the outcome. Same PAM build, same MinIO, same
bucket — the only difference is three nginx lines:

| ingress | bucket list | file list inside the bucket |
|---|---|---|
| **with** `proxy_http_version 1.1` + `Upgrade` + `Connection` | loads | **all 12 files listed** |
| **without** those three lines | loads | **"Loading..." forever**, 20 socket errors |

`proof/minio-BROKEN-ingress-spinner.png` is a pixel-match for the screenshot
you sent — bucket list on the left, header correctly reading "12 Objects",
main pane spinning. `proof/minio-CORRECT-ingress-files-listed.png` is the same
session with the ingress fixed.

**So the fix is in your ingress, not in PAM.** In the location that proxies to
PAM:

```nginx
proxy_http_version 1.1;
proxy_set_header Upgrade    $http_upgrade;
proxy_set_header Connection "upgrade";
```

`deploy/nginx-websocket-reference.conf` is the exact working ingress from the
test rig above (the correct lane on :8443, the broken lane on :9443 for
comparison), if you want something to diff your own config against.

On an AWS ALB/ELB, use a target group with protocol version HTTP/1.1.
If you are on k8s ingress-nginx this is usually already on, but a custom
`configuration-snippet` or a proxy in front of the ingress can still strip it.

PAM detects this exact shape and logs the remedy (`webproxy.upgrade.stripped`),
and since last round it also writes it to the Audit page and shows a banner on
the affected session's recording — so you can confirm it from the console
without server log access.

### The recording you asked to see

`proof/minio-session-replay.mp4` — the PAM console replaying a real 57-second
brokered MinIO session, filmed from the product itself at 4x. You can watch
the bucket list, buckets being created during the session, and the transport
running to 00:54/00:54.

Note the artifact PAM stores is an **rrweb event stream**, not a video file —
the console reconstructs the screen from DOM events at replay time, which is
why it is searchable and ~1 MB for a minute instead of tens of MB. That cannot
be opened in a media player, so `e2e/capture-replay-video.mjs` (new) films the
player and produces the MP4 for exactly this purpose: showing someone the
recording outside the product.

---

## Verified

- backend `go build` + `go test ./...` — **13 packages, all pass**
- agent `go build` + `go test ./...` — **8 packages, all pass**, plus all five
  cross-builds (linux/darwin/windows, amd64+arm64)
- console `npm run lint` (`--max-warnings 0`) and `npm run build` — clean
- browser suites re-run in full, including the three new ones

One **existing** browser suite also failed and was corrected in the test, not
the product: `replay-video.mjs` looked for the desktop video recording only on
page one of the recordings table. Recordings are never pruned, so this
session's own runs buried it. It now pages through — via the API and via the
console's pager — and matches on session id rather than resource name (the
same resource also has rrweb and asciicast recordings, and opening one of
those reported "no `<video>`" as if the player were broken). With that fixed
it is **9/9**, and it is real proof for item 1: a genuine ffmpeg-captured
desktop recording replays in the console at **1920x1080, VP9, 10.0s, playing**
— the artifact type that was not being produced at all when ffmpeg failed to
resolve.

Two **existing** agent tests failed against this change and were corrected, not
suppressed: both simulated "this machine has no ffmpeg" by emptying PATH,
which stopped meaning that once resolution learned to check the standard
install locations. They now state the premise directly via an injected
parameter — the same pattern `launcher.Capabilities` already used — so they
test what their names claim.
