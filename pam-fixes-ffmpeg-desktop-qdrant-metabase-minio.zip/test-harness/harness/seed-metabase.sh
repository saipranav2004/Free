#!/bin/bash
# The metabase resource + its vaulted credential, for e2e/metabase.mjs.
set -e
S=/tmp/claude-0/-home-user-ueba-pipeline-production/971148d6-bce9-583f-aaf4-52b8e9c586ef/scratchpad
export PGPASSWORD=$(grep '^PAM_DATABASE_PASSWORD=' $S/harness/api.env | cut -d= -f2-)
RID=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT user_id FROM pam.pam_users WHERE username='root';")
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c "
DELETE FROM pam.pam_credentials WHERE resource_id='metabase-real';
DELETE FROM pam.pam_resources   WHERE id='metabase-real';
INSERT INTO pam.pam_resources (id,name,description,resource_type,host,port,connect_mode,console_url,is_active,always_record,created_by,created_at,updated_at)
VALUES ('metabase-real','metabase-real','Metabase for brokered-session tests','metabase','127.0.0.1',3100,'embed_redirect','http://127.0.0.1:3100',true,true,'$RID',NOW(),NOW());"

T=$(cat /tmp/tok)
SAFE=$(psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -At -c "SELECT id FROM pam.pam_safes ORDER BY created_at LIMIT 1;")
CID=$(curl -s --noproxy '*' -X POST -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
  -d '{"name":"metabase-analyst","account_name":"analyst@example.com","secret_plaintext":"metabase-local-only-123","credential_type":"password","resource_id":"metabase-real","description":"Local Metabase"}' \
  "http://127.0.0.1:8080/api/v1/pam/safes/$SAFE/credentials" \
  | python3 -c "import sys,json;print((json.load(sys.stdin).get('data') or {}).get('id',''))")
if [ -z "$CID" ]; then echo "could not vault the credential — is /tmp/tok fresh?" >&2; exit 1; fi
psql -h 127.0.0.1 -p 5433 -U postgres -d postgres -q -c \
  "UPDATE pam.pam_resources SET vault_entry_id='$CID' WHERE id='metabase-real';"
echo "seeded metabase-real with vaulted credential $CID"
