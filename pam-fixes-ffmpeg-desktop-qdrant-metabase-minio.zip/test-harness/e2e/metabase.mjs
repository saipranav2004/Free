// Metabase, end to end through PAM's brokered web session.
//
// The gap this covers: a metabase resource used to infer the "none" auth
// strategy, so the proxy worked and the session was recorded but the operator
// still had to know a Metabase password — the one thing a privileged access
// product exists to remove. This drives the whole path: PAM logs in
// server-side, the operator lands signed in, the credential never reaches the
// browser, and the session is recorded.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const PASSWORD = 'metabase-local-only-123'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  return { ok: r.ok, status: r.status, data: (await r.json().catch(() => ({}))).data }
}

const open = await api('pam/resources/metabase-real/web-session', { method: 'POST', body: '{}' })
check('PAM opens a brokered session for a metabase resource', open.ok, `HTTP ${open.status}`)
if (!open.ok) process.exit(1)
const { launch_url, session_id, web_proxy_session_id } = open.data

// The strategy actually chosen, from the session row PAM wrote.
const sessions = await api('pam/admin/web-sessions')
const row = (sessions.data?.sessions || sessions.data || []).find((s) => s.id === web_proxy_session_id)
check('it authenticates with the Metabase session strategy, not "none"',
  row?.auth_strategy === 'metabase_session', row?.auth_strategy || 'unknown')

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
const page = await ctx.newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))

await page.goto(launch_url, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2500)

// Count the recorder's own batches, so "was it recorded" is answered by what
// the browser actually sent rather than inferred from the artifact alone.
let replayBatches = 0
page.on('request', (r) => {
  if (r.url().includes('/__pam/replay') && r.method() === 'POST') replayBatches++
})

const text = await page.locator('body').innerText()
check('the operator lands signed in, not on the login form',
  /Our analytics/i.test(text) && !/Sign in to Metabase/i.test(text),
  text.replace(/\s+/g, ' ').slice(0, 80))
check('the signed-in identity is the vaulted account',
  /analyst@example\.com/.test(text))
check('Metabase content renders through the proxy',
  (await page.locator('#collections li').count()) === 3)

// The credential must never be reachable from the browser: not in the DOM,
// not in storage, not in a cookie the page can read.
const leaked = await page.evaluate((pw) => {
  const inDom = document.documentElement.innerHTML.includes(pw)
  const inCookie = document.cookie.includes(pw)
  let inStorage = false
  try {
    for (const s of [localStorage, sessionStorage]) {
      for (let i = 0; i < s.length; i++) if (String(s.getItem(s.key(i))).includes(pw)) inStorage = true
    }
  } catch { /* storage may be blocked; that is not a leak */ }
  return { inDom, inCookie, inStorage }
}, PASSWORD)
check('the password never reaches the browser', !leaked.inDom && !leaked.inCookie && !leaked.inStorage,
  JSON.stringify(leaked))

// The session cookie is HttpOnly, so script on the page cannot lift it.
const jar = await ctx.cookies()
const mb = jar.find((c) => c.name === 'metabase.SESSION')
check('the upstream session cookie is not exposed to page script', !mb || mb.httpOnly,
  mb ? `httpOnly=${mb.httpOnly}` : 'held server-side only')

check('no page errors', errors.length === 0, errors.slice(0, 2).join(' | '))

// A session the length of a real one. The recorder batches on a 5s interval
// (pam-replay.js FLUSH_MS), so a browser closed in three seconds sends
// nothing and the artifact falls back to the request transcript — which is
// the recorder working as designed, not a failure, but it tests nothing.
// This browses the way an operator would and outlives that interval.
for (let i = 0; i < 3; i++) {
  await page.mouse.move(280 + i * 140, 300 + i * 60, { steps: 10 })
  await page.locator('#collections li').nth(i).hover().catch(() => {})
  await page.waitForTimeout(3000)
}
await page.waitForTimeout(2000)
check('the browser delivered rrweb batches to PAM', replayBatches > 0, `${replayBatches} batch(es)`)

await browser.close()
const ended = await api(`pam/web-sessions/${web_proxy_session_id}/end`, { method: 'POST', body: '{}' })
check('the session ends cleanly', ended.ok, `HTTP ${ended.status}`)
await new Promise((r) => setTimeout(r, 2500))

const recs = await api(`pam/admin/recordings?session_id=${session_id}`)
const rec = (recs.data?.recordings || [])[0]
check('the session left a recording', !!rec,
  rec ? `${rec.format} ${rec.status} ${rec.size_bytes}B` : 'none')
check('it is the visual replay, not just a request log', rec?.format === 'rrweb', rec?.format)

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
