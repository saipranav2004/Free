// The reported failure, precisely: the bucket LIST loads, and then opening a
// bucket shows "Loading..." forever and never lists the files inside it.
//
// Why the earlier suites missed it. minio-real.mjs asserts "the bucket list
// loads", and the bucket list is a plain REST call (GET /api/v1/buckets) that
// was never broken. The OBJECT list inside a bucket is not: MinIO Console
// fetches it over the /ws/objectManager WebSocket. So every previous test
// stopped one click short of the thing that fails, and reported green.
//
// This drives the click that matters: open a bucket that has objects in it,
// and require the objects to actually appear.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const BUCKET = process.env.PAM_TEST_BUCKET || 'pam-objects'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  return { ok: r.ok, status: r.status, data: (await r.json().catch(() => ({}))).data }
}

const open = await api('pam/resources/minio-real/web-session', { method: 'POST', body: '{}' })
if (!open.ok) { console.log('could not open a session', open.status); process.exit(1) }
const { launch_url, web_proxy_session_id } = open.data

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
const page = await ctx.newPage()

// Watch the object-manager socket specifically: it is the one the file list
// depends on, and the one the report showed failing over and over.
const sockets = []
page.on('websocket', (ws) => {
  const rec = { url: ws.url(), ok: true, frames: 0, closed: false }
  ws.on('socketerror', () => { rec.ok = false })
  ws.on('framereceived', () => { rec.frames++ })
  ws.on('close', () => { rec.closed = true })
  sockets.push(rec)
})
const wsErrors = []
page.on('console', (m) => {
  const t = m.text()
  if (/websocket/i.test(t) && /(fail|error|disconnect)/i.test(t)) wsErrors.push(t.slice(0, 120))
})

await page.goto(launch_url, { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(6000)

// Dismiss MinIO's first-run licence modal if it is up, so it cannot be
// mistaken for the app failing to load.
const dialog = page.locator('[role="dialog"]').first()
if (await dialog.count()) {
  await dialog.getByRole('button', { name: /acknowledge|accept|close|ok|agree|got it/i }).first().click({ timeout: 1500 }).catch(() => {})
  await page.keyboard.press('Escape').catch(() => {})
  await page.waitForTimeout(800)
}

check('the bucket list loads (the part that always worked)',
  /Buckets/i.test(await page.locator('body').innerText()))

// ── the click the earlier suites never made ────────────────────────────────
await page.goto(new URL(`/browser/${BUCKET}`, page.url()).toString(), { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2000)
const dialog2 = page.locator('[role="dialog"]').first()
if (await dialog2.count()) {
  await dialog2.getByRole('button', { name: /acknowledge|accept|close|ok|agree|got it/i }).first().click({ timeout: 1500 }).catch(() => {})
  await page.keyboard.press('Escape').catch(() => {})
}

// Give the object list a generous, explicit window to arrive. The failure
// mode is a spinner that never resolves, so this waits for the OBJECTS and
// reports the spinner if they never come, rather than sleeping and guessing.
let listed = false
const deadline = Date.now() + 25000
while (Date.now() < deadline && !listed) {
  const body = await page.locator('body').innerText().catch(() => '')
  if (/report-01\.txt/.test(body)) { listed = true; break }
  await page.waitForTimeout(1000)
}

const finalText = await page.locator('body').innerText().catch(() => '')
const stillSpinning = /Loading\.\.\./i.test(finalText) && !listed

check('opening a bucket lists the files inside it', listed,
  listed ? 'objects rendered' : (stillSpinning ? 'still showing "Loading..." after 25s — the reported bug' : finalText.replace(/\s+/g, ' ').slice(0, 110)))

if (listed) {
  const shown = (finalText.match(/report-\d\d\.txt/g) || []).length
  check('every object in the bucket is listed', shown >= 12, `${shown} of 12 shown`)
}

const objectManager = sockets.filter((s) => s.url.includes('objectManager'))
check('the object-manager websocket was opened', objectManager.length > 0,
  objectManager.map((s) => s.url.replace(/^wss?:\/\/[^/]+/, '')).join(', ') || 'none')
check('it connected rather than erroring', objectManager.every((s) => s.ok),
  objectManager.map((s) => (s.ok ? 'ok' : 'ERR')).join(', '))
check('it actually carried the object listing', objectManager.some((s) => s.frames > 0),
  objectManager.map((s) => `${s.frames} frames`).join(', '))
check('the browser reported no websocket failures', wsErrors.length === 0,
  wsErrors.slice(0, 2).join(' | '))

await page.screenshot({ path: '/tmp/minio-objects.png' })
await browser.close()
await api(`pam/web-sessions/${web_proxy_session_id}/end`, { method: 'POST', body: '{}' })

const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
