// A stand-in shaped like Metabase: its documented session API, a session
// cookie, and a dashboard that only renders for an authenticated caller.
// Enough to prove PAM signs the operator in server-side and that the browser
// never sees the credential.
const http = require('http')
const PORT = Number(process.argv[2] || 3100)
const USER = process.env.MB_USER || 'analyst@example.com'
const PASS = process.env.MB_PASS || 'metabase-local-only-123'
const SESSION = 'mb-sess-' + Math.random().toString(36).slice(2, 10)

const html = (body) => `<!doctype html><html><head><title>Metabase</title></head><body>${body}</body></html>`

http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`)
  const cookies = Object.fromEntries(
    (req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0])
  )
  const authed = cookies['metabase.SESSION'] === SESSION

  if (url.pathname === '/api/session' && req.method === 'POST') {
    let body = ''
    req.on('data', (d) => (body += d))
    req.on('end', () => {
      let parsed = {}
      try { parsed = JSON.parse(body) } catch { /* fall through to 400 */ }
      if (parsed.username !== USER || parsed.password !== PASS) {
        res.writeHead(401, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ errors: { password: 'did not match stored password' } }))
      }
      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Set-Cookie': `metabase.SESSION=${SESSION}; Path=/; HttpOnly; SameSite=Lax`,
      })
      res.end(JSON.stringify({ id: SESSION }))
    })
    return
  }

  if (url.pathname === '/api/user/current') {
    if (!authed) { res.writeHead(401); return res.end('{}') }
    res.writeHead(200, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ email: USER, first_name: 'Analyst', is_superuser: true }))
  }

  if (!authed) {
    res.writeHead(200, { 'Content-Type': 'text/html' })
    return res.end(html('<h1 id="login">Sign in to Metabase</h1><form><input id="username"><input id="password" type="password"></form>'))
  }

  res.writeHead(200, { 'Content-Type': 'text/html' })
  res.end(html(`<h1 id="dashboard">Our analytics</h1><p id="who">Signed in as ${USER}</p>
    <ul id="collections"><li>Revenue</li><li>Retention</li><li>Funnels</li></ul>`))
}).listen(PORT, '127.0.0.1', () => console.log('metabase stub on ' + PORT))
