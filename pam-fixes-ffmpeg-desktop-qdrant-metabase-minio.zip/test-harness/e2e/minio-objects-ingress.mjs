// The object list inside a bucket, driven through a REAL TLS ingress in the
// two shapes that decide the outcome — because that is the topology the
// failure was reported from (wss:// on a real wildcard domain), and it is not
// reproducible on loopback.
//
//   :8443  ingress WITH proxy_http_version 1.1 + Upgrade + Connection
//   :9443  the SAME ingress with those three lines missing
//
// The bucket list is REST and loads on both. The file list inside a bucket is
// not: it arrives over /ws/objectManager, so it is the half that dies when an
// ingress swallows the upgrade — which is exactly the reported symptom, a
// bucket that opens and then shows "Loading..." forever.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const BUCKET = process.env.PAM_TEST_BUCKET || 'pam-objects'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  return { ok: r.ok, status: r.status, data: (await r.json().catch(() => ({}))).data }
}


// MinIO's first-run licence modal is not marked role="dialog", so it has to
// be found by its own button. It reappears on every navigation until it is
// acknowledged, which is why this is called after each one.
async function dismissLicence(page) {
  for (let i = 0; i < 3; i++) {
    const btn = page.getByRole('button', { name: /acknowledge|accept|agree|got it/i }).first()
    if ((await btn.count()) === 0) return
    await btn.click({ timeout: 1500 }).catch(() => {})
    await page.waitForTimeout(400)
  }
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: [
    '--no-sandbox', '--no-proxy-server', '--ignore-certificate-errors',
    '--host-resolver-rules=MAP *.pam.test 127.0.0.1',
  ],
})

async function lane(port, label) {
  console.log(`\n=== ${label} (port ${port}) ===`)
  const open = await api('pam/resources/minio-real/web-session', { method: 'POST', body: '{}' })
  if (!open.ok) { check(`${label}: session opens`, false, `HTTP ${open.status}`); return null }
  const url = open.data.launch_url.replace(':8443', `:${port}`)

  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, ignoreHTTPSErrors: true })
  const page = await ctx.newPage()
  const objectManager = []
  page.on('websocket', (ws) => {
    if (!ws.url().includes('objectManager')) return
    const rec = { ok: true, frames: 0 }
    ws.on('socketerror', () => { rec.ok = false })
    ws.on('framereceived', () => { rec.frames++ })
    objectManager.push(rec)
  })

  await page.goto(url, { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(5000)
  await dismissLicence(page)
  await page.waitForTimeout(600)

  const bucketListLoaded = /Buckets/i.test(await page.locator('body').innerText().catch(() => ''))

  // Into the bucket — the click that matters.
  await page.goto(new URL(`/browser/${BUCKET}`, page.url()).toString(), { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(2000)
  await dismissLicence(page)

  let listed = false
  const deadline = Date.now() + 22000
  while (Date.now() < deadline && !listed) {
    if (/report-01\.txt/.test(await page.locator('body').innerText().catch(() => ''))) { listed = true; break }
    await page.waitForTimeout(1000)
  }
  const body = await page.locator('body').innerText().catch(() => '')
  const spinning = /Loading\.\.\./i.test(body) && !listed

  await page.screenshot({ path: `/tmp/minio-objects-${port}.png` })
  await ctx.close()
  await api(`pam/web-sessions/${open.data.web_proxy_session_id}/end`, { method: 'POST', body: '{}' })
  return { bucketListLoaded, listed, spinning, objectManager }
}

const good = await lane(8443, 'ingress configured correctly')
if (good) {
  check('the bucket list loads', good.bucketListLoaded)
  check('opening a bucket LISTS THE FILES', good.listed,
    good.listed ? 'objects rendered' : (good.spinning ? 'stuck on "Loading..."' : 'no objects'))
  check('the object-manager socket connected', good.objectManager.length > 0 && good.objectManager.every((s) => s.ok),
    good.objectManager.map((s) => (s.ok ? `ok/${s.frames}f` : 'ERR')).join(', ') || 'none opened')
}

const broken = await lane(9443, 'ingress MISSING the three upgrade directives')
if (broken) {
  check('the bucket list still loads on the broken lane — which is why this looks like a PAM bug',
    broken.bucketListLoaded)
  check('and the FILE LIST is the half that dies — the reported symptom exactly',
    !broken.listed,
    broken.spinning ? 'stuck on "Loading..." forever' : 'objects did not render')
  check('the object-manager socket is what failed', broken.objectManager.every((s) => !s.ok || s.frames === 0),
    broken.objectManager.map((s) => (s.ok ? `ok/${s.frames}f` : 'ERR')).join(', ') || 'none opened')
}

// PAM names the fix in its own log rather than leaving a silent spinner.
const log = readFileSync('/tmp/pam-api-tls.log', 'utf8')
check('PAM logged the diagnosis with the nginx lines to add',
  log.includes('webproxy.upgrade.stripped'),
  (log.split('\n').find((l) => l.includes('webproxy.upgrade.stripped')) || '').slice(0, 100))

await browser.close()
const failed = checks.filter((c) => !c.ok)
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`)
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach((f) => console.log('  - ' + f.name + (f.detail ? ' — ' + f.detail : '')))
  process.exit(1)
}
console.log('ALL CHECKS PASSED')
