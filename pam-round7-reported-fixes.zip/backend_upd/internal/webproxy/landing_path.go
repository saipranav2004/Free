// pam/internal/webproxy/landing_path.go
//
// Where a brokered session should ARRIVE, when the resource does not say.
//
// THE REPORT. Opening a Qdrant resource dropped the operator on a page
// showing:
//
//	{"title":"qdrant - vector search engine","version":"1.19.1","commit":"..."}
//
// Nothing was broken. That is exactly what Qdrant serves at "/" — its version
// banner. Qdrant's web UI lives at /dashboard, and the resource's console URL
// had no path, so PAM landed on the root and the operator saw a line of JSON
// where they expected a console. It also made the session look unrecorded: a
// JSON document produces no DOM activity, so there was nothing for the visual
// recorder to capture and the session fell back to a request transcript.
//
// Asking every operator to remember to type "/dashboard" into the console URL
// is not a fix; it is the same knowledge, moved. PAM already knows the
// resource type, and where each of these applications keeps its UI is a fact
// about the application, not about the deployment — so it belongs here.
//
// An explicit path on the resource's console URL always wins. This only fills
// in a blank.
package webproxy

import (
	"net/url"
	"strings"
)

// landingPathByType maps a resource type to the path its web UI actually
// lives at, for the applications whose UI is NOT at the root.
//
// Deliberately small. A guess that lands somewhere wrong is worse than the
// root, because the root at least tells the operator something true about the
// service; so an application only appears here once its UI path is a
// documented, stable fact about that application.
var landingPathByType = map[string]string{
	// Qdrant serves its version banner at "/" and its console at /dashboard.
	// Verified against Qdrant 1.12.4 and reported against 1.19.1.
	"qdrant": "/dashboard",
}

// DefaultLandingPath returns the path a brokered session should land on for a
// resource type when its console URL carries no path of its own. An empty
// return means "the root", which is correct for every application whose UI is
// served there — MinIO, Metabase, Langfuse and the rest.
func DefaultLandingPath(resourceType string) string {
	return landingPathByType[strings.ToLower(strings.TrimSpace(resourceType))]
}

// applyDefaultLandingPath fills in a target's path from the resource type,
// and only when the resource itself named none. An explicit path on the
// console URL is the operator's decision and is never overridden.
func applyDefaultLandingPath(u *url.URL, resourceType string) {
	if u == nil {
		return
	}
	if p := strings.TrimSpace(u.Path); p != "" && p != "/" {
		return
	}
	if def := DefaultLandingPath(resourceType); def != "" {
		u.Path = def
	}
}
