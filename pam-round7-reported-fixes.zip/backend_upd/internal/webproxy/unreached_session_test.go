package webproxy

import (
	"strings"
	"testing"
)

// The reported artifact: a 1.4 KB transcript with a header, no requests and
// no replay, which reads as "recording is broken on Windows". It is not — the
// browser never reached the session at all, and nothing said so.
func TestASessionNoBrowserReachedSaysSoInItsOwnTranscript(t *testing.T) {
	note := unreachedSessionNote("minio-web-df539cf0.dashboard-dev.adapid.link", 0, 0)
	if note == "" {
		t.Fatal("a session with no requests and no replay produced no explanation")
	}
	for _, want := range []string{
		"never reached",
		"minio-web-df539cf0.dashboard-dev.adapid.link",
		"wildcard DNS",
		"ingress",
	} {
		if !strings.Contains(note, want) {
			t.Errorf("the explanation does not mention %q:\n%s", want, note)
		}
	}
	// It must actively DENY that recording failed. Staying silent on the
	// point is not enough: the misreading the note exists to prevent is
	// exactly "the recorder is broken", and an empty artifact invites it.
	if !strings.Contains(note, "not because recording failed") {
		t.Errorf("the note does not rule out the wrong diagnosis:\n%s", note)
	}
}

// A real session that simply produced no DOM — a JSON API, a file download —
// is NOT a deployment fault and must not be reported as one.
func TestARealSessionWithNoDOMIsNotReportedAsUnreachable(t *testing.T) {
	if note := unreachedSessionNote("qdrant-abc.pam.example", 12, 0); note != "" {
		t.Fatalf("a session with 12 requests was called unreachable:\n%s", note)
	}
}

// And a session that delivered replay frames is plainly reached, whatever the
// request counter says.
func TestASessionWithReplayFramesIsNeverCalledUnreachable(t *testing.T) {
	if note := unreachedSessionNote("minio-abc.pam.example", 0, 40); note != "" {
		t.Fatalf("a session with 40 replay events was called unreachable:\n%s", note)
	}
}
