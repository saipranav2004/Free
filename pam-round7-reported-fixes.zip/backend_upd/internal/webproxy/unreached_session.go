// pam/internal/webproxy/unreached_session.go
//
// Telling an operator that their browser never arrived.
//
// THE REPORT. A brokered MinIO session was opened from Windows and its
// recording came back as a 1.4 KB transcript holding nothing but the header —
// no requests, no visual replay, "No commands logged". It reads as "recording
// is broken on Windows".
//
// It is not. The recorder writes a line for every proxied request, so a
// transcript with none means NO REQUEST EVER ARRIVED: PAM opened the session,
// logged into the target server-side, printed the header, and then the
// operator's browser never reached the session's address at all. Nothing was
// recorded because nothing happened to record.
//
// That distinction is invisible from the artifact, which is the actual defect
// here. A session that was never reached and a session that recorded badly
// look identical to the person reading the evidence, and they have completely
// different causes and fixes. So PAM now says which one it was, in the
// transcript itself, where whoever opens the recording will see it.
//
// The usual cause is that the per-session address does not resolve or does
// not route: every brokered session gets its own subdomain, so the deployment
// needs a wildcard DNS record and an ingress that sends unknown subdomains to
// PAM. Without both, every brokered session behaves exactly this way — the
// console hands out a link that goes nowhere, and the evidence looks empty.
package webproxy

import "fmt"

// unreachedSessionNote returns the line to append to a session's transcript
// when the evidence shows the browser never arrived, or "" when the session
// was genuinely used.
//
// requests counts every proxied request, including the first document load.
// replayEvents counts rrweb frames the browser delivered. Zero of both is the
// only combination that means "never reached": a session with requests but no
// replay frames is a real session that simply produced no DOM activity (a
// JSON API, a download), which is a different thing and must not be reported
// as a deployment fault.
func unreachedSessionNote(proxiedHost string, requests int64, replayEvents int) string {
	if requests > 0 || replayEvents > 0 {
		return ""
	}
	return fmt.Sprintf(
		"\r\n"+
			"*** This session was never reached by a browser. ***\r\n"+
			"\r\n"+
			"PAM opened the session and authenticated to the target, but no request\r\n"+
			"ever arrived at %s, so there was\r\n"+
			"nothing to record. The recording is empty because the session did not\r\n"+
			"happen — not because recording failed.\r\n"+
			"\r\n"+
			"Almost always this is the session address not resolving or not routing.\r\n"+
			"Every brokered session gets its own subdomain, so the deployment needs:\r\n"+
			"  1. a wildcard DNS record covering *.<your PAM web-session domain>\r\n"+
			"  2. an ingress/load balancer that routes those subdomains to PAM\r\n"+
			"  3. a TLS certificate covering the wildcard, if sessions are https\r\n"+
			"\r\n"+
			"Open the session link and check what the browser reports: a DNS failure\r\n"+
			"means 1, a 404 from something that is not PAM means 2, a certificate\r\n"+
			"warning means 3.\r\n",
		proxiedHost)
}
