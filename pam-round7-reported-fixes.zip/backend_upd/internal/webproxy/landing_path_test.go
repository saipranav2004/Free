package webproxy

import (
	"net/url"
	"testing"
)

// The report: opening a Qdrant resource showed the operator
// {"title":"qdrant - vector search engine",...} — Qdrant's version banner at
// "/". Its console is at /dashboard.
func TestQdrantLandsOnItsDashboardNotItsVersionJSON(t *testing.T) {
	u, _ := url.Parse("http://13.206.221.6:6333")
	applyDefaultLandingPath(u, "qdrant")
	if u.Path != "/dashboard" {
		t.Fatalf("qdrant landed on %q, want /dashboard", u.Path)
	}
}

// An explicit path is the operator's decision and must survive.
func TestAnExplicitConsolePathIsNeverOverridden(t *testing.T) {
	u, _ := url.Parse("http://13.206.221.6:6333/dashboard#/collections")
	applyDefaultLandingPath(u, "qdrant")
	if u.Path != "/dashboard" {
		t.Fatalf("path was rewritten to %q", u.Path)
	}

	other, _ := url.Parse("http://host:6333/custom-ui")
	applyDefaultLandingPath(other, "qdrant")
	if other.Path != "/custom-ui" {
		t.Fatalf("an explicit path was replaced: %q", other.Path)
	}
}

// Everything whose UI really is at the root must be left alone — a wrong
// guess is worse than the root, which at least shows something true.
func TestApplicationsServedAtTheRootAreUntouched(t *testing.T) {
	for _, rt := range []string{"minio", "metabase", "langfuse", "clickhouse", "", "unknown-thing"} {
		u, _ := url.Parse("http://host:9001")
		applyDefaultLandingPath(u, rt)
		if u.Path != "" && u.Path != "/" {
			t.Errorf("%s was redirected to %q", rt, u.Path)
		}
	}
}

func TestLandingDefaultIgnoresCaseAndSpace(t *testing.T) {
	for _, rt := range []string{"Qdrant", " qdrant ", "QDRANT"} {
		if DefaultLandingPath(rt) != "/dashboard" {
			t.Errorf("%q did not resolve the qdrant default", rt)
		}
	}
}
