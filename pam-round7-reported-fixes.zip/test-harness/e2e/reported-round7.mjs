// The three things reported from the Windows box, driven through PAM.
//
//  2. a Qdrant session landed on {"title":"qdrant - vector search engine",...}
//     instead of a console, and the credential form demanded an account name
//     for an API key
//  4. a brokered session recorded as an empty transcript, which read as
//     "recording is broken"
//
// Each check is paired with the thing that used to happen, so a pass means the
// reported behaviour is gone rather than merely that something works.
import { chromium } from 'playwright-core'
import { readFileSync } from 'node:fs'

const token = readFileSync('/tmp/tok', 'utf8').trim()
const API = 'http://127.0.0.1:8080'
const APP = 'http://127.0.0.1:4180'

const checks = []
const check = (name, ok, detail = '') => {
  checks.push({ name, ok, detail })
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' — ' + detail : ''}`)
}
const api = async (p, opts = {}) => {
  const r = await fetch(`${API}/api/v1/${p}`, {
    ...opts,
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json', ...(opts.headers || {}) },
  })
  return { ok: r.ok, status: r.status, data: (await r.json().catch(() => ({}))).data }
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--no-sandbox', '--no-proxy-server', '--host-resolver-rules=MAP *.pam.local 127.0.0.1'],
})

// ── the reported behaviour, reproduced first ──────────────────────────────
{
  const root = await (await fetch('http://127.0.0.1:6333/', {
    headers: { 'api-key': 'pam-test-qdrant-key-7f3a91' },
  })).text()
  check('REPRODUCED: Qdrant\'s root really does serve the version JSON the operator saw',
    root.includes('"title":"qdrant - vector search engine"'), root.trim().slice(0, 60))
}

// ── 2a. the session now lands on the console ──────────────────────────────
let qdrantSession = null
{
  const open = await api('pam/resources/qdrant-live/web-session', { method: 'POST', body: '{}' })
  check('PAM opens a brokered Qdrant session', open.ok, `HTTP ${open.status}`)
  if (open.ok) {
    qdrantSession = open.data
    const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage()
    await page.goto(qdrantSession.launch_url, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(3000)

    const landed = new URL(page.url()).pathname
    check('the operator lands on /dashboard, not the JSON root', landed === '/dashboard', `landed on ${landed}`)

    const body = await page.locator('body').innerText()
    check('and sees the console rather than a line of JSON',
      !body.includes('"title":"qdrant - vector search engine"') && /Qdrant Dashboard/i.test(body),
      body.replace(/\s+/g, ' ').slice(0, 70))

    check('the API key still never reaches the browser',
      !(await page.evaluate((k) => document.documentElement.innerHTML.includes(k) || document.cookie.includes(k),
        'pam-test-qdrant-key-7f3a91')))

    await page.waitForTimeout(1500)
    await page.close()
    await api(`pam/web-sessions/${qdrantSession.web_proxy_session_id}/end`, { method: 'POST', body: '{}' }).catch(() => {})
    await api(`pam/sessions/${qdrantSession.session_id}/end`, { method: 'POST', body: '{}' }).catch(() => {})
  }
}

// ── 2b. the credential form no longer demands an account name ─────────────
{
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 } })).newPage()
  await page.addInitScript((tok) => {
    sessionStorage.setItem('pam_session', JSON.stringify({
      accessToken: tok, refreshToken: 'r',
      expiresAt: new Date(Date.now() + 36e5).toISOString(), user: null,
    }))
  }, token)
  await page.route('**/api/v1/auth/me', async (route) => {
    const resp = await route.fetch()
    const body = await resp.json().catch(() => ({}))
    if (body?.data) body.data.mfa_verified = true
    await route.fulfill({ response: resp, body: JSON.stringify(body) })
  })
  // Reached the way an operator does — the detail page is opened from the
  // list, not by typing a path (the console redirects an unknown one).
  await page.goto(`${APP}/resources`, { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(5000)
  await page.getByText('qdrant-live', { exact: true }).first().click({ timeout: 10000 })
  await page.waitForTimeout(4000)
  await page.getByRole('tab', { name: /^Credentials$/i }).first().click({ timeout: 8000 })
    .catch(async () => {
      await page.locator('button, a').filter({ hasText: /^Credentials$/ }).first().click({ timeout: 8000 }).catch(() => {})
    })
  await page.waitForTimeout(3000)
  // A resource that already holds a credential shows the store form behind
  // "Replace credential" — which is the form the report is about.
  await page.getByRole('button', { name: /Replace credential/i }).first().click({ timeout: 8000 }).catch(() => {})
  await page.waitForTimeout(2000)

  const sel = page.locator('select').filter({ hasText: /API Key|Password/i }).first()
  if (await sel.count()) {
    await sel.selectOption({ label: /API Key/i }).catch(async () => {
      await sel.selectOption('api_key').catch(() => {})
    })
    await page.waitForTimeout(1200)
  }
  const text = await page.locator('body').innerText()
  const hasAccountField = /Account name/i.test(text)
  const marksItRequired = /Account name\s*\(required\)/i.test(text)
  check('the credential form no longer marks Account name required for an API key',
    hasAccountField && !marksItRequired,
    marksItRequired ? 'still says (required)' : 'shown as optional')
  await page.screenshot({ path: '/tmp/round7-credential-form.png' })
  await page.close()
}

// ── 4. an unreached session explains itself ───────────────────────────────
{
  const open = await api('pam/resources/qdrant-live/web-session', { method: 'POST', body: '{}' })
  if (open.ok) {
    const s = open.data
    // Deliberately never open the launch URL: this is the reported situation,
    // a session brokered but never reached by any browser.
    await api(`pam/web-sessions/${s.web_proxy_session_id}/end`, { method: 'POST', body: '{}' }).catch(() => {})
    await api(`pam/sessions/${s.session_id}/end`, { method: 'POST', body: '{}' }).catch(() => {})

    let rec = null
    for (let i = 0; i < 40 && !rec; i++) {
      const r = await api(`pam/admin/recordings?session_id=${s.session_id}&limit=5`)
      rec = (r.data?.recordings || []).find((x) => x.status === 'COMPLETED') || null
      if (!rec) await new Promise((res) => setTimeout(res, 2000))
    }
    check('an unreached session still produces a recording', !!rec,
      rec ? `${rec.format} ${rec.size_bytes}B` : 'none')

    if (rec) {
      const castRes = await fetch(`${API}/api/v1/pam/admin/recordings/${rec.id}/cast`, {
        headers: { Authorization: 'Bearer ' + token },
      })
      const cast = await castRes.text()
      check('and the transcript says the browser never arrived',
        /never reached by a browser/i.test(cast))
      check('naming the likely cause instead of blaming the recorder',
        /wildcard DNS/i.test(cast) && /ingress/i.test(cast) && /not because recording failed/i.test(cast))
    }
  }
}

await browser.close()
const passed = checks.filter((c) => c.ok).length
console.log(`\n${passed}/${checks.length} checks passed`)
for (const c of checks.filter((x) => !x.ok)) console.log(`  FAILED: ${c.name} — ${c.detail}`)
process.exit(passed === checks.length ? 0 : 1)
