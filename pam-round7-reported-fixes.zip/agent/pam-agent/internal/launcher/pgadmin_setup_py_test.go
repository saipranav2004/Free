package launcher

import (
	"strings"
	"testing"
)

// fakeFS answers "does this path exist" from a fixed set, so a Windows or
// macOS pgAdmin layout can be asserted from a Linux test runner.
func fakeFS(paths ...string) statFunc {
	set := map[string]bool{}
	for _, p := range paths {
		set[p] = true
	}
	return func(p string) bool { return set[p] }
}

// The regression this whole file exists for: the agent used to run
// `pgAdmin4.exe --load-servers <file>`, which pgAdmin ignores, so nothing was
// ever imported and the operator was asked for a password PAM was holding.
func TestPgAdminImportRunsSetupPyAndNotTheExecutable(t *testing.T) {
	const exe = `C:\Program Files\pgAdmin 4\runtime\pgAdmin4.exe`
	fs := fakeFS(
		`C:\Program Files\pgAdmin 4\web\setup.py`,
		`C:\Program Files\pgAdmin 4\python\python.exe`,
	)

	setup, ok := ResolvePgAdminSetup("windows", exe, fs)
	if !ok {
		t.Fatal("did not resolve setup.py for a standard Windows install")
	}
	if strings.HasSuffix(setup.Python, "pgAdmin4.exe") {
		t.Fatal("the pgAdmin executable is not something that can import a server")
	}
	if !strings.HasSuffix(setup.SetupPy, `web\setup.py`) {
		t.Errorf("setup.py = %q", setup.SetupPy)
	}
	if !strings.HasSuffix(setup.Python, `python\python.exe`) {
		t.Errorf("python = %q", setup.Python)
	}

	args := PgAdminLoadServersArgs(setup, `C:\Temp\servers.json`, `C:\Users\P\AppData\Roaming\pgAdmin\pgadmin4.db`)
	joined := strings.Join(args, " ")
	// The subcommand form, not the flag form that silently did nothing.
	if !strings.Contains(joined, "load-servers") || strings.Contains(joined, "--load-servers") {
		t.Errorf("expected the load-servers SUBCOMMAND, got: %s", joined)
	}
	for _, want := range []string{"--sqlite-path", "--user", "--replace"} {
		if !strings.Contains(joined, want) {
			t.Errorf("missing %s in: %s", want, joined)
		}
	}
}

// Every packaged layout an operator is likely to have.
func TestPgAdminSetupLayoutsPerPlatform(t *testing.T) {
	cases := []struct {
		name       string
		goos       string
		exe        string
		files      []string
		wantPython string
	}{
		{
			name: "windows standalone",
			goos: "windows",
			exe:  `C:\Program Files\pgAdmin 4\runtime\pgAdmin4.exe`,
			files: []string{
				`C:\Program Files\pgAdmin 4\web\setup.py`,
				`C:\Program Files\pgAdmin 4\python\python.exe`,
			},
			wantPython: `C:\Program Files\pgAdmin 4\python\python.exe`,
		},
		{
			name: "windows versioned directory",
			goos: "windows",
			exe:  `C:\Program Files\pgAdmin 4\v8\runtime\pgAdmin4.exe`,
			files: []string{
				`C:\Program Files\pgAdmin 4\v8\web\setup.py`,
				`C:\Program Files\pgAdmin 4\v8\python\python.exe`,
			},
			wantPython: `C:\Program Files\pgAdmin 4\v8\python\python.exe`,
		},
		{
			// The copy the PostgreSQL installer lays down — the one most
			// likely to be present on a machine that also has psql working,
			// which is exactly the reported configuration.
			name: "bundled with the PostgreSQL installer",
			goos: "windows",
			exe:  `C:\Program Files\PostgreSQL\18\pgAdmin 4\runtime\pgAdmin4.exe`,
			files: []string{
				`C:\Program Files\PostgreSQL\18\pgAdmin 4\web\setup.py`,
				`C:\Program Files\PostgreSQL\18\pgAdmin 4\python\python.exe`,
			},
			wantPython: `C:\Program Files\PostgreSQL\18\pgAdmin 4\python\python.exe`,
		},
		{
			name: "macOS app bundle",
			goos: "darwin",
			exe:  "/Applications/pgAdmin 4.app/Contents/MacOS/pgAdmin4",
			files: []string{
				"/Applications/pgAdmin 4.app/Contents/Resources/web/setup.py",
				"/Applications/pgAdmin 4.app/Contents/Frameworks/Python.framework/Versions/3.12/bin/python3",
			},
			wantPython: "/Applications/pgAdmin 4.app/Contents/Frameworks/Python.framework/Versions/3.12/bin/python3",
		},
		{
			name: "linux package",
			goos: "linux",
			exe:  "/usr/pgadmin4/bin/pgadmin4",
			files: []string{
				"/usr/pgadmin4/web/setup.py",
				"/usr/pgadmin4/venv/bin/python3",
			},
			wantPython: "/usr/pgadmin4/venv/bin/python3",
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			setup, ok := ResolvePgAdminSetup(tc.goos, tc.exe, fakeFS(tc.files...))
			if !ok {
				t.Fatalf("no setup.py resolved for %s", tc.exe)
			}
			if setup.Python != tc.wantPython {
				t.Errorf("python = %q, want %q", setup.Python, tc.wantPython)
			}
			if setup.Workdir == "" || strings.HasSuffix(setup.Workdir, "setup.py") {
				t.Errorf("workdir must be setup.py's DIRECTORY (it imports config from there), got %q", setup.Workdir)
			}
		})
	}
}

// A machine can hold more than one pgAdmin. Importing into the wrong one's
// config database is, from the operator's side, the same as importing nothing.
func TestPgAdminSetupStaysWithinTheInstallationBeingLaunched(t *testing.T) {
	fs := fakeFS(
		`C:\Program Files\pgAdmin 4\web\setup.py`,
		`C:\Program Files\pgAdmin 4\python\python.exe`,
		`C:\Program Files\PostgreSQL\18\pgAdmin 4\web\setup.py`,
		`C:\Program Files\PostgreSQL\18\pgAdmin 4\python\python.exe`,
	)
	setup, ok := ResolvePgAdminSetup("windows", `C:\Program Files\PostgreSQL\18\pgAdmin 4\runtime\pgAdmin4.exe`, fs)
	if !ok {
		t.Fatal("not resolved")
	}
	if !strings.Contains(setup.SetupPy, "PostgreSQL") {
		t.Fatalf("resolved a different installation's setup.py: %s", setup.SetupPy)
	}
}

// An install without its bundled Python must report that, not silently do
// nothing — the failure mode that hid this bug for a whole round.
func TestPgAdminSetupUnresolvedWhenPythonIsAbsent(t *testing.T) {
	fs := fakeFS(`C:\Program Files\pgAdmin 4\web\setup.py`)
	if _, ok := ResolvePgAdminSetup("windows", `C:\Program Files\pgAdmin 4\runtime\pgAdmin4.exe`, fs); ok {
		t.Fatal("claimed to resolve an import path with no interpreter")
	}
}

func TestPgAdminConfigDBPerPlatform(t *testing.T) {
	win := PgAdminConfigDB("windows", func(k string) string {
		if k == "APPDATA" {
			return `C:\Users\Pranav\AppData\Roaming`
		}
		return ""
	})
	if win != `C:\Users\Pranav\AppData\Roaming\pgAdmin\pgadmin4.db` {
		t.Errorf("windows config db = %q", win)
	}

	nix := PgAdminConfigDB("linux", func(k string) string {
		if k == "HOME" {
			return "/home/op"
		}
		return ""
	})
	if nix != "/home/op/.pgadmin/pgadmin4.db" {
		t.Errorf("linux config db = %q", nix)
	}

	// An explicit override wins, for a deployment that relocates the data dir.
	override := PgAdminConfigDB("windows", func(k string) string {
		if k == "PGADMIN_SQLITE_PATH" {
			return `D:\pgadmin\pgadmin4.db`
		}
		return `C:\Users\Pranav\AppData\Roaming`
	})
	if override != `D:\pgadmin\pgadmin4.db` {
		t.Errorf("override ignored: %q", override)
	}
}

// Paths must be assembled with the TARGET platform's separator, not the
// build platform's — the same trap the ffmpeg lookup hit earlier.
func TestPathsUseTheTargetPlatformSeparator(t *testing.T) {
	if got := joinFor("windows", `C:\a`, "b", "c.txt"); got != `C:\a\b\c.txt` {
		t.Errorf("windows join = %q", got)
	}
	if got := joinFor("linux", "/a", "b", "c.txt"); got != "/a/b/c.txt" {
		t.Errorf("posix join = %q", got)
	}
	if got := dirFor("windows", `C:\a\b\c.txt`); got != `C:\a\b` {
		t.Errorf("windows dir = %q", got)
	}
	if got := dirFor("linux", "/a/b/c.txt"); got != "/a/b" {
		t.Errorf("posix dir = %q", got)
	}
}
