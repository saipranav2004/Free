// pam-agent/internal/launcher/pgadmin_setup_py.go
//
// Finding the thing that can actually import a server into pgAdmin 4.
//
// THE BUG THIS FIXES. The preseed used to run:
//
//	pgAdmin4.exe --load-servers <file>
//
// and `--load-servers` is not a flag pgAdmin4.exe has. It is a SUBCOMMAND of
// pgAdmin's setup.py:
//
//	<python> <setup.py> load-servers <file> --user <email> --sqlite-path <db>
//
// The desktop runtime ignores the unknown argument and just opens its window,
// so the import silently never happened. The operator then saw whatever
// servers pgAdmin already had — typically the one the PostgreSQL installer
// registered — and was asked for its password, which looks exactly like PAM
// failing to pass a credential it never got the chance to pass.
//
// It passed review here because the live test drove `python setup.py
// load-servers` directly, which is the correct interface, while the agent
// shipped the exe flag. The test proved the mechanism and not the caller.
// LaunchArgsFor now returns what the agent will actually run, and the live
// test asserts on that, so the two cannot diverge again.
//
// --sqlite-path is passed explicitly because pgAdmin's own documentation
// recommends it for desktop mode: without it setup.py resolves the config
// database from its own configuration, which is not necessarily the one the
// desktop runtime opened.
//
// LAYOUTS. Every packaged pgAdmin keeps its Python and its web/ directory in a
// fixed place relative to the launcher, so the launcher path the agent already
// discovered is enough to find them:
//
//	Windows  ...\pgAdmin 4\runtime\pgAdmin4.exe
//	         ...\pgAdmin 4\python\python.exe        ...\pgAdmin 4\web\setup.py
//	         (also ...\pgAdmin 4\v8\runtime\..., and the copy the PostgreSQL
//	         installer puts under ...\PostgreSQL\<ver>\pgAdmin 4\)
//	macOS    /Applications/pgAdmin 4.app/Contents/MacOS/pgAdmin4
//	         .../Contents/Frameworks/Python.framework/Versions/*/bin/python3
//	         .../Contents/Resources/web/setup.py
//	Linux    /usr/pgadmin4/bin/pgadmin4
//	         /usr/pgadmin4/venv/bin/python3          /usr/pgadmin4/web/setup.py
//	pip      <site-packages>/pgadmin4/setup.py with the venv's own python
//
// goos and the filesystem probe are parameters for the same reason they are
// throughout discovery: these paths belong to the machine the agent RUNS on,
// and Go's path helpers are fixed at build time, so a Linux builder must not
// decide how a Windows path is assembled.
package launcher

import (
	"os"
	"path"
	"strings"
)

// PgAdminSetup is a resolved way to run pgAdmin's setup.py.
type PgAdminSetup struct {
	Python  string // interpreter that can import pgAdmin's modules
	SetupPy string // the setup.py belonging to THAT installation
	Workdir string // setup.py's own directory; it imports config from there
}

// pgAdminDesktopUser is the account pgAdmin creates for itself in desktop
// mode. A server imported against any other user exists in the config
// database but is invisible in the window the operator is looking at.
const pgAdminDesktopUser = "pgadmin4@pgadmin.org"

// statFunc reports whether a path exists, injected so the layout rules can be
// tested for every platform from one machine.
type statFunc func(string) bool

func realStat(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

// joinFor assembles a path with the separator of the TARGET platform rather
// than the build platform.
func joinFor(goos string, parts ...string) string {
	sep := "/"
	if goos == "windows" {
		sep = `\`
	}
	cleaned := make([]string, 0, len(parts))
	for _, p := range parts {
		if p != "" {
			cleaned = append(cleaned, strings.TrimRight(p, `/\`))
		}
	}
	return strings.Join(cleaned, sep)
}

// dirFor returns the parent directory of a target-platform path.
func dirFor(goos, p string) string {
	seps := "/"
	if goos == "windows" {
		seps = `/\`
	}
	i := strings.LastIndexAny(strings.TrimRight(p, seps), seps)
	if i < 0 {
		return ""
	}
	return p[:i]
}

// ResolvePgAdminSetup finds the python + setup.py pair belonging to the
// pgAdmin installation that execPath launches.
//
// Deliberately anchored on the launcher the agent already resolved rather than
// searching the machine: a box can easily have several pgAdmins (a standalone
// install plus the one bundled with PostgreSQL), and importing a server into a
// different one's config database is indistinguishable, from the operator's
// side, from importing nothing at all.
func ResolvePgAdminSetup(goos, execPath string, stat statFunc) (PgAdminSetup, bool) {
	return resolvePgAdminSetupWithEnv(goos, execPath, stat, os.Getenv)
}

// resolvePgAdminSetupWithEnv adds the escape hatch: an installation whose
// layout is not one of the packaged ones (a pip install, a relocated
// deployment, a distribution that rearranges things) can be named directly.
// The same shape as PAM_AGENT_FFMPEG, and for the same reason — a layout this
// code has never seen should be configurable rather than unsupported.
func resolvePgAdminSetupWithEnv(goos, execPath string, stat statFunc, env func(string) string) (PgAdminSetup, bool) {
	if stat == nil {
		stat = realStat
	}
	if env != nil {
		py, sp := env("PAM_PGADMIN_PYTHON"), env("PAM_PGADMIN_SETUP_PY")
		if py != "" && sp != "" && stat(py) && stat(sp) {
			return PgAdminSetup{Python: py, SetupPy: sp, Workdir: dirFor(goos, sp)}, true
		}
	}
	if execPath == "" {
		return PgAdminSetup{}, false
	}

	// Candidate roots to look under, nearest first: the launcher's own
	// directory, then its parent (Windows and Linux both keep the launcher in
	// a bin/ or runtime/ subdirectory), then the grandparent for macOS's
	// Contents/MacOS nesting.
	launcherDir := dirFor(goos, execPath)
	roots := []string{launcherDir, dirFor(goos, launcherDir)}
	if goos == "darwin" {
		roots = append(roots, dirFor(goos, dirFor(goos, launcherDir)))
	}

	pythonNames := []string{"python3", "python"}
	pythonDirs := []string{
		joinFor(goos, "python", "bin"), // macOS/Linux bundled interpreter
		"python",                       // Windows bundled interpreter
		joinFor(goos, "venv", "bin"),   // Linux package venv
		"bin",                          // pip install in a venv
		"",                             // the root itself
	}
	if goos == "windows" {
		pythonNames = []string{"python.exe"}
	}
	if goos == "darwin" {
		// The .app keeps its interpreter under a versioned framework path;
		// the version is not knowable in advance, so the common ones are
		// probed rather than globbed (no filesystem walk on a launch path).
		for _, v := range []string{"3.13", "3.12", "3.11", "3.10", "3.9", "Current"} {
			pythonDirs = append(pythonDirs,
				joinFor(goos, "Frameworks", "Python.framework", "Versions", v, "bin"))
		}
	}

	setupDirs := []string{"web", "", joinFor(goos, "Resources", "web")}

	for _, root := range roots {
		if root == "" {
			continue
		}
		var setupPy string
		for _, sd := range setupDirs {
			candidate := joinFor(goos, root, sd, "setup.py")
			if stat(candidate) {
				setupPy = candidate
				break
			}
		}
		if setupPy == "" {
			continue
		}
		for _, pd := range pythonDirs {
			for _, pn := range pythonNames {
				candidate := joinFor(goos, root, pd, pn)
				if stat(candidate) {
					return PgAdminSetup{
						Python:  candidate,
						SetupPy: setupPy,
						Workdir: dirFor(goos, setupPy),
					}, true
				}
			}
		}
	}
	return PgAdminSetup{}, false
}

// PgAdminConfigDB is where the DESKTOP runtime keeps its configuration
// database. setup.py is pointed at this explicitly so the import lands in the
// database the operator's window is actually reading.
//
// env is injected (rather than calling os.Getenv) so every platform's rule can
// be exercised from one machine.
func PgAdminConfigDB(goos string, env func(string) string) string {
	if override := env("PGADMIN_SQLITE_PATH"); override != "" {
		return override
	}
	switch goos {
	case "windows":
		if appData := env("APPDATA"); appData != "" {
			return joinFor(goos, appData, "pgAdmin", "pgadmin4.db")
		}
	default:
		if home := env("HOME"); home != "" {
			return joinFor(goos, home, ".pgadmin", "pgadmin4.db")
		}
	}
	return ""
}

// PgAdminLoadServersArgs builds the argument list for the import.
//
// --replace is deliberate: a relaunch of the same resource should update its
// entry, not add a second one beside it. Without it an operator who opens the
// same server three times finds three identical entries and no way to tell
// which carries a current credential.
func PgAdminLoadServersArgs(setup PgAdminSetup, serversFile, sqlitePath string) []string {
	args := []string{setup.SetupPy, "load-servers", serversFile, "--user", pgAdminDesktopUser, "--replace"}
	if sqlitePath != "" {
		args = append(args, "--sqlite-path", sqlitePath)
	}
	return args
}

// pgAdminLegacyLoadServersArgs is the pre-6.x spelling, where load-servers was
// a flag rather than a subcommand. Tried only after the modern form fails, so
// an old install still gets its server without the new one paying for it.
func pgAdminLegacyLoadServersArgs(setup PgAdminSetup, serversFile, sqlitePath string) []string {
	args := []string{setup.SetupPy, "--load-servers", serversFile, "--user", pgAdminDesktopUser, "--replace"}
	if sqlitePath != "" {
		args = append(args, "--sqlite-path", sqlitePath)
	}
	return args
}

// unusedPathHelper keeps the stdlib path import meaningful on every platform
// build; joinFor deliberately does not use path.Join because that is fixed to
// forward slashes at build time.
var _ = path.Clean
