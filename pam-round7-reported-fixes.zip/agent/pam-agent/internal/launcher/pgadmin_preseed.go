// pam-agent/internal/launcher/pgadmin_preseed.go
//
// Pre-registers the resource as a server in pgAdmin4's own tree via its
// documented --load-servers mechanism.
//
// The password is never written into this file — pgAdmin does not import
// passwords at all. It is supplied at connect time through
// PasswordExecCommand, which calls back into this agent; see
// pgadmin_passexec.go for how that works and what was verified against a
// real pgAdmin. When that route is unavailable (an agent path that cannot be
// expressed to the shell, or a password pgAdmin's stdout.strip() would
// alter), the launch falls back to putting the password on the clipboard and
// the operator types it once.
package launcher

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"runtime"
	"strings"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

// pgAdminServersFile mirrors the shape pgAdmin4's own `--load-servers`
// switch expects (a top-level "Servers" object keyed by an arbitrary
// integer ID). Documented at
// https://www.pgadmin.org/docs/pgadmin4/latest/import_export_servers.html
// — this is pgAdmin4's own supported mechanism, not something reverse
// engineered.
type pgAdminServersFile struct {
	Servers map[string]pgAdminServerEntry `json:"Servers"`
}

type pgAdminServerEntry struct {
	Name          string `json:"Name"`
	Group         string `json:"Group"`
	Host          string `json:"Host"`
	Port          int    `json:"Port"`
	MaintenanceDB string `json:"MaintenanceDB"`
	Username      string `json:"Username"`
	SSLMode       string `json:"SSLMode"`

	// The password is never a field here — pgAdmin does not import one, by
	// design. PasswordExecCommand is how a credential reaches it instead:
	// pgAdmin runs the command at connect time and uses its stdout as the
	// password, so the server entry stays secret-free and pgAdmin's own
	// config database records server.password = NULL. See
	// pgadmin_passexec.go. Omitted entirely when unset so the import file
	// keeps its previous shape for the clipboard fallback.
	PasswordExecCommand    string `json:"PasswordExecCommand,omitempty"`
	PasswordExecExpiration int    `json:"PasswordExecExpiration,omitempty"`
}

// writePgAdminServersFile writes a pgAdmin4 servers-import JSON (0600, temp
// dir) containing host/port/database/username for the resolved resource —
// and, when passexecCommand is non-empty, the command pgAdmin should run to
// obtain the password. The password itself is never written here.
func writePgAdminServersFile(tempDir string, resolved *apiclient.ResolvedLaunch, dbName, passexecCommand string) (string, error) {
	if dbName == "" {
		dbName = "postgres"
	}

	entry := pgAdminServerEntry{
		Name:          fmt.Sprintf("PAM - %s", resolved.Host),
		Group:         "PAM",
		Host:          resolved.Host,
		Port:          resolved.Port,
		MaintenanceDB: dbName,
		Username:      resolved.AccountName,
		SSLMode:       "prefer",
	}
	if passexecCommand != "" {
		entry.PasswordExecCommand = passexecCommand
		entry.PasswordExecExpiration = pgAdminPassexecExpiration
	}

	doc := pgAdminServersFile{Servers: map[string]pgAdminServerEntry{"1": entry}}

	raw, err := json.MarshalIndent(doc, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to encode pgAdmin4 servers file: %w", err)
	}

	f, err := os.CreateTemp(tempDir, "pam-agent-*.pgadmin-servers.json")
	if err != nil {
		return "", fmt.Errorf("failed to create temp pgAdmin4 servers file: %w", err)
	}
	defer f.Close()
	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp pgAdmin4 servers file: %w", err)
	}
	if _, err := f.Write(raw); err != nil {
		return "", fmt.Errorf("failed to write temp pgAdmin4 servers file: %w", err)
	}
	return f.Name(), nil
}

// RunPgAdminPreseed imports the server definition into pgAdmin's own config
// database, by running pgAdmin's setup.py the way pgAdmin documents.
//
// It used to run `<pgAdmin4 executable> --load-servers <file>`, which does
// nothing at all: --load-servers belongs to setup.py, not to the desktop
// runtime, which ignores the unknown argument and opens its window. See
// pgadmin_setup_py.go for the full account.
//
// Still deliberately non-fatal. A failure here means the operator adds the
// connection by hand rather than the GUI refusing to open — but unlike before,
// the error says which step failed, because "pgAdmin opened with nothing in
// it" was previously indistinguishable from PAM never having tried.
func RunPgAdminPreseed(execPath, appBundle, serversFilePath string) error {
	return runPgAdminPreseedOn(runtime.GOOS, execPath, appBundle, serversFilePath,
		os.Getenv, nil, func(name string, args ...string) *exec.Cmd { return exec.Command(name, args...) })
}

// runPgAdminPreseedOn is the testable body: goos, the environment and the
// command constructor are all injected.
func runPgAdminPreseedOn(
	goos, execPath, appBundle, serversFilePath string,
	env func(string) string,
	stat statFunc,
	command func(string, ...string) *exec.Cmd,
) error {
	launcher := execPath
	if launcher == "" && appBundle != "" {
		// macOS: the bundle path is the anchor, and the launcher inside it is
		// where the layout rules below start from.
		launcher = joinFor(goos, appBundle, "Contents", "MacOS", "pgAdmin4")
	}
	if launcher == "" {
		return fmt.Errorf("no pgAdmin 4 executable was resolved, so its server list could not be preseeded")
	}

	setup, ok := resolvePgAdminSetupWithEnv(goos, launcher, stat, env)
	if !ok {
		return fmt.Errorf(
			"found pgAdmin 4 at %s but not the setup.py beside it, so the server could not be imported "+
				"(a pgAdmin installed without its bundled Python cannot be preseeded)", launcher)
	}

	sqlitePath := PgAdminConfigDB(goos, env)
	run := func(args []string) error {
		c := command(setup.Python, args...)
		c.Dir = setup.Workdir // setup.py imports config from its own directory
		out, err := c.CombinedOutput()
		if err != nil {
			return fmt.Errorf("%w: %s", err, strings.TrimSpace(string(out)))
		}
		return nil
	}

	err := run(PgAdminLoadServersArgs(setup, serversFilePath, sqlitePath))
	if err == nil {
		return nil
	}
	// Older pgAdmin spelled it as a flag rather than a subcommand.
	if legacyErr := run(pgAdminLegacyLoadServersArgs(setup, serversFilePath, sqlitePath)); legacyErr == nil {
		return nil
	}
	return fmt.Errorf("pgAdmin 4 refused the server import: %w", err)
}
