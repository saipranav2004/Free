package launcher

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/yourorg/pam-agent/internal/apiclient"
	"github.com/yourorg/pam-agent/internal/discovery"
)

// Proves the credential handoff end to end using the AGENT'S OWN OUTPUT: the
// server definition this package writes, loaded into a real pgAdmin 4, and
// the password fetched back by running the real agent binary the way pgAdmin
// runs it — through a shell, exactly as subprocess.run(shell=True) would.
//
// The browser half (no password dialog, pg_stat_activity shows an
// authenticated backend) is e2e/pgadmin-passexec.mjs. This half is the part
// that belongs with the code: that what buildCommand emits is something
// pgAdmin can actually execute, and that it yields the right secret.
//
// Skips unless PAM_LIVE_PGADMIN names a real pgAdmin install, so it is a
// no-op everywhere else.
func TestLivePgAdminPassexecRoundTripThroughAShell(t *testing.T) {
	pgadminDir := os.Getenv("PAM_LIVE_PGADMIN")
	if pgadminDir == "" {
		t.Skip("PAM_LIVE_PGADMIN not set; needs a real pgAdmin 4 install")
	}
	agent := os.Getenv("PAM_LIVE_AGENT_BIN")
	if agent == "" {
		t.Skip("PAM_LIVE_AGENT_BIN not set; needs a built pam-agent binary")
	}

	const password = "Pg4Exec!Secret2026"
	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "127.0.0.1", Port: 5433,
		DatabaseName: "postgres", AccountName: "pam_pgadmin_test", Password: password,
	}
	candidates := []Candidate{
		{ID: "pgadmin4", Kind: "gui", Command: "go", CredentialInjection: "pgadmin_preseed", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}

	// A directory that outlives the test, so the browser half can load the
	// same file the agent wrote rather than a reconstruction of it.
	outDir := os.Getenv("PAM_LIVE_PGADMIN_OUT")
	if outDir == "" {
		outDir = t.TempDir()
	}
	cmd, _, err := SelectAndBuildCommand(resolved, candidates, outDir, testLogger())
	if err != nil {
		t.Fatalf("building the launch failed: %v", err)
	}

	raw, err := os.ReadFile(cmd.PreseedLoadServersPath)
	if err != nil {
		t.Fatal(err)
	}
	var doc pgAdminServersFile
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatalf("the agent wrote a servers file pgAdmin cannot parse: %v", err)
	}
	entry := doc.Servers["1"]
	if entry.PasswordExecCommand == "" {
		t.Fatal("no PasswordExecCommand was emitted")
	}
	if strings.Contains(string(raw), password) {
		t.Fatal("the password is in the servers file")
	}

	// pgAdmin substitutes these before running the command; anything left
	// unsubstituted would reach the shell literally.
	shellCmd := entry.PasswordExecCommand
	for placeholder, value := range map[string]string{
		"%HOSTNAME%": resolved.Host, "%PORT%": "5433", "%USERNAME%": resolved.AccountName,
	} {
		shellCmd = strings.ReplaceAll(shellCmd, placeholder, value)
	}
	// The agent path in the emitted command is this test binary's notion of
	// os.Executable(); point it at the real agent instead.
	shellCmd = strings.Replace(shellCmd, shellQuoteFor("linux", mustExecutable(t)), shellQuoteFor("linux", agent), 1)

	out, err := exec.Command("/bin/sh", "-c", shellCmd).Output()
	if err != nil {
		t.Fatalf("pgAdmin would not have been able to run the command: %v\n  %s", err, shellCmd)
	}
	// pgAdmin takes stdout.strip() — assert on that, not on the raw bytes.
	if got := strings.TrimSpace(string(out)); got != password {
		t.Fatalf("the command returned %q, want %q", got, password)
	}

	// And nothing on stderr, because pgAdmin runs it with check=True and
	// logs whatever it finds there.
	var stderr strings.Builder
	c := exec.Command("/bin/sh", "-c", shellCmd)
	c.Stderr = &stderr
	_ = c.Run()
	if stderr.Len() != 0 {
		t.Errorf("the credential command wrote to stderr: %s", stderr.String())
	}

	if _, statErr := os.Stat(filepath.Join(pgadminDir, "setup.py")); statErr != nil {
		t.Logf("note: %s does not look like a pgAdmin source dir", pgadminDir)
	}
}

func mustExecutable(t *testing.T) string {
	t.Helper()
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	return exe
}

// Emits the RedisInsight pre-setup file from the AGENT'S OWN launch path into
// a directory the browser half can then start RedisInsight against, so what is
// tested is the file this code writes rather than a hand-made copy of it.
// See e2e/redisinsight-presetup.mjs for the half that drives the real app.
func TestLiveRedisInsightPreSetupFileFromTheRealLaunchPath(t *testing.T) {
	outDir := os.Getenv("PAM_LIVE_REDISINSIGHT_OUT")
	if outDir == "" {
		t.Skip("PAM_LIVE_REDISINSIGHT_OUT not set")
	}

	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "redis", Host: "127.0.0.1", Port: 6380,
		Password: "Redis!PamTest2026",
	}
	candidates := []Candidate{
		{ID: "redisinsight", Kind: "gui", Command: "go", CredentialInjection: "redisinsight_presetup", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}
	cmd, _, err := SelectAndBuildCommand(resolved, candidates, outDir, testLogger())
	if err != nil {
		t.Fatalf("building the launch failed: %v", err)
	}

	var path string
	for _, e := range cmd.Env {
		if strings.HasPrefix(e, RedisInsightPreSetupEnv+"=") {
			path = strings.TrimPrefix(e, RedisInsightPreSetupEnv+"=")
		}
	}
	if path == "" {
		t.Fatalf("%s was not set", RedisInsightPreSetupEnv)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var entries []redisInsightDatabase
	if err := json.Unmarshal(raw, &entries); err != nil {
		t.Fatalf("not parseable as RedisInsight expects: %v", err)
	}
	t.Logf("agent emitted %s with %d entry: %s", path, len(entries), entries[0].Name)
}

// The whole preseed, end to end, through the function the agent actually
// calls — not a hand-written command that happens to use the same mechanism.
//
// That distinction is the bug this test exists to prevent: the previous live
// test drove `python setup.py load-servers` directly and passed, while the
// shipped code ran `pgAdmin4.exe --load-servers`, which pgAdmin ignores. The
// import silently never happened and the operator was asked for a password.
func TestLivePgAdminPreseedImportsThroughTheRealCodePath(t *testing.T) {
	python := os.Getenv("PAM_PGADMIN_PYTHON")
	setupPy := os.Getenv("PAM_PGADMIN_SETUP_PY")
	sqlitePath := os.Getenv("PGADMIN_SQLITE_PATH")
	if python == "" || setupPy == "" || sqlitePath == "" {
		t.Skip("needs PAM_PGADMIN_PYTHON, PAM_PGADMIN_SETUP_PY and PGADMIN_SQLITE_PATH against a real pgAdmin")
	}

	resolved := &apiclient.ResolvedLaunch{
		ResourceType: "postgresql", Host: "127.0.0.1", Port: 5433,
		DatabaseName: "postgres", AccountName: "pam_pgadmin_test", Password: "Pg4Exec!Secret2026",
	}
	candidates := []Candidate{
		{ID: "pgadmin4", Kind: "gui", Command: "go", CredentialInjection: "pgadmin_preseed", Discovery: discovery.Spec{BinaryNames: []string{"go"}}},
	}
	outDir := os.Getenv("PAM_LIVE_PGADMIN_OUT")
	if outDir == "" {
		outDir = t.TempDir()
	}
	cmd, _, err := SelectAndBuildCommand(resolved, candidates, outDir, testLogger())
	if err != nil {
		t.Fatalf("building the launch failed: %v", err)
	}
	if cmd.PreseedLoadServersPath == "" {
		t.Fatal("no servers file was produced")
	}

	// RunPgAdminPreseed as the agent calls it. The environment overrides point
	// the resolver at this installation.
	if err := RunPgAdminPreseed("/nonexistent/pgAdmin4", "", cmd.PreseedLoadServersPath); err != nil {
		t.Fatalf("the real preseed path failed: %v", err)
	}

	// pgAdmin's own config database is the evidence: the server must be there,
	// carrying the callback command, with no password stored.
	out, err := exec.Command("python3", "-c",
		"import sqlite3,sys;c=sqlite3.connect(sys.argv[1]);"+
			"r=c.execute('select name,host,port,username,password,passexec_cmd from server').fetchall();"+
			"print(r)", sqlitePath).CombinedOutput()
	if err != nil {
		t.Fatalf("could not read pgAdmin's config database: %v\n%s", err, out)
	}
	row := string(out)
	t.Logf("pgAdmin config database now holds: %s", strings.TrimSpace(row))
	if !strings.Contains(row, "pam_pgadmin_test") {
		t.Fatalf("the server was not imported: %s", row)
	}
	if !strings.Contains(row, "pgadmin-credential") {
		t.Fatalf("the imported server carries no credential callback: %s", row)
	}
	if strings.Contains(row, resolved.Password) {
		t.Fatalf("the password was stored in pgAdmin's database: %s", row)
	}
}
