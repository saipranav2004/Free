import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The Flask IAM backend listens on :5000. During development we proxy the
// API + JWKS paths so cookies/CSP/origin are never an issue. For production
// builds set VITE_API_BASE_URL to your gateway and remove the proxy.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:5000', changeOrigin: true },
      '/well-known': { target: 'http://localhost:5000', changeOrigin: true },
      '/idp': { target: 'https://idp.cf.adapid.link', changeOrigin: true },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
  }});
