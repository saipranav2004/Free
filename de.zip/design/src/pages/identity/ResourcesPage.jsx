/**
 * ResourcesPage — protected-resource inventory (identity domain).
 *
 * Enterprise pattern: search-first, action-second. Resources are referenced by
 * ARN inside policy documents, so ARNs are monospace and copy-friendly, and
 * deactivation is a reversible soft-disable behind a confirmation rather than
 * a delete.
 *
 * NOTE (unchanged from before this redesign): the backend does not expose a
 * list endpoint for this collection yet, so the table renders from an empty
 * resolved promise. Create and deactivate use the real endpoints.
 */
import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Boxes, Plus, Ban, Eye } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { resourcesApi } from '../../lib/api/resources.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, Select, StatusBadge, EmptyState, Badge, StatCard, Toolbar, SearchInput,
  IconButton, DescriptionList, Field,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

const RESOURCE_TYPES = [
  { value: 'api', label: 'API' },
  { value: 'application', label: 'Application' },
  { value: 'dataset', label: 'Dataset' },
  { value: 'service', label: 'Service' },
  { value: 'database', label: 'Database' },
  { value: 'storage', label: 'Storage' },
];

export default function ResourcesPage() {
  const toast = useToast();
  const [searchParams] = useSearchParams();

  const [open, setOpen] = useState(false);
  const [viewResource, setViewResource] = useState(null);
  const [deactivateTarget, setDeactivateTarget] = useState(null);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [filterType, setFilterType] = useState('all');
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    resource_name: '',
    resource_type: 'api',
    resource_arn: '',
    target_url: '',
    is_active: true,
    metadata: '{}',
  });

  const resources = useResource(() => Promise.resolve([]), []);
  const data = Array.isArray(resources.data) ? resources.data : resources.data?.resources || [];

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return data.filter((r) => {
      const matchesSearch =
        !q ||
        r.resource_name?.toLowerCase().includes(q) ||
        r.resource_arn?.toLowerCase().includes(q) ||
        r.target_url?.toLowerCase().includes(q);
      const matchesType = filterType === 'all' || r.resource_type === filterType;
      return matchesSearch && matchesType;
    });
  }, [data, searchQuery, filterType]);

  const stats = {
    total: data.length,
    active: data.filter((r) => r.is_active).length,
    inactive: data.filter((r) => !r.is_active).length,
  };

  const resetForm = () =>
    setForm({
      resource_name: '',
      resource_type: 'api',
      resource_arn: '',
      target_url: '',
      is_active: true,
      metadata: '{}',
    });

  const createResource = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      let metadata = {};
      try {
        metadata = JSON.parse(form.metadata || '{}');
      } catch {
        throw new Error('Metadata must be valid JSON.');
      }
      await resourcesApi.create({
        resource_name: form.resource_name,
        resource_type: form.resource_type,
        resource_arn: form.resource_arn,
        target_url: form.target_url,
        is_active: form.is_active,
        metadata,
      });
      toast.success('Resource created.');
      setOpen(false);
      resetForm();
      resources.reload();
    } catch (err) {
      toast.error(err.message || err.userMessage || 'Could not create resource.');
    } finally {
      setSaving(false);
    }
  };

  const deactivate = async () => {
    setBusy(true);
    try {
      await resourcesApi.deactivate(deactivateTarget?.resource_id);
      toast.success('Resource deactivated.');
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not deactivate resource.');
    } finally {
      setBusy(false);
      setDeactivateTarget(null);
    }
  };

  const columns = [
    {
      id: 'resource_name',
      header: 'Resource',
      primary: true,
      sortable: true,
      render: (r) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <Boxes className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate text-[13px] font-medium text-ink-900">{r.resource_name}</p>
              {r.resource_type && <Badge tone="slate">{r.resource_type}</Badge>}
            </div>
            <p className="truncate font-mono text-xs text-slate-500">{r.resource_arn}</p>
          </div>
        </div>
      ),
    },
    {
      id: 'target_url',
      header: 'Target',
      sortable: true,
      render: (r) => (
        <span className="block max-w-[240px] truncate text-[13px] text-slate-600" title={r.target_url}>
          {r.target_url || '—'}
        </span>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.is_active ? 'ACTIVE' : 'DISABLED'} />,
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex justify-end gap-1">
          <IconButton icon={Eye} title="View details" tone="brand" onClick={() => setViewResource(r)} />
          {r.is_active && (
            <IconButton
              icon={Ban}
              title="Deactivate resource"
              tone="danger"
              onClick={() => setDeactivateTarget(r)}
            />
          )}
        </div>
      ),
    },
  ];

  const filtersActive = !!searchQuery || filterType !== 'all';

  return (
    <div>
      <PageHeader
        title="Resources"
        description="Protected resources available to attribute-based access control."
        icon={<Boxes className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Identity' }, { label: 'Resources' }]}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Create resource
          </Button>
        }
      />

      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <StatCard label="Total" value={stats.total} icon={Boxes} tone="brand" loading={resources.loading} />
          <StatCard label="Active" value={stats.active} icon={Boxes} tone="green" loading={resources.loading} />
          <StatCard label="Inactive" value={stats.inactive} icon={Boxes} tone="slate" loading={resources.loading} />
        </div>

        <Toolbar
          right={
            <span className="text-2xs text-slate-500 tabular">
              {filtered.length} of {data.length} resource{data.length === 1 ? '' : 's'}
            </span>
          }
        >
          <SearchInput
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Search name, ARN or target…"
            width="w-full sm:w-80"
          />
          <Select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full sm:w-44"
            aria-label="Filter by type"
          >
            <option value="all">All types</option>
            {RESOURCE_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
        </Toolbar>

        {resources.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={resources.loading}
            columnsStorageKey="iam-resources-columns"
          />
        ) : (
          <EmptyState
            icon={Boxes}
            title={filtersActive ? 'No resources match these filters' : 'No resources'}
            description={
              filtersActive
                ? 'Adjust the search or type filter to widen the result set.'
                : 'Create a resource to protect it with attribute-based policies.'
            }
            action={
              filtersActive ? (
                <Button
                  variant="secondary"
                  onClick={() => {
                    setSearchQuery('');
                    setFilterType('all');
                  }}
                >
                  Clear filters
                </Button>
              ) : (
                <Button onClick={() => setOpen(true)}>Create resource</Button>
              )
            }
          />
        )}
      </div>

      {/* Create */}
      <Modal
        open={open}
        onClose={() => {
          setOpen(false);
          resetForm();
        }}
        title="Create resource"
        description="The ARN is what policies match on — keep it stable once published."
        icon={Boxes}
        footer={
          <>
            <Button
              variant="secondary"
              onClick={() => {
                setOpen(false);
                resetForm();
              }}
            >
              Cancel
            </Button>
            <Button onClick={createResource} loading={saving}>
              Create resource
            </Button>
          </>
        }
      >
        <form onSubmit={createResource} className="space-y-4">
          <Input
            label="Resource name"
            value={form.resource_name}
            onChange={(e) => setForm((f) => ({ ...f, resource_name: e.target.value }))}
            required
            placeholder="user-management-api"
          />
          <Select
            label="Resource type"
            value={form.resource_type}
            onChange={(e) => setForm((f) => ({ ...f, resource_type: e.target.value }))}
          >
            {RESOURCE_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
          <Input
            label="ARN"
            value={form.resource_arn}
            onChange={(e) => setForm((f) => ({ ...f, resource_arn: e.target.value }))}
            required
            placeholder="iam:api:user-management"
            hint="Stable identifier referenced by policy documents."
            className="font-mono"
          />
          <Input
            label="Target URL"
            value={form.target_url}
            onChange={(e) => setForm((f) => ({ ...f, target_url: e.target.value }))}
            placeholder="https://api.example.com"
          />
          <Field label="Metadata (JSON)" hint="Optional attributes available to policy conditions.">
            <textarea
              value={form.metadata}
              onChange={(e) => setForm((f) => ({ ...f, metadata: e.target.value }))}
              rows={3}
              className="input-base font-mono text-xs"
              placeholder='{"env": "prod", "team": "backend"}'
            />
          </Field>
        </form>
      </Modal>

      {/* View */}
      <Modal
        open={!!viewResource}
        onClose={() => setViewResource(null)}
        title={viewResource?.resource_name || 'Resource details'}
        icon={Boxes}
        footer={
          <Button variant="secondary" onClick={() => setViewResource(null)}>
            Close
          </Button>
        }
      >
        {viewResource && (
          <div className="space-y-4">
            <DescriptionList
              items={[
                { label: 'Name', value: viewResource.resource_name },
                { label: 'Type', value: <Badge tone="slate">{viewResource.resource_type}</Badge> },
                { label: 'ARN', value: viewResource.resource_arn, mono: true, wide: true },
                { label: 'Target URL', value: viewResource.target_url || '—', wide: true },
                {
                  label: 'Status',
                  value: <StatusBadge status={viewResource.is_active ? 'ACTIVE' : 'DISABLED'} />,
                },
              ]}
            />
            {viewResource.metadata && Object.keys(viewResource.metadata).length > 0 && (
              <div>
                <p className="mb-1.5 text-3xs font-semibold uppercase tracking-[0.08em] text-slate-400">
                  Metadata
                </p>
                <pre className="overflow-auto rounded-lg border border-line-soft bg-slate-50/70 p-3 font-mono text-2xs text-slate-600">
                  {JSON.stringify(viewResource.metadata, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deactivateTarget}
        onClose={() => setDeactivateTarget(null)}
        onConfirm={deactivate}
        danger
        loading={busy}
        title="Deactivate resource"
        confirmLabel="Deactivate"
        message={`“${deactivateTarget?.resource_name || 'This resource'}” will stop matching policy evaluations.`}
        detail="Deactivation is reversible and recorded in the audit trail. Policies referencing this ARN stay in place."
      />
    </div>
  );
}
