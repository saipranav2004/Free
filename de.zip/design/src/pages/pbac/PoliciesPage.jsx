import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileLock2, Plus, Ban, Pencil } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, StatusBadge, Badge, EmptyState, Toolbar, SearchInput, IconButton,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

/**
 * PoliciesPage — PBAC policy inventory.
 *
 * System policies are marked and protected from disable, matching the backend
 * contract; the destructive action always routes through ConfirmDialog with the
 * blast radius spelled out.
 */
export default function PoliciesPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const policies = useResource(() => pbacApi.listPolicies(), []);
  const [disableTarget, setDisableTarget] = useState(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');

  const data = Array.isArray(policies.data) ? policies.data : policies.data?.policies || [];

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (p) => p.policy_name?.toLowerCase().includes(q) || p.description?.toLowerCase().includes(q)
    );
  }, [data, search]);

  const disable = async () => {
    setBusy(true);
    try {
      await pbacApi.disablePolicy(disableTarget?.policy_id);
      toast.success('Policy disabled.');
      policies.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable policy.');
    } finally {
      setBusy(false);
      setDisableTarget(null);
    }
  };

  const columns = [
    {
      id: 'policy_name',
      header: 'Policy',
      primary: true,
      sortable: true,
      render: (p) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <FileLock2 className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate text-[13px] font-medium text-ink-900">{p.policy_name}</p>
              {p.is_system_policy && <Badge tone="brand">System</Badge>}
            </div>
            <p className="truncate text-xs text-slate-500">{p.description || 'No description'}</p>
          </div>
        </div>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      sortable: true,
      render: (p) => <StatusBadge status={p.status} />,
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (p) => (
        <div className="flex justify-end gap-1">
          <IconButton
            icon={Pencil}
            title="Edit policy"
            tone="brand"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/pbac/policies/${p.policy_id}`);
            }}
          />
          {!p.is_system_policy && (
            <IconButton
              icon={Ban}
              title="Disable policy"
              tone="danger"
              onClick={(e) => {
                e.stopPropagation();
                setDisableTarget(p);
              }}
            />
          )}
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Policies"
        description="Attribute-based policies evaluated by the policy decision point (OPA)."
        icon={<FileLock2 className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Access control' }, { label: 'Policies (PBAC)' }]}
        actions={
          <Button onClick={() => navigate('/pbac/policies/new')}>
            <Plus className="h-4 w-4" /> New policy
          </Button>
        }
      />

      <div className="space-y-4">
        <Toolbar
          right={
            <span className="text-2xs text-slate-500 tabular">
              {filtered.length} of {data.length} polic{data.length === 1 ? 'y' : 'ies'}
            </span>
          }
        >
          <SearchInput value={search} onChange={setSearch} placeholder="Search policies…" />
        </Toolbar>

        {policies.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={policies.loading}
            columnsStorageKey="iam-policies-columns"
            onRowClick={(p) => navigate(`/pbac/policies/${p.policy_id}`)}
            empty={{
              icon: FileLock2,
              title: `No policies match “${search}”`,
              description: 'Adjust the search to see more results.',
              action: (
                <Button variant="secondary" onClick={() => setSearch('')}>
                  Clear search
                </Button>
              ),
            }}
          />
        ) : (
          <EmptyState
            icon={FileLock2}
            title="No policies yet"
            description="Create a policy to express fine-grained, attribute-based access rules."
            action={<Button onClick={() => navigate('/pbac/policies/new')}>New policy</Button>}
          />
        )}
      </div>

      <ConfirmDialog
        open={!!disableTarget}
        onClose={() => setDisableTarget(null)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Disable policy"
        confirmLabel="Disable policy"
        message={`“${disableTarget?.policy_name || 'This policy'}” will stop being evaluated by the PDP immediately.`}
        detail="Requests that relied on this policy for an Allow decision will begin to be denied. Existing sessions are not revoked."
      />
    </div>
  );
}
