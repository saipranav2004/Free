import { useState, useMemo } from 'react';
import { Boxes, Plus, Ban } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, StatusBadge, EmptyState, Badge, Toolbar, SearchInput, IconButton,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

/**
 * ResourcesPage (ABAC) — the registry of protected resources referenced by
 * policies. ARNs are monospace because they are copied into policy documents.
 */
export default function ResourcesPage() {
  const toast = useToast();
  const resources = useResource(() => pbacApi.listResources(), []);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [disableTarget, setDisableTarget] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: '', type: '', arn: '', target_url: '' });

  const data = Array.isArray(resources.data) ? resources.data : resources.data?.resources || [];

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (r) =>
        r.resource_name?.toLowerCase().includes(q) ||
        r.resource_arn?.toLowerCase().includes(q) ||
        r.resource_type?.toLowerCase().includes(q)
    );
  }, [data, search]);

  const register = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await pbacApi.registerResource(form);
      toast.success('Resource registered.');
      setOpen(false);
      setForm({ name: '', type: '', arn: '', target_url: '' });
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not register resource.');
    } finally {
      setSaving(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await pbacApi.disableResource(disableTarget?.resource_id);
      toast.success('Resource disabled.');
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable resource.');
    } finally {
      setBusy(false);
      setDisableTarget(null);
    }
  };

  const columns = [
    {
      id: 'resource_name',
      header: 'Resource',
      primary: true,
      sortable: true,
      render: (r) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <Boxes className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate text-[13px] font-medium text-ink-900">{r.resource_name}</p>
              {r.resource_type && <Badge tone="slate">{r.resource_type}</Badge>}
            </div>
            <p className="truncate font-mono text-xs text-slate-500">{r.resource_arn}</p>
          </div>
        </div>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      render: (r) => <StatusBadge status={r.is_active ? 'ACTIVE' : 'DISABLED'} />,
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) =>
        r.is_active ? (
          <IconButton
            icon={Ban}
            title="Disable resource"
            tone="danger"
            onClick={() => setDisableTarget(r)}
          />
        ) : null,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Registered resources"
        description="Protected resources available to attribute-based policy evaluation."
        icon={<Boxes className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Access control' }, { label: 'Resources (ABAC)' }]}
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Register resource
          </Button>
        }
      />

      <div className="space-y-4">
        <Toolbar
          right={
            <span className="text-2xs text-slate-500 tabular">
              {filtered.length} of {data.length} resource{data.length === 1 ? '' : 's'}
            </span>
          }
        >
          <SearchInput value={search} onChange={setSearch} placeholder="Search name, type or ARN…" />
        </Toolbar>

        {resources.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={resources.loading}
            columnsStorageKey="iam-abac-resources-columns"
            empty={{
              icon: Boxes,
              title: `No resources match “${search}”`,
              description: 'Adjust the search to see more results.',
              action: (
                <Button variant="secondary" onClick={() => setSearch('')}>
                  Clear search
                </Button>
              ),
            }}
          />
        ) : (
          <EmptyState
            icon={Boxes}
            title="No resources registered"
            description="Register an application or dataset so policies can reference it by ARN."
            action={<Button onClick={() => setOpen(true)}>Register resource</Button>}
          />
        )}
      </div>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Register resource"
        description="The ARN is the identifier policies match on — keep it stable."
        icon={Boxes}
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={register} loading={saving}>
              Register resource
            </Button>
          </>
        }
      >
        <form onSubmit={register} className="space-y-4">
          <Input
            label="Name"
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            required
            placeholder="user-management-api"
          />
          <Input
            label="Type"
            value={form.type}
            onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))}
            placeholder="application | dataset"
            required
          />
          <Input
            label="ARN"
            value={form.arn}
            onChange={(e) => setForm((f) => ({ ...f, arn: e.target.value }))}
            placeholder="iam:app/my-app"
            required
            className="font-mono"
          />
          <Input
            label="Target URL"
            value={form.target_url}
            onChange={(e) => setForm((f) => ({ ...f, target_url: e.target.value }))}
            placeholder="https://…"
            required
          />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!disableTarget}
        onClose={() => setDisableTarget(null)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Disable resource"
        confirmLabel="Disable resource"
        message={`“${disableTarget?.resource_name || 'This resource'}” will no longer be evaluated for access decisions.`}
        detail="Policies referencing this ARN remain in place but stop matching until the resource is re-enabled."
      />
    </div>
  );
}
