import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, UserPlus, Link2, Users, ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, EmptyState, SearchableCombobox } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';

/**
 * Premium Enterprise Group Detail Page.
 *
 * Bug fix: Extract members and roles from multiple possible response shapes
 * since the backend may return them under different field names.
 *
 * Features:
 *  - Searchable combobox for attaching roles (enterprise pattern)
 *  - Premium empty states with actionable CTAs
 *  - Better visual hierarchy
 */
export default function GroupDetailPage() {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const group = useResource(() => rbacApi.getGroup(groupId), [groupId]);
  const roles = useResource(() => rbacApi.listRoles(), []);

  const [memberOpen, setMemberOpen] = useState(false);
  const [roleOpen, setRoleOpen] = useState(false);
  const [userId, setUserId] = useState('');
  const [roleId, setRoleId] = useState('');
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState({ group_name: '', description: '' });
  const [disableOpen, setDisableOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const { accountId } = useAuth();

  // ── Fetch users for the Add Member combobox ──
  const usersResource = useResource(
    () => memberOpen ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null,
    [memberOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];
  const userOptions = usersList.map((u) => ({
    id: u.user_id,
    label: u.username || u.email || u.user_id,
    description: u.email,
    badge: u.status,
  }));

  // ── Role combobox data ──
  const rolesList = roles.data?.roles || [];
  const roleOptions = rolesList.map((r) => ({
    id: r.role_id,
    label: r.role_name,
    description: r.description,
  }));

  // ── Group data extraction (tolerate multiple response shapes) ──
  const data = group.data || {};

  // Bug fix: Extract members from multiple possible field names
  const members = Array.isArray(data.members)
    ? data.members
    : Array.isArray(data.users)
      ? data.users
      : Array.isArray(data.memberships)
        ? data.memberships
        : [];

  // Bug fix: Extract attached roles from multiple possible field names
  const attachedRoles = Array.isArray(data.roles)
    ? data.roles
    : Array.isArray(data.attached_roles)
      ? data.attached_roles
      : [];

  // Also check for policies if no roles found
  const attachedPolicies = Array.isArray(data.policies)
    ? data.policies
    : Array.isArray(data.attached_policies)
      ? data.attached_policies
      : [];

  // Determine what's attached (roles take precedence if present)
  const attached = attachedRoles.length > 0 ? attachedRoles : attachedPolicies;
  const attachedIsRole = attachedRoles.length > 0;
  const itemId = (x) => x.role_id || x.policy_id || x.id;
  const itemName = (x) => x.role_name || x.policy_name || x.name || itemId(x);

  const openEdit = () => {
    setForm({ group_name: data.group_name || '', description: data.description || '' });
    setEditOpen(true);
  };

  const addMember = async (e) => {
    e.preventDefault();
    if (!userId) { toast.error('Please enter a user ID.'); return; }
    setBusy(true);
    try {
      await rbacApi.addGroupMember(groupId, userId);
      toast.success('Member added.');
      setMemberOpen(false);
      setUserId('');
      group.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not add member.');
    } finally {
      setBusy(false);
    }
  };

  const removeMember = async (uid) => {
    try {
      await rbacApi.removeGroupMember(groupId, uid);
      toast.success('Member removed.');
      group.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not remove member.');
    }
  };

  const attachRole = async (e) => {
    e.preventDefault();
    if (!roleId) { toast.error('Please select a role.'); return; }
    setBusy(true);
    try {
      await rbacApi.attachGroupRole(groupId, roleId);
      toast.success('Role attached.');
      setRoleOpen(false);
      setRoleId('');
      group.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach role.');
    } finally {
      setBusy(false);
    }
  };

  const detachRole = async (rid) => {
    try {
      await rbacApi.detachGroupRole(groupId, rid);
      toast.success('Role detached.');
      group.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not detach role.');
    }
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await rbacApi.updateGroup(groupId, form);
      toast.success('Group updated.');
      setEditOpen(false);
      group.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not update group.');
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await rbacApi.disableGroup(groupId);
      toast.success('Group disabled.');
      navigate('/rbac/groups');
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable group.');
    } finally {
      setBusy(false);
      setDisableOpen(false);
    }
  };

  if (group.loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => navigate('/rbac/groups')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Groups
      </button>

      <PageHeader
        title={data.group_name}
        description={data.description}
        actions={
          <>
            <Button variant="secondary" onClick={openEdit}>Edit</Button>
            <Button variant="danger" onClick={() => setDisableOpen(true)}>
              <Trash2 className="h-4 w-4" /> Disable
            </Button>
          </>
        }
      />

      {/* Enterprise: summary stats row */}
      <div className="mb-6 grid grid-cols-2 gap-4">
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-brand-50 p-2 text-brand-600">
            <Users className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Members</p>
            <p className="text-lg font-semibold text-ink-900">{members.length}</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">{attachedIsRole ? 'Attached Roles' : 'Attached Policies'}</p>
            <p className="text-lg font-semibold text-ink-900">{attached.length}</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Members Card */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <Users className="h-4 w-4 text-brand-600" /> Members
            </h3>
            <Button size="sm" onClick={() => setMemberOpen(true)}>
              <UserPlus className="h-4 w-4" /> Add
            </Button>
          </div>
          {group.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : members.length ? (
            <ul className="divide-y divide-line-soft">
              {members.map((m) => (
                <li key={m.user_id || m.id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-2xs font-semibold text-brand-700">
                      {m.username?.charAt(0)?.toUpperCase() || '?'}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{m.username}</p>
                      {m.email && <p className="text-xs text-slate-400">{m.email}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeMember(m.user_id || m.id)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <Users className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No members</p>
              <p className="mt-1 text-xs text-slate-500">Add users to grant this group's roles.</p>
            </div>
          )}
        </Card>

        {/* Attached Roles Card */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <ShieldCheck className="h-4 w-4 text-emerald-600" /> {attachedIsRole ? 'Attached roles' : 'Attached policies'}
            </h3>
            <Button size="sm" onClick={() => setRoleOpen(true)}>
              <Link2 className="h-4 w-4" /> Attach
            </Button>
          </div>
          {group.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : attached.length ? (
            <ul className="divide-y divide-line-soft">
              {attached.map((r) => (
                <li key={itemId(r)} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-2xs font-semibold text-slate-600">
                      <ShieldCheck className="h-4 w-4" />
                    </span>
                    <span className="text-sm font-medium text-ink-800">{itemName(r)}</span>
                  </div>
                  {r.role_id ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => detachRole(r.role_id)}
                      className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <ShieldCheck className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No {attachedIsRole ? 'roles' : 'policies'} attached</p>
              <p className="mt-1 text-xs text-slate-500">Attach {attachedIsRole ? 'roles' : 'policies'} to grant access.</p>
            </div>
          )}
        </Card>
      </div>

      {/* ── Add Member Modal (enterprise searchable combobox) ── */}
      <Modal
        open={memberOpen}
        onClose={() => { setMemberOpen(false); setUserId(''); }}
        title="Add member"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setMemberOpen(false); setUserId(''); }}>Cancel</Button>
            <Button onClick={addMember} loading={busy}>Add</Button>
          </>
        }
      >
        <form onSubmit={addMember} className="space-y-4">
          <SearchableCombobox
            label="User"
            options={userOptions}
            value={userId}
            onChange={setUserId}
            placeholder="Choose a user to add…"
            searchPlaceholder="Search by name or email…"
            loading={usersResource.loading}
            hint="Select a user to add as a member of this group."
          />
        </form>
      </Modal>

      {/* ── Attach Role Modal (enterprise searchable combobox) ── */}
      <Modal
        open={roleOpen}
        onClose={() => { setRoleOpen(false); setRoleId(''); }}
        title="Attach role"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setRoleOpen(false); setRoleId(''); }}>Cancel</Button>
            <Button onClick={attachRole} loading={busy}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attachRole} className="space-y-4">
          <SearchableCombobox
            label="Role"
            options={roleOptions}
            value={roleId}
            onChange={setRoleId}
            placeholder="Choose a role…"
            searchPlaceholder="Search by name…"
            loading={roles.loading}
            hint="Select a role to attach to this group."
          />
        </form>
      </Modal>

      {/* ── Edit Group Modal ── */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit group"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={saveEdit} loading={busy}>Save</Button>
          </>
        }
      >
        <form onSubmit={saveEdit} className="space-y-4">
          <Input label="Group name" value={form.group_name} onChange={(e) => setForm((f) => ({ ...f, group_name: e.target.value }))} required />
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
        </form>
      </Modal>

      <ConfirmDialog
        open={disableOpen}
        onClose={() => setDisableOpen(false)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Disable group"
        message="Members will lose the roles granted through this group."
      />
    </div>
  );
}
