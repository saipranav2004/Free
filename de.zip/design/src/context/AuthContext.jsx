import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../lib/api/auth.js';
import { mfaApi } from '../lib/api/mfa.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { tokenStore } from '../lib/tokenStore.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => tokenStore.getUser());
  const [accessToken, setAccessToken] = useState(() =>
    tokenStore.getAccessToken()
  );
  const [accountId, setAccountId] = useState(() => tokenStore.getAccountId());
  const [bootstrapping, setBootstrapping] = useState(true);
  const navigate = useNavigate();

  // On first load:
  //  1. If the URL carries SSO tokens (?access_token&refresh_token), consume
  //     them — this runs regardless of which route the IdP/browser lands on —
  //     fetch the profile, strip the tokens from the URL, then go to the
  //     dashboard.
  //  2. Otherwise re-hydrate the profile if we have a token but no user.
  useEffect(() => {
    let cancelled = false;

    const consumeSso = async () => {
      // Tokens may arrive in the query string OR the URL fragment.
      const search = new URLSearchParams(window.location.search);
      const hash = new URLSearchParams(window.location.hash.replace(/^#/, ''));
      const read = (k) => search.get(k) || hash.get(k);

      // ---- SSO step-up MFA (patched backend) ----
      // When the user has MFA enabled, the backend's SSO callback redirects
      // here with `mfa_required` + `mfa_challenge_token` instead of tokens.
      // Route straight to the MFA page so the second factor can be verified
      // before any session is established.
      const mfaRequired = read('mfa_required');
      const mfaChallengeToken = read('mfa_challenge_token');
      if (mfaRequired && mfaChallengeToken) {
        window.history.replaceState(
          {},
          document.title,
          window.location.pathname + (window.location.hash || '')
        );
        if (!cancelled) {
          navigate('/login/mfa', {
            replace: true,
            state: { challengeToken: mfaChallengeToken, ssoMfaPending: true },
          });
          setBootstrapping(false);
        }
        return true;
      }

      const access = read('access_token');
      const refresh = read('refresh_token');
      if (!access || !refresh) return false;
      const acc = read('account_id') || read('tenant_id') || null;
      // Provisionally install the tokens ONLY so we can read the profile
      // (to learn whether MFA is enabled). The session is not committed yet.
      tokenStore.setTokens(access, refresh);
      if (acc) tokenStore.setAccountId(acc);
      // Strip tokens from the URL so they aren't leaked via history/referers.
      window.history.replaceState({}, document.title, window.location.pathname);
      let profile = null;
      try {
        profile = await authApi.me();
      } catch {
        profile = null;
      }

      // ---- MFA gate for SSO users ----
      // If MFA is enabled we must NOT drop the user straight into the app.
      // Send them to the MFA page. With the backend SSO MFA gate applied the
      // page becomes a real verification step; without it the page explains
      // why the sign-in cannot complete (the user is never silently logged in).
      if (profile?.mfa_enabled) {
        tokenStore.clear(); // discard the provisional tokens
        if (!cancelled) {
          navigate('/login/mfa', {
            replace: true,
            state: { ssoMfaPending: true, noChallenge: true },
          });
          setBootstrapping(false);
        }
        return true;
      }

      // No MFA required: persist the profile + tokens and enter the app.
      tokenStore.setUser(profile || {});
      setUser(profile || {});
      const aid = profile?.account_id || profile?.accountId || acc;
      if (aid) {
        tokenStore.setAccountId(aid);
        setAccountId(aid);
      }
      setAccessToken(access);
      setAccountId(tokenStore.getAccountId());
      if (!cancelled) {
        navigate('/', { replace: true });
        setBootstrapping(false);
      }
      return true;
    };

    const token = tokenStore.getAccessToken();
    const existing = tokenStore.getUser();
    const hasUser = !!existing && Object.keys(existing).length > 0;

    (async () => {
      if (await consumeSso()) return;
      if (token && !hasUser) {
        authApi
          .me()
          .then((u) => {
            if (!cancelled) {
              tokenStore.setUser(u);
              setUser(u);
            }
          })
          .catch(() => {
            tokenStore.clear();
            if (!cancelled) {
              setUser(null);
              setAccessToken(null);
            }
          })
          .finally(() => !cancelled && setBootstrapping(false));
      } else {
        setBootstrapping(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const _applySession = useCallback((result, accountIdValue) => {
    const { access_token, refresh_token, user: u } = result;
    tokenStore.setTokens(access_token, refresh_token);
    tokenStore.setUser(u);
    if (accountIdValue) {
      tokenStore.setAccountId(accountIdValue);
      setAccountId(accountIdValue);
    }
    setAccessToken(access_token);
    setUser(u);
    return u;
  }, []);

  // Step 1 of login. Returns { mfaRequired, challengeToken?, user? }.
  const login = useCallback(
    async ({ identifier, password, accountId }) => {
      const result = await authApi.login({ identifier, password, account_id: accountId });
      if (result?.mfa_required) {
        // Persist account id even for the MFA step so it's available after.
        if (accountId) {
          tokenStore.setAccountId(accountId);
          setAccountId(accountId);
        }
        return { mfaRequired: true, challengeToken: result.mfa_challenge_token };
      }
      _applySession(result, accountId);
      return { mfaRequired: false, user: result.user };
    },
    [_applySession]
  );

  const completeMfa = useCallback(
    async ({ code, challengeToken }) => {
      const result = await mfaApi.verifyMfa({
        mfa_challenge_token: challengeToken,
        code,
      });
      _applySession(result, tokenStore.getAccountId());
      return result.user;
    },
    [_applySession]
  );

  const logout = useCallback(
    async (allSessions = false) => {
      try {
        await sessionsApi.logout(allSessions, tokenStore.getRefreshToken());
      } catch {
        /* best effort */
      }
      tokenStore.clear();
      setUser(null);
      setAccessToken(null);
    },
    []
  );

  // SSO tokens are now consumed centrally on mount (see the bootstrap effect
  // above) so the callback works on any route. This helper is kept for
  // explicit use and also fetches the profile so the user is fully populated.
  const applyTokensFromUrl = useCallback(
    async (result, accountIdValue) => {
      _applySession(result, accountIdValue || tokenStore.getAccountId());
      try {
        const u = await authApi.me();
        tokenStore.setUser(u);
        setUser(u);
      } catch {
        /* keep the token; profile re-hydrates on next load */
      }
    },
    [_applySession]
  );

  const refreshProfile = useCallback(async () => {
    const u = await authApi.me();
    tokenStore.setUser(u);
    setUser(u);
    return u;
  }, []);

  const value = useMemo(
    () => ({
      user,
      accessToken,
      accountId,
      isAuthenticated: !!accessToken && !!user,
      bootstrapping,
      login,
      completeMfa,
      logout,
      refreshProfile,
      applyTokensFromUrl,
      setAccountId: (id) => {
        tokenStore.setAccountId(id);
        setAccountId(id);
      },
      setUser: (u) => {
        tokenStore.setUser(u);
        setUser(u);
      },
    }),
    [
      user,
      accessToken,
      accountId,
      bootstrapping,
      login,
      completeMfa,
      logout,
      refreshProfile,
      applyTokensFromUrl,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
