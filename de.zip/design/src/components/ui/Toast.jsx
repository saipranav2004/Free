import { CheckCircle2, XCircle, Info, AlertTriangle, X } from 'lucide-react';
import { classNames } from '../../utils/format.js';

const ICONS = {
  success: CheckCircle2,
  error: XCircle,
  info: Info,
  warning: AlertTriangle,
};

const ICON_TONES = {
  success: 'text-emerald-600 bg-emerald-50',
  error: 'text-rose-600 bg-rose-50',
  info: 'text-brand-600 bg-brand-50',
  warning: 'text-amber-600 bg-amber-50',
};

/**
 * ToastViewport — transient confirmations.
 * Bottom-right, hairline border, one subtle elevation. No coloured slabs:
 * the icon carries the semantics so the surface stays calm.
 */
export function ToastViewport({ toasts, onDismiss }) {
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[calc(100vw-2rem)] max-w-sm flex-col gap-2">
      {toasts.map((t) => {
        const Icon = ICONS[t.type] || Info;
        return (
          <div
            key={t.id}
            className="pointer-events-auto flex items-start gap-3 rounded-xl border border-line bg-white px-3.5 py-3 shadow-popover animate-toast-in"
            role={t.type === 'error' ? 'alert' : 'status'}
          >
            <span
              className={classNames(
                'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg',
                ICON_TONES[t.type] || ICON_TONES.info
              )}
            >
              <Icon className="h-4 w-4" />
            </span>
            <div className="flex-1 pt-0.5 text-[13px] leading-snug text-ink-800">{t.message}</div>
            <button
              type="button"
              onClick={() => onDismiss(t.id)}
              className="-mr-1 -mt-0.5 rounded-lg p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
              aria-label="Dismiss notification"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
