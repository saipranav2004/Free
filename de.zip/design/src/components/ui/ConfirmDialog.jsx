import { AlertTriangle, HelpCircle } from 'lucide-react';
import { Modal } from './Modal.jsx';
import { Button } from './primitives.jsx';

/**
 * ConfirmDialog — destructive and irreversible actions.
 *
 * Enterprise convention: state the blast radius in the body, not the title.
 * The confirm button carries the verb ("Revoke", "Offboard"), never "OK".
 */
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title = 'Are you sure?',
  message,
  detail,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  danger = false,
  loading = false,
  children,
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      size="sm"
      icon={danger ? AlertTriangle : HelpCircle}
      tone={danger ? 'danger' : 'brand'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={loading}>
            {cancelLabel}
          </Button>
          <Button
            variant={danger ? 'danger' : 'primary'}
            onClick={onConfirm}
            loading={loading}
            data-autofocus
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      {message && <p className="text-[13px] leading-relaxed text-ink-700">{message}</p>}
      {detail && (
        <div className="mt-3 rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2.5 text-xs leading-relaxed text-slate-600">
          {detail}
        </div>
      )}
      {children}
    </Modal>
  );
}
