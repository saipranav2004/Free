/**
 * EventDetailPanel — forensic detail for one audit / denial event.
 *
 * Design decisions (SIEM master-detail conventions):
 *  · Answers WHO / WHAT / WHERE / WHEN in a two-column key-value grid before
 *    anything else, so triage takes one glance.
 *  · Matched policies are surfaced for denials — the "why" of a DENY decision.
 *  · Raw payload stays available but collapsed: forensics without visual noise.
 *  · Identifiers are monospace and one-click copyable (investigators paste IDs
 *    into tickets constantly).
 *  · With nothing selected the pane is a quiet prompt, not an empty chrome.
 *
 * Fix in this pass: the alert-detail fetch now re-runs when the selected event
 * changes (its dependency list was previously empty, so the panel kept showing
 * the first event's enriched payload).
 */
import { useState, useCallback } from 'react';
import {
  X, User, Shield, FileText, Copy, Check, CheckCircle2, XCircle, Info,
  ChevronDown, Fingerprint,
} from 'lucide-react';
import { Badge, Button, Spinner } from '../ui/primitives.jsx';
import { useResource } from '../../hooks/useResource.js';
import { alertsApi } from '../../lib/api/alerts.js';
import { formatDateTime, shortId, classNames } from '../../utils/format.js';

function DecisionBadge({ decision }) {
  if (!decision) return <span className="text-xs text-slate-400">—</span>;
  const d = String(decision).toUpperCase();
  const allow = d === 'ALLOW' || d === 'SUCCESS';
  return (
    <Badge tone={allow ? 'green' : 'red'} dot>
      {d}
    </Badge>
  );
}

function Field({ label, value, mono, copyable, wide }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(() => {
    if (!value || value === '—') return;
    navigator.clipboard?.writeText(String(value));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }, [value]);

  return (
    <div className={classNames('group min-w-0', wide && 'col-span-2')}>
      <p className="text-3xs font-medium uppercase tracking-[0.08em] text-slate-400">{label}</p>
      <div className="mt-1 flex items-start gap-1.5">
        <p
          className={classNames(
            'min-w-0 flex-1 text-[13px] text-ink-900',
            mono ? 'break-all font-mono text-xs' : 'truncate'
          )}
          title={typeof value === 'string' ? value : undefined}
        >
          {value || '—'}
        </p>
        {copyable && value && value !== '—' && (
          <button
            type="button"
            onClick={handleCopy}
            title="Copy"
            className="shrink-0 rounded p-0.5 text-slate-300 opacity-0 transition hover:text-slate-600 focus:opacity-100 group-hover:opacity-100"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
        )}
      </div>
    </div>
  );
}

function EmptyDetailState() {
  return (
    <div className="flex h-full flex-col items-center justify-center px-8 py-16 text-center">
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100">
        <Info className="h-5 w-5 text-slate-400" />
      </span>
      <p className="mt-3 text-[13px] font-semibold text-ink-900">No event selected</p>
      <p className="mt-1 max-w-[220px] text-xs leading-relaxed text-slate-500">
        Choose an event from the feed to inspect the principal, decision and matched policies.
      </p>
    </div>
  );
}

export function EventDetailPanel({ event, onClose, onNavigateToUser, onNavigateToResource }) {
  const [rawOpen, setRawOpen] = useState(false);

  const isDeny =
    String(event?.decision || '').toUpperCase() === 'DENY' ||
    String(event?.status || '').toUpperCase() === 'FAILURE';
  const alertId = event?.audit_id || event?.id;
  const shouldFetch = isDeny && !!alertId;

  const detailFetcher = useCallback(() => alertsApi.detail(alertId), [alertId]);
  // Dependencies matter here: the panel must re-fetch when the selection moves.
  const detailRes = useResource(shouldFetch ? detailFetcher : null, [alertId, shouldFetch]);
  const detail = detailRes?.data;

  if (!event) return <EmptyDetailState />;

  const auditEvent = detail?.audit_event || event;
  const userProfile = detail?.user_profile || {};
  const policies = detail?.policy_attachments || [];

  let detailsJson = null;
  if (auditEvent?.details) {
    try {
      const parsed =
        typeof auditEvent.details === 'string' ? JSON.parse(auditEvent.details) : auditEvent.details;
      detailsJson = JSON.stringify(parsed, null, 2);
    } catch {
      detailsJson = String(auditEvent.details);
    }
  }

  const decision = String(auditEvent?.decision || auditEvent?.status || '').toUpperCase();
  const denied = decision === 'DENY' || decision === 'FAILURE';

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-start justify-between gap-2 border-b border-line bg-white px-4 py-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span
            className={classNames(
              'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg',
              denied ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
            )}
          >
            {denied ? <XCircle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
          </span>
          <div className="min-w-0">
            <p className="truncate font-mono text-[13px] font-semibold text-ink-900">
              {auditEvent?.action || auditEvent?.event_type || 'Event detail'}
            </p>
            <p className="text-2xs text-slate-500">{formatDateTime(auditEvent?.created_at)}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="-mr-1 shrink-0 rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
          aria-label="Close detail panel"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {detailRes?.loading ? (
        <div className="flex flex-1 items-center justify-center py-16">
          <Spinner className="h-5 w-5" />
        </div>
      ) : (
        <div className="flex-1 space-y-5 overflow-y-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-1.5">
            <DecisionBadge decision={auditEvent?.decision || auditEvent?.status} />
            {auditEvent?.log_type && (
              <Badge tone={auditEvent.log_type === 'authn' ? 'sky' : 'brand'}>
                {String(auditEvent.log_type).toUpperCase()}
              </Badge>
            )}
            {auditEvent?.audit_id && (
              <Badge tone="outline" mono>
                {shortId(auditEvent.audit_id)}
              </Badge>
            )}
          </div>

          <section>
            <p className="mb-2.5 flex items-center gap-1.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <Fingerprint className="h-3 w-3" />
              Principal & target
            </p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-3.5">
              <Field label="Principal" value={userProfile.username || auditEvent?.username} />
              <Field label="Email" value={userProfile.email || auditEvent?.email} />
              <Field label="User ID" value={shortId(auditEvent?.user_id)} mono copyable />
              <Field label="IP address" value={auditEvent?.ip_address} mono copyable />
              <Field
                label="Resource"
                value={auditEvent?.resource_name || auditEvent?.resource}
                wide
              />
            </div>
          </section>

          {auditEvent?.user_agent && (
            <section>
              <p className="mb-1.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                User agent
              </p>
              <p className="break-all rounded-lg border border-line-soft bg-slate-50/70 p-2.5 font-mono text-2xs leading-relaxed text-slate-600">
                {auditEvent.user_agent}
              </p>
            </section>
          )}

          {policies.length > 0 && (
            <section>
              <p className="mb-2 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                Matched policies ({policies.length})
              </p>
              <ul className="space-y-1.5">
                {policies.map((pol, i) => (
                  <li
                    key={pol.policy_id || i}
                    className="flex items-center gap-2 rounded-lg border border-line bg-white px-3 py-2"
                  >
                    <Shield className="h-3.5 w-3.5 shrink-0 text-amber-600" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-ink-900">
                        {pol.policy_name || pol.name || `Policy ${shortId(pol.policy_id)}`}
                      </p>
                      {pol.policy_id && (
                        <p className="truncate font-mono text-3xs text-slate-400">
                          {shortId(pol.policy_id)}
                        </p>
                      )}
                    </div>
                    <Badge tone={String(pol.effect).toUpperCase() === 'ALLOW' ? 'green' : 'amber'}>
                      {pol.effect || 'DENY'}
                    </Badge>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {detailsJson && (
            <section>
              <button
                type="button"
                onClick={() => setRawOpen((o) => !o)}
                className="flex w-full items-center justify-between rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2 text-left transition-colors hover:bg-slate-100"
              >
                <span className="text-3xs font-semibold uppercase tracking-[0.1em] text-slate-500">
                  Raw event payload
                </span>
                <ChevronDown
                  className={classNames('h-3.5 w-3.5 text-slate-400 transition-transform', rawOpen && 'rotate-180')}
                />
              </button>
              {rawOpen && (
                <pre className="mt-2 max-h-64 overflow-auto rounded-lg bg-ink-900 p-3 font-mono text-3xs leading-relaxed text-slate-200">
                  {detailsJson}
                </pre>
              )}
            </section>
          )}

          {(onNavigateToUser || onNavigateToResource) && (
            <div className="flex flex-wrap gap-2 border-t border-line-soft pt-3">
              {onNavigateToUser && (auditEvent?.user_id || auditEvent?.username) && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => onNavigateToUser(auditEvent.user_id || auditEvent.username)}
                >
                  <User className="h-3.5 w-3.5" /> View principal
                </Button>
              )}
              {onNavigateToResource && (auditEvent?.resource_name || auditEvent?.resource) && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => onNavigateToResource(auditEvent.resource_name || auditEvent.resource)}
                >
                  <FileText className="h-3.5 w-3.5" /> View resource
                </Button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
