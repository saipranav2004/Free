import { ChevronLeft, ChevronRight } from 'lucide-react';
import { classNames } from '../../utils/format.js';

/**
 * Pagination — result-set navigator.
 *
 * Enterprise pattern: state the range and the total ("11–20 of 348") so admins
 * know how much data exists, offer numbered pages for direct jumps, and expose
 * page size where result sets vary wildly in size.
 *
 * API: { page, perPage, total, onPageChange } (unchanged)
 * Additions: onPerPageChange, perPageOptions, className
 */
function pageWindow(page, totalPages) {
  const span = 5;
  if (totalPages <= span + 2) return Array.from({ length: totalPages }, (_, i) => i + 1);
  const pages = new Set([1, totalPages, page]);
  for (let d = 1; d <= 1; d += 1) {
    if (page - d > 1) pages.add(page - d);
    if (page + d < totalPages) pages.add(page + d);
  }
  const sorted = [...pages].sort((a, b) => a - b);
  const out = [];
  sorted.forEach((p, i) => {
    if (i > 0 && p - sorted[i - 1] > 1) out.push('…');
    out.push(p);
  });
  return out;
}

export function Pagination({
  page = 1,
  perPage = 10,
  total = 0,
  onPageChange,
  onPerPageChange,
  perPageOptions = [10, 25, 50, 100],
  className,
}) {
  const totalPages = Math.max(1, Math.ceil(total / perPage));
  if (totalPages <= 1 && !onPerPageChange) return null;

  const from = total === 0 ? 0 : (page - 1) * perPage + 1;
  const to = Math.min(page * perPage, total);
  const pages = pageWindow(page, totalPages);

  return (
    <nav
      aria-label="Pagination"
      className={classNames(
        'flex flex-col gap-3 pt-4 sm:flex-row sm:items-center sm:justify-between',
        className
      )}
    >
      <div className="flex items-center gap-3 text-xs text-slate-500">
        <span className="tabular">
          <span className="font-medium text-ink-800">{from.toLocaleString()}</span>–
          <span className="font-medium text-ink-800">{to.toLocaleString()}</span> of{' '}
          <span className="font-medium text-ink-800">{total.toLocaleString()}</span>
        </span>
        {onPerPageChange && (
          <label className="flex items-center gap-1.5">
            <span className="hidden sm:inline">Rows</span>
            <select
              value={perPage}
              onChange={(e) => onPerPageChange(Number(e.target.value))}
              className="h-7 rounded-md border border-slate-300 bg-white px-1.5 text-xs text-ink-800 transition hover:border-slate-400 focus:border-brand-500 focus:outline-none focus:ring-4 focus:ring-brand-500/10"
            >
              {perPageOptions.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </label>
        )}
      </div>

      <div className="flex items-center gap-1">
        <button
          type="button"
          disabled={page <= 1}
          onClick={() => onPageChange?.(page - 1)}
          className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 text-xs font-medium text-ink-700 transition-colors hover:bg-slate-50 disabled:pointer-events-none disabled:opacity-40"
        >
          <ChevronLeft className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Prev</span>
        </button>

        <div className="hidden items-center gap-1 sm:flex">
          {pages.map((p, i) =>
            p === '…' ? (
              <span key={`gap-${i}`} className="px-1 text-xs text-slate-400">
                …
              </span>
            ) : (
              <button
                key={p}
                type="button"
                onClick={() => onPageChange?.(p)}
                aria-current={p === page ? 'page' : undefined}
                className={classNames(
                  'h-8 min-w-[2rem] rounded-lg px-2 text-xs font-medium tabular transition-colors',
                  p === page
                    ? 'bg-brand-600 text-white'
                    : 'border border-transparent text-slate-600 hover:bg-slate-100 hover:text-ink-800'
                )}
              >
                {p}
              </button>
            )
          )}
        </div>

        <span className="text-xs text-slate-500 sm:hidden tabular">
          {page} / {totalPages}
        </span>

        <button
          type="button"
          disabled={page >= totalPages}
          onClick={() => onPageChange?.(page + 1)}
          className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 text-xs font-medium text-ink-700 transition-colors hover:bg-slate-50 disabled:pointer-events-none disabled:opacity-40"
        >
          <span className="hidden sm:inline">Next</span>
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </nav>
  );
}
