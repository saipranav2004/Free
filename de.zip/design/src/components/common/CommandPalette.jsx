/**
 * CommandPalette — ⌘K / Ctrl-K search across the whole console.
 *
 * Why this exists: identity admins navigate by *object name*, not by menu path.
 * Every serious enterprise console (Entra, Okta, GCP) puts a global resolver one
 * keystroke away so "find the user, open their access" is two actions instead of
 * six. This reads the same list endpoints the pages already call — no new API —
 * and only fetches on first open, so it costs nothing until it is used.
 *
 * Keyboard: ⌘K / Ctrl-K opens · ↑ ↓ move · ↵ open · Esc close.
 * Anything can open it programmatically:  window.dispatchEvent(new Event('iam:command-palette'))
 */
import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search, Users, ShieldCheck, UsersRound, FileLock2, LayoutDashboard, Activity,
  Boxes, UserCog, CornerDownLeft, Loader2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { classNames } from '../../utils/format.js';

const NAV_COMMANDS = [
  { id: 'nav-dash', group: 'Go to', label: 'Dashboard', icon: LayoutDashboard, to: '/' },
  { id: 'nav-users', group: 'Go to', label: 'Users', icon: Users, to: '/identity/users' },
  { id: 'nav-groups', group: 'Go to', label: 'Groups (RBAC)', icon: UsersRound, to: '/rbac/groups' },
  { id: 'nav-roles', group: 'Go to', label: 'Roles (RBAC)', icon: ShieldCheck, to: '/rbac/roles' },
  { id: 'nav-policies', group: 'Go to', label: 'Policies (PBAC)', icon: FileLock2, to: '/pbac/policies' },
  { id: 'nav-delegations', group: 'Go to', label: 'Delegations', icon: UserCog, to: '/identity/delegations' },
  { id: 'nav-resources', group: 'Go to', label: 'Resources', icon: Boxes, to: '/identity/resources' },
  { id: 'nav-pam', group: 'Go to', label: 'PAM — audit logs & alerts', icon: Activity, to: '/pam' },
  { id: 'nav-sessions', group: 'Go to', label: 'Active sessions', icon: Activity, to: '/security/sessions' },
];

const GROUP_ORDER = ['Go to', 'Users', 'Roles', 'Groups', 'Policies'];

export function CommandPalette() {
  const navigate = useNavigate();
  const { accountId, isAuthenticated } = useAuth();

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [highlight, setHighlight] = useState(0);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [entities, setEntities] = useState({ users: [], roles: [], groups: [], policies: [] });

  const inputRef = useRef(null);
  const listRef = useRef(null);

  /* ── Open / close ── */
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    const onEvent = () => setOpen(true);
    document.addEventListener('keydown', onKey);
    window.addEventListener('iam:command-palette', onEvent);
    return () => {
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('iam:command-palette', onEvent);
    };
  }, []);

  useEffect(() => {
    if (!open) {
      setQuery('');
      setHighlight(0);
      return undefined;
    }
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const t = window.setTimeout(() => inputRef.current?.focus(), 30);
    return () => {
      document.body.style.overflow = prev;
      window.clearTimeout(t);
    };
  }, [open]);

  /* ── Lazy load the searchable inventory once ── */
  useEffect(() => {
    if (!open || loaded || loading || !isAuthenticated) return;
    setLoading(true);
    Promise.allSettled([
      accountId
        ? identityApi.listUsers({ account_id: accountId, per_page: 200 })
        : Promise.resolve({ users: [] }),
      rbacApi.listRoles(),
      rbacApi.listGroups(),
      pbacApi.listPolicies(),
    ])
      .then(([u, r, g, p]) => {
        const val = (res, pick) => {
          if (res.status !== 'fulfilled') return [];
          const d = res.value;
          const list = Array.isArray(d) ? d : d?.[pick] || [];
          return Array.isArray(list) ? list : [];
        };
        setEntities({
          users: val(u, 'users'),
          roles: val(r, 'roles'),
          groups: val(g, 'groups'),
          policies: val(p, 'policies'),
        });
        setLoaded(true);
      })
      .finally(() => setLoading(false));
  }, [open, loaded, loading, accountId, isAuthenticated]);

  /* ── Result set ── */
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const match = (text) => !q || String(text || '').toLowerCase().includes(q);
    const out = [];

    NAV_COMMANDS.filter((c) => match(c.label)).forEach((c) => out.push(c));

    const cap = q ? 6 : 3;
    entities.users
      .filter((u) => match(u.username) || match(u.email))
      .slice(0, cap)
      .forEach((u) =>
        out.push({
          id: `user-${u.user_id}`,
          group: 'Users',
          label: u.username || u.email,
          hint: u.email,
          badge: u.status && u.status !== 'ACTIVE' ? u.status : undefined,
          icon: Users,
          to: `/identity/users/${u.user_id}`,
        })
      );
    entities.roles
      .filter((r) => match(r.role_name) || match(r.description))
      .slice(0, cap)
      .forEach((r) =>
        out.push({
          id: `role-${r.role_id}`,
          group: 'Roles',
          label: r.role_name,
          hint: r.description,
          icon: ShieldCheck,
          to: `/rbac/roles/${r.role_id}`,
        })
      );
    entities.groups
      .filter((g) => match(g.group_name) || match(g.description))
      .slice(0, cap)
      .forEach((g) =>
        out.push({
          id: `group-${g.group_id}`,
          group: 'Groups',
          label: g.group_name,
          hint: g.description,
          icon: UsersRound,
          to: `/rbac/groups/${g.group_id}`,
        })
      );
    entities.policies
      .filter((p) => match(p.policy_name) || match(p.description))
      .slice(0, cap)
      .forEach((p) =>
        out.push({
          id: `policy-${p.policy_id}`,
          group: 'Policies',
          label: p.policy_name,
          hint: p.description,
          icon: FileLock2,
          to: `/pbac/policies/${p.policy_id}`,
        })
      );

    return out.sort((a, b) => GROUP_ORDER.indexOf(a.group) - GROUP_ORDER.indexOf(b.group));
  }, [query, entities]);

  useEffect(() => setHighlight(0), [query]);

  useEffect(() => {
    if (!listRef.current) return;
    const el = listRef.current.querySelector(`[data-idx="${highlight}"]`);
    if (!el) return;
    const box = listRef.current;
    if (el.offsetTop < box.scrollTop) box.scrollTop = el.offsetTop;
    else if (el.offsetTop + el.offsetHeight > box.scrollTop + box.clientHeight) {
      box.scrollTop = el.offsetTop + el.offsetHeight - box.clientHeight;
    }
  }, [highlight]);

  const run = useCallback(
    (item) => {
      if (!item) return;
      setOpen(false);
      navigate(item.to);
    },
    [navigate]
  );

  const onKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlight((h) => (h < results.length - 1 ? h + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlight((h) => (h > 0 ? h - 1 : results.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      run(results[highlight]);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setOpen(false);
    }
  };

  if (!open || !isAuthenticated) return null;

  let lastGroup = null;

  return (
    <div
      className="fixed inset-0 z-[60] bg-ink-900/40 p-4 backdrop-blur-[2px] animate-fade-in"
      onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        className="mx-auto mt-[8vh] w-full max-w-xl overflow-hidden rounded-2xl border border-line bg-white shadow-overlay animate-dialog-in"
      >
        <div className="flex items-center gap-2.5 border-b border-line-soft px-4">
          <Search className="h-4 w-4 shrink-0 text-slate-400" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Search users, roles, groups, policies…"
            className="h-12 w-full border-0 bg-transparent text-[14px] text-ink-900 outline-none placeholder:text-slate-400"
            aria-label="Search the console"
          />
          {loading && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-slate-400" />}
          <kbd className="hidden shrink-0 rounded border border-line bg-slate-50 px-1.5 py-0.5 text-3xs font-medium text-slate-500 sm:block">
            ESC
          </kbd>
        </div>

        <div ref={listRef} className="max-h-[54vh] overflow-y-auto p-1.5">
          {results.length === 0 ? (
            <p className="px-3 py-10 text-center text-[13px] text-slate-400">
              {loading ? 'Loading directory…' : `Nothing matches “${query}”.`}
            </p>
          ) : (
            results.map((item, idx) => {
              const Icon = item.icon;
              const showGroup = item.group !== lastGroup;
              lastGroup = item.group;
              return (
                <div key={item.id}>
                  {showGroup && (
                    <p className="px-2.5 pb-1 pt-2.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                      {item.group}
                    </p>
                  )}
                  <div
                    data-idx={idx}
                    role="button"
                    tabIndex={-1}
                    onMouseEnter={() => setHighlight(idx)}
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => run(item)}
                    className={classNames(
                      'flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 transition-colors',
                      idx === highlight ? 'bg-slate-100' : 'hover:bg-slate-50'
                    )}
                  >
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-100 text-slate-500">
                      {Icon && <Icon className="h-3.5 w-3.5" />}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-medium text-ink-900">{item.label}</span>
                      {item.hint && (
                        <span className="block truncate text-2xs text-slate-500">{item.hint}</span>
                      )}
                    </span>
                    {item.badge && (
                      <span className="shrink-0 rounded-md bg-slate-100 px-1.5 py-0.5 text-3xs font-medium text-slate-600">
                        {item.badge}
                      </span>
                    )}
                    {idx === highlight && <CornerDownLeft className="h-3.5 w-3.5 shrink-0 text-slate-400" />}
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="flex items-center justify-between border-t border-line-soft bg-slate-50/70 px-4 py-2 text-3xs text-slate-500">
          <span>↑↓ navigate · ↵ open · esc close</span>
          <span>{results.length} result{results.length === 1 ? '' : 's'}</span>
        </div>
      </div>
    </div>
  );
}
