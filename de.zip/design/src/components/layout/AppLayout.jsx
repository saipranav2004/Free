import { useState, useCallback, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from './Sidebar.jsx';
import { Topbar } from './Topbar.jsx';
import { CommandPalette } from '../common/CommandPalette.jsx';
import { classNames } from '../../utils/format.js';

/**
 * AppLayout — the console shell.
 *
 * ┌──────────────────────────────────────────────────────────────┐
 * │ Topbar — fixed, full width, 56px                             │
 * ├────────────┬─────────────────────────────────────────────────┤
 * │ Sidebar    │ Working area (scrolls with the document)        │
 * │ 256 / 64px │ max 1440px, gutters 16/24/32px                  │
 * └────────────┴─────────────────────────────────────────────────┘
 *
 * The topbar is `fixed` (not sticky) so it never participates in layout, and
 * the main region compensates with top padding. The sidebar is fixed below it;
 * `main` carries left padding — padding, not margin, so nothing can collide
 * with a centring `mx-auto` on the inner container (the previous version mixed
 * `mx-auto` with `lg:ml-64`, two rules fighting over the same property).
 */
export function AppLayout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const location = useLocation();

  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem('iam-sidebar-collapsed') === 'true';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('iam-sidebar-collapsed', String(collapsed));
    } catch {
      /* storage unavailable — preference stays session-local */
    }
  }, [collapsed]);

  // Close the mobile drawer on navigation and lock scroll while it is open.
  useEffect(() => {
    setMobileNavOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!mobileNavOpen) return undefined;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e) => e.key === 'Escape' && setMobileNavOpen(false);
    document.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener('keydown', onKey);
    };
  }, [mobileNavOpen]);

  const toggleCollapse = useCallback(() => setCollapsed((c) => !c), []);

  return (
    <div className="min-h-screen bg-canvas">
      <Topbar onMenu={() => setMobileNavOpen(true)} />

      {/* Global ⌘K resolver — mounted once, costs nothing until opened. */}
      <CommandPalette />

      <Sidebar
        open={mobileNavOpen}
        onClose={() => setMobileNavOpen(false)}
        collapsed={collapsed}
        onToggleCollapse={toggleCollapse}
      />

      <main
        id="main"
        className={classNames(
          'pt-14 transition-[padding] duration-200 ease-out',
          collapsed ? 'lg:pl-16' : 'lg:pl-64'
        )}
      >
        <div className="mx-auto w-full max-w-[1440px] px-4 py-5 sm:px-6 lg:px-8 lg:py-7">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
