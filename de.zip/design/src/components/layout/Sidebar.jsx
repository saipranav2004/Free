import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  UserCog,
  UsersRound,
  ShieldCheck,
  FileLock2,
  Boxes,
  Cloud,
  Database,
  PanelLeftClose,
  PanelLeftOpen,
  Activity,
  Network,
  X,
} from 'lucide-react';
import { classNames } from '../../utils/format.js';
import { M365_SERVICES } from '../../pages/integrations/m365/registry.js';
import { Logo } from '../common/Logo.jsx';

/**
 * Sidebar — the persistent working navigation.
 *
 * Enterprise console conventions applied:
 *  · Sections are labelled by domain (Identity, Access Control, Integrations)
 *    so the mental model matches the product's information architecture
 *  · Active item: tinted row + 3px leading accent — visible at a glance
 *    without shouting, and it survives collapse to the icon rail
 *  · Collapsible 64px rail with hover tooltips for screen-constrained work
 *  · A contextual section appears for the active product (IDP / PAM) so the
 *    rail never highlights nothing when those tabs are open
 *  · On mobile it is a real drawer: header, close affordance, scrim
 *
 * Route set is deliberately unchanged — this is a visual/UX pass, not an IA
 * change, and hidden routes (Admin Bootstrap et al.) stay hidden.
 */

const IAM_NAV = [
  {
    section: 'Overview',
    items: [{ to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true }],
  },
  {
    section: 'Identity',
    items: [
      { to: '/identity/users', label: 'Users', icon: Users },
      { to: '/identity/delegations', label: 'Delegations', icon: UserCog },
      { to: '/identity/resources', label: 'Resources', icon: Boxes },
    ],
  },
  {
    section: 'Access Control',
    items: [
      { to: '/rbac/groups', label: 'Groups (RBAC)', icon: UsersRound },
      { to: '/rbac/roles', label: 'Roles (RBAC)', icon: ShieldCheck },
      { to: '/pbac/policies', label: 'Policies (PBAC)', icon: FileLock2 },
    ],
  },
  {
    section: 'Microsoft 365',
    items: [
      { to: '/integrations/m365', label: 'M365 Overview', icon: Cloud, end: true },
      ...M365_SERVICES.map((s) => ({
        to: `/integrations/m365/${s.id}`,
        label: s.name,
        icon: s.icon,
      })),
    ],
  },
  {
    section: 'Oracle',
    items: [{ to: '/integrations/oracle', label: 'Oracle DB', icon: Database }],
  },
];

const IDP_SECTION = {
  section: 'Identity Provider',
  items: [
    { to: '/idp/overview', label: 'Federation Overview', icon: Network },
    { to: '/idp/tenants', label: 'Tenants', icon: Boxes },
  ],
};

const PAM_SECTION = {
  section: 'Privileged Access',
  items: [{ to: '/pam', label: 'Monitoring & Alerts', icon: Activity, end: true }],
};

function NavItem({ item, collapsed, onNavigate }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.to}
      end={item.end}
      onClick={onNavigate}
      className={({ isActive }) =>
        classNames(
          'group/nav relative flex items-center rounded-lg text-[13px] font-medium transition-colors duration-100',
          collapsed ? 'justify-center px-2 py-2.5' : 'gap-2.5 px-3 py-2',
          isActive
            ? 'bg-brand-50 text-brand-800'
            : 'text-slate-600 hover:bg-slate-100/80 hover:text-ink-900'
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive && (
            <span className="absolute inset-y-1.5 left-0 w-[3px] rounded-r-full bg-brand-600" />
          )}
          {Icon && (
            <Icon
              className={classNames(
                'h-4 w-4 shrink-0',
                isActive ? 'text-brand-700' : 'text-slate-400 group-hover/nav:text-slate-600'
              )}
            />
          )}
          {!collapsed && <span className="truncate">{item.label}</span>}
          {collapsed && (
            <span className="pointer-events-none absolute left-full z-50 ml-2 hidden whitespace-nowrap rounded-lg bg-ink-900 px-2.5 py-1.5 text-2xs font-medium text-white shadow-popover group-hover/nav:block">
              {item.label}
            </span>
          )}
        </>
      )}
    </NavLink>
  );
}

export function Sidebar({ open, onClose, collapsed, onToggleCollapse }) {
  const { pathname } = useLocation();

  const groups = [
    ...(pathname.startsWith('/idp') ? [IDP_SECTION] : []),
    ...(pathname.startsWith('/pam') || pathname === '/audit-logs' ? [PAM_SECTION] : []),
    ...IAM_NAV,
  ];

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-40 bg-ink-900/40 backdrop-blur-[2px] animate-fade-in lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        aria-label="Main navigation"
        className={classNames(
          'fixed left-0 z-40 flex flex-col border-r border-line bg-white transition-[width,transform] duration-200 ease-out',
          'top-0 bottom-0 w-[17rem] lg:top-14 lg:w-64',
          collapsed && 'lg:w-16',
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Drawer header — mobile only (desktop keeps the logo in the topbar) */}
        <div className="flex h-14 shrink-0 items-center justify-between border-b border-line px-4 lg:hidden">
          <Logo variant="appbar" />
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
            aria-label="Close navigation"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>

        <nav className="flex-1 space-y-5 overflow-y-auto overflow-x-hidden px-2.5 py-4">
          {groups.map((group, gi) => (
            <div key={group.section}>
              {!collapsed ? (
                <p className="px-3 pb-1.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                  {group.section}
                </p>
              ) : (
                gi > 0 && <div className="mx-2 mb-2 border-t border-line-soft" />
              )}
              <div className="space-y-0.5">
                {group.items.map((item) => (
                  <NavItem key={item.to} item={item} collapsed={collapsed} onNavigate={onClose} />
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div
          className={classNames(
            'flex shrink-0 items-center border-t border-line px-2.5 py-2.5',
            collapsed ? 'justify-center' : 'justify-between'
          )}
        >
          {!collapsed && (
            <span className="pl-1 text-3xs font-semibold uppercase tracking-[0.12em] text-slate-400">
              IAM Control Center
            </span>
          )}
          <button
            type="button"
            onClick={onToggleCollapse}
            className="hidden h-7 w-7 shrink-0 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700 lg:flex"
            aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}
            title={collapsed ? 'Expand navigation' : 'Collapse navigation'}
          >
            {collapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </button>
        </div>
      </aside>
    </>
  );
}
