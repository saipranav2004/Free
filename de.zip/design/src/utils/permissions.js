// Front-end permission helpers. These ONLY control UI visibility — the
// backend (OPA + @require_permission / @require_admin) is the real authority.

export function isAdmin(user) {
  if (!user) return false;
  if (Array.isArray(user.roles) && user.roles.includes('admin')) return true;
  if (Array.isArray(user.account_type) && user.account_type.includes('admin'))
    return true;
  if (user.account_type === 'admin') return true;
  return false;
}

export function hasRole(user, role) {
  if (!user) return false;
  const roles = user.roles || [];
  return roles.includes(role);
}

// Root / super-admin check. This ONLY controls UI visibility — the backend
// (`is_root_user` in integrations/oracle_db/config.py) is the real authority.
// The root admin is identified by IAM user id; the seeded id is
// b41250cc-84ae-4f19-adcf-c0bc32ebc91b.
export function isRoot(user) {
  if (!user) return false;
  const id = (user.id || user.sub || user.user_id || '').toString().toLowerCase();
  return id === 'b41250cc-84ae-4f19-adcf-c0bc32ebc91b';
}

// Simple capability gate used by RequirePermission route wrapper.
export function can(user, permission) {
  if (!user) return false;
  if (isAdmin(user)) return true;
  // Delegated permissions (populated by identity middleware) take over for
  // non-admin human users.
  const delegations = user.delegations || [];
  return delegations.some((d) =>
    Array.isArray(d.permissions) ? d.permissions.includes(permission) : false
  );
}
