import { useCallback, useEffect, useState } from 'react';

/**
 * Minimal async-data hook for GET-style fetches.
 * Returns { data, loading, error, reload }.
 * `fetcher` should be a function returning a promise (already unwrapped by the
 * api client). `deps` controls re-fetching.
 */
export function useResource(fetcher, deps = []) {
  const [state, setState] = useState({ loading: true, data: null, error: null });

  const load = useCallback(() => {
    let cancelled = false;
    setState((s) => ({ ...s, loading: true, error: null }));
    Promise.resolve()
      .then(fetcher)
      .then((data) => {
        if (!cancelled) setState({ loading: false, data, error: null });
      })
      .catch((err) => {
        if (!cancelled)
          setState({
            loading: false,
            data: null,
            error: err?.userMessage || err?.message || 'Failed to load.',
          });
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => load(), [load]);

  return { ...state, reload: load };
}
