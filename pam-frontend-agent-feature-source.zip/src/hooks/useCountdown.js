import { useEffect, useState } from 'react'

// Ticks once a second while `targetIso` is in the future. Used for grant
// expiry countdowns and the break-glass cooling-off timer.
//
// Bugs this specifically guards against:
//  - Leaked interval: without the cleanup return from useEffect, every
//    remount (e.g. navigating away and back to a grant detail page) would
//    stack another setInterval on top of the previous one, each still
//    firing — a classic memory leak that also makes the countdown
//    increasingly janky the more times a page is revisited.
//  - Stale target: if `targetIso` changes (e.g. polling refetches the grant
//    and its expires_at moved because a revoke happened), the effect
//    dependency array includes it, so a new interval is set up against the
//    new value rather than continuing to count down the stale one.
//  - Runs forever after expiry: once remaining <= 0, the interval clears
//    itself rather than continuing to tick uselessly.
export function useCountdown(targetIso) {
  const [remainingMs, setRemainingMs] = useState(() => computeRemaining(targetIso))

  useEffect(() => {
    setRemainingMs(computeRemaining(targetIso))
    if (!targetIso) return undefined

    const interval = setInterval(() => {
      const next = computeRemaining(targetIso)
      setRemainingMs(next)
      if (next <= 0) clearInterval(interval)
    }, 1000)

    return () => clearInterval(interval)
  }, [targetIso])

  return remainingMs
}

function computeRemaining(targetIso) {
  if (!targetIso) return 0
  const target = new Date(targetIso).getTime()
  if (Number.isNaN(target)) return 0
  return target - Date.now()
}
