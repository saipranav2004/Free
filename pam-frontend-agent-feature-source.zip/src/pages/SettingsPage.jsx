import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { me } from '../api/auth'
import { PageHeader, Card } from '../components/common/Layout'
import { QueryState } from '../components/common/QueryState'
import { MfaEnrollment } from '../components/auth/MfaEnrollment'
import { Badge } from '../components/common/Badge'
import { AgentDevicesPanel } from '../components/agent/AgentDevicesPanel'

export default function SettingsPage() {
  const queryClient = useQueryClient()
  const [justEnrolled, setJustEnrolled] = useState(false)
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal) })

  return (
    <div>
      <PageHeader title="Settings" description="Your account and security settings." />

      <div className="space-y-6">
        <Card className="p-5">
          <h3 className="mb-3 text-sm font-semibold text-ink-50">Account</h3>
          <QueryState query={meQuery}>
            {(data) => (
              <dl className="grid grid-cols-[120px_1fr] gap-y-2 text-sm">
                <dt className="text-ink-500">Username</dt>
                <dd className="text-ink-100">{data.username}</dd>
                <dt className="text-ink-500">Email</dt>
                <dd className="text-ink-100">{data.email}</dd>
                <dt className="text-ink-500">MFA</dt>
                <dd>
                  {data.mfa_verified ? (
                    <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30">
                      Verified this session
                    </Badge>
                  ) : (
                    <Badge className="bg-ink-500/15 text-ink-400 ring-ink-500/30">
                      Not verified this session
                    </Badge>
                  )}
                </dd>
                <dt className="text-ink-500">Roles</dt>
                <dd className="text-ink-100">{(data.roles || []).join(', ') || '—'}</dd>
              </dl>
            )}
          </QueryState>
        </Card>

        {justEnrolled ? (
          <Card className="p-5">
            <p className="text-sm text-emerald-700 dark:text-emerald-300">
              Two-factor authentication is now active on your account.
            </p>
          </Card>
        ) : (
          <MfaEnrollment
            onEnrolled={() => {
              setJustEnrolled(true)
              queryClient.invalidateQueries({ queryKey: ['me'] })
              toast.success('MFA enabled')
            }}
          />
        )}

        <AgentDevicesPanel />
      </div>
    </div>
  )
}
