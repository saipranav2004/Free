import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams, Link } from 'react-router-dom'
import { toast } from 'sonner'
import { ArrowLeft, ShieldAlert, Clock } from 'lucide-react'
import { getJitRequest, cancelJitRequest } from '../../api/jit'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { useCountdown } from '../../hooks/useCountdown'
import { formatDateTime, formatDuration } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import { JIT_STATUS, JIT_STATUS_LABELS, JIT_STATUS_BADGE, GRANT_STATUS_BADGE } from '../../config/constants'

const CANCELLABLE_STATUSES = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

// The exact field the backend nests a resulting grant under (if any) isn't
// pinned down by the API contract we have — this checks the couple of
// shapes that would make sense (`grant`, plural `grants[0]`) and otherwise
// falls back to whatever expiry-looking field lives directly on the
// request itself, so the countdown still works even if the nesting name is
// different from what's guessed here.
function extractGrant(request) {
  if (!request) return null
  if (request.grant) return request.grant
  if (Array.isArray(request.grants) && request.grants.length > 0) return request.grants[0]
  return null
}

function Countdown({ targetIso }) {
  const remainingMs = useCountdown(targetIso)
  if (!targetIso) return <>—</>
  if (remainingMs <= 0) return <span className="text-ink-500">Expired</span>
  return (
    <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
      <Clock className="h-3.5 w-3.5" /> {formatDuration(remainingMs / 1000)} remaining
    </span>
  )
}

export default function JitRequestDetailPage() {
  const { id } = useParams()
  const queryClient = useQueryClient()
  const [cancelOpen, setCancelOpen] = useState(false)

  const requestQuery = useQuery({
    queryKey: ['jit', 'requests', id],
    queryFn: ({ signal }) => getJitRequest(id, signal),
  })

  const cancelMutation = useMutation({
    mutationFn: (reason) => cancelJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request cancelled')
      setCancelOpen(false)
      queryClient.invalidateQueries({ queryKey: ['jit'] })
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setCancelOpen(false)
    },
  })

  return (
    <div>
      <Link to="/jit" className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 hover:text-ink-200">
        <ArrowLeft className="h-3.5 w-3.5" /> Back to JIT
      </Link>

      <QueryState query={requestQuery}>
        {(request) => {
          const grant = extractGrant(request)
          const isBreakglass = request?.type === 'BREAKGLASS'
          const expiryIso = grant?.expires_at || request?.expires_at || null
          const canCancel = CANCELLABLE_STATUSES.includes(request?.status)

          return (
            <>
              <PageHeader
                title={
                  <span className="flex items-center gap-2">
                    {isBreakglass && <ShieldAlert className="h-5 w-5 text-red-600 dark:text-red-400" />}
                    {request?.resource_name || request?.resource_id || 'JIT request'}
                  </span>
                }
                description={isBreakglass ? 'Break-glass emergency access request' : 'Time-boxed access request'}
                actions={
                  canCancel && (
                    <button
                      onClick={() => setCancelOpen(true)}
                      className="flex items-center gap-1.5 rounded-md border border-red-300 dark:border-red-900/50 px-3 py-1.5 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30"
                    >
                      Cancel request
                    </button>
                  )
                }
              />

              <div className="grid gap-6 lg:grid-cols-2">
                <Card className={isBreakglass ? 'border-red-300 dark:border-red-900/40' : ''}>
                  <CardHeader>
                    <h3 className="text-sm font-semibold text-ink-50">Request details</h3>
                  </CardHeader>
                  <div className="p-4">
                    <dl className="grid grid-cols-[140px_1fr] gap-y-2 text-sm">
                      <dt className="text-ink-500">Status</dt>
                      <dd>
                        <Badge className={JIT_STATUS_BADGE[request?.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                          {JIT_STATUS_LABELS[request?.status] || request?.status || '—'}
                        </Badge>
                      </dd>
                      <dt className="text-ink-500">Type</dt>
                      <dd>
                        {isBreakglass ? (
                          <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400">
                            <ShieldAlert className="h-3.5 w-3.5" /> Break-glass
                          </span>
                        ) : (
                          <span className="text-ink-100">Standard</span>
                        )}
                      </dd>
                      <dt className="text-ink-500">Resource</dt>
                      <dd className="text-ink-100">{request?.resource_name || request?.resource_id || '—'}</dd>
                      <dt className="text-ink-500">Action</dt>
                      <dd className="text-ink-100">{request?.action || '—'}</dd>
                      <dt className="text-ink-500">Duration</dt>
                      <dd className="text-ink-100">
                        {request?.duration_minutes ? `${request.duration_minutes} minutes` : '—'}
                      </dd>
                      <dt className="text-ink-500">Reason</dt>
                      <dd className="text-ink-100">{request?.reason || '—'}</dd>
                      <dt className="text-ink-500">Ticket ref</dt>
                      <dd className="text-ink-100">{request?.ticket_ref || '—'}</dd>
                      <dt className="text-ink-500">Requested</dt>
                      <dd className="text-ink-100">{formatDateTime(request?.created_at)}</dd>
                      {request?.approved_at && (
                        <>
                          <dt className="text-ink-500">Approved</dt>
                          <dd className="text-ink-100">{formatDateTime(request.approved_at)}</dd>
                        </>
                      )}
                      {request?.denied_at && (
                        <>
                          <dt className="text-ink-500">Denied</dt>
                          <dd className="text-ink-100">{formatDateTime(request.denied_at)}</dd>
                        </>
                      )}
                    </dl>
                  </div>
                </Card>

                <Card>
                  <CardHeader>
                    <h3 className="text-sm font-semibold text-ink-50">Resulting grant</h3>
                  </CardHeader>
                  <div className="p-4">
                    {grant ? (
                      <dl className="grid grid-cols-[140px_1fr] gap-y-2 text-sm">
                        <dt className="text-ink-500">Status</dt>
                        <dd>
                          <Badge className={GRANT_STATUS_BADGE[grant.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                            {grant.status || '—'}
                          </Badge>
                        </dd>
                        <dt className="text-ink-500">Expires</dt>
                        <dd className="text-ink-100">{formatDateTime(grant.expires_at)}</dd>
                        <dt className="text-ink-500">Time left</dt>
                        <dd>
                          <Countdown targetIso={grant.expires_at} />
                        </dd>
                      </dl>
                    ) : expiryIso ? (
                      <dl className="grid grid-cols-[140px_1fr] gap-y-2 text-sm">
                        <dt className="text-ink-500">Expires</dt>
                        <dd className="text-ink-100">{formatDateTime(expiryIso)}</dd>
                        <dt className="text-ink-500">Time left</dt>
                        <dd>
                          <Countdown targetIso={expiryIso} />
                        </dd>
                      </dl>
                    ) : (
                      <p className="text-sm text-ink-500">
                        No grant information is available for this request yet — check the Grants tab on the JIT
                        hub once this request is approved.
                      </p>
                    )}
                  </div>
                </Card>
              </div>

              <ConfirmDialog
                open={cancelOpen}
                title="Cancel this request?"
                description="This withdraws the request. You can submit a new one later if you still need access."
                confirmLabel="Cancel request"
                destructive
                requireReason
                reasonLabel="Reason (required for the audit record)"
                isLoading={cancelMutation.isPending}
                onConfirm={(reason) => cancelMutation.mutate(reason)}
                onCancel={() => setCancelOpen(false)}
              />
            </>
          )
        }}
      </QueryState>
    </div>
  )
}
