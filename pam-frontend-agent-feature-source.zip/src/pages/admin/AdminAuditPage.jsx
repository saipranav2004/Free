import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ScrollText, Video, ShieldCheck, ShieldAlert } from 'lucide-react'
import { listAudit, listRecordings, verifyAudit } from '../../api/admin'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { TabBar } from '../../components/common/TabBar'
import { Spinner } from '../../components/common/Spinner'
import { formatDateTime, formatDuration } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  AUDIT_CATEGORIES, AUDIT_OUTCOMES, AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE,
  RECORDING_STATUS_BADGE, DEFAULT_PAGE_SIZE,
} from '../../config/constants'

const TABS = [
  { key: 'events', label: 'Events', icon: ScrollText },
  { key: 'recordings', label: 'Recordings', icon: Video },
  { key: 'chain', label: 'Chain Verification', icon: ShieldCheck },
]

const selectClass =
  'rounded-md border border-surface-700 bg-surface-800 px-2.5 py-1.5 text-sm text-ink-100 focus:border-blue-500 focus:outline-none'

// Same defensive lookups as the self-service AuditPage — the exact field
// names for actor/target on an org-wide event aren't pinned down anywhere
// we've been given.
function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}
function actorLabel(item) {
  return (
    item?.actor_username ||
    item?.username ||
    item?.actor?.username ||
    item?.user_email ||
    item?.actor_id ||
    item?.user_id ||
    '—'
  )
}
function targetLabel(item) {
  return item?.resource_name || item?.resource || item?.target || item?.resource_id || '—'
}

function EventsTab() {
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [page, setPage] = useState(1)

  const changeCategory = (next) => {
    setCategory(next)
    setPage(1)
  }
  const changeOutcome = (next) => {
    setOutcome(next)
    setPage(1)
  }

  const eventsQuery = useQuery({
    queryKey: ['admin', 'audit', 'events', { page, category, outcome }],
    queryFn: ({ signal }) =>
      listAudit(
        { page, page_size: DEFAULT_PAGE_SIZE, category: category || undefined, outcome: outcome || undefined },
        signal
      ),
    placeholderData: (prev) => prev,
  })

  const pagination = eventsQuery.data?.pagination

  return (
    <>
      <Card className="mb-4">
        <CardHeader className="flex flex-wrap items-center gap-3">
          <select value={category} onChange={(e) => changeCategory(e.target.value)} className={selectClass}>
            <option value="">All categories</option>
            {AUDIT_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select value={outcome} onChange={(e) => changeOutcome(e.target.value)} className={selectClass}>
            <option value="">All outcomes</option>
            {AUDIT_OUTCOMES.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </CardHeader>

        <QueryState
          query={eventsQuery}
          empty={(d) => !d?.events || d.events.length === 0}
          emptyMessage="No audit events found."
        >
          {(data) => (
            <>
              <ul className="divide-y divide-surface-800">
                {data.events.map((item, idx) => (
                  <li key={item?.id ?? idx} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink-100">
                        <span className="text-ink-400">{item?.category || 'OTHER'}</span>
                        <span>{item?.action || '—'}</span>
                        {item?.outcome && (
                          <Badge className={AUDIT_OUTCOME_BADGE[item.outcome] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                            {item.outcome}
                          </Badge>
                        )}
                        {item?.severity && (
                          <Badge className={AUDIT_SEVERITY_BADGE[item.severity] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                            {item.severity}
                          </Badge>
                        )}
                      </p>
                      <p className="mt-1 truncate text-xs text-ink-500">
                        {formatDateTime(itemTimestamp(item))} · actor: {actorLabel(item)} · target: {targetLabel(item)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>
    </>
  )
}

function RecordingsTab() {
  const [page, setPage] = useState(1)

  const recordingsQuery = useQuery({
    queryKey: ['admin', 'recordings', { page }],
    queryFn: ({ signal }) => listRecordings({ page, page_size: DEFAULT_PAGE_SIZE }, signal),
  })

  const pagination = recordingsQuery.data?.pagination

  return (
    <Card>
      <QueryState
        query={recordingsQuery}
        empty={(d) => !d?.recordings || d.recordings.length === 0}
        emptyMessage="No session recordings found."
      >
        {(data) => (
          <>
            <ul className="divide-y divide-surface-800">
              {data.recordings.map((rec, idx) => (
                <li key={rec?.id ?? idx} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink-100">
                      {rec?.resource_name || rec?.resource_id || '—'}
                      {rec?.session_id ? (
                        <span className="ml-2 text-xs font-normal text-ink-500">session {rec.session_id}</span>
                      ) : null}
                    </p>
                    <p className="mt-0.5 truncate text-xs text-ink-500">
                      Started {formatDateTime(rec?.started_at || rec?.created_at)}
                      {rec?.duration_seconds != null ? ` · ${formatDuration(rec.duration_seconds)}` : ''}
                    </p>
                  </div>
                  <Badge className={RECORDING_STATUS_BADGE[rec?.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                    {rec?.status || 'UNKNOWN'}
                  </Badge>
                </li>
              ))}
            </ul>
            {pagination && (
              <Pagination
                page={pagination.page}
                pageSize={pagination.page_size}
                total={pagination.total}
                totalPages={pagination.total_pages}
                onPageChange={setPage}
              />
            )}
          </>
        )}
      </QueryState>
    </Card>
  )
}

// Local to this file only (deliberately not shared with AdminOverviewPage's
// own version) — same defensive field-name probing, since the exact shape
// of verifyAudit()'s payload isn't pinned down anywhere we have access to.
function ChainVerificationBanner({ result }) {
  if (!result) return null
  const knownField =
    'valid' in result ? 'valid'
    : 'chain_valid' in result ? 'chain_valid'
    : 'intact' in result ? 'intact'
    : 'success' in result ? 'success'
    : null
  const isValid = knownField ? Boolean(result[knownField]) : null

  return (
    <div
      className={
        'flex items-start gap-3 rounded-lg border p-4 ' +
        (isValid === false
          ? 'border-red-400 dark:border-red-600/60 bg-red-50 dark:bg-red-950/40'
          : isValid === true
            ? 'border-emerald-300 dark:border-emerald-600/40 bg-emerald-50 dark:bg-emerald-950/20'
            : 'border-surface-800 bg-surface-900')
      }
    >
      {isValid === false && <ShieldAlert className="mt-0.5 h-5 w-5 flex-none text-red-600 dark:text-red-400" />}
      {isValid === true && <ShieldCheck className="mt-0.5 h-5 w-5 flex-none text-emerald-600 dark:text-emerald-400" />}
      <div className="min-w-0">
        {isValid === true && (
          <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">Audit chain intact — no tampering detected.</p>
        )}
        {isValid === false && (
          <p className="text-sm font-semibold text-red-700 dark:text-red-300">
            Audit chain broken — possible tampering detected. Notify a security administrator.
          </p>
        )}
        {isValid === null && (
          <>
            <p className="mb-1 text-sm font-medium text-ink-100">Verification result</p>
            <pre className="max-w-full overflow-x-auto text-xs text-ink-400">{JSON.stringify(result, null, 2)}</pre>
          </>
        )}
      </div>
    </div>
  )
}

function ChainVerificationTab() {
  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <Card>
      <CardHeader className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-medium text-ink-100">Audit chain integrity (org-wide)</h2>
        <button
          onClick={() => verifyMutation.mutate()}
          disabled={verifyMutation.isPending}
          className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500 disabled:opacity-60"
        >
          {verifyMutation.isPending ? <Spinner size="h-3.5 w-3.5" className="text-white" /> : <ShieldCheck className="h-4 w-4" />}
          Run verification
        </button>
      </CardHeader>
      <div className="p-4">
        {verifyMutation.isPending ? (
          <div className="flex items-center gap-2 text-sm text-ink-400">
            <Spinner size="h-4 w-4" /> Verifying…
          </div>
        ) : verifyMutation.isSuccess ? (
          <ChainVerificationBanner result={verifyMutation.data} />
        ) : (
          <p className="text-xs text-ink-500">
            Checks that org-wide audit entries form an unbroken, tamper-evident chain. Not run automatically —
            trigger it explicitly.
          </p>
        )}
      </div>
    </Card>
  )
}

export default function AdminAuditPage() {
  const [tab, setTab] = useState('events')

  return (
    <div>
      <PageHeader
        title="Audit & Compliance"
        description="Org-wide audit trail, session recordings, and tamper-evident chain verification."
      />

      <div className="mb-4">
        <TabBar tabs={TABS} active={tab} onChange={setTab} />
      </div>

      {tab === 'events' && <EventsTab />}
      {tab === 'recordings' && <RecordingsTab />}
      {tab === 'chain' && <ChainVerificationTab />}
    </div>
  )
}
