import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { KeyRound, Lock, ShieldAlert, X } from 'lucide-react'
import {
  listJitRequests, approveJitRequest, denyJitRequest,
  listGrants, revokeGrant,
  listBreakglass, getBreakglassReport,
} from '../../api/admin'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Pagination } from '../../components/common/Pagination'
import { Badge } from '../../components/common/Badge'
import { TabBar } from '../../components/common/TabBar'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Spinner } from '../../components/common/Spinner'
import { formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  JIT_STATUS, JIT_STATUS_LABELS, JIT_STATUS_BADGE,
  GRANT_STATUS, GRANT_STATUS_BADGE,
  DEFAULT_PAGE_SIZE,
} from '../../config/constants'

const TABS = [
  { key: 'requests', label: 'Requests', icon: KeyRound },
  { key: 'grants', label: 'Grants', icon: Lock },
  { key: 'breakglass', label: 'Break-glass', icon: ShieldAlert },
]

const selectClass =
  'rounded-md border border-surface-700 bg-surface-800 px-2.5 py-1.5 text-sm text-ink-100 focus:border-blue-500 focus:outline-none'

// Field names for "who requested this" aren't pinned down on the admin list
// endpoint's payload — probe the plausible candidates rather than assume one.
function requesterLabel(r) {
  return (
    r?.requester_username ||
    r?.username ||
    r?.requested_by ||
    r?.user_username ||
    r?.requester?.username ||
    r?.user_id ||
    '—'
  )
}

const PENDING_LIKE_STATUSES = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

function RequestsTab() {
  const [status, setStatus] = useState('')
  const [page, setPage] = useState(1)
  const [approveTarget, setApproveTarget] = useState(null)
  const [denyTarget, setDenyTarget] = useState(null)
  const queryClient = useQueryClient()

  const changeStatus = (next) => {
    setStatus(next)
    setPage(1)
  }

  const requestsQuery = useQuery({
    queryKey: ['admin', 'jit-requests', { page, status }],
    queryFn: ({ signal }) =>
      listJitRequests({ page, page_size: DEFAULT_PAGE_SIZE, status: status || undefined }, signal),
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'jit-requests'] })

  const approveMutation = useMutation({
    mutationFn: ({ id, reason }) => approveJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request approved')
      setApproveTarget(null)
      invalidate()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setApproveTarget(null)
    },
  })

  const denyMutation = useMutation({
    mutationFn: ({ id, reason }) => denyJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request denied')
      setDenyTarget(null)
      invalidate()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDenyTarget(null)
    },
  })

  const isMutating = approveMutation.isPending || denyMutation.isPending
  const pagination = requestsQuery.data?.pagination

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <select value={status} onChange={(e) => changeStatus(e.target.value)} className={selectClass}>
          <option value="">All statuses</option>
          {Object.values(JIT_STATUS).map((s) => (
            <option key={s} value={s}>
              {JIT_STATUS_LABELS[s] || s}
            </option>
          ))}
        </select>
      </div>

      <Card>
        <QueryState
          query={requestsQuery}
          empty={(d) => !d?.requests || d.requests.length === 0}
          emptyMessage="No JIT requests found."
        >
          {(data) => (
            <>
              <ul className="divide-y divide-surface-800">
                {data.requests.map((r) => (
                  <li key={r.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 truncate text-sm font-medium text-ink-100">
                        {r.resource_name || r.resource_id || '—'}
                        <span className="text-xs font-normal text-ink-500">by {requesterLabel(r)}</span>
                        {r.type === 'BREAKGLASS' && (
                          <span className="inline-flex items-center gap-1 text-xs font-medium text-red-600 dark:text-red-400">
                            <ShieldAlert className="h-3 w-3" /> break-glass
                          </span>
                        )}
                      </p>
                      <p className="mt-0.5 truncate text-xs text-ink-500">
                        Requested {formatDateTime(r.created_at)}
                        {r.reason ? ` · ${r.reason}` : ''}
                      </p>
                    </div>
                    <div className="flex flex-none items-center gap-2">
                      <Badge className={JIT_STATUS_BADGE[r.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                        {JIT_STATUS_LABELS[r.status] || r.status}
                      </Badge>
                      {PENDING_LIKE_STATUSES.includes(r.status) && (
                        <>
                          <button
                            onClick={() => setApproveTarget(r)}
                            disabled={isMutating}
                            className="rounded-md bg-blue-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => setDenyTarget(r)}
                            disabled={isMutating}
                            className="rounded-md border border-red-300 dark:border-red-900/50 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-60"
                          >
                            Deny
                          </button>
                        </>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <ConfirmDialog
        open={!!approveTarget}
        title={`Approve request for "${approveTarget?.resource_name || approveTarget?.resource_id || 'this resource'}"?`}
        description="This grants time-boxed access immediately. Separation-of-duty rules apply — you cannot approve your own request."
        confirmLabel="Approve"
        destructive={false}
        reasonLabel="Reason (optional)"
        isLoading={approveMutation.isPending}
        onConfirm={(reason) => approveMutation.mutate({ id: approveTarget.id, reason })}
        onCancel={() => setApproveTarget(null)}
      />

      <ConfirmDialog
        open={!!denyTarget}
        title={`Deny request for "${denyTarget?.resource_name || denyTarget?.resource_id || 'this resource'}"?`}
        description="This rejects the request. The requester will need to submit a new one if access is still needed."
        confirmLabel="Deny"
        destructive
        requireReason
        reasonLabel="Reason for denial (required for the audit record)"
        isLoading={denyMutation.isPending}
        onConfirm={(reason) => denyMutation.mutate({ id: denyTarget.id, reason })}
        onCancel={() => setDenyTarget(null)}
      />
    </>
  )
}

function GrantsTab() {
  const [status, setStatus] = useState('')
  const [page, setPage] = useState(1)
  const [revokeTarget, setRevokeTarget] = useState(null)
  const queryClient = useQueryClient()

  const changeStatus = (next) => {
    setStatus(next)
    setPage(1)
  }

  const grantsQuery = useQuery({
    queryKey: ['admin', 'grants', { page, status }],
    queryFn: ({ signal }) =>
      listGrants({ page, page_size: DEFAULT_PAGE_SIZE, status: status || undefined }, signal),
  })

  const revokeMutation = useMutation({
    mutationFn: ({ id, reason }) => revokeGrant(id, reason),
    onSuccess: (result) => {
      const killed = result?.sessions_killed
      toast.success(
        typeof killed === 'number'
          ? `Grant revoked — ${killed} session${killed === 1 ? '' : 's'} killed`
          : 'Grant revoked'
      )
      setRevokeTarget(null)
      queryClient.invalidateQueries({ queryKey: ['admin', 'grants'] })
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setRevokeTarget(null)
    },
  })

  const pagination = grantsQuery.data?.pagination

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <select value={status} onChange={(e) => changeStatus(e.target.value)} className={selectClass}>
          <option value="">All statuses</option>
          {Object.values(GRANT_STATUS).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      <Card>
        <QueryState
          query={grantsQuery}
          empty={(d) => !d?.grants || d.grants.length === 0}
          emptyMessage="No grants found."
        >
          {(data) => (
            <>
              <ul className="divide-y divide-surface-800">
                {data.grants.map((g) => (
                  <li key={g.id} className="flex items-center justify-between gap-3 px-4 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-ink-100">
                        {g.resource_name || g.resource_id || '—'}
                        <span className="ml-2 text-xs font-normal text-ink-500">by {requesterLabel(g)}</span>
                      </p>
                      <p className="mt-0.5 truncate text-xs text-ink-500">
                        Granted {formatDateTime(g.created_at)}
                        {g.expires_at ? ` · Expires ${formatDateTime(g.expires_at)}` : ''}
                      </p>
                    </div>
                    <div className="flex flex-none items-center gap-2">
                      <Badge className={GRANT_STATUS_BADGE[g.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                        {g.status}
                      </Badge>
                      {g.status === 'ACTIVE' && (
                        <button
                          onClick={() => setRevokeTarget(g)}
                          disabled={revokeMutation.isPending}
                          className="rounded-md border border-red-300 dark:border-red-900/50 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-60"
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <ConfirmDialog
        open={!!revokeTarget}
        title={`Revoke grant on "${revokeTarget?.resource_name || revokeTarget?.resource_id || 'this resource'}"?`}
        description="This immediately revokes access and kills any active sessions using this grant."
        confirmLabel="Revoke grant"
        destructive
        requireReason
        reasonLabel="Reason (required for the audit record)"
        isLoading={revokeMutation.isPending}
        onConfirm={(reason) => revokeMutation.mutate({ id: revokeTarget.id, reason })}
        onCancel={() => setRevokeTarget(null)}
      />
    </>
  )
}

function BreakglassReportModal({ grantId, onClose }) {
  const reportQuery = useQuery({
    queryKey: ['admin', 'breakglass', 'report', grantId],
    queryFn: ({ signal }) => getBreakglassReport(grantId, signal),
    enabled: !!grantId,
  })

  if (!grantId) return null

  const report = reportQuery.data

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" role="dialog" aria-modal="true">
      <div className="w-full max-w-lg rounded-lg border border-surface-700 bg-surface-900 p-5 shadow-xl">
        <div className="mb-4 flex items-start justify-between gap-4">
          <h3 className="text-sm font-semibold text-ink-50">Break-glass report</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        {reportQuery.isLoading && (
          <div className="flex items-center justify-center gap-2 py-8 text-ink-400">
            <Spinner /> <span className="text-sm">Loading…</span>
          </div>
        )}
        {reportQuery.isError && (
          <p className="text-sm text-red-700 dark:text-red-300">{apiErrorMessage(reportQuery.error)}</p>
        )}
        {reportQuery.isSuccess && report && (
          <dl className="grid grid-cols-[140px_1fr] gap-y-2 text-sm">
            {Object.entries(report).map(([key, value]) => (
              <ReportField key={key} field={key} value={value} />
            ))}
          </dl>
        )}
        {reportQuery.isSuccess && !report && (
          <p className="text-sm text-ink-500">No report data returned.</p>
        )}
      </div>
    </div>
  )
}

// Renders any value defensively — the report's exact field names/shape
// aren't pinned down here, so nested objects/arrays fall back to JSON.
function ReportField({ field, value }) {
  const display =
    value === null || value === undefined
      ? '—'
      : typeof value === 'object'
        ? JSON.stringify(value)
        : String(value)
  return (
    <>
      <dt className="text-ink-500">{field}</dt>
      <dd className="truncate text-ink-100">{display}</dd>
    </>
  )
}

function BreakglassTab() {
  const [page, setPage] = useState(1)
  const [reportTarget, setReportTarget] = useState(null)

  const breakglassQuery = useQuery({
    queryKey: ['admin', 'breakglass', { page }],
    queryFn: ({ signal }) => listBreakglass({ page, page_size: DEFAULT_PAGE_SIZE }, signal),
  })

  const pagination = breakglassQuery.data?.pagination

  return (
    <>
      <Card>
        <QueryState
          query={breakglassQuery}
          empty={(d) => !d?.requests || d.requests.length === 0}
          emptyMessage="No break-glass requests found."
        >
          {(data) => (
            <>
              <ul className="divide-y divide-surface-800">
                {data.requests.map((r) => (
                  <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 truncate text-sm font-medium text-ink-100">
                        <ShieldAlert className="h-3.5 w-3.5 flex-none text-red-600 dark:text-red-400" />
                        {r.resource_name || r.resource_id || '—'}
                        <span className="text-xs font-normal text-ink-500">by {requesterLabel(r)}</span>
                      </p>
                      <p className="mt-0.5 truncate text-xs text-ink-500">
                        Requested {formatDateTime(r.created_at)}
                        {r.reason ? ` · ${r.reason}` : ''}
                      </p>
                    </div>
                    <div className="flex flex-none items-center gap-2">
                      <Badge className={JIT_STATUS_BADGE[r.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                        {JIT_STATUS_LABELS[r.status] || r.status}
                      </Badge>
                      <button
                        onClick={() => setReportTarget(r.grant_id || r.id)}
                        className="rounded-md bg-surface-800 px-2.5 py-1 text-xs font-medium text-ink-100 hover:bg-surface-700"
                      >
                        View report
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
              {pagination && (
                <Pagination
                  page={pagination.page}
                  pageSize={pagination.page_size}
                  total={pagination.total}
                  totalPages={pagination.total_pages}
                  onPageChange={setPage}
                />
              )}
            </>
          )}
        </QueryState>
      </Card>

      <BreakglassReportModal grantId={reportTarget} onClose={() => setReportTarget(null)} />
    </>
  )
}

export default function AdminJitPage() {
  const [tab, setTab] = useState('requests')

  return (
    <div>
      <PageHeader
        title="JIT Approvals"
        description="Approve or deny access requests, manage active grants, and review break-glass emergency access."
      />

      <div className="mb-4">
        <TabBar tabs={TABS} active={tab} onChange={setTab} />
      </div>

      {tab === 'requests' && <RequestsTab />}
      {tab === 'grants' && <GrantsTab />}
      {tab === 'breakglass' && <BreakglassTab />}
    </div>
  )
}
