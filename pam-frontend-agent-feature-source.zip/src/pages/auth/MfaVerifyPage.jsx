import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { ShieldCheck } from 'lucide-react'
import { verifyMfa } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../../components/common/Spinner'

// NOTE ON THE MISSING COUNTDOWN: the previous PAM frontend (built against an
// older backend) showed a live countdown for the MFA challenge. Verified
// against THIS backend's actual code (auth_service.go's
// verifyChallengeToken): the challenge token here has no expiry check at
// all — it's parsed and accepted regardless of age. Rather than show a
// countdown that lies about enforcement that doesn't exist, this screen
// just doesn't claim one. Worth fixing on the backend at some point; not
// something the frontend should paper over with fake UI.
export default function MfaVerifyPage() {
  const navigate = useNavigate()
  const challenge = useAuthStore((s) => s.mfaChallenge)
  const setSession = useAuthStore((s) => s.setSession)
  const clearMfaChallenge = useAuthStore((s) => s.clearMfaChallenge)
  const [code, setCode] = useState('')
  const [error, setError] = useState(null)
  const inputRef = useRef(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  // Guard against reaching this screen directly (deep link, back button
  // after the flow already completed, a stale bookmark) with no challenge
  // in memory — without this, submitting would 400 with a confusing
  // "malformed challenge token" instead of just sending the user back to
  // start a fresh login.
  useEffect(() => {
    if (!challenge?.challengeToken) {
      navigate('/login', { replace: true })
    }
  }, [challenge, navigate])

  const mutation = useMutation({
    mutationFn: (code) => verifyMfa(challenge.challengeToken, code),
    onSuccess: (result) => {
      resetSessionExpiredGuard()
      clearMfaChallenge()
      setSession({
        accessToken: result.access_token,
        expiresAt: result.expires_at,
        user: null,
      })
      navigate('/', { replace: true })
    },
    onError: (err) => {
      setError(apiErrorMessage(err))
      // Clear the code on failure so the user re-types rather than
      // resubmitting the same rejected code by accident — but keep focus in
      // the field so they don't have to click back into it.
      setCode('')
      inputRef.current?.focus()
    },
  })

  const submit = (e) => {
    e?.preventDefault()
    if (code.trim().length === 0 || mutation.isPending) return
    setError(null)
    mutation.mutate(code.trim())
  }

  if (!challenge?.challengeToken) return null

  return (
    <div className="flex min-h-screen items-center justify-center bg-surface-950 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-2 text-center">
          <div className="rounded-full bg-blue-500/10 p-3">
            <ShieldCheck className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          </div>
          <h1 className="text-lg font-semibold text-ink-50">Verify it&apos;s you</h1>
          <p className="text-sm text-ink-400">Enter the 6-digit code from your authenticator app.</p>
        </div>

        <form
          onSubmit={submit}
          className="space-y-4 rounded-lg border border-surface-800 bg-surface-900 p-6"
        >
          {error && (
            <div className="rounded-md bg-red-50 dark:bg-red-950/40 px-3 py-2 text-sm text-red-700 dark:text-red-300" role="alert">
              {error}
            </div>
          )}

          <input
            ref={inputRef}
            inputMode="numeric"
            autoComplete="one-time-code"
            pattern="[0-9]*"
            maxLength={8}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ''))}
            className="w-full rounded-md border border-surface-700 bg-surface-800 px-3 py-3 text-center text-2xl tracking-[0.4em] text-ink-50 focus:border-blue-500 focus:outline-none"
            placeholder="000000"
          />

          <button
            type="submit"
            disabled={mutation.isPending || code.length === 0}
            className="flex w-full items-center justify-center gap-2 rounded-md bg-blue-600 py-2 text-sm font-medium text-white hover:bg-blue-500 disabled:pointer-events-none disabled:opacity-60"
          >
            {mutation.isPending && <Spinner size="h-4 w-4" className="text-white" />}
            Verify
          </button>

          <button
            type="button"
            onClick={() => {
              clearMfaChallenge()
              navigate('/login', { replace: true })
            }}
            className="w-full text-center text-xs text-ink-500 hover:text-ink-300"
          >
            Back to login
          </button>
        </form>
      </div>
    </div>
  )
}
