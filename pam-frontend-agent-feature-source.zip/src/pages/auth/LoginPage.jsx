import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useNavigate, useLocation } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { ShieldCheck, Lock } from 'lucide-react'
import { login } from '../../api/auth'
import { useAuthStore } from '../../store/authStore'
import { resetSessionExpiredGuard } from '../../lib/http'
import { Field, inputClass } from '../../components/common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../../components/common/Spinner'

const schema = z.object({
  identifier: z.string().trim().min(1, 'Required'),
  password: z.string().min(1, 'Required'),
})

export default function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const setSession = useAuthStore((s) => s.setSession)
  const setMfaChallenge = useAuthStore((s) => s.setMfaChallenge)
  const [formError, setFormError] = useState(null)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })

  const mutation = useMutation({
    mutationFn: ({ identifier, password }) => login(identifier, password),
    onSuccess: (result) => {
      setFormError(null)
      // LoginResult's fields are `omitempty` on the Go side — the only
      // reliable way to tell "full session" from "MFA challenge" apart is
      // whether access_token actually came back, not the HTTP status (both
      // paths return 200 — see auth_handler.go's Login: ErrMFARequired is
      // deliberately treated as a *success* response, not an error one).
      if (result?.access_token) {
        resetSessionExpiredGuard()
        setSession({
          accessToken: result.access_token,
          expiresAt: result.expires_at,
          user: null, // populated by the dashboard's `me()` fetch
        })
        const from = location.state?.from?.pathname || '/'
        navigate(from, { replace: true })
        return
      }
      if (result?.challenge_token) {
        setMfaChallenge({ challengeToken: result.challenge_token })
        navigate('/mfa-verify', { replace: true })
        return
      }
      // Defensive: neither shape came back. Don't silently do nothing —
      // that's the kind of bug where the user clicks Login, sees no error
      // and no navigation, and assumes the app is frozen.
      setFormError('Unexpected response from the server. Please try again.')
    },
    onError: (err) => setFormError(apiErrorMessage(err)),
  })

  const onSubmit = (values) => {
    setFormError(null)
    mutation.mutate(values)
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-surface-950 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-2 text-center">
          <div className="rounded-full bg-blue-500/10 p-3">
            <ShieldCheck className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          </div>
          <h1 className="text-lg font-semibold text-ink-50">PAM Console</h1>
          <p className="text-sm text-ink-400">Privileged access management</p>
        </div>

        <form
          onSubmit={handleSubmit(onSubmit)}
          noValidate
          className="space-y-4 rounded-lg border border-surface-800 bg-surface-900 p-6"
        >
          {formError && (
            <div className="rounded-md bg-red-50 dark:bg-red-950/40 px-3 py-2 text-sm text-red-700 dark:text-red-300" role="alert">
              {formError}
            </div>
          )}

          <Field label="Username or email" error={errors.identifier?.message} required>
            <input
              autoFocus
              autoComplete="username"
              className={inputClass(!!errors.identifier)}
              {...register('identifier')}
            />
          </Field>

          <Field label="Password" error={errors.password?.message} required>
            <input
              type="password"
              autoComplete="current-password"
              className={inputClass(!!errors.password)}
              {...register('password')}
            />
          </Field>

          <button
            type="submit"
            disabled={mutation.isPending}
            className="flex w-full items-center justify-center gap-2 rounded-md bg-blue-600 py-2 text-sm font-medium text-white hover:bg-blue-500 disabled:pointer-events-none disabled:opacity-60"
          >
            {mutation.isPending ? <Spinner size="h-4 w-4" className="text-white" /> : <Lock className="h-4 w-4" />}
            Sign in
          </button>
        </form>
      </div>
    </div>
  )
}
