import { useEffect, useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ChevronLeft, ChevronRight, ShieldCheck, ShieldAlert, Download, FileSearch } from 'lucide-react'
import { searchAudit, verifyAuditChain, generateComplianceReport } from '../../api/audit'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Spinner } from '../../components/common/Spinner'
import { inputClass } from '../../components/common/FormFields'
import { formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  AUDIT_CATEGORIES,
  AUDIT_OUTCOMES,
  AUDIT_OUTCOME_BADGE,
  AUDIT_SEVERITY_BADGE,
  SEARCH_DEBOUNCE_MS,
} from '../../config/constants'

const PAGE_LIMIT = 20

// Defensive readers — the exact field names an audit item carries for
// "when did this happen" / "who did it" / "what did it touch" aren't pinned
// down anywhere we've been given, so try the plausible candidates and fall
// back to a placeholder rather than crashing on `undefined.foo`.
function itemTimestamp(item) {
  return item?.occurred_at || item?.created_at || item?.timestamp || null
}
function actorLabel(item) {
  return (
    item?.actor_username ||
    item?.username ||
    item?.actor?.username ||
    item?.user_email ||
    item?.actor_id ||
    item?.user_id ||
    '—'
  )
}
function targetLabel(item) {
  return (
    item?.resource_name ||
    item?.resource ||
    item?.target ||
    item?.resource_id ||
    '—'
  )
}

function AuditRow({ item }) {
  const ts = itemTimestamp(item)
  return (
    <li className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink-100">
          <span className="text-ink-400">{item?.category || 'OTHER'}</span>
          <span>{item?.action || '—'}</span>
          {item?.outcome && (
            <Badge className={AUDIT_OUTCOME_BADGE[item.outcome] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
              {item.outcome}
            </Badge>
          )}
          {item?.severity && (
            <Badge className={AUDIT_SEVERITY_BADGE[item.severity] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
              {item.severity}
            </Badge>
          )}
        </p>
        <p className="mt-1 truncate text-xs text-ink-500">
          {formatDateTime(ts)} · actor: {actorLabel(item)} · target: {targetLabel(item)}
        </p>
      </div>
    </li>
  )
}

export default function AuditPage() {
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [outcome, setOutcome] = useState('')
  const [offset, setOffset] = useState(0)
  const [reportOpen, setReportOpen] = useState(false)
  const [reportFormat, setReportFormat] = useState('pdf')

  // Debounce the free-text search so it doesn't fire a request per keystroke —
  // the input updates immediately for responsiveness, the query key only
  // picks up `search` after SEARCH_DEBOUNCE_MS of no further typing.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  // Any filter change invalidates the current offset — otherwise "offset 60"
  // can persist into a filtered result set with only 10 total items.
  useEffect(() => {
    setOffset(0)
  }, [search, category, outcome])

  const filters = {
    action: search || undefined,
    category: category || undefined,
    outcome: outcome || undefined,
  }

  const auditQuery = useQuery({
    queryKey: ['audit', 'search', { search, category, outcome, offset }],
    queryFn: ({ signal }) => searchAudit({ ...filters, limit: PAGE_LIMIT, offset }, signal),
    placeholderData: (prev) => prev,
  })

  const verifyMutation = useMutation({
    mutationFn: () => verifyAuditChain(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const reportMutation = useMutation({
    mutationFn: () => generateComplianceReport({ ...filters, format: reportFormat }),
    onSuccess: (result) => {
      toast.success(result?.filename ? `Report downloaded: ${result.filename}` : 'Report downloaded')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const total = auditQuery.data?.total ?? 0
  const limit = auditQuery.data?.limit ?? PAGE_LIMIT
  const items = auditQuery.data?.items
  const canPrev = offset > 0
  const canNext = offset + limit < total
  const rangeStart = total === 0 ? 0 : offset + 1
  const rangeEnd = Math.min(offset + limit, total)

  const verifyResult = verifyMutation.data
  // `verifyAuditChain` already normalizes the enveloped-vs-bare response
  // shape internally, but the field naming inside the payload itself isn't
  // pinned down — probe the plausible boolean fields and otherwise fall
  // back to showing the raw JSON rather than silently dropping the signal.
  const verifyKnownField =
    verifyResult && (
      'valid' in verifyResult ? 'valid'
      : 'chain_valid' in verifyResult ? 'chain_valid'
      : 'success' in verifyResult ? 'success'
      : null
    )
  const verifyIsValid = verifyKnownField ? Boolean(verifyResult[verifyKnownField]) : null

  return (
    <div>
      <PageHeader
        title="Audit"
        description="Your own audit trail — actions performed by or affecting your account."
      />

      {verifyMutation.isSuccess && (
        <div
          className={
            'mb-4 flex items-center gap-3 rounded-lg border p-4 ' +
            (verifyIsValid === false
              ? 'border-red-400 dark:border-red-600/60 bg-red-50 dark:bg-red-950/40'
              : verifyIsValid === true
                ? 'border-emerald-300 dark:border-emerald-600/40 bg-emerald-50 dark:bg-emerald-950/20'
                : 'border-surface-800 bg-surface-900')
          }
        >
          {verifyIsValid === false && <ShieldAlert className="h-6 w-6 flex-none text-red-600 dark:text-red-400" />}
          {verifyIsValid === true && <ShieldCheck className="h-6 w-6 flex-none text-emerald-600 dark:text-emerald-400" />}
          <div className="min-w-0">
            {verifyIsValid === true && (
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                Audit chain intact — no tampering detected.
              </p>
            )}
            {verifyIsValid === false && (
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">
                Audit chain broken — possible tampering detected. Notify a security administrator.
              </p>
            )}
            {verifyIsValid === null && (
              <>
                <p className="mb-1 text-sm font-medium text-ink-100">Verification result</p>
                <pre className="max-w-full overflow-x-auto text-xs text-ink-400">
                  {JSON.stringify(verifyResult, null, 2)}
                </pre>
              </>
            )}
          </div>
        </div>
      )}

      <Card className="mb-4">
        <CardHeader className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-medium text-ink-100">Chain integrity</h2>
          <button
            onClick={() => verifyMutation.mutate()}
            disabled={verifyMutation.isPending}
            className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
          >
            {verifyMutation.isPending ? <Spinner size="h-3.5 w-3.5" /> : <ShieldCheck className="h-3.5 w-3.5" />}
            Verify audit chain
          </button>
        </CardHeader>
        <div className="px-4 py-3 text-xs text-ink-500">
          Checks that the recorded audit entries in scope for your account form an unbroken,
          tamper-evident chain. This is not run automatically — trigger it explicitly.
        </div>
      </Card>

      <Card className="mb-4">
        <CardHeader className="flex flex-wrap items-center gap-3">
          <input
            className={inputClass(false) + ' max-w-xs'}
            placeholder="Search action…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
          <select
            className={inputClass(false) + ' max-w-[10rem]'}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All categories</option>
            {AUDIT_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select
            className={inputClass(false) + ' max-w-[10rem]'}
            value={outcome}
            onChange={(e) => setOutcome(e.target.value)}
          >
            <option value="">All outcomes</option>
            {AUDIT_OUTCOMES.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
          <button
            onClick={() => setReportOpen((v) => !v)}
            className="ml-auto flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
          >
            <FileSearch className="h-4 w-4" /> Generate report
          </button>
        </CardHeader>

        {reportOpen && (
          <div className="flex flex-wrap items-center gap-3 border-b border-surface-800 px-4 py-3">
            <span className="text-xs font-medium text-ink-300">Format:</span>
            <label className="flex items-center gap-1.5 text-sm text-ink-200">
              <input
                type="radio"
                name="report-format"
                checked={reportFormat === 'pdf'}
                onChange={() => setReportFormat('pdf')}
              />
              PDF
            </label>
            <label className="flex items-center gap-1.5 text-sm text-ink-200">
              <input
                type="radio"
                name="report-format"
                checked={reportFormat === 'csv'}
                onChange={() => setReportFormat('csv')}
              />
              CSV
            </label>
            <button
              onClick={() => reportMutation.mutate()}
              disabled={reportMutation.isPending}
              className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
            >
              {reportMutation.isPending ? <Spinner size="h-3.5 w-3.5" /> : <Download className="h-3.5 w-3.5" />}
              Download
            </button>
            <span className="text-xs text-ink-500">
              Scoped to the current search filters above.
            </span>
          </div>
        )}

        <QueryState
          query={auditQuery}
          empty={(d) => !d?.items || d.items.length === 0}
          emptyMessage="No audit entries found."
        >
          {() => (
            <>
              <ul className="divide-y divide-surface-800">
                {items.map((item, idx) => (
                  <AuditRow key={item?.id ?? item?.sequence ?? idx} item={item} />
                ))}
              </ul>
              <div className="flex items-center justify-between border-t border-surface-800 px-4 py-3 text-sm text-ink-400">
                <span>
                  Showing <span className="text-ink-200">{rangeStart}</span>–
                  <span className="text-ink-200">{rangeEnd}</span> of{' '}
                  <span className="text-ink-200">{total}</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={!canPrev}
                    onClick={() => canPrev && setOffset((o) => Math.max(0, o - limit))}
                    className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
                    aria-label="Previous page"
                  >
                    <ChevronLeft className="h-4 w-4" /> Prev
                  </button>
                  <button
                    disabled={!canNext}
                    onClick={() => canNext && setOffset((o) => o + limit)}
                    className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
                    aria-label="Next page"
                  >
                    Next <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </>
          )}
        </QueryState>
      </Card>
    </div>
  )
}
