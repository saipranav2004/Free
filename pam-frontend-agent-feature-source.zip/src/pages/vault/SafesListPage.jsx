import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight, Vault as VaultIcon } from 'lucide-react'
import { listSafes } from '../../api/vault'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { CreateSafeModal } from '../../components/vault/CreateSafeModal'

export default function SafesListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const safesQuery = useQuery({
    queryKey: ['vault', 'safes'],
    queryFn: ({ signal }) => listSafes(signal),
  })

  return (
    <div>
      <PageHeader
        title="Vault"
        description="Safes group credentials by ownership and retention policy."
        actions={
          <button
            onClick={() => setCreateOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
          >
            <Plus className="h-4 w-4" /> Create safe
          </button>
        }
      />

      <QueryState
        query={safesQuery}
        empty={(safes) => !safes || safes.length === 0}
        emptyMessage="No safes yet. Create one to start storing credentials."
      >
        {(safes) => (
          <Card>
            <ul className="divide-y divide-surface-800">
              {safes.map((safe) => (
                <li key={safe.id}>
                  <Link to={`/vault/${safe.id}`} className="flex items-center justify-between px-4 py-3 hover:bg-surface-850">
                    <div className="flex items-center gap-3">
                      <VaultIcon className="h-4 w-4 text-ink-400" />
                      <div>
                        <p className="text-sm font-medium text-ink-100">{safe.name}</p>
                        {safe.description && <p className="text-xs text-ink-500">{safe.description}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {safe.is_default && (
                        <Badge className="bg-blue-500/15 text-blue-700 dark:text-blue-300 ring-blue-500/30">Default</Badge>
                      )}
                      <span className="text-xs text-ink-500">{safe.retention_days}d retention</span>
                      <ChevronRight className="h-4 w-4 text-ink-600" />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreateSafeModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
