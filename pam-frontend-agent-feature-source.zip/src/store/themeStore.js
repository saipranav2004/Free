import { create } from 'zustand'

// ---------------------------------------------------------------------------
// Light / dark / system theme
// ---------------------------------------------------------------------------
// Persisted to localStorage (not sessionStorage like authStore) deliberately:
// a UI preference like "I use light mode" carries no security sensitivity —
// unlike a bearer token, there is nothing here worth shrinking the exposure
// window for, and losing it every time the tab closes would just be
// annoying (retyping/reclicking the same preference every session).
const STORAGE_KEY = 'pam_theme'
const VALID = new Set(['light', 'dark', 'system'])

function readPersisted() {
  try {
    const v = localStorage.getItem(STORAGE_KEY)
    return VALID.has(v) ? v : 'system'
  } catch {
    return 'system'
  }
}

function systemPrefersDark() {
  return typeof window !== 'undefined' && window.matchMedia
    ? window.matchMedia('(prefers-color-scheme: dark)').matches
    : false
}

function resolveIsDark(theme) {
  if (theme === 'dark') return true
  if (theme === 'light') return false
  return systemPrefersDark()
}

function applyToDocument(isDark) {
  const root = document.documentElement
  root.classList.toggle('dark', isDark)
  // Keeps native form controls (checkboxes, scrollbars in some browsers)
  // and the browser's own UI chrome (address bar on mobile) in sync with
  // the resolved theme, independent of the color-scheme set in index.css.
  root.style.colorScheme = isDark ? 'dark' : 'light'
}

const initialTheme = readPersisted()
const initialIsDark = resolveIsDark(initialTheme)
if (typeof document !== 'undefined') applyToDocument(initialIsDark)

export const useThemeStore = create((set, get) => ({
  theme: initialTheme, // 'light' | 'dark' | 'system'
  isDark: initialIsDark,

  setTheme: (theme) => {
    if (!VALID.has(theme)) return
    try {
      localStorage.setItem(STORAGE_KEY, theme)
    } catch {
      /* private-browsing etc — non-fatal, just won't persist across tabs */
    }
    const isDark = resolveIsDark(theme)
    applyToDocument(isDark)
    set({ theme, isDark })
  },

  // Cycles light -> dark -> system -> light… — a single button in the topbar
  // drives this rather than a 3-way switcher, which is enough real estate
  // for a setting most people set once and forget.
  cycleTheme: () => {
    const order = ['light', 'dark', 'system']
    const next = order[(order.indexOf(get().theme) + 1) % order.length]
    get().setTheme(next)
  },
}))

// Track the OS-level preference live while in 'system' mode — if the user
// hasn't picked an explicit theme, flipping their OS between light/dark
// (common: automatic at sunset) should repaint the app without a reload.
if (typeof window !== 'undefined' && window.matchMedia) {
  const mql = window.matchMedia('(prefers-color-scheme: dark)')
  const handler = () => {
    const { theme } = useThemeStore.getState()
    if (theme === 'system') {
      const isDark = systemPrefersDark()
      applyToDocument(isDark)
      useThemeStore.setState({ isDark })
    }
  }
  // addEventListener is the modern API; addListener is the Safari <14 fallback.
  if (mql.addEventListener) mql.addEventListener('change', handler)
  else if (mql.addListener) mql.addListener(handler)
}
