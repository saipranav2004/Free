import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createResource } from '../../api/adminResources'
import { RESOURCE_TYPES, CONNECT_MODES } from '../../config/constants'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  description: z.string().optional(),
  resource_type: z.string().min(1, 'Select a resource type'),
  host: z.string().trim().min(1, 'Required'),
  // react-hook-form gives us a string from the input; coerce here rather
  // than trusting the browser's <input type="number"> (which can still
  // submit an empty string, "e", or "-" on some browsers/keyboards).
  port: z.coerce
    .number({ invalid_type_error: 'Port must be a number' })
    .int('Port must be a whole number')
    .min(1, 'Port must be between 1 and 65535')
    .max(65535, 'Port must be between 1 and 65535'),
  database_name: z.string().optional(),
  connect_mode: z.string().optional(),
  console_url: z
    .string()
    .optional()
    .refine((v) => !v || /^https?:\/\//.test(v), 'Must start with http:// or https://'),
  extra_config: z
    .string()
    .optional()
    .refine((v) => {
      if (!v || v.trim() === '') return true
      try {
        JSON.parse(v)
        return true
      } catch {
        return false
      }
    }, 'Must be valid JSON'),
  requires_jit: z.boolean().optional(),
  always_record: z.boolean().optional(),
})

export function CreateResourceModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { connect_mode: 'web_terminal', requires_jit: false, always_record: false },
  })

  const connectMode = watch('connect_mode')

  const mutation = useMutation({
    mutationFn: createResource,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resources'] })
      toast.success('Resource created')
      reset()
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-lg border border-surface-700 bg-surface-900 p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Register a resource</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit((values) => mutation.mutate(values))}
          noValidate
          className="space-y-4"
        >
          <Field label="Name" error={errors.name?.message} required>
            <input className={inputClass(!!errors.name)} {...register('name')} />
          </Field>

          <Field label="Type" error={errors.resource_type?.message} required>
            <select className={inputClass(!!errors.resource_type)} {...register('resource_type')}>
              <option value="">Select…</option>
              {RESOURCE_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </Field>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <Field label="Host" error={errors.host?.message} required>
                <input className={inputClass(!!errors.host)} {...register('host')} />
              </Field>
            </div>
            <Field label="Port" error={errors.port?.message} required>
              <input
                inputMode="numeric"
                className={inputClass(!!errors.port)}
                {...register('port')}
              />
            </Field>
          </div>

          <Field label="Database name" hint="Optional">
            <input className={inputClass(false)} {...register('database_name')} />
          </Field>

          <Field label="Connect mode">
            <select className={inputClass(false)} {...register('connect_mode')}>
              {CONNECT_MODES.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </Field>

          <Field
            label="Console URL"
            error={errors.console_url?.message}
            hint={
              connectMode === 'embed_redirect'
                ? 'Required for embed_redirect mode — used as the target when opening this resource.'
                : 'Optional — shown as a shortcut link if set.'
            }
          >
            <input
              className={inputClass(!!errors.console_url)}
              placeholder="https://…"
              {...register('console_url')}
            />
          </Field>

          <Field
            label="Extra config (JSON)"
            error={errors.extra_config?.message}
            hint="Optional, protocol-specific settings as a JSON object."
          >
            <textarea
              rows={2}
              className={inputClass(!!errors.extra_config) + ' font-mono'}
              placeholder="{}"
              {...register('extra_config')}
            />
          </Field>

          <div className="space-y-2 rounded-md border border-surface-800 bg-surface-950/40 p-3">
            <label className="flex items-center gap-2 text-sm text-ink-200">
              <input
                type="checkbox"
                className="rounded border-surface-700 bg-surface-800"
                {...register('requires_jit')}
              />
              Requires JIT approval
              <span className="text-xs text-ink-500">
                — access only via an approved time-boxed request, no standing access
              </span>
            </label>
            <label className="flex items-center gap-2 text-sm text-ink-200">
              <input
                type="checkbox"
                className="rounded border-surface-700 bg-surface-800"
                {...register('always_record')}
              />
              Always record sessions
              <span className="text-xs text-ink-500">— session recording is never optional for this resource</span>
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md px-3 py-1.5 text-sm text-ink-300 hover:bg-surface-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 rounded-md bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-500 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
