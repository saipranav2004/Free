import { Navigate, Outlet } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'

// Gates the entire /admin/* subtree client-side. This is a UX guard, not a
// security boundary — the real enforcement is server-side
// (middleware.RequireAdmin on every /api/v1/pam/admin/* route), exactly the
// way a client-side check should never be the only thing standing between a
// user and a privileged action. This just keeps a non-admin from ever
// seeing the Admin Center shell flash on screen before every one of its
// requests 403s.
export function AdminRoute() {
  const isAdmin = useAuthStore((s) => s.isAdmin())
  if (!isAdmin) return <Navigate to="/" replace />
  return <Outlet />
}
