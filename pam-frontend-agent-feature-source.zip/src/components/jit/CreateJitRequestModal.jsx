import { useEffect, useRef, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X, ShieldAlert } from 'lucide-react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { createJitRequest, createBreakglassRequest } from '../../api/jit'
import { listResources } from '../../api/resources'
import { JIT_DEFAULTS } from '../../config/constants'
import { Field, inputClass } from '../common/FormFields'
import { Spinner } from '../common/Spinner'
import { apiErrorMessage } from '../../lib/apiError'

const schema = z.object({
  resource_id: z.string().min(1, 'Select a resource'),
  action: z.string().optional(),
  duration_minutes: z.coerce
    .number()
    .int()
    .min(1, 'Must be at least 1 minute')
    .max(JIT_DEFAULTS.MAX_DURATION_MIN, `Cannot exceed ${JIT_DEFAULTS.MAX_DURATION_MIN} minutes — the server will reject anything longer`),
  reason: z
    .string()
    .trim()
    .min(JIT_DEFAULTS.MIN_REASON_LENGTH, `At least ${JIT_DEFAULTS.MIN_REASON_LENGTH} characters — the server requires a substantive reason`),
  ticket_ref: z.string().optional(),
})

// Generates a fresh idempotency key exactly once per "open" of the modal
// (not once per render, and not once per mount — reopening the modal for a
// second, genuinely different request must get a NEW key, or the second
// request would be silently deduped as a replay of the first).
function useIdempotencyKey(open) {
  const ref = useRef(null)
  useEffect(() => {
    if (open) ref.current = crypto.randomUUID()
  }, [open])
  return ref
}

export function CreateJitRequestModal({ open, onClose, defaultResourceId, defaultBreakglass = false }) {
  const [isBreakglass, setIsBreakglass] = useState(defaultBreakglass)
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const idempotencyKeyRef = useIdempotencyKey(open)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      resource_id: defaultResourceId || '',
      duration_minutes: isBreakglass
        ? JIT_DEFAULTS.BREAKGLASS_MAX_DURATION_MIN
        : JIT_DEFAULTS.DEFAULT_DURATION_MIN,
    },
  })

  useEffect(() => {
    if (open) setIsBreakglass(defaultBreakglass)
  }, [open, defaultBreakglass])

  const resourcesQuery = useQuery({
    queryKey: ['resources', 'flat'],
    queryFn: ({ signal }) => listResources({ signal }),
    enabled: open,
    staleTime: 30_000,
  })

  const mutation = useMutation({
    mutationFn: (values) => {
      const payload = {
        resource_id: values.resource_id,
        action: values.action || undefined,
        duration_minutes: Number(values.duration_minutes),
        reason: values.reason,
        ticket_ref: values.ticket_ref || undefined,
      }
      return isBreakglass
        ? createBreakglassRequest(payload, idempotencyKeyRef.current)
        : createJitRequest(payload, idempotencyKeyRef.current)
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['jit'] })
      toast.success(isBreakglass ? 'Break-glass request raised' : 'Access request submitted')
      reset()
      onClose()
      navigate(`/jit/requests/${data.request.id}`)
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-lg border border-surface-700 bg-surface-900 p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">
            {isBreakglass ? 'Break-glass emergency access' : 'Request time-boxed access'}
          </h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        {!defaultBreakglass && (
          <label className="mb-4 flex items-center gap-2 rounded-md border border-surface-800 bg-surface-950/40 p-3 text-xs text-ink-300">
            <input
              type="checkbox"
              checked={isBreakglass}
              onChange={(e) => setIsBreakglass(e.target.checked)}
              className="rounded border-surface-700 bg-surface-800"
            />
            This is a break-glass emergency request (no approver, mandatory
            waiting period, always recorded, raises a CRITICAL alert)
          </label>
        )}

        {isBreakglass && (
          <div className="mb-4 flex items-start gap-2 rounded-md border border-red-300 dark:border-red-900/40 bg-red-50 dark:bg-red-950/20 p-3 text-xs text-red-700 dark:text-red-200">
            <ShieldAlert className="mt-0.5 h-4 w-4 flex-none text-red-600 dark:text-red-400" />
            <span>
              This immediately raises a CRITICAL security alert and is fully recorded. Access does
              not activate until a {JIT_DEFAULTS.BREAKGLASS_WAIT_MIN}-minute waiting period elapses —
              an administrator can revoke it before then.
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate className="space-y-4">
          <Field label="Resource" error={errors.resource_id?.message} required>
            <select className={inputClass(!!errors.resource_id)} {...register('resource_id')} disabled={resourcesQuery.isLoading}>
              <option value="">{resourcesQuery.isLoading ? 'Loading…' : 'Select…'}</option>
              {(resourcesQuery.data?.resources || []).map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.host}:{r.port})
                </option>
              ))}
            </select>
          </Field>

          <Field label="Action" hint="Optional — e.g. read, write, admin.">
            <input className={inputClass(false)} {...register('action')} />
          </Field>

          <Field
            label="Duration (minutes)"
            error={errors.duration_minutes?.message}
            hint={`Server max is ${isBreakglass ? JIT_DEFAULTS.BREAKGLASS_MAX_DURATION_MIN : JIT_DEFAULTS.MAX_DURATION_MIN} minutes.`}
            required
          >
            <input inputMode="numeric" className={inputClass(!!errors.duration_minutes)} {...register('duration_minutes')} />
          </Field>

          <Field label="Reason" error={errors.reason?.message} required>
            <textarea rows={3} className={inputClass(!!errors.reason)} {...register('reason')} />
          </Field>

          <Field label="Ticket reference" hint="Optional — e.g. JIRA-1234.">
            <input className={inputClass(false)} {...register('ticket_ref')} />
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="rounded-md px-3 py-1.5 text-sm text-ink-300 hover:bg-surface-800">
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className={
                'flex items-center gap-2 rounded-md px-4 py-1.5 text-sm font-medium text-white disabled:opacity-60 ' +
                (isBreakglass ? 'bg-red-600 hover:bg-red-500' : 'bg-blue-600 hover:bg-blue-500')
              }
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              {isBreakglass ? 'Raise emergency access' : 'Submit request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
