import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createPolicy } from '../../api/rbac'
import { POLICY_EFFECTS, COMMON_ACTIONS } from '../../config/constants'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'

// Splits a comma-separated free-text field into a trimmed, non-empty string
// array — the shape the backend policy payload expects for actions/resources.
function toStringArray(value) {
  return (value || '')
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean)
}

const schema = z.object({
  name: z.string().trim().min(1, 'Required').max(255),
  description: z.string().optional(),
  effect: z.string().min(1, 'Select an effect'),
  actions: z.string().trim().min(1, 'At least one action is required'),
  resources: z.string().trim().min(1, 'At least one resource pattern is required'),
})

export function CreatePolicyModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    control,
    watch,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { effect: 'allow', actions: '', resources: '' },
  })

  const actionsValue = watch('actions')

  const mutation = useMutation({
    mutationFn: (values) =>
      createPolicy({
        name: values.name,
        description: values.description,
        effect: values.effect,
        actions: toStringArray(values.actions),
        resources: toStringArray(values.resources),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'policies'] })
      toast.success('Policy created')
      reset({ effect: 'allow', actions: '', resources: '' })
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  const addAction = (action) => {
    const current = toStringArray(actionsValue)
    if (current.includes(action)) return
    setValue('actions', [...current, action].join(', '), { shouldValidate: true })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-lg border border-surface-700 bg-surface-900 p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Create policy</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit((values) => mutation.mutate(values))}
          noValidate
          className="space-y-4"
        >
          <Field label="Name" error={errors.name?.message} required>
            <input className={inputClass(!!errors.name)} {...register('name')} />
          </Field>

          <Field label="Description" hint="Optional">
            <textarea rows={2} className={inputClass(false)} {...register('description')} />
          </Field>

          <Field label="Effect" error={errors.effect?.message} required>
            <Controller
              name="effect"
              control={control}
              render={({ field }) => (
                <select className={inputClass(!!errors.effect)} {...field}>
                  {POLICY_EFFECTS.map((e) => (
                    <option key={e.value} value={e.value}>
                      {e.label}
                    </option>
                  ))}
                </select>
              )}
            />
          </Field>

          <Field
            label="Actions"
            error={errors.actions?.message}
            hint="Comma-separated action strings — not an enforced client-side vocabulary, the server validates these."
            required
          >
            <textarea
              rows={2}
              className={inputClass(!!errors.actions) + ' font-mono'}
              placeholder="pam:resource:List, pam:vault:Reveal"
              {...register('actions')}
            />
            <div className="mt-2 flex flex-wrap gap-1.5">
              {COMMON_ACTIONS.map((a) => (
                <button
                  key={a}
                  type="button"
                  onClick={() => addAction(a)}
                  className="rounded-full bg-surface-800 px-2 py-0.5 text-xs text-ink-300 hover:bg-surface-700"
                >
                  {a}
                </button>
              ))}
            </div>
          </Field>

          <Field
            label="Resources"
            error={errors.resources?.message}
            hint="Comma-separated resource patterns, e.g. * or specific resource IDs."
            required
          >
            <textarea
              rows={2}
              className={inputClass(!!errors.resources) + ' font-mono'}
              placeholder="*"
              {...register('resources')}
            />
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md px-3 py-1.5 text-sm text-ink-300 hover:bg-surface-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 rounded-md bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-500 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
