import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { X } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { createUser, assignRole } from '../../api/identity'
import { SYSTEM_ROLES } from '../../config/constants'
import { Field, inputClass } from '../common/FormFields'
import { apiErrorMessage } from '../../lib/apiError'
import { Spinner } from '../common/Spinner'

// Field names for the create-user payload aren't pinned down by any doc
// available here — username/email/full_name/password is the reasonable,
// commonly-named shape assumed for the POST /admin/identity/users body.
const schema = z.object({
  username: z.string().trim().min(1, 'Required').max(255),
  email: z.string().trim().min(1, 'Required').email('Must be a valid email'),
  full_name: z.string().optional(),
  password: z.string().min(10, 'Must be at least 10 characters'),
  role: z.string().optional(),
})

const DEFAULT_ROLE = 'user'

export function CreateUserModal({ open, onClose }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { role: DEFAULT_ROLE },
  })

  const mutation = useMutation({
    mutationFn: async ({ role, ...payload }) => {
      const user = await createUser(payload)
      if (role && role !== DEFAULT_ROLE) {
        await assignRole(user.id, role)
      }
      return user
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] })
      toast.success('User created')
      reset({ role: DEFAULT_ROLE })
      onClose()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-lg border border-surface-700 bg-surface-900 p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-ink-50">Create user</h3>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-200" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={handleSubmit((values) => mutation.mutate(values))}
          noValidate
          className="space-y-4"
        >
          <Field label="Username" error={errors.username?.message} required>
            <input className={inputClass(!!errors.username)} {...register('username')} />
          </Field>

          <Field label="Email" error={errors.email?.message} required>
            <input className={inputClass(!!errors.email)} type="email" {...register('email')} />
          </Field>

          <Field label="Full name" hint="Optional">
            <input className={inputClass(false)} {...register('full_name')} />
          </Field>

          <Field
            label="Password"
            error={errors.password?.message}
            hint="At least 10 characters, matching this app's password policy."
            required
          >
            <input className={inputClass(!!errors.password)} type="password" {...register('password')} />
          </Field>

          <Field label="Role" hint="Assigned via RBAC after the account is created.">
            <select className={inputClass(false)} {...register('role')}>
              {SYSTEM_ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md px-3 py-1.5 text-sm text-ink-300 hover:bg-surface-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="flex items-center gap-2 rounded-md bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-500 disabled:opacity-60"
            >
              {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
