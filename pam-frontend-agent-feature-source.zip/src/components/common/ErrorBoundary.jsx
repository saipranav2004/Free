import { Component } from 'react'
import { AlertTriangle, RotateCcw } from 'lucide-react'

// A single bad render anywhere in the tree (a null-deref on an unexpected
// API shape, a third-party component throwing, whatever) should never take
// down the entire console with a blank white screen — that's the single
// worst possible failure mode for a tool people use to manage privileged
// access. This is the backstop.
//
// Deliberately class-based: error boundaries are not expressible as hooks
// (no useErrorBoundary equivalent exists in React 18) — this is the one
// legitimate reason for a class component in an otherwise all-function
// codebase.
export class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { error: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    // In a real deployment this is where you'd forward to Sentry/similar.
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary] caught render error:', error, info)
  }

  reset = () => this.setState({ error: null })

  render() {
    if (this.state.error) {
      return (
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 p-8 text-center">
          <AlertTriangle className="h-10 w-10 text-amber-600 dark:text-amber-400" />
          <h2 className="text-lg font-semibold text-ink-50">Something went wrong</h2>
          <p className="max-w-md text-sm text-ink-400">
            This section hit an unexpected error and couldn&apos;t render. The
            rest of the console should still work — try again, or navigate
            elsewhere.
          </p>
          {import.meta.env.DEV && (
            <pre className="max-w-full overflow-auto rounded-md bg-surface-900 p-3 text-left text-xs text-red-700 dark:text-red-300">
              {String(this.state.error?.stack || this.state.error)}
            </pre>
          )}
          <button
            onClick={this.reset}
            className="flex items-center gap-2 rounded-md bg-surface-800 px-4 py-2 text-sm font-medium text-ink-50 hover:bg-surface-700"
          >
            <RotateCcw className="h-4 w-4" /> Try again
          </button>
        </div>
      )
    }
    return this.props.children
  }
}
