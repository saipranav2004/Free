import { ChevronLeft, ChevronRight } from 'lucide-react'

// Every list endpoint in this backend returns the same
// { page, page_size, total, total_pages } shape (see jit_handler.go's
// paged() helper) — one Pagination component for all of them.
//
// Edge cases handled deliberately:
//  - total_pages === 0 (no results at all) -> render nothing rather than a
//    confusing "Page 1 of 0".
//  - Attempting to go below page 1 or above total_pages is a no-op, not a
//    request for a page that doesn't exist (a naive `onPageChange(page+1)`
//    with no bound check is how you get "page 47 of 3" stuck states after
//    a filter change shrinks the result set while the user's page number
//    was left stale).
export function Pagination({ page, pageSize, total, totalPages, onPageChange }) {
  if (!totalPages || totalPages <= 1) return null

  const canPrev = page > 1
  const canNext = page < totalPages
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1
  const end = Math.min(page * pageSize, total)

  return (
    <div className="flex items-center justify-between border-t border-surface-800 px-4 py-3 text-sm text-ink-400">
      <span>
        Showing <span className="text-ink-200">{start}</span>–
        <span className="text-ink-200">{end}</span> of{' '}
        <span className="text-ink-200">{total}</span>
      </span>
      <div className="flex items-center gap-2">
        <button
          disabled={!canPrev}
          onClick={() => canPrev && onPageChange(page - 1)}
          className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" /> Prev
        </button>
        <span className="text-ink-200">
          Page {page} of {totalPages}
        </span>
        <button
          disabled={!canNext}
          onClick={() => canNext && onPageChange(page + 1)}
          className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
          aria-label="Next page"
        >
          Next <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
