import { Sun, Moon, Monitor } from 'lucide-react'
import { useThemeStore } from '../../store/themeStore'

const ICONS = { light: Sun, dark: Moon, system: Monitor }
const LABELS = { light: 'Light', dark: 'Dark', system: 'System' }
const NEXT_LABEL = { light: 'dark', dark: 'system', system: 'light' }

// A single button that cycles light -> dark -> system, rather than a 3-way
// segmented control — this is meant to live in a compact topbar/sidebar
// footer slot, and one click to the theme you actually want (of 3) is a
// fine trade for the space it saves.
export function ThemeToggle({ compact = false }) {
  const theme = useThemeStore((s) => s.theme)
  const cycleTheme = useThemeStore((s) => s.cycleTheme)
  const Icon = ICONS[theme] || Monitor

  return (
    <button
      type="button"
      onClick={cycleTheme}
      title={`Theme: ${LABELS[theme]} — click for ${NEXT_LABEL[theme]}`}
      aria-label={`Switch theme, currently ${LABELS[theme]}`}
      className={
        compact
          ? 'flex h-8 w-8 flex-none items-center justify-center rounded-md text-ink-400 hover:bg-surface-800 hover:text-ink-100'
          : 'flex items-center gap-2 rounded-md border border-surface-700 bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-200 hover:bg-surface-700'
      }
    >
      <Icon className="h-4 w-4" />
      {!compact && LABELS[theme]}
    </button>
  )
}
