// Shared pill-tab bar — Sessions/JIT/Admin pages all had their own
// hand-rolled copy of this; centralizing it means the active/inactive
// styling (and its light/dark contrast) is fixed in one place.
export function TabBar({ tabs, active, onChange }) {
  return (
    <div className="flex flex-wrap gap-1 rounded-md bg-surface-900 p-1">
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={
            'flex items-center gap-1.5 rounded px-3 py-1.5 text-sm font-medium transition-colors ' +
            (active === t.key
              ? 'bg-blue-600 text-white'
              : 'text-ink-400 hover:bg-surface-800 hover:text-ink-100')
          }
        >
          {t.icon && <t.icon className="h-3.5 w-3.5" />}
          {t.label}
          {typeof t.count === 'number' && (
            <span
              className={
                'ml-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-semibold ' +
                (active === t.key ? 'bg-white/20 text-white' : 'bg-surface-800 text-ink-400')
              }
            >
              {t.count}
            </span>
          )}
        </button>
      ))}
    </div>
  )
}
