import clsx from 'clsx'

// Thin, consistent wrappers around a labeled input/select/textarea plus its
// react-hook-form error message. Not a full form-library abstraction —
// deliberately dumb, so it's obvious what each field does.

export function Field({ label, error, hint, children, required }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-ink-300">
        {label}
        {required && <span className="ml-0.5 text-red-600 dark:text-red-400">*</span>}
      </label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
      {error && <p className="mt-1 text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  )
}

export const inputClass = (hasError) =>
  clsx(
    'w-full rounded-md border bg-surface-800 px-3 py-2 text-sm text-ink-50 placeholder:text-ink-500 focus:outline-none',
    hasError
      ? 'border-red-500/60 focus:border-red-400'
      : 'border-surface-700 focus:border-blue-500'
  )
