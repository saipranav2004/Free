import { AlertCircle, Inbox, RefreshCw } from 'lucide-react'
import { Spinner } from './Spinner'
import { apiErrorMessage } from '../../lib/apiError'

// Wraps the loading/error/empty/success branches every data-fetching view
// needs. This exists specifically to make it HARD to forget one of these
// states — a raw `{data.map(...)}` with no guard is exactly how a blank
// screen (loading), a silent no-op (error swallowed), or a crash (data is
// undefined on first render) sneaks into a component. Centralizing this
// means a fix to how errors render applies everywhere at once.
export function QueryState({
  query,
  empty, // optional: fn(data) => boolean — when true, renders emptyMessage instead of children
  emptyMessage = 'Nothing here yet.',
  loadingLabel = 'Loading…',
  children, // fn(data) => ReactNode
}) {
  if (query.isLoading) {
    return (
      <div className="flex items-center justify-center gap-2 py-16 text-ink-400">
        <Spinner /> <span className="text-sm">{loadingLabel}</span>
      </div>
    )
  }

  if (query.isError) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-lg border border-red-300 dark:border-red-900/40 bg-red-50 dark:bg-red-950/20 py-12 text-center">
        <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
        <p className="max-w-sm text-sm text-red-700 dark:text-red-300">{apiErrorMessage(query.error)}</p>
        <button
          onClick={() => query.refetch()}
          className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-50 hover:bg-surface-700"
        >
          <RefreshCw className="h-3.5 w-3.5" /> Retry
        </button>
      </div>
    )
  }

  const data = query.data
  const isEmpty = empty ? empty(data) : false

  if (isEmpty) {
    return (
      <div className="flex flex-col items-center gap-2 py-16 text-center text-ink-400">
        <Inbox className="h-6 w-6" />
        <p className="text-sm">{emptyMessage}</p>
      </div>
    )
  }

  return children(data)
}
