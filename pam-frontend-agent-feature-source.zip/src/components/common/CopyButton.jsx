import { useEffect, useRef, useState } from 'react'
import { Check, Copy } from 'lucide-react'

// navigator.clipboard.writeText() requires a secure context (HTTPS or
// localhost) and can reject silently in some embedded/iframe contexts —
// both handled here so a copy failure shows a clear fallback instead of
// just doing nothing when clicked (a real, reported class of bug: users
// clicking "Copy" repeatedly assuming they mis-clicked).
export function CopyButton({ value, label = 'Copy' }) {
  const [copied, setCopied] = useState(false)
  const [failed, setFailed] = useState(false)
  const timeoutRef = useRef(null)

  // Clear the pending "copied" reset timer on unmount so it doesn't call
  // setState on an unmounted component (React warns about this, and it's a
  // real memory-leak-shaped bug in a modal that can close before 1.5s pass).
  useEffect(() => () => clearTimeout(timeoutRef.current), [])

  const handleClick = async () => {
    setFailed(false)
    try {
      if (!navigator.clipboard) throw new Error('clipboard API unavailable')
      await navigator.clipboard.writeText(value)
      setCopied(true)
      timeoutRef.current = setTimeout(() => setCopied(false), 1500)
    } catch {
      setFailed(true)
      timeoutRef.current = setTimeout(() => setFailed(false), 2000)
    }
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className="inline-flex items-center gap-1.5 rounded-md border border-surface-700 bg-surface-800 px-2.5 py-1 text-xs font-medium text-ink-200 hover:bg-surface-700"
    >
      {copied ? (
        <>
          <Check className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" /> Copied
        </>
      ) : failed ? (
        <span className="text-red-700 dark:text-red-300">Copy failed — select manually</span>
      ) : (
        <>
          <Copy className="h-3.5 w-3.5" /> {label}
        </>
      )}
    </button>
  )
}
