import clsx from 'clsx'
import { Card } from './Layout'

// Dashboard tile — one number, one label, one icon. Deliberately not
// clickable-by-default (many stats, like "active breakglass grants", are
// informational, not always a drill-down); pass `to`/`onClick` via the
// `as`/wrapper pattern at the call site if a given tile should navigate.
export function StatCard({ label, value, icon: Icon, tone = 'default', hint, loading }) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-ink-400">{label}</p>
          <p className="mt-1.5 text-2xl font-semibold tabular-nums text-ink-50">
            {loading ? <span className="inline-block h-7 w-12 animate-pulse rounded bg-surface-800" /> : value}
          </p>
          {hint && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
        </div>
        {Icon && (
          <div
            className={clsx(
              'flex h-9 w-9 flex-none items-center justify-center rounded-lg',
              TONE_CLASSES[tone] || TONE_CLASSES.default
            )}
          >
            <Icon className="h-4.5 w-4.5" />
          </div>
        )}
      </div>
    </Card>
  )
}

const TONE_CLASSES = {
  default: 'bg-blue-100 text-blue-600 dark:bg-blue-500/15 dark:text-blue-300',
  amber: 'bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300',
  emerald: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300',
  red: 'bg-red-100 text-red-600 dark:bg-red-500/15 dark:text-red-300',
  purple: 'bg-purple-100 text-purple-600 dark:bg-purple-500/15 dark:text-purple-300',
}
