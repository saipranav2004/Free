import { http, extractFilename, triggerBlobDownload } from '../lib/http'

export async function searchAudit(filters, signal) {
  const params = {}
  for (const [k, v] of Object.entries(filters || {})) {
    if (v !== undefined && v !== null && v !== '') params[k] = v
  }
  const { data } = await http.get('/api/v1/pam/audit', { params, signal })
  return data.data // SearchResult { total, limit, offset, items }
}

export async function auditByRequest(requestId, signal) {
  const { data } = await http.get(`/api/v1/pam/audit/request/${requestId}`, { signal })
  return data.data // array
}

export async function auditByUser(userId, limit, signal) {
  const { data } = await http.get(`/api/v1/pam/audit/user/${userId}`, {
    params: limit ? { limit } : undefined,
    signal,
  })
  return data.data // array
}

export async function auditByResource(resourcePath, limit, signal) {
  // resourcePath can itself contain slashes (route is /audit/resource/*resource)
  const { data } = await http.get(`/api/v1/pam/audit/resource/${resourcePath}`, {
    params: limit ? { limit } : undefined,
    signal,
  })
  return data.data // array
}

// SPECIAL CASE: audit_handler.go's VerifyChain returns a bare
// VerificationResult (no {success,data} envelope) with HTTP 200 when the
// chain is broken, but the normal { success, data, message } envelope when
// it's intact. Both are 200s, so this can't be told apart by status code —
// only by whether `data.success` is present. Get this wrong and a broken
// audit chain silently renders as "undefined" instead of the alarm it
// should be.
export async function verifyAuditChain(orgId, signal) {
  const { data } = await http.get('/api/v1/pam/audit/verify', {
    params: orgId ? { org_id: orgId } : undefined,
    signal,
  })
  if (typeof data?.success === 'boolean') {
    return data.data // enveloped (chain intact) shape
  }
  return data // bare VerificationResult (chain broken) shape
}

// Returns a raw PDF/CSV binary, not JSON — download it directly rather than
// trying to parse it as a normal API response.
export async function generateComplianceReport(payload) {
  const response = await http.post('/api/v1/pam/audit/report', payload, {
    responseType: 'blob',
  })
  const ext = payload.format === 'csv' ? 'csv' : 'pdf'
  const filename = extractFilename(
    response.headers['content-disposition'],
    `pam-audit-report.${ext}`
  )
  triggerBlobDownload(response.data, filename)
  return { filename }
}
