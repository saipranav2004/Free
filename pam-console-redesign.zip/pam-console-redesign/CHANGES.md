# PAM Console — redesign drop

Drop-in replacement for the 17 files listed below. Copy each into the same
path in your project, overwriting the original. Nothing else needs to change.

## Verified, not just written

Every file here was checked with your actual toolchain, not eyeballed:
`npm run build` (vite build) after each change, `eslint src` on the full
tree at the end (zero errors, zero new warnings), plus one manual runtime
trace (see "Bugs caught" below) that neither tool would have flagged.

Colors are untouched — every class here is still `surface-*`/`ink-*` or the
existing status colors (blue/emerald/amber/red/purple). No new palette was
introduced anywhere.

## Files changed

**Foundation (used by every page automatically, zero page-level changes needed):**
- `tailwind.config.js` — elevation shadow scale (`shadow-card`/`raised`/`overlay`), motion tokens. No color changes.
- `src/index.css` — additive utility classes only (`.hairline-b`, `.nums`, `.skeleton-shimmer`).
- `src/components/common/Layout.jsx` — `Card` gets optional `elevated`/`interactive` props (default behavior unchanged); `PageHeader` gets optional `eyebrow`/`breadcrumbs` props; new `SectionLabel` export.
- `src/components/common/Badge.jsx` — optional `size`/`dot` props, default unchanged.
- `src/components/common/StatCard.jsx` — same props as before, refined visual treatment, optional `trend` prop (unused anywhere — no fake data, see note below).
- `src/components/common/FormFields.jsx` — same exports (`Field`, `inputClass`), refined focus/error styling.
- `src/components/common/Pagination.jsx` — same props, same edge-case handling, visual refinement only.
- `src/components/common/TabBar.jsx` — same props, visual refinement only.
- `src/components/common/QueryState.jsx` — same contract, error branch now distinguishes network failure from server error.
- `src/components/common/ConfirmDialog.jsx` — same contract, animation + stronger destructive-action treatment.
- `src/components/common/AppLayout.jsx` — collapsible sidebar (persisted to `localStorage`, key `pam_sidebar_collapsed` — pure UI preference, same non-sensitive pattern your own `themeStore.js` already uses for theme), animated mobile nav, breadcrumb-ready.
- `src/components/common/Table.jsx` — **new**. Table/Thead/Th/Tbody/Tr/Td primitives. Nothing imported this before, so adding it changes nothing until a page opts in.
- `src/components/resources/ResourceTypeIcon.jsx` — same API, optional `withBackground` prop for the new table rows.

**Flagship page conversions (full redesign, functionality byte-for-byte identical — same queries, same mutations, same query keys):**
- `src/pages/DashboardPage.jsx`
- `src/pages/sessions/SessionsPage.jsx` — list → real `<table>`
- `src/pages/admin/IdentityListPage.jsx` — list → real `<table>`
- `src/pages/jit/JitPage.jsx` — list → real `<table>` (both tabs)

## What this does NOT cover

I did not touch: Resources, Vault (all 4 pages), Audit, AdminOverview,
AdminJit, AdminAudit, Roles, Policies, IdentityDetail, ResourceDetail,
CredentialDetail, SafeDetail, Settings, Login, MfaVerify, or any of the
Create*Modal components. They'll pick up the Card/Badge/FormFields/AppLayout
visual refresh automatically (shared imports), but their lists are still
the old `<ul>/<li>` markup, not tables.

To convert one of those pages, the mechanical pattern is exactly what
SessionsPage/IdentityListPage/JitPage show:
1. Import `Table, Thead, Th, Tbody, Tr, Td` from `components/common/Table`.
2. Replace `<ul className="divide-y divide-surface-800">` with `<Table><Thead>...` and one `<Th>` per column you can name.
3. Replace each `<li>` with a `<Tr>`; wrap cell content in `<Td>`.
4. If the row was a `<Link>` wrapping everything, either keep the `Link` inside one `Td` (JitPage's pattern — use this when other interactive elements like buttons also live in the row) or use `Tr clickable onClick={...}` with `useNavigate` (SessionsPage/IdentityListPage's pattern — use this when the whole row is the only interactive element).
5. Do not touch the query, the mutation, or the data shape. Only the markup between `{() => ( ... )}` changes.
6. Run `npx eslint <file>` then `npm run build` before moving to the next page — this is not optional. Two real bugs surfaced during this exact loop on the four pages I did convert (a self-referencing prop default that would `ReferenceError` at runtime, and a Tailwind class-ordering conflict where `w-auto` silently lost to `w-full` in the compiled cascade) — neither was visible from reading the JSX, both were confirmed by actually building and, in the second case, inspecting the compiled CSS.

## On the `trend` prop on StatCard

It exists but nothing passes it. `admin/stats.go` (per your own audit)
returns point-in-time counts with no historical comparison, so there's no
real delta to show. I added the capability, not a number — do not fill it
with a placeholder value later without backend support, or you're back to
fake data on a security dashboard.
