/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Desaturated console palette — status colors (amber/red/emerald) do
        // the signaling, the base palette stays quiet so they stand out.
        //
        // THEME NOTE: every shade below is backed by a CSS custom property
        // (see src/index.css) rather than a literal hex value. `:root`
        // defines the LIGHT values, `.dark` overrides them with the
        // original dark-console values — so every existing class in the
        // app (`bg-surface-900`, `text-ink-400`, etc.) automatically
        // repaints for the active theme with zero per-component changes.
        // The `<alpha-value>` placeholder is Tailwind's own mechanism for
        // letting `bg-surface-900/50` opacity modifiers keep working against
        // an rgb()-triplet custom property.
        surface: {
          950: 'rgb(var(--surface-950) / <alpha-value>)',
          900: 'rgb(var(--surface-900) / <alpha-value>)',
          850: 'rgb(var(--surface-850) / <alpha-value>)',
          800: 'rgb(var(--surface-800) / <alpha-value>)',
          700: 'rgb(var(--surface-700) / <alpha-value>)',
          600: 'rgb(var(--surface-600) / <alpha-value>)',
        },
        ink: {
          50: 'rgb(var(--ink-50) / <alpha-value>)',
          200: 'rgb(var(--ink-200) / <alpha-value>)',
          400: 'rgb(var(--ink-400) / <alpha-value>)',
          500: 'rgb(var(--ink-500) / <alpha-value>)',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      boxShadow: {
        pop: '0 8px 30px -8px rgb(0 0 0 / 0.35)',
        // Enterprise elevation scale — used sparingly (raised cards, open
        // menus, modals) so it reads as intentional hierarchy rather than
        // "everything has a shadow." Numbers tuned to stay subtle in dark
        // mode (where large diffuse shadows just look like haze) and
        // slightly stronger in light mode via the `card` shadow below.
        xs: '0 1px 2px 0 rgb(0 0 0 / 0.04)',
        card: '0 1px 2px 0 rgb(0 0 0 / 0.03), 0 1px 1px 0 rgb(0 0 0 / 0.04)',
        raised: '0 4px 12px -2px rgb(0 0 0 / 0.08), 0 2px 4px -2px rgb(0 0 0 / 0.06)',
        overlay: '0 20px 40px -12px rgb(0 0 0 / 0.35), 0 8px 16px -8px rgb(0 0 0 / 0.2)',
      },
      keyframes: {
        'fade-in': { from: { opacity: 0 }, to: { opacity: 1 } },
        'scale-in': { from: { opacity: 0, transform: 'scale(0.97)' }, to: { opacity: 1, transform: 'scale(1)' } },
        'slide-in-right': { from: { transform: 'translateX(-100%)' }, to: { transform: 'translateX(0)' } },
        'slide-up': { from: { opacity: 0, transform: 'translateY(6px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
      },
      animation: {
        'fade-in': 'fade-in 150ms ease-out',
        'scale-in': 'scale-in 150ms ease-out',
        'slide-in-right': 'slide-in-right 220ms cubic-bezier(0.22, 1, 0.36, 1)',
        'slide-up': 'slide-up 180ms ease-out',
      },
    },
  },
  plugins: [],
}
