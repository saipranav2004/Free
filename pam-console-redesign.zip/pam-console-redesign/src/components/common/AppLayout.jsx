import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  LayoutDashboard, Boxes, Vault, Radio, KeyRound, ScrollText, ShieldAlert,
  LogOut, Settings as SettingsIcon, Users, Lock, FileKey2, ServerCog,
  ClipboardList, Archive, Menu, X, ChevronDown, PanelLeftClose, PanelLeftOpen,
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { me, logout as logoutApi } from '../../api/auth'
import { ROLE_BADGE } from '../../config/constants'
import { Badge } from './Badge'
import { ThemeToggle } from './ThemeToggle'
import { toast } from 'sonner'

// Self-service — visible to every authenticated user, regardless of role.
const CONSOLE_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/resources', label: 'Resources', icon: Boxes },
  { to: '/vault', label: 'Vault', icon: Vault },
  { to: '/sessions', label: 'Sessions', icon: Radio },
  { to: '/jit', label: 'JIT Access', icon: KeyRound },
  { to: '/audit', label: 'Audit', icon: ScrollText },
]

// Admin Center — only rendered for accounts holding the "admin" or "root"
// role (see AdminRoute for the matching route guard).
const ADMIN_NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/identity', label: 'Identity', icon: Users },
  { to: '/admin/roles', label: 'Roles', icon: Lock },
  { to: '/admin/policies', label: 'Policies', icon: FileKey2 },
  { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound },
  { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
  { to: '/admin/vault-ops', label: 'Vault Operations', icon: Archive },
]

// Sidebar collapse is a pure UI preference — same "not worth a Zustand
// store" reasoning as ThemeToggle's own persistence in themeStore.js, but
// deliberately NOT added there (store/ is functional/state-management code
// this task must not touch); it's local state to this component with a
// plain localStorage mirror, same non-sensitive persistence pattern.
const COLLAPSE_KEY = 'pam_sidebar_collapsed'

function readCollapsed() {
  try {
    return localStorage.getItem(COLLAPSE_KEY) === '1'
  } catch {
    return false
  }
}

function NavItem({ to, label, icon: Icon, end, onNavigate, collapsed }) {
  const item = (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      title={collapsed ? label : undefined}
      className={({ isActive }) =>
        clsx(
          'group relative flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors',
          collapsed && 'justify-center px-0',
          isActive
            ? 'bg-blue-600/10 text-blue-600 dark:bg-blue-500/10 dark:text-blue-300'
            : 'text-ink-400 hover:bg-surface-800 hover:text-ink-100'
        )
      }
    >
      {({ isActive }) => (
        <>
          {/* Active-route indicator — a filled bar rather than only a
              background tint, so the current section is unambiguous even
              at a glance (the audit flagged the plain bg-tint as "easy to
              miss"). */}
          <span
            className={clsx(
              'absolute left-0 top-1/2 h-4 w-0.5 -translate-y-1/2 rounded-r-full bg-blue-500 transition-opacity',
              isActive ? 'opacity-100' : 'opacity-0'
            )}
            aria-hidden="true"
          />
          <Icon className="h-4 w-4 flex-none" />
          {!collapsed && label}
        </>
      )}
    </NavLink>
  )
  return item
}

function SidebarContent({ isAdmin, onNavigate, collapsed }) {
  return (
    <>
      <div className={clsx('flex items-center gap-2 px-4 py-5', collapsed && 'justify-center px-2')}>
        <div className="flex h-7 w-7 flex-none items-center justify-center rounded-md bg-blue-600 text-white">
          <ServerCog className="h-4 w-4" />
        </div>
        {!collapsed && <h1 className="text-sm font-semibold tracking-wide text-ink-50">PAM CONSOLE</h1>}
      </div>

      <nav className={clsx('flex-1 space-y-4 overflow-y-auto overflow-x-hidden pb-4', collapsed ? 'px-2' : 'px-2')}>
        <div className="space-y-0.5">
          {CONSOLE_NAV.map((item) => (
            <NavItem key={item.to} {...item} onNavigate={onNavigate} collapsed={collapsed} />
          ))}
        </div>

        {isAdmin && (
          <div>
            <div className={clsx('flex items-center gap-1.5 px-3 pb-1.5 pt-2', collapsed && 'justify-center px-0')}>
              <ShieldAlert className="h-3 w-3 flex-none text-amber-500 dark:text-amber-400" />
              {!collapsed && (
                <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">
                  Admin Center
                </span>
              )}
            </div>
            <div className="space-y-0.5">
              {ADMIN_NAV.map((item) => (
                <NavItem key={item.to} {...item} onNavigate={onNavigate} collapsed={collapsed} />
              ))}
            </div>
          </div>
        )}
      </nav>
    </>
  )
}

export function AppLayout() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const setUser = useAuthStore((s) => s.setUser)
  const doLogout = useAuthStore((s) => s.logout)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(readCollapsed)

  const toggleCollapsed = () => {
    setCollapsed((prev) => {
      const next = !prev
      try {
        localStorage.setItem(COLLAPSE_KEY, next ? '1' : '0')
      } catch {
        /* private-browsing etc — non-fatal, just won't persist */
      }
      return next
    })
  }

  // /auth/me is the source of truth for "who am I" — login only returns
  // access_token/expires_at, not the user's profile, so this fetch is what
  // actually populates the header/username/roles rather than showing blank
  // (and is also what AdminRoute/the nav's isAdmin() check depends on).
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal), retry: false })

  useEffect(() => {
    if (meQuery.data) setUser(meQuery.data)
  }, [meQuery.data, setUser])

  const handleLogout = async () => {
    try {
      await logoutApi()
    } catch {
      // Even if the server-side logout call fails (network blip, already
      // expired token), we still clear the local session below — a failed
      // logout call must never leave the user stuck "logged in" client-side
      // when they explicitly asked to log out.
    } finally {
      doLogout()
      navigate('/login', { replace: true })
      toast.success('Logged out')
    }
  }

  const roles = user?.roles || []

  return (
    // h-screen + overflow-hidden pins this whole shell to exactly the
    // viewport height so the browser's own document scrollbar never kicks
    // in; only <main> below scrolls internally.
    <div className="flex h-screen overflow-hidden bg-surface-950">
      {/* Desktop sidebar — width driven by `collapsed`, animated so the
          toggle reads as a deliberate transition rather than a jump cut. */}
      <aside
        className={clsx(
          'hidden flex-none flex-col border-r border-surface-800 bg-surface-900 transition-[width] duration-200 ease-out md:flex',
          collapsed ? 'w-[68px]' : 'w-60'
        )}
      >
        <SidebarContent isAdmin={isAdmin} onNavigate={() => {}} collapsed={collapsed} />
        <SidebarFooter
          user={user}
          roles={roles}
          loadingUser={meQuery.isLoading}
          onLogout={handleLogout}
          collapsed={collapsed}
        />
        <button
          onClick={toggleCollapsed}
          className="flex items-center justify-center gap-2 border-t border-surface-800 py-2.5 text-xs font-medium text-ink-500 transition-colors hover:bg-surface-800 hover:text-ink-200"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <PanelLeftOpen className="h-4 w-4" /> : (
            <>
              <PanelLeftClose className="h-4 w-4" /> Collapse
            </>
          )}
        </button>
      </aside>

      {/* Mobile sidebar (overlay) — animated slide-in rather than an
          instant appear/disappear (audit item: "no slide-in transition"). */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/50 animate-fade-in"
            onClick={() => setMobileNavOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative flex w-64 flex-col border-r border-surface-800 bg-surface-900 shadow-overlay animate-slide-in-right">
            <button
              onClick={() => setMobileNavOpen(false)}
              className="absolute right-3 top-4 text-ink-400 hover:text-ink-100"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent isAdmin={isAdmin} onNavigate={() => setMobileNavOpen(false)} collapsed={false} />
            <SidebarFooter
              user={user}
              roles={roles}
              loadingUser={meQuery.isLoading}
              onLogout={handleLogout}
              collapsed={false}
            />
          </aside>
        </div>
      )}

      {/* min-h-0 overrides flex's default min-height:auto — without it, a
          flex child (main, below) can't shrink below its content height,
          so overflow-y-auto never actually engages. */}
      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="flex h-14 flex-none items-center gap-3 border-b border-surface-800 bg-surface-900/70 px-4 backdrop-blur md:justify-end">
          <button
            onClick={() => setMobileNavOpen(true)}
            className="text-ink-400 hover:text-ink-100 md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <span className="flex-1 text-sm font-medium text-ink-50 md:hidden">PAM Console</span>

          <ThemeToggle compact />

          <div className="relative">
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-ink-200 transition-colors hover:bg-surface-800"
            >
              <span className="flex h-6 w-6 flex-none items-center justify-center rounded-full bg-blue-600/15 text-[11px] font-semibold text-blue-600 dark:text-blue-300">
                {(user?.username || '?').slice(0, 1).toUpperCase()}
              </span>
              <span className="hidden max-w-[10rem] truncate sm:inline" title={user?.username}>
                {user?.username || (meQuery.isLoading ? '…' : 'Signed in')}
              </span>
              <ChevronDown className="h-3.5 w-3.5 text-ink-500" />
            </button>
            {userMenuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
                <div className="absolute right-0 z-20 mt-1 w-48 animate-scale-in rounded-lg border border-surface-700 bg-surface-900 py-1 shadow-overlay">
                  <div className="border-b border-surface-800 px-3 py-2">
                    <p className="truncate text-sm font-medium text-ink-50">{user?.username}</p>
                    <p className="truncate text-xs text-ink-500">{user?.email}</p>
                  </div>
                  <NavLink
                    to="/settings"
                    onClick={() => setUserMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-ink-200 transition-colors hover:bg-surface-800"
                  >
                    <SettingsIcon className="h-3.5 w-3.5" /> Settings
                  </NavLink>
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-red-600 transition-colors hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                  >
                    <LogOut className="h-3.5 w-3.5" /> Log out
                  </button>
                </div>
              </>
            )}
          </div>
        </header>

        <main className="min-w-0 flex-1 overflow-y-auto">
          <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}

function SidebarFooter({ user, roles, loadingUser, onLogout, collapsed }) {
  if (collapsed) {
    return (
      <div className="border-t border-surface-800 p-2">
        <button
          onClick={onLogout}
          className="flex w-full items-center justify-center rounded-md p-2 text-ink-500 transition-colors hover:bg-surface-800 hover:text-red-500 dark:hover:text-red-400"
          title="Log out"
          aria-label="Log out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    )
  }

  return (
    <div className="border-t border-surface-800 p-3">
      <div className="flex items-center justify-between gap-2 rounded-md px-1 py-1">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-ink-200" title={user?.username}>
            {user?.username || (loadingUser ? '…' : 'Signed in')}
          </p>
          <div className="mt-1 flex flex-wrap gap-1">
            {roles.length === 0 && !loadingUser && (
              <Badge size="sm" className="bg-ink-500/15 text-ink-500 ring-ink-500/30">no roles</Badge>
            )}
            {roles.map((r) => (
              <Badge key={r} size="sm" className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                {r}
              </Badge>
            ))}
          </div>
        </div>
        <button
          onClick={onLogout}
          className="flex-none rounded-md p-1.5 text-ink-500 transition-colors hover:bg-surface-800 hover:text-red-500 dark:hover:text-red-400"
          title="Log out"
          aria-label="Log out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
