import { AlertCircle, Inbox, RefreshCw, WifiOff } from 'lucide-react'
import { Spinner } from './Spinner'
import { apiErrorMessage } from '../../lib/apiError'

// Wraps the loading/error/empty/success branches every data-fetching view
// needs. Same contract as before: { query, empty?, emptyMessage?,
// loadingLabel?, children: fn(data) => node }. Visual refinement only —
// the error branch now distinguishes a network failure (no response at
// all) from a server-returned error, since "check your connection" is
// only ever correct advice for the former.
export function QueryState({
  query,
  empty,
  emptyMessage = 'Nothing here yet.',
  loadingLabel = 'Loading…',
  children,
}) {
  if (query.isLoading) {
    return (
      <div className="flex items-center justify-center gap-2 py-16 text-ink-400">
        <Spinner /> <span className="text-sm">{loadingLabel}</span>
      </div>
    )
  }

  if (query.isError) {
    const isNetworkError = !query.error?.response
    return (
      <div className="flex flex-col items-center gap-3 rounded-lg border border-red-300 bg-red-50 py-12 text-center dark:border-red-900/40 dark:bg-red-950/20">
        {isNetworkError ? (
          <WifiOff className="h-6 w-6 text-red-600 dark:text-red-400" />
        ) : (
          <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
        )}
        <div>
          <p className="max-w-sm text-sm font-medium text-red-700 dark:text-red-300">
            {apiErrorMessage(query.error)}
          </p>
          {isNetworkError && (
            <p className="mt-1 text-xs text-red-600/80 dark:text-red-400/70">Check your network connection and try again.</p>
          )}
        </div>
        <button
          onClick={() => query.refetch()}
          className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-50 transition-colors hover:bg-surface-700"
        >
          <RefreshCw className="h-3.5 w-3.5" /> Retry
        </button>
      </div>
    )
  }

  const data = query.data
  const isEmpty = empty ? empty(data) : false

  if (isEmpty) {
    return (
      <div className="flex flex-col items-center gap-2 py-16 text-center text-ink-400">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-surface-800">
          <Inbox className="h-5 w-5" />
        </div>
        <p className="text-sm">{emptyMessage}</p>
      </div>
    )
  }

  return children(data)
}
