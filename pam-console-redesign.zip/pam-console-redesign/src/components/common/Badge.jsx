import clsx from 'clsx'

// Every status badge in the app goes through this one component, so a
// design tweak is a one-file change. `className` still carries the
// semantic color (unchanged — every call site's color map in
// config/constants.js is untouched); this only adds an optional `size` and
// `dot` for the compact/dense contexts the audit flagged (dense tables,
// inline metadata) without changing the default rendering anyone already
// relies on.
export function Badge({ children, className, size = 'md', dot = false }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 rounded-full font-medium ring-1 ring-inset',
        size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-0.5 text-xs',
        className || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'
      )}
    >
      {dot && <span className="h-1.5 w-1.5 flex-none rounded-full bg-current" aria-hidden="true" />}
      {children}
    </span>
  )
}
