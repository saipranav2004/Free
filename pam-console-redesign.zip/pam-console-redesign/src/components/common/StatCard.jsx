import clsx from 'clsx'
import { TrendingUp, TrendingDown } from 'lucide-react'
import { Card } from './Layout'

// Dashboard tile. API is unchanged from the original component
// (label/value/icon/tone/hint/loading) — every existing call site in
// DashboardPage.jsx and AdminOverviewPage.jsx renders exactly as before.
//
// `trend` is new and strictly optional: pass { direction: 'up' | 'down',
// label: '...' } only where a real, backend-sourced delta exists. Nothing
// in this codebase currently has that data (admin/stats.go returns point-
// in-time counts, no historical comparison), so no call site passes it and
// no trend arrow renders anywhere — this is capacity for when that data
// exists, not a fabricated indicator.
export function StatCard({ label, value, icon: Icon, tone = 'default', hint, loading, trend }) {
  const tones = TONE_CLASSES[tone] || TONE_CLASSES.default
  return (
    <Card className="relative overflow-hidden p-4">
      <span className={clsx('absolute inset-y-0 left-0 w-0.5', tones.bar)} aria-hidden="true" />
      <div className="flex items-start justify-between gap-3 pl-1.5">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-ink-400">{label}</p>
          <p className="mt-1.5 nums text-2xl font-semibold text-ink-50">
            {loading ? (
              <span className="skeleton-shimmer inline-block h-7 w-14 rounded" />
            ) : (
              value
            )}
          </p>
          {!loading && trend && (
            <p
              className={clsx(
                'mt-1.5 flex items-center gap-1 text-xs font-medium',
                trend.direction === 'down' ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'
              )}
            >
              {trend.direction === 'down' ? (
                <TrendingDown className="h-3 w-3" />
              ) : (
                <TrendingUp className="h-3 w-3" />
              )}
              {trend.label}
            </p>
          )}
          {hint && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
        </div>
        {Icon && (
          <div className={clsx('flex h-9 w-9 flex-none items-center justify-center rounded-lg', tones.icon)}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        )}
      </div>
    </Card>
  )
}

const TONE_CLASSES = {
  default: {
    icon: 'bg-blue-100 text-blue-600 dark:bg-blue-500/15 dark:text-blue-300',
    bar: 'bg-blue-500/60',
  },
  amber: {
    icon: 'bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300',
    bar: 'bg-amber-500/60',
  },
  emerald: {
    icon: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300',
    bar: 'bg-emerald-500/60',
  },
  red: {
    icon: 'bg-red-100 text-red-600 dark:bg-red-500/15 dark:text-red-300',
    bar: 'bg-red-500/60',
  },
  purple: {
    icon: 'bg-purple-100 text-purple-600 dark:bg-purple-500/15 dark:text-purple-300',
    bar: 'bg-purple-500/60',
  },
}
