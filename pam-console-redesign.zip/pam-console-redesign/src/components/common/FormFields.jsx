import clsx from 'clsx'

// Thin, consistent wrappers around a labeled input/select/textarea plus its
// react-hook-form error message. Exports (`Field`, `inputClass`) and their
// signatures are unchanged — every modal/form in the app calls these the
// same way; only the resulting classNames are refined for a more
// enterprise input treatment (subtler resting border, clearer focus,
// consistent error state).

export function Field({ label, error, hint, children, required }) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium text-ink-300">
        {label}
        {required && <span className="ml-0.5 text-red-600 dark:text-red-400">*</span>}
      </label>
      {children}
      {hint && !error && <p className="mt-1.5 text-xs text-ink-500">{hint}</p>}
      {error && <p className="mt-1.5 text-xs font-medium text-red-600 dark:text-red-400">{error}</p>}
    </div>
  )
}

export const inputClass = (hasError) =>
  clsx(
    'w-full rounded-md border bg-surface-800 px-3 py-2 text-sm text-ink-50 placeholder:text-ink-500',
    'transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-blue-500/25',
    hasError
      ? 'border-red-500/60 focus:border-red-400'
      : 'border-surface-700 hover:border-surface-600 focus:border-blue-500'
  )

// Additive: several pages (Audit, admin Audit) currently define their own
// local `const selectClass = ...` per the audit's consistency finding.
// This export gives them a shared target to migrate to later without
// forcing that migration here — no existing file imports it yet, so this
// change alone affects nothing.
export const selectClass = (hasError) => inputClass(hasError)
