import { useState, useId } from 'react'
import { AlertTriangle, X } from 'lucide-react'
import { Spinner } from './Spinner'

// Same contract as before: { open, title, description, confirmLabel,
// destructive, requireReason, reasonLabel, isLoading, onConfirm, onCancel }.
// Visual refinement only — adds an entrance animation and a stronger
// destructive-action treatment (the audit specifically called out
// "destructive-action clarity" as a modal requirement).
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  destructive = true,
  requireReason = false,
  reasonLabel = 'Reason',
  isLoading = false,
  onConfirm,
  onCancel,
}) {
  const [reason, setReason] = useState('')
  const titleId = useId()

  if (!open) return null

  const canConfirm = !requireReason || reason.trim().length > 0

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
      onKeyDown={(e) => {
        if (e.key === 'Escape' && !isLoading) onCancel()
      }}
    >
      <div className="w-full max-w-md rounded-xl border border-surface-700 bg-surface-900 p-5 shadow-overlay animate-scale-in">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            {destructive && (
              <span className="flex h-9 w-9 flex-none items-center justify-center rounded-full bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
                <AlertTriangle className="h-4.5 w-4.5" />
              </span>
            )}
            <div>
              <h3 id={titleId} className="text-sm font-semibold text-ink-50">
                {title}
              </h3>
              {description && <p className="mt-1 text-sm leading-relaxed text-ink-400">{description}</p>}
            </div>
          </div>
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="flex-none rounded-md p-1 text-ink-500 transition-colors hover:bg-surface-800 hover:text-ink-200 disabled:opacity-40"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {requireReason && (
          <div className="mt-4">
            <label className="mb-1.5 block text-xs font-medium text-ink-400">{reasonLabel}</label>
            <textarea
              autoFocus
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full rounded-md border border-surface-700 bg-surface-800 px-3 py-2 text-sm text-ink-50 placeholder:text-ink-500 transition-colors focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/25"
              placeholder="Required — recorded in the audit log"
            />
          </div>
        )}

        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="rounded-md px-3 py-1.5 text-sm font-medium text-ink-300 transition-colors hover:bg-surface-800 disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirm(reason.trim())}
            disabled={!canConfirm || isLoading}
            className={
              'flex items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium text-white shadow-xs transition-colors disabled:pointer-events-none disabled:opacity-40 ' +
              (destructive ? 'bg-red-600 hover:bg-red-500' : 'bg-blue-600 hover:bg-blue-500')
            }
          >
            {isLoading && <Spinner size="h-3.5 w-3.5" className="text-white" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
