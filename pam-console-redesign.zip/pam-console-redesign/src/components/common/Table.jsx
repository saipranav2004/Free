import clsx from 'clsx'

// Enterprise table primitives. This is new — the audit's single biggest,
// most-repeated finding was "no actual tables anywhere, everything is a
// styled <ul>," which loses column headers, alignment, and sort
// affordances. This file is purely additive: nothing in the app imported a
// `Table` before, so adding it changes nothing until a page opts in
// (SessionsPage does, as the reference conversion — see that file for the
// pattern to repeat on the other list pages).
//
// Deliberately NOT a data-grid abstraction (no built-in sorting/virtualization)
// — every list here is backend-paginated already (Pagination.jsx), so a
// client-side sort would only sort the current page, which is worse than no
// sort at all. `sortable`/`sortDir` are visual-only affordances a page can
// wire up to its own query params if/when the backend supports it.

export function Table({ children, className = '' }) {
  return (
    <div className="overflow-x-auto">
      <table className={clsx('w-full border-collapse text-sm', className)}>{children}</table>
    </div>
  )
}

export function Thead({ children }) {
  return <thead className="hairline-b bg-surface-850/60">{children}</thead>
}

export function Th({ children, align = 'left', className = '', sortable = false, sortDir, onSort }) {
  const content = (
    <span className={clsx('inline-flex items-center gap-1', align === 'right' && 'justify-end')}>
      {children}
      {sortable && (
        <span className="text-ink-600" aria-hidden="true">
          {sortDir === 'asc' ? '▲' : sortDir === 'desc' ? '▼' : '⇅'}
        </span>
      )}
    </span>
  )
  return (
    <th
      scope="col"
      className={clsx(
        'whitespace-nowrap px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-ink-500',
        align === 'right' ? 'text-right' : 'text-left',
        sortable && 'cursor-pointer select-none hover:text-ink-300',
        className
      )}
      onClick={sortable ? onSort : undefined}
      aria-sort={sortable ? (sortDir === 'asc' ? 'ascending' : sortDir === 'desc' ? 'descending' : 'none') : undefined}
    >
      {content}
    </th>
  )
}

export function Tbody({ children }) {
  return <tbody className="divide-y divide-surface-800">{children}</tbody>
}

// `clickable` renders the row with hover/focus affordance and keyboard
// activation — use for rows that navigate to a detail page (matches the
// existing pattern where some list rows were <Link>, others <button>; this
// gives one consistent, accessible implementation to standardize on).
export function Tr({ children, className = '', clickable = false, onClick }) {
  return (
    <tr
      className={clsx(
        'transition-colors',
        clickable && 'cursor-pointer hover:bg-surface-850 focus-within:bg-surface-850',
        className
      )}
      onClick={clickable ? onClick : undefined}
      tabIndex={clickable ? 0 : undefined}
      role={clickable ? 'button' : undefined}
      onKeyDown={
        clickable
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                onClick?.(e)
              }
            }
          : undefined
      }
    >
      {children}
    </tr>
  )
}

export function Td({ children, align = 'left', className = '' }) {
  return (
    <td className={clsx('px-4 py-3 align-middle', align === 'right' && 'text-right', className)}>
      {children}
    </td>
  )
}

// Loading skeleton rows — same row/column geometry as real data so the
// table doesn't reflow once results arrive. `columns` should match the
// number of <Th> in the header.
export function TableSkeleton({ columns = 4, rows = 5 }) {
  return (
    <>
      {Array.from({ length: rows }).map((_, r) => (
        <tr key={r}>
          {Array.from({ length: columns }).map((_, c) => (
            <td key={c} className="px-4 py-3">
              <span className="skeleton-shimmer inline-block h-4 w-full max-w-[10rem] rounded" />
            </td>
          ))}
        </tr>
      ))}
    </>
  )
}
