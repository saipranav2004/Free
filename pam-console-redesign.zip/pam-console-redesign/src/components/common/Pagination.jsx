import { ChevronLeft, ChevronRight } from 'lucide-react'

// Same contract as before: { page, pageSize, total, totalPages, onPageChange }.
// Same edge-case handling (renders nothing at <=1 page, bounds-checked
// prev/next). Visual refinement only — clearer button affordance, tabular
// numerals so the "Page X of Y" text doesn't jitter in width as it updates.
export function Pagination({ page, pageSize, total, totalPages, onPageChange }) {
  if (!totalPages || totalPages <= 1) return null

  const canPrev = page > 1
  const canNext = page < totalPages
  const start = total === 0 ? 0 : (page - 1) * pageSize + 1
  const end = Math.min(page * pageSize, total)

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-surface-800 px-4 py-3 text-sm text-ink-400">
      <span className="nums">
        Showing <span className="font-medium text-ink-200">{start}</span>–
        <span className="font-medium text-ink-200">{end}</span> of{' '}
        <span className="font-medium text-ink-200">{total}</span>
      </span>
      <div className="flex items-center gap-1">
        <button
          disabled={!canPrev}
          onClick={() => canPrev && onPageChange(page - 1)}
          className="flex items-center gap-1 rounded-md border border-surface-700 px-2.5 py-1.5 text-xs font-medium text-ink-200 transition-colors hover:border-surface-600 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
          aria-label="Previous page"
        >
          <ChevronLeft className="h-3.5 w-3.5" /> Prev
        </button>
        <span className="nums px-2 text-ink-200">
          Page {page} of {totalPages}
        </span>
        <button
          disabled={!canNext}
          onClick={() => canNext && onPageChange(page + 1)}
          className="flex items-center gap-1 rounded-md border border-surface-700 px-2.5 py-1.5 text-xs font-medium text-ink-200 transition-colors hover:border-surface-600 hover:bg-surface-800 disabled:pointer-events-none disabled:opacity-30"
          aria-label="Next page"
        >
          Next <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  )
}
