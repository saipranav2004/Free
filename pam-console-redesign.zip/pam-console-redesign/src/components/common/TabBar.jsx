// Shared pill-tab bar. Same props as before: { tabs, active, onChange }
// where each tab is { key, label, icon?, count? }. Visual refinement only.
export function TabBar({ tabs, active, onChange }) {
  return (
    <div className="inline-flex flex-wrap gap-1 rounded-lg border border-surface-800 bg-surface-900 p-1">
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={
            'flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ' +
            (active === t.key
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-ink-400 hover:bg-surface-800 hover:text-ink-100')
          }
        >
          {t.icon && <t.icon className="h-3.5 w-3.5" />}
          {t.label}
          {typeof t.count === 'number' && (
            <span
              className={
                'nums ml-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-semibold ' +
                (active === t.key ? 'bg-white/20 text-white' : 'bg-surface-800 text-ink-400')
              }
            >
              {t.count}
            </span>
          )}
        </button>
      ))}
    </div>
  )
}
