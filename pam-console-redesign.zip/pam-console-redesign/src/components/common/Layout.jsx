import { Fragment } from 'react'
import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'
import clsx from 'clsx'

// PageHeader
// -----------------------------------------------------------------------
// `eyebrow` and `breadcrumbs` are new, optional props — every existing call
// site (`<PageHeader title="..." description="..." actions={...} />`) is
// untouched and renders exactly as before. Detail pages can now pass
// `breadcrumbs={[{ label: 'Identity', to: '/admin/identity' }, { label: user.username }]}`
// to get the trail the audit flagged as missing, without every page being
// forced to adopt it.
export function PageHeader({ title, description, actions, eyebrow, breadcrumbs }) {
  return (
    <div className="mb-6">
      {breadcrumbs && breadcrumbs.length > 0 && (
        <nav aria-label="Breadcrumb" className="mb-2 flex items-center gap-1.5 text-xs text-ink-500">
          {breadcrumbs.map((crumb, i) => {
            const isLast = i === breadcrumbs.length - 1
            return (
              <Fragment key={`${crumb.label}-${i}`}>
                {i > 0 && <ChevronRight className="h-3 w-3 flex-none text-ink-600" aria-hidden="true" />}
                {crumb.to && !isLast ? (
                  <Link to={crumb.to} className="truncate hover:text-ink-200">
                    {crumb.label}
                  </Link>
                ) : (
                  <span className={clsx('truncate', isLast && 'font-medium text-ink-400')} aria-current={isLast ? 'page' : undefined}>
                    {crumb.label}
                  </span>
                )}
              </Fragment>
            )
          })}
        </nav>
      )}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          {eyebrow && (
            <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-ink-500">{eyebrow}</p>
          )}
          <h1 className="text-xl font-semibold tracking-tight text-ink-50">{title}</h1>
          {description && <p className="mt-1 max-w-2xl text-sm leading-relaxed text-ink-400">{description}</p>}
        </div>
        {actions && <div className="flex flex-none flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </div>
  )
}

// Card
// -----------------------------------------------------------------------
// Signature is unchanged: `Card({ children, className })` still works
// exactly as every existing call site uses it (a bare border container).
// Two new, opt-in props give the "elevation hierarchy" and "interactive
// card" treatments the audit asked for, without touching any page that
// doesn't pass them:
//   - elevated: adds the `raised` shadow token for content that should read
//     as more important (e.g. break-glass banners, chain-verification card)
//   - interactive: adds hover/focus affordances for cards that act as links
//     (dashboard quick-links already did this ad hoc via className; this
//     centralizes it, existing className-based hover styles still work too)
export function Card({ children, className = '', elevated = false, interactive = false }) {
  return (
    <div
      className={clsx(
        'rounded-lg border border-surface-800 bg-surface-900',
        elevated ? 'shadow-raised' : 'shadow-card',
        interactive &&
          'transition-all duration-150 hover:-translate-y-px hover:border-surface-600 hover:shadow-raised focus-within:border-blue-500/50',
        className
      )}
    >
      {children}
    </div>
  )
}

export function CardHeader({ children, className = '' }) {
  return (
    <div className={clsx('border-b border-surface-800 px-4 py-3.5', className)}>
      {children}
    </div>
  )
}

// New, purely additive: a small-caps section label for grouping content
// inside a Card (e.g. "Profile", "Roles", "Access") — the audit called out
// "no section headings between page title and body text" as a hierarchy
// gap. Nothing existing imports this yet, so it changes nothing by itself.
export function SectionLabel({ children, className = '' }) {
  return (
    <h2 className={clsx('text-[11px] font-semibold uppercase tracking-wider text-ink-500', className)}>
      {children}
    </h2>
  )
}
