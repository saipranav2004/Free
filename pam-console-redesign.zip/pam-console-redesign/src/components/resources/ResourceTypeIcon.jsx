import {
  Database, Layers, Zap, Archive, Search as SearchIcon, BarChart3, Activity, Globe, Boxes,
} from 'lucide-react'
import clsx from 'clsx'

const ICONS = {
  postgresql: { Icon: Database, className: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-500/10' },
  mongodb: { Icon: Layers, className: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-100 dark:bg-emerald-500/10' },
  redis: { Icon: Zap, className: 'text-red-600 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-500/10' },
  clickhouse: { Icon: Activity, className: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-500/10' },
  minio: { Icon: Archive, className: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-100 dark:bg-orange-500/10' },
  qdrant: { Icon: SearchIcon, className: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-100 dark:bg-purple-500/10' },
  metabase: { Icon: BarChart3, className: 'text-yellow-600 dark:text-yellow-400', bg: 'bg-yellow-100 dark:bg-yellow-500/10' },
  langfuse: { Icon: Activity, className: 'text-pink-600 dark:text-pink-400', bg: 'bg-pink-100 dark:bg-pink-500/10' },
  web: { Icon: Globe, className: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-100 dark:bg-sky-500/10' },
  oracle: { Icon: Database, className: 'text-red-600 dark:text-red-500', bg: 'bg-red-100 dark:bg-red-500/10' },
}

// Same API as before: `<ResourceTypeIcon type={...} className="h-4 w-4" />`
// still renders a bare, correctly-colored icon everywhere it's already
// used inline in text rows. `withBackground` is new and opt-in — it wraps
// the icon in the small rounded container the audit asked for ("consider
// adding a background container for more visual weight"), used by the new
// Table-based rows without changing any existing call site's markup.
export function ResourceTypeIcon({ type, className = 'h-4 w-4', withBackground = false }) {
  const entry = ICONS[type] || { Icon: Boxes, className: 'text-ink-400', bg: 'bg-surface-800' }
  const { Icon, className: colorClass, bg } = entry

  if (!withBackground) {
    return <Icon className={`${className} ${colorClass}`} />
  }

  return (
    <span className={clsx('flex h-8 w-8 flex-none items-center justify-center rounded-md', bg)}>
      <Icon className={clsx('h-4 w-4', colorClass)} />
    </span>
  )
}
