import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { Plus, ChevronRight, Search } from 'lucide-react'
import { listUsers } from '../../api/identity'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { inputClass } from '../../components/common/FormFields'
import { Table, Thead, Th, Tbody, Tr, Td } from '../../components/common/Table'
import { CreateUserModal } from '../../components/admin/CreateUserModal'
import { USER_STATUS_BADGE, SEARCH_DEBOUNCE_MS } from '../../config/constants'

export default function IdentityListPage() {
  const navigate = useNavigate()
  const [createOpen, setCreateOpen] = useState(false)
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')

  // Debounce the free-text search so it doesn't fire a request per keystroke —
  // the input updates immediately for responsiveness, the query key only
  // picks up `search` after SEARCH_DEBOUNCE_MS of no further typing.
  // Unchanged from the pre-redesign version.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })

  return (
    <div>
      <PageHeader
        eyebrow="Admin Center"
        title="Identity"
        description="User accounts in this PAM install — create, disable, lock, or delete, and manage RBAC role/policy assignment."
        actions={
          <button
            onClick={() => setCreateOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white shadow-xs transition-colors hover:bg-blue-500"
          >
            <Plus className="h-4 w-4" /> Create user
          </button>
        }
      />

      <Card className="mb-4">
        <div className="px-4 py-3">
          <div className="relative max-w-xs">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500" />
            <input
              className={inputClass(false) + ' pl-9'}
              placeholder="Search username or email…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
            />
          </div>
        </div>
      </Card>

      <QueryState
        query={usersQuery}
        empty={(data) => !data?.users || data.users.length === 0}
        emptyMessage="No users found."
      >
        {(data) => (
          <Card>
            <Table>
              <Thead>
                <tr>
                  <Th>User</Th>
                  <Th>Status</Th>
                  <Th align="right" className="w-10" />
                </tr>
              </Thead>
              <Tbody>
                {data.users.map((u) => (
                  <Tr key={u.user_id} clickable onClick={() => navigate(`/admin/identity/${u.user_id}`)}>
                    <Td>
                      <p className="text-sm font-medium text-ink-100">{u.username}</p>
                      <p className="text-xs text-ink-500">
                        {u.email}
                        {u.full_name ? ` · ${u.full_name}` : ''}
                      </p>
                    </Td>
                    <Td>
                      <Badge size="sm" dot className={USER_STATUS_BADGE[u.status] || undefined}>
                        {u.status || 'UNKNOWN'}
                      </Badge>
                    </Td>
                    <Td align="right">
                      <ChevronRight className="ml-auto h-4 w-4 text-ink-600" />
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Card>
        )}
      </QueryState>

      <CreateUserModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
