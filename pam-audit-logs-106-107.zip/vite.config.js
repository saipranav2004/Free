import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The Flask IAM backend listens on :5000. During development we proxy the
// API + JWKS paths so cookies/CSP/origin are never an issue. For production
// builds set VITE_API_BASE_URL to your gateway and remove the proxy.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:5000', changeOrigin: true },
      '/well-known': { target: 'http://localhost:5000', changeOrigin: true },

      // ═════════════════════════════════════════════════════════════════════
      // AdapID (IDP) — SEPARATE service on its own host.
      // ═════════════════════════════════════════════════════════════════════
      // BUG FIX — `{"data":null,"error":"Missing token","success":false}` on a
      // hard reload of an IDP page.
      //
      // This proxy used to be mounted on '/idp', which is ALSO the SPA's own
      // route namespace (/idp/overview, /idp/tenants). The two cannot share a
      // prefix:
      //
      //   · SPA navigation  → no document request, React Router renders the
      //                       page, XHRs to /idp/api/* are proxied. Works.
      //   · F5 / hard reload → the browser asks the dev server for the DOCUMENT
      //                       at /idp/overview. The proxy matched first and
      //                       forwarded it to AdapID, which answered its own
      //                       JSON error ("Missing token") instead of index.html
      //                       — the raw payload seen in the browser.
      //
      // The API prefix is therefore moved to '/idp-api', which no client route
      // can ever collide with. `rewrite` still strips it, because the client
      // requests /idp-api/api/tenants and the service exposes /api/tenants.
      // Mirrored in nginx.conf for production (location /idp-api/).
      // ═════════════════════════════════════════════════════════════════════
      // PAM compliance service — a THIRD backend, on its own port.
      // ═════════════════════════════════════════════════════════════════════
      //   IAM backend        :5000  → '/api'
      //   AdapID (IDP)       remote → '/idp-api'
      //   PAM compliance     :8080  → '/pam-api'   (this block)
      //
      // Its routes are '/api/v1/pam/audit...', which the '/api' proxy above
      // already claims, so without a prefix of its own every call would be sent
      // to the IAM backend and answered with a 404 that looks like a missing
      // feature rather than a misrouted request.
      //
      // The prefix is '/pam-api' and NOT '/pam' for the reason documented on
      // the IDP block below: '/pam/*' is the SPA's own route namespace
      // (/pam/audit, /pam/alerts, /pam/audit-logs). A proxy mounted there would
      // intercept the DOCUMENT request on a hard reload and hand the browser
      // the API's JSON error instead of index.html. `rewrite` strips the prefix
      // because the client asks for /pam-api/api/v1/pam/audit and the service
      // exposes /api/v1/pam/audit. Mirrored in nginx.conf for production.
      '/pam-api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/pam-api/, ''),
      },

      '/idp-api': {
        target: 'https://idp.cf.adapid.link/idp',
        changeOrigin: true,
        // The target is HTTPS with a real certificate; keep verification on.
        secure: true,
        rewrite: (path) => path.replace(/^\/idp-api/, ''),
      },
    },
  },
  // NOTE: `build` previously sat INSIDE `server`, where Vite ignores it.
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
