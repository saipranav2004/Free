import { useCallback, useMemo, useState } from 'react';
import {
  AlertTriangle, ArrowDownUp, Ban, CheckCircle2, ChevronRight, Copy, Download,
  FileText, Fingerprint, Filter, KeyRound, Link2, RefreshCw, RotateCcw, ScrollText,
  Search as SearchIcon, ShieldAlert, User as UserIcon,
} from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import {
  PAM_BASE, downloadBlob, pamAuditApi, pamDevToken,
} from '../../lib/api/pamAudit.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Pagination } from '../../components/common/Pagination.jsx';
import {
  Badge, Button, EmptyState, IconButton, Input, Panel, Select, Spinner,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { classNames, formatDateTime, formatRelative } from '../../utils/format.js';

/**
 * PamAuditLogsPage — the console for the PAM compliance service.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * SCOPE
 * ═══════════════════════════════════════════════════════════════════════════
 * Feature 107 — searchable audit logs (the list, the filters, the record view,
 *               and the three pivot reads: by request, by user, by resource)
 * Feature 106 — compliance report export (PDF / CSV over a date range)
 *
 * Feature 105 is NOT surfaced here: no chain verification, no PAM resource
 * CRUD. Both live in the same service and the same document; their absence is
 * a decision, not an oversight.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHAT THIS DATA IS, AND WHAT THE UI OWES IT
 * ═══════════════════════════════════════════════════════════════════════════
 * These rows are not application logs. They are a hash-chained, append-only
 * evidence trail: every row carries `sequence_number`, `prev_hash` and
 * `entry_hash`, so any edit to history breaks the chain and becomes provable.
 * Two consequences drive the design:
 *
 *  · THE RECORD IS THE PRODUCT. A row is evidence, so the detail view shows the
 *    WHOLE record — including the chain fields and the raw `details` payload —
 *    rather than a friendly summary of it. Nothing is silently omitted, and the
 *    hashes are rendered truncated to 16 characters exactly as the API
 *    documentation prescribes, with the full value one copy away.
 *
 *  · CORRELATION IS THE INVESTIGATION. A single operator click writes several
 *    rows sharing one `request_id`. Reading them apart is guesswork; reading
 *    them together is the answer. The request trace is therefore a first-class
 *    action on every row, not a filter buried in an advanced panel.
 *
 * Export is deliberate and explicit rather than ambient: generating evidence is
 * itself an auditable act, so it is a considered dialog with a stated range,
 * never a one-click download of whatever happens to be on screen.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PAGINATION IS SERVER-SIDE
 * ═══════════════════════════════════════════════════════════════════════════
 * The API takes `limit` (1–500) and `offset` and returns `total`. The page
 * therefore asks for exactly the rows it shows and reports the server's total —
 * it never pulls a large window and slices it locally, which would make the
 * count on screen a property of the fetch size rather than of the tenant.
 */

const CATEGORIES = ['RESOURCE', 'AUTH', 'VAULT', 'SESSION', 'ADMIN', 'REPORT'];
const OUTCOMES = ['SUCCESS', 'DENIED', 'ERROR'];
const SORTS = [
  { value: 'occurred_at_desc', label: 'Newest first' },
  { value: 'occurred_at_asc', label: 'Oldest first' },
  { value: 'sequence_desc', label: 'Chain sequence (newest)' },
];
const FRAMEWORKS = ['SOC2', 'PCI', 'GDPR', 'HIPAA', 'ISO27001'];

/** `limit` is capped at 500 by the contract; these stay well inside it. */
const PAGE_SIZES = [25, 50, 100, 200];

const EMPTY_FILTERS = {
  q: '',
  username: '',
  user_id: '',
  category: '',
  action: '',
  outcome: '',
  resource: '',
  resource_prefix: '',
  source_ip: '',
  org_id: '',
  from: '',
  to: '',
  sort: 'occurred_at_desc',
};

/** `datetime-local` → RFC3339, which is what every date field here expects. */
function toRfc3339(localValue) {
  if (!localValue) return '';
  const d = new Date(localValue);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString();
}

/** The doc prescribes 16 characters for on-screen hashes. */
const shortHash = (h) => (h ? `${String(h).slice(0, 16)}…` : '—');

const outcomeTone = (outcome) =>
  ({ SUCCESS: 'green', DENIED: 'red', ERROR: 'amber' })[
    String(outcome || '').toUpperCase()
  ] || 'slate';

/** `details` arrives as a JSON *string*; show it as an object when it parses. */
function prettyDetails(details) {
  if (!details) return null;
  if (typeof details === 'object') return JSON.stringify(details, null, 2);
  try {
    return JSON.stringify(JSON.parse(details), null, 2);
  } catch {
    return String(details);
  }
}

export default function PamAuditLogsPage() {
  const toast = useToast();

  const [draft, setDraft] = useState(EMPTY_FILTERS);
  const [applied, setApplied] = useState(EMPTY_FILTERS);
  const [advanced, setAdvanced] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const [record, setRecord] = useState(null);
  const [traceOf, setTraceOf] = useState(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [devBusy, setDevBusy] = useState(false);

  const offset = (page - 1) * pageSize;

  /* ── Feature 107: the search ─────────────────────────────────────────── */
  const logs = useResource(
    () =>
      pamAuditApi.search({
        ...applied,
        from: toRfc3339(applied.from),
        to: toRfc3339(applied.to),
        limit: pageSize,
        offset,
      }),
    [applied, pageSize, offset]
  );

  const items = useMemo(() => {
    const payload = logs.data;
    if (Array.isArray(payload)) return payload;
    return payload?.items || [];
  }, [logs.data]);

  const total = logs.data?.total ?? items.length;

  /* A 401/403 here usually means the IAM session token is not the token this
     service issues, which is a different problem from "the request failed" and
     needs a different remedy — so it is detected and answered separately. */
  const authBlocked = /401|403/.test(String(logs.error || '')) ||
    /permission|denied|unauthor/i.test(String(logs.error || ''));
  const usingDevToken = !!pamDevToken.get();

  const applyFilters = () => {
    setPage(1);
    setApplied(draft);
  };

  const resetFilters = () => {
    setDraft(EMPTY_FILTERS);
    setApplied(EMPTY_FILTERS);
    setPage(1);
  };

  const set = (key) => (e) =>
    setDraft((f) => ({ ...f, [key]: e?.target ? e.target.value : e }));

  const activeFilterCount = useMemo(
    () =>
      Object.entries(applied).filter(
        ([k, v]) => k !== 'sort' && v !== '' && v != null
      ).length,
    [applied]
  );

  const copyValue = useCallback(
    async (value) => {
      try {
        await navigator.clipboard.writeText(String(value));
        toast.success('Copied to clipboard.');
      } catch {
        toast.error('Clipboard is unavailable in this browser.');
      }
    },
    [toast]
  );

  /** Narrow the search to one facet straight from a row. */
  const pivot = (key, value) => {
    if (!value) return;
    const next = { ...EMPTY_FILTERS, sort: applied.sort, [key]: String(value) };
    setDraft(next);
    setApplied(next);
    setPage(1);
    setRecord(null);
  };

  const useDevToken = async () => {
    setDevBusy(true);
    try {
      await pamAuditApi.devLogin();
      toast.success('Development token issued for this tab.');
      logs.reload();
    } catch (err) {
      toast.error(
        err.userMessage ||
          'The compliance service did not issue a development token. Check that it is running and that the test route is enabled.'
      );
    } finally {
      setDevBusy(false);
    }
  };

  const clearDevToken = () => {
    pamDevToken.clear();
    toast.success('Development token cleared. Using the signed-in session again.');
    logs.reload();
  };

  /* ── Table ───────────────────────────────────────────────────────────── */
  const columns = [
    {
      id: 'occurred_at',
      header: 'When',
      primary: true,
      render: (r) => (
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-ink-900">
            {formatRelative(r.occurred_at)}
          </p>
          <p className="truncate text-xs text-slate-500">{formatDateTime(r.occurred_at)}</p>
        </div>
      ),
    },
    {
      id: 'sequence_number',
      header: 'Seq',
      align: 'right',
      hideOnMobile: true,
      render: (r) => (
        <span className="font-mono text-xs text-slate-500 tabular">
          {r.sequence_number ?? '—'}
        </span>
      ),
    },
    {
      id: 'username',
      header: 'Principal',
      render: (r) => (
        <div className="min-w-0">
          <p className="truncate text-[13px] text-ink-900">{r.username || '—'}</p>
          {r.email && <p className="truncate text-xs text-slate-500">{r.email}</p>}
        </div>
      ),
    },
    {
      id: 'action',
      header: 'Action',
      render: (r) => (
        <div className="min-w-0">
          <p className="truncate font-mono text-xs text-ink-800" title={r.action}>
            {r.action || '—'}
          </p>
          {r.category && (
            <span className="mt-0.5 inline-flex">
              <Badge tone="slate">{r.category}</Badge>
            </span>
          )}
        </div>
      ),
    },
    {
      id: 'outcome',
      header: 'Outcome',
      hideable: false,
      render: (r) => (
        <Badge tone={outcomeTone(r.outcome)} dot>
          {r.outcome || 'UNKNOWN'}
        </Badge>
      ),
    },
    {
      id: 'resource',
      header: 'Resource',
      hideOnMobile: true,
      render: (r) => (
        <span className="block truncate font-mono text-xs text-slate-600" title={r.resource}>
          {r.resource || '—'}
        </span>
      ),
    },
    {
      id: 'source_ip',
      header: 'Source IP',
      hideOnMobile: true,
      render: (r) => (
        <span className="font-mono text-xs text-slate-500">{r.source_ip || '—'}</span>
      ),
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
          {r.request_id && (
            <IconButton
              icon={Link2}
              title="Trace every row from this request"
              onClick={() => setTraceOf(r)}
            />
          )}
          <IconButton icon={ChevronRight} title="Open record" onClick={() => setRecord(r)} />
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="PAM Audit Logs"
        description="Hash-chained evidence from the PAM compliance service — search the trail, trace a single request end to end, and export a report."
        icon={<ScrollText className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'PAM' }, { label: 'PAM Audit Logs' }]}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={logs.reload} loading={logs.loading}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button onClick={() => setReportOpen(true)}>
              <FileText className="h-4 w-4" /> Generate report
            </Button>
          </div>
        }
      />

      <div className="space-y-4">
        {/* Which service answered, and how much of it is in view. On a page
            whose job is to exercise a specific backend, saying so plainly is
            worth more than hiding it. */}
        <div className="card flex flex-wrap items-center gap-x-5 gap-y-2 px-4 py-2.5">
          <span className="flex items-center gap-1.5 text-2xs text-slate-500">
            <Fingerprint className="h-3.5 w-3.5 text-slate-400" />
            <span className="font-mono">{PAM_BASE || 'same origin'}</span>
            <span className="font-mono text-slate-400">/api/v1/pam/audit</span>
          </span>
          <span className="text-2xs text-slate-500 tabular">
            {logs.loading && !items.length
              ? 'Loading…'
              : `${total.toLocaleString()} rows · showing ${items.length} from offset ${offset}`}
          </span>
          {usingDevToken && (
            <span className="flex items-center gap-1.5">
              <Badge tone="amber" dot>
                Development token
              </Badge>
              <Button variant="link" size="xs" onClick={clearDevToken}>
                Clear
              </Button>
            </span>
          )}
        </div>

        {/* ── Filters (Feature 107 parameters, verbatim) ── */}
        <Panel
          title="Search"
          icon={SearchIcon}
          subtitle="All filters are optional and combined with AND"
          action={
            <button
              type="button"
              onClick={() => setAdvanced((v) => !v)}
              className="inline-flex items-center gap-1.5 text-xs text-brand-700 hover:text-brand-800"
            >
              <Filter className="h-3.5 w-3.5" />
              {advanced ? 'Fewer filters' : 'More filters'}
            </button>
          }
        >
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Input
              label="Full-text"
              value={draft.q}
              onChange={set('q')}
              placeholder="final_check"
              hint="Matches across the record"
            />
            <Input
              label="Username"
              value={draft.username}
              onChange={set('username')}
              placeholder="das.admin"
            />
            <Select label="Category" value={draft.category} onChange={set('category')}>
              <option value="">All categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
            <Select label="Outcome" value={draft.outcome} onChange={set('outcome')}>
              <option value="">All outcomes</option>
              {OUTCOMES.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </Select>
          </div>

          {advanced && (
            <div className="mt-3 grid grid-cols-1 gap-3 border-t border-line-soft pt-3 sm:grid-cols-2 lg:grid-cols-4">
              <Input
                label="Action"
                value={draft.action}
                onChange={set('action')}
                placeholder="pam:resource:POST"
                className="font-mono"
              />
              <Input
                label="Resource"
                value={draft.resource}
                onChange={set('resource')}
                placeholder="/api/v1/pam/resources"
                className="font-mono"
              />
              <Input
                label="Resource prefix"
                value={draft.resource_prefix}
                onChange={set('resource_prefix')}
                placeholder="pam:resource/"
                className="font-mono"
              />
              <Input
                label="Source IP"
                value={draft.source_ip}
                onChange={set('source_ip')}
                placeholder="192.168.1.1"
                className="font-mono"
              />
              <Input
                label="User ID"
                value={draft.user_id}
                onChange={set('user_id')}
                placeholder="UUID"
                className="font-mono"
              />
              <Input
                label="Organisation"
                value={draft.org_id}
                onChange={set('org_id')}
                placeholder="default"
              />
              <Input
                type="datetime-local"
                label="From"
                value={draft.from}
                onChange={set('from')}
              />
              <Input type="datetime-local" label="To" value={draft.to} onChange={set('to')} />
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-line-soft pt-3">
            <div className="flex items-center gap-2">
              <ArrowDownUp className="h-3.5 w-3.5 shrink-0 text-slate-400" />
              <Select value={draft.sort} onChange={set('sort')} className="w-auto">
                {SORTS.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </Select>
              {activeFilterCount > 0 && (
                <Badge tone="brand">
                  {activeFilterCount} filter{activeFilterCount === 1 ? '' : 's'} applied
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" onClick={resetFilters}>
                <RotateCcw className="h-4 w-4" /> Reset
              </Button>
              <Button onClick={applyFilters} loading={logs.loading}>
                <SearchIcon className="h-4 w-4" /> Apply
              </Button>
            </div>
          </div>
        </Panel>

        {/* An authentication failure is a different problem from a failed
            request and gets its own remedy rather than a generic retry. */}
        {authBlocked && !logs.loading && (
          <div className="flex flex-col gap-3 rounded-xl border border-amber-200 bg-amber-50/70 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-2">
              <KeyRound className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
              <p className="text-xs leading-relaxed text-ink-700/80">
                The compliance service rejected this session. It issues its own token, which is
                not the one held by the IAM console. Request a development token to exercise the
                endpoints from here — it is kept for this browser tab only and sent to no other
                service.
              </p>
            </div>
            <Button variant="secondary" onClick={useDevToken} loading={devBusy}>
              <KeyRound className="h-4 w-4" /> Get development token
            </Button>
          </div>
        )}

        {logs.error && !logs.loading && items.length === 0 ? (
          <EmptyState
            icon={ShieldAlert}
            title="Audit logs could not be loaded"
            description={logs.error}
            action={<Button onClick={logs.reload}>Retry</Button>}
          />
        ) : (
          <>
            <DataTable
              columns={columns}
              data={items}
              loading={logs.loading}
              getRowId={(r, i) => r.entry_hash || r.sequence_number || i}
              onRowClick={(r) => setRecord(r)}
              columnsStorageKey="pam-audit-107-columns"
              empty={{
                icon: ScrollText,
                title: 'No audit rows match these filters',
                description:
                  activeFilterCount > 0
                    ? 'Widen the search, or reset the filters to see the whole trail.'
                    : 'The compliance service has not recorded any events yet.',
                action:
                  activeFilterCount > 0 ? (
                    <Button variant="secondary" onClick={resetFilters}>
                      Reset filters
                    </Button>
                  ) : undefined,
              }}
            />

            {/* Server-side: `page` becomes `offset`, `perPage` becomes `limit`. */}
            <Pagination
              page={page}
              perPage={pageSize}
              total={total}
              onPageChange={setPage}
              onPerPageChange={(n) => {
                setPageSize(n);
                setPage(1);
              }}
              perPageOptions={PAGE_SIZES}
            />
          </>
        )}
      </div>

      {record && (
        <RecordModal
          row={record}
          onClose={() => setRecord(null)}
          onCopy={copyValue}
          onTrace={() => {
            setTraceOf(record);
            setRecord(null);
          }}
          onPivot={pivot}
        />
      )}

      {traceOf && <RequestTraceModal row={traceOf} onClose={() => setTraceOf(null)} />}

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        filters={applied}
        toast={toast}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   RecordModal — the whole row, because the row is the evidence
   ═══════════════════════════════════════════════════════════════════════════ */
function Field({ label, children, mono = false }) {
  return (
    <div className="grid grid-cols-[130px_1fr] items-start gap-3 py-2">
      <dt className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-400">{label}</dt>
      <dd
        className={classNames(
          'min-w-0 break-words text-[13px] text-ink-800',
          mono && 'font-mono text-xs'
        )}
      >
        {children}
      </dd>
    </div>
  );
}

function RecordModal({ row, onClose, onCopy, onTrace, onPivot }) {
  const details = prettyDetails(row.details);

  return (
    <Modal
      open
      onClose={onClose}
      size="lg"
      icon={ScrollText}
      title={row.action || 'Audit record'}
      description={`Sequence ${row.sequence_number ?? '—'} · ${formatDateTime(row.occurred_at)}`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
          {row.request_id && (
            <Button onClick={onTrace}>
              <Link2 className="h-4 w-4" /> Trace this request
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone={outcomeTone(row.outcome)} dot>
            {row.outcome || 'UNKNOWN'}
          </Badge>
          {row.category && <Badge tone="slate">{row.category}</Badge>}
          {row.org_id && <Badge tone="outline">{row.org_id}</Badge>}
        </div>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <UserIcon className="h-3.5 w-3.5" /> Who
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <Field label="Username">
              <span className="flex flex-wrap items-center gap-2">
                <span>{row.username || '—'}</span>
                {row.username && (
                  <Button variant="link" size="xs" onClick={() => onPivot('username', row.username)}>
                    Filter by this principal
                  </Button>
                )}
              </span>
            </Field>
            <Field label="Email">{row.email || '—'}</Field>
            <Field label="User ID" mono>
              <CopyRow value={row.user_id} onCopy={onCopy} />
            </Field>
          </dl>
        </section>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <ScrollText className="h-3.5 w-3.5" /> What
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <Field label="Action" mono>
              {row.action || '—'}
            </Field>
            <Field label="Resource" mono>
              <span className="flex flex-wrap items-center gap-2">
                <span className="break-all">{row.resource || '—'}</span>
                {row.resource && (
                  <Button variant="link" size="xs" onClick={() => onPivot('resource', row.resource)}>
                    Filter by this resource
                  </Button>
                )}
              </span>
            </Field>
            <Field label="Occurred">{formatDateTime(row.occurred_at)}</Field>
            <Field label="Recorded">{formatDateTime(row.created_at)}</Field>
          </dl>
        </section>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <Fingerprint className="h-3.5 w-3.5" /> Origin
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <Field label="Source IP" mono>
              {row.source_ip || '—'}
            </Field>
            <Field label="User agent">{row.user_agent || '—'}</Field>
            <Field label="Request ID" mono>
              <CopyRow value={row.request_id} onCopy={onCopy} />
            </Field>
            <Field label="Session ID" mono>
              <CopyRow value={row.session_id} onCopy={onCopy} />
            </Field>
            <Field label="Authz decision" mono>
              <CopyRow value={row.authz_decision_id} onCopy={onCopy} />
            </Field>
          </dl>
        </section>

        {/* The chain fields are what make this record evidence rather than a
            log line, so they are shown rather than tucked away — truncated to
            16 characters as the API documentation prescribes, with the full
            value one copy away. */}
        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <KeyRound className="h-3.5 w-3.5" /> Chain integrity
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <Field label="Sequence" mono>
              {row.sequence_number ?? '—'}
            </Field>
            <Field label="Previous hash" mono>
              <CopyRow value={row.prev_hash} display={shortHash(row.prev_hash)} onCopy={onCopy} />
            </Field>
            <Field label="Entry hash" mono>
              <CopyRow value={row.entry_hash} display={shortHash(row.entry_hash)} onCopy={onCopy} />
            </Field>
            <Field label="Hash version" mono>
              {row.hash_version ?? '—'}
            </Field>
          </dl>
        </section>

        {details && (
          <section>
            <h4 className="text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              Details
            </h4>
            <pre className="mt-1.5 max-h-56 overflow-auto rounded-lg border border-line-soft bg-slate-50/70 p-3 font-mono text-xs leading-relaxed text-ink-800">
              {details}
            </pre>
          </section>
        )}
      </div>
    </Modal>
  );
}

function CopyRow({ value, display, onCopy }) {
  if (!value) return <span className="text-slate-400">—</span>;
  return (
    <span className="flex items-start gap-1.5">
      <span className="min-w-0 flex-1 break-all">{display || value}</span>
      <IconButton icon={Copy} title="Copy full value" onClick={() => onCopy(value)} />
    </span>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   RequestTraceModal — every row written while serving one HTTP request
   ═══════════════════════════════════════════════════════════════════════════
   GET /api/v1/pam/audit/request/:request_id, ordered by sequence.

   This is the read that turns a list of events into an account of what
   happened: one operator click produces several rows — the authorisation
   decision, the resource write, the session note — and only together do they
   explain the outcome.
   ═══════════════════════════════════════════════════════════════════════════ */
function RequestTraceModal({ row, onClose }) {
  const trace = useResource(
    () => pamAuditApi.byRequest(row.request_id),
    [row.request_id]
  );

  const items = useMemo(() => {
    const payload = trace.data;
    if (Array.isArray(payload)) return payload;
    return payload?.items || [];
  }, [trace.data]);

  return (
    <Modal
      open
      onClose={onClose}
      size="lg"
      icon={Link2}
      title="Request trace"
      description={`Every audit row written while serving request ${row.request_id}`}
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      {trace.loading && items.length === 0 ? (
        <div className="flex justify-center py-10">
          <Spinner />
        </div>
      ) : trace.error && items.length === 0 ? (
        <EmptyState
          icon={ShieldAlert}
          title="Trace could not be loaded"
          description={trace.error}
          action={<Button onClick={trace.reload}>Retry</Button>}
        />
      ) : items.length === 0 ? (
        <p className="py-8 text-center text-[13px] text-slate-500">
          No rows are recorded against this request id.
        </p>
      ) : (
        <ol className="relative space-y-4 pl-6">
          {/* The rail makes the ordering explicit — these rows are a sequence,
              not a set. */}
          <span
            aria-hidden="true"
            className="absolute left-[7px] top-2 bottom-2 w-px bg-line-soft"
          />
          {items.map((step, i) => (
            <li key={step.entry_hash || `${step.sequence_number}-${i}`} className="relative">
              <span
                className={classNames(
                  'absolute -left-6 top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full ring-2 ring-white',
                  outcomeTone(step.outcome) === 'green' && 'bg-emerald-500',
                  outcomeTone(step.outcome) === 'red' && 'bg-rose-500',
                  outcomeTone(step.outcome) === 'amber' && 'bg-amber-500',
                  outcomeTone(step.outcome) === 'slate' && 'bg-slate-300'
                )}
              />
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-xs text-slate-400 tabular">
                  #{step.sequence_number ?? i + 1}
                </span>
                <span className="font-mono text-[13px] text-ink-900">{step.action || '—'}</span>
                <Badge tone={outcomeTone(step.outcome)}>{step.outcome || 'UNKNOWN'}</Badge>
                {step.category && <Badge tone="slate">{step.category}</Badge>}
              </div>
              <p className="mt-1 truncate font-mono text-xs text-slate-500" title={step.resource}>
                {step.resource || '—'}
              </p>
              <p className="mt-0.5 text-2xs text-slate-400">
                {formatDateTime(step.occurred_at)}
                {step.username ? ` · ${step.username}` : ''}
              </p>
            </li>
          ))}
        </ol>
      )}
    </Modal>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   ReportModal — Feature 106
   ═══════════════════════════════════════════════════════════════════════════
   POST /api/v1/pam/audit/report → a PDF or CSV byte stream.

   Prefilled from the SEARCH filters already applied, because the report an
   auditor wants is almost always the evidence the operator is currently
   looking at. `from`/`to` are required by the contract and are the one thing
   the search does not have to supply, so they default to the last 30 days and
   are validated before the request rather than after it.
   ═══════════════════════════════════════════════════════════════════════════ */
function ReportModal({ open, onClose, filters, toast }) {
  const defaults = useMemo(() => {
    const now = new Date();
    const past = new Date(now.getTime() - 30 * 86400e3);
    const toLocal = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
    return {
      from: filters.from || toLocal(past),
      to: filters.to || toLocal(now),
      format: 'pdf',
      title: '',
      frameworks: ['SOC2'],
      user_id: filters.user_id || '',
      category: filters.category || '',
      action: filters.action || '',
      outcome: filters.outcome || '',
      resource_prefix: filters.resource_prefix || '',
    };
  }, [filters]);

  const [form, setForm] = useState(defaults);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [signature, setSignature] = useState('');

  // Re-seed whenever the dialog is opened against a different filter set.
  const seed = JSON.stringify(defaults);
  if (open && seed !== signature) {
    setSignature(seed);
    setForm(defaults);
    setErrors({});
  }

  const set = (key) => (e) => {
    const value = e?.target ? e.target.value : e;
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((x) => ({ ...x, [key]: undefined }));
  };

  const toggleFramework = (fw) =>
    setForm((f) => ({
      ...f,
      frameworks: f.frameworks.includes(fw)
        ? f.frameworks.filter((x) => x !== fw)
        : [...f.frameworks, fw],
    }));

  const submit = async () => {
    const next = {};
    if (!form.from) next.from = 'A start date is required.';
    if (!form.to) next.to = 'An end date is required.';
    if (form.from && form.to && new Date(form.from) > new Date(form.to)) {
      next.to = 'The end date must fall after the start date.';
    }
    setErrors(next);
    if (Object.keys(next).length) return;

    setBusy(true);
    try {
      const { blob, filename } = await pamAuditApi.generateReport({
        from: toRfc3339(form.from),
        to: toRfc3339(form.to),
        format: form.format,
        title: form.title,
        frameworks: form.frameworks,
        user_id: form.user_id,
        category: form.category,
        action: form.action,
        outcome: form.outcome,
        resource_prefix: form.resource_prefix,
      });
      downloadBlob(blob, filename);
      toast.success(`Report generated — ${filename}`);
      onClose();
    } catch (err) {
      toast.error(err.userMessage || 'The compliance report could not be generated.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="form"
      icon={FileText}
      title="Generate compliance report"
      description="Produces a signed evidence pack over a date range, narrowed by the same filters as the search."
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button onClick={submit} loading={busy}>
            <Download className="h-4 w-4" /> Generate {String(form.format).toUpperCase()}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            type="datetime-local"
            label="From"
            value={form.from}
            onChange={set('from')}
            error={errors.from}
            required
          />
          <Input
            type="datetime-local"
            label="To"
            value={form.to}
            onChange={set('to')}
            error={errors.to}
            required
          />
        </div>

        <Select label="Format" value={form.format} onChange={set('format')} required>
          <option value="pdf">PDF — a formatted evidence pack</option>
          <option value="csv">CSV — raw rows for further analysis</option>
        </Select>

        <Input
          label="Title"
          value={form.title}
          onChange={set('title')}
          placeholder="Q3 2026 Audit Report"
          hint="Optional. Printed on the report."
        />

        <div>
          <p className="label-base">Frameworks</p>
          <div className="flex flex-wrap items-center gap-1.5">
            {FRAMEWORKS.map((fw) => {
              const active = form.frameworks.includes(fw);
              return (
                <button
                  key={fw}
                  type="button"
                  onClick={() => toggleFramework(fw)}
                  className={classNames(
                    'rounded-md px-2 py-1 text-2xs font-medium ring-1 ring-inset transition-colors',
                    active
                      ? 'bg-brand-50 text-brand-700 ring-brand-200'
                      : 'bg-white text-slate-600 ring-slate-300 hover:bg-slate-50'
                  )}
                >
                  {active ? (
                    <CheckCircle2 className="mr-1 inline h-3 w-3" />
                  ) : (
                    <Ban className="mr-1 inline h-3 w-3 opacity-40" />
                  )}
                  {fw}
                </button>
              );
            })}
          </div>
          <p className="mt-1.5 text-xs leading-snug text-slate-500">
            Optional. Tags the report with the control frameworks it is evidence for.
          </p>
        </div>

        {/* Inherited narrowing, stated rather than assumed — an operator must be
            able to see exactly what the exported evidence will and will not
            contain before they generate it. */}
        <div className="rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2.5">
          <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.07em] text-slate-400">
            <Filter className="h-3 w-3" /> Inherited from the current search
          </p>
          {[
            ['Category', form.category],
            ['Action', form.action],
            ['Outcome', form.outcome],
            ['User ID', form.user_id],
            ['Resource prefix', form.resource_prefix],
          ].some(([, v]) => v) ? (
            <dl className="mt-1.5 space-y-1">
              {[
                ['Category', form.category],
                ['Action', form.action],
                ['Outcome', form.outcome],
                ['User ID', form.user_id],
                ['Resource prefix', form.resource_prefix],
              ]
                .filter(([, v]) => v)
                .map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between gap-3 text-xs">
                    <dt className="text-slate-500">{label}</dt>
                    <dd className="truncate font-mono text-ink-800">{value}</dd>
                  </div>
                ))}
            </dl>
          ) : (
            <p className="mt-1 text-xs text-slate-500">
              No filters applied — the report covers every event in the range.
            </p>
          )}
        </div>

        <p className="flex items-start gap-1.5 text-2xs leading-relaxed text-slate-500">
          <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-amber-500" />
          <span>
            Generating a report is itself an audited event and is recorded in the trail under the
            REPORT category.
          </span>
        </p>
      </div>
    </Modal>
  );
}
