import { Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from '../components/layout/AppLayout.jsx';
import { ProtectedRoute } from '../components/layout/ProtectedRoute.jsx';
import { RequireAdmin } from '../components/layout/RequireAdmin.jsx';

import LoginPage from '../pages/auth/LoginPage.jsx';
import MfaChallengePage from '../pages/auth/MfaChallengePage.jsx';
import RegisterPage from '../pages/auth/RegisterPage.jsx';
import RegisterTenantPage from '../pages/auth/RegisterTenantPage.jsx';
import ForgotPasswordPage from '../pages/auth/ForgotPasswordPage.jsx';
import ResetPasswordPage from '../pages/auth/ResetPasswordPage.jsx';

import DashboardPage from '../pages/DashboardPage.jsx';
import ProfilePage from '../pages/ProfilePage.jsx';
import MfaSetupPage from '../pages/MfaSetupPage.jsx';
import SessionsPage from '../pages/SessionsPage.jsx';

import UsersPage from '../pages/identity/UsersPage.jsx';
import UserDetailPage from '../pages/identity/UserDetailPage.jsx';
import ServiceAccountsPage from '../pages/identity/ServiceAccountsPage.jsx';
import ApiKeysPage from '../pages/identity/ApiKeysPage.jsx';
// ── Delegations — TEMPORARILY COMMENTED OUT ──────────────────────────────
// The page file (pages/identity/DelegationsPage.jsx) is intact. Restore by
// uncommenting this import, the matching <Route> below, the Sidebar item and the
// CommandPalette entry.
// import DelegationsPage from '../pages/identity/DelegationsPage.jsx';
import TenantsPage from '../pages/identity/TenantsPage.jsx';
import BootstrapPage from '../pages/identity/BootstrapPage.jsx';

// ── Groups (RBAC) — TEMPORARILY COMMENTED OUT ───────────────────────────
// GroupsPage / GroupDetailPage files are intact. Restore by uncommenting these
// imports, the matching <Route> entries below, the Sidebar item, the
// CommandPalette entries and the UserDetailPage "Groups" tab.
// import GroupsPage from '../pages/rbac/GroupsPage.jsx';
// import GroupDetailPage from '../pages/rbac/GroupDetailPage.jsx';
import RolesPage from '../pages/rbac/RolesPage.jsx';
import RoleDetailPage from '../pages/rbac/RoleDetailPage.jsx';

// ── Oracle integration — TEMPORARILY DISABLED ──────────────────────────────
// Every Oracle page is commented out for now. Restore by uncommenting these
// imports and the matching <Route> entries below; the page files are intact.
// import OracleHubPage from '../pages/integrations/oracle/OracleHubPage.jsx';
// import OracleConnectionDetailPage from '../pages/integrations/oracle/OracleConnectionDetailPage.jsx';

import AuditLogsPage from '../pages/identity/AuditLogsPage.jsx';
// PAM — the former single tabbed page is now two dedicated pages plus a
// redirect shell that preserves the legacy /pam and /pam?tab=alerts links.
import PamPage from '../pages/pam/PamPage.jsx';
import PamAuditLogsPage from '../pages/pam/AuditLogsPage.jsx';
import PamAlertsPage from '../pages/pam/AlertsPage.jsx';

import PoliciesPage from '../pages/pbac/PoliciesPage.jsx';
import PolicyEditorPage from '../pages/pbac/PolicyEditorPage.jsx';
import ResourcesPage from '../pages/pbac/ResourcesPage.jsx';
import IdentityResourcesPage from '../pages/identity/ResourcesPage.jsx';
// Provider-scoped resource detail: opened from a GitHub row in the resource
// registry. The route is provider-explicit so the surface a link resolves to is
// never ambiguous; a second provider is a second import and a second <Route>.
import GithubResourcePage from '../pages/integrations/github/GithubResourcePage.jsx';
// PAM compliance console (Features 106/107). Talks to the PAM compliance
// service on its own /pam-api prefix, NOT the IAM backend.
//
// Bound as PamComplianceAuditPage, not PamAuditLogsPage: that identifier is
// already taken above by pages/pam/AuditLogsPage.jsx (the IAM-backed audit
// view). Two different pages, two different backends — they must not share a
// binding here even though both are "PAM audit logs" to a reader.
import PamComplianceAuditPage from '../pages/pam/PamAuditLogsPage.jsx';
import AuthzCheckPage from '../pages/pbac/AuthzCheckPage.jsx';

// ── Microsoft 365 integration — TEMPORARILY DISABLED ───────────────────────
// Every M365 page is commented out for now. Restore by uncommenting these
// imports and the matching <Route> entries below; the page files are intact.
// import M365HubPage from '../pages/integrations/m365/M365HubPage.jsx';
// import M365ServicePage from '../pages/integrations/m365/M365ServicePage.jsx';
import IamControlPage from '../pages/integrations/IamControlPage.jsx';
import SsoPage from '../pages/settings/SsoPage.jsx';

// IDP pages — identity provider federation (separate API domain)
import IdpOverviewPage from '../pages/idp/IdpOverviewPage.jsx';
import IdpTenantsPage from '../pages/idp/IdpTenantsPage.jsx';

function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center text-center">
      <p className="text-5xl font-bold text-brand-600">404</p>
      <p className="mt-2 text-slate-500">This page could not be found.</p>
      <a href="/" className="mt-4 text-sm text-brand-600 hover:underline">
        Back to dashboard
      </a>
    </div>
  );
}

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public / auth routes */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/login/mfa" element={<MfaChallengePage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/login/forgot" element={<ForgotPasswordPage />} />
      <Route path="/login/reset" element={<ResetPasswordPage />} />
      {/* Public tenant registration (bootstrap a new account without auth).
          Uses the dedicated public registration screen — the in-app
          TenantsPage stays on /identity/tenants for signed-in admins. */}
      <Route path="/register-tenant" element={<RegisterTenantPage />} />

      {/* Protected app shell */}
      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<DashboardPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/security/mfa" element={<MfaSetupPage />} />
        <Route path="/security/sessions" element={<SessionsPage />} />

        {/* Identity */}
        <Route path="/identity/users" element={<UsersPage />} />
        <Route path="/identity/users/:userId" element={<UserDetailPage />} />
        <Route path="/identity/service-accounts" element={<ServiceAccountsPage />} />
        <Route path="/identity/api-keys" element={<ApiKeysPage />} />
        {/* Delegations — TEMPORARILY COMMENTED OUT (see the import above). */}
        {/* <Route path="/identity/delegations" element={<DelegationsPage />} /> */}
        <Route path="/identity/tenants" element={<TenantsPage />} />
        <Route path="/identity/bootstrap" element={<BootstrapPage />} />

        {/* RBAC */}
        {/* Groups — TEMPORARILY COMMENTED OUT (see the imports above). */}
        {/* <Route path="/rbac/groups" element={<GroupsPage />} /> */}
        {/* <Route path="/rbac/groups/:groupId" element={<GroupDetailPage />} /> */}
        <Route path="/rbac/roles" element={<RolesPage />} />
        <Route path="/rbac/roles/:roleId" element={<RoleDetailPage />} />

        {/* PBAC */}
        <Route path="/pbac/policies" element={<PoliciesPage />} />
        <Route path="/pbac/policies/new" element={<PolicyEditorPage />} />
        <Route path="/pbac/policies/:policyId" element={<PolicyEditorPage />} />
        <Route path="/pbac/resources" element={<ResourcesPage />} />
        <Route path="/identity/resources" element={<IdentityResourcesPage />} />
        {/* GitHub external-identity mapping detail for one registered resource.
            Declared AFTER the list route; the paths do not overlap, so ordering
            is documentation rather than precedence. */}
        <Route
          path="/identity/resources/:resourceId/github"
          element={<GithubResourcePage />}
        />
        <Route path="/pbac/check" element={<AuthzCheckPage />} />

        {/* Integrations — M365 + Oracle DB as IAM-protected service catalog.
            M365 and Oracle routes are TEMPORARILY DISABLED (see imports above). */}
        {/* <Route path="/integrations/m365" element={<M365HubPage />} /> */}
        {/* <Route path="/integrations/m365/:service" element={<M365ServicePage />} /> */}
        {/* <Route path="/integrations/oracle" element={<OracleHubPage />} /> */}
        {/* <Route path="/integrations/oracle/:connectionId" element={<OracleConnectionDetailPage />} /> */}
        <Route path="/integrations/iam-control" element={<IamControlPage />} />
        <Route path="/settings/sso" element={<SsoPage />} />

        {/* IDP — identity provider federation (AdapID backend, separate domain).
            ADMIN ONLY, BUT NEVER HIDDEN: the Topbar dropdown and the Sidebar
            section stay visible for every operator; RequireAdmin decides access
            from `account_type` (GET /identity/accounts/<acc>/users/<id>) and
            renders a clean "Access Restricted" panel for non-admins. */}
        <Route
          path="/idp/overview"
          element={
            <RequireAdmin area="Federation overview">
              <IdpOverviewPage />
            </RequireAdmin>
          }
        />
        <Route
          path="/idp/tenants"
          element={
            <RequireAdmin area="Identity-provider tenants">
              <IdpTenantsPage />
            </RequireAdmin>
          }
        />

        {/* PAM — privileged access management.
            The old tabbed page has been split into two dedicated pages, each with
            its own route and its own sidebar entry. `/pam` redirects (and honours
            the legacy `?tab=alerts` deep link from the notifications bell). */}
        <Route path="/pam" element={<PamPage />} />

        <Route path="/pam/audit-logs" element={<PamAuditLogsPage />} />
        {/* Feature 107 search + Feature 106 report, on the compliance service. */}
        <Route path="/pam/audit" element={<PamComplianceAuditPage />} />
        <Route path="/pam/alerts" element={<PamAlertsPage />} />
        {/* Backwards compatibility: /audit-logs → the PAM audit trail page */}
        <Route path="/audit-logs" element={<Navigate to="/pam/audit-logs" replace />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
