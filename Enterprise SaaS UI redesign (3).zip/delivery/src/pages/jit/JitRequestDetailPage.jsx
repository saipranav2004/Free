import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams, Link } from 'react-router-dom'
import { toast } from 'sonner'
import clsx from 'clsx'
import {
  ArrowLeft, ShieldAlert, Clock, CheckCircle2, XCircle, Hourglass, Ban, Lock,
  FileText, Timer, ArrowRight, Copy, Check, KeyRound,
} from 'lucide-react'
import { getJitRequest, cancelJitRequest } from '../../api/jit'
import { PageHeader, Card, CardHeader, CardTitle, DetailList } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Button } from '../../components/common/Button'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { useCountdown } from '../../hooks/useCountdown'
import { formatDateTime, formatDuration, formatRelativeToNow } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import { JIT_STATUS, JIT_STATUS_LABELS, JIT_STATUS_BADGE, GRANT_STATUS_BADGE } from '../../config/constants'

// ---------------------------------------------------------------------------
// JIT request detail
// ---------------------------------------------------------------------------
// WHAT WAS WRONG. Two cards side by side, each a bare <dl> of label/value
// pairs, with the request's status hidden as one row among ten. The page
// answered "what are this record's fields" when the only question a person
// opens it with is "where is my access, and what happens next".
//
// RESEARCHED SHAPE. CyberArk's request view, Entra PIM's activation detail
// and ServiceNow's approval record all lead with the same two things: a
// STATE BANNER that says in words what is happening and what to do about it,
// and a LIFECYCLE TIMELINE showing the stages the request has passed and the
// one it is sitting in. The property sheet comes after, because it is
// reference material, not the answer.
//
// So the page is now:
//   1. STATE BANNER — one sentence, coloured by verdict, carrying the one
//      action available in that state (withdraw while pending; open the
//      resource once active; raise a new request once denied or expired).
//   2. TIMELINE — requested → decided → active → expires, with the stage it
//      is currently in marked live. Stages that cannot have happened are
//      rendered as pending, not hidden, so the shape of the workflow is
//      legible even on a request that was denied at step two.
//   3. DETAILS + GRANT — the reference material, in the console's standard
//      DetailList so it lines up with every other detail page.
//
// The API contract is unchanged: getJitRequest and cancelJitRequest only.

const CANCELLABLE_STATUSES = [JIT_STATUS.PENDING, JIT_STATUS.WAITING]

// The backend's nesting for a resulting grant isn't pinned by the contract we
// have, so check the two shapes that would make sense and otherwise fall back
// to an expiry field on the request itself — the countdown then still works
// even if the nesting name differs per deployment.
function extractGrant(request) {
  if (!request) return null
  if (request.grant) return request.grant
  if (Array.isArray(request.grants) && request.grants.length > 0) return request.grants[0]
  return null
}

function CopyableId({ value }) {
  const [copied, setCopied] = useState(false)
  if (!value) return null
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value)
          setCopied(true)
          setTimeout(() => setCopied(false), 1600)
        } catch {
          toast.error('Clipboard unavailable in this browser')
        }
      }}
      className="group inline-flex max-w-full items-center gap-1.5 rounded px-1 font-mono text-xs text-ink-500 transition-colors hover:bg-surface-800 hover:text-ink-200"
      title="Copy request ID"
    >
      <span className="truncate">{value}</span>
      {copied ? (
        <Check className="h-3 w-3 flex-none text-emerald-600 dark:text-emerald-400" strokeWidth={2.5} />
      ) : (
        <Copy className="h-3 w-3 flex-none opacity-0 transition-opacity group-hover:opacity-100" strokeWidth={2} />
      )}
    </button>
  )
}

function LiveCountdown({ targetIso, className }) {
  const remainingMs = useCountdown(targetIso)
  const remaining = Math.max(0, remainingMs / 1000)
  if (!targetIso) return <span className="text-ink-500">—</span>
  if (remaining <= 0) return <span className="text-ink-500">Expired</span>
  const tone = remaining < 300 ? 'text-red-700 dark:text-red-300' : remaining < 1800 ? 'text-amber-700 dark:text-amber-300' : 'text-emerald-700 dark:text-emerald-300'
  return <span className={clsx('font-semibold tabular-nums', tone, className)}>{formatDuration(remaining)}</span>
}

// --- state banner ----------------------------------------------------------

const BANNERS = {
  PENDING: {
    tone: 'amber',
    icon: Hourglass,
    title: 'Waiting for an approver',
    body: 'An administrator has to decide this before any access exists. You can withdraw it while it is still undecided.',
  },
  WAITING: {
    tone: 'orange',
    icon: Timer,
    title: 'In the cooling-off period',
    body: 'Break-glass access does not activate immediately. It becomes usable when the mandatory waiting period elapses, unless an administrator revokes it first.',
  },
  APPROVED: {
    tone: 'emerald',
    icon: CheckCircle2,
    title: 'Approved — access granted',
    body: 'The grant below is what you actually hold. It is time-boxed and stops working the moment it expires.',
  },
  DENIED: {
    tone: 'red',
    icon: XCircle,
    title: 'Denied',
    body: 'No access was granted. The approver’s reason is recorded below. Raise a new request if the need still stands.',
  },
  CANCELLED: {
    tone: 'neutral',
    icon: Ban,
    title: 'Withdrawn',
    body: 'You withdrew this request before it was decided. Nothing was granted.',
  },
  EXPIRED: {
    tone: 'neutral',
    icon: Clock,
    title: 'Expired',
    body: 'This request is no longer actionable. Any access it granted has already ended.',
  },
}

const BANNER_STYLE = {
  amber: { wrap: 'border-amber-500 bg-amber-50/60 dark:bg-amber-950/15', tile: 'bg-amber-100 text-amber-600 ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/25', head: 'text-amber-900 dark:text-amber-200', body: 'text-amber-800/90 dark:text-amber-300/85' },
  orange: { wrap: 'border-orange-500 bg-orange-50/60 dark:bg-orange-950/15', tile: 'bg-orange-100 text-orange-600 ring-orange-600/20 dark:bg-orange-500/10 dark:text-orange-300 dark:ring-orange-500/25', head: 'text-orange-900 dark:text-orange-200', body: 'text-orange-800/90 dark:text-orange-300/85' },
  emerald: { wrap: 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/15', tile: 'bg-emerald-100 text-emerald-600 ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/25', head: 'text-emerald-900 dark:text-emerald-200', body: 'text-emerald-800/90 dark:text-emerald-300/85' },
  red: { wrap: 'border-red-500 bg-red-50/60 dark:bg-red-950/15', tile: 'bg-red-100 text-red-600 ring-red-600/20 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/25', head: 'text-red-900 dark:text-red-200', body: 'text-red-800/90 dark:text-red-300/85' },
  neutral: { wrap: 'border-surface-600 bg-surface-850', tile: 'bg-surface-800 text-ink-400 ring-surface-700', head: 'text-ink-100', body: 'text-ink-400' },
}

function StateBanner({ request, grant, onWithdraw }) {
  const spec = BANNERS[request.status] || BANNERS.EXPIRED
  const s = BANNER_STYLE[spec.tone]
  const Icon = spec.icon
  const canWithdraw = CANCELLABLE_STATUSES.includes(request.status)
  const activeGrant = grant?.expires_at && new Date(grant.expires_at).getTime() > Date.now()

  return (
    <div className={clsx('mb-6 flex flex-col gap-4 rounded-xl border border-l-[3px] px-4 py-4 sm:flex-row sm:items-center', s.wrap)}>
      <span className={clsx('flex h-10 w-10 flex-none items-center justify-center rounded-xl ring-1 ring-inset', s.tile)}>
        <Icon className="h-[1.15rem] w-[1.15rem]" strokeWidth={1.75} />
      </span>

      <div className="min-w-0 flex-1">
        <p className={clsx('text-sm font-semibold', s.head)}>{spec.title}</p>
        <p className={clsx('mt-1 text-sm leading-relaxed', s.body)}>{spec.body}</p>
      </div>

      {/* Exactly one action, chosen by state — a banner offering three
          buttons is a toolbar, and a toolbar has no opinion. */}
      <div className="flex flex-none items-center gap-2">
        {activeGrant && (
          <span className={clsx('hidden text-sm sm:block', s.body)}>
            <LiveCountdown targetIso={grant.expires_at} /> left
          </span>
        )}
        {canWithdraw ? (
          <Button variant="dangerGhost" onClick={onWithdraw}>
            Withdraw request
          </Button>
        ) : activeGrant && request.resource_id ? (
          <Link to={`/resources/${request.resource_id}`}>
            <Button variant="primary" iconRight={ArrowRight}>
              Open resource
            </Button>
          </Link>
        ) : null}
      </div>
    </div>
  )
}

// --- lifecycle timeline ----------------------------------------------------

function Timeline({ request, grant }) {
  const denied = request.status === JIT_STATUS.DENIED
  const cancelled = request.status === JIT_STATUS.CANCELLED
  const approvedAt = request.approved_at || grant?.granted_at || null
  const decidedAt = approvedAt || request.denied_at || request.cancelled_at || null
  const expiresAt = grant?.expires_at || request.expires_at || null
  const expired = expiresAt ? new Date(expiresAt).getTime() <= Date.now() : false

  const stages = [
    {
      key: 'requested',
      label: 'Requested',
      at: request.created_at,
      done: true,
      note: request.created_at ? formatRelativeToNow(request.created_at) : null,
      icon: KeyRound,
    },
    {
      key: 'decided',
      label: cancelled ? 'Withdrawn' : denied ? 'Denied' : 'Approved',
      at: decidedAt,
      done: !!decidedAt,
      live: !decidedAt && CANCELLABLE_STATUSES.includes(request.status),
      failed: denied || cancelled,
      note: !decidedAt ? 'Awaiting an approver' : null,
      icon: cancelled ? Ban : denied ? XCircle : CheckCircle2,
    },
    {
      key: 'active',
      label: 'Access active',
      at: grant?.granted_at || approvedAt,
      done: !!grant && !expired,
      live: !!grant && !expired,
      skipped: denied || cancelled,
      note: denied || cancelled ? 'Never activated' : !grant ? 'Nothing granted yet' : null,
      icon: Lock,
    },
    {
      key: 'expires',
      label: expired ? 'Expired' : 'Expires',
      at: expiresAt,
      done: expired,
      skipped: denied || cancelled,
      note: expiresAt && !expired ? null : denied || cancelled ? '—' : null,
      icon: Clock,
    },
  ]

  return (
    <ol className="px-4 py-4">
      {stages.map((st, i) => {
        const Icon = st.icon
        const last = i === stages.length - 1
        const tone = st.skipped
          ? 'muted'
          : st.failed && st.done
            ? 'red'
            : st.live
              ? 'live'
              : st.done
                ? 'done'
                : 'muted'
        const tile = {
          done: 'border-emerald-600/25 bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300',
          live: 'border-amber-600/25 bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-300',
          red: 'border-red-600/25 bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-300',
          muted: 'border-surface-700 bg-surface-850 text-ink-600',
        }[tone]

        return (
          <li key={st.key} className="relative flex gap-3.5 pb-5 last:pb-0">
            {!last && (
              <span
                aria-hidden="true"
                className={clsx('absolute left-[0.9375rem] top-8 bottom-1 w-px', tone === 'muted' ? 'bg-surface-800' : 'bg-surface-700')}
              />
            )}
            <span className={clsx('relative z-10 flex h-[1.875rem] w-[1.875rem] flex-none items-center justify-center rounded-full border', tile)}>
              <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
              {st.live && <span className="dot-live absolute inset-0 rounded-full bg-amber-500/40" aria-hidden="true" />}
            </span>
            <div className="min-w-0 flex-1 pt-1">
              <p className={clsx('text-sm font-medium', tone === 'muted' ? 'text-ink-500' : 'text-ink-100')}>{st.label}</p>
              <p className="mt-0.5 text-xs text-ink-500">
                {st.at ? formatDateTime(st.at) : st.note || 'Not reached'}
                {st.at && st.note ? ` · ${st.note}` : ''}
              </p>
            </div>
          </li>
        )
      })}
    </ol>
  )
}

// ---------------------------------------------------------------------------

export default function JitRequestDetailPage() {
  const { id } = useParams()
  const queryClient = useQueryClient()
  const [cancelOpen, setCancelOpen] = useState(false)

  const requestQuery = useQuery({
    queryKey: ['jit', 'requests', id],
    queryFn: ({ signal }) => getJitRequest(id, signal),
  })

  const cancelMutation = useMutation({
    mutationFn: (reason) => cancelJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request withdrawn')
      setCancelOpen(false)
      queryClient.invalidateQueries({ queryKey: ['jit'] })
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setCancelOpen(false)
    },
  })

  return (
    <div>
      <Link
        to="/jit"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 transition-colors hover:text-ink-100"
      >
        <ArrowLeft className="h-3.5 w-3.5" strokeWidth={2} /> Just-in-Time Access
      </Link>

      <QueryState query={requestQuery} skeletonRows={5}>
        {(request) => {
          const grant = extractGrant(request)
          const breakglass = request?.type === 'BREAKGLASS' || !!request?.is_breakglass

          return (
            <>
              <PageHeader
                eyebrow={breakglass ? 'Break-glass request' : 'Access request'}
                title={
                  <span className="flex min-w-0 items-center gap-2.5">
                    <span
                      className={clsx(
                        'flex h-8 w-8 flex-none items-center justify-center rounded-lg border',
                        breakglass
                          ? 'border-red-600/30 bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-300'
                          : 'border-surface-700 bg-surface-850 text-ink-400'
                      )}
                    >
                      {breakglass ? (
                        <ShieldAlert className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
                      ) : (
                        <KeyRound className="h-[1.05rem] w-[1.05rem]" strokeWidth={1.75} />
                      )}
                    </span>
                    <span className="truncate">{request?.resource_name || request?.resource_id || 'Access request'}</span>
                  </span>
                }
                description={
                  breakglass
                    ? 'Emergency elevation — recorded, alerted on, and reviewable after the fact.'
                    : 'Time-boxed elevation requested through the approval workflow.'
                }
                meta={
                  <>
                    <Badge className={JIT_STATUS_BADGE[request?.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                      {JIT_STATUS_LABELS[request?.status] || request?.status || '—'}
                    </Badge>
                    <CopyableId value={request?.id} />
                  </>
                }
              />

              <StateBanner request={request} grant={grant} onWithdraw={() => setCancelOpen(true)} />

              <div className="grid gap-5 lg:grid-cols-[1fr_1.15fr]">
                <Card className="h-fit overflow-hidden">
                  <CardHeader>
                    <CardTitle icon={Timer}>Lifecycle</CardTitle>
                  </CardHeader>
                  <Timeline request={request} grant={grant} />
                </Card>

                <div className="space-y-5">
                  <Card className="overflow-hidden">
                    <CardHeader>
                      <CardTitle icon={FileText}>Request</CardTitle>
                    </CardHeader>
                    <DetailList
                      items={[
                        { label: 'Resource', value: request?.resource_name || request?.resource_id || '—' },
                        { label: 'Type', value: breakglass ? 'Break-glass (emergency)' : 'Standard' },
                        { label: 'Action', value: request?.action || 'Any permitted action' },
                        {
                          label: 'Duration',
                          value: request?.duration_minutes ? `${request.duration_minutes} minutes` : '—',
                        },
                        {
                          label: 'Justification',
                          value: request?.reason ? (
                            <span className="block whitespace-pre-line leading-relaxed">{request.reason}</span>
                          ) : (
                            '—'
                          ),
                        },
                        { label: 'Ticket', value: request?.ticket_ref || '—' },
                        { label: 'Requested', value: formatDateTime(request?.created_at) },
                        ...(request?.decided_by || request?.approver_username
                          ? [{ label: 'Decided by', value: request.decided_by || request.approver_username }]
                          : []),
                        ...(request?.decision_reason || request?.denial_reason
                          ? [{ label: 'Decision note', value: request.decision_reason || request.denial_reason }]
                          : []),
                      ]}
                    />
                  </Card>

                  <Card className="overflow-hidden">
                    <CardHeader>
                      <CardTitle icon={Lock}>Resulting grant</CardTitle>
                      {grant?.status && (
                        <span className="ml-auto">
                          <Badge className={GRANT_STATUS_BADGE[grant.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                            {grant.status}
                          </Badge>
                        </span>
                      )}
                    </CardHeader>

                    {grant || request?.expires_at ? (
                      <DetailList
                        items={[
                          { label: 'Granted', value: formatDateTime(grant?.granted_at || request?.approved_at) },
                          { label: 'Expires', value: formatDateTime(grant?.expires_at || request?.expires_at) },
                          {
                            label: 'Time left',
                            value: <LiveCountdown targetIso={grant?.expires_at || request?.expires_at} />,
                          },
                        ]}
                      />
                    ) : (
                      <p className="px-4 py-6 text-sm leading-relaxed text-ink-500">
                        Nothing is granted yet. A grant appears here the moment this request is approved — it is the
                        object that actually carries your access, and it is what expires.
                      </p>
                    )}
                  </Card>
                </div>
              </div>

              <ConfirmDialog
                open={cancelOpen}
                title="Withdraw this request?"
                description="This withdraws the request before a decision is made. You can raise a new one later if you still need access."
                confirmLabel="Withdraw request"
                destructive
                requireReason
                reasonLabel="Reason (required for the audit record)"
                isLoading={cancelMutation.isPending}
                onConfirm={(reason) => cancelMutation.mutate(reason)}
                onCancel={() => setCancelOpen(false)}
              />
            </>
          )
        }}
      </QueryState>
    </div>
  )
}
