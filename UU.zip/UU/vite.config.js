import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The Flask IAM backend listens on :5000. During development we proxy the
// API + JWKS paths so cookies/CSP/origin are never an issue. For production
// builds set VITE_API_BASE_URL to your gateway and remove the proxy.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:5000', changeOrigin: true },
      '/well-known': { target: 'http://localhost:5000', changeOrigin: true },

      // AdapID (IDP) is a SEPARATE service on its own host. The SPA calls it
      // through this prefix so the browser stays same-origin (no CORS, and the
      // UI API key is never sent cross-site).
      //
      // `rewrite` is essential: the client requests /idp/api/tenants, and the
      // service exposes /api/tenants — without stripping the prefix the proxy
      // would forward /idp/api/tenants and every call would 404.
      '/idp': {
        target: 'https://idp.cf.adapid.link/idp',
        changeOrigin: true,
        // The target is HTTPS with a real certificate; keep verification on.
        secure: true,
        rewrite: (path) => path.replace(/^\/idp/, ''),
      },
    },
  },
  // NOTE: `build` previously sat INSIDE `server`, where Vite ignores it.
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
