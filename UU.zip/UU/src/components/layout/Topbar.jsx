/**
 * Topbar — the product header.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * DESIGN DECISIONS
 * ═══════════════════════════════════════════════════════════════════════════
 * Layout: [menu] [logo] │ IAM · IDP▾ · PAM ────────── tenant · alerts · profile
 *
 *  · Product switcher sits next to the logo, not floating on the right: these
 *    tabs change the whole working context, so they belong with the identity
 *    lockup rather than with the account controls.
 *  · Active tab = tinted pill + 2px underline anchored to the header edge.
 *  · Right cluster is account/tenant context only: active tenant, MFA posture,
 *    notifications, profile. The decorative live clock has been removed —
 *    every timestamp in the product is already absolute.
 *  · Responsive: below `sm` the tabs collapse to a compact scrollable row and
 *    the tenant chip / profile text are dropped, never the profile itself.
 * ═══════════════════════════════════════════════════════════════════════════
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Menu, Bell, LogOut, User as UserIcon, ShieldAlert, Building2, Search,
  Smartphone, MonitorSmartphone, Shield, ChevronDown, ChevronRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { initials, classNames } from '../../utils/format.js';
import { isAdmin } from '../../utils/permissions.js';
import { Logo } from '../common/Logo.jsx';
import { useAlertNotifications } from '../../hooks/useAlertNotifications.js';

const TABS = [
  { id: 'iam', label: 'IAM', description: 'Identity & Access Management', to: '/' },
  {
    id: 'idp',
    label: 'IDP',
    description: 'Identity Provider Federation',
    children: [
      { label: 'Overview', to: '/idp/overview', description: 'All adopted tenants' },
      { label: 'Tenants', to: '/idp/tenants', description: 'Adopt a new tenant' },
    ],
  },
  { id: 'pam', label: 'PAM', description: 'Privileged Access Management', to: '/pam' },
];

function getActiveTab(pathname) {
  if (pathname.startsWith('/idp')) return 'idp';
  if (pathname.startsWith('/pam') || pathname === '/audit-logs') return 'pam';
  return 'iam';
}

export function Topbar({ onMenu }) {
  const { user, logout, accountId } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [menuOpen, setMenuOpen] = useState(false);
  const [idpOpen, setIdpOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const menuRef = useRef(null);
  const triggerRef = useRef(null);
  const idpRef = useRef(null);

  const activeTab = getActiveTab(location.pathname);
  const admin = isAdmin(user);

  /* Denial alerts drive the bell. The unread count is the number of DENY events
     recorded since the admin last reviewed the Alerts tab — see the hook for
     how the baseline is kept. Polling is admin-only: the endpoint is gated to
     root administrators, so there is nothing to ask for otherwise. */
  const { unread, total, lastCheckedAt, markRead } = useAlertNotifications(accountId, {
    enabled: admin,
  });

  const openAlerts = useCallback(() => {
    // Reviewing resets the badge; the next denial starts counting again at 1.
    markRead();
    navigate('/pam?tab=alerts');
  }, [markRead, navigate]);

  const bellTitle = unread
    ? `${unread} new denial alert${unread === 1 ? '' : 's'} — open the Alerts tab`
    : total != null
      ? `No new denial alerts${lastCheckedAt ? ` · checked ${lastCheckedAt.toLocaleTimeString()}` : ''}`
      : 'Security alerts';

  useEffect(() => {
    if (!menuOpen && !idpOpen) return undefined;
    const handleClick = (e) => {
      if (menuOpen && menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
      if (idpOpen && idpRef.current && !idpRef.current.contains(e.target)) setIdpOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [menuOpen, idpOpen]);

  useEffect(() => {
    setIdpOpen(false);
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (menuOpen) setActiveIndex(-1);
  }, [menuOpen]);

  const handleLogout = useCallback(
    async (allSessions = false) => {
      await logout(allSessions);
      toast.success('Signed out.');
      navigate('/login', { replace: true });
    },
    [logout, toast, navigate]
  );

  const navigateAndClose = useCallback(
    (path) => {
      setMenuOpen(false);
      navigate(path);
    },
    [navigate]
  );

  // Keyboard model for the profile menu (5 actionable rows).
  const menuActions = [
    () => navigateAndClose('/profile'),
    () => navigateAndClose('/security/mfa'),
    () => navigateAndClose('/security/sessions'),
    () => {
      setMenuOpen(false);
      handleLogout(false);
    },
    () => {
      setMenuOpen(false);
      handleLogout(true);
    },
  ];

  const handleMenuKeyDown = useCallback(
    (e) => {
      if (!menuOpen) return;
      if (e.key === 'Escape') {
        e.preventDefault();
        setMenuOpen(false);
        triggerRef.current?.focus();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setActiveIndex((p) => Math.min(p + 1, menuActions.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setActiveIndex((p) => Math.max(p - 1, 0));
      } else if (e.key === 'Enter' || e.key === ' ') {
        if (activeIndex >= 0) {
          e.preventDefault();
          menuActions[activeIndex]?.();
        }
      }
    },
    [menuOpen, activeIndex, menuActions]
  );

  return (
    <header
      className="fixed inset-x-0 top-0 z-50 flex h-14 items-center gap-2 border-b border-line bg-white/95 px-3 backdrop-blur supports-[backdrop-filter]:bg-white/85 sm:px-4 lg:px-5"
      role="banner"
    >
      {/* Mobile navigation trigger */}
      <button
        type="button"
        onClick={onMenu}
        className="-ml-1 rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 hover:text-ink-800 lg:hidden"
        aria-label="Open navigation"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Logo → dashboard */}
      <button
        type="button"
        onClick={() => navigate('/')}
        title="Go to dashboard"
        className="flex shrink-0 items-center rounded-lg transition-opacity hover:opacity-80"
      >
        <Logo variant="appbar" />
      </button>

      <div className="mx-1 hidden h-6 w-px bg-line sm:mx-2.5 sm:block lg:mx-3" />

      {/* Product switcher — centred in the header on desktop, inline on mobile */}
      <nav
        className={classNames(
          'no-scrollbar flex min-w-0 flex-1 items-center gap-1 overflow-x-auto px-1',
          'justify-start lg:absolute lg:left-1/2 lg:flex-none lg:-translate-x-1/2 lg:justify-center lg:overflow-visible lg:px-0'
        )}
        role="tablist"
        aria-label="Product areas"
      >
        {TABS.map((tab) => {
          const isActive = tab.id === activeTab;
          const base = classNames(
            'relative flex h-9 shrink-0 items-center gap-1 rounded-lg px-3 text-[13.5px] font-semibold transition-colors duration-100',
            isActive
              ? 'bg-brand-50 text-brand-800'
              : 'text-slate-500 hover:bg-slate-100 hover:text-ink-800'
          );

          if (tab.children) {
            return (
              <div key={tab.id} className="relative shrink-0" ref={idpRef}>
                <button
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  aria-expanded={idpOpen}
                  onClick={() => setIdpOpen((o) => !o)}
                  title={tab.description}
                  className={base}
                >
                  {tab.label}
                  <ChevronDown
                    className={classNames('h-3.5 w-3.5 transition-transform', idpOpen && 'rotate-180')}
                  />
                  {isActive && (
                    <span className="absolute -bottom-[11px] left-2 right-2 h-[2px] rounded-full bg-brand-600" />
                  )}
                </button>

                {idpOpen && (
                  <div className="absolute left-0 z-50 mt-2 w-60 overflow-hidden rounded-xl border border-line bg-white p-1.5 shadow-popover animate-pop-in">
                    {tab.children.map((child) => {
                      const childActive = location.pathname === child.to;
                      return (
                        <button
                          key={child.to}
                          type="button"
                          onClick={() => {
                            navigate(child.to);
                            setIdpOpen(false);
                          }}
                          className={classNames(
                            'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left transition-colors',
                            childActive
                              ? 'bg-brand-50 text-brand-800'
                              : 'text-ink-700 hover:bg-slate-50'
                          )}
                        >
                          <span className="min-w-0 flex-1">
                            <span className="block text-[13px] font-semibold">{child.label}</span>
                            <span className="block text-2xs text-slate-400">{child.description}</span>
                          </span>
                          <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-300" />
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }

          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              onClick={() => navigate(tab.to)}
              title={tab.description}
              className={base}
            >
              {tab.label}
              {isActive && (
                <span className="absolute -bottom-[11px] left-2 right-2 h-[2px] rounded-full bg-brand-600" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Spacer: the centred nav is out of flow on desktop, so this keeps the
          account cluster pinned to the right edge. */}
      <div className="hidden lg:block lg:flex-1" />

      {/* Right cluster — search + tenant + posture + account */}
      <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
        {/* Global search: the fastest path to any object in the tenant. */}
        <button
          type="button"
          onClick={() => window.dispatchEvent(new Event('iam:command-palette'))}
          title="Search users, roles, groups, policies (⌘K)"
          /* Neutral focus treatment instead of the global blue focus ring. */
          className="hidden items-center gap-2 rounded-lg border border-line bg-slate-50 py-1.5 pl-2.5 pr-2 text-2xs text-slate-500 transition-colors hover:border-slate-300 hover:bg-white focus:outline-none focus-visible:border-slate-400 focus-visible:outline-none md:inline-flex"
        >
          <Search className="h-3.5 w-3.5 text-slate-400" />
          <span className="pr-6">Search…</span>
          <kbd className="rounded border border-line bg-white px-1 py-0.5 font-sans text-3xs font-medium text-slate-500">
            ⌘K
          </kbd>
        </button>
        <button
          type="button"
          onClick={() => window.dispatchEvent(new Event('iam:command-palette'))}
          aria-label="Search"
          className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 hover:text-ink-800 focus:outline-none focus-visible:bg-slate-100 focus-visible:outline-none md:hidden"
        >
          <Search className="h-4.5 w-4.5" />
        </button>
        {accountId && (
          <span
            className="hidden items-center gap-1.5 rounded-lg border border-line bg-slate-50 px-2.5 py-1.5 text-2xs font-medium text-slate-600 xl:inline-flex"
            title="Active tenant / account"
          >
            <Building2 className="h-3.5 w-3.5 text-slate-400" />
            <span className="max-w-[160px] truncate font-mono tracking-tight">{accountId}</span>
          </span>
        )}

        {!user?.mfa_enabled && (
          <button
            type="button"
            onClick={() => navigate('/security/mfa')}
            title="Multi-factor authentication is not enabled"
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-50 px-2 py-1.5 text-2xs font-semibold text-amber-700 ring-1 ring-inset ring-amber-200 transition-colors hover:bg-amber-100"
          >
            <ShieldAlert className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">MFA off</span>
          </button>
        )}

        {/* Notifications — denial alerts. Opens the PAM page on its Alerts tab
            (PamPage reads the `tab` query param) and clears the unread badge.
            Restraint is deliberate: the icon only takes colour while something
            is genuinely unread, so a quiet header stays quiet. */}
        <button
          type="button"
          className={classNames(
            'relative rounded-lg p-2 transition-colors duration-150 focus:outline-none focus-visible:bg-slate-100 focus-visible:outline-none',
            unread > 0
              ? 'text-rose-600 hover:bg-rose-50'
              : 'text-slate-500 hover:bg-slate-100 hover:text-ink-800'
          )}
          aria-label={
            unread > 0
              ? `Notifications — ${unread} unread denial alert${unread === 1 ? '' : 's'}`
              : 'Notifications'
          }
          onClick={openAlerts}
          title={bellTitle}
        >
          <Bell className="h-4.5 w-4.5" />
          {unread > 0 && (
            <>
              {/* One-off ping on arrival, then stillness — no perpetual motion
                  in a header an operator stares at all day. */}
              <span
                aria-hidden="true"
                className="pointer-events-none absolute right-1 top-1 h-2 w-2 animate-ping rounded-full bg-rose-400/70"
                style={{ animationIterationCount: 3 }}
              />
              <span
                aria-hidden="true"
                className={classNames(
                  'pointer-events-none absolute -right-0.5 -top-0.5 flex items-center justify-center rounded-full bg-rose-600 text-3xs font-bold leading-none text-white ring-2 ring-white',
                  unread > 9 ? 'h-4 min-w-[18px] px-1' : 'h-4 w-4'
                )}
              >
                {unread > 99 ? '99+' : unread > 9 ? `${unread}` : unread}
              </span>
            </>
          )}
        </button>

        <div className="hidden h-6 w-px bg-line sm:block" />

        {/* Profile */}
        <div className="relative" ref={menuRef}>
          <button
            ref={triggerRef}
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            onKeyDown={handleMenuKeyDown}
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            className={classNames(
              'flex items-center gap-2 rounded-lg p-1 pr-1.5 transition-colors sm:pr-2',
              menuOpen ? 'bg-slate-100' : 'hover:bg-slate-100'
            )}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-2xs font-bold text-white">
              {initials(user?.username || user?.email || 'U')}
            </span>
            <span className="hidden max-w-[160px] text-left md:block">
              <span className="block truncate text-[13px] font-semibold leading-tight text-ink-900">
                {user?.username || user?.email}
              </span>
              <span className="block truncate text-2xs leading-tight text-slate-500">
                {admin ? 'Administrator' : user?.account_type || 'User'}
              </span>
            </span>
          </button>

          {menuOpen && (
            <div
              role="menu"
              onKeyDown={handleMenuKeyDown}
              className="absolute right-0 z-50 mt-2 w-72 overflow-hidden rounded-xl border border-line bg-white shadow-popover animate-pop-in"
            >
              <div className="border-b border-line-soft px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-[13px] font-bold text-white">
                    {initials(user?.username || user?.email || 'U')}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold text-ink-900">
                      {user?.username || user?.email}
                    </p>
                    <p className="truncate text-2xs text-slate-500">{user?.email}</p>
                  </div>
                  {admin && (
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-md bg-brand-50 px-1.5 py-0.5 text-3xs font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">
                      <Shield className="h-2.5 w-2.5" />
                      Admin
                    </span>
                  )}
                </div>
                {accountId && (
                  <p className="mt-2.5 flex items-center gap-1.5 text-2xs text-slate-500">
                    <Building2 className="h-3 w-3 text-slate-400" />
                    <span className="font-mono">{accountId}</span>
                  </p>
                )}
              </div>

              <div className="py-1.5">
                <DropdownItem
                  icon={UserIcon}
                  label="My profile"
                  onClick={menuActions[0]}
                  index={0}
                  activeIndex={activeIndex}
                />
              </div>

              <div className="border-t border-line-soft py-1.5">
                <p className="px-4 pb-1 pt-1.5 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
                  Security
                </p>
                <DropdownItem
                  icon={Smartphone}
                  label="Multi-factor authentication"
                  onClick={menuActions[1]}
                  index={1}
                  activeIndex={activeIndex}
                />
                <DropdownItem
                  icon={MonitorSmartphone}
                  label="Active sessions"
                  onClick={menuActions[2]}
                  index={2}
                  activeIndex={activeIndex}
                />
              </div>

              <div className="border-t border-line-soft py-1.5">
                <DropdownItem
                  icon={LogOut}
                  label="Sign out"
                  onClick={menuActions[3]}
                  index={3}
                  activeIndex={activeIndex}
                />
                <DropdownItem
                  icon={LogOut}
                  label="Sign out everywhere"
                  onClick={menuActions[4]}
                  index={4}
                  activeIndex={activeIndex}
                  danger
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function DropdownItem({ icon: Icon, label, onClick, danger = false, index, activeIndex }) {
  const isActive = index === activeIndex;
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onClick}
      className={classNames(
        'flex w-full items-center gap-2.5 px-4 py-2 text-[13px] font-medium transition-colors',
        danger
          ? isActive
            ? 'bg-rose-50 text-rose-700'
            : 'text-rose-600 hover:bg-rose-50'
          : isActive
            ? 'bg-slate-100 text-ink-900'
            : 'text-ink-700 hover:bg-slate-50'
      )}
    >
      <Icon className="h-4 w-4 shrink-0 text-slate-400" />
      <span>{label}</span>
    </button>
  );
}
