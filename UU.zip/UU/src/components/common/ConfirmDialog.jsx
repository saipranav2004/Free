import { useState, useId } from 'react'
import { AlertTriangle, X } from 'lucide-react'
import { Spinner } from './Spinner'

// A real confirm() modal, not window.confirm() — window.confirm is
// synchronous and blocks the whole tab (including any pending fetch/timer
// callbacks), renders inconsistently across browsers, and can't show a
// reason-required text field for the destructive actions here (revoke
// grant, kill session, deny request) that the backend requires an
// audit-logged reason for anyway.
//
// requireReason: when true, the confirm button stays disabled until the
// user types something — this exists because several backend endpoints
// (deny, revoke) 400 with "a reason is required for the audit record" if
// the reason is blank, and surfacing that as a disabled button beats a
// round-trip just to learn the field was required.
export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  destructive = true,
  requireReason = false,
  reasonLabel = 'Reason',
  isLoading = false,
  onConfirm,
  onCancel,
}) {
  const [reason, setReason] = useState('')
  const titleId = useId()

  if (!open) return null

  const canConfirm = !requireReason || reason.trim().length > 0

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
      onKeyDown={(e) => {
        if (e.key === 'Escape' && !isLoading) onCancel()
      }}
    >
      <div className="w-full max-w-md rounded-lg border border-surface-700 bg-surface-900 p-5 shadow-xl">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            {destructive && <AlertTriangle className="mt-0.5 h-5 w-5 flex-none text-amber-600 dark:text-amber-400" />}
            <div>
              <h3 id={titleId} className="text-sm font-semibold text-ink-50">
                {title}
              </h3>
              {description && <p className="mt-1 text-sm text-ink-400">{description}</p>}
            </div>
          </div>
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="text-ink-500 hover:text-ink-200 disabled:opacity-40"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {requireReason && (
          <div className="mt-4">
            <label className="mb-1 block text-xs font-medium text-ink-400">{reasonLabel}</label>
            <textarea
              autoFocus
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full rounded-md border border-surface-700 bg-surface-800 px-3 py-2 text-sm text-ink-50 placeholder:text-ink-500 focus:border-blue-500 focus:outline-none"
              placeholder="Required — recorded in the audit log"
            />
          </div>
        )}

        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="rounded-md px-3 py-1.5 text-sm text-ink-300 hover:bg-surface-800 disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirm(reason.trim())}
            disabled={!canConfirm || isLoading}
            className={
              'flex items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium text-white disabled:pointer-events-none disabled:opacity-40 ' +
              (destructive ? 'bg-red-600 hover:bg-red-500' : 'bg-blue-600 hover:bg-blue-500')
            }
          >
            {isLoading && <Spinner size="h-3.5 w-3.5" className="text-white" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
