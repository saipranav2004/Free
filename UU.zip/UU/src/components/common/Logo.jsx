/**
 * Logo component — displays the company logo from /das_logo_light.png
 * Falls back to ShieldCheck icon if the image fails to load.
 *
 * Premium enterprise pattern:
 * - Logo is raw image with NO box, NO container, NO background wrapper
 * - Logo is BIG and WIDE for premium enterprise appearance
 * - Clean, professional appearance in light mode
 */
import { useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { classNames } from '../../utils/format.js';

export function Logo({ className = '', size = 'md', variant = 'dashboard' }) {
  const [imgError, setImgError] = useState(false);

  /**
   * appbar — the console header lockup: a raw, height-capped image flush with
   * the header's own padding. Kept separate from `topbar` (which the sign-in
   * screen depends on) so the auth screens are never affected.
   */
  if (variant === 'appbar') {
    if (imgError) {
      return (
        <span className={classNames('flex items-center gap-2 text-brand-700', className)}>
          <ShieldCheck className="h-6 w-6" />
          <span className="text-[15px] font-semibold tracking-tight text-ink-900">
            IAM Control Center
          </span>
        </span>
      );
    }
    return (
      <img
        src="/das_logo_light.png"
        alt="Company logo"
        className={classNames('h-10 w-auto max-w-[500px] object-contain object-left sm:h-14', className)}
        onError={() => setImgError(true)}
      />
    );
  }

  // Enterprise sizing
  const sizes = {
    xs: 'h-6 w-6',
    sm: 'h-8 w-8',
    md: 'h-10 w-10',
    lg: 'h-14 w-14',
    xl: 'h-14 w-64',  // Topbar: very wide for sidebar coverage
  };

  const iconSizes = {
    xs: 'h-3.5 w-3.5',
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-7 w-7',
    xl: 'h-8 w-8',
  };

  // Topbar variant: raw image, no box, BIG and WIDE
  if (variant === 'topbar') {
    if (imgError) {
      return (
        <div className={classNames(
          'flex items-center justify-center text-brand-600',
          className
        )}>
          <ShieldCheck className="h-10 w-10" />
        </div>
      );
    }

    return (
      <img
        src="/das_logo_light.png"
        alt="Company Logo"
        className={classNames(
          'h-14 w-35 object-left ml-8',
          className
        )}
        onError={() => setImgError(true)}
      />
    );
  }

  // Clean variant: just the raw logo image, no wrapper
  if (variant === 'clean') {
    if (imgError) {
      return (
        <div className={classNames(
          'flex items-center justify-center text-brand-600',
          sizes[size],
          className
        )}>
          <ShieldCheck className={iconSizes[size]} />
        </div>
      );
    }

    return (
      <img
        src="/das_logo_light.png"
        alt="Company Logo"
        className={classNames(
          'object-contain',
          sizes[size],
          className
        )}
        onError={() => setImgError(true)}
      />
    );
  }

  // Login variant
  if (variant === 'login') {
    if (imgError) {
      return (
        <div className={classNames(
          'flex items-center justify-center rounded-xl bg-brand-600 text-white shadow-lg shadow-brand-600/30',
          sizes[size],
          className
        )}>
          <ShieldCheck className={iconSizes[size]} />
        </div>
      );
    }

    return (
      <div className={classNames(
        'flex items-center justify-center rounded-xl bg-brand-600 shadow-lg shadow-brand-600/30 overflow-hidden',
        sizes[size],
        className
      )}>
        <img
          src="/das_logo_light.png"
          alt="Company Logo"
          className="h-full w-full object-contain"
          onError={() => setImgError(true)}
        />
      </div>
    );
  }

  // Default dashboard variant
  if (imgError) {
    return (
      <div className={classNames(
        'flex items-center justify-center rounded-lg bg-white text-brand-600 border border-slate-200 shadow-sm',
        sizes[size],
        className
      )}>
        <ShieldCheck className={iconSizes[size]} />
      </div>
    );
  }

  return (
    <div className={classNames(
      'flex items-center justify-center rounded-lg overflow-hidden bg-white border border-slate-200 shadow-sm',
      sizes[size],
      className
    )}>
      <img
        src="/das_logo_light.png"
        alt="Company Logo"
        className="h-full w-full object-contain"
        onError={() => setImgError(true)}
      />
    </div>
  );
}
