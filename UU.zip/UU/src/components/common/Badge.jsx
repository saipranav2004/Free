import clsx from 'clsx'

// A tiny wrapper, but the point is that every status badge in the app goes
// through this one component with the same ring/padding/weight — so a
// design tweak is a one-file change, not a grep-and-replace across 20 files.
export function Badge({ children, className }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset',
        className || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'
      )}
    >
      {children}
    </span>
  )
}
