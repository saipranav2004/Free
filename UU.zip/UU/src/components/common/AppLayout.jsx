import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import clsx from 'clsx'
import {
  LayoutDashboard, Boxes, Vault, Radio, KeyRound, ScrollText, ShieldAlert,
  LogOut, Settings as SettingsIcon, Users, Lock, FileKey2, ServerCog,
  ClipboardList, Archive, Menu, X, ChevronDown,
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { me, logout as logoutApi } from '../../api/auth'
import { ROLE_BADGE } from '../../config/constants'
import { Badge } from './Badge'
import { ThemeToggle } from './ThemeToggle'
import { toast } from 'sonner'

// Self-service — visible to every authenticated user, regardless of role.
const CONSOLE_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/resources', label: 'Resources', icon: Boxes },
  { to: '/vault', label: 'Vault', icon: Vault },
  { to: '/sessions', label: 'Sessions', icon: Radio },
  { to: '/jit', label: 'JIT Access', icon: KeyRound },
  { to: '/audit', label: 'Audit', icon: ScrollText },
]

// Admin Center — only rendered for accounts holding the "admin" or "root"
// role (see AdminRoute for the matching route guard). This is PAM's own
// central control plane now; there is no separate admin login, just a
// section of the same console that appears once the JWT says you're allowed
// to see it.
const ADMIN_NAV = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/identity', label: 'Identity', icon: Users },
  { to: '/admin/roles', label: 'Roles', icon: Lock },
  { to: '/admin/policies', label: 'Policies', icon: FileKey2 },
  { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound },
  { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
  { to: '/admin/vault-ops', label: 'Vault Operations', icon: Archive },
]

function NavItem({ to, label, icon: Icon, end, onNavigate }) {
  return (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      className={({ isActive }) =>
        clsx(
          'flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors',
          isActive
            ? 'bg-blue-600/10 text-blue-600 dark:bg-blue-500/10 dark:text-blue-300'
            : 'text-ink-400 hover:bg-surface-800 hover:text-ink-100'
        )
      }
    >
      <Icon className="h-4 w-4 flex-none" />
      {label}
    </NavLink>
  )
}

function SidebarContent({ isAdmin, onNavigate }) {
  return (
    <>
      <div className="flex items-center gap-2 px-4 py-5">
        <div className="flex h-7 w-7 flex-none items-center justify-center rounded-md bg-blue-600 text-white">
          <ServerCog className="h-4 w-4" />
        </div>
        <h1 className="text-sm font-semibold tracking-wide text-ink-50">PAM CONSOLE</h1>
      </div>

      <nav className="flex-1 space-y-4 overflow-y-auto px-2 pb-4">
        <div className="space-y-0.5">
          {CONSOLE_NAV.map((item) => (
            <NavItem key={item.to} {...item} onNavigate={onNavigate} />
          ))}
        </div>

        {isAdmin && (
          <div>
            <div className="flex items-center gap-1.5 px-3 pb-1.5 pt-2">
              <ShieldAlert className="h-3 w-3 text-amber-500 dark:text-amber-400" />
              <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">
                Admin Center
              </span>
            </div>
            <div className="space-y-0.5">
              {ADMIN_NAV.map((item) => (
                <NavItem key={item.to} {...item} onNavigate={onNavigate} />
              ))}
            </div>
          </div>
        )}
      </nav>
    </>
  )
}

export function AppLayout() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const setUser = useAuthStore((s) => s.setUser)
  const doLogout = useAuthStore((s) => s.logout)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  // /auth/me is the source of truth for "who am I" — login only returns
  // access_token/expires_at, not the user's profile, so this fetch is what
  // actually populates the header/username/roles rather than showing blank
  // (and is also what AdminRoute/the nav's isAdmin() check depends on).
  const meQuery = useQuery({ queryKey: ['me'], queryFn: ({ signal }) => me(signal), retry: false })

  useEffect(() => {
    if (meQuery.data) setUser(meQuery.data)
  }, [meQuery.data, setUser])

  const handleLogout = async () => {
    try {
      await logoutApi()
    } catch {
      // Even if the server-side logout call fails (network blip, already
      // expired token), we still clear the local session below — a failed
      // logout call must never leave the user stuck "logged in" client-side
      // when they explicitly asked to log out.
    } finally {
      doLogout()
      navigate('/login', { replace: true })
      toast.success('Logged out')
    }
  }

  const roles = user?.roles || []

  return (
    // h-screen + overflow-hidden pins this whole shell to exactly the
    // viewport height, so the browser's own document scrollbar never kicks
    // in. Previously this was min-h-screen, which lets the container grow
    // taller than the viewport with tall page content — at that point the
    // *document* scrolls, dragging the sidebar along with everything else
    // instead of leaving it in place. Now only <main> below scrolls
    // internally; the sidebar (and topbar) stay fixed on screen.
    <div className="flex h-screen overflow-hidden bg-surface-950">
      {/* Desktop sidebar — bounded to the parent's h-screen height via flex
          stretch; the nav list inside SidebarContent scrolls internally
          (overflow-y-auto) while SidebarFooter stays pinned at the bottom. */}
      <aside className="hidden w-60 flex-none flex-col border-r border-surface-800 bg-surface-900 md:flex">
        <SidebarContent isAdmin={isAdmin} onNavigate={() => {}} />
        <SidebarFooter
          user={user}
          roles={roles}
          loadingUser={meQuery.isLoading}
          onLogout={handleLogout}
        />
      </aside>

      {/* Mobile sidebar (overlay) */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setMobileNavOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative flex w-64 flex-col border-r border-surface-800 bg-surface-900 shadow-pop">
            <button
              onClick={() => setMobileNavOpen(false)}
              className="absolute right-3 top-4 text-ink-400 hover:text-ink-100"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent isAdmin={isAdmin} onNavigate={() => setMobileNavOpen(false)} />
            <SidebarFooter
              user={user}
              roles={roles}
              loadingUser={meQuery.isLoading}
              onLogout={handleLogout}
            />
          </aside>
        </div>
      )}

      {/* min-h-0 overrides flex's default min-height:auto — without it, a
          flex child (main, below) can't shrink below its content height,
          so overflow-y-auto never actually engages and the page scrolls as
          a whole instead of just the content area. */}
      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="flex h-14 flex-none items-center gap-3 border-b border-surface-800 bg-surface-900/60 px-4 backdrop-blur md:justify-end">
          <button
            onClick={() => setMobileNavOpen(true)}
            className="text-ink-400 hover:text-ink-100 md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <span className="flex-1 text-sm font-medium text-ink-50 md:hidden">PAM Console</span>

          <ThemeToggle compact />

          <div className="relative">
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-ink-200 hover:bg-surface-800"
            >
              <span className="hidden max-w-[10rem] truncate sm:inline" title={user?.username}>
                {user?.username || (meQuery.isLoading ? '…' : 'Signed in')}
              </span>
              <ChevronDown className="h-3.5 w-3.5 text-ink-500" />
            </button>
            {userMenuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
                <div className="absolute right-0 z-20 mt-1 w-48 rounded-md border border-surface-700 bg-surface-900 py-1 shadow-pop">
                  <div className="border-b border-surface-800 px-3 py-2">
                    <p className="truncate text-sm font-medium text-ink-50">{user?.username}</p>
                    <p className="truncate text-xs text-ink-500">{user?.email}</p>
                  </div>
                  <NavLink
                    to="/settings"
                    onClick={() => setUserMenuOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-ink-200 hover:bg-surface-800"
                  >
                    <SettingsIcon className="h-3.5 w-3.5" /> Settings
                  </NavLink>
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-red-600 dark:text-red-500 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                  >
                    <LogOut className="h-3.5 w-3.5" /> Log out
                  </button>
                </div>
              </>
            )}
          </div>
        </header>

        <main className="min-w-0 flex-1 overflow-y-auto">
          <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}

function SidebarFooter({ user, roles, loadingUser, onLogout }) {
  return (
    <div className="border-t border-surface-800 p-3">
      <div className="flex items-center justify-between gap-2 rounded-md px-1 py-1">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-ink-200" title={user?.username}>
            {user?.username || (loadingUser ? '…' : 'Signed in')}
          </p>
          <div className="mt-1 flex flex-wrap gap-1">
            {roles.length === 0 && !loadingUser && (
              <Badge className="bg-ink-500/15 text-ink-500 ring-ink-500/30">no roles</Badge>
            )}
            {roles.map((r) => (
              <Badge key={r} className={ROLE_BADGE[r] || ROLE_BADGE.user}>
                {r}
              </Badge>
            ))}
          </div>
        </div>
        <button
          onClick={onLogout}
          className="flex-none rounded-md p-1.5 text-ink-500 hover:bg-surface-800 hover:text-red-600 dark:hover:text-red-500 dark:hover:text-red-400"
          title="Log out"
          aria-label="Log out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
