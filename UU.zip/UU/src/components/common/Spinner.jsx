import { Loader2 } from 'lucide-react'
import clsx from 'clsx'

export function Spinner({ className, size = 'h-5 w-5' }) {
  return <Loader2 className={clsx(size, 'animate-spin text-ink-400', className)} aria-label="Loading" />
}

export function FullPageSpinner({ label = 'Loading…' }) {
  return (
    <div className="flex min-h-[40vh] flex-col items-center justify-center gap-3 text-ink-400">
      <Spinner size="h-8 w-8" />
      <span className="text-sm">{label}</span>
    </div>
  )
}
