import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, Eye, History, KeyRound, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'
import {
  getCredential,
  createCredentialVersion,
  passwordChange,
  requestCredentialRotation,
} from '../../api/vault'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Field, inputClass } from '../../components/common/FormFields'
import { Spinner } from '../../components/common/Spinner'
import { RevealCredentialModal } from '../../components/vault/RevealCredentialModal'
import { formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'

const versionSchema = z.object({
  secret_plaintext: z.string().trim().min(1, 'Required'),
  reason: z.string().optional(),
})

const quickChangeSchema = z.object({
  secret_plaintext: z.string().trim().min(1, 'Required'),
})

function AddVersionForm({ credentialId }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(versionSchema) })

  const mutation = useMutation({
    mutationFn: (values) => createCredentialVersion(credentialId, values.secret_plaintext, values.reason),
    onSuccess: () => {
      toast.success('New version stored')
      queryClient.invalidateQueries({ queryKey: ['vault', 'credentials', credentialId] })
      reset()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate className="space-y-3">
      <Field label="New secret" error={errors.secret_plaintext?.message} required>
        <textarea rows={2} className={inputClass(!!errors.secret_plaintext) + ' font-mono'} {...register('secret_plaintext')} />
      </Field>
      <Field label="Reason" hint="Optional — recorded with the new version.">
        <input className={inputClass(false)} {...register('reason')} />
      </Field>
      <button
        type="submit"
        disabled={mutation.isPending}
        className="flex items-center gap-2 rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
      >
        {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
        <History className="h-3.5 w-3.5" /> Add version
      </button>
    </form>
  )
}

function QuickChangeForm({ credentialId }) {
  const queryClient = useQueryClient()
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(quickChangeSchema) })

  const mutation = useMutation({
    mutationFn: (values) => passwordChange(credentialId, values.secret_plaintext),
    onSuccess: () => {
      toast.success('Password changed')
      queryClient.invalidateQueries({ queryKey: ['vault', 'credentials', credentialId] })
      reset()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate className="space-y-3">
      <Field
        label="New secret"
        error={errors.secret_plaintext?.message}
        hint="Records the same audit trail as 'Add version', with a fixed reason of 'Manual password change'."
        required
      >
        <textarea rows={2} className={inputClass(!!errors.secret_plaintext) + ' font-mono'} {...register('secret_plaintext')} />
      </Field>
      <button
        type="submit"
        disabled={mutation.isPending}
        className="flex items-center gap-2 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
      >
        {mutation.isPending && <Spinner size="h-3.5 w-3.5" />}
        <KeyRound className="h-3.5 w-3.5" /> Quick password change
      </button>
    </form>
  )
}

export default function CredentialDetailPage() {
  const { safeId, credentialId } = useParams()
  const queryClient = useQueryClient()
  const [revealOpen, setRevealOpen] = useState(false)

  const credentialQuery = useQuery({
    queryKey: ['vault', 'credentials', credentialId],
    queryFn: ({ signal }) => getCredential(credentialId, signal),
  })

  const rotationMutation = useMutation({
    mutationFn: () => requestCredentialRotation(credentialId),
    onSuccess: (job) => {
      toast.success(`Rotation job ${job.status === 'pending' ? 'queued' : job.status}`)
      queryClient.invalidateQueries({ queryKey: ['vault', 'credentials', credentialId] })
    },
    // A 409 here means a rotation is already in progress for this credential
    // (services.ErrRotationInProgress) — the generic 409 message from
    // apiErrorMessage already covers this clearly enough not to need a
    // special case, but the button being disabled while pending prevents
    // most double-submits from ever reaching the server at all.
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <div>
      <Link
        to={`/vault/${safeId}`}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 hover:text-ink-200"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to safe
      </Link>

      <QueryState query={credentialQuery}>
        {(cred) => (
          <>
            <PageHeader
              title={cred.name}
              description={`${cred.account_name} · ${cred.credential_type}`}
              actions={
                <button
                  onClick={() => setRevealOpen(true)}
                  className="flex items-center gap-1.5 rounded-md bg-amber-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-amber-500"
                >
                  <Eye className="h-4 w-4" /> Reveal
                </button>
              }
            />

            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <h3 className="text-sm font-semibold text-ink-50">Details</h3>
                </CardHeader>
                <div className="p-4">
                  <dl className="grid grid-cols-[140px_1fr] gap-y-2 text-sm">
                    <dt className="text-ink-500">Status</dt>
                    <dd>
                      <Badge
                        className={
                          cred.status === 'active'
                            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30'
                            : 'bg-ink-500/15 text-ink-400 ring-ink-500/30'
                        }
                      >
                        {cred.status}
                      </Badge>
                    </dd>
                    <dt className="text-ink-500">Version</dt>
                    <dd className="text-ink-100">{cred.version}</dd>
                    <dt className="text-ink-500">Rotation interval</dt>
                    <dd className="text-ink-100">
                      {cred.rotation_interval_days > 0 ? `${cred.rotation_interval_days} days` : 'Manual only'}
                    </dd>
                    <dt className="text-ink-500">Last rotated</dt>
                    <dd className="text-ink-100">{formatDateTime(cred.last_rotated_at)}</dd>
                    <dt className="text-ink-500">Next rotation</dt>
                    <dd className="text-ink-100">{formatDateTime(cred.next_rotation_at)}</dd>
                    {cred.is_breakglass && (
                      <>
                        <dt className="text-ink-500">Break-glass</dt>
                        <dd>
                          <Badge className="bg-red-500/15 text-red-700 dark:text-red-300 ring-red-500/30">
                            {cred.breakglass_note || 'Emergency-access credential'}
                          </Badge>
                        </dd>
                      </>
                    )}
                  </dl>

                  <div className="mt-4 border-t border-surface-800 pt-4">
                    <button
                      onClick={() => rotationMutation.mutate()}
                      disabled={rotationMutation.isPending}
                      className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
                    >
                      {rotationMutation.isPending ? (
                        <Spinner size="h-3.5 w-3.5" />
                      ) : (
                        <RefreshCw className="h-3.5 w-3.5" />
                      )}
                      Request rotation now
                    </button>
                  </div>
                </div>
              </Card>

              <Card>
                <CardHeader>
                  <h3 className="text-sm font-semibold text-ink-50">Update secret</h3>
                </CardHeader>
                <div className="space-y-5 p-4">
                  <AddVersionForm credentialId={credentialId} />
                  <div className="border-t border-surface-800 pt-4">
                    <QuickChangeForm credentialId={credentialId} />
                  </div>
                </div>
              </Card>
            </div>

            <RevealCredentialModal
              open={revealOpen}
              onClose={() => setRevealOpen(false)}
              credentialId={credentialId}
              accountName={cred.account_name}
            />
          </>
        )}
      </QueryState>
    </div>
  )
}
