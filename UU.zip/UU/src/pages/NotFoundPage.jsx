import { Link } from 'react-router-dom'

export default function NotFoundPage() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 text-center">
      <h1 className="text-2xl font-semibold text-ink-50">Page not found</h1>
      <p className="text-sm text-ink-400">The page you&apos;re looking for doesn&apos;t exist.</p>
      <Link to="/" className="mt-2 text-sm text-blue-600 dark:text-blue-400 hover:underline">
        Back to Resources
      </Link>
    </div>
  )
}
