import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate, useParams, Link } from 'react-router-dom'
import { ArrowLeft, KeyRound, RefreshCw, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { getResource } from '../../api/resources'
import { deleteResource, storeResourceCredential, rotateResourceCredential } from '../../api/adminResources'
import { useAuthStore } from '../../store/authStore'
import { CREDENTIAL_TYPES } from '../../config/constants'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Field, inputClass } from '../../components/common/FormFields'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Spinner } from '../../components/common/Spinner'
import { ResourceTypeIcon } from '../../components/resources/ResourceTypeIcon'
import { ConnectPanel } from '../../components/resources/ConnectPanel'
import { apiErrorMessage } from '../../lib/apiError'

// This is the "legacy" single-credential-per-resource path
// (POST /resources/:id/credential, POST /resources/:id/rotate) — distinct
// from the full Safes/Folders/Credentials vault model in api/vault.js.
// Both exist in the merged backend; this page only deals with the simple
// one attached directly to a resource record.
//
// storeCredentialRequest (resource_handler.go) requires account_name and
// credential (both `binding:"required"`), plus optional credential_type.
// This form previously submitted `username` (optional) and `secret` as-is,
// which the backend doesn't recognize at all — every submit 400'd with
// "AccountName ... required, Credential ... required" regardless of what
// was typed in. Username is required here (not optional) to match the
// backend contract, and the payload is remapped to account_name/credential
// before it's sent (see CredentialForm's onSubmit below).
const credentialSchema = z.object({
  credential_type: z.string().min(1, 'Select a type'),
  username: z.string().trim().min(1, 'Required'),
  secret: z.string().trim().min(1, 'Required'),
})

function CredentialForm({ resourceId, hasCredential }) {
  const queryClient = useQueryClient()
  const [mode, setMode] = useState(null) // null | 'store' | 'rotate'
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(credentialSchema) })

  const storeMutation = useMutation({
    // Remap the form's field names to the backend contract: account_name
    // (required) and credential (required), not username/secret.
    mutationFn: (payload) =>
      storeResourceCredential(resourceId, {
        account_name: payload.username,
        credential_type: payload.credential_type,
        credential: payload.secret,
      }),
    onSuccess: () => {
      toast.success('Credential stored')
      queryClient.invalidateQueries({ queryKey: ['resources', resourceId] })
      queryClient.invalidateQueries({ queryKey: ['resources', resourceId, 'connect-info'] })
      reset()
      setMode(null)
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const rotateMutation = useMutation({
    mutationFn: (payload) => rotateResourceCredential(resourceId, payload.secret),
    onSuccess: () => {
      toast.success('Credential rotated')
      queryClient.invalidateQueries({ queryKey: ['resources', resourceId] })
      queryClient.invalidateQueries({ queryKey: ['resources', resourceId, 'connect-info'] })
      reset()
      setMode(null)
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const activeMutation = mode === 'rotate' ? rotateMutation : storeMutation

  if (!mode) {
    return (
      <div className="flex gap-2">
        <button
          onClick={() => setMode('store')}
          className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700"
        >
          <KeyRound className="h-3.5 w-3.5" />
          {hasCredential ? 'Replace credential' : 'Store credential'}
        </button>
        {hasCredential && (
          <button
            onClick={() => setMode('rotate')}
            className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Rotate now
          </button>
        )}
      </div>
    )
  }

  return (
    <form
      onSubmit={handleSubmit((values) => activeMutation.mutate(values))}
      noValidate
      className="space-y-3 rounded-md border border-surface-800 bg-surface-950/40 p-4"
    >
      <p className="text-xs font-medium text-ink-300">
        {mode === 'rotate' ? 'Rotate credential' : 'Store credential'}
      </p>

      {mode === 'store' && (
        <Field label="Type" error={errors.credential_type?.message} required>
          <select className={inputClass(!!errors.credential_type)} {...register('credential_type')}>
            <option value="">Select…</option>
            {CREDENTIAL_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </Field>
      )}

      {mode === 'store' && (
        <Field label="Username" error={errors.username?.message} required>
          <input className={inputClass(!!errors.username)} {...register('username')} />
        </Field>
      )}

      <Field label={mode === 'rotate' ? 'New secret' : 'Secret'} error={errors.secret?.message} required>
        <textarea
          rows={2}
          className={inputClass(!!errors.secret) + ' font-mono'}
          placeholder={mode === 'rotate' ? 'New password / key value' : 'Password / key value'}
          {...register('secret')}
        />
      </Field>

      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={() => {
            reset()
            setMode(null)
          }}
          className="rounded-md px-3 py-1.5 text-xs text-ink-300 hover:bg-surface-800"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={activeMutation.isPending}
          className="flex items-center gap-2 rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
        >
          {activeMutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
          {mode === 'rotate' ? 'Rotate' : 'Store'}
        </button>
      </div>
    </form>
  )
}

export default function ResourceDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false)

  const resourceQuery = useQuery({
    queryKey: ['resources', id],
    queryFn: ({ signal }) => getResource(id, signal),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteResource(id),
    onSuccess: () => {
      toast.success('Resource deleted')
      queryClient.invalidateQueries({ queryKey: ['resources'] })
      navigate('/')
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setConfirmDeleteOpen(false)
    },
  })

  return (
    <div>
      <Link to="/" className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 hover:text-ink-200">
        <ArrowLeft className="h-3.5 w-3.5" /> Back to resources
      </Link>

      <QueryState query={resourceQuery}>
        {(resource) => (
          <>
            <PageHeader
              title={
                <span className="flex items-center gap-2">
                  <ResourceTypeIcon type={resource.resource_type} className="h-5 w-5" />
                  {resource.name}
                </span>
              }
              description={resource.description || `${resource.host}:${resource.port}`}
              actions={
                isAdmin && (
                  <button
                    onClick={() => setConfirmDeleteOpen(true)}
                    className="flex items-center gap-1.5 rounded-md border border-red-300 dark:border-red-900/50 px-3 py-1.5 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30"
                  >
                    <Trash2 className="h-4 w-4" /> Delete
                  </button>
                )
              }
            />

            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <h3 className="text-sm font-semibold text-ink-50">Details</h3>
                </CardHeader>
                <div className="space-y-4 p-4">
                  <dl className="grid grid-cols-[120px_1fr] gap-y-2 text-sm">
                    <dt className="text-ink-500">Type</dt>
                    <dd className="text-ink-100">{resource.resource_type}</dd>
                    <dt className="text-ink-500">Host</dt>
                    <dd className="text-ink-100">{resource.host}</dd>
                    <dt className="text-ink-500">Port</dt>
                    <dd className="text-ink-100">{resource.port}</dd>
                    {resource.database_name && (
                      <>
                        <dt className="text-ink-500">Database</dt>
                        <dd className="text-ink-100">{resource.database_name}</dd>
                      </>
                    )}
                    <dt className="text-ink-500">Access</dt>
                    <dd>
                      {resource.requires_jit ? (
                        <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-300 ring-amber-500/30">JIT-gated</Badge>
                      ) : (
                        <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30">Standing access</Badge>
                      )}
                    </dd>
                    <dt className="text-ink-500">Status</dt>
                    <dd>
                      {resource.is_active ? (
                        <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30">Active</Badge>
                      ) : (
                        <Badge className="bg-ink-500/15 text-ink-400 ring-ink-500/30">Inactive</Badge>
                      )}
                    </dd>
                  </dl>

                  {isAdmin && (
                    <div className="border-t border-surface-800 pt-4">
                      <p className="mb-2 text-xs font-medium text-ink-400">Credential</p>
                      {/* PAMResource has no has_credential field — only vault_entry_id
                          (json:"vault_entry_id,omitempty"), confirmed against resource.go.
                          The old resource.has_credential lookup was always undefined, so the
                          form permanently thought no credential was attached. */}
                      <CredentialForm resourceId={id} hasCredential={!!resource.vault_entry_id} />
                    </div>
                  )}
                </div>
              </Card>

              <Card>
                <CardHeader>
                  <h3 className="text-sm font-semibold text-ink-50">Connect</h3>
                </CardHeader>
                <div className="p-4">
                  <ConnectPanel resourceId={id} />
                </div>
              </Card>
            </div>

            {isAdmin && (
              <ConfirmDialog
                open={confirmDeleteOpen}
                title={`Delete "${resource.name}"?`}
                description="This removes the resource registration. Any stored credential and history remain in the audit trail."
                confirmLabel="Delete"
                destructive
                isLoading={deleteMutation.isPending}
                onConfirm={() => deleteMutation.mutate()}
                onCancel={() => setConfirmDeleteOpen(false)}
              />
            )}
          </>
        )}
      </QueryState>
    </div>
  )
}
