import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight } from 'lucide-react'
import { listResourceGroups } from '../../api/resources'
import { useAuthStore } from '../../store/authStore'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { ResourceTypeIcon } from '../../components/resources/ResourceTypeIcon'
import { CreateResourceModal } from '../../components/resources/CreateResourceModal'
import { Badge } from '../../components/common/Badge'

export default function ResourcesPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  const groupsQuery = useQuery({
    queryKey: ['resources', 'groups'],
    queryFn: ({ signal }) => listResourceGroups(signal),
  })

  return (
    <div>
      <PageHeader
        title="Resources"
        description="Systems PAM can manage or broker access to."
        actions={
          isAdmin && (
            <button
              onClick={() => setCreateOpen(true)}
              className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
            >
              <Plus className="h-4 w-4" /> Register resource
            </button>
          )
        }
      />

      <QueryState
        query={groupsQuery}
        empty={(groups) => !groups || groups.length === 0}
        emptyMessage="No resources registered yet."
      >
        {(groups) => (
          <div className="space-y-6">
            {groups.map((group) => (
              <div key={group.name}>
                <h2 className="mb-2 flex items-center gap-2 text-sm font-medium text-ink-300">
                  <span>{group.icon}</span> {group.name}
                  <span className="text-ink-500">({group.resources?.length || 0})</span>
                </h2>
                <Card>
                  <ul className="divide-y divide-surface-800">
                    {(group.resources || []).map((r) => (
                      <li key={r.id}>
                        <Link
                          to={`/resources/${r.id}`}
                          className="flex items-center justify-between px-4 py-3 hover:bg-surface-850"
                        >
                          <div className="flex items-center gap-3">
                            <ResourceTypeIcon type={r.resource_type} />
                            <div>
                              <p className="text-sm font-medium text-ink-100">{r.name}</p>
                              <p className="text-xs text-ink-500">
                                {r.host}:{r.port}
                                {r.database_name ? ` · ${r.database_name}` : ''}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {r.requires_jit && (
                              <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-300 ring-amber-500/30">
                                JIT-gated
                              </Badge>
                            )}
                            {!r.is_active && (
                              <Badge className="bg-ink-500/15 text-ink-400 ring-ink-500/30">
                                Inactive
                              </Badge>
                            )}
                            <ChevronRight className="h-4 w-4 text-ink-600" />
                          </div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>
            ))}
          </div>
        )}
      </QueryState>

      {isAdmin && <CreateResourceModal open={createOpen} onClose={() => setCreateOpen(false)} />}
    </div>
  )
}
