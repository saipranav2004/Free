import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate, useParams, Link } from 'react-router-dom'
import { ArrowLeft, KeyRound, Trash2, X } from 'lucide-react'
import { toast } from 'sonner'
import {
  getUser,
  setUserStatus,
  deleteUser,
  resetUserPassword,
  assignRole,
  removeRole,
  attachPolicy,
  detachPolicy,
} from '../../api/identity'
import { listPolicies } from '../../api/rbac'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { Field, inputClass } from '../../components/common/FormFields'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Spinner } from '../../components/common/Spinner'
import { apiErrorMessage } from '../../lib/apiError'
import { USER_STATUS_BADGE, ROLE_BADGE, SYSTEM_ROLES } from '../../config/constants'

const STATUS_TRANSITIONS = ['ACTIVE', 'DISABLED', 'LOCKED']

const resetPasswordSchema = z.object({
  new_password: z.string().min(10, 'Must be at least 10 characters'),
})

function ResetPasswordForm({ userId }) {
  const [open, setOpen] = useState(false)
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(resetPasswordSchema) })

  const mutation = useMutation({
    mutationFn: ({ new_password }) => resetUserPassword(userId, new_password),
    onSuccess: () => {
      toast.success('Password reset')
      reset()
      setOpen(false)
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700"
      >
        <KeyRound className="h-3.5 w-3.5" /> Reset password
      </button>
    )
  }

  return (
    <form
      onSubmit={handleSubmit((values) => mutation.mutate(values))}
      noValidate
      className="space-y-3 rounded-md border border-surface-800 bg-surface-950/40 p-4"
    >
      <p className="text-xs font-medium text-ink-300">Reset password</p>
      <Field label="New password" error={errors.new_password?.message} required>
        <input
          type="password"
          className={inputClass(!!errors.new_password)}
          {...register('new_password')}
        />
      </Field>
      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={() => {
            reset()
            setOpen(false)
          }}
          className="rounded-md px-3 py-1.5 text-xs text-ink-300 hover:bg-surface-800"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={mutation.isPending}
          className="flex items-center gap-2 rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
        >
          {mutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
          Reset
        </button>
      </div>
    </form>
  )
}

export default function IdentityDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false)
  const [confirmStatus, setConfirmStatus] = useState(null) // status string or null
  const [newRole, setNewRole] = useState('')
  const [newPolicyId, setNewPolicyId] = useState('')

  const userQuery = useQuery({
    queryKey: ['admin', 'users', id],
    queryFn: ({ signal }) => getUser(id, signal),
  })

  const policiesQuery = useQuery({
    queryKey: ['admin', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'users', id] })

  const statusMutation = useMutation({
    mutationFn: (status) => setUserStatus(id, status),
    onSuccess: () => {
      toast.success('Status updated')
      invalidate()
      setConfirmStatus(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setConfirmStatus(null)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteUser(id),
    onSuccess: () => {
      toast.success('User deleted')
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] })
      navigate('/admin/identity')
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setConfirmDeleteOpen(false)
    },
  })

  const assignRoleMutation = useMutation({
    mutationFn: (roleName) => assignRole(id, roleName),
    onSuccess: () => {
      toast.success('Role assigned')
      invalidate()
      setNewRole('')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const removeRoleMutation = useMutation({
    mutationFn: (roleName) => removeRole(id, roleName),
    onSuccess: () => {
      toast.success('Role removed')
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const attachPolicyMutation = useMutation({
    mutationFn: (policyId) => attachPolicy(id, policyId),
    onSuccess: () => {
      toast.success('Policy attached')
      invalidate()
      setNewPolicyId('')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const detachPolicyMutation = useMutation({
    mutationFn: (policyId) => detachPolicy(id, policyId),
    onSuccess: () => {
      toast.success('Policy detached')
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <div>
      <Link
        to="/admin/identity"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-400 hover:text-ink-200"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to identity
      </Link>

      <QueryState query={userQuery}>
        {(data) => {
          const user = data.user
          // GetEffectiveAccess (identity_service.go) returns `roles` as full
          // Role objects ({id, name, description, is_system, ...}), not
          // plain name strings — rendering one directly as JSX children
          // crashes with "Objects are not valid as a React child". Every
          // downstream use here (badges, remove/assign, the available-roles
          // filter) wants the plain name, matching what assignRole/removeRole
          // send over the wire, so map to `.name` once up front. Likewise the
          // policies field is named `direct_policies`, not `policies` — a
          // plain `data.access?.policies` silently reads as undefined and
          // renders an empty list rather than crashing, which is why this
          // one was easy to miss without live-testing against a real user.
          const roles = (data.access?.roles || []).map((r) => r.name)
          const policies = data.access?.direct_policies || []
          const availableRoles = SYSTEM_ROLES.filter((r) => !roles.includes(r))
          const attachedPolicyIds = new Set(policies.map((p) => p.id))
          const availablePolicies = (policiesQuery.data || []).filter(
            (p) => !attachedPolicyIds.has(p.id)
          )

          return (
            <>
              <PageHeader
                title={user.username}
                description={user.email}
                actions={
                  <button
                    onClick={() => setConfirmDeleteOpen(true)}
                    className="flex items-center gap-1.5 rounded-md border border-red-300 dark:border-red-900/50 px-3 py-1.5 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30"
                  >
                    <Trash2 className="h-4 w-4" /> Delete user
                  </button>
                }
              />

              <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <h3 className="text-sm font-semibold text-ink-50">Profile</h3>
                  </CardHeader>
                  <div className="space-y-4 p-4">
                    <dl className="grid grid-cols-[120px_1fr] gap-y-2 text-sm">
                      <dt className="text-ink-500">Username</dt>
                      <dd className="text-ink-100">{user.username}</dd>
                      <dt className="text-ink-500">Email</dt>
                      <dd className="text-ink-100">{user.email}</dd>
                      <dt className="text-ink-500">Full name</dt>
                      <dd className="text-ink-100">{user.full_name || '—'}</dd>
                      <dt className="text-ink-500">Status</dt>
                      <dd>
                        <Badge className={USER_STATUS_BADGE[user.status] || undefined}>
                          {user.status || 'UNKNOWN'}
                        </Badge>
                      </dd>
                    </dl>

                    <div className="border-t border-surface-800 pt-4">
                      <p className="mb-2 text-xs font-medium text-ink-400">Change status</p>
                      <div className="flex flex-wrap gap-2">
                        {STATUS_TRANSITIONS.filter((s) => s !== user.status).map((s) => (
                          <button
                            key={s}
                            onClick={() => setConfirmStatus(s)}
                            className="rounded-md bg-surface-800 px-2.5 py-1 text-xs font-medium text-ink-100 hover:bg-surface-700"
                          >
                            Set {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="border-t border-surface-800 pt-4">
                      <p className="mb-2 text-xs font-medium text-ink-400">Password</p>
                      <ResetPasswordForm userId={id} />
                    </div>
                  </div>
                </Card>

                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <h3 className="text-sm font-semibold text-ink-50">Roles</h3>
                    </CardHeader>
                    <div className="space-y-3 p-4">
                      <div className="flex flex-wrap gap-2">
                        {roles.length === 0 && <p className="text-xs text-ink-500">No roles assigned.</p>}
                        {roles.map((r) => (
                          <span key={r} className="inline-flex items-center gap-1">
                            <Badge className={ROLE_BADGE[r] || undefined}>{r}</Badge>
                            <button
                              onClick={() => removeRoleMutation.mutate(r)}
                              disabled={removeRoleMutation.isPending}
                              className="text-ink-500 hover:text-red-600 dark:hover:text-red-400 disabled:opacity-40"
                              aria-label={`Remove ${r} role`}
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                      {availableRoles.length > 0 && (
                        <div className="flex items-center gap-2 border-t border-surface-800 pt-3">
                          <select
                            className={inputClass(false) + ' max-w-[10rem]'}
                            value={newRole}
                            onChange={(e) => setNewRole(e.target.value)}
                          >
                            <option value="">Add role…</option>
                            {availableRoles.map((r) => (
                              <option key={r} value={r}>
                                {r}
                              </option>
                            ))}
                          </select>
                          <button
                            onClick={() => newRole && assignRoleMutation.mutate(newRole)}
                            disabled={!newRole || assignRoleMutation.isPending}
                            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
                          >
                            {assignRoleMutation.isPending && (
                              <Spinner size="h-3.5 w-3.5" className="text-white" />
                            )}
                            Add
                          </button>
                        </div>
                      )}
                    </div>
                  </Card>

                  <Card>
                    <CardHeader>
                      <h3 className="text-sm font-semibold text-ink-50">Policies</h3>
                    </CardHeader>
                    <div className="space-y-3 p-4">
                      <ul className="space-y-2">
                        {policies.length === 0 && (
                          <p className="text-xs text-ink-500">No policies directly attached.</p>
                        )}
                        {policies.map((p) => (
                          <li
                            key={p.id}
                            className="flex items-center justify-between rounded-md border border-surface-800 px-3 py-2"
                          >
                            <span className="text-sm text-ink-100">{p.name}</span>
                            <button
                              onClick={() => detachPolicyMutation.mutate(p.id)}
                              disabled={detachPolicyMutation.isPending}
                              className="text-xs text-ink-500 hover:text-red-600 dark:hover:text-red-400 disabled:opacity-40"
                            >
                              Detach
                            </button>
                          </li>
                        ))}
                      </ul>
                      {availablePolicies.length > 0 && (
                        <div className="flex items-center gap-2 border-t border-surface-800 pt-3">
                          <select
                            className={inputClass(false) + ' max-w-[12rem]'}
                            value={newPolicyId}
                            onChange={(e) => setNewPolicyId(e.target.value)}
                          >
                            <option value="">Attach policy…</option>
                            {availablePolicies.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name}
                              </option>
                            ))}
                          </select>
                          <button
                            onClick={() => newPolicyId && attachPolicyMutation.mutate(newPolicyId)}
                            disabled={!newPolicyId || attachPolicyMutation.isPending}
                            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
                          >
                            {attachPolicyMutation.isPending && (
                              <Spinner size="h-3.5 w-3.5" className="text-white" />
                            )}
                            Attach
                          </button>
                        </div>
                      )}
                    </div>
                  </Card>
                </div>
              </div>

              <ConfirmDialog
                open={!!confirmStatus}
                title={`Set status to ${confirmStatus}?`}
                description="This changes the user's ability to sign in immediately."
                confirmLabel="Confirm"
                destructive={confirmStatus === 'DISABLED' || confirmStatus === 'LOCKED'}
                isLoading={statusMutation.isPending}
                onConfirm={() => statusMutation.mutate(confirmStatus)}
                onCancel={() => setConfirmStatus(null)}
              />

              <ConfirmDialog
                open={confirmDeleteOpen}
                title={`Delete "${user.username}"?`}
                description="This permanently removes the user account."
                confirmLabel="Delete"
                destructive
                requireReason
                reasonLabel="Reason for deletion"
                isLoading={deleteMutation.isPending}
                onConfirm={() => deleteMutation.mutate()}
                onCancel={() => setConfirmDeleteOpen(false)}
              />
            </>
          )
        }}
      </QueryState>
    </div>
  )
}
