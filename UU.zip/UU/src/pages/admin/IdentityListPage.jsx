import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Plus, ChevronRight } from 'lucide-react'
import { listUsers } from '../../api/identity'
import { PageHeader, Card } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { inputClass } from '../../components/common/FormFields'
import { CreateUserModal } from '../../components/admin/CreateUserModal'
import { USER_STATUS_BADGE, SEARCH_DEBOUNCE_MS } from '../../config/constants'

export default function IdentityListPage() {
  const [createOpen, setCreateOpen] = useState(false)
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')

  // Debounce the free-text search so it doesn't fire a request per keystroke —
  // the input updates immediately for responsiveness, the query key only
  // picks up `search` after SEARCH_DEBOUNCE_MS of no further typing.
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', search],
    queryFn: ({ signal }) => listUsers(search || undefined, signal),
  })

  return (
    <div>
      <PageHeader
        title="Identity"
        description="User accounts in this PAM install — create, disable, lock, or delete, and manage RBAC role/policy assignment."
        actions={
          <button
            onClick={() => setCreateOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
          >
            <Plus className="h-4 w-4" /> Create user
          </button>
        }
      />

      <Card className="mb-4">
        <div className="px-4 py-3">
          <input
            className={inputClass(false) + ' max-w-xs'}
            placeholder="Search username or email…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
        </div>
      </Card>

      <QueryState
        query={usersQuery}
        empty={(data) => !data?.users || data.users.length === 0}
        emptyMessage="No users found."
      >
        {(data) => (
          <Card>
            <ul className="divide-y divide-surface-800">
              {data.users.map((u) => (
                <li key={u.user_id}>
                  <Link
                    to={`/admin/identity/${u.user_id}`}
                    className="flex items-center justify-between px-4 py-3 hover:bg-surface-850"
                  >
                    <div>
                      <p className="text-sm font-medium text-ink-100">{u.username}</p>
                      <p className="text-xs text-ink-500">
                        {u.email}
                        {u.full_name ? ` · ${u.full_name}` : ''}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={USER_STATUS_BADGE[u.status] || undefined}>
                        {u.status || 'UNKNOWN'}
                      </Badge>
                      <ChevronRight className="h-4 w-4 text-ink-600" />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreateUserModal open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  )
}
