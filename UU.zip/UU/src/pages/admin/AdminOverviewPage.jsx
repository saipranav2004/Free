import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { toast } from 'sonner'
import {
  KeyRound, ShieldAlert, ShieldCheck, ScrollText, ArrowRight, Activity,
} from 'lucide-react'
import { listJitRequests, listBreakglass, listAudit, verifyAudit, approveJitRequest, denyJitRequest } from '../../api/admin'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { StatCard } from '../../components/common/StatCard'
import { Badge } from '../../components/common/Badge'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Spinner } from '../../components/common/Spinner'
import { formatDateTime } from '../../lib/format'
import { apiErrorMessage } from '../../lib/apiError'
import {
  JIT_STATUS_BADGE, JIT_STATUS_LABELS,
  AUDIT_OUTCOME_BADGE, AUDIT_SEVERITY_BADGE,
} from '../../config/constants'

// Requester/resource field names on the admin JIT list aren't pinned down
// either — same defensive-lookup approach as AuditPage's actorLabel/targetLabel.
function requesterLabel(r) {
  return (
    r?.requester_username ||
    r?.username ||
    r?.requested_by ||
    r?.user_username ||
    r?.requester?.username ||
    r?.user_id ||
    '—'
  )
}

function PendingRequestRow({ request, onApprove, onDeny, isMutating }) {
  return (
    <li className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <p className="truncate text-sm font-medium text-ink-100">
          {request?.resource_name || request?.resource_id || '—'}
          <span className="ml-2 text-xs font-normal text-ink-500">by {requesterLabel(request)}</span>
        </p>
        <p className="mt-0.5 truncate text-xs text-ink-500">
          Requested {formatDateTime(request?.created_at)}
          {request?.reason ? ` · ${request.reason}` : ''}
        </p>
      </div>
      <div className="flex flex-none items-center gap-2">
        <Badge className={JIT_STATUS_BADGE[request?.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
          {JIT_STATUS_LABELS[request?.status] || request?.status || '—'}
        </Badge>
        <button
          onClick={() => onApprove(request)}
          disabled={isMutating}
          className="rounded-md bg-blue-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
        >
          Approve
        </button>
        <button
          onClick={() => onDeny(request)}
          disabled={isMutating}
          className="rounded-md border border-red-300 dark:border-red-900/50 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-60"
        >
          Deny
        </button>
      </div>
    </li>
  )
}

function VerifyChainBanner({ result, isPending }) {
  if (isPending) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-surface-800 bg-surface-950/40 p-4 text-sm text-ink-400">
        <Spinner size="h-4 w-4" /> Verifying audit chain…
      </div>
    )
  }
  if (!result) return null

  const knownField =
    'valid' in result ? 'valid'
    : 'chain_valid' in result ? 'chain_valid'
    : 'intact' in result ? 'intact'
    : 'success' in result ? 'success'
    : null
  const isValid = knownField ? Boolean(result[knownField]) : null

  return (
    <div
      className={
        'flex items-start gap-3 rounded-lg border p-4 ' +
        (isValid === false
          ? 'border-red-400 dark:border-red-600/60 bg-red-50 dark:bg-red-950/40'
          : isValid === true
            ? 'border-emerald-300 dark:border-emerald-600/40 bg-emerald-50 dark:bg-emerald-950/20'
            : 'border-surface-800 bg-surface-900')
      }
    >
      {isValid === false && <ShieldAlert className="mt-0.5 h-5 w-5 flex-none text-red-600 dark:text-red-400" />}
      {isValid === true && <ShieldCheck className="mt-0.5 h-5 w-5 flex-none text-emerald-600 dark:text-emerald-400" />}
      <div className="min-w-0">
        {isValid === true && (
          <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">Audit chain intact — no tampering detected.</p>
        )}
        {isValid === false && (
          <p className="text-sm font-semibold text-red-700 dark:text-red-300">
            Audit chain broken — investigate immediately. Notify a security administrator.
          </p>
        )}
        {isValid === null && (
          <>
            <p className="mb-1 text-sm font-medium text-ink-100">Verification result</p>
            <pre className="max-w-full overflow-x-auto text-xs text-ink-400">{JSON.stringify(result, null, 2)}</pre>
          </>
        )}
      </div>
    </div>
  )
}

export default function AdminOverviewPage() {
  const queryClient = useQueryClient()
  const [approveTarget, setApproveTarget] = useState(null)
  const [denyTarget, setDenyTarget] = useState(null)

  const pendingCountQuery = useQuery({
    queryKey: ['admin', 'jit-requests', 'pending-count'],
    queryFn: ({ signal }) => listJitRequests({ page: 1, page_size: 1, status: 'PENDING' }, signal),
  })

  const breakglassCountQuery = useQuery({
    queryKey: ['admin', 'breakglass', 'count'],
    queryFn: ({ signal }) => listBreakglass({ page: 1, page_size: 1 }, signal),
  })

  const pendingListQuery = useQuery({
    queryKey: ['admin', 'jit-requests', 'pending-list'],
    queryFn: ({ signal }) => listJitRequests({ page: 1, page_size: 5, status: 'PENDING' }, signal),
  })

  const deniedAuditQuery = useQuery({
    queryKey: ['admin', 'audit', 'denied-feed'],
    queryFn: ({ signal }) => listAudit({ page: 1, page_size: 5, outcome: 'DENIED' }, signal),
  })

  const verifyMutation = useMutation({
    mutationFn: () => verifyAudit(),
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const invalidatePending = () => {
    queryClient.invalidateQueries({ queryKey: ['admin', 'jit-requests'] })
  }

  const approveMutation = useMutation({
    mutationFn: ({ id, reason }) => approveJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request approved')
      setApproveTarget(null)
      invalidatePending()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setApproveTarget(null)
    },
  })

  const denyMutation = useMutation({
    mutationFn: ({ id, reason }) => denyJitRequest(id, reason),
    onSuccess: () => {
      toast.success('Request denied')
      setDenyTarget(null)
      invalidatePending()
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDenyTarget(null)
    },
  })

  const pendingApprovalsTotal = pendingCountQuery.data?.pagination?.total ?? 0

  // listBreakglass returns { requests, pagination, grants } — "active
  // break-glass" most plausibly means live break-glass grants, so prefer
  // counting the `grants` array (filtered to ACTIVE where a status field
  // exists) and fall back to the request pagination total if `grants`
  // isn't present in this deployment's response.
  const bgData = breakglassCountQuery.data
  const activeBreakglassCount = Array.isArray(bgData?.grants)
    ? bgData.grants.filter((g) => !g?.status || g.status === 'ACTIVE').length
    : (bgData?.pagination?.total ?? 0)

  const isMutatingJit = approveMutation.isPending || denyMutation.isPending

  return (
    <div>
      <PageHeader
        title="Needs attention"
        description="What's waiting on you right now — pending approvals, break-glass activity, and audit chain integrity. For overall org stats, see the main Dashboard."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Link to="/admin/jit">
          <StatCard
            label="Pending approvals"
            icon={KeyRound}
            tone="amber"
            loading={pendingCountQuery.isLoading}
            value={pendingApprovalsTotal}
            hint="JIT requests awaiting a decision"
          />
        </Link>
        <Link to="/admin/jit">
          <StatCard
            label="Active break-glass"
            icon={ShieldAlert}
            tone="red"
            loading={breakglassCountQuery.isLoading}
            value={activeBreakglassCount}
            hint="Emergency access in use"
          />
        </Link>
        <StatCard
          label="Chain status"
          icon={ShieldCheck}
          tone={verifyMutation.data ? (chainToneFor(verifyMutation.data) ?? 'default') : 'default'}
          loading={verifyMutation.isPending}
          value={verifyMutation.data ? chainLabelFor(verifyMutation.data) : 'Not checked'}
          hint="Run the check below"
        />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex items-center justify-between">
            <h2 className="flex items-center gap-1.5 text-sm font-semibold text-ink-50">
              <KeyRound className="h-4 w-4" /> Pending JIT approvals
            </h2>
            <Link to="/admin/jit" className="flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300">
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <QueryState
            query={pendingListQuery}
            empty={(d) => !d?.requests || d.requests.length === 0}
            emptyMessage="No pending requests."
          >
            {(data) => (
              <ul className="divide-y divide-surface-800">
                {data.requests.map((r) => (
                  <PendingRequestRow
                    key={r.id}
                    request={r}
                    isMutating={isMutatingJit}
                    onApprove={setApproveTarget}
                    onDeny={setDenyTarget}
                  />
                ))}
              </ul>
            )}
          </QueryState>
        </Card>

        <Card>
          <CardHeader className="flex items-center justify-between">
            <h2 className="flex items-center gap-1.5 text-sm font-semibold text-ink-50">
              <ScrollText className="h-4 w-4" /> Recently denied activity
            </h2>
            <Link to="/admin/audit" className="flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300">
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <QueryState
            query={deniedAuditQuery}
            empty={(d) => !d?.events || d.events.length === 0}
            emptyMessage="No denied events recently."
          >
            {(data) => (
              <ul className="divide-y divide-surface-800">
                {data.events.map((e, idx) => (
                  <li key={e?.id ?? idx} className="px-4 py-3">
                    <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink-100">
                      <span className="text-ink-400">{e?.category || 'OTHER'}</span>
                      <span>{e?.action || '—'}</span>
                      {e?.outcome && (
                        <Badge className={AUDIT_OUTCOME_BADGE[e.outcome] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                          {e.outcome}
                        </Badge>
                      )}
                      {e?.severity && (
                        <Badge className={AUDIT_SEVERITY_BADGE[e.severity] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                          {e.severity}
                        </Badge>
                      )}
                    </p>
                    <p className="mt-1 truncate text-xs text-ink-500">
                      {formatDateTime(e?.occurred_at || e?.created_at)}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="flex items-center gap-1.5 text-sm font-medium text-ink-100">
            <Activity className="h-4 w-4" /> Audit chain integrity
          </h2>
          <button
            onClick={() => verifyMutation.mutate()}
            disabled={verifyMutation.isPending}
            className="flex items-center gap-1.5 rounded-md bg-surface-800 px-3 py-1.5 text-xs font-medium text-ink-100 hover:bg-surface-700 disabled:opacity-60"
          >
            {verifyMutation.isPending ? <Spinner size="h-3.5 w-3.5" /> : <ShieldCheck className="h-3.5 w-3.5" />}
            Verify audit chain
          </button>
        </CardHeader>
        <div className="p-4">
          {verifyMutation.isSuccess || verifyMutation.isPending ? (
            <VerifyChainBanner result={verifyMutation.data} isPending={verifyMutation.isPending} />
          ) : (
            <p className="text-xs text-ink-500">
              Checks that org-wide audit entries form an unbroken, tamper-evident chain. Not run automatically —
              trigger it explicitly.
            </p>
          )}
        </div>
      </Card>

      <ConfirmDialog
        open={!!approveTarget}
        title={`Approve request for "${approveTarget?.resource_name || approveTarget?.resource_id || 'this resource'}"?`}
        description="This grants time-boxed access immediately."
        confirmLabel="Approve"
        destructive={false}
        reasonLabel="Reason (optional)"
        isLoading={approveMutation.isPending}
        onConfirm={(reason) => approveMutation.mutate({ id: approveTarget.id, reason })}
        onCancel={() => setApproveTarget(null)}
      />

      <ConfirmDialog
        open={!!denyTarget}
        title={`Deny request for "${denyTarget?.resource_name || denyTarget?.resource_id || 'this resource'}"?`}
        description="This rejects the request. The requester will need to submit a new one if access is still needed."
        confirmLabel="Deny"
        destructive
        requireReason
        reasonLabel="Reason for denial (required for the audit record)"
        isLoading={denyMutation.isPending}
        onConfirm={(reason) => denyMutation.mutate({ id: denyTarget.id, reason })}
        onCancel={() => setDenyTarget(null)}
      />
    </div>
  )
}

// Same defensive field-name probing as VerifyChainBanner, reused for the
// StatCard tile so the tone/label agree with the banner underneath it.
function chainKnownField(result) {
  if (!result) return null
  if ('valid' in result) return 'valid'
  if ('chain_valid' in result) return 'chain_valid'
  if ('intact' in result) return 'intact'
  if ('success' in result) return 'success'
  return null
}
function chainToneFor(result) {
  const field = chainKnownField(result)
  if (!field) return 'default'
  return result[field] ? 'emerald' : 'red'
}
function chainLabelFor(result) {
  const field = chainKnownField(result)
  if (!field) return 'Checked'
  return result[field] ? 'Intact' : 'Broken'
}
