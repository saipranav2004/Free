import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Plus, ChevronDown, ChevronRight, Trash2 } from 'lucide-react'
import {
  listRoles,
  getRole,
  attachPolicyToRole,
  detachPolicyFromRole,
  deleteRole,
  listPolicies,
} from '../../api/rbac'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { Spinner } from '../../components/common/Spinner'
import { inputClass } from '../../components/common/FormFields'
import { CreateRoleModal } from '../../components/admin/CreateRoleModal'
import { apiErrorMessage } from '../../lib/apiError'

function RoleRow({ role, isExpanded, onToggle, onDelete }) {
  const queryClient = useQueryClient()
  const [newPolicyId, setNewPolicyId] = useState('')

  const roleQuery = useQuery({
    queryKey: ['admin', 'roles', role.id],
    queryFn: ({ signal }) => getRole(role.id, signal),
    enabled: isExpanded,
  })

  const policiesQuery = useQuery({
    queryKey: ['admin', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
    enabled: isExpanded,
  })

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'roles', role.id] })

  const attachMutation = useMutation({
    mutationFn: (policyId) => attachPolicyToRole(role.id, policyId),
    onSuccess: () => {
      toast.success('Policy attached')
      invalidate()
      setNewPolicyId('')
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  const detachMutation = useMutation({
    mutationFn: (policyId) => detachPolicyFromRole(role.id, policyId),
    onSuccess: () => {
      toast.success('Policy detached')
      invalidate()
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  })

  return (
    <li>
      <button
        onClick={onToggle}
        className="flex w-full items-center justify-between px-4 py-3 text-left hover:bg-surface-850"
      >
        <div>
          <p className="text-sm font-medium text-ink-100">{role.name}</p>
          {role.description && <p className="text-xs text-ink-500">{role.description}</p>}
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={(e) => {
              e.stopPropagation()
              onDelete(role)
            }}
            className="rounded-md p-1 text-ink-500 hover:bg-red-50 dark:hover:bg-red-950/30 hover:text-red-600 dark:hover:text-red-300"
            aria-label={`Delete ${role.name}`}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
          {isExpanded ? (
            <ChevronDown className="h-4 w-4 text-ink-600" />
          ) : (
            <ChevronRight className="h-4 w-4 text-ink-600" />
          )}
        </div>
      </button>

      {isExpanded && (
        <div className="border-t border-surface-800 bg-surface-950/40 px-4 py-3">
          <QueryState query={roleQuery} loadingLabel="Loading policies…">
            {(data) => {
              const policies = data.policies || []
              const attachedIds = new Set(policies.map((p) => p.id))
              const available = (policiesQuery.data || []).filter((p) => !attachedIds.has(p.id))

              return (
                <div className="space-y-3">
                  <ul className="space-y-2">
                    {policies.length === 0 && (
                      <p className="text-xs text-ink-500">No policies attached to this role.</p>
                    )}
                    {policies.map((p) => (
                      <li
                        key={p.id}
                        className="flex items-center justify-between rounded-md border border-surface-800 bg-surface-900 px-3 py-2"
                      >
                        <span className="text-sm text-ink-100">{p.name}</span>
                        <button
                          onClick={() => detachMutation.mutate(p.id)}
                          disabled={detachMutation.isPending}
                          className="text-xs text-ink-500 hover:text-red-600 dark:hover:text-red-400 disabled:opacity-40"
                        >
                          Detach
                        </button>
                      </li>
                    ))}
                  </ul>
                  {available.length > 0 && (
                    <div className="flex items-center gap-2">
                      <select
                        className={inputClass(false) + ' max-w-[12rem]'}
                        value={newPolicyId}
                        onChange={(e) => setNewPolicyId(e.target.value)}
                      >
                        <option value="">Attach policy…</option>
                        {available.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() => newPolicyId && attachMutation.mutate(newPolicyId)}
                        disabled={!newPolicyId || attachMutation.isPending}
                        className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-60"
                      >
                        {attachMutation.isPending && <Spinner size="h-3.5 w-3.5" className="text-white" />}
                        Attach
                      </button>
                    </div>
                  )}
                </div>
              )
            }}
          </QueryState>
        </div>
      )}
    </li>
  )
}

export default function RolesPage() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [expandedId, setExpandedId] = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)

  const rolesQuery = useQuery({
    queryKey: ['admin', 'roles'],
    queryFn: ({ signal }) => listRoles(signal),
  })

  const deleteMutation = useMutation({
    mutationFn: (roleId) => deleteRole(roleId),
    onSuccess: () => {
      toast.success('Role deleted')
      queryClient.invalidateQueries({ queryKey: ['admin', 'roles'] })
      setDeleteTarget(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDeleteTarget(null)
    },
  })

  return (
    <div>
      <PageHeader
        title="Roles"
        description="RBAC roles — bundles of policies that can be assigned to a user."
        actions={
          <button
            onClick={() => setCreateOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
          >
            <Plus className="h-4 w-4" /> Create role
          </button>
        }
      />

      <QueryState
        query={rolesQuery}
        empty={(roles) => !roles || roles.length === 0}
        emptyMessage="No roles defined yet."
      >
        {(roles) => (
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold text-ink-50">All roles</h3>
            </CardHeader>
            <ul className="divide-y divide-surface-800">
              {roles.map((role) => (
                <RoleRow
                  key={role.id}
                  role={role}
                  isExpanded={expandedId === role.id}
                  onToggle={() => setExpandedId(expandedId === role.id ? null : role.id)}
                  onDelete={setDeleteTarget}
                />
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreateRoleModal open={createOpen} onClose={() => setCreateOpen(false)} />

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete "${deleteTarget?.name}"?`}
        description="This removes the role. Users who had it assigned lose the policies it granted."
        confirmLabel="Delete"
        destructive
        isLoading={deleteMutation.isPending}
        onConfirm={() => deleteMutation.mutate(deleteTarget.id)}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  )
}
