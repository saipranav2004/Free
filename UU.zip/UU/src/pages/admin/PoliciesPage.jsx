import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Plus, Trash2 } from 'lucide-react'
import { listPolicies, deletePolicy } from '../../api/rbac'
import { PageHeader, Card, CardHeader } from '../../components/common/Layout'
import { QueryState } from '../../components/common/QueryState'
import { Badge } from '../../components/common/Badge'
import { ConfirmDialog } from '../../components/common/ConfirmDialog'
import { CreatePolicyModal } from '../../components/admin/CreatePolicyModal'
import { POLICY_EFFECT_BADGE } from '../../config/constants'
import { apiErrorMessage } from '../../lib/apiError'

// Compact, truncated "actions, resources" summary for a policy row — the
// exact shape of these arrays isn't guaranteed everywhere, so guard for
// missing/non-array values rather than assuming every policy carries them.
function summarizeList(values, max = 3) {
  if (!Array.isArray(values) || values.length === 0) return '—'
  const shown = values.slice(0, max).join(', ')
  return values.length > max ? `${shown}, +${values.length - max} more` : shown
}

export default function PoliciesPage() {
  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)

  const policiesQuery = useQuery({
    queryKey: ['admin', 'policies'],
    queryFn: ({ signal }) => listPolicies(signal),
  })

  const deleteMutation = useMutation({
    mutationFn: (policyId) => deletePolicy(policyId),
    onSuccess: () => {
      toast.success('Policy deleted')
      queryClient.invalidateQueries({ queryKey: ['admin', 'policies'] })
      setDeleteTarget(null)
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err))
      setDeleteTarget(null)
    },
  })

  return (
    <div>
      <PageHeader
        title="Policies"
        description="PBAC policies — allow/deny rules over actions and resources, attachable to roles or directly to users."
        actions={
          <button
            onClick={() => setCreateOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
          >
            <Plus className="h-4 w-4" /> Create policy
          </button>
        }
      />

      <QueryState
        query={policiesQuery}
        empty={(policies) => !policies || policies.length === 0}
        emptyMessage="No policies defined yet."
      >
        {(policies) => (
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold text-ink-50">All policies</h3>
            </CardHeader>
            <ul className="divide-y divide-surface-800">
              {policies.map((policy) => (
                <li key={policy.id} className="flex items-center justify-between px-4 py-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="truncate text-sm font-medium text-ink-100">{policy.name}</p>
                      <Badge className={POLICY_EFFECT_BADGE[policy.effect] || undefined}>
                        {policy.effect || 'unknown'}
                      </Badge>
                    </div>
                    <p className="truncate text-xs text-ink-500">
                      actions: {summarizeList(policy.actions)} · resources: {summarizeList(policy.resources)}
                    </p>
                  </div>
                  <button
                    onClick={() => setDeleteTarget(policy)}
                    className="ml-3 flex flex-none items-center gap-1.5 rounded-md p-1.5 text-ink-500 hover:bg-red-50 dark:hover:bg-red-950/30 hover:text-red-600 dark:hover:text-red-300"
                    aria-label={`Delete ${policy.name}`}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </QueryState>

      <CreatePolicyModal open={createOpen} onClose={() => setCreateOpen(false)} />

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete "${deleteTarget?.name}"?`}
        description="This removes the policy. Any role or user it was attached to loses the access it granted."
        confirmLabel="Delete"
        destructive
        isLoading={deleteMutation.isPending}
        onConfirm={() => deleteMutation.mutate(deleteTarget.id)}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  )
}
