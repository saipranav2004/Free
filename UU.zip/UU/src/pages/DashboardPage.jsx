import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  Boxes, Vault, Radio, KeyRound, ScrollText, ShieldAlert, ArrowRight,
  Users, ClipboardList, Lock, Activity,
} from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { getStats } from '../api/admin'
import { listMyGrants, listMyJitRequests } from '../api/jit'
import { listMySessions } from '../api/sessions'
import { PageHeader, Card } from '../components/common/Layout'
import { StatCard } from '../components/common/StatCard'
import { Badge } from '../components/common/Badge'
import { formatDateTime } from '../lib/format'
import { JIT_STATUS_BADGE, JIT_STATUS_LABELS } from '../config/constants'

// GET /admin/stats (AdminHandler.Stats, admin_handler.go) returns exactly
// five fields — pending_approvals, active_sessions, active_grants,
// active_breakglass_grants, active_resources, plus generated_at — verified
// against the actual handler source, not guessed. An earlier version of
// this file guessed at several OTHER field names (total_users,
// pending_jit_requests, total_resources, audit_events_24h,
// total_credentials) that the backend has never returned, so those tiles
// always rendered "—" regardless of real data. Two of those (pending JIT
// count, resource count) mapped onto real fields under a different name
// and are fixed below. The other three (user count, 24h audit volume,
// vault credential count) have no backing query anywhere in the backend
// at all — Stats() has no access to IdentityService/VaultService/audit
// counts to compute them — so rather than ship tiles that can never show
// real data, they've been removed. Re-add them once AdminHandler.Stats is
// extended to actually compute those three counts.
function pick(obj, ...keys) {
  if (!obj) return undefined
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null) return obj[k]
  }
  return undefined
}

const QUICK_LINKS = [
  { to: '/resources', label: 'Resources', icon: Boxes, description: 'Browse systems you can connect to' },
  { to: '/vault', label: 'Vault', icon: Vault, description: 'Safes, folders & credentials' },
  { to: '/sessions', label: 'Sessions', icon: Radio, description: 'Your connection history' },
  { to: '/jit', label: 'JIT Access', icon: KeyRound, description: 'Request or view time-boxed access' },
  { to: '/audit', label: 'Audit', icon: ScrollText, description: 'Search your activity trail' },
]

function AdminDashboard() {
  const statsQuery = useQuery({ queryKey: ['admin', 'stats'], queryFn: ({ signal }) => getStats(signal) })
  const s = statsQuery.data

  return (
    <div>
      <PageHeader
        title="Admin overview"
        description="Organization-wide snapshot across identity, access, and audit."
      />

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard
          label="Active sessions"
          icon={Activity}
          tone="emerald"
          loading={statsQuery.isLoading}
          value={pick(s, 'active_sessions') ?? '—'}
        />
        <StatCard
          label="Pending JIT requests"
          icon={KeyRound}
          tone="amber"
          loading={statsQuery.isLoading}
          value={pick(s, 'pending_approvals') ?? '—'}
        />
        <StatCard
          label="Active grants"
          icon={Lock}
          tone="emerald"
          loading={statsQuery.isLoading}
          value={pick(s, 'active_grants') ?? '—'}
        />
        <StatCard
          label="Resources"
          icon={Boxes}
          loading={statsQuery.isLoading}
          value={pick(s, 'active_resources') ?? '—'}
        />
        <StatCard
          label="Break-glass (active)"
          icon={ShieldAlert}
          tone="red"
          loading={statsQuery.isLoading}
          value={pick(s, 'active_breakglass_grants') ?? '—'}
        />
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { to: '/admin/identity', label: 'Identity', icon: Users },
          { to: '/admin/jit', label: 'JIT Approvals', icon: KeyRound },
          { to: '/admin/audit', label: 'Audit & Compliance', icon: ClipboardList },
          { to: '/admin/vault-ops', label: 'Vault Operations', icon: Vault },
        ].map((l) => (
          <Link key={l.to} to={l.to}>
            <Card className="flex items-center justify-between p-4 transition-colors hover:border-blue-500/40">
              <span className="flex items-center gap-2 text-sm font-medium text-ink-100">
                <l.icon className="h-4 w-4 text-ink-400" /> {l.label}
              </span>
              <ArrowRight className="h-4 w-4 text-ink-600" />
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

function UserDashboard({ user }) {
  const grantsQuery = useQuery({
    queryKey: ['jit', 'grants', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMyGrants({ activeOnly: true, pageSize: 5, signal }),
  })
  const requestsQuery = useQuery({
    queryKey: ['jit', 'requests', 'mine', { status: 'PENDING', dashboard: true }],
    queryFn: ({ signal }) => listMyJitRequests({ status: 'PENDING', pageSize: 5, signal }),
  })
  const sessionsQuery = useQuery({
    queryKey: ['sessions', 'mine', { activeOnly: true, dashboard: true }],
    queryFn: ({ signal }) => listMySessions({ activeOnly: true, pageSize: 5, signal }),
  })

  return (
    <div>
      <PageHeader
        title={`Welcome${user?.username ? `, ${user.username}` : ''}`}
        description="Your access at a glance."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Active grants"
          icon={Lock}
          tone="emerald"
          loading={grantsQuery.isLoading}
          value={grantsQuery.data?.pagination?.total ?? grantsQuery.data?.grants?.length ?? 0}
        />
        <StatCard
          label="Pending requests"
          icon={KeyRound}
          tone="amber"
          loading={requestsQuery.isLoading}
          value={requestsQuery.data?.pagination?.total ?? requestsQuery.data?.requests?.length ?? 0}
        />
        <StatCard
          label="Active sessions"
          icon={Activity}
          loading={sessionsQuery.isLoading}
          value={sessionsQuery.data?.pagination?.total ?? sessionsQuery.data?.sessions?.length ?? 0}
        />
      </div>

      {!requestsQuery.isLoading && (requestsQuery.data?.requests?.length ?? 0) > 0 && (
        <div className="mt-8">
          <h2 className="mb-2 text-sm font-medium text-ink-300">Your pending requests</h2>
          <Card>
            <ul className="divide-y divide-surface-800">
              {requestsQuery.data.requests.map((r) => (
                <li key={r.id}>
                  <Link to={`/jit/requests/${r.id}`} className="flex items-center justify-between px-4 py-3 hover:bg-surface-850">
                    <div>
                      <p className="text-sm font-medium text-ink-100">{r.resource_name || r.resource_id}</p>
                      <p className="text-xs text-ink-500">Requested {formatDateTime(r.created_at)}</p>
                    </div>
                    <Badge className={JIT_STATUS_BADGE[r.status] || 'bg-ink-500/15 text-ink-400 ring-ink-500/30'}>
                      {JIT_STATUS_LABELS[r.status] || r.status}
                    </Badge>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {QUICK_LINKS.map((l) => (
          <Link key={l.to} to={l.to}>
            <Card className="flex items-center justify-between p-4 transition-colors hover:border-blue-500/40">
              <span className="flex items-center gap-3">
                <span className="flex h-9 w-9 flex-none items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-500/15 dark:text-blue-300">
                  <l.icon className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-sm font-medium text-ink-100">{l.label}</span>
                  <span className="block text-xs text-ink-500">{l.description}</span>
                </span>
              </span>
              <ArrowRight className="h-4 w-4 flex-none text-ink-600" />
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const isAdmin = useAuthStore((s) => s.isAdmin())
  return isAdmin ? <AdminDashboard /> : <UserDashboard user={user} />
}
