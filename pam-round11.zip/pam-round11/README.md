# Deep Algorithms PAM — round 11

Copy `backend_upd/` and `frontend_upd/` over your folders (the same paths) and
replace the files. No agent change in this round: keep the 2026.09.25.4
binaries already in `backend_upd/agents/` — that is the build SQL Developer
works with on Windows, and its source is kept in a safe snapshot on my side.

`.env` is NOT in this zip. Your own `backend_upd/.env` stays as it is.

## What changed

### 1. Devices panel wording (Settings → Devices)
- Every row is now a real resource type named the way the Resources page names
  it (PostgreSQL, MongoDB, Oracle, …) and shows what that machine can use:
  `CLI · psql`, `Desktop · pgAdmin 4`, `Web`.
- Only channels that resource type actually has are shown. Oracle no longer
  asks for SQLcl when SQL*Plus is there. ClickHouse shows its install hint
  only because no CLI client was found.
- Header: "Ready for N of 9 resource types", "Can record desktop sessions".
  Footer: "Checked when a session was last opened from this machine…".
- Section texts for "Install the desktop agent" and "Paired devices" were
  rewritten in plain words.

### 2. Why MongoDB appeared twice
The agent reports MongoDB Compass as its own entry (`mongodb-compass`), and the
panel printed every entry it received. The panel now shows only the resource
types the console offers, so Compass is folded into the single MongoDB row as
`Desktop · MongoDB Compass`. MongoDB also has no "Web" chip any more, because
PAM has no web client for MongoDB.

### 3. "Web" resource type removed
- The panel no longer lists it.
- The API now refuses to create a resource of type `web`
  (`400 resource_type must be one of: postgresql, mongodb, redis, clickhouse,
  minio, qdrant, metabase, langfuse, oracle`). Existing old rows, if any,
  still open.
- The Resources group list got its missing "Oracle Databases" label.

### 4. Settings page at low zoom
The settings content was capped at a fixed width, so when zoomed out it sat on
the left with empty space on the right. It now stretches across the page like
Resources, Sessions and the other pages (see `proof/02`–`04`).

### 5. Working env example files
| File | Use |
|---|---|
| `backend_upd/.env.example` | Local development. Copy to `.env`, works as it is with a local PostgreSQL database `pam` (user `pam`, password `pam`). Sign in as `root` / `DevRoot!ChangeMe-2026`. |
| `backend_upd/.env.production.example` | Production template: every setting, empty secrets, and the `openssl` command to generate each one. |
| `frontend_upd/.env.example` | Local development: `VITE_API_BASE_URL=http://localhost:8080`, then `npm run dev`. |
| `frontend_upd/.env.production.example` | Production build: the API URL, plus the runtime variables of the console container. |

The dev secrets in `.env.example` are public sample values. The backend now
refuses to start with `PAM_SERVER_ENV=production` while any of them (JWT key,
vault key, pepper, audit HMAC, root password) is still in place:

```
config.load.fail: jwt.secret_key (PAM_JWT_SECRET_KEY) is still the published sample value from .env.example; generate a real one before running in production
```

### 6. Bug found while testing the env files: CORS with several origins
`PAM_SERVER_ALLOWED_ORIGINS` accepts a comma-separated list (the websocket
gateway already read it that way), but the REST API sent the whole list back
in one header, which every browser rejects. So any list with more than one
origin blocked the console. The API now answers each allowed origin with
itself, and gives other origins nothing. A single origin or `*` behaves as
before.

## Also included: earlier backend files
Comparing against the last full package you have (pam-complete, plus round 8),
these earlier backend fixes were not in any zip I could confirm reached you,
and `resource_handler.go` above needs them to compile. They are included so
the zip builds on its own. If you already have them, the copies are identical.
- Qdrant and Metabase automatic sign-in in web sessions
  (`webproxy/authenticator_qdrant.go`, `authenticator_metabase.go`,
  `authenticator.go`, `proxy.go`)
- API-key credentials no longer require an account name
  (`models/vault.go`, `vault_handler.go`, `vault_service.go`)
- Audit event when a proxy in front of PAM strips websocket upgrade headers
  (`webproxy/upgrade_stripped_audit.go`, `models/audit_log.go`)

## How it was verified
- Your last copy plus this zip: `go vet ./...` and `go test ./...` pass, and
  the console lints and builds.
- The env files were tested on an empty database: the backend from
  `.env.example` (only the DB port changed for my test machine) created its
  schema, seeded root and served the agent downloads from `./agents`. The
  console from `frontend_upd/.env.example` signed in through the login form
  (`proof/05`). The same backend with `PAM_SERVER_ENV=production` refused
  to start, as shown above.
- CORS checked live: `localhost:5173` gets `localhost:5173` back,
  `localhost:4173` gets `localhost:4173`, and an unlisted origin gets nothing.
- Creating a `web` resource through the API returns 400; `oracle` is accepted.

## Reminder
The secrets in your real `backend_upd/.env` (RDS password, MinIO keys, JWT
secret, audit HMAC, root password) were shared earlier in this work. Please
rotate them if you haven't yet.
