package credentials

// Allowed query parameters and enum values — strict validation so typos like
// credential_tye are not silently ignored.

var (
	credentialsListAllowed = map[string]struct{}{
		"page": {}, "page_size": {}, "search": {},
		"credential_type": {}, "status": {}, "owner_principal_arn": {},
		"rotation_enabled": {}, "rotation_overdue": {},
		"is_orphaned": {}, "has_external_trust": {},
		"min_idle_days": {}, "max_days_until_expiry": {},
		"sort_by": {}, "sort_order": {},
	}

	credentialDetailAllowed = map[string]struct{}{
		"tab": {}, "time_range": {}, "start_date": {}, "end_date": {},
		"depth": {}, "edge_type": {}, "page": {}, "page_size": {},
	}

	credentialSortColumnsAllowed = map[string]struct{}{
		"name": {}, "arn": {}, "credential_type": {}, "account_id": {},
		"region": {}, "status": {}, "last_used_at": {}, "last_rotated_at": {},
		"expires_at": {}, "age_days": {}, "idle_days": {},
		"days_until_expiry": {}, "bound_identities_count": {},
	}

	validCredentialTypes = map[string]struct{}{
		"iam_role": {}, "iam_user": {}, "access_key": {}, "certificate": {},
		"api_key": {}, "secret": {}, "password": {}, "saml_provider": {},
		"oidc_provider": {}, "managed_policy": {}, "inline_policy": {},
		"service_account": {}, "service_principal": {}, "oauth_token": {},
		"ssh_key": {}, "tls_cert": {}, "kms_key": {},
	}

	validCredentialStatuses = map[string]struct{}{
		"active": {}, "inactive": {}, "expired": {}, "revoked": {},
		"rotated": {}, "pending": {}, "deleted": {},
	}

	validCredentialTabs = map[string]struct{}{
		"overview": {}, "trust": {}, "activity": {}, "rotation": {},
		"relationships": {}, "raw": {}, "changes": {},
	}
)
