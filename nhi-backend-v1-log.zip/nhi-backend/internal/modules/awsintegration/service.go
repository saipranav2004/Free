package awsintegration

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"time"

	"nhi-backend-api/internal/identitygraph/eventstore"
	"nhi-backend-api/internal/platform/awsconnect"
	"nhi-backend-api/internal/platform/logging"
)

var (
	// ErrAWSTenantNotConfigured: the tenant's row in nhi_global.tenants lacks
	// (or has inconsistent) AWS values. The super admin has to fill it in.
	ErrAWSTenantNotConfigured = errors.New("aws integration is not configured for this tenant")
	// ErrAWSUnavailable: this process has no usable AWS configuration.
	ErrAWSUnavailable = errors.New("aws is not reachable from the api")
	// ErrAWSVerifyInProgress: a verification for this tenant is already running.
	ErrAWSVerifyInProgress = errors.New("a connection check is already running")
	// ErrAWSWorkspaceUpdate: the account is saved but could not be added to
	// the tenant's account list. Verifying again repeats it safely.
	ErrAWSWorkspaceUpdate = errors.New("could not update the workspace's account list")
)

// What the customer is asked to set up. Kept next to the checks that prove it.
var (
	awsManagedPolicies = []string{"SecurityAudit", "ViewOnlyAccess"}
	awsEventSources    = []string{
		"aws.ec2", "aws.ecs", "aws.iam", "aws.sts",
		"aws.lambda", "aws.eks", "aws.secretsmanager", "aws.kms",
	}
)

// Time budget for one verification. The HTTP server's write timeout is 15s.
const (
	awsVerifyBudget     = 12 * time.Second
	awsAssumeTimeout    = 4 * time.Second
	awsReadTimeout      = 3 * time.Second
	awsPermissionBudget = 3 * time.Second
	awsCleanupTimeout   = 5 * time.Second
)

// AWSIntegrationStore is the global-database persistence
// (AWSIntegrationRepository in production).
type AWSIntegrationStore interface {
	TenantSettings(ctx context.Context, tenantID string) (*AWSTenantSettings, error)
	ListAccounts(ctx context.Context, tenantID string) ([]AWSAccountRecord, error)
	GetAccount(ctx context.Context, tenantID, accountID string) (*AWSAccountRecord, error)
	AccountClaimedByOther(ctx context.Context, tenantID, accountID string) (bool, error)
	SaveVerification(ctx context.Context, rec AWSAccountRecord) (*AWSAccountRecord, bool, error)
	UpdateRegions(ctx context.Context, tenantID, accountID string, regions []string) (*AWSAccountRecord, error)
	RequestSync(ctx context.Context, tenantID, accountID, actor string, at time.Time) (*AWSAccountRecord, bool, error)
	DeleteAccount(ctx context.Context, tenantID, accountID string) error
}

// AWSAccountRegistry keeps the tenant database's account list in step
// (TenantAccountRegistry in production).
type AWSAccountRegistry interface {
	Register(ctx context.Context, dbName, tenantID, accountID string, regions []string) error
	Unregister(ctx context.Context, dbName, tenantID, accountID string) error
}

// AWSVerifier is the AWS side (awsconnect.Client in production).
type AWSVerifier interface {
	AssumeRole(ctx context.Context, p awsconnect.Platform, role awsconnect.RoleARN, externalID string) (*awsconnect.Session, error)
	TestRead(ctx context.Context, s *awsconnect.Session) error
	AllowAccountOnBus(ctx context.Context, p awsconnect.Platform, accountID string) error
	RevokeAccountOnBus(ctx context.Context, p awsconnect.Platform, accountID string) error
}

// AWSEventSource answers "has an event from this account reached us?".
type AWSEventSource interface {
	HasEventsFrom(ctx context.Context, p awsconnect.Platform, accountID string, since time.Time) (bool, error)
}

// ClickHouseEventSource checks the CloudTrail event store the pipeline fills
// from the central bus.
type ClickHouseEventSource struct{ Repo *eventstore.Repository }

func (s ClickHouseEventSource) HasEventsFrom(ctx context.Context, _ awsconnect.Platform, accountID string, since time.Time) (bool, error) {
	return s.Repo.AccountHasEventsSince(ctx, accountID, since)
}

// AWSIntegrationOptions are the deployment's names and limits.
type AWSIntegrationOptions struct {
	AssumerRoleName   string
	CollectorRoleName string
	ForwardRuleName   string
	EventLookback     time.Duration
}

// AWSCaller is who is asking, from the signed token.
type AWSCaller struct {
	TenantID string
	DBName   string
	Actor    string
}

type AWSIntegrationService struct {
	store    AWSIntegrationStore
	registry AWSAccountRegistry
	verifier AWSVerifier
	events   AWSEventSource
	opts     AWSIntegrationOptions
	now      func() time.Time

	running sync.Map // tenantID -> struct{}: one verification per tenant at a time
}

// NewAWSIntegrationService wires the service. verifier may be nil when the
// process has no AWS configuration (the page still loads; verification
// answers ErrAWSUnavailable), and events may be nil when there is no event
// store (the events check then reports it cannot run).
func NewAWSIntegrationService(store AWSIntegrationStore, registry AWSAccountRegistry, verifier AWSVerifier, events AWSEventSource, opts AWSIntegrationOptions) *AWSIntegrationService {
	if opts.EventLookback <= 0 {
		opts.EventLookback = 24 * time.Hour
	}
	opts.AssumerRoleName = orDefault(opts.AssumerRoleName, "NHIPlatformAssumer")
	opts.CollectorRoleName = orDefault(opts.CollectorRoleName, "NHIPlatformCollector")
	opts.ForwardRuleName = orDefault(opts.ForwardRuleName, "nhi-forward-events")
	return &AWSIntegrationService{store: store, registry: registry, verifier: verifier, events: events, opts: opts, now: time.Now}
}

// platform reads the tenant's AWS values and checks them against each other.
func (s *AWSIntegrationService) platform(ctx context.Context, tenantID string) (awsconnect.Platform, *AWSTenantSettings, error) {
	settings, err := s.store.TenantSettings(ctx, tenantID)
	if err != nil {
		return awsconnect.Platform{}, nil, err
	}
	if settings == nil || settings.AWSAccountID == "" || settings.EventBusARN == "" || settings.ExternalID == "" {
		logging.FromContext(ctx).Warn("aws integration: tenant has no aws_account_id / event_bus_arn / external_id in nhi_global.tenants", "tenant_id", tenantID)
		return awsconnect.Platform{}, settings, ErrAWSTenantNotConfigured
	}
	p, err := awsconnect.PlatformForTenant(settings.AWSAccountID, settings.EventBusARN, s.opts.AssumerRoleName)
	if err != nil {
		logging.FromContext(ctx).Warn("aws integration: platform lookup failed", "tenant_id", tenantID, "err", err)
		return awsconnect.Platform{}, settings, ErrAWSTenantNotConfigured
	}
	return p, settings, nil
}

// Get returns the tenant's connection status and accounts and, for those who
// may manage them, the values to copy and the regions to choose from.
func (s *AWSIntegrationService) Get(ctx context.Context, tenantID string, canManage bool) (*AWSIntegrationResponse, error) {
	records, err := s.store.ListAccounts(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	out := &AWSIntegrationResponse{
		Status:    tenantStatus(records),
		CanManage: canManage,
		Accounts:  make([]AWSConnectedAccount, 0, len(records)),
	}
	for _, rec := range records {
		out.Accounts = append(out.Accounts, rec.ToAPI())
	}

	p, settings, err := s.platform(ctx, tenantID)
	if settings != nil {
		out.Workspace.Domain = settings.Domain
	}
	if !canManage {
		return out, nil
	}
	if err != nil {
		return nil, err
	}
	regions := make([]AWSRegion, 0, len(awsconnect.Regions))
	for _, r := range awsconnect.Regions {
		regions = append(regions, AWSRegion{Code: r.Code, Name: r.Name, Group: r.Group, OptIn: r.OptIn})
	}
	out.Setup = &AWSSetupValues{
		AccountID:       p.AccountID,
		ExternalID:      settings.ExternalID,
		EventBusARN:     p.EventBusARN,
		Region:          p.Region,
		AssumerRoleARN:  p.AssumerRoleARN,
		RoleName:        s.opts.CollectorRoleName,
		RuleName:        s.opts.ForwardRuleName,
		ManagedPolicies: append([]string(nil), awsManagedPolicies...),
		EventSources:    append([]string(nil), awsEventSources...),
		Regions:         regions,
	}
	return out, nil
}

func tenantStatus(records []AWSAccountRecord) string {
	if len(records) == 0 {
		return AWSStatusNotConnected
	}
	for _, rec := range records {
		if rec.Status == AWSStatusConnected {
			return AWSStatusConnected
		}
	}
	return AWSStatusActionNeeded
}

// Verify runs the three checks for a pasted role ARN and the regions the
// customer allows, in order:
//
//  1. sts:AssumeRole with the ARN and the tenant's External ID
//  2. iam:ListRoles with the assumed role (one test read)
//  3. an event from the account has reached us
//
// Before (3) the account is allowed to put events on the central bus. Nothing
// is stored or granted until (1) passes, because only then has the tenant
// shown it controls the account. The first time all three pass, a sync is
// queued and the account joins the tenant's account list.
func (s *AWSIntegrationService) Verify(ctx context.Context, caller AWSCaller, rawRoleARN string, rawRegions []string) (*AWSVerifyResponse, error) {
	p, settings, err := s.platform(ctx, caller.TenantID)
	if err != nil {
		return nil, err
	}
	role, err := awsconnect.ParseRoleARN(rawRoleARN)
	if err != nil {
		return nil, err
	}
	if role.AccountID == p.AccountID {
		return nil, &awsconnect.ErrInvalidRoleARN{Message: "That ARN is in our account (" + p.AccountID + "). Paste the ARN of the role you created in your own AWS account."}
	}
	regions, err := awsconnect.NormalizeRegions(rawRegions)
	if err != nil {
		return nil, err
	}
	if s.verifier == nil {
		return nil, ErrAWSUnavailable
	}

	if _, busy := s.running.LoadOrStore(caller.TenantID, struct{}{}); busy {
		return nil, ErrAWSVerifyInProgress
	}
	defer s.running.Delete(caller.TenantID)

	ctx, cancel := context.WithTimeout(ctx, awsVerifyBudget)
	defer cancel()

	checks := newChecks()
	result := &AWSVerifyResponse{
		Status:     AWSStatusActionNeeded,
		AccountID:  role.AccountID,
		RoleARN:    role.ARN,
		Regions:    regions,
		Checks:     checks,
		VerifiedAt: s.now().UTC(),
	}

	// 1. AssumeRole
	stepCtx, stepCancel := context.WithTimeout(ctx, awsAssumeTimeout)
	session, err := s.verifier.AssumeRole(stepCtx, p, role, settings.ExternalID)
	stepCancel()
	if err != nil {
		if errors.Is(err, awsconnect.ErrAccessDenied) {
			fail(&checks[0], "AWS would not let us use this role.", "Check the External ID matches")
		} else {
			logCheckError(caller.TenantID, role.AccountID, checks[0].Key, err)
			unavailable(&checks[0])
		}
		skip(&checks[1])
		skip(&checks[2])
		return result, nil
	}
	pass(&checks[0], "Signed in to your account with your External ID.")

	// The tenant controls this account. It may still belong to another tenant.
	claimed, err := s.store.AccountClaimedByOther(ctx, caller.TenantID, role.AccountID)
	if err != nil {
		return nil, err
	}
	if claimed {
		return nil, ErrAWSAccountClaimed
	}

	// 2. One test read
	stepCtx, stepCancel = context.WithTimeout(ctx, awsReadTimeout)
	err = s.verifier.TestRead(stepCtx, session)
	stepCancel()
	switch {
	case err == nil:
		pass(&checks[1], "Read access works.")
	case errors.Is(err, awsconnect.ErrAccessDenied), errors.Is(err, awsconnect.ErrNothingRead):
		fail(&checks[1], "The role cannot read your account.", "Attach SecurityAudit + ViewOnlyAccess")
	default:
		logCheckError(caller.TenantID, role.AccountID, checks[1].Key, err)
		unavailable(&checks[1])
	}

	// 3. Events. Allow the account on the bus first (idempotent); EventBridge
	// retries refused deliveries, so events sent before this still arrive.
	stepCtx, stepCancel = context.WithTimeout(ctx, awsPermissionBudget)
	err = s.verifier.AllowAccountOnBus(stepCtx, p, role.AccountID)
	stepCancel()
	switch {
	case err != nil:
		logCheckError(caller.TenantID, role.AccountID, "bus_permission", err)
		unavailable(&checks[2])
	case s.events == nil:
		logCheckError(caller.TenantID, role.AccountID, checks[2].Key, errors.New("no event source: configure ClickHouse or aws_integration.event_log_group"))
		unavailable(&checks[2])
	default:
		found, err := s.events.HasEventsFrom(ctx, p, role.AccountID, s.now().Add(-s.opts.EventLookback))
		switch {
		case err != nil:
			logCheckError(caller.TenantID, role.AccountID, checks[2].Key, err)
			unavailable(&checks[2])
		case found:
			pass(&checks[2], "Events from your account are arriving.")
		default:
			fail(&checks[2], fmt.Sprintf("No events from this account in the last %s.", humanHours(s.opts.EventLookback)), "Check the EventBridge rule target ARN")
		}
	}

	if checks[0].State == AWSCheckPass && checks[1].State == AWSCheckPass && checks[2].State == AWSCheckPass {
		result.Status = AWSStatusConnected
	}

	// Saved even if the caller has gone: the checks really ran.
	saveCtx, saveCancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer saveCancel()
	saved, queued, err := s.store.SaveVerification(saveCtx, AWSAccountRecord{
		TenantID:       caller.TenantID,
		AccountID:      role.AccountID,
		RoleARN:        role.ARN,
		Regions:        regions,
		ExternalID:     settings.ExternalID,
		Status:         result.Status,
		Checks:         checks,
		LastVerifiedAt: result.VerifiedAt,
		LastVerifiedBy: caller.Actor,
	})
	if errors.Is(err, ErrAWSAccountClaimed) {
		return nil, ErrAWSAccountClaimed
	}
	if err != nil {
		return nil, err
	}
	result.Saved = true
	result.SyncQueued = queued

	if saved.Status == AWSStatusConnected {
		if err := s.registry.Register(saveCtx, caller.DBName, caller.TenantID, role.AccountID, regions); err != nil {
			slog.WarnContext(ctx, "aws integration: register in tenant database", "tenant_id", caller.TenantID, "account", role.AccountID, "err", err)
			return nil, ErrAWSWorkspaceUpdate
		}
	}
	return result, nil
}

// UpdateRegions changes the regions an account is read in. A connected
// account's rows in the tenant's account list follow.
func (s *AWSIntegrationService) UpdateRegions(ctx context.Context, caller AWSCaller, accountID string, rawRegions []string) (*AWSConnectedAccount, error) {
	regions, err := awsconnect.NormalizeRegions(rawRegions)
	if err != nil {
		return nil, err
	}
	rec, err := s.store.UpdateRegions(ctx, caller.TenantID, accountID, regions)
	if err != nil {
		return nil, err
	}
	if rec.Status == AWSStatusConnected {
		if err := s.registry.Register(ctx, caller.DBName, caller.TenantID, accountID, regions); err != nil {
			slog.WarnContext(ctx, "aws integration: register regions", "tenant_id", caller.TenantID, "account", accountID, "err", err)
			return nil, ErrAWSWorkspaceUpdate
		}
	}
	account := rec.ToAPI()
	return &account, nil
}

// RequestSync queues a sync of one connected account, in its allowed
// regions. Asking again while one is queued or running changes nothing.
func (s *AWSIntegrationService) RequestSync(ctx context.Context, caller AWSCaller, accountID string) (*AWSSyncResponse, error) {
	rec, already, err := s.store.RequestSync(ctx, caller.TenantID, accountID, caller.Actor, s.now().UTC())
	if err != nil {
		return nil, err
	}
	// Repairs the tenant's account list if an earlier update did not land;
	// the sync itself does not depend on it.
	if err := s.registry.Register(ctx, caller.DBName, caller.TenantID, accountID, rec.Regions); err != nil {
		slog.WarnContext(ctx, "aws integration: register on sync", "tenant_id", caller.TenantID, "account", accountID, "err", err)
	}
	return &AWSSyncResponse{Account: rec.ToAPI(), AlreadyQueued: already}, nil
}

// RemoveAccount disconnects an account: it leaves the tenant's account list
// (its scanned records drop out of every scope), its row is deleted, and its
// permission on the central bus is revoked so its events are refused.
// Nothing changes in the customer's AWS account; the page tells them to
// delete the role and rule themselves.
func (s *AWSIntegrationService) RemoveAccount(ctx context.Context, caller AWSCaller, accountID string) error {
	rec, err := s.store.GetAccount(ctx, caller.TenantID, accountID)
	if err != nil {
		return err
	}
	if rec == nil {
		return ErrAWSAccountNotFound
	}
	// The account list first: if this fails nothing has changed, and a retry
	// starts clean. Both steps are idempotent.
	if err := s.registry.Unregister(ctx, caller.DBName, caller.TenantID, accountID); err != nil {
		slog.WarnContext(ctx, "aws integration: unregister", "tenant_id", caller.TenantID, "account", accountID, "err", err)
		return ErrAWSWorkspaceUpdate
	}
	if err := s.store.DeleteAccount(ctx, caller.TenantID, accountID); err != nil {
		return err
	}
	// Best effort: the account is already removed; a permission left behind
	// only lets events in that no tenant scope includes.
	if s.verifier != nil {
		if p, _, err := s.platform(ctx, caller.TenantID); err == nil {
			cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), awsCleanupTimeout)
			defer cancel()
			if err := s.verifier.RevokeAccountOnBus(cleanupCtx, p, accountID); err != nil {
				slog.ErrorContext(ctx, "aws integration: revoke bus permission failed, remove the statement by hand",
					"tenant_id", caller.TenantID, "account", accountID, "statement", awsconnect.BusStatementID(accountID), "err", err)
			}
		}
	}
	return nil
}

func newChecks() []AWSCheck {
	return []AWSCheck{
		{Key: AWSCheckAssumeRole, Label: "Assume your role"},
		{Key: AWSCheckReadAccess, Label: "Read your account"},
		{Key: AWSCheckEvents, Label: "Receive your events"},
	}
}

func pass(c *AWSCheck, message string) {
	c.State, c.Message, c.Fix = AWSCheckPass, message, ""
}

func fail(c *AWSCheck, message, fix string) {
	c.State, c.Message, c.Fix = AWSCheckFail, message, fix
}

func skip(c *AWSCheck) {
	c.State, c.Message, c.Fix = AWSCheckSkipped, "Runs once the check above passes.", ""
}

func unavailable(c *AWSCheck) {
	c.State, c.Message, c.Fix = AWSCheckError, "We could not run this check just now. Try again in a minute.", ""
}

// logCheckError keeps AWS's own error text in the server log only.
func logCheckError(tenantID, accountID, check string, err error) {
	slog.Warn("aws integration: check failed", "tenant_id", tenantID, "account", accountID, "check", check, "err", err)
}

func humanHours(d time.Duration) string {
	hours := int(d.Round(time.Hour) / time.Hour)
	switch {
	case hours <= 1:
		return "hour"
	case hours%24 == 0 && hours > 24:
		return fmt.Sprintf("%d days", hours/24)
	default:
		return fmt.Sprintf("%d hours", hours)
	}
}

func orDefault(value, fallback string) string {
	if v := strings.TrimSpace(value); v != "" {
		return v
	}
	return fallback
}
