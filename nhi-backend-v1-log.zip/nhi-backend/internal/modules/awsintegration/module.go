// Package awsintegration serves the "Connect AWS Account" setup: it shows the
// values a tenant copies into the AWS console, runs the connection checks,
// and manages the connected accounts, their regions and their sync requests.
package awsintegration

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/database"
)

// Module wires the package's handler and registers its routes.
type Module struct {
	handler *AWSIntegrationHandler
}

// New builds the module. verifier may be nil when the process has no AWS
// configuration, and events may be nil when there is no event store; the page
// still loads and the affected checks report that they cannot run.
func New(pg *database.PostgresDB, verifier AWSVerifier, events AWSEventSource, opts AWSIntegrationOptions) *Module {
	service := NewAWSIntegrationService(NewAWSIntegrationRepository(pg), NewTenantAccountRegistry(pg), verifier, events, opts)
	return &Module{handler: NewAWSIntegrationHandler(service)}
}

// Register mounts the AWS integration routes on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/integrations/aws", m.handler.Get).Methods(http.MethodGet)
	r.HandleFunc("/integrations/aws/verify", m.handler.Verify).Methods(http.MethodPost)
	r.HandleFunc("/integrations/aws/accounts/{account_id}/regions", m.handler.UpdateRegions).Methods(http.MethodPut)
	r.HandleFunc("/integrations/aws/accounts/{account_id}/sync", m.handler.Sync).Methods(http.MethodPost)
	r.HandleFunc("/integrations/aws/accounts/{account_id}", m.handler.Remove).Methods(http.MethodDelete)
}
