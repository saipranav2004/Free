package credentialexposure

import (
	"errors"
	"net/http"
	"strings"

	"nhi-backend-api/internal/platform/middleware"
)

type DecisionHandler struct{ service *DecisionService }

func NewDecisionHandler(service *DecisionService) *DecisionHandler {
	return &DecisionHandler{service: service}
}

func (h *DecisionHandler) Save(w http.ResponseWriter, r *http.Request) {
	if !requireScannerAdmin(w, r) {
		return
	}
	claims := middleware.GetClaims(r)
	if rejectUnknownQuery(w, r, map[string]struct{}{}) {
		return
	}
	var req FindingDecisionRequest
	if !decodeJSONBody(w, r, &req) {
		return
	}
	by := strings.TrimSpace(req.DecidedBy)
	if by == "" {
		by = "dashboard user"
	}
	err := h.service.Save(r.Context(), claims.UserID, claims.TenantID, claims.DBName, req.FindingID, req.Decision, by)
	if err != nil {
		switch {
		case errors.Is(err, ErrDecisionFindingNotFound):
			writeError(w, http.StatusNotFound, "NOT_FOUND", "Finding not found")
		case errors.Is(err, ErrDecisionFindingAmbiguous):
			writeError(w, http.StatusConflict, "AMBIGUOUS_FINDING", "Finding ID matched more than one platform table")
		case strings.Contains(err.Error(), "required") || strings.Contains(err.Error(), "must be") || strings.Contains(err.Error(), "decision must") || strings.Contains(err.Error(), "exceeds"):
			writeAPIError(w, http.StatusBadRequest, err.Error(), "INVALID_DECISION")
		default:
			serverError(w, r, "Unable to save analyst decision", err)
		}
		return
	}
	writeJSON(w, http.StatusOK, OKResponse{OK: true})
}
