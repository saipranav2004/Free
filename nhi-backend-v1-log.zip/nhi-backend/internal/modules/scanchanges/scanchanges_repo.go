package scanchanges

import (
	"context"
	"database/sql"
	"errors"
	"fmt"

	"github.com/lib/pq"

	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/scope"
)

// Repository layer: SQL only. Every table is qualified with the caller's
// tenant schema (scope.Table) and every scan lookup is constrained to the
// caller's selected accounts, so a scan id guessed from another account or
// tenant reads as "not found".
type ScanChangesRepository struct{}

func NewScanChangesRepository() *ScanChangesRepository { return &ScanChangesRepository{} }

// ScanHeader loads the scan row itself. A scan outside the account scope and a
// missing nhi_scans_aws table both answer ErrScanNotFound, because in neither
// case can the caller read it.
func (r *ScanChangesRepository) ScanHeader(ctx context.Context, sc *scope.DataScope, scanID string) (*scanHeader, error) {
	if sc == nil || sc.DB == nil {
		return nil, ErrScanNotFound
	}
	query := fmt.Sprintf(`
		SELECT scan_id::text, COALESCE(status, ''), scan_end
		FROM %s
		WHERE scan_id::text = $1 AND account_id = ANY($2::text[])
		LIMIT 1`, sc.Table("nhi_scans_aws"))

	var h scanHeader
	err := sc.DB.QueryRowContext(ctx, query, scanID, pq.Array(sc.AccountIDs)).Scan(&h.ScanID, &h.Status, &h.ScannedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) || database.IsUndefinedTable(err) {
			return nil, ErrScanNotFound
		}
		return nil, fmt.Errorf("load scan header: %w", err)
	}
	return &h, nil
}

// PreviousScanID returns the previous scan id recorded on the newest change
// row of this scan, or nil when no row carries one (or scan_changes does not
// exist for this tenant yet).
func (r *ScanChangesRepository) PreviousScanID(ctx context.Context, sc *scope.DataScope, scanID string) (*string, error) {
	if sc == nil || sc.DB == nil {
		return nil, nil
	}
	query := fmt.Sprintf(`
		SELECT NULLIF(previous_scan_id, '')
		FROM %s
		WHERE scan_id = $1 AND previous_scan_id IS NOT NULL AND previous_scan_id <> ''
		ORDER BY detected_at DESC, id
		LIMIT 1`, sc.Table("scan_changes"))

	var prev sql.NullString
	err := sc.DB.QueryRowContext(ctx, query, scanID).Scan(&prev)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) || database.IsUndefinedTable(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("load previous scan id: %w", err)
	}
	if !prev.Valid {
		return nil, nil
	}
	return &prev.String, nil
}

// Counts groups the whole scan by (change_type, entity_type). It deliberately
// has no filter: the summary must not shift when the list is filtered. A
// missing scan_changes table is "no changes yet", not an error.
func (r *ScanChangesRepository) Counts(ctx context.Context, sc *scope.DataScope, scanID string) ([]countRow, error) {
	if sc == nil || sc.DB == nil {
		return nil, nil
	}
	query := fmt.Sprintf(`
		SELECT change_type, entity_type, count(*)::int
		FROM %s
		WHERE scan_id = $1
		GROUP BY change_type, entity_type`, sc.Table("scan_changes"))

	rows, err := sc.DB.QueryContext(ctx, query, scanID)
	if err != nil {
		if database.IsUndefinedTable(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("load change counts: %w", err)
	}
	defer rows.Close()

	var out []countRow
	for rows.Next() {
		var c countRow
		if err := rows.Scan(&c.ChangeType, &c.EntityType, &c.Count); err != nil {
			return nil, fmt.Errorf("scan change count: %w", err)
		}
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return out, nil
}

// Page returns the filtered page plus the unfiltered total (COUNT(*) OVER()).
// Bounded page/limit integers are interpolated rather than bound, the same
// convention as the eventstore queries; every other value is parameterised.
func (r *ScanChangesRepository) Page(ctx context.Context, sc *scope.DataScope, f ScanChangesFilter) ([]ScanChangeItem, int, error) {
	if sc == nil || sc.DB == nil {
		return []ScanChangeItem{}, 0, nil
	}
	where := "scan_id = $1"
	args := []any{f.ScanID}
	if f.ChangeType != "" {
		args = append(args, f.ChangeType)
		where += fmt.Sprintf(" AND change_type = $%d", len(args))
	}
	if f.EntityType != "" {
		args = append(args, f.EntityType)
		where += fmt.Sprintf(" AND entity_type = $%d", len(args))
	}
	query := fmt.Sprintf(`
		SELECT id::text, change_type, entity_type, entity_arn,
		       entity_id::text, summary, details, detected_at,
		       COUNT(*) OVER()::int AS total
		FROM %s
		WHERE %s
		ORDER BY detected_at DESC, id
		LIMIT %d OFFSET %d`,
		sc.Table("scan_changes"), where, f.Limit, (f.Page-1)*f.Limit)

	rows, err := sc.DB.QueryContext(ctx, query, args...)
	if err != nil {
		if database.IsUndefinedTable(err) {
			return []ScanChangeItem{}, 0, nil
		}
		return nil, 0, fmt.Errorf("query scan changes: %w", err)
	}
	defer rows.Close()

	var (
		out   []ScanChangeItem
		total int
	)
	for rows.Next() {
		var (
			c   ScanChangeItem
			eid sql.NullString
			n   int
		)
		if err := rows.Scan(&c.ID, &c.ChangeType, &c.EntityType, &c.EntityARN,
			&eid, &c.Summary, &c.Details, &c.DetectedAt, &n); err != nil {
			return nil, 0, fmt.Errorf("scan scan change: %w", err)
		}
		if eid.Valid {
			c.EntityID = &eid.String
		}
		total = n
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, err
	}
	if out == nil {
		out = []ScanChangeItem{}
	}
	return out, total, nil
}
