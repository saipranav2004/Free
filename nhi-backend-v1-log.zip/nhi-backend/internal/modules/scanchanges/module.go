// Package scanchanges serves the per-scan change list produced by comparing
// two scans (GET /api/v1/scans/{scan_id}/changes). The tables scan_changes and
// nhi_scans_aws live in the tenant schema; every query is schema-qualified
// through scope.DataScope.Table and scoped to the caller's selected accounts.
package scanchanges

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handler and registers its route.
type Module struct {
	handler *ScanChangesHandler
}

// New builds the module.
func New(resolver *scope.Resolver) *Module {
	return &Module{handler: NewScanChangesHandler(NewScanChangesService(NewScanChangesRepository(), resolver))}
}

// Register mounts the scan-changes route on an authenticated router. Paths are
// relative; the router adds /api/v1.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/scans/{scan_id}/changes", m.handler.List).Methods(http.MethodGet)
}
