package identitysummary

import (
	"context"

	"nhi-backend-api/internal/modules/genome/common"
)

// Service implements GET /api/v1/genome/identities/{source_type}/{identity_name}
// — the identity page header:
//
//   - identity          latest discovery snapshot, normalized (PostgreSQL)
//   - baseline_summary  baselines                                (PostgreSQL)
//   - risk              latest identity_risk_scores snapshot     (PostgreSQL)
//   - headline_metrics  open alerts (PostgreSQL); calls in the requested
//     window and last seen (ClickHouse log_events)
//   - links             relative paths of the sub-resources
//
// Monitoring facts are looked up by the identity key first and the shared
// workload key second (the fallback). Nothing is invented: a section whose
// store cannot be read is null (logged server-side), and the ClickHouse
// metrics are null until the pipeline's log_events is reachable.
type Service struct {
	lookup *common.MonitoredIdentityLookup
	repo   *Repository
	events *common.MonitoringEvents // nil when no monitoring ClickHouse is configured
}

// NewService wires the service.
func NewService(lookup *common.MonitoredIdentityLookup, repo *Repository, events *common.MonitoringEvents) *Service {
	return &Service{lookup: lookup, repo: repo, events: events}
}

// Params are the parsed query parameters (from/to).
type Params struct {
	Window common.TimeWindow // window of headline_metrics.calls_in_window
}

// GetIdentity builds the response. Unknown identities are
// common.ErrIdentityNotFound; scope/discovery failures are
// *common.StoreUnavailableError.
func (s *Service) GetIdentity(ctx context.Context, userID, tenantID, dbName, sourceType, identityName string, p Params) (*Response, error) {
	res, err := s.lookup.Resolve(ctx, userID, tenantID, dbName, sourceType, identityName)
	if err != nil {
		return nil, err
	}
	id, sc := res.Identity, res.Scope
	keys := id.AllKeys() // identity key, then the workload key when it differs

	out := &Response{
		Identity: Record{
			ID:              id.Key.SourceType + ":" + id.Key.IdentityName,
			SourceType:      id.Key.SourceType,
			NHIIdentityType: id.Subtype,
			IdentityName:    id.Key.IdentityName,
			DisplayName:     id.DisplayName,
			WorkloadKey:     id.WorkloadKey,
			Status:          common.OptionalString(id.Status),
			AccountID:       id.AccountID,
			Region:          common.OptionalString(id.Region),
			ServiceName:     common.OptionalString(id.ServiceName),
			RoleType:        common.OptionalString(id.RoleType),
			RoleARN:         common.OptionalString(id.RoleARN),
		},
		Links: common.IdentityLinksFor(id.Key.SourceType, id.Key.IdentityName),
	}

	// ---- PostgreSQL monitoring tables -------------------------------------
	if b, err := s.repo.BaselineSummary(ctx, sc, keys); common.ReadOK("identity baseline summary", err) && b != nil {
		out.BaselineSummary = BaselineSummary{Status: common.OptionalString(b.Status), BuiltDays: common.IntPtr(b.BuiltDays), RequiredDays: common.IntPtr(b.RequiredDays)}
	}
	if r, err := common.LatestRiskPreferred(ctx, sc, keys); common.ReadOK("identity latest risk", err) && r != nil {
		out.Risk = RiskSnapshot{Score: r.RiskScore, Severity: common.OptionalString(r.Severity), Status: common.OptionalString(r.ScoreStatus)}
	}
	if n, err := s.repo.OpenAlertCount(ctx, sc, keys); common.ReadOK("identity open alerts", err) {
		out.HeadlineMetrics.OpenAnomalies = common.IntPtr(n)
	}

	// ---- ClickHouse log_events ------------------------------------------------
	if calls, err := s.events.TotalCalls(ctx, id.Key.SourceType, id.Key.IdentityName, p.Window.From, p.Window.To); common.EventsReadOK("identity calls in window", err) {
		out.HeadlineMetrics.CallsInWindow = &calls
	}
	if last, err := s.events.LastSeen(ctx, id.Key.SourceType, id.Key.IdentityName); common.EventsReadOK("identity last seen", err) {
		out.HeadlineMetrics.LastSeen = last
	}
	if err := common.BudgetExceeded(ctx, "identity summary"); err != nil {
		return nil, err
	}
	return out, nil
}
