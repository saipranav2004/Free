package eventstore

import (
	"context"
	"fmt"
	"strings"
	"time"

	ch "github.com/ClickHouse/clickhouse-go/v2"
)

// changeEventsLimit bounds the rows read for one resource. A resource has a
// handful of Create*/Delete* events in practice; the cap only guards against a
// pathological ARN.
const changeEventsLimit = 200

// ChangeEvent is one successful Create*/Delete* CloudTrail call on a resource,
// used as evidence for a CREATED/DELETED scan change.
type ChangeEvent struct {
	EventName string
	CallerARN string
	EventTime time.Time
	SourceIP  string
}

// ChangeEventsByARN returns the successful events whose name starts with
// Create or Delete and whose resource_arn is arn, newest first. accounts is
// the tenant's isolation boundary: no accounts, no query.
func (c *Repository) ChangeEventsByARN(ctx context.Context, arn string, accounts []string) ([]ChangeEvent, error) {
	arn = strings.TrimSpace(arn)
	if arn == "" || len(accounts) == 0 {
		return nil, nil
	}
	q := fmt.Sprintf(`SELECT event_name, caller_arn, event_time, source_ip FROM %s
		WHERE resource_arn = {arn:String}
		  AND (startsWith(event_name, 'Create') OR startsWith(event_name, 'Delete'))
		  AND error_code = ''
		  AND account_id IN {accounts:Array(String)}
		ORDER BY event_time DESC
		LIMIT %d`, c.table, changeEventsLimit)

	ctx, cancel := c.withTimeout(ctx)
	defer cancel()
	rows, err := c.conn.Query(ctx, q, ch.Named("arn", arn), ch.Named("accounts", accounts))
	if err != nil {
		return nil, fmt.Errorf("clickhouse change events: %w", err)
	}
	defer rows.Close()

	var out []ChangeEvent
	for rows.Next() {
		var e ChangeEvent
		if err := rows.Scan(&e.EventName, &e.CallerARN, &e.EventTime, &e.SourceIP); err != nil {
			return nil, fmt.Errorf("clickhouse change events scan: %w", err)
		}
		out = append(out, e)
	}
	return out, rows.Err()
}
