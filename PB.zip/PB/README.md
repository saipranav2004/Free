# PAM — Privileged Access Management

Go (Gin) backend for enterprise PAM. Uses IAM as the PDP (Policy Decision Point).
Every privileged action calls IAM's `POST /api/v1/authz/check` → OPA → allow/deny.

---

## Table of Contents

1. [Architecture](#1-architecture)
2. [How to Start the Application](#2-how-to-start-the-application)
3. [Project Structure](#3-project-structure)
4. [Authentication System](#4-authentication-system)
5. [How IAM Is Used as PDP (Not IdP)](#5-how-iam-is-used-as-pdp-not-idp)
6. [GORM Models — Shared & PAM-Specific](#6-gorm-models--shared--pam-specific)
7. [Middleware System](#7-middleware-system)
8. [How to Build a New Feature (step by step)](#8-how-to-build-a-new-feature-step-by-step)
9. [Common Go Errors & Fixes](#9-common-go-errors--fixes)
10. [Context for LLMs (ChatGPT / Claude / Copilot)](#10-context-for-llms-chatgpt--claude--copilot)
11. [Environment Variables](#11-environment-variables)
12. [Testing in Postman](#12-testing-in-postman)
13. [Tech Stack & Libraries](#13-tech-stack--libraries)

---

## 1. Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     IAM CONTROL CENTER (Python/Flask)            │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Admin dashboard: audit, recordings, JIT approvals       │   │
│  │  PDP: POST /api/v1/authz/check → OPA → allow/deny        │   │
│  │  Creates users in iam.iam_users (shared PostgreSQL)      │   │
│  └──────────────────────────────────────────────────────────┘   │
└──────────────────────────┬──────────────────────────────────────┘
                           │ authz/check (HTTP)
┌──────────────────────────▼──────────────────────────────────────┐
│                     PAM APPLICATION (Go/Gin)                     │
│                                                                  │
│  AUTH (PAM owns it):                                             │
│    Login → verify password against iam.iam_users (Argon2id)     │
│    MFA  → PAM's own TOTP (pam_mfa_devices table)               │
│    JWT  → HS256, self-signed (separate from IAM's RS256)        │
│                                                                  │
│  AUTHORIZATION (IAM owns it):                                    │
│    Every privileged action → POST IAM /authz/check → OPA        │
│    If denied → 403                                               │
│                                                                  │
│  ┌────────────┐ ┌──────────────┐ ┌──────────────────────────┐  │
│  │  PAM API   │ │  Vault Svc   │ │  Session Gateway         │  │
│  │  (Gin)     │ │  (AES-256)   │ │  (SSH proxy + recording) │  │
│  └─────┬──────┘ └──────┬───────┘ └────────────┬─────────────┘  │
│        └───────────────┼──────────────────────┘                 │
│                 GORM → PostgreSQL (shared, pam schema)           │
│                 Redis  (live sessions)                           │
│                 S3     (recordings)                              │
└──────────────────────────────────────────────────────────────────┘
```

**Key principle:** PAM owns authentication (login + MFA). IAM owns authorization (what you're allowed to do). They share the same PostgreSQL database but use different schemas (`iam.*` and `pam.*`).

---

## 2. How to Start the Application

### Prerequisites
- Go 1.22+
- PostgreSQL (shared with IAM, same instance)
- IAM running on `localhost:5000` (for authz/check)

### Setup

```bash
# 1. Clone / navigate to the project root
cd pam/

# 2. Create .env file (see §11 for all variables)
cp .env.example .env
# Edit .env with your actual values

# 3. Generate the two required keys:
openssl rand -hex 32     # → paste into PAM_JWT_SECRET_KEY
openssl rand -base64 32  # → paste into PAM_VAULT_ENCRYPTION_KEY

# 4. Download dependencies
go mod tidy

# 5. Run
go run cmd/pam-api/main.go
# → PAM API starts on :8080
```

### Verify it's running

```bash
curl http://localhost:8080/health
# → {"status":"ok","service":"PAM","version":"1.0.0"}
```

---

## 3. Project Structure

```
pam/
├── cmd/
│   └── pam-api/
│       └── main.go                    # Entry point (Gin server + route registration)
│
├── internal/                           # Private application code
│   ├── api/handlers/                   # Gin HTTP handlers (one file per domain)
│   │   ├── auth_handler.go             #   Login, MFA, logout, /me
│   │   ├── vault_handler.go            #   Vault CRUD, checkout, rotate (TODO)
│   │   ├── session_handler.go          #   SSH/RDP sessions (TODO)
│   │   ├── jit_handler.go              #   JIT access workflow (TODO)
│   │   ├── discovery_handler.go        #   Network scanning (TODO)
│   │   └── audit_handler.go            #   Compliance reports (TODO)
│   │
│   ├── config/config.go               # Viper config (env vars + YAML)
│   ├── database/postgres.go           # GORM connection + schema init
│   │
│   ├── middleware/                     # Gin middleware
│   │   ├── auth.go                    #   PAMAuth (verify PAM HS256 JWT)
│   │   ├── authz.go                   #   RequirePermission (call IAM /authz/check)
│   │   ├── audit.go                   #   AuditMiddleware (log every request)
│   │   └── cors.go                    #   CORS headers
│   │
│   ├── models/                        # GORM models (table mappings)
│   │   ├── user.go                    #   iam.iam_users (READ-ONLY, shared with IAM)
│   │   ├── pam_mfa.go                 #   pam_mfa_devices (PAM's own TOTP)
│   │   ├── vault.go                   #   pam_vault_entries (TODO)
│   │   ├── session.go                 #   pam_sessions (TODO)
│   │   └── ...
│   │
│   ├── response/response.go           # Standardized JSON envelopes
│   │
│   └── services/                      # Business logic layer
│       ├── auth_service.go            #   Login, MFA, session lifecycle
│       ├── vault_service.go           #   Encrypt/decrypt, checkout, rotate (TODO)
│       └── ...
│
├── pkg/                                # Reusable libraries (importable)
│   ├── argon2/verify.go               # Argon2id PHC hash verification
│   ├── jwt/issuer.go                  # PAM JWT issuer + verifier (HS256)
│   ├── totp/totp.go                   # TOTP generate, verify, QR codes
│   ├── crypto/aes.go                  # AES-256-GCM encrypt/decrypt
│   └── iamclient/client.go            # IAM PDP HTTP client (POST /authz/check)
│
├── migrations/                        # SQL migration files (prod)
├── configs/config.yaml               # Default config
├── deployments/                       # Docker + K8s
├── go.mod  go.sum  Makefile  .env.example
└── README.md
```

### Rules for every developer:
- **Handlers** go in `internal/api/handlers/` — one file per domain.
- **Business logic** goes in `internal/services/` — one file per domain.
- **GORM models** go in `internal/models/` — shared across all services.
- **Reusable utilities** go in `pkg/` — importable by any service.
- **Every Go file** starts with a path comment: `// pam/internal/services/vault_service.go`
- **Internal packages** (`internal/`) cannot be imported outside the module.
- **Pkg packages** (`pkg/`) are designed to be reusable.

---

## 4. Authentication System

PAM has its **own complete authentication**, separate from IAM.

### What PAM owns (auth):
- ✅ Login (username/password verification against `iam.iam_users`)
- ✅ MFA/TOTP (PAM's own secrets in `pam_mfa_devices`)
- ✅ JWT issuance (HS256, self-signed)
- ✅ Session lifecycle
- ✅ Account lockout (max 5 attempts → 30-min lock)

### What IAM owns (authz only):
- ❌ PAM does NOT use IAM's JWT for auth
- ❌ PAM does NOT use IAM's MFA
- ✅ PAM calls IAM `POST /api/v1/authz/check` for **authorization** (is this user allowed to do X?)

### Auth Flow:
```
1. POST /api/v1/auth/login {identifier, password}
   → Verify password (Argon2id) against iam.iam_users
   → If MFA active → {mfa_required: true, challenge_token}
   → If no MFA → issue PAM JWT

2. POST /api/v1/auth/mfa/verify {challenge_token, code}
   → Verify TOTP against pam_mfa_devices
   → Issue PAM JWT

3. All requests carry PAM JWT → PAMAuth middleware verifies (HS256)

4. For privileged actions → RequirePermission middleware
   → calls IAM POST /api/v1/authz/check → OPA → allow/deny

5. POST /api/v1/auth/logout → revoke session
```

### How PAM reads users from IAM's table:
```go
// internal/models/user.go
type User struct {
    UserID       string  `gorm:"column:user_id"`
    Username     string  `gorm:"column:username"`
    PasswordHash *string `gorm:"column:password_hash"`
    Status       string  `gorm:"column:status"`
    // ...
}
func (User) TableName() string { return "iam.iam_users" }  // cross-schema read
```

- PAM reads `iam.iam_users` (read-only) for authentication.
- Users are CREATED in the IAM admin dashboard, not in PAM.
- Password hashes use Argon2id PHC format — `pkg/argon2/verify.go` parses them in Go.

### Important: `mfa_enabled` column type

The `iam.iam_users` table stores `mfa_enabled` as **`boolean`** (not int).
The Go model MUST use `bool`, not `int`:
```go
MFAEnabled bool `gorm:"column:mfa_enabled"`  // ✓ correct
// MFAEnabled int  `gorm:"column:mfa_enabled"`  // ✗ will cause scan error
```

---

## 5. How IAM Is Used as PDP (Not IdP)

PAM uses IAM purely as a **Policy Decision Point** — for authorization, not authentication.

### The IAM client (`pkg/iamclient/client.go`)

```go
// Every privileged PAM action calls this:
resp, err := iamClient.CheckAuthz(iamclient.AuthzRequest{
    UserID:      "d66e0687-...",
    Action:      "pam:session:SSH",
    ResourceARN: "pam:server/prod-db-01",
})
// resp.Data.Allowed == true → proceed
// resp.Data.Allowed == false → return 403
```

### How it's wired in middleware (`internal/middleware/authz.go`):

```go
// Every protected route uses RequirePermission:
api.POST("/pam/sessions/ssh",
    middleware.PAMAuth(jwtIssuer, logger),      // 1. Verify PAM JWT
    middleware.RequireMFA(),                      // 2. Require MFA claim
    middleware.RequirePermission(iamClient,       // 3. Call IAM PDP
        "pam:session:SSH",
        func(c *gin.Context) string {
            return fmt.Sprintf("pam:server/%s", c.Param("hostname"))
        },
        logger),
    sessionHandler.StartSSH)
```

### PAM action vocabulary for OPA:

```
pam:session:SSH | RDP | Database | Kill | View | Playback
pam:vault:List | Create | Read | Checkout | Checkin | Rotate | Reveal
pam:jit:Request | Approve | Deny | Revoke
pam:breakglass:Use
pam:discovery:Run | Read
pam:audit:Read
pam:report:Generate
```

### Resources:
```
pam:server/{hostname}
pam:server/{hostname}/{account}
pam:database/{name}
pam:vault/{safe}/{entry}
pam:network/{device}
pam:*
```

---

## 6. GORM Models — Shared & PAM-Specific

### Tables PAM reads from IAM schema (read-only):
| Table | Schema | Purpose |
|-------|--------|---------|
| `iam_users` | `iam` | User identity + password hash for login |

### Tables PAM owns (in `pam` schema):
| Table | Schema | Purpose |
|-------|--------|---------|
| `pam_mfa_devices` | `pam` | PAM's own TOTP secrets (encrypted) |
| `pam_vault_entries` | `pam` | Encrypted privileged credentials (TODO) |
| `pam_sessions` | `pam` | SSH/RDP/DB session records (TODO) |
| `pam_jit_requests` | `pam` | Just-in-time access workflow (TODO) |
| `pam_audit_log` | `pam` | Immutable audit trail (TODO) |
| `pam_rotation_history` | `pam` | Password rotation log (TODO) |
| `pam_discovered_accounts` | `pam` | Discovery scan results (TODO) |

### GORM AutoMigrate:
In development mode (`PAM_SERVER_ENV=development`), PAM runs `db.AutoMigrate()` on startup to create PAM-owned tables automatically. IAM tables (`iam_users`) are NOT migrated by PAM — they're owned by IAM.

### Creating a new model:
```go
// pam/internal/models/vault.go
package models

import (
    "time"
    "github.com/google/uuid"
    "gorm.io/gorm"
)

type VaultEntry struct {
    ID              string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
    UserID          string         `gorm:"type:varchar(36);not null" json:"user_id"`
    // ... your fields ...
    CreatedAt       time.Time      `gorm:"autoCreateTime" json:"created_at"`
    UpdatedAt       time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
    DeletedAt       gorm.DeletedAt `gorm:"index" json:"-"`
}

func (VaultEntry) TableName() string { return "pam_vault_entries" }

func (v *VaultEntry) BeforeCreate(tx *gorm.DB) error {
    if v.ID == "" {
        v.ID = uuid.NewString()
    }
    return nil
}
```

Then add to AutoMigrate in `main.go`:
```go
db.AutoMigrate(&models.PAMMFA{}, &models.VaultEntry{})
```

---

## 7. Middleware System

PAM uses three layers of middleware on protected routes:

### Layer 1: PAMAuth (always)
Verifies the PAM-issued HS256 JWT from `Authorization: Bearer <token>`.
Sets context: `user_id`, `username`, `email`, `mfa_verified`, `roles`, `session_id`.

### Layer 2: RequireMFA (on sensitive endpoints)
Checks `mfa_verified == true` in the JWT claims. Use on: SSH sessions, vault reveal, break-glass.

### Layer 3: RequirePermission (on all privileged actions)
Calls IAM's `POST /api/v1/authz/check` with the user's ID + action + resource.
If denied → 403. If allowed → sets `authz_decision_id` for audit correlation.

### How to apply middleware to a new route:
```go
// In cmd/pam-api/main.go
vault := r.Group("/api/v1/pam/vault")
vault.Use(middleware.PAMAuth(jwtIssuer, logger))
{
    vault.GET("",
        middleware.RequirePermission(iamClient, "pam:vault:List",
            func(c *gin.Context) string { return "pam:*" },
            logger),
        vaultHandler.List)

    vault.POST("/:id/checkout",
        middleware.RequirePermission(iamClient, "pam:vault:Checkout",
            func(c *gin.Context) string {
                return fmt.Sprintf("pam:vault/%s", c.Param("id"))
            },
            logger),
        vaultHandler.Checkout)
}
```

---

## 8. How to Build a New Feature (step by step)

When a developer needs to build a new PAM feature (e.g., "Vault Checkout"):

### Step 1: Create the GORM model
```
pam/internal/models/vault.go
```

### Step 2: Add AutoMigrate
In `cmd/pam-api/main.go`, add your model to the `db.AutoMigrate(...)` call.

### Step 3: Create the service
```
pam/internal/services/vault_service.go
```
Business logic only. Takes `*gorm.DB` + other deps. Returns plain Go structs/errors.

### Step 4: Create the handler
```
pam/internal/api/handlers/vault_handler.go
```
Thin layer: parse request → call service → return `response.Success()` or `response.Error()`.

### Step 5: Register routes
In `cmd/pam-api/main.go`, add a route group with middleware:
```go
vault := r.Group("/api/v1/pam/vault")
vault.Use(middleware.PAMAuth(jwtIssuer, logger))
{
    vault.GET("", middleware.RequirePermission(iamClient, "pam:vault:List", ...), vaultHandler.List)
}
```

### Step 6: Add the PAM action to IAM's OPA policies
In the IAM admin dashboard, create a policy with `Action: ["pam:vault:Checkout"]` and attach it to users who should have checkout access.

### Step 7: Test in Postman
1. Login to PAM → get `access_token`
2. Call the new endpoint with `Authorization: Bearer {{token}}`
3. Verify the IAM authz/check is called (check IAM logs)

---

## 9. Common Go Errors & Fixes

### GORM scan error (type mismatch)
```
sql: Scan error on column index 6, name "mfa_enabled":
converting driver.Value type bool ("false") to a int: invalid syntax
```
**Cause:** Go struct field type doesn't match the PostgreSQL column type.
**Fix:** Change the model field to match the DB type.
```go
// DB column is boolean →
MFAEnabled bool `gorm:"column:mfa_enabled"`  // not int
```

### Config load error ("X is required")
```
FATAL config.load.fail {"error": "database.host (PAM_DATABASE_HOST) is required"}
```
**Cause:** Missing env var OR `.env` file not loaded.
**Fix:** Ensure `.env` file is in the project root. `godotenv.Load("../.env")` is called in `main.go`.

### GORM "record not found"
```
record not found
[rows:0] SELECT * FROM "pam_mfa_devices" WHERE user_id = '...'
```
**Cause:** No matching row. This is often expected (e.g., user hasn't set up MFA).
**Fix:** Handle with `errors.Is(err, gorm.ErrRecordNotFound)`:
```go
if err := db.Where(...).First(&model).Error; err != nil {
    if errors.Is(err, gorm.ErrRecordNotFound) {
        // expected — return a domain-specific error
        return nil, ErrNotFound
    }
    return nil, err  // unexpected DB error
}
```

### "declared and not used"
```
auth_service.go:323:15: declared and not used: jti
```
**Cause:** Go requires every declared variable to be used.
**Fix:** Use `_` for intentionally unused return values:
```go
accessToken, _, expiresAt, err := s.jwt.IssueAccessToken(...)  // skip jti
```

### Package import cycle
```
import cycle not allowed
```
**Cause:** Package A imports B, B imports A.
**Fix:** Move the shared code to `pkg/` or `internal/models/`.

### "cannot use X as Y type"
```
cannot use 256 (untyped int constant) as qr.Encoding value
```
**Cause:** Wrong type passed to a function argument.
**Fix:** Check the library's API docs and pass the correct type/constant.

### Undefined function/variable
```
undefined: totp.WithDigits
```
**Cause:** Used an API that doesn't exist in the imported library version.
**Fix:** Check the library's actual API (not what ChatGPT guessed). Use `go doc` to verify:
```bash
go doc github.com/pquerna/otp/totp
```

### PostgreSQL connection error
```
failed to connect to PostgreSQL: ...
```
**Cause:** Wrong DSN, network issue, or SSL mode.
**Fix:** Check `PAM_DATABASE_*` env vars. For AWS RDS: `PAM_DATABASE_SSLMODE=require`.

---

## 10. Context for LLMs (ChatGPT / Claude / Copilot)

When asking an LLM to generate PAM code, give it this context:

```
I'm building a Go (Gin) PAM application. Here's the context:

TECH STACK:
- Go 1.22 + Gin web framework
- GORM as ORM (PostgreSQL)
- Viper for config (env vars with PAM_ prefix)
- Zap for structured logging
- JWT (HS256) for PAM's own auth
- Argon2id for password verification
- AES-256-GCM for encryption

PROJECT STRUCTURE:
- cmd/pam-api/main.go — entry point + route registration
- internal/api/handlers/ — Gin HTTP handlers (parse → call service → response)
- internal/services/ — business logic (takes *gorm.DB, returns structs/errors)
- internal/models/ — GORM model structs
- internal/middleware/ — auth.go (PAMAuth), authz.go (RequirePermission)
- internal/response/ — response.Success/Error helpers
- internal/config/ — config struct loaded by Viper
- pkg/ — reusable libraries (argon2, jwt, totp, crypto, iamclient)

CONVENTIONS:
- Every file starts with a path comment: // pam/internal/services/vault_service.go
- Handlers are thin: parse request → call service → return response.Success/Error
- Services contain all business logic
- Models use GORM tags: `gorm:"column:xxx;type:varchar(36)"`
- PAM-owned tables use TableName() returning "pam_xxx"
- IAM tables (read-only) use TableName() returning "iam.iam_xxx"
- UUIDs generated in BeforeCreate hook

AUTH:
- PAM has its OWN auth (login + MFA), separate from IAM
- PAM JWT is HS256 (self-signed)
- PAM reads users from iam.iam_users (shared PostgreSQL)
- PAM calls IAM POST /api/v1/authz/check for authorization only

MIDDLEWARE CHAIN:
PAMAuth (verify JWT) → RequireMFA (optional) → RequirePermission (call IAM) → handler

IAM CLIENT:
- pkg/iamclient/client.go has CheckAuthz(req) → AuthzResponse
- Every privileged route uses middleware.RequirePermission(iamClient, action, resourceBuilder, logger)
- Fail-closed: any error = deny
```

Paste this context + your feature description into the LLM. It will generate code that follows the project's conventions.

---

## 11. Environment Variables

### Required (app crashes without these):
| Variable | Description | Example |
|----------|-------------|---------|
| `PAM_DATABASE_HOST` | PostgreSQL host | `localhost` or RDS URL |
| `PAM_DATABASE_PORT` | PostgreSQL port | `5432` |
| `PAM_DATABASE_NAME` | Database name (shared with IAM) | `iam` |
| `PAM_DATABASE_USER` | DB user | `iam_app` |
| `PAM_DATABASE_PASSWORD` | DB password | `your-password` |
| `PAM_DATABASE_SSLMODE` | SSL mode | `prefer` or `require` |
| `PAM_DATABASE_SCHEMA` | PAM schema name | `pam` |
| `PAM_JWT_SECRET_KEY` | PAM JWT signing key (HS256) | `openssl rand -hex 32` |
| `PAM_VAULT_ENCRYPTION_KEY` | AES-256 key (base64 32-byte) | `openssl rand -base64 32` |
| `PAM_IAM_BASE_URL` | IAM control center URL | `http://localhost:5000` |
| `PAM_IAM_SERVICE_TOKEN` | Token for calling IAM /authz/check | must match IAM's `IAM_SERVICE_TOKEN` |

### Optional (have defaults):
| Variable | Default | Description |
|----------|---------|-------------|
| `PAM_SERVER_PORT` | `8080` | API server port |
| `PAM_SERVER_ENV` | `development` | `development` or `production` |
| `PAM_JWT_ACCESS_TTL_MIN` | `30` | Access token lifetime |
| `PAM_JWT_REFRESH_TTL_DAYS` | `7` | Refresh token lifetime |
| `PAM_SECURITY_MAX_LOGIN_ATTEMPTS` | `5` | Max failed logins before lock |
| `PAM_SECURITY_LOCKOUT_MINUTES` | `30` | Lock duration |

### Naming convention:
`PAM_` + uppercase path with dots replaced by underscores.
So `database.host` → `PAM_DATABASE_HOST`, `jwt.secret_key` → `PAM_JWT_SECRET_KEY`.

---

## 12. Testing in Postman

### Environment setup:
| Variable | Value |
|----------|-------|
| `base_url` | `http://localhost:8080` |
| `token` | *(set by login)* |

### Test sequence:
1. `GET /health` → verify PAM is running
2. `POST /api/v1/auth/login` → get `access_token` → set as `token`
3. `GET /api/v1/auth/me` → verify identity
4. `POST /api/v1/auth/mfa/setup/initiate` → enroll TOTP
5. `POST /api/v1/auth/mfa/setup/verify` → activate MFA
6. `POST /api/v1/auth/login` → now requires MFA
7. `POST /api/v1/auth/mfa/verify` → complete MFA → get new token
8. `POST /api/v1/auth/logout` → revoke

See `docs/PAM_AUTH_POSTMAN_GUIDE.md` for the full step-by-step with request/response examples.

---

## 13. Tech Stack & Libraries

| Library | Import path | Purpose |
|---------|-------------|---------|
| Gin | `github.com/gin-gonic/gin` | HTTP framework |
| GORM | `gorm.io/gorm` + `gorm.io/driver/postgres` | ORM + PostgreSQL driver |
| Viper | `github.com/spf13/viper` | Config (env vars + YAML) |
| Zap | `go.uber.org/zap` | Structured logging |
| godotenv | `github.com/joho/godotenv` | `.env` file loader |
| golang-jwt | `github.com/golang-jwt/jwt/v5` | JWT creation + verification (HS256) |
| pquerna/otp | `github.com/pquerna/otp` | TOTP generation + verification |
| boombuler/barcode | `github.com/boombuler/barcode` | QR code generation |
| golang.org/x/crypto | `golang.org/x/crypto/argon2` | Argon2id hash verification |
| UUID | `github.com/google/uuid` | UUID generation |

### Adding a new dependency:
```bash
go get github.com/some/library
go mod tidy
```

---

## Quick Reference: Developer Checklist

When starting work on a new feature:

- [ ] Read this README fully
- [ ] Understand the auth flow (PAM owns auth, IAM owns authz)
- [ ] Check `internal/models/` for existing models
- [ ] Create your model → service → handler → route
- [ ] Add the PAM action to IAM's OPA policies (e.g., `pam:vault:Checkout`)
- [ ] Test the full chain: login → get token → call endpoint → verify authz/check
- [ ] Add a path comment to every Go file: `// pam/internal/...`
- [ ] Run `go mod tidy` before committing
