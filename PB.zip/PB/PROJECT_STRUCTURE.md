# PAM Project — Complete Folder Structure

Every Go source file in this project includes a comment at the very top
with its **exact file path** (e.g. `// pam/internal/config/config.go`).
When generating new files, always add that comment.

```
pam/
│
├── cmd/                                    # Entry points (binaries)
│   └── pam-api/
│       └── main.go                         # PAM REST API + WebSocket server (Gin)
│
├── internal/                               # Private application code (not importable)
│   │
│   ├── api/                                # HTTP layer (Gin handlers)
│   │   └── handlers/
│   │       ├── auth_handler.go             # Login, MFA, logout, /me
│   │       ├── vault_handler.go            # Vault CRUD, checkout, reveal, rotate
│   │       ├── session_handler.go          # SSH/RDP/DB session start, kill, list
│   │       ├── jit_handler.go              # JIT request, approve, deny, revoke
│   │       ├── discovery_handler.go        # Network scan, results, classify
│   │       ├── audit_handler.go            # Searchable audit log, compliance reports
│   │       └── admin_handler.go            # Admin endpoints (called by IAM dashboard)
│   │
│   ├── config/
│   │   └── config.go                       # Viper config (env vars + YAML)
│   │
│   ├── database/
│   │   └── postgres.go                     # GORM connection + pool + schema init
│   │
│   ├── middleware/                         # Gin middleware
│   │   ├── auth.go                         # PAMAuth (verify PAM HS256 JWT), RequireMFA
│   │   ├── authz.go                        # RequirePermission (calls IAM /authz/check)
│   │   ├── audit.go                        # AuditMiddleware (logs every request)
│   │   └── cors.go                         # CORS configuration
│   │
│   ├── models/                             # GORM models (table mappings)
│   │   ├── user.go                         # Maps to iam.iam_users (read-only)
│   │   ├── pam_mfa.go                      # pam_mfa_devices (PAM's own TOTP)
│   │   ├── vault.go                        # pam_vault_entries (encrypted creds)
│   │   ├── session.go                      # pam_sessions (SSH/RDP/DB session records)
│   │   ├── jit_request.go                  # pam_jit_requests
│   │   ├── audit_log.go                    # pam_audit_log (immutable)
│   │   ├── rotation.go                     # pam_rotation_history
│   │   └── discovery.go                    # pam_discovered_accounts
│   │
│   ├── response/
│   │   └── response.go                     # Standardized JSON envelopes
│   │
│   └── services/                           # Business logic layer
│       ├── auth_service.go                 # Login, MFA verify, MFA setup, logout
│       ├── vault_service.go                # Encrypt, decrypt, checkout, rotate
│       ├── session_service.go              # SSH/RDP/DB session lifecycle
│       ├── jit_service.go                  # JIT request workflow
│       ├── rotation_service.go             # Password rotation engine
│       ├── discovery_service.go            # Network scanner + classifier
│       └── audit_service.go                # Immutable audit write + search
│
├── pkg/                                    # Shared libraries (importable, reusable)
│   │
│   ├── argon2/
│   │   └── verify.go                       # Argon2id PHC hash verification
│   │
│   ├── jwt/
│   │   └── issuer.go                       # PAM JWT issuer + verifier (HS256)
│   │
│   ├── totp/
│   │   └── totp.go                         # TOTP generate, verify, QR, backup codes
│   │
│   ├── crypto/
│   │   └── aes.go                          # AES-256-GCM encrypt/decrypt
│   │
│   ├── iamclient/
│   │   └── client.go                       # IAM PDP client (POST /authz/check)
│   │
│   ├── sshproxy/
│   │   ├── proxy.go                        # SSH proxy (user → PAM → target)
│   │   ├── recording.go                    # asciinema cast recording
│   │   └── keystroke.go                    # Keystroke logger (searchable text)
│   │
│   ├── rdpproxy/
│   │   └── guacamole.go                    # Guacamole integration wrapper (RDP)
│   │
│   ├── recording/
│   │   └── storage.go                      # S3/MinIO upload/download for recordings
│   │
│   └── passwordgen/
│       └── generator.go                    # Password generation with policy rules
│
├── migrations/                             # SQL migration files (prod)
│   ├── 001_create_schema.sql
│   ├── 002_create_mfa_tables.sql
│   ├── 003_create_vault_tables.sql
│   ├── 004_create_session_tables.sql
│   ├── 005_create_jit_tables.sql
│   └── 006_create_audit_tables.sql
│
├── configs/
│   └── config.yaml                         # Default config (overridden by env vars)
│
├── deployments/
│   ├── docker-compose.yml                  # Dev: PAM + PostgreSQL + Redis + MinIO
│   ├── Dockerfile                          # PAM API container
│   └── k8s/                                # Kubernetes manifests (production)
│       ├── deployment.yaml
│       ├── service.yaml
│       ├── configmap.yaml
│       └── ingress.yaml
│
├── scripts/
│   ├── generate_jwt_key.sh                 # Generate PAM_JWT_SECRET_KEY
│   ├── generate_vault_key.sh              # Generate PAM_VAULT_ENCRYPTION_KEY
│   └── seed_test_user.sql                 # Insert test user into iam_users
│
├── docs/
│   ├── PAM_ARCHITECTURE.md                # Full architecture document
│   ├── PAM_PROJECT_PLAN.md                # Team division + sprint plan
│   ├── API_REFERENCE.md                   # OpenAPI/Swagger reference
│   └── DEPLOYMENT.md                      # Production deployment guide
│
├── go.mod
├── go.sum
├── Makefile
├── .env.example
├── .gitignore
└── README.md
```

## File Path Comment Convention

Every Go source file MUST start with a comment showing its path:

```go
// pam/internal/config/config.go
package config

import ...
```

## Key Directories Explained

| Directory | Who owns it | Purpose |
|-----------|-------------|---------|
| `cmd/pam-api/` | Dev 5 | Single binary entry point |
| `internal/api/handlers/` | Dev 1-4 | Gin route handlers (one file per domain) |
| `internal/services/` | Dev 1-4 | Business logic (one file per domain) |
| `internal/models/` | Dev 5 (shared) | GORM model structs — everyone imports these |
| `internal/middleware/` | Dev 3 | Auth + authz middleware |
| `internal/config/` | Dev 5 | Config loading |
| `internal/database/` | Dev 5 | DB connection |
| `pkg/argon2/` | Dev 3 | Argon2id password verification |
| `pkg/jwt/` | Dev 3 | PAM JWT issuer/verifier |
| `pkg/totp/` | Dev 3 | TOTP MFA engine |
| `pkg/crypto/` | Dev 2 | AES-256-GCM encryption |
| `pkg/iamclient/` | Dev 3 | IAM PDP HTTP client |
| `pkg/sshproxy/` | Dev 1 | SSH proxy + recording |
| `pkg/rdpproxy/` | Dev 1 | RDP proxy (Guacamole) |
| `pkg/recording/` | Dev 1 | S3 storage for recordings |
| `pkg/passwordgen/` | Dev 2 | Password generator with policy |
| `migrations/` | Dev 5 | SQL migrations (run in prod) |
| `deployments/` | Dev 5 | Docker + K8s |
| `docs/` | All | Architecture, API docs, deployment guides |
