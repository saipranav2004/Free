package iamclient

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/yourorg/pam/internal/config"
	"go.uber.org/zap"
)

// Client is the HTTP client that talks to the IAM control center (PDP).
// Every privileged action in PAM must call CheckAuthz() before executing.
type Client struct {
	httpClient    *http.Client
	baseURL       string
	authzCheckURL string
	serviceToken  string
	logger        *zap.Logger
}

// AuthzRequest is the payload sent to IAM POST /api/v1/authz/check.
type AuthzRequest struct {
	UserID      string `json:"user_id"`
	Action      string `json:"action"`
	ResourceARN string `json:"resource_arn"`
}

// AuthzResponse is what IAM returns.
type AuthzResponse struct {
	Success bool `json:"success"`
	Data    struct {
		Allowed    bool   `json:"allowed"`
		Reason     string `json:"reason"`
		DecisionID string `json:"decision_id"`
	} `json:"data"`
	Message string `json:"message"`
}

// New creates an IAM client.
func New(cfg config.IAMConfig, log *zap.Logger) *Client {
	return &Client{
		httpClient: &http.Client{
			Timeout: time.Duration(cfg.TimeoutSec) * time.Second,
		},
		baseURL:       cfg.BaseURL,
		authzCheckURL: cfg.AuthzCheckURL,
		serviceToken:  cfg.ServiceToken,
		logger:        log,
	}
}

// CheckAuthz calls IAM's POST /api/v1/authz/check and returns the decision.
// This is the ONLY method that talks to IAM's PDP. All PAM middleware/routes
// use this to gate every privileged action.
//
// Fail-closed: any error (network, parse, non-200) returns allowed=false.
func (c *Client) CheckAuthz(req AuthzRequest) (*AuthzResponse, error) {
	body, err := json.Marshal(req)
	if err != nil {
		c.logger.Error("iam.authz.marshal.fail", zap.Error(err))
		return denyResponse("marshal_error"), err
	}

	url := c.baseURL + c.authzCheckURL
	httpReq, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		c.logger.Error("iam.authz.request.build.fail", zap.Error(err))
		return denyResponse("request_build_error"), err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("X-IAM-Service-Token", c.serviceToken)

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		c.logger.Error("iam.authz.http.fail",
			zap.String("action", req.Action),
			zap.String("resource", req.ResourceARN),
			zap.Error(err),
		)
		return denyResponse("iam_unreachable"), err
	}
	defer resp.Body.Close()

	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		c.logger.Error("iam.authz.read.fail", zap.Error(err))
		return denyResponse("read_error"), err
	}

	var authzResp AuthzResponse
	if err := json.Unmarshal(raw, &authzResp); err != nil {
		c.logger.Error("iam.authz.parse.fail", zap.Error(err), zap.ByteString("body", raw))
		return denyResponse("parse_error"), err
	}

	if resp.StatusCode != http.StatusOK {
		c.logger.Warn("iam.authz.non_200",
			zap.Int("status", resp.StatusCode),
			zap.String("action", req.Action),
		)
		return denyResponse(fmt.Sprintf("iam_http_%d", resp.StatusCode)), nil
	}

	c.logger.Info("iam.authz.decision",
		zap.String("user", req.UserID),
		zap.String("action", req.Action),
		zap.String("resource", req.ResourceARN),
		zap.Bool("allowed", authzResp.Data.Allowed),
		zap.String("reason", authzResp.Data.Reason),
		zap.String("decision_id", authzResp.Data.DecisionID),
	)

	return &authzResp, nil
}

// denyResponse constructs a fail-closed AuthzResponse.
func denyResponse(reason string) *AuthzResponse {
	return &AuthzResponse{
		Success: false,
		Data: struct {
			Allowed    bool   `json:"allowed"`
			Reason     string `json:"reason"`
			DecisionID string `json:"decision_id"`
		}{
			Allowed: false,
			Reason:  reason,
		},
	}
}
