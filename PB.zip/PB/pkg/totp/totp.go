// pam/pkg/totp/totp.go
package totp

import (
	"crypto/rand"
	"encoding/base32"
	"encoding/base64"
	"fmt"
	"time"

	"github.com/boombuler/barcode/qr"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
)

const (
	issuer = "PAM"
)

// GenerateSecret creates a new random TOTP secret (base32, 20 bytes).
func GenerateSecret() (string, error) {
	key := make([]byte, 20)
	if _, err := rand.Read(key); err != nil {
		return "", fmt.Errorf("failed to generate TOTP secret: %w", err)
	}
	return base32.StdEncoding.EncodeToString(key), nil
}

// ProvisioningURI builds the otpauth:// URI for QR code generation.
func ProvisioningURI(secret, accountName string) string {
	return fmt.Sprintf(
		"otpauth://totp/%s:%s?secret=%s&issuer=%s&algorithm=SHA1&digits=6&period=30",
		issuer, accountName, secret, issuer,
	)
}

// Validate checks a 6-digit TOTP code against the secret.
// Allows ±1 period (30s skew) to tolerate clock drift.
func Validate(secret, code string) bool {
	if len(code) != 6 {
		return false
	}
	valid, err := totp.ValidateCustom(code, secret, time.Now(), totp.ValidateOpts{
		Digits:    otp.DigitsSix,
		Period:    30,
		Skew:      1, // ±1 period
		Algorithm: otp.AlgorithmSHA1,
	})
	if err != nil {
		return false
	}
	return valid
}

// GenerateCode produces the current TOTP code for a secret (for testing).
func GenerateCode(secret string) (string, error) {
	return totp.GenerateCodeCustom(secret, time.Now(), totp.ValidateOpts{
		Digits:    otp.DigitsSix,
		Period:    30,
		Algorithm: otp.AlgorithmSHA1,
	})
}

// GenerateBackupCodes produces 10 one-time backup codes.
func GenerateBackupCodes() ([]string, error) {
	codes := make([]string, 10)
	for i := range codes {
		b := make([]byte, 5)
		if _, err := rand.Read(b); err != nil {
			return nil, err
		}
		codes[i] = fmt.Sprintf("%x", b) // 10-char hex
	}
	return codes, nil
}

// GenerateQRCodeBase64 encodes the provisioning URI as a base64 PNG string
// that can be embedded directly as <img src="data:image/png;base64,...">.
func GenerateQRCodeBase64(provisioningURI string) (string, error) {
	code, err := qr.Encode(provisioningURI, qr.M, qr.Auto)
	if err != nil {
		return "", fmt.Errorf("failed to encode QR: %w", err)
	}

	pngData, err := pngEncode(code)
	if err != nil {
		return "", fmt.Errorf("failed to render QR PNG: %w", err)
	}

	return "data:image/png;base64," + base64.StdEncoding.EncodeToString(pngData), nil
}
