package models

import "time"

// User maps to iam.iam_users — PAM reads this (read-only) for authentication.
// Users are CREATED in the IAM admin dashboard; PAM never creates users.
// PAM verifies passwords (Argon2id) and has its own TOTP MFA on top.
type User struct {
	UserID              string     `gorm:"primaryKey;column:user_id;type:varchar(36)" json:"user_id"`
	Username            string     `gorm:"column:username;type:varchar(150)" json:"username"`
	Email               string     `gorm:"column:email;type:varchar(255)" json:"email"`
	PasswordHash        *string    `gorm:"column:password_hash;type:varchar(512)" json:"-"`
	UserType            string     `gorm:"column:user_type;type:varchar(20)" json:"user_type"`
	AccountType         *string    `gorm:"column:account_type;type:varchar(50)" json:"account_type"`
	Status              string     `gorm:"column:status;type:varchar(30)" json:"status"`
	MFAEnabled          bool       `gorm:"column:mfa_enabled" json:"mfa_enabled"`
	FailedLoginAttempts int        `gorm:"column:failed_login_attempts" json:"failed_login_attempts"`
	LockedUntil         *time.Time `gorm:"column:locked_until" json:"locked_until,omitempty"`
	LastLoginAt         *time.Time `gorm:"column:last_login_at" json:"last_login_at,omitempty"`
	LastLoginIP         *string    `gorm:"column:last_login_ip;type:varchar(45)" json:"last_login_ip,omitempty"`
	AccountID           *string    `gorm:"column:account_id;type:varchar(20)" json:"account_id,omitempty"`
	CreatedAt           time.Time  `gorm:"column:created_at" json:"created_at"`
	UpdatedAt           time.Time  `gorm:"column:updated_at" json:"updated_at"`
}

// TableName explicitly sets the IAM users table (cross-schema read).
func (User) TableName() string { return "iam.iam_users" }
