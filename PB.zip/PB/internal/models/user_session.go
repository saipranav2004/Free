package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// PAMUserSession tracks the user's PAM login session (separate from IAM's JWT
// sessions). When a user opens the PAM app and their IAM JWT is verified,
// a PAMUserSession row is created to track their PAM-specific activity.
type PAMUserSession struct {
	ID           string         `gorm:"primaryKey;type:varchar(36)" json:"id"`
	UserID       string         `gorm:"type:varchar(36);not null;index" json:"user_id"`
	Username     string         `gorm:"type:varchar(150)" json:"username"`
	Email        string         `gorm:"type:varchar(255)" json:"email"`
	IAMJTI       string         `gorm:"type:varchar(36);index" json:"iam_jti"`     // IAM JWT's JTI
	IAMTokenHash string         `gorm:"type:varchar(64)" json:"-"`                  // SHA-256 of the raw JWT
	SourceIP     string         `gorm:"type:varchar(45)" json:"source_ip"`
	UserAgent    string         `gorm:"type:varchar(512)" json:"user_agent"`
	Status       string         `gorm:"type:varchar(20);default:'ACTIVE';index" json:"status"` // ACTIVE | REVOKED | EXPIRED
	StartedAt    time.Time      `gorm:"autoCreateTime" json:"started_at"`
	EndedAt      *time.Time     `json:"ended_at,omitempty"`
	CreatedAt    time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt    time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"-"`
}

// TableName overrides the default table name.
func (PAMUserSession) TableName() string { return "pam_user_sessions" }

// BeforeCreate generates a UUID if not set.
func (s *PAMUserSession) BeforeCreate(tx *gorm.DB) error {
	if s.ID == "" {
		s.ID = uuid.NewString()
	}
	return nil
}
