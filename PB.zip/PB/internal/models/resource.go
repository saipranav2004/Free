// pam/internal/models/resource.go
package models

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// PAMResource is a target system that PAM can manage or connect to.
// Examples: PostgreSQL, MongoDB, Redis, MinIO, web application, etc.
type PAMResource struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	Name         string `gorm:"type:varchar(255);not null;index" json:"name"`
	Description  string `gorm:"type:text" json:"description"`
	ResourceType string `gorm:"type:varchar(50);not null;index" json:"resource_type"`

	Host         string `gorm:"type:varchar(255);not null" json:"host"`
	Port         int    `gorm:"not null" json:"port"`
	DatabaseName string `gorm:"type:varchar(255)" json:"database_name,omitempty"`

	// web_terminal or embed_redirect
	ConnectMode string `gorm:"type:varchar(50);default:'web_terminal'" json:"connect_mode"`

	// Optional external console URL, for example a MinIO or Metabase console.
	ConsoleURL string `gorm:"type:text" json:"console_url,omitempty"`

	// JSON stored as text, containing protocol-specific configuration.
	ExtraConfig string `gorm:"type:text" json:"extra_config,omitempty"`

	// Points to the currently active encrypted vault credential.
	VaultEntryID *string `gorm:"type:varchar(36);index" json:"vault_entry_id,omitempty"`

	IsActive  bool   `gorm:"default:true;index" json:"is_active"`
	CreatedBy string `gorm:"type:varchar(36);not null;index" json:"created_by"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (PAMResource) TableName() string {
	return "pam_resources"
}

func (r *PAMResource) BeforeCreate(tx *gorm.DB) error {
	if r.ID == "" {
		r.ID = uuid.NewString()
	}
	return nil
}

// ResourceGroup is a response-only structure used to group resources
// by their ResourceType in the PAM UI. It is not a database table.
type ResourceGroup struct {
	Name      string        `json:"name"`
	Icon      string        `json:"icon"`
	Resources []PAMResource `json:"resources"`
}

// VaultEntry stores an AES-256-GCM encrypted privileged credential.
// CredentialEnc must never be returned in an API response.
type VaultEntry struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	ResourceID string `gorm:"type:varchar(36);not null;index" json:"resource_id"`

	AccountName    string `gorm:"type:varchar(255);not null" json:"account_name"`
	CredentialType string `gorm:"type:varchar(50);not null;default:'password'" json:"credential_type"`

	// AES-256-GCM encrypted credential. Never expose through JSON.
	CredentialEnc string `gorm:"type:text;not null" json:"-"`

	LastRotatedAt *time.Time     `json:"last_rotated_at,omitempty"`
	CreatedAt     time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt     time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"-"`
}

func (VaultEntry) TableName() string {
	return "pam_vault_entries"
}

func (v *VaultEntry) BeforeCreate(tx *gorm.DB) error {
	if v.ID == "" {
		v.ID = uuid.NewString()
	}
	return nil
}

// ConnectionSession stores PAM connection-session metadata.
// It does not itself create SSH/RDP/database connections.
type ConnectionSession struct {
	ID string `gorm:"primaryKey;type:varchar(36)" json:"id"`

	UserID   string `gorm:"type:varchar(36);not null;index" json:"user_id"`
	Username string `gorm:"type:varchar(150);not null" json:"username"`

	ResourceID   string `gorm:"type:varchar(36);not null;index" json:"resource_id"`
	ResourceName string `gorm:"type:varchar(255);not null" json:"resource_name"`
	ResourceType string `gorm:"type:varchar(50);not null;index" json:"resource_type"`

	Protocol string `gorm:"type:varchar(50)" json:"protocol"`
	SourceIP string `gorm:"type:varchar(45)" json:"source_ip"`

	// ACTIVE | COMPLETED | KILLED | FAILED
	Status string `gorm:"type:varchar(20);not null;default:'ACTIVE';index" json:"status"`

	StartedAt       time.Time  `gorm:"autoCreateTime;index" json:"started_at"`
	EndedAt         *time.Time `json:"ended_at,omitempty"`
	DurationSeconds int        `gorm:"default:0" json:"duration_seconds"`

	KillReason      string  `gorm:"type:text" json:"kill_reason,omitempty"`
	KilledBy        string  `gorm:"type:varchar(36)" json:"killed_by,omitempty"`
	AuthzDecisionID *string `gorm:"type:varchar(255);index" json:"authz_decision_id,omitempty"`
	AuthzAllowed    *bool   `json:"authz_allowed,omitempty"`

	CreatedAt time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (ConnectionSession) TableName() string {
	return "pam_connection_sessions"
}

func (s *ConnectionSession) BeforeCreate(tx *gorm.DB) error {
	if s.ID == "" {
		s.ID = uuid.NewString()
	}
	return nil
}
