package config

import (
	"fmt"
	"strings"

	"github.com/spf13/viper"
)

// Config holds all configuration for the PAM application.
type Config struct {
	Server   ServerConfig   `mapstructure:"server"`
	Database DatabaseConfig `mapstructure:"database"`
	Redis    RedisConfig    `mapstructure:"redis"`
	S3       S3Config       `mapstructure:"s3"`
	IAM      IAMConfig      `mapstructure:"iam"`
	JWT      JWTConfig      `mapstructure:"jwt"`
	Vault    VaultConfig    `mapstructure:"vault"`
	Security SecurityConfig `mapstructure:"security"`
}

type ServerConfig struct {
	Port            string `mapstructure:"port"`
	Env             string `mapstructure:"env"` // "development" | "production"
	AllowedOrigins  string `mapstructure:"allowed_origins"`
	ShutdownTimeout int    `mapstructure:"shutdown_timeout"` // seconds
}

type DatabaseConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Name     string `mapstructure:"name"`
	User     string `mapstructure:"user"`
	Password string `mapstructure:"password"`
	SSLMode  string `mapstructure:"sslmode"`
	Schema   string `mapstructure:"schema"` // "pam"
}

func (d DatabaseConfig) DSN() string {
	return fmt.Sprintf(
		"host=%s port=%d user=%s password=%s dbname=%s sslmode=%s search_path=%s",
		d.Host, d.Port, d.User, d.Password, d.Name, d.SSLMode, d.Schema,
	)
}

type RedisConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Password string `mapstructure:"password"`
	DB       int    `mapstructure:"db"`
}

type S3Config struct {
	Endpoint  string `mapstructure:"endpoint"`
	Bucket    string `mapstructure:"bucket"`
	AccessKey string `mapstructure:"access_key"`
	SecretKey string `mapstructure:"secret_key"`
	Region    string `mapstructure:"region"`
	UseSSL    bool   `mapstructure:"use_ssl"`
}

// IAMConfig — connection details for the IAM control center (PDP).
type IAMConfig struct {
	BaseURL       string `mapstructure:"base_url"`        // e.g. http://iam-host:5000
	ServiceToken  string `mapstructure:"service_token"`   // X-IAM-Service-Token for /authz/check
	AuthzCheckURL string `mapstructure:"authz_check_url"` // /api/v1/authz/check
	JWKsURL       string `mapstructure:"jwks_url"`        // /.well-known/jwks.json
	TimeoutSec    int    `mapstructure:"timeout_sec"`
}

// JWTConfig — PAM's own HS256 JWT (separate from IAM's RS256).
type JWTConfig struct {
	SecretKey      string `mapstructure:"secret_key"`       // PAM-only signing secret
	AccessTTLMin   int    `mapstructure:"access_ttl_min"`   // access token lifetime (default 30)
	RefreshTTLDays int    `mapstructure:"refresh_ttl_days"` // refresh token lifetime (default 7)
}

// VaultConfig — AES-256-GCM master key management.
type VaultConfig struct {
	EncryptionKey string `mapstructure:"encryption_key"` // base64-encoded 32-byte key
}

// SecurityConfig — login security policies.
type SecurityConfig struct {
	MaxLoginAttempts int `mapstructure:"max_login_attempts"` // default 5
	LockoutMinutes   int `mapstructure:"lockout_minutes"`    // default 30
}

// Load reads configuration from environment variables (viper auto-bind).
func Load() (*Config, error) {
	v := viper.New()

	// ── Defaults (MUST register every key so AutomaticEnv can find its env var) ──
	// Viper's AutomaticEnv only binds env vars for keys that have a SetDefault.
	// Without this, keys like database.host are invisible even if the env var exists.
	v.SetDefault("server.port", "8080")
	v.SetDefault("server.env", "development")
	v.SetDefault("server.allowed_origins", "*")
	v.SetDefault("server.shutdown_timeout", 30)

	v.SetDefault("database.host", "")
	v.SetDefault("database.port", 5432)
	v.SetDefault("database.name", "")
	v.SetDefault("database.user", "")
	v.SetDefault("database.password", "")
	v.SetDefault("database.sslmode", "prefer")
	v.SetDefault("database.schema", "pam")

	v.SetDefault("redis.host", "localhost")
	v.SetDefault("redis.port", 6379)
	v.SetDefault("redis.password", "")
	v.SetDefault("redis.db", 1)

	v.SetDefault("s3.endpoint", "localhost:9000")
	v.SetDefault("s3.bucket", "pam-recordings")
	v.SetDefault("s3.access_key", "")
	v.SetDefault("s3.secret_key", "")
	v.SetDefault("s3.region", "us-east-1")
	v.SetDefault("s3.use_ssl", false)

	v.SetDefault("iam.base_url", "")
	v.SetDefault("iam.service_token", "")
	v.SetDefault("iam.authz_check_url", "/api/v1/authz/check")
	v.SetDefault("iam.timeout_sec", 5)

	v.SetDefault("jwt.secret_key", "")
	v.SetDefault("jwt.access_ttl_min", 30)
	v.SetDefault("jwt.refresh_ttl_days", 7)

	v.SetDefault("vault.encryption_key", "")

	v.SetDefault("security.max_login_attempts", 5)
	v.SetDefault("security.lockout_minutes", 30)

	// ── Environment variable binding (PAM_SERVER_PORT, PAM_DB_HOST, etc.) ──
	v.SetEnvPrefix("PAM")
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	v.AutomaticEnv()

	// ── Optional config file ──
	v.SetConfigName("config")
	v.SetConfigType("yaml")
	v.AddConfigPath(".")
	v.AddConfigPath("./configs")
	v.AddConfigPath("/etc/pam")
	if err := v.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("config file error: %w", err)
		}
		// No config file is fine — we use env vars.
	}

	var cfg Config
	if err := v.Unmarshal(&cfg); err != nil {
		return nil, fmt.Errorf("failed to unmarshal config: %w", err)
	}

	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (c *Config) validate() error {
	if c.Database.Host == "" {
		return fmt.Errorf("database.host (PAM_DATABASE_HOST) is required")
	}
	if c.Database.Name == "" {
		return fmt.Errorf("database.name (PAM_DATABASE_NAME) is required")
	}
	if c.IAM.BaseURL == "" {
		return fmt.Errorf("iam.base_url (PAM_IAM_BASE_URL) is required")
	}
	if c.IAM.ServiceToken == "" {
		return fmt.Errorf("iam.service_token (PAM_IAM_SERVICE_TOKEN) is required")
	}
	if c.JWT.SecretKey == "" {
		return fmt.Errorf("jwt.secret_key (PAM_JWT_SECRET_KEY) is required")
	}
	if c.Vault.EncryptionKey == "" {
		return fmt.Errorf("vault.encryption_key (PAM_VAULT_ENCRYPTION_KEY) is required")
	}
	return nil
}

func (c *Config) IsProduction() bool {
	return c.Server.Env == "production"
}
