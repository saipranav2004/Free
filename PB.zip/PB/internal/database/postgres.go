package database

import (
	"fmt"
	"time"

	"github.com/yourorg/pam/internal/config"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var DB *gorm.DB

// Connect establishes the PostgreSQL connection pool and returns the GORM DB.
func Connect(cfg config.DatabaseConfig) (*gorm.DB, error) {
	gormLogLevel := logger.Info
	if cfg.SSLMode == "require" {
		gormLogLevel = logger.Warn // quieter in prod-like
	}

	db, err := gorm.Open(postgres.Open(cfg.DSN()), &gorm.Config{
		Logger:      logger.Default.LogMode(gormLogLevel),
		PrepareStmt: true,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to connect to PostgreSQL: %w", err)
	}

	sqlDB, err := db.DB()
	if err != nil {
		return nil, fmt.Errorf("failed to get underlying *sql.DB: %w", err)
	}

	sqlDB.SetMaxOpenConns(20)
	sqlDB.SetMaxIdleConns(5)
	sqlDB.SetConnMaxLifetime(time.Hour)

	// Ensure the pam schema exists.
	if err := db.Exec(fmt.Sprintf("CREATE SCHEMA IF NOT EXISTS %s", cfg.Schema)).Error; err != nil {
		return nil, fmt.Errorf("failed to create schema %s: %w", cfg.Schema, err)
	}

	DB = db
	return db, nil
}
