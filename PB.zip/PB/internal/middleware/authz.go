// pam/internal/middleware/authz.go
//
// RequirePermission is the PEP (Policy Enforcement Point) middleware.
// It calls IAM's POST /api/v1/authz/check for every privileged PAM action.
// If IAM says deny → 403. If IAM is unreachable → 403 (fail-closed).
//
// Usage:
//
//	vault.GET("",
//	    middleware.RequirePermission(iamClient, "pam:vault:List",
//	        func(c *gin.Context) string { return "pam:*" }, logger),
//	    vaultHandler.List)
package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/pam/pkg/iamclient"
	"go.uber.org/zap"
)

// RequirePermission calls IAM's authz/check endpoint with the given action
// and a resource ARN built from the request context. If denied or any error,
// the request is aborted with 403 (fail-closed).
//
// Parameters:
//   - client:     the IAM PDP HTTP client (*iamclient.Client)
//   - action:     the PAM action string, e.g. "pam:resource:Connect"
//   - resourceBuilder: a function that returns the resource ARN from the Gin context
//     (e.g. func(c) string { return "pam:postgresql/" + c.Param("id") })
//   - log:        zap logger
func RequirePermission(client *iamclient.Client, action string,
	resourceBuilder func(*gin.Context) string, log *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Get user_id from context (set by PAMAuth middleware).
		userIDRaw, exists := c.Get("user_id")
		if !exists {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"success": false,
				"error":   "Authentication required before authorization check",
			})
			return
		}
		userID := userIDRaw.(string)

		// Build the resource ARN from the request context.
		resourceARN := resourceBuilder(c)

		// Call IAM PDP: POST /api/v1/authz/check
		resp, err := client.CheckAuthz(iamclient.AuthzRequest{
			UserID:      userID,
			Action:      action,
			ResourceARN: resourceARN,
		})

		if err != nil {
			log.Warn("authz.check.error",
				zap.String("user_id", userID),
				zap.String("action", action),
				zap.String("resource", resourceARN),
				zap.Error(err),
			)
		}

		// Fail-closed: deny if no response, error, or explicit deny.
		if resp == nil || !resp.Data.Allowed {
			reason := "permission_denied"
			if resp != nil && resp.Data.Reason != "" {
				reason = resp.Data.Reason
			}
			log.Warn("authz.denied",
				zap.String("user_id", userID),
				zap.String("action", action),
				zap.String("resource", resourceARN),
				zap.String("reason", reason),
			)
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"success": false,
				"error":   "Permission denied",
				"reason":  reason,
				"action":  action,
			})
			return
		}

		// Allowed — store the decision ID for audit correlation.
		c.Set("authz_decision_id", resp.Data.DecisionID)
		c.Set("authz_action", action)
		c.Set("authz_resource", resourceARN)

		log.Info("authz.allowed",
			zap.String("user_id", userID),
			zap.String("action", action),
			zap.String("resource", resourceARN),
			zap.String("decision_id", resp.Data.DecisionID),
		)

		c.Next()
	}
}
