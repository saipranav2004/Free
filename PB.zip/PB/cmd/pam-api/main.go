package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/yourorg/pam/internal/api/handlers"
	"github.com/yourorg/pam/internal/config"
	"github.com/yourorg/pam/internal/database"
	"github.com/yourorg/pam/internal/middleware"
	"github.com/yourorg/pam/internal/models"
	"github.com/yourorg/pam/internal/services"
	"github.com/yourorg/pam/pkg/iamclient"
	pamjwt "github.com/yourorg/pam/pkg/jwt"
	"go.uber.org/zap"
)

func main() {
	// ── Load .env file into OS environment (Go doesn't do this automatically) ──
	// Try: current dir → parent (project root) → ../..
	godotenv.Load()
	godotenv.Load("../.env")
	godotenv.Load("../../.env")

	// ── Logger ──
	var logger *zap.Logger
	var err error
	if os.Getenv("PAM_SERVER_ENV") == "production" {
		logger, _ = zap.NewProduction()
		gin.SetMode(gin.ReleaseMode)
	} else {
		logger, _ = zap.NewDevelopment()
	}
	defer logger.Sync()

	// ── Config ──
	cfg, err := config.Load()
	if err != nil {
		logger.Fatal("config.load.fail", zap.Error(err))
	}

	// ── Database ──
	db, err := database.Connect(cfg.Database)
	if err != nil {
		logger.Fatal("db.connect.fail", zap.Error(err))
	}

	// AutoMigrate PAM-specific tables (not iam_users — that's IAM's table).
	if !cfg.IsProduction() {
		db.AutoMigrate(
			&models.PAMMFA{},
			&models.PAMResource{},
			&models.VaultEntry{},
			&models.ConnectionSession{},
		)
		logger.Info("db.migrated.pam_tables")
	}

	// ── PAM JWT Issuer (HS256, self-signed — separate from IAM's RS256) ──
	jwtIssuer := pamjwt.New(
		cfg.JWT.SecretKey,
		"pam.yourorg.com", // PAM's own issuer
		cfg.JWT.AccessTTLMin,
		cfg.JWT.RefreshTTLDays,
	)

	// ── IAM Client (for authz/check — PDP only, NOT auth) ──
	iamClient := iamclient.New(cfg.IAM, logger)

	// ── Services ──
	authService := services.NewAuthService(
		db, jwtIssuer, cfg.Vault.EncryptionKey,
		cfg.Security.MaxLoginAttempts,
		cfg.Security.LockoutMinutes,
		logger,
	)
	resourceService := services.NewResourceService(db, cfg.Vault.EncryptionKey, logger)

	// ── Handlers ──
	authHandler := handlers.NewAuthHandler(authService, logger)
	resourceHandler := handlers.NewResourceHandler(resourceService, logger)

	// ── Gin Engine ──
	r := gin.New()
	r.Use(gin.Recovery())

	// CORS
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", cfg.Server.AllowedOrigins)
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers",
			"Origin, Content-Type, Accept, Authorization, X-IAM-Service-Token")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// ── Public health (no auth) ──
	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "PAM", "version": "1.0.0"})
	})

	// ═════════════════════════════════════════════════════════════
	//  AUTH ROUTES (PAM owns its own auth — NOT IAM JWT)
	// ═════════════════════════════════════════════════════════════

	// Public (no token required)
	pub := r.Group("/api/v1/auth")
	{
		pub.POST("/login", authHandler.Login)
		pub.POST("/mfa/verify", authHandler.MFAVerify)
	}

	// Protected (require PAM JWT)
	authed := r.Group("/api/v1/auth")
	authed.Use(middleware.PAMAuth(jwtIssuer, logger))
	{
		authed.GET("/me", authHandler.Me)
		authed.POST("/logout", authHandler.Logout)
		authed.GET("/health", authHandler.Health)

		// MFA setup (requires login first, then enroll TOTP)
		authed.POST("/mfa/setup/initiate", authHandler.MFASetupInitiate)
		authed.POST("/mfa/setup/verify", authHandler.MFASetupVerify)
	}

	// ═════════════════════════════════════════════════════════════
	//  PAM FEATURE ROUTES (require PAM JWT + IAM authz/check)
	//  Every route: PAMAuth → RequirePermission → handler
	// ═════════════════════════════════════════════════════════════
	res := r.Group("/api/v1/pam")
	res.Use(middleware.PAMAuth(jwtIssuer, logger))
	{
		// ── Resources ──
		res.GET("/resources/groups",
			middleware.RequirePermission(iamClient, "pam:resource:List",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.ListGroups)

		res.GET("/resources",
			middleware.RequirePermission(iamClient, "pam:resource:List",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.List)

		res.GET("/resources/:id",
			middleware.RequirePermission(iamClient, "pam:resource:Read",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.Get)

		res.POST("/resources",
			middleware.RequirePermission(iamClient, "pam:resource:Create",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.Create)

		res.DELETE("/resources/:id",
			middleware.RequirePermission(iamClient, "pam:resource:Delete",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.Delete)

		// ── Vault (credential management) ──
		res.POST("/resources/:id/credential",
			middleware.RequirePermission(iamClient, "pam:vault:Store",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.StoreCredential)

		res.POST("/resources/:id/rotate",
			middleware.RequirePermission(iamClient, "pam:vault:Rotate",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.RotateCredential)

		// ── Connection ──
		res.GET("/resources/:id/connect-info",
			middleware.RequirePermission(iamClient, "pam:resource:Connect",
				func(c *gin.Context) string { return fmt.Sprintf("pam:resource/%s", c.Param("id")) }, logger),
			resourceHandler.ConnectInfo)

		// ── Sessions (admin monitoring) ──
		res.GET("/sessions",
			middleware.RequirePermission(iamClient, "pam:session:List",
				func(c *gin.Context) string { return "pam:*" }, logger),
			resourceHandler.ListSessions)

		res.POST("/sessions/:id/kill",
			middleware.RequirePermission(iamClient, "pam:session:Kill",
				func(c *gin.Context) string { return fmt.Sprintf("pam:session/%s", c.Param("id")) }, logger),
			resourceHandler.KillSession)
	}

	// ── Server ──
	srv := &http.Server{
		Addr:         ":" + cfg.Server.Port,
		Handler:      r,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		logger.Info("server.start", zap.String("port", cfg.Server.Port))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Fatal("server.fail", zap.Error(err))
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("server.shutdown")

	ctx, cancel := context.WithTimeout(context.Background(),
		time.Duration(cfg.Server.ShutdownTimeout)*time.Second)
	defer cancel()
	srv.Shutdown(ctx)
	logger.Info("server.stopped")
}
