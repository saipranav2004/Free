import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, Plus, Trash2, UserX, RotateCcw, Eye, UserCog, Download, ShieldCheck, KeyRound,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';
import { writeProfileCache } from '../../utils/profileCache.js';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { AccountGate } from '../../components/common/AccountGate.jsx';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, Select, StatusBadge, SummaryBar, Toolbar, SearchInput, IconButton, InlineAlert,
  DescriptionList, FormErrorSummary,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { Pagination } from '../../components/common/Pagination.jsx';
import { formatDateTime, initials } from '../../utils/format.js';
import { IDENTITY_USER_STATUS } from '../../utils/constants.js';
import * as XLSX from 'xlsx';

/** Downloads the one-time credentials for a freshly created user. */
const downloadCredentials = (user) => {
  const data = [
    {
      Username: user.username,
      Password: user.password,
      Email: user.email,
      'First Name': user.first_name,
      'Last Name': user.last_name,
      Department: user.department,
      Title: user.title,
      'Created At': new Date().toLocaleString(),
    },
  ];
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Credentials');
  XLSX.writeFile(workbook, `${user.username}_credentials.xlsx`);
};

/**
 * First / last name validation — ALPHABETS ONLY.
 *
 * Product rule: `first_name` and `last_name` accept the letters A–Z / a–z and
 * nothing else — no digits, no punctuation, no spaces (so no double-barrelled
 * input either). Kept as one helper so the field-level check, the blur check and
 * the submit check can never disagree, and so the message an operator reads is
 * identical in all three places.
 */
const NAME_PATTERN = /^[A-Za-z]+$/;

function validateNameField(value, label) {
  const raw = String(value ?? '');
  if (!raw.trim()) return `${label} is required.`;
  if (/\s/.test(raw)) return `${label} cannot contain spaces — use letters only (A–Z).`;
  if (/[0-9]/.test(raw)) return `${label} cannot contain numbers — use letters only (A–Z).`;
  if (!NAME_PATTERN.test(raw)) {
    return `${label} can contain letters only (A–Z) — no numbers or special characters.`;
  }
  return null;
}

/**
 * UsersPage — local identity lifecycle.
 *
 * Enterprise list-page anatomy: header → summary KPIs → toolbar → table.
 * Row actions are limited to the three lifecycle verbs (inspect, enable or
 * disable, offboard); everything destructive routes through a confirmation
 * that names the blast radius.
 */
function UsersInner() {
  const { accountId } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [filters, setFilters] = useState({ status: '', search: '', page: 1, per_page: 10 });
  const [createOpen, setCreateOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState(null);
  const [offboardConfirm, setOffboardConfirm] = useState(null);
  const [offboarding, setOffboarding] = useState(false);
  const [errors, setErrors] = useState({});
  const [selectedIds, setSelectedIds] = useState([]);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [form, setForm] = useState({
    email: '',
    first_name: '',
    last_name: '',
    department: '',
    title: '',
  });

  const users = useResource(
    () =>
      identityApi.listUsers({
        account_id: accountId,
        status: filters.status || undefined,
        search: filters.search || undefined,
        page: filters.page,
        per_page: filters.per_page,
      }),
    [accountId, filters.status, filters.search, filters.page, filters.per_page]
  );

  const data = users.data?.users || [];
  const pagination = users.data?.pagination || { total: 0, page: 1, per_page: 10, total_pages: 1 };

  /* ── Tenant-wide status totals ────────────────────────────────────────────
     BUG FIX: "Active" and "Disabled" used to count the rows on the CURRENT PAGE
     (`data.filter(...)`), so page 2 of a 300-user tenant could read "Active 7".
     A directory summary has to describe the DIRECTORY.

     Each figure is now the server's own `pagination.total` for that status —
     the identical technique the Dashboard's directory panel uses, so the two
     screens can never disagree. Three deliberately tiny requests (per_page 1;
     only the total is read) that carry NO search filter, so the band always
     states the tenant, while the table below states the current query. */
  const tenantTotals = useResource(
    () =>
      accountId
        ? Promise.all([
            identityApi.listUsers({ account_id: accountId, page: 1, per_page: 1 }),
            identityApi.listUsers({ account_id: accountId, status: 'ACTIVE', page: 1, per_page: 1 }),
            identityApi.listUsers({ account_id: accountId, status: 'DISABLED', page: 1, per_page: 1 }),
          ]).then(([all, active, disabled]) => ({
            total: all?.pagination?.total ?? 0,
            active: active?.pagination?.total ?? 0,
            disabled: disabled?.pagination?.total ?? 0,
          }))
        : null,
    [accountId]
  );

  const counts = useMemo(() => {
    const t = tenantTotals.data || {};
    const total = t.total ?? 0;
    const active = t.active ?? 0;
    const disabled = t.disabled ?? 0;
    return {
      total,
      active,
      disabled,
      // Locked / pending / offboarded — whatever is neither active nor disabled.
      other: Math.max(0, total - active - disabled),
    };
  }, [tenantTotals.data]);

  const totalsLoading = tenantTotals.loading && !tenantTotals.data;

  /* Every mutation moves the directory, so the table AND the tenant totals are
     re-read together — a disable that did not move the "Disabled" figure would
     make the band lie until the next hard refresh. */
  const reloadDirectory = () => {
    users.reload();
    tenantTotals.reload();
  };

  /**
   * Client-side validation. Errors stay on the field AND in a summary at the
   * top of the dialog — a toast disappears before a long form can be fixed.
   */
  const validate = () => {
    const next = {};
    // Names: alphabets only (A–Z, a–z) — see validateNameField above.
    const firstNameError = validateNameField(form.first_name, 'First name');
    if (firstNameError) next.first_name = firstNameError;
    const lastNameError = validateNameField(form.last_name, 'Last name');
    if (lastNameError) next.last_name = lastNameError;
    if (!form.email.trim()) next.email = 'Email is required.';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) {
      next.email = 'Enter a valid email address, e.g. name@company.com.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const create = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      const res = await identityApi.createUser({ account_id: accountId, ...form });
      downloadCredentials({
        ...res,
        email: form.email,
        first_name: form.first_name,
        last_name: form.last_name,
        department: form.department,
        title: form.title,
      });
      /* The detail route does not always echo first_name / last_name back, so
         a brand-new user could open with a blank name. Remember what was
         submitted; UserDetailPage uses it only to fill blanks the API left. */
      const newUserId = res?.user_id || res?.user?.user_id;
      writeProfileCache(newUserId, {
        first_name: form.first_name,
        last_name: form.last_name,
        department: form.department,
        title: form.title,
      });

      setCreated(res);
      setCreateOpen(false);
      setErrors({});
      setForm({ email: '', first_name: '', last_name: '', department: '', title: '' });
      reloadDirectory();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create user.');
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (userId, status) => {
    try {
      if (status === 'ACTIVE') await identityApi.enableUser(userId, accountId);
      else await identityApi.disableUser(userId, accountId);
      toast.success(`User ${status.toLowerCase()}.`);
      reloadDirectory();
    } catch (err) {
      toast.error(err.userMessage || 'Action failed.');
    }
  };

  const offboard = async (userId) => {
    if (!userId) { toast.error('This row has no user id.'); return; }
    setOffboarding(true);
    try {
      // The account scope is required — without it the API cannot resolve the
      // user and answers "User not found."
      await identityApi.offboardUser(userId, 'Admin-initiated offboarding', accountId);
      toast.success('User offboarded — all access revoked.');
      setOffboardConfirm(null);
      reloadDirectory();
    } catch (err) {
      toast.error(err.userMessage || 'Offboarding failed.');
    } finally {
      setOffboarding(false);
    }
  };

  /* ── Bulk operations: existing per-user endpoints, run as one batch ── */
  const runBulk = async (label, fn) => {
    const targets = data.filter((u) => selectedIds.includes(u.user_id));
    if (!targets.length) return;
    setBulkBusy(true);
    const results = await Promise.allSettled(targets.map((u) => fn(u)));
    const failed = results.filter((r) => r.status === 'rejected').length;
    setBulkBusy(false);
    setSelectedIds([]);
    reloadDirectory();
    if (failed === 0) toast.success(`${label} ${targets.length} user${targets.length === 1 ? '' : 's'}.`);
    else if (failed === targets.length) toast.error(`Could not ${label.toLowerCase()} any of the selected users.`);
    else toast.error(`${targets.length - failed} succeeded, ${failed} failed.`);
  };

  const exportSelected = () => {
    const targets = data.filter((u) => selectedIds.includes(u.user_id));
    if (!targets.length) return;
    const rows = targets.map((u) => ({
      Username: u.username,
      Email: u.email,
      Status: u.status,
      Department: u.department || '',
      Title: u.title || '',
      'Last Login': u.last_login_at || '',
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Users');
    XLSX.writeFile(wb, `users_selection_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const exportCurrentView = () => {
    if (!data.length) return;
    const rows = data.map((u) => ({
      Username: u.username,
      Email: u.email,
      Status: u.status,
      Department: u.department || '',
      Title: u.title || '',
      'Last Login': u.last_login_at || '',
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Users');
    XLSX.writeFile(wb, `users_export_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const columns = [
    {
      id: 'username',
      header: 'User',
      primary: true,
      sortable: true,
      render: (r) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-2xs font-semibold text-brand-700">
            {initials(r.username || r.email || 'U')}
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium text-ink-900">{r.username}</p>
            <p className="truncate text-xs text-slate-500">{r.email}</p>
          </div>
        </div>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      sortable: true,
      render: (r) => <StatusBadge status={r.status} />,
    },
    {
      id: 'department',
      header: 'Department',
      sortable: true,
      render: (r) => r.department || <span className="text-slate-400">—</span>,
    },
    {
      id: 'title',
      header: 'Title',
      sortable: true,
      render: (r) => r.title || <span className="text-slate-400">—</span>,
    },
    {
      id: 'last_login_at',
      header: 'Last sign-in',
      sortable: true,
      render: (r) => (
        <span className="whitespace-nowrap text-[13px] text-slate-600">
          {formatDateTime(r.last_login_at)}
        </span>
      ),
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex justify-end gap-1">
          <IconButton
            icon={Eye}
            title="View user"
            tone="brand"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/identity/users/${r.user_id}`);
            }}
          />
          {r.status === 'ACTIVE' ? (
            <IconButton
              icon={UserX}
              title="Disable user"
              tone="warning"
              onClick={(e) => {
                e.stopPropagation();
                setStatus(r.user_id, 'DISABLED');
              }}
            />
          ) : (
            <IconButton
              icon={RotateCcw}
              title="Enable user"
              tone="success"
              onClick={(e) => {
                e.stopPropagation();
                setStatus(r.user_id, 'ACTIVE');
              }}
            />
          )}
          <IconButton
            icon={Trash2}
            title="Offboard user"
            tone="danger"
            onClick={(e) => {
              e.stopPropagation();
              setOffboardConfirm(r);
            }}
          />
        </div>
      ),
    },
  ];

  const filtersActive = !!(filters.search || filters.status);

  return (
    <div>
      <PageHeader
        title="Users"
        description="Local identity records, lifecycle state and access history for this tenant."
        icon={<UserCog className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Identity' }, { label: 'Users' }]}
        meta={
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-slate-400" />
            Tenant <span className="font-mono text-slate-600">{accountId}</span>
          </span>
        }
        actions={
          <>
            <Button variant="secondary" onClick={exportCurrentView} disabled={!data.length}>
              <Download className="h-4 w-4" /> Export
            </Button>
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="h-4 w-4" /> New user
            </Button>
          </>
        }
      />

      <div className="space-y-4">
        {/* ── Directory facets ─────────────────────────────────────────────
            The console's standard summary band (see SummaryBar in primitives):
            tenant-wide figures, and each one filters the table to the slice it
            counts — so the number is verifiable by clicking it, and the status
            dropdown below stays in step because both drive `filters.status`.

            ── "OTHER STATES" facet — TEMPORARILY COMMENTED OUT ──────────────
            Hidden at the product owner's request; `counts.other` is still
            derived above, so restoring it is a one-line uncomment:
            { id: 'other', label: 'Other states', value: counts.other,
              hint: 'Locked, pending, offboarded', tone: 'warning', icon: KeyRound }, */}
        <SummaryBar
          ariaLabel="Directory summary"
          loading={totalsLoading}
          value={filters.status || 'all'}
          onSelect={(id) =>
            setFilters((f) => ({ ...f, status: id === 'all' ? '' : id, page: 1 }))
          }
          items={[
            {
              id: 'all',
              label: 'Total users',
              value: counts.total,
              hint: 'Every identity in this tenant',
              icon: Users,
            },
            {
              id: 'ACTIVE',
              label: 'Active',
              value: counts.active,
              hint: 'Can sign in to this tenant',
              tone: 'positive',
              icon: ShieldCheck,
            },
            {
              id: 'DISABLED',
              label: 'Disabled',
              value: counts.disabled,
              hint: 'Access suspended',
              tone: 'muted',
              icon: UserX,
            },
          ]}
        />

        <Toolbar
          right={
            <div className="flex items-center gap-2">
              {/* The band states the tenant; this states the current query. */}
              <span className="text-2xs text-slate-500 tabular">
                {pagination.total.toLocaleString()} matching user
                {pagination.total === 1 ? '' : 's'}
              </span>
              {filtersActive && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFilters({ status: '', search: '', page: 1, per_page: filters.per_page })}
                >
                  Clear filters
                </Button>
              )}
            </div>
          }
        >
          <SearchInput
            value={filters.search}
            onChange={(v) => setFilters((f) => ({ ...f, search: v, page: 1 }))}
            placeholder="Search username or email…"
            width="w-full sm:w-80"
          />
          <Select
            value={filters.status}
            onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value, page: 1 }))}
            className="w-full sm:w-44"
            aria-label="Filter by status"
          >
            <option value="">All statuses</option>
            {Object.values(IDENTITY_USER_STATUS).map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
        </Toolbar>

        <DataTable
          columns={columns}
          data={data}
          loading={users.loading}
          onRowClick={(r) => navigate(`/identity/users/${r.user_id}`)}
          columnsStorageKey="iam-users-columns"
          selectable
          selectedIds={selectedIds}
          onSelectionChange={setSelectedIds}
          bulkActions={
            <>
              <Button
                variant="secondary"
                size="xs"
                loading={bulkBusy}
                onClick={() => runBulk('Disabled', (u) => identityApi.disableUser(u.user_id, accountId))}
              >
                <UserX className="h-3 w-3" /> Disable
              </Button>
              <Button
                variant="secondary"
                size="xs"
                loading={bulkBusy}
                onClick={() => runBulk('Enabled', (u) => identityApi.enableUser(u.user_id, accountId))}
              >
                <RotateCcw className="h-3 w-3" /> Enable
              </Button>
              <Button variant="secondary" size="xs" onClick={exportSelected}>
                <Download className="h-3 w-3" /> Export
              </Button>
            </>
          }
          empty={{
            icon: Users,
            title: filtersActive ? 'No users match these filters' : 'No users yet',
            description: filtersActive
              ? 'Adjust the search or status filter to widen the result set.'
              : 'Create the first user for this tenant to get started.',
            action: filtersActive ? (
              <Button
                variant="secondary"
                onClick={() => setFilters({ status: '', search: '', page: 1, per_page: filters.per_page })}
              >
                Clear filters
              </Button>
            ) : (
              <Button onClick={() => setCreateOpen(true)}>New user</Button>
            ),
          }}
          footer={
            <Pagination
              page={pagination.page}
              perPage={pagination.per_page}
              total={pagination.total}
              onPageChange={(p) => setFilters((f) => ({ ...f, page: p }))}
              onPerPageChange={(n) => setFilters((f) => ({ ...f, per_page: n, page: 1 }))}
              className="pt-0"
            />
          }
        />
      </div>

      {/* Create user */}
      <Modal
        open={createOpen}
        onClose={() => {
          setCreateOpen(false);
          setErrors({});
        }}
        title="Create user"
        description="A username and one-time password are generated by the platform and downloaded as a spreadsheet."
        icon={UserCog}
        footer={
          <>
            <Button
              variant="secondary"
              onClick={() => {
                setCreateOpen(false);
                setErrors({});
              }}
            >
              Cancel
            </Button>
            <Button onClick={create} loading={saving}>
              Create user
            </Button>
          </>
        }
      >
        <form onSubmit={create} className="space-y-4">
          <FormErrorSummary errors={errors} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              label="First name"
              value={form.first_name}
              error={errors.first_name}
              onChange={(e) => {
                const value = e.target.value;
                setForm((f) => ({ ...f, first_name: value }));
                /* Validated as it is typed: the moment a digit, space or symbol
                   appears the field says so, instead of failing on submit. An
                   empty field is not an error until the form is submitted. */
                setErrors((x) => ({
                  ...x,
                  first_name: value ? validateNameField(value, 'First name') || undefined : undefined,
                }));
              }}
              onBlur={() =>
                setErrors((x) => ({
                  ...x,
                  first_name: form.first_name
                    ? validateNameField(form.first_name, 'First name') || undefined
                    : undefined,
                }))
              }
              required
              autoComplete="given-name"
              inputMode="text"
              placeholder="Jane"
              hint="Letters only (A–Z)."
            />
            <Input
              label="Last name"
              value={form.last_name}
              error={errors.last_name}
              onChange={(e) => {
                const value = e.target.value;
                setForm((f) => ({ ...f, last_name: value }));
                setErrors((x) => ({
                  ...x,
                  last_name: value ? validateNameField(value, 'Last name') || undefined : undefined,
                }));
              }}
              onBlur={() =>
                setErrors((x) => ({
                  ...x,
                  last_name: form.last_name
                    ? validateNameField(form.last_name, 'Last name') || undefined
                    : undefined,
                }))
              }
              required
              autoComplete="family-name"
              inputMode="text"
              placeholder="Doe"
              hint="Letters only (A–Z)."
            />
          </div>
          <Input
            label="Email"
            type="email"
            value={form.email}
            error={errors.email}
            onChange={(e) => {
              setForm((f) => ({ ...f, email: e.target.value }));
              setErrors((x) => ({ ...x, email: undefined }));
            }}
            onBlur={() => {
              if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) {
                setErrors((x) => ({ ...x, email: 'Enter a valid email address, e.g. name@company.com.' }));
              }
            }}
            required
            placeholder="name@company.com"
          />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              label="Department"
              value={form.department}
              onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))}
            />
            <Input
              label="Title"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            />
          </div>
        </form>
      </Modal>

      {/* One-time credentials */}
      <Modal
        open={!!created}
        onClose={() => setCreated(null)}
        title="User created"
        description={created?.message}
        icon={KeyRound}
        size="sm"
        footer={<Button onClick={() => setCreated(null)}>Done</Button>}
      >
        <div className="rounded-lg border border-line bg-slate-50/70 p-3">
          <DescriptionList
            columns={1}
            items={[
              { label: 'Username', value: created?.username, mono: true },
              { label: 'One-time password', value: created?.password, mono: true },
            ]}
          />
        </div>
        <InlineAlert tone="warning" className="mt-3">
          Save these credentials now — the password is not retrievable after this dialog closes. A
          spreadsheet copy has been downloaded.
        </InlineAlert>
      </Modal>

      <ConfirmDialog
        open={!!offboardConfirm}
        onClose={() => setOffboardConfirm(null)}
        onConfirm={() => offboard(offboardConfirm?.user_id)}
        loading={offboarding}
        danger
        title="Offboard user"
        confirmLabel="Offboard user"
        message={`${offboardConfirm?.username || offboardConfirm?.user_id} will lose all access immediately.`}
        detail="Sessions are revoked, role and group memberships are removed, and the account is marked offboarded. This cannot be undone."
      />
    </div>
  );
}

export default function UsersPage() {
  return (
    <AccountGate>
      <UsersInner />
    </AccountGate>
  );
}
