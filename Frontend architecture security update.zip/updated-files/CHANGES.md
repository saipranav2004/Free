# Updated frontend files — round 2 (3 tasks)

Copy over your project root; paths mirror the original `src/`. **Only changed files are included.**
No backend file was touched. No git command was run. Palette and design tokens unchanged.

---

## Research → the `SummaryBar` pattern (Task 1)

How leading enterprise consoles present a set of related numbers above a list — Microsoft Entra ID
(Users / Groups blades), Okta (People, Applications), AWS IAM (Users, Policies), CyberArk PVWA
(accounts), Datadog (facet panels), GitHub (issue lists):

1. **The set total belongs to the list**, not to a tile — it lives in the list title or the pagination
   range ("1–20 of 348"). A large tile repeating it is redundant chrome.
2. **A status breakdown is a filter, not a read-out.** Each figure is a *facet* that narrows the list,
   so the number and the action are the same control — and the number becomes verifiable, because
   clicking it shows the rows it counted.
3. **Large number tiles are for analytical surfaces**, where the number *is* the content — not for an
   inventory page, where the table is the content.

Implemented as one new primitive, `SummaryBar` (`components/ui/primitives.jsx`): a single compact
band, hairline-divided cells, uppercase label + tabular figure + one line of context — roughly a
third of the height of the tile strip it replaces. Pass `onSelect` and each cell becomes a facet with
the same 2px active accent the navigation uses. `StatCard` is untouched and still exported.

**Rolled out to every page that showed a number-tile strip:**

| Page | Band | Facets drive |
|---|---|---|
| `identity/UsersPage` | Total · Active · Disabled | `filters.status` |
| `pbac/ResourcesPage` | Total · Active · Inactive | `statusFilter` |
| `identity/ResourcesPage` | Total · Active · Inactive | read-only (no status control on this view) |
| `identity/DelegationsPage` | Total · Active · Revoked · Expired | read-only |
| `idp/IdpOverviewPage` | Adopted · Google · Deprecated | `platformFilter` |
| `pam` Audit Logs | Events in scope · AuthN · AuthZ · Successful · Denied | read-only (decision facets sit in the filter bar) |
| `pam` Alerts | Total denials · Last 24h · Principals · Resources | read-only (analytics page) |
| `identity/AuditLogsPage` (legacy view) | same as PAM audit | read-only |

### Task 1 — the actual bug: page-local counts

`UsersPage` computed Active/Disabled with `data.filter(...)` over the **fetched page**, so page 2 of a
300-user tenant read "Active 7". Each figure is now the server's own `pagination.total` for that
status — three deliberately tiny requests (`per_page: 1`, only the total is read), carrying no search
filter, exactly the technique `DashboardPage`'s directory panel already uses, so the two screens can
never disagree. The toolbar states the current query's total separately ("N matching users").

Every mutation (create · enable · disable · offboard · bulk enable/disable) now calls
`reloadDirectory()`, which re-reads **both** the table and the tenant totals — a disable that didn't
move the "Disabled" figure would leave the band lying until a hard refresh.

Also fixed while there: `IdpOverviewPage`'s "Deprecated" figure is now a real filter (added to the
platform filter memo and the segmented control), because an active facet that changes nothing is a lie.

---

## Task 2 — RoleDetailPage: detach now works

**Root cause.** Both handlers called the id-**pair** routes that `lib/endpoints.js` itself flags as
possibly unregistered — `DELETE /authz/roles/<role_id>/users/<user_id>` (`RoleUserDetailAPI`) and
`DELETE /authz/roles/<role_id>/policies/<policy_id>` (`RolePolicyDetailAPI`) — while `UserDetailPage`'s
Roles and Policies tabs, where detach works, use the **attachment-scoped** routes
(`/authz/roles/assignments/<assignment_id>`, `/authz/roles/policies/<role_policy_id>`). The policy rows
were also discarding the attachment id: the identity endpoint nests the policy under `policy` and puts
the id in `role_policy_id`, and the page read neither. On top of that neither button had a
confirmation or a busy state, so a failure was completely invisible.

**Fix**, following the `UserDetailPage` pattern exactly:
* `normaliseAttachedPolicy` keeps `role_policy_id` (and every alias) and hydrates names from the policy
  catalogue; assigned-user rows already kept `assignment_id`.
* The proven attachment-scoped route is tried **first**; a "not registered" answer (404/405/501) falls
  through to the id-pair route, and any other error is reported.
* Both actions go through a `ConfirmDialog` ("Detach role" / "Detach policy", with blast-radius detail)
  with a `loading` state, then `reloadAll()` — which reloads the role graph, the policy list, the
  directory and the assigned-user reconciliation, so both cards, both counts and both pickers move.

Nothing else on the page changed.

---

## Task 3 — PAM Audit Logs & Alerts

**Pagination.** `ActivityFeed`'s bespoke Prev/Next pair is replaced by the console's shared
`Pagination` control — numbered pages, the "1–20 of 348" range, and a **rows-per-page dropdown**
(10 / 20 / 50 / 100). On both pages page size is a real request parameter (`page_size`), so widening
the window widens the query; it survives a filter reset (a display preference, not a filter) and
resets to page 1.

**Filter counts (the reported bug).** The Denied/Success counts were computed from the rows on the
current page, and the decision filter was applied client-side to that page too — so "Denied" showed
only the denials that happened to land on page 1 while the pagination total still described the
unfiltered set. Now:

* The decision facet is a **server parameter** (`status`), so filtering and paging happen over the
  whole log set and the feed count, the list and the range all agree.
* Facet counts come from **one extra minimal request** (`page_size: 1`) carrying every applied filter
  **except** the decision facet — the standard facet-count rule: a facet's count must not be narrowed
  by that same facet. All three counts (All / Denied / Success) are whole-set figures.
* If a deployment sends no aggregate, counts are **omitted** rather than guessed — a wrong number is
  worse than no number.
* A scope band above the filter bar states Events in scope · AuthN · AuthZ · Successful · Denied for the
  current filters, which is the CyberArk / Splunk / Datadog reading order: shape of the evidence, then
  the evidence. It refreshes with the rows, including on the 30s auto-refresh.

---

## Verification performed

* All 14 touched files parse cleanly (Babel, React preset).
* Comment-stripping scan confirms no stale `StatCard`, `revokeUser(`, `detachPolicy(`, `ChevronLeft` or
  page-local count reference is still live anywhere.
* `users.reload()` now exists in exactly one place (inside `reloadDirectory`), which all four mutation
  paths call — no path can update the table without updating the totals.
* Facet ⇄ control parity checked on every band: Users (band ⇄ status dropdown), Resources (band ⇄
  segmented control), IDP (band ⇄ platform control) all write the same state, so they cannot diverge.
* Status tokens verified against `utils/constants.js` (`ACTIVE` / `DISABLED`); `ConfirmDialog` verified
  to support the `confirmLabel` / `detail` / `loading` props used.
* Role detail: assign / detach-user / attach / detach-policy all funnel into `reloadAll()`, and counts
  derive from the resolved lists once loading settles.
* No design token, palette value or shared primitive signature was changed — `SummaryBar` is additive.
