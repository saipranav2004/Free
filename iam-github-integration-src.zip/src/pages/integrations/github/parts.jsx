/**
 * parts.jsx — building blocks for the external identity mapping detail page.
 *
 * Split out of the page for the same reason pam/parts.jsx and m365/parts.jsx
 * are: the page then reads as data flow and layout, and the dialogs can be
 * reasoned about (and re-used by a second provider) on their own.
 *
 * Everything here is provider-agnostic and driven by the descriptor from
 * utils/providers.js — GitHub is passed in, never hard-coded.
 */
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle, Clock, Copy, ExternalLink, KeyRound, ShieldCheck, UserRoundCheck,
} from 'lucide-react';
import { useToast } from '../../../context/ToastContext.jsx';
import { useResource } from '../../../hooks/useResource.js';
import { integrationApi } from '../../../lib/api/integration.js';
import {
  Button, Input, Select, Textarea, Badge, StatusBadge, IconButton, Spinner,
  FormErrorSummary,
} from '../../../components/ui/primitives.jsx';
import { UserPicker } from '../../../components/common/EntityPickers.jsx';
import { Modal } from '../../../components/ui/Modal.jsx';
import {
  ExpiryInput, toIsoExpiry, fromIsoExpiry, isPastExpiry,
} from '../../../components/ui/ExpiryInput.jsx';
import { classNames, formatDateTime, shortId } from '../../../utils/format.js';
/* Record-shape helpers live in utils/integrations.js so the Resources list and
   this page can never parse the same collection differently. */
import {
  isTokenExpired, mappingId, mappingStatus, normaliseMapping, scopeList,
} from '../../../utils/integrations.js';

/* ═══════════════════════════════════════════════════════════════════════════
   Small presentational pieces
   ═══════════════════════════════════════════════════════════════════════════ */

export function DetailRow({ label, children, mono = false }) {
  return (
    <div className="grid grid-cols-[140px_1fr] items-start gap-3 py-2">
      <dt className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-400">{label}</dt>
      <dd
        className={classNames(
          'min-w-0 break-words text-[13px] text-ink-800',
          mono && 'font-mono text-xs'
        )}
      >
        {children}
      </dd>
    </div>
  );
}

export function CopyableValue({ value, onCopy, title = 'Copy to clipboard' }) {
  if (!value) return <span className="text-slate-400">—</span>;
  return (
    <span className="flex items-start gap-1.5">
      <span className="min-w-0 flex-1 break-all font-mono text-xs text-ink-800">{value}</span>
      <IconButton icon={Copy} title={title} onClick={() => onCopy(value)} />
    </span>
  );
}

/** Scope chips with an overflow counter, so a wide scope set never breaks a row. */
export function ScopeChips({ scopes, max = 3 }) {
  const list = scopeList(scopes);
  if (!list.length) return <span className="text-slate-400">—</span>;
  const shown = list.slice(0, max);
  const rest = list.length - shown.length;
  return (
    <span className="flex flex-wrap items-center gap-1" title={list.join(', ')}>
      {shown.map((s) => (
        <Badge key={s} tone="outline" mono>
          {s}
        </Badge>
      ))}
      {rest > 0 && <Badge tone="slate">+{rest}</Badge>}
    </span>
  );
}

/** Status badge plus the separate credential-expiry warning. */
export function MappingStatus({ mapping }) {
  const expired = isTokenExpired(mapping);
  return (
    <span className="flex flex-wrap items-center gap-1.5">
      <StatusBadge status={mappingStatus(mapping)} />
      {expired && (
        <Badge tone="amber" dot>
          Token expired
        </Badge>
      )}
    </span>
  );
}

/**
 * The IAM principal a mapping is bound to.
 *
 * A raw UUID is unverifiable at a glance, which is the single most common cause
 * of a mis-targeted assignment — so the directory name leads and the id is the
 * subtitle, the same way Entra and Okta present a linked account.
 */
export function LinkedUser({ userId, directory, compact = false }) {
  if (!userId) return <span className="text-slate-400">—</span>;
  const name = directory?.[userId];
  return (
    <div className="min-w-0">
      <Link
        to={`/identity/users/${encodeURIComponent(userId)}`}
        onClick={(e) => e.stopPropagation()}
        className="truncate text-[13px] font-medium text-brand-700 hover:text-brand-800"
        title={name || userId}
      >
        {name || shortId(userId)}
      </Link>
      {!compact && name && (
        <p className="truncate font-mono text-2xs text-slate-500" title={userId}>
          {shortId(userId)}
        </p>
      )}
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   MappingFormModal — create and edit
   ═══════════════════════════════════════════════════════════════════════════
   Two modes, one dialog, because they describe the same object:
     CREATE  POST /api/v1/integrations  { user_id, provider, external_id }
             Exactly those three fields — nothing else is in the create
             contract, so nothing else is sent.
     EDIT    PUT  /api/v1/integrations/<id>
             { status, scopes, metadata, token_expires_at }
             The principal, the provider and the external identity are the
             record's IDENTITY, so they are shown read-only here: the update
             contract does not accept them, and silently dropping typed input
             would be worse than not offering the field.
   ═══════════════════════════════════════════════════════════════════════════ */
export function MappingFormModal({
  open,
  mode = 'create',
  provider,
  mapping,
  currentUserId,
  existingMappings = [],
  directory,
  onClose,
  onSaved,
}) {
  const toast = useToast();
  const isEdit = mode === 'edit';
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({
    user_id: '',
    external_id: '',
    status: 'ACTIVE',
    scopes: '',
    token_expires_at: '',
    metadata: '',
  });

  /* Reset on every opening so a cancelled edit never leaks into the next one.
     Create defaults the principal to the signed-in operator — the overwhelmingly
     common case is "map my own GitHub login" — while leaving it changeable. */
  useEffect(() => {
    if (!open) return;
    setErrors({});
    if (isEdit && mapping) {
      setForm({
        user_id: mapping.user_id || '',
        external_id: mapping.external_id || '',
        status: mappingStatus(mapping) === 'DISABLED' ? 'DISABLED' : 'ACTIVE',
        scopes: scopeList(mapping.scopes).join(', '),
        token_expires_at: fromIsoExpiry(mapping.token_expires_at),
        metadata:
          mapping.metadata && typeof mapping.metadata === 'object'
            ? JSON.stringify(mapping.metadata, null, 2)
            : '',
      });
    } else {
      setForm({
        user_id: currentUserId || '',
        external_id: '',
        status: 'ACTIVE',
        scopes: '',
        token_expires_at: '',
        metadata: '',
      });
    }
  }, [open, isEdit, mapping, currentUserId]);

  const set = (key) => (e) => {
    const value = e?.target ? e.target.value : e;
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((x) => ({ ...x, [key]: undefined }));
  };

  /* A duplicate is caught before the request so the operator reads a sentence
     about their tenant rather than a 409 translated into generic copy. */
  const duplicateOf = useMemo(() => {
    if (isEdit) return null;
    const candidate = form.external_id.trim().toLowerCase();
    if (!candidate) return null;
    return (
      existingMappings.find(
        (m) => String(m.external_id ?? '').trim().toLowerCase() === candidate
      ) || null
    );
  }, [isEdit, form.external_id, existingMappings]);

  const validate = () => {
    const next = {};
    if (!isEdit) {
      if (!form.user_id) next.user_id = 'Select the IAM user this identity belongs to.';
      const identityError = provider.validateExternalId(form.external_id);
      if (identityError) next.external_id = identityError;
      else if (duplicateOf) {
        next.external_id =
          mappingStatus(duplicateOf) === 'DISABLED'
            ? `“${form.external_id.trim()}” is already mapped on a deactivated record. Reactivate that mapping instead of creating a second one.`
            : `“${form.external_id.trim()}” is already mapped to a user in this tenant.`;
      }
    } else {
      if (form.metadata.trim()) {
        try {
          const parsed = JSON.parse(form.metadata);
          if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            next.metadata = 'Metadata must be a JSON object, for example { "team": "platform" }.';
          }
        } catch {
          next.metadata = 'Metadata is not valid JSON. Check for a missing quote, comma or brace.';
        }
      }
      if (form.token_expires_at && isPastExpiry(form.token_expires_at)) {
        next.token_expires_at = 'Choose a future date — an expiry in the past grants no access.';
      }
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = async (e) => {
    e?.preventDefault?.();
    if (saving) return;
    if (!validate()) return;

    setSaving(true);
    try {
      if (isEdit) {
        const id = mappingId(mapping);
        if (!id) {
          toast.error('This mapping has no identifier and cannot be updated.');
          return;
        }
        /* Echo `scopes` back in the shape it arrived in. A deployment that
           stores a delimited string must not be handed an array, and vice
           versa. */
        const parsedScopes = scopeList(form.scopes);
        const scopes =
          typeof mapping?.scopes === 'string' ? parsedScopes.join(',') : parsedScopes;

        await integrationApi.mappings.update(id, {
          status: form.status,
          scopes,
          metadata: form.metadata.trim() ? JSON.parse(form.metadata) : {},
          token_expires_at: toIsoExpiry(form.token_expires_at),
        });
        toast.success(`Mapping for “${mapping.external_id}” updated.`);
      } else {
        await integrationApi.mappings.create({
          user_id: form.user_id,
          provider: provider.id,
          external_id: form.external_id.trim(),
        });
        toast.success(
          `${provider.label} identity “${form.external_id.trim()}” mapped successfully.`
        );
      }
      onSaved?.();
      onClose?.();
    } catch (err) {
      toast.error(
        err.userMessage ||
          (isEdit ? 'Could not update this mapping.' : 'Could not create this mapping.')
      );
    } finally {
      setSaving(false);
    }
  };

  const ProviderIcon = provider.icon;
  const usingOwnAccount = !!currentUserId && form.user_id === currentUserId;

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="form"
      icon={ProviderIcon}
      title={isEdit ? `Edit ${provider.label} mapping` : `Map a ${provider.label} identity`}
      description={
        isEdit
          ? 'Lifecycle, scopes and credential expiry for this external identity.'
          : `Bind a ${provider.label} login to an IAM user so activity on this resource resolves to a known principal.`
      }
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={submit} loading={saving}>
            {isEdit ? 'Save changes' : 'Create mapping'}
          </Button>
        </>
      }
    >
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormErrorSummary errors={errors} />

        {/* Provider is FIXED by the resource that was opened. It is shown, not
            hidden, so the operator can see what the record will carry — and it
            is not editable, because this page is scoped to one provider. */}
        <Input
          label="Provider"
          value={provider.id}
          readOnly
          disabled
          className="font-mono"
          hint={`Set from the resource you opened — every mapping created here is a ${provider.label} mapping.`}
        />

        {isEdit ? (
          <>
            <div>
              <p className="label-base">IAM user</p>
              <div className="surface-muted px-3 py-2.5">
                <LinkedUser userId={mapping?.user_id} directory={directory} />
              </div>
              <p className="mt-1.5 text-xs leading-snug text-slate-500">
                The principal and the external identity define this record. To bind this
                identity to a different user, deactivate this mapping and create a new one.
              </p>
            </div>

            <Input
              label={provider.identityLabel}
              value={form.external_id}
              readOnly
              disabled
              className="font-mono"
            />

            <Select label="Status" value={form.status} onChange={set('status')} required>
              <option value="ACTIVE">Active — the mapping is in force</option>
              <option value="DISABLED">Disabled — retained but not applied</option>
            </Select>

            <Input
              label="Scopes"
              value={form.scopes}
              onChange={set('scopes')}
              error={errors.scopes}
              placeholder="read:user, read:org"
              className="font-mono"
              hint="Comma separated. Records the access this identity was granted at the provider."
            />
            {provider.commonScopes?.length > 0 && (
              <div className="-mt-2 flex flex-wrap items-center gap-1.5">
                <span className="text-2xs text-slate-500">Common:</span>
                {provider.commonScopes.map((scope) => {
                  const active = scopeList(form.scopes).includes(scope);
                  return (
                    <button
                      key={scope}
                      type="button"
                      onClick={() => {
                        const current = scopeList(form.scopes);
                        const next = active
                          ? current.filter((s) => s !== scope)
                          : [...current, scope];
                        setForm((f) => ({ ...f, scopes: next.join(', ') }));
                      }}
                      className={classNames(
                        'rounded-md px-1.5 py-0.5 font-mono text-2xs ring-1 ring-inset transition-colors',
                        active
                          ? 'bg-brand-50 text-brand-700 ring-brand-200'
                          : 'bg-white text-slate-600 ring-slate-300 hover:bg-slate-50'
                      )}
                    >
                      {scope}
                    </button>
                  );
                })}
              </div>
            )}

            <ExpiryInput
              label="Token expires at"
              value={form.token_expires_at}
              onChange={set('token_expires_at')}
              error={errors.token_expires_at}
              hint="Leave empty when the provider credential does not expire."
            />

            <Textarea
              label="Metadata"
              rows={4}
              value={form.metadata}
              onChange={set('metadata')}
              error={errors.metadata}
              className="font-mono text-xs"
              placeholder={'{\n  "team": "platform"\n}'}
              hint="Optional JSON object stored alongside the mapping."
            />
          </>
        ) : (
          <>
            <div>
              <UserPicker
                label="IAM user"
                value={form.user_id}
                onChange={(id) => {
                  setForm((f) => ({ ...f, user_id: id || '' }));
                  setErrors((x) => ({ ...x, user_id: undefined }));
                }}
                error={errors.user_id}
                required
                placeholder="Search users by name or email…"
                hint="Defaults to your own account. Search the directory to map someone else."
              />
              <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2">
                <span className="min-w-0 truncate font-mono text-2xs text-slate-500">
                  {form.user_id ? `user_id ${form.user_id}` : 'No principal selected'}
                </span>
                {currentUserId && !usingOwnAccount && (
                  <Button
                    variant="link"
                    size="xs"
                    onClick={() => {
                      setForm((f) => ({ ...f, user_id: currentUserId }));
                      setErrors((x) => ({ ...x, user_id: undefined }));
                    }}
                  >
                    <UserRoundCheck className="h-3.5 w-3.5" /> Use my account
                  </Button>
                )}
              </div>
            </div>

            <Input
              label={provider.identityLabel}
              value={form.external_id}
              onChange={set('external_id')}
              error={errors.external_id}
              placeholder={provider.identityPlaceholder}
              className="font-mono"
              required
              hint={provider.identityHint}
            />
          </>
        )}
      </form>
    </Modal>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   MappingRecordModal — the authoritative single record
   ═══════════════════════════════════════════════════════════════════════════
   Reads GET /api/v1/integrations/<id> rather than reusing the row from the
   list: the list is a snapshot, and this dialog is where an operator goes to
   check what the platform actually holds before acting on it.
   ═══════════════════════════════════════════════════════════════════════════ */
export function MappingRecordModal({
  mapping,
  provider,
  directory,
  onClose,
  onEdit,
  onDeactivate,
  onReactivate,
  onCopy,
}) {
  const id = mappingId(mapping);
  const record = useResource(
    () => (id ? integrationApi.mappings.get(id) : Promise.resolve(null)),
    [id]
  );

  // Fall back to the row we already have if the single-record read fails, so
  // the dialog is never blank.
  const data = normaliseMapping(record.data) || mapping || {};
  const status = mappingStatus(data);
  const expired = isTokenExpired(data);
  const meta = data.metadata && typeof data.metadata === 'object' ? data.metadata : {};
  const metaEntries = Object.entries(meta);
  const ProviderIcon = provider.icon;

  return (
    <Modal
      open={!!mapping}
      onClose={onClose}
      size="lg"
      icon={ProviderIcon}
      title={data.external_id || `${provider.label} mapping`}
      description={`Full integration record held by the platform for this ${provider.label} identity.`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
          <Button variant="secondary" onClick={() => onEdit?.(data)}>
            Edit mapping
          </Button>
          {status === 'DISABLED' ? (
            <Button onClick={() => onReactivate?.(data)}>Reactivate</Button>
          ) : (
            <Button variant="danger" onClick={() => onDeactivate?.(data)}>
              Deactivate
            </Button>
          )}
        </>
      }
    >
      {record.loading && !mapping ? (
        <div className="flex justify-center py-10">
          <Spinner />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <MappingStatus mapping={data} />
            <Badge tone="slate" mono>
              {data.provider || provider.id}
            </Badge>
            {record.error && (
              <Badge tone="amber">Showing the last loaded copy of this record</Badge>
            )}
          </div>

          {expired && status === 'ACTIVE' && (
            <div
              role="status"
              className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50/70 px-4 py-3"
            >
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
              <p className="text-xs leading-relaxed text-ink-700/80">
                The credential recorded against this mapping expired on{' '}
                {formatDateTime(data.token_expires_at)}. The mapping is still active — update
                the expiry once the credential has been renewed at the provider.
              </p>
            </div>
          )}

          <section>
            <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <ProviderIcon className="h-3.5 w-3.5" /> External identity
            </h4>
            <dl className="mt-1 divide-y divide-line-soft">
              <DetailRow label={provider.identityLabel}>
                {data.external_id ? (
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="break-all font-mono text-xs text-ink-800">
                      {data.external_id}
                    </span>
                    <a
                      href={provider.profileUrl(data.external_id)}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="inline-flex items-center gap-1 text-xs text-brand-700 hover:text-brand-800"
                    >
                      <ExternalLink className="h-3 w-3" /> Open on {provider.label}
                    </a>
                  </span>
                ) : (
                  <span className="text-slate-400">—</span>
                )}
              </DetailRow>
              <DetailRow label="Provider" mono>
                {data.provider || provider.id}
              </DetailRow>
              <DetailRow label="Integration ID">
                <CopyableValue value={id} onCopy={onCopy} title="Copy integration id" />
              </DetailRow>
            </dl>
          </section>

          <section>
            <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <ShieldCheck className="h-3.5 w-3.5" /> Linked principal
            </h4>
            <dl className="mt-1 divide-y divide-line-soft">
              <DetailRow label="IAM user">
                <LinkedUser userId={data.user_id} directory={directory} />
              </DetailRow>
              <DetailRow label="User ID">
                <CopyableValue value={data.user_id} onCopy={onCopy} title="Copy user id" />
              </DetailRow>
            </dl>
          </section>

          <section>
            <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <KeyRound className="h-3.5 w-3.5" /> Access
            </h4>
            <dl className="mt-1 divide-y divide-line-soft">
              <DetailRow label="Scopes">
                <ScopeChips scopes={data.scopes} max={12} />
              </DetailRow>
              <DetailRow label="Token expires">
                {data.token_expires_at ? (
                  <span className={expired ? 'text-amber-700' : undefined}>
                    {formatDateTime(data.token_expires_at)}
                    {expired && ' — expired'}
                  </span>
                ) : (
                  <span className="text-slate-400">No expiry recorded</span>
                )}
              </DetailRow>
            </dl>
          </section>

          <section>
            <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
              <Clock className="h-3.5 w-3.5" /> Provenance
            </h4>
            <dl className="mt-1 divide-y divide-line-soft">
              <DetailRow label="Created">{formatDateTime(data.created_at)}</DetailRow>
              <DetailRow label="Updated">{formatDateTime(data.updated_at)}</DetailRow>
              {metaEntries.length > 0 &&
                metaEntries.map(([key, value]) => (
                  <DetailRow key={key} label={key.replace(/_/g, ' ')}>
                    {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                  </DetailRow>
                ))}
            </dl>
          </section>
        </div>
      )}
    </Modal>
  );
}
