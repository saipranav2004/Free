import { useState, useMemo } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Boxes, Plus, Trash2, RefreshCw, Link2, CheckCircle2, Ban } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { integrationApi } from '../../lib/api/integration.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, Select, StatusBadge, EmptyState, Badge, Toolbar, SearchInput, IconButton,
  SummaryBar,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { detectProvider, integrationPathFor } from '../../utils/providers.js';
import { readMappings } from '../../utils/integrations.js';
import { classNames, formatDateTime } from '../../utils/format.js';

/**
 * ResourcesPage (ABAC) — the registry of protected resources referenced by
 * policies. ARNs are monospace because they are copied into policy documents.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * API CONTRACT (top-level /api/v1/resources surface)
 * ═══════════════════════════════════════════════════════════════════════════
 *   GET    /api/v1/resources             → { pagination, resources: [ … ] }
 *   POST   /api/v1/resources/create      → { resource: { … } }
 *   DELETE /api/v1/resources/<id>
 *
 * The create body is sent EXACTLY as the contract specifies:
 *   {
 *     resource_name, resource_type, resource_arn, target_url,
 *     is_active: true,
 *     metadata: { env, team }
 *   }
 *
 * The page previously called the authz-scoped paths with a flat
 * { name, type, arn, target_url } body, so listing returned nothing and both
 * create and delete failed. Every call now goes through pbacApi's resource
 * methods, and the table reloads from the server after each mutation so what
 * is on screen is always what the backend holds.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * PROVIDER ROWS (external identity integrations)
 * ═══════════════════════════════════════════════════════════════════════════
 * A registry row that RESOLVES to an external identity provider — GitHub today
 * — is more than a protected ARN: it is a connection with linked identities
 * behind it. Those rows therefore carry two extra affordances, and nothing
 * else on this page changes:
 *
 *   · the resource name becomes a link to the provider's integration page, and
 *     the row shows how many identities are currently mapped to it;
 *   · an explicit "Manage integration" action sits beside the existing disable
 *     action.
 *
 * Rows with no provider render and behave EXACTLY as before — no row click, no
 * extra chrome, no cursor change. Which rows qualify is decided in one place,
 * utils/providers.js, so this list and the detail page can never disagree.
 *
 * The mapping count is a hint, never a gate: if /api/v1/integrations is
 * unreachable or not deployed, the badge is simply absent and the registry is
 * unaffected.
 */

/** Common resource types — free text is still allowed via the "Other" option. */
const RESOURCE_TYPES = ['application', 'api', 'dataset', 'database', 'service', 'storage'];

const EMPTY_FORM = {
  resource_name: '',
  resource_type: 'application',
  resource_type_other: '',
  resource_arn: '',
  target_url: '',
  is_active: true,
  env: '',
  team: '',
};

export default function ResourcesPage() {
  const toast = useToast();
  const navigate = useNavigate();
  /* The PAM views deep-link here as /identity/resources?search=<resource> when
     an operator pivots from an audit event to the resource it names. The page
     never read the parameter, so those links silently landed on an unfiltered
     table; the search now seeds from the URL. Read once, on mount — the field
     stays a normal controlled input afterwards. */
  const [searchParams] = useSearchParams();
  const resources = useResource(() => pbacApi.listResources(), []);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState(() => searchParams.get('search') || '');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);

  /* ── List response: { pagination, resources: [...] }, with tolerance for a
     bare array or a { data: { resources } } envelope from older builds. ── */
  const payload = resources.data;
  const data = Array.isArray(payload)
    ? payload
    : payload?.resources || payload?.data?.resources || [];
  /* Counts.
     `pagination.total` is the server's view across all pages, but it can lag a
     just-completed create/delete (or be absent entirely), and it must never
     read lower than the rows actually in hand — so take the larger of the two.
     Active / inactive are derived from the rows themselves, so every tile moves
     the moment `resources.reload()` lands after a create or a delete. */
  const total = Math.max(payload?.pagination?.total ?? 0, data.length);
  const activeCount = data.filter((r) => r.is_active).length;
  const inactiveCount = data.length - activeCount;

  /* ── Provider mapping counts ──
     Only requested when the registry actually contains a provider row, so a
     tenant with no integrations never pays for the call. Deliberately scoped to
     status=ACTIVE: the figure on a list row should state what is in force, not
     what has ever existed. Failure is silent — `mappingCounts` stays empty and
     the badge does not render. */
  const hasGithubResource = useMemo(
    () => data.some((r) => detectProvider(r)?.id === 'github'),
    [data]
  );
  const githubMappings = useResource(
    () =>
      hasGithubResource
        ? integrationApi.mappings.list({ provider: 'github', status: 'ACTIVE' })
        : Promise.resolve(null),
    [hasGithubResource]
  );
  const mappingCounts = useMemo(() => {
    if (!hasGithubResource || githubMappings.loading || githubMappings.error) return {};
    return { github: readMappings(githubMappings.data).length };
  }, [hasGithubResource, githubMappings.loading, githubMappings.error, githubMappings.data]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (r) =>
        r.resource_name?.toLowerCase().includes(q) ||
        r.resource_arn?.toLowerCase().includes(q) ||
        r.resource_type?.toLowerCase().includes(q) ||
        r.target_url?.toLowerCase().includes(q) ||
        r.metadata?.env?.toLowerCase().includes(q) ||
        r.metadata?.team?.toLowerCase().includes(q)
    );
  }, [data, search]);

  const set = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((x) => ({ ...x, [key]: undefined }));
  };

  const resolvedType = () =>
    (form.resource_type === '__other' ? form.resource_type_other : form.resource_type).trim();

  const validate = () => {
    const next = {};
    if (!form.resource_name.trim()) next.resource_name = 'Resource name is required.';
    if (!resolvedType()) next.resource_type_other = 'Resource type is required.';
    if (!form.resource_arn.trim()) next.resource_arn = 'ARN is required.';
    if (!form.target_url.trim()) next.target_url = 'Target URL is required.';
    else if (!/^https?:\/\/\S+$/i.test(form.target_url.trim())) {
      next.target_url = 'Enter a full URL, e.g. https://api.example.com';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  // ── Create ── POST /api/v1/resources/create, then refresh the table.
  const createResource = async (e) => {
    e.preventDefault();
    if (saving) return;
    if (!validate()) return;

    setSaving(true);
    try {
      const res = await pbacApi.createResource({
        resource_name: form.resource_name.trim(),
        resource_type: resolvedType(),
        resource_arn: form.resource_arn.trim(),
        target_url: form.target_url.trim(),
        is_active: !!form.is_active,
        metadata: {
          env: form.env.trim(),
          team: form.team.trim(),
        },
      });
      const created = res?.resource || res?.data?.resource;
      toast.success(
        created?.resource_name
          ? `Resource “${created.resource_name}” created.`
          : 'Resource created successfully.'
      );
      setOpen(false);
      setForm(EMPTY_FORM);
      setErrors({});
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create resource.');
    } finally {
      setSaving(false);
    }
  };

  // ── Delete ── DELETE /api/v1/resources/<resource_id>, then refresh.
  const removeResource = async () => {
    const resourceId = deleteTarget?.resource_id;
    if (!resourceId) {
      toast.error('This resource has no id — it cannot be deleted.');
      setDeleteTarget(null);
      return;
    }
    setBusy(true);
    try {
      await pbacApi.deleteResource(resourceId);
      toast.success('Resource Disabled.');
      setDeleteTarget(null);
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable resource.');
    } finally {
      setBusy(false);
    }
  };

  const columns = [
    {
      id: 'resource_name',
      header: 'Resource',
      primary: true,
      sortable: true,
      render: (r) => {
        /* A provider row is branded and navigable; every other row renders
           exactly as it always has. */
        const provider = detectProvider(r);
        const RowIcon = provider?.icon || Boxes;
        const path = integrationPathFor(r);
        const linked = provider ? mappingCounts[provider.id] : undefined;
        return (
          <div className="flex items-center gap-3">
            <span
              className={classNames(
                'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100',
                provider ? 'text-ink-800' : 'text-slate-500'
              )}
            >
              <RowIcon className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                {path ? (
                  /* `state` hands the row to the detail page so it paints
                     immediately instead of waiting on its own registry read. */
                  <Link
                    to={path}
                    state={{ resource: r }}
                    title={`Open the ${provider.label} integration`}
                    className="truncate text-[13px] font-medium text-brand-700 hover:text-brand-800"
                  >
                    {r.resource_name}
                  </Link>
                ) : (
                  <p className="truncate text-[13px] font-medium text-ink-900">{r.resource_name}</p>
                )}
                {r.resource_type && <Badge tone="slate">{r.resource_type}</Badge>}
                {path && linked != null && (
                  <Badge tone={linked > 0 ? 'brand' : 'outline'}>
                    {linked} linked {linked === 1 ? 'identity' : 'identities'}
                  </Badge>
                )}
              </div>
              <p className="truncate font-mono text-xs text-slate-500">{r.resource_arn}</p>
            </div>
          </div>
        );
      },
    },
    {
      id: 'target_url',
      header: 'Target URL',
      sortable: true,
      render: (r) =>
        r.target_url ? (
          <a
            href={r.target_url}
            target="_blank"
            rel="noreferrer noopener"
            onClick={(e) => e.stopPropagation()}
            className="inline-flex max-w-[220px] items-center gap-1.5 truncate text-[13px] text-brand-700 hover:text-brand-800"
            title={r.target_url}
          >
            <Link2 className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            <span className="truncate">{r.target_url}</span>
          </a>
        ) : (
          <span className="text-slate-400">—</span>
        ),
    },
    {
      id: 'env',
      header: 'Environment',
      sortValue: (r) => r.metadata?.env || '',
      render: (r) =>
        r.metadata?.env ? <Badge tone="slate">{r.metadata.env}</Badge> : <span className="text-slate-400">—</span>,
    },
    {
      id: 'team',
      header: 'Team',
      sortValue: (r) => r.metadata?.team || '',
      render: (r) => (
        <span className="text-[13px] text-ink-800">{r.metadata?.team || <span className="text-slate-400">—</span>}</span>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      sortValue: (r) => (r.is_active ? 0 : 1),
      render: (r) => <StatusBadge status={r.is_active ? 'ACTIVE' : 'DISABLED'} />,
    },
    {
      id: 'created_at',
      header: 'Created',
      sortable: true,
      hideOnMobile: true,
      render: (r) => (
        <div className="min-w-0">
          <p className="text-[13px] text-ink-800">{formatDateTime(r.created_at)}</p>
          {r.created_by && <p className="truncate text-xs text-slate-500">by {r.created_by}</p>}
        </div>
      ),
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => {
        const provider = detectProvider(r);
        const path = integrationPathFor(r);
        return (
          <div className="flex items-center justify-end gap-1">
            {path && (
              <IconButton
                icon={Link2}
                title={`Manage the ${provider.label} integration`}
                tone="brand"
                onClick={() => navigate(path, { state: { resource: r } })}
              />
            )}
            <IconButton
              icon={Trash2}
              title="Disable resource"
              tone="danger"
              onClick={() => setDeleteTarget(r)}
            />
          </div>
        );
      },
    },
  ];

  return (
    <div>
      <PageHeader
        title="Registered resources"
        description="Protected resources available to attribute-based policy evaluation."
        icon={<Boxes className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Access control' }, { label: 'Resources (ABAC)' }]}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={resources.reload} loading={resources.loading}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button onClick={() => setOpen(true)}>
              <Plus className="h-4 w-4" /> Register resource
            </Button>
          </div>
        }
      />

      <div className="space-y-4">
        {/* Registry summary — the console's standard band (see SummaryBar).
            Read-only here: this view has no status control to drive, so the
            figures state the shape of the registry without pretending to be
            filters. Refreshed with the table after every mutation. */}
        <SummaryBar
          ariaLabel="Resource registry summary"
          loading={resources.loading}
          items={[
            {
              id: 'all',
              label: 'Total resources',
              value: total,
              hint: 'Registered in this tenant',
              icon: Boxes,
            },
            {
              id: 'active',
              label: 'Active',
              value: activeCount,
              hint: 'Evaluated in access decisions',
              tone: 'positive',
              icon: CheckCircle2,
            },
            {
              id: 'inactive',
              label: 'Inactive',
              value: inactiveCount,
              hint: 'Registered but not evaluated',
              tone: 'muted',
              icon: Ban,
            },
          ]}
        />

        <Toolbar
          right={
            <span className="text-2xs text-slate-500 tabular">
              {filtered.length} of {total} resource{total === 1 ? '' : 's'}
            </span>
          }
        >
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search name, type, ARN, URL, env or team…"
          />
        </Toolbar>

        {/* Load failure is surfaced explicitly — an empty table would otherwise
            read as "no resources" when the request never succeeded. */}
        {resources.error && !resources.loading ? (
          <EmptyState
            icon={Boxes}
            title="Resources could not be loaded"
            description={resources.error}
            action={<Button onClick={resources.reload}>Retry</Button>}
          />
        ) : resources.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={resources.loading}
            columnsStorageKey="iam-abac-resources-columns"
            empty={{
              icon: Boxes,
              title: `No resources match “${search}”`,
              description: 'Adjust the search to see more results.',
              action: (
                <Button variant="secondary" onClick={() => setSearch('')}>
                  Clear search
                </Button>
              ),
            }}
          />
        ) : (
          <EmptyState
            icon={Boxes}
            title="No resources registered"
            description="Register an application or dataset so policies can reference it by ARN."
            action={<Button onClick={() => setOpen(true)}>Register resource</Button>}
          />
        )}
      </div>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Register resource"
        description="The ARN is the identifier policies match on — keep it stable."
        icon={Boxes}
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={createResource} loading={saving}>
              Register resource
            </Button>
          </>
        }
      >
        <form onSubmit={createResource} className="space-y-4" noValidate>
          <Input
            label="Resource name"
            value={form.resource_name}
            onChange={set('resource_name')}
            error={errors.resource_name}
            required
            placeholder="user-management-api"
          />
          <Select
            label="Resource type"
            value={form.resource_type}
            onChange={set('resource_type')}
            required
          >
            {RESOURCE_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
            <option value="__other">Other…</option>
          </Select>
          {form.resource_type === '__other' && (
            <Input
              label="Custom type"
              value={form.resource_type_other}
              onChange={set('resource_type_other')}
              error={errors.resource_type_other}
              placeholder="queue"
              required
            />
          )}
          <Input
            label="ARN"
            value={form.resource_arn}
            onChange={set('resource_arn')}
            error={errors.resource_arn}
            placeholder="iam:app/my-app"
            required
            className="font-mono"
          />
          <Input
            label="Target URL"
            value={form.target_url}
            onChange={set('target_url')}
            error={errors.target_url}
            placeholder="https://api.example.com"
            required
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Environment"
              value={form.env}
              onChange={set('env')}
              placeholder="production"
              hint="metadata.env"
            />
            <Input
              label="Team"
              value={form.team}
              onChange={set('team')}
              placeholder="platform"
              hint="metadata.team"
            />
          </div>
          <label className="flex items-center gap-2 text-[13px] text-ink-800">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={set('is_active')}
              className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
            />
            Active — evaluate this resource in access decisions
          </label>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={removeResource}
        danger
        loading={busy}
        title="Disable resource"
        confirmLabel="Disable resource"
        message={`“${deleteTarget?.resource_name || 'This resource'}” will be removed from the registry.`}
        detail="Policies referencing this ARN remain in place but stop matching. This cannot be undone."
      />
    </div>
  );
}
