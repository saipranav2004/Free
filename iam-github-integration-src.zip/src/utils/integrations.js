/**
 * integrations.js — record-shape helpers for the /api/v1/integrations surface.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THESE ARE HERE AND NOT IN THE PAGE
 * ═══════════════════════════════════════════════════════════════════════════
 * Two surfaces read the same collection: the Resources registry shows a live
 * mapping count on a provider row, and the integration detail page renders the
 * records themselves. If each parsed the response its own way, a deployment
 * whose envelope differs even slightly would show one number in the list and a
 * different one on the page — and the operator would have no way to tell which
 * was lying. One reader, one answer.
 *
 * apiClient already unwraps the { success, message, data } envelope; what still
 * varies between deployments is the collection key and the id field, so every
 * read goes through here.
 *
 * Pure module: no React, no API client, no side effects.
 */
import { extractList } from './format.js';

/** Collection keys seen in the wild, in the order they are tried. */
const COLLECTION_KEYS = ['integrations', 'mappings', 'items', 'results'];

/** A list payload → an array of mapping records (never null). */
export function readMappings(payload) {
  if (!payload) return [];
  for (const key of COLLECTION_KEYS) {
    const list = extractList(payload, key);
    if (list.length) return list;
  }
  /* Nothing matched. That is either a genuinely empty tenant or a payload shape
     we do not recognise; both render as the empty state, which is the honest
     answer in either case. */
  return [];
}

/** A single-record payload → the record itself. */
export function normaliseMapping(payload) {
  if (!payload || typeof payload !== 'object') return null;
  const inner = payload.integration || payload.mapping || payload.data;
  if (inner && typeof inner === 'object' && !Array.isArray(inner)) {
    return { ...payload, ...inner };
  }
  return payload;
}

/** The record's identifier, whatever the backend names it. */
export const mappingId = (m) =>
  m?.integration_id ?? m?.id ?? m?.mapping_id ?? m?.external_integration_id ?? null;

/**
 * Status as an upper-case token.
 * Read verbatim from the API — the console never derives a lifecycle value the
 * backend did not return.
 */
export const mappingStatus = (m) => String(m?.status ?? '').trim().toUpperCase() || 'UNKNOWN';

/** `scopes` may arrive as an array or as a delimited string. Always read as an array. */
export function scopeList(scopes) {
  if (Array.isArray(scopes)) return scopes.map((s) => String(s).trim()).filter(Boolean);
  if (typeof scopes === 'string') {
    return scopes.split(/[,\s]+/).map((s) => s.trim()).filter(Boolean);
  }
  return [];
}

/**
 * True when the credential recorded against this mapping has already expired.
 *
 * Deliberately separate from `status`: an elapsed expiry is a warning about a
 * credential, not a lifecycle state, and the two are shown independently so an
 * operator can tell "the platform disabled this" from "the token needs
 * renewing".
 */
export function isTokenExpired(m) {
  const iso = m?.token_expires_at;
  if (!iso) return false;
  const at = new Date(iso);
  if (Number.isNaN(at.getTime())) return false;
  return at.getTime() < Date.now();
}

/** The most recent timestamp on a record (ms epoch), or null. */
export function lastTouched(m) {
  const values = [m?.updated_at, m?.created_at]
    .map((v) => (v ? new Date(v).getTime() : NaN))
    .filter((t) => !Number.isNaN(t));
  return values.length ? Math.max(...values) : null;
}
