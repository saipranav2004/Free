/**
 * providers.js — external identity providers, and the single rule that decides
 * which provider (if any) a registered resource represents.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS FILE EXISTS
 * ═══════════════════════════════════════════════════════════════════════════
 * The ABAC resource registry is deliberately generic: a row carries
 * `resource_name`, `resource_type`, `resource_arn`, `target_url` and a free-form
 * `metadata` object, and NOTHING that says "this is GitHub". The integration
 * surface (/api/v1/integrations) is the opposite — every record is keyed by a
 * `provider` string.
 *
 * Something has to bridge the two, and that something must be:
 *   · deterministic  — the same row always resolves to the same provider,
 *   · conservative   — a near-miss resolves to nothing rather than to a wrong
 *                      provider, because a wrong provider would map identities
 *                      into the wrong external system,
 *   · overridable    — an operator can state the answer explicitly instead of
 *                      relying on a heuristic.
 *
 * That bridge lives here, once, so the Resources list and the integration
 * detail page can never disagree about what a row is.
 *
 * Precedent for holding a lucide icon in a registry module: the M365 service
 * registry (pages/integrations/m365/registry.js) does exactly this.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * MATCHING RULES (evaluated in this order; first hit wins)
 * ═══════════════════════════════════════════════════════════════════════════
 *   1. metadata.provider   — an explicit operator declaration, always trusted
 *   2. resource_arn        — e.g. iam:app/github, github:org/acme
 *   3. target_url host     — github.com, *.github.com, github.<corp>.tld (GHES)
 *   4. resource_name       — e.g. "GitHub", "GitHub Enterprise"
 *   5. resource_type       — e.g. "github"
 *
 * Matching is on WORD TOKENS, never substrings. A string is lower-cased and
 * split on every non-alphanumeric character, so:
 *      "GitHub Enterprise"  → ["github","enterprise"]   ✓ matches
 *      "iam:app/github"     → ["iam","app","github"]    ✓ matches
 *      "github-actions"     → ["github","actions"]      ✓ matches
 *      "githubbing"         → ["githubbing"]            ✗ no match
 *      "mygithubclone"      → ["mygithubclone"]         ✗ no match
 * Substring matching would have claimed the last two, which is precisely the
 * false positive that must never happen here.
 */
import { Github } from 'lucide-react';

/**
 * GitHub login rules (github.com): 1–39 characters, alphanumerics and single
 * hyphens, never starting or ending with a hyphen, never two hyphens in a row.
 */
const GITHUB_LOGIN = /^[A-Za-z0-9](?:[A-Za-z0-9]|-(?=[A-Za-z0-9])){0,38}$/;

export const PROVIDERS = {
  github: {
    id: 'github',
    label: 'GitHub',
    icon: Github,

    /* What `external_id` actually IS for this provider. Naming the field after
       the provider's own vocabulary is what stops an operator pasting a numeric
       account id where a login belongs. */
    identityLabel: 'GitHub username',
    identityPlaceholder: 'octocat',
    identityHint:
      'The login exactly as it appears on GitHub — letters, digits and single hyphens, 39 characters at most.',

    /** Public profile for an external id, used for the "open on GitHub" link. */
    profileUrl: (externalId) =>
      `https://github.com/${encodeURIComponent(String(externalId || '').trim())}`,

    /** Returns an operator-facing message, or null when the value is valid. */
    validateExternalId(value) {
      const v = String(value ?? '').trim();
      if (!v) return 'A GitHub username is required.';
      if (v.length > 39) return 'A GitHub username cannot be longer than 39 characters.';
      if (!GITHUB_LOGIN.test(v)) {
        return 'Enter a valid GitHub username — letters, digits and single hyphens only, and it cannot start or end with a hyphen.';
      }
      return null;
    },

    /** Scopes most often recorded against a GitHub mapping (suggestions only). */
    commonScopes: ['read:user', 'user:email', 'read:org', 'repo', 'workflow', 'admin:org'],

    /** Hostnames that identify this provider on a resource's target URL. */
    hosts: ['github.com'],
  },
};

/** Provider ids that have a routed integration page today. */
export const ROUTED_PROVIDER_IDS = ['github'];

/** Lower-case word tokens for any value. See the matching rules above. */
function tokenize(value) {
  return String(value ?? '')
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
}

function hasToken(value, token) {
  return tokenize(value).includes(token);
}

/**
 * Does a resource's target URL point at this provider?
 * Accepts the canonical host, any sub-domain of it, and a self-hosted instance
 * whose host carries the provider as a label (github.acme.example — GHES).
 */
function hostMatchesProvider(targetUrl, provider) {
  const raw = String(targetUrl ?? '').trim();
  if (!raw) return false;
  let host = '';
  try {
    host = new URL(raw).hostname.toLowerCase();
  } catch {
    /* Not a parseable URL — fall back to token matching on the raw string so a
       bare host ("github.com/acme") is still recognised. */
    return tokenize(raw).includes(provider.id);
  }
  if (!host) return false;
  if (provider.hosts.some((h) => host === h || host.endsWith(`.${h}`))) return true;
  // Self-hosted: the provider name appears as a whole DNS label.
  return host.split('.').includes(provider.id);
}

/**
 * Resolve the external identity provider a registry row represents.
 *
 * @param   {object} resource  a row from GET /api/v1/resources
 * @returns {object|null}      the PROVIDERS entry, or null when the row is a
 *                             plain protected resource with no provider
 */
export function detectProvider(resource) {
  if (!resource || typeof resource !== 'object') return null;

  // 1. Explicit declaration — an operator's answer beats any heuristic.
  const declared = String(resource.metadata?.provider ?? '').trim().toLowerCase();
  if (declared && PROVIDERS[declared]) return PROVIDERS[declared];

  for (const provider of Object.values(PROVIDERS)) {
    if (hasToken(resource.resource_arn, provider.id)) return provider;      // 2
    if (hostMatchesProvider(resource.target_url, provider)) return provider; // 3
    if (hasToken(resource.resource_name, provider.id)) return provider;      // 4
    if (hasToken(resource.resource_type, provider.id)) return provider;      // 5
  }
  return null;
}

/** True when the row resolves to exactly the given provider id. */
export function isProviderResource(resource, providerId) {
  return detectProvider(resource)?.id === providerId;
}

/**
 * The in-app route for a resource's integration page, or null when the row has
 * no provider (or no provider page has been routed yet). Returning null is what
 * keeps the Resources list behaving EXACTLY as it did for every other row.
 */
export function integrationPathFor(resource) {
  const provider = detectProvider(resource);
  const id = resource?.resource_id;
  if (!provider || !id) return null;
  if (!ROUTED_PROVIDER_IDS.includes(provider.id)) return null;
  return `/identity/resources/${encodeURIComponent(id)}/${provider.id}`;
}
