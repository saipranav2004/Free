package middleware

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

func hostEngine(t *testing.T, cfg TrustedHostConfig) (*gin.Engine, *[]string) {
	t.Helper()
	gin.SetMode(gin.TestMode)
	rejected := &[]string{}
	mw, err := TrustedHost(cfg, func(host, _, _, _ string) {
		*rejected = append(*rejected, host)
	}, zap.NewNop())
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	r := gin.New()
	r.Use(mw)
	r.GET("/api/health", func(c *gin.Context) { c.String(http.StatusOK, "ok") })
	r.GET("/anything", func(c *gin.Context) { c.String(http.StatusOK, "reached") })
	return r, rejected
}

func get(r *gin.Engine, host, path string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(http.MethodGet, path, nil)
	req.Host = host
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	return w
}

func TestExactHostIsAllowedAndEverythingElseIsNot(t *testing.T) {
	r, rejected := hostEngine(t, TrustedHostConfig{Hosts: []string{"pam.corp.internal"}})

	if w := get(r, "pam.corp.internal", "/anything"); w.Code != http.StatusOK {
		t.Fatalf("the configured host must be served, got %d", w.Code)
	}
	// Case and port are not part of the identity.
	if w := get(r, "PAM.Corp.Internal:8443", "/anything"); w.Code != http.StatusOK {
		t.Fatalf("host comparison must ignore case and port, got %d", w.Code)
	}
	// The two that a network control cannot see.
	for _, bad := range []string{
		"10.4.2.17",                  // found the private address
		"pam.attacker.example",       // DNS rebinding
		"evil.com",                   // Host-header poisoning of a URL we build
		"notpam.corp.internal",       // near miss
		"pam.corp.internal.evil.com", // suffix trickery
	} {
		w := get(r, bad, "/anything")
		if w.Code != http.StatusMisdirectedRequest {
			t.Errorf("%q: got %d, want 421", bad, w.Code)
		}
	}
	if len(*rejected) != 5 {
		t.Fatalf("every refusal must be auditable, got %d", len(*rejected))
	}
}

// A leading dot is a subdomain wildcard, which the brokered gateway needs. It
// deliberately does NOT include the apex: a wildcard that silently covers the
// parent is how a parked domain ends up serving a PAM console.
func TestWildcardMatchesSubdomainsButNotTheApex(t *testing.T) {
	r, _ := hostEngine(t, TrustedHostConfig{Hosts: []string{".apps.corp.internal"}})

	for _, ok := range []string{"a.apps.corp.internal", "deep.nested.apps.corp.internal"} {
		if w := get(r, ok, "/anything"); w.Code != http.StatusOK {
			t.Errorf("%q must be served, got %d", ok, w.Code)
		}
	}
	for _, bad := range []string{"apps.corp.internal", "notapps.corp.internal"} {
		if w := get(r, bad, "/anything"); w.Code != http.StatusMisdirectedRequest {
			t.Errorf("%q must be refused, got %d", bad, w.Code)
		}
	}
}

// A load balancer probes by address, not by name. An unexempted health check
// fails, the instance leaves the pool, and the control causes the outage it
// was meant to prevent.
func TestExemptPathIsServedUnderAnyHost(t *testing.T) {
	r, _ := hostEngine(t, TrustedHostConfig{
		Hosts:       []string{"pam.corp.internal"},
		ExemptPaths: []string{"/api/health"},
	})
	if w := get(r, "10.4.2.17", "/api/health"); w.Code != http.StatusOK {
		t.Fatalf("health check by address must be served, got %d", w.Code)
	}
	if w := get(r, "10.4.2.17", "/anything"); w.Code != http.StatusMisdirectedRequest {
		t.Fatalf("the exemption must not widen to other paths, got %d", w.Code)
	}
}

func TestMissingHostIsRefused(t *testing.T) {
	r, _ := hostEngine(t, TrustedHostConfig{Hosts: []string{"pam.corp.internal"}})
	if w := get(r, "", "/anything"); w.Code != http.StatusMisdirectedRequest {
		t.Fatalf("an empty Host must be refused, got %d", w.Code)
	}
}

// An empty list is a boot failure, not a deny-everything: a control that locks
// out the person who has to fix it should surface at deploy time.
func TestEmptyHostListRefusesToBuild(t *testing.T) {
	if _, err := TrustedHost(TrustedHostConfig{}, nil, zap.NewNop()); err == nil {
		t.Fatal("an empty host list must refuse to build")
	}
	// A list of nothing but blanks is the same mistake wearing a comma.
	if _, err := TrustedHost(TrustedHostConfig{Hosts: []string{" ", "", "."}}, nil, zap.NewNop()); err == nil {
		t.Fatal("a list of blanks must refuse to build")
	}
}

func TestAllowAnyHostDisablesTheCheck(t *testing.T) {
	r, _ := hostEngine(t, TrustedHostConfig{AllowAnyHost: true})
	if w := get(r, "anything.at.all", "/anything"); w.Code != http.StatusOK {
		t.Fatalf("allow_any_host must serve everything, got %d", w.Code)
	}
}
