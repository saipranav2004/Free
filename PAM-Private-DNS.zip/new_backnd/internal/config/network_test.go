package config

import (
	"strings"
	"testing"
)

// prodConfig is a config that is otherwise complete, so each test below is
// changing exactly one thing.
func prodConfig() *Config {
	c := &Config{}
	c.Server.Env = "production"
	c.Network.TrustedProxies = "10.0.0.0/8"
	c.Network.TrustedHosts = "pam.corp.internal"
	return c
}

// A private-DNS deployment has to fail at boot rather than in production
// traffic. Each case below is a configuration that looks finished and leaves
// the console answering to names it should not.

func TestProductionWithoutTrustedHostsRefusesToBoot(t *testing.T) {
	c := prodConfig()
	c.Network.TrustedHosts = ""
	err := c.validateNetwork()
	if err == nil {
		t.Fatal("expected a boot failure with no trusted hosts named")
	}
	if !strings.Contains(err.Error(), "PAM_NETWORK_TRUSTED_HOSTS") {
		t.Fatalf("the error must name the variable to set, got %q", err)
	}
}

func TestProductionWithAllowAnyHostRefusesToBoot(t *testing.T) {
	c := prodConfig()
	c.Network.AllowAnyHost = true
	if err := c.validateNetwork(); err == nil {
		t.Fatal("allow_any_host must be refused in production: it answers to a raw IP")
	}
}

// TRUSTED PROXIES DID NOT LEAVE WITH THE ALLOWLIST. It decides whether
// X-Forwarded-For can be believed, and therefore whether any SourceIP in the
// audit trail is a fact or a value the client picked. A private deployment
// always has a load balancer in front, so it matters more, not less.
func TestProductionWithoutATrustedProxyDecisionRefusesToBoot(t *testing.T) {
	c := prodConfig()
	c.Network.TrustedProxies = ""
	err := c.validateNetwork()
	if err == nil {
		t.Fatal("expected a boot failure with the trusted-proxy question unanswered")
	}
	if !strings.Contains(err.Error(), "PAM_NETWORK_TRUSTED_PROXIES") {
		t.Fatalf("the error must name the variable to set, got %q", err)
	}
}

// "none" is the explicit answer, not a missing one.
func TestTrustedProxiesNoneIsAnAnswer(t *testing.T) {
	c := prodConfig()
	c.Network.TrustedProxies = "none"
	if err := c.validateNetwork(); err != nil {
		t.Fatalf("\"none\" is a deliberate answer and must boot: %v", err)
	}
}

func TestCompleteProductionConfigurationBoots(t *testing.T) {
	if err := prodConfig().validateNetwork(); err != nil {
		t.Fatalf("a complete configuration must boot: %v", err)
	}
}

// A laptop should not have to name a DNS zone to show a login page.
func TestOutsideProductionNothingIsRequired(t *testing.T) {
	c := &Config{}
	c.Server.Env = "development"
	c.Network.AllowAnyHost = true
	if err := c.validateNetwork(); err != nil {
		t.Fatalf("development must not require a perimeter: %v", err)
	}
}

func TestTrustedProxyParsing(t *testing.T) {
	cases := []struct {
		in   string
		want []string
	}{
		{"none", nil},
		{"NONE", nil},
		{"  ", nil},
		{"10.0.0.0/8", []string{"10.0.0.0/8"}},
		{"10.0.0.0/8, 172.16.0.0/12", []string{"10.0.0.0/8", "172.16.0.0/12"}},
		{"10.0.0.0/8\n172.16.0.0/12", []string{"10.0.0.0/8", "172.16.0.0/12"}},
	}
	for _, tc := range cases {
		got := NetworkConfig{TrustedProxies: tc.in}.TrustedProxyCIDRs()
		if len(got) != len(tc.want) {
			t.Fatalf("%q -> %v, want %v", tc.in, got, tc.want)
		}
		for i := range got {
			if got[i] != tc.want[i] {
				t.Fatalf("%q -> %v, want %v", tc.in, got, tc.want)
			}
		}
	}
}

// The reason every list is a string: a comma-separated env var must not become
// one nonsense entry.
func TestCommaSeparatedEnvValueSplitsIntoSeparateHosts(t *testing.T) {
	n := NetworkConfig{TrustedHosts: "pam.corp.internal,pam-api.corp.internal , .apps.corp.internal"}
	got := n.TrustedHostList()
	if len(got) != 3 {
		t.Fatalf("want 3 hosts, got %d: %v", len(got), got)
	}
	if got[1] != "pam-api.corp.internal" {
		t.Fatalf("entries must be trimmed, got %q", got[1])
	}
}
