package config

import (
	"bufio"
	"os"
	"strings"
	"testing"
)

// Every key named in .env.example must be one the server actually reads, and
// every key the server reads must be in .env.example. A drifting example file
// is worse than none: it teaches settings that do nothing.
func TestEnvExampleMatchesTheConfigSurface(t *testing.T) {
	f, err := os.Open("../../.env.example")
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer f.Close()

	inExample := map[string]bool{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if k, _, ok := strings.Cut(line, "="); ok {
			inExample[strings.TrimSpace(k)] = true
		}
	}

	src, err := os.ReadFile("config.go")
	if err != nil {
		t.Fatalf("read config.go: %v", err)
	}
	known := map[string]bool{}
	for _, part := range strings.Split(string(src), `v.SetDefault("`)[1:] {
		key, _, _ := strings.Cut(part, `"`)
		known["PAM_"+strings.ToUpper(strings.ReplaceAll(key, ".", "_"))] = true
	}

	for k := range inExample {
		if !known[k] {
			t.Errorf("%s is in .env.example but the server never reads it", k)
		}
	}
	for k := range known {
		if !inExample[k] {
			t.Errorf("%s is read by the server but missing from .env.example", k)
		}
	}
}
