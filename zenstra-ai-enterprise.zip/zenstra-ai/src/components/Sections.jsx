/* Building blocks shared by the platform, capability and use-case pages, so every
   page has the same rhythm, type scale and card language. */
import A from './A.jsx';
import Icon from './Icon.jsx';
import Two from './Two.jsx';
import { StatBand } from './Motion.jsx';
import { CAPABILITIES, USE_CASES, INDUSTRIES, capabilityPath, useCasePath } from '../content/site.js';

export const Arrow = () => (<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" /></svg>);

export { Two };

const SHOTS = {
  overview: ['screen-overview', 1600, 1000], detections: ['screen-detections', 1600, 1000], investigation: ['screen-investigation', 1600, 1000], agent: ['screen-agent', 1600, 1000],
  coverage: ['crop-coverage', 687, 404], grants: ['crop-grants', 1206, 411], kpis: ['crop-kpis', 1740, 186], riskiest: ['crop-riskiest', 1031, 546], run: ['crop-run', 1206, 1025],
};
const SHOT_ALT = {
  overview: 'Zenstra console overview', detections: 'Detections ranked by severity', investigation: 'An investigation in the Zenstra console', agent: 'An agent profile in the Zenstra console',
  coverage: 'Coverage by platform: governed versus discovered agents', grants: 'Tool grants with scope, expiry and last use', kpis: 'Agents governed, open detections, actions blocked and approvals waiting', riskiest: 'Highest-risk agents with risk score, main factor and owner', run: 'An agent run blocked by policy after a failed intent check',
};

/* A real console screen in a framed card, light and dark versions. */
export function Shot({ name, eager, className = '' }) {
  const [file, w, h] = SHOTS[name] || SHOTS.overview;
  const load = eager ? 'eager' : 'lazy';
  return (
    <figure className={'shot ' + className + (h / w < 0.3 ? ' strip' : '')}>
      <div className="shot-chrome" aria-hidden="true"><i /><i /><i /><span>console.zenstra.ai</span></div>
      <img className="th-light" src={'/img/' + file + '-light.webp'} alt={SHOT_ALT[name]} width={w} height={h} loading={load} />
      <img className="th-dark" src={'/img/' + file + '-dark.webp'} alt={SHOT_ALT[name]} width={w} height={h} loading={load} />
    </figure>
  );
}

const CHIP_IC = {
  block: <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="8" cy="8" r="6" /><path d="M4 12 12 4" /></svg>,
  hold: <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="8" cy="8" r="6" /><path d="M8 5v3.5l2 1.5" /></svg>,
  allow: <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="m3.5 8.5 3 3 6-7" /></svg>,
};

/* A console screen cropped to a card thumbnail (no window chrome). */
export function Thumb({ name }) {
  const [file] = SHOTS[name] || SHOTS.overview;
  return (
    <span className="thumb" aria-hidden="true">
      <img className="th-light" src={'/img/' + file + '-light.webp'} alt="" loading="lazy" decoding="async" />
      <img className="th-dark" src={'/img/' + file + '-dark.webp'} alt="" loading="lazy" decoding="async" />
    </span>
  );
}

/* Hero visual: a console screen with live decision chips floating over it. */
export function HeroVisual({ shot, chips }) {
  return (
    <div className="pv" aria-hidden="true">
      <Shot name={shot} eager className="pv-shot" />
      <div className="pv-chips">
        {chips.map((c, i) => (
          <div key={i} className={'dchip ' + c[0]} data-fixed="">
            <span className="ic">{CHIP_IC[c[0]]}</span><span><b>{c[1]}</b><small>{c[2]}</small></span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* Page hero shared by the platform, capability and use-case pages. The demo request
   lives in the header and at the end of the page, so the hero leads into the page
   itself instead of repeating it. */
export function PageHero({ eyebrow, icon, title, lede, visual, ctas }) {
  return (
    <section className="phero rails" aria-labelledby="hero-h">
      <div className="lens" data-cx="0.74" data-cy="0.46" aria-hidden="true"></div>
      <div className="wrap phero-grid">
        <div className="phero-copy" data-lens-mask="">
          <span className="eyebrow" data-after="">{icon ? <Icon name={icon} className="eb-ic" /> : null}{eyebrow}</span>
          <h1 className="display" id="hero-h" data-scan="">
            <span className="scanline"><span className="in">{title[0]}</span><i className="bar"></i></span>
            <span className="scanline"><span className="in grad">{title[1]}</span><i className="bar"></i></span>
          </h1>
          <p className="lede" data-after="">{lede}</p>
          <div className="ctas" data-after="">
            {ctas || (<><a href="#how" className="btn primary lg">See how it works <Arrow /></a><A to="/platform" className="btn secondary lg">Platform overview</A></>)}
          </div>
        </div>
        <div className="phero-side" data-after="">{visual}</div>
      </div>
    </section>
  );
}

/* Centred problem statement with three icon cards. */
export function Problem({ eyebrow = 'The problem', h, p, cards }) {
  return (
    <section className="sec" aria-labelledby="problem-h">
      <div className="wrap">
        <div className="sec-head center">
          <span className="eyebrow" data-reveal="">{eyebrow}</span>
          <h2 className="h2" id="problem-h" data-reveal=""><Two t={h} /></h2>
          <p className="lede" data-words="">{p}</p>
        </div>
        <div className="icards">
          {cards.map((c, i) => (
            <div className="icard" key={c.h} data-reveal="" data-delay={i * 90}>
              <span className="icard-ic"><Icon name={c.icon} /></span>
              <h3>{c.h}</h3>
              <p>{c.p}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const VERDICT = { block: 'Block', hold: 'Hold', allow: 'Allow' };

/* The problem, told as one real attack path: who acts at each step, and the
   decision Zenstra makes at the end. The industry references name the risk. */
export function AttackPath({ eyebrow = 'The problem', problem, path, refs }) {
  return (
    <section className="sec brief" aria-labelledby="problem-h">
      <div className="wrap brief-grid">
        <div className="brief-copy">
          <span className="eyebrow" data-reveal="">{eyebrow}</span>
          <h2 className="h2" id="problem-h" data-reveal=""><Two t={problem.h} /></h2>
          <p className="lede" data-reveal="">{problem.p}</p>
          <ul className="brief-points">
            {problem.cards.map((c, i) => (
              <li key={c.h} data-reveal="" data-delay={i * 80}>
                <span className="brief-ic"><Icon name={c.icon} /></span>
                <span><b>{c.h}</b>{c.p}</span>
              </li>
            ))}
          </ul>
        </div>
        <figure className="apath" data-reveal="">
          <figcaption className="apath-head"><span className="apath-k">A real path</span><b>{path.h}</b></figcaption>
          <ol className="apath-steps">
            {path.steps.map((s, i) => (
              <li key={i}><span className="apath-n">{i + 1}</span><span><code>{s.who}</code>{s.t}</span></li>
            ))}
            <li className={'apath-v ' + path.verdict.k}>
              <span className="apath-n" aria-hidden="true">{CHIP_IC[path.verdict.k]}</span>
              <span><span className={'vd2 ' + (path.verdict.k === 'block' ? 'bad' : path.verdict.k === 'hold' ? 'hold' : 'ok')}>{VERDICT[path.verdict.k]}</span>{path.verdict.t}<code className="apath-tag">{path.verdict.tag}</code></span>
            </li>
          </ol>
          <div className="apath-refs">
            <span className="apath-refs-l">Industry references</span>
            <ul>{refs.map(([f, id, name]) => <li key={f + id}><b>{id}</b><span>{name}</span><small>{f}</small></li>)}</ul>
          </div>
        </figure>
      </div>
    </section>
  );
}

/* How Zenstra handles it: numbered rows, each with its own console screen,
   alternating sides so the page reads as a sequence, not a grid. */
export function FeatureRows({ id = 'how', eyebrow = 'How Zenstra handles it', h, p, tabs }) {
  return (
    <section className="sec frows-sec" id={id} aria-labelledby={id + '-h'}>
      <div className="wrap">
        <div className="sec-head split">
          <div style={{ display: 'grid', gap: 20 }}>
            <span className="eyebrow" data-reveal="">{eyebrow}</span>
            <h2 className="h2" id={id + '-h'} data-reveal=""><Two t={h} /></h2>
          </div>
          <p className="lede" data-reveal="">{p}</p>
        </div>
        <div className="frows">
          {tabs.map((t, k) => (
            <article className={'frow' + (k % 2 ? ' flip' : '')} key={t.label} aria-labelledby={id + '-r' + k}>
              <div className="frow-copy" data-reveal="">
                <span className="frow-n">{String(k + 1).padStart(2, '0')} · {t.label}</span>
                <h3 className="h3" id={id + '-r' + k}>{t.h}</h3>
                <p>{t.p}</p>
                <ul className="how-feats">{t.feats.map((f) => <li key={f}><Icon name="check" />{f}</li>)}</ul>
              </div>
              <div className="frow-media" data-reveal="" data-delay="120"><Shot name={t.shot} /></div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

const VERB_CLASS = { allow: 'a', hold: 'h', deny: 'b', record: 'r' };

/* The policy behind the page, as Zenstra reads it. */
export function PolicyPanel({ policy, title = ['The policy', 'behind it.'] }) {
  const ledger = policy.lines.every((l) => l[0] === 'record');
  return (
    <section className="sec alt pol-sec" aria-labelledby="pol-h">
      <div className="wrap pol-grid">
        <div className="pol-copy">
          <span className="eyebrow" data-reveal="">{ledger ? 'On the record' : 'Policy as code'}</span>
          <h2 className="h2" id="pol-h" data-reveal=""><Two t={ledger ? ['The evidence,', 'as it is kept.'] : title} /></h2>
          <p className="lede" data-reveal="">{policy.p}</p>
          <ul className="pol-facts" data-reveal="">
            {ledger ? (<><li>Tamper-evident</li><li>Every action, not just alerts</li><li>Export as PDF and CSV</li></>)
              : (<><li>Decided inline at 18 ms p95</li><li>Fails closed</li><li>Versioned with every decision</li></>)}
          </ul>
        </div>
        <div className={'pol-code' + (ledger ? ' ledger' : '')} data-reveal="" data-delay="100">
          <div className="pol-bar" aria-hidden="true"><i /><i /><i /><span>{policy.file}</span></div>
          <pre><code>
            {policy.lines.map((l, i) => (
              <span className="pl" key={i}><span className="pl-n" aria-hidden="true">{i + 1}</span>{ledger ? null : <b className={'pverb ' + VERB_CLASS[l[0]]}>{l[0]}</b>}<span className="pt">{l[1]}</span><span className="pc">{l[2]}</span></span>
            ))}
          </code></pre>
        </div>
      </div>
    </section>
  );
}

/* Scenarios as a still, numbered grid: read at a glance, nothing moving. */
export function Grid({ eyebrow, h, items }) {
  return (
    <section className="sec" aria-labelledby="grid-h">
      <div className="wrap">
        <div className="sec-head">
          <span className="eyebrow" data-reveal="">{eyebrow}</span>
          <h2 className="h2" id="grid-h" data-reveal=""><Two t={h} /></h2>
        </div>
        <ol className="scen-grid">
          {items.map((x, i) => (
            <li key={x.h} data-reveal="" data-delay={(i % 3) * 80}>
              <span className="scen-n">{String(i + 1).padStart(2, '0')}</span>
              <h3>{x.h}</h3>
              <p>{x.p}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* Proof: the numbers as a still row, then the certifications. */
export function Proof({ h = ['Built for regulated', 'environments.'], p = 'Every control runs inline, before a tool call executes, and leaves evidence your auditors can read.' }) {
  return (
    <section className="sec proof" aria-labelledby="proof-h">
      <div className="wrap">
        <div className="sec-head">
          <span className="eyebrow" data-reveal="">Why teams choose Zenstra</span>
          <h2 className="h2" id="proof-h" data-reveal=""><Two t={h} /></h2>
          <p className="lede" data-reveal="">{p}</p>
        </div>
        <StatBand />
        <ul className="certs-line" data-reveal="" aria-label="Certifications">
          <li>SOC 2 Type II</li><li>ISO/IEC 27001</li><li>ISO/IEC 42001</li><li>ISO/IEC 27701</li><li>HIPAA and GDPR programmes</li>
        </ul>
      </div>
    </section>
  );
}

function linkFor(kind, slug) {
  if (kind === 'cap') { const c = CAPABILITIES.find((x) => x.slug === slug); return c && { to: capabilityPath(slug), tag: 'Capability', name: c.name.charAt(0).toUpperCase() + c.name.slice(1), short: c.short, icon: c.icon }; }
  if (kind === 'use') { const u = USE_CASES.find((x) => x.slug === slug); return u && { to: useCasePath(slug), tag: 'Use case', name: u.name, short: u.short, icon: u.icon }; }
  const n = INDUSTRIES.find((x) => x.to === '/' + slug); return n && { to: n.to, tag: 'Industry', name: n.name, short: n.short, icon: n.icon };
}

/* "Explore more": cross-links that make the site feel like one system. */
export function Related({ items, h = ['Keep', 'exploring.'] }) {
  const links = items.map(([k, s]) => linkFor(k, s)).filter(Boolean);
  return (
    <section className="sec" aria-labelledby="rel-h">
      <div className="wrap">
        <div className="sec-head">
          <span className="eyebrow" data-reveal="">Related</span>
          <h2 className="h2" id="rel-h" data-reveal=""><Two t={h} /></h2>
        </div>
        <div className="rel">
          {links.map((l, i) => (
            <A key={l.to} to={l.to} className="rel-card" data-reveal="" data-delay={i * 90}>
              <span className="rel-top"><span className="mm-ic"><Icon name={l.icon} /></span><span className="mono-label">{l.tag}</span></span>
              <b>{l.name}</b>
              <small>{l.short}</small>
              <span className="link">Learn more <Arrow /></span>
            </A>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Faq({ items, h = 'Common questions.' }) {
  return (
    <section className="sec alt" aria-labelledby="faq-h">
      <div className="wrap faq">
        <div style={{ display: 'grid', gap: 18, alignContent: 'start' }}><span className="eyebrow" data-reveal="">FAQ</span><h2 className="h2" id="faq-h" style={{ fontSize: 'clamp(28px,3vw,42px)' }} data-reveal="">{h}</h2></div>
        <div data-reveal="">
          {items.map((f) => (<details key={f.q}><summary>{f.q}</summary><div className="a"><p>{f.a}</p></div></details>))}
        </div>
      </div>
    </section>
  );
}

/* The one closing call to action on inner pages: a quiet band, not a second hero.
   (The home page ends with the full-width version.) */
export function NextSteps({ h = 'See it on your own agents.', p = 'A 30-minute technical session with a Zenstra security engineer, run against one of your agents.' }) {
  return (
    <section className="next-sec" aria-labelledby="next-h">
      <div className="wrap">
        <div className="next" data-reveal="">
          <div className="next-copy">
            <h2 className="next-h" id="next-h">{h}</h2>
            <p>{p}</p>
          </div>
          <div className="next-act">
            <A to="/demo" className="btn primary lg">Request a demo <Arrow /></A>
            <a className="next-mail" href="mailto:info@zenstra.ai">or email info@zenstra.ai</a>
          </div>
        </div>
      </div>
    </section>
  );
}
