import A from './A.jsx';

/* The Zenstra core: a pinned, scroll-driven exploded view of the platform
   (lib/core5.js draws it on the canvas; the page mounts it with useCore). */
export default function Core() {
  return (
    <section className="core" id="core" data-core="" aria-labelledby="core-h">
    <div className="wrap core-head">
    <div style={{ display: "grid", gap: "20px" }}><span className="eyebrow" data-reveal="">Inside the Zenstra core</span><h2 className="h2" id="core-h" data-reveal="">Secure every agent.<br />Verify every intent.</h2></div>
    <p className="lede" data-reveal="">Agents work inside workflows, in your cloud and on every laptop. Take the core apart to see where each attack is stopped, and what lands on the record.</p>
    </div>
    <div className="core-track">
    <div className="core-pin">
    <div className="core-stage">
    <canvas aria-hidden="true"></canvas>
    <div className="core-labels" aria-hidden="true">
    <span className="core-label"><b>Policy engine</b><small>Decides inline</small></span>
    <span className="core-label"><b>Workflow Security</b><small>Stops injected hand-offs</small></span>
    <span className="core-label"><b>Cloud Security</b><small>Payloads stay in your VPC</small></span>
    <span className="core-label"><b>Zenstra EDR</b><small>Contains hijacked agents</small></span>
    <span className="core-label"><b>Decision record</b><small>Tamper-evident</small></span>
    </div>
    </div>
    <div className="core-cards">
    <article className="core-card pos-tl on" data-name="The exposure"><div className="cc"><span className="cc-n">The exposure</span><h3>Agents act faster than your controls.</h3><p>They read documents, call tools and move data inside workflows, in your cloud and on every laptop. The same few attacks reach all three.</p><div className="cc-tags threat"><span>Prompt injection</span><span>Tool poisoning</span><span>Credential leakage</span><span>Shadow AI</span></div></div></article>
    <article className="core-card pos-br" data-name="One policy engine"><div className="cc"><span className="cc-n">One policy engine</span><h3>One engine decides every action.</h3><p>Each action is checked against the agent’s identity, the task it was given and your policy, inline, before it runs.</p><pre className="cc-code"><span><b>{"deny"}</b>{"  tool.call   when outside(task.scope)"}</span><span><b>{"hold"}</b>{"  payments.*  for human approval"}</span><span><b>{"allow"}</b>{" crm.read    for member in task"}</span></pre><p className="cc-facts">Inline · p95 18 ms · Fails closed</p></div></article>
    <article className="core-card pos-br" data-name="Workflow Security"><div className="cc"><span className="cc-n">Workflow Security</span><h3>Every hop, checked against its task.</h3><dl className="cc-rows"><div><dt>Runs in</dt><dd>n8n, Zapier, LangGraph, CrewAI, Copilot Studio</dd></div><div><dt>Checks</dt><dd>Every hop and agent-to-agent hand-off</dd></div><div><dt>Stops</dt><dd>Injected instructions spreading between agents</dd></div></dl><p className="cc-dec"><span className="vd2 bad">Block</span><code>hop 7 · crm.export → outside email · not in task</code></p></div></article>
    <article className="core-card pos-tl" data-name="Cloud Security"><div className="cc"><span className="cc-n">Cloud Security</span><h3>A gateway inside your cloud.</h3><dl className="cc-rows"><div><dt>Runs in</dt><dd>Your VPC on AWS, Azure or Google Cloud</dd></div><div><dt>Checks</dt><dd>Every MCP, model and API call against the agent’s grant</dd></div><div><dt>Stops</dt><dd>Tool poisoning, over-scoped keys, data leaving your cloud</dd></div></dl><p className="cc-dec"><span className="vd2 bad">Block</span><code>mcp core-banking · accounts.transfer · not in grant</code></p><p className="cc-facts">Prompts and payloads never leave your VPC</p></div></article>
    <article className="core-card pos-br" data-name="Zenstra EDR"><div className="cc"><span className="cc-n">Zenstra EDR</span><h3>AI on every laptop, contained in seconds.</h3><dl className="cc-rows"><div><dt>Runs on</dt><dd>Windows and macOS, through Intune, Jamf or Kandji</dd></div><div><dt>Checks</dt><dd>Copilot, ChatGPT, Claude Code and Cursor: prompt, tool call and device together</dd></div><div><dt>Stops</dt><dd>Hijacked coding agents, secrets pasted into AI, shadow AI</dd></div></dl><p className="cc-dec"><span className="vd2 bad">Block</span><code>laptop-114 · cursor · read ~/.aws · session contained</code></p></div></article>
    <article className="core-card pos-tr" data-name="The record"><div className="cc"><span className="cc-n">The record</span><h3>Every decision, on one record.</h3><p>Each entry is chained to the one before it, so any change shows. Export it as evidence for your auditors and examiners.</p><pre className="cc-code ledger"><span>{"#48213  "}<i className="b">{"block"}</i>{"  POL-114 v7   prev 9f2c…a71e"}</span><span>{"#48214  "}<i className="h">{"hold"}</i>{"   POL-021 v3   prev c07a…5d12"}</span><span>{"#48215  "}<i className="a">{"allow"}</i>{"  POL-003 v12  prev 4be1…09c3"}</span></pre><p className="cc-facts">Hash-chained · Exported as PDF and CSV</p><A to="/platform/decision-record" className="cc-link">See the decision record{" "}<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"></path></svg></A></div></article>
    </div>
    <div className="core-hud" aria-hidden="true"><span data-core-n="">01 / 06</span><span data-core-t="">The exposure</span><i></i></div>
    </div>
    </div>
    </section>
  );
}
