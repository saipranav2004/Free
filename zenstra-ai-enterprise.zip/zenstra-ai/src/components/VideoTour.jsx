import { useEffect, useRef, useState } from 'react';
import { PRODUCT_VIDEO } from '../content/media.js';

/* The product video (configured in content/media.js), shown as a card on the home
   page right after the hero. */
export function useHasVideo() {
  return !!PRODUCT_VIDEO.src;
}

/* The video card on the home page: a poster with one play button. The video plays
   in place once PRODUCT_VIDEO.src is set; until then the button is static. */
export function ProductVideo() {
  const ok = useHasVideo();
  const [playing, setPlaying] = useState(false);
  const vid = useRef(null);
  // Start as soon as the player replaces the poster (the click is the user's gesture).
  useEffect(() => { if (playing && vid.current) vid.current.play().catch(() => {}); }, [playing]);
  return (
    <div className="pvid" data-reveal="">
      {playing ? (
        <video ref={vid} src={PRODUCT_VIDEO.src} poster={PRODUCT_VIDEO.poster} controls playsInline aria-label={PRODUCT_VIDEO.title} />
      ) : (
        <>
          <div className="pvid-poster" aria-hidden="true">
            <img className="th-light" src="/img/screen-overview-light.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" />
            <img className="th-dark" src="/img/screen-overview-dark.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" />
          </div>
          <div className="pvid-shade" aria-hidden="true" />
          <button type="button" className="pvid-play" disabled={!ok} onClick={() => setPlaying(true)} aria-label={'Play the ' + PRODUCT_VIDEO.title.toLowerCase()}>
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 4.5v15a1 1 0 0 0 1.5.86l12.5-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5Z" /></svg>
          </button>
          <div className="pvid-cap"><b>{PRODUCT_VIDEO.title}</b><span>{PRODUCT_VIDEO.length}</span></div>
        </>
      )}
    </div>
  );
}
