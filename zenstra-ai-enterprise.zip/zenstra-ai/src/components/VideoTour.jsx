import { useEffect, useRef, useState } from 'react';
import Icon from './Icon.jsx';
import { PRODUCT_VIDEO } from '../content/media.js';
import { reduced } from '../lib/env.js';

/* The product video (configured in content/media.js): once set, "Watch the product
   tour" appears on the home console and on the platform page, opening a player. */
export function useHasVideo() {
  return !!PRODUCT_VIDEO.src;
}

/* Play button and the dialog it opens. Renders nothing until the video exists. */
export function VideoButton({ className = '' }) {
  const ok = useHasVideo();
  const [open, setOpen] = useState(false);
  const dlg = useRef(null), vid = useRef(null), btn = useRef(null);
  useEffect(() => {
    const d = dlg.current; if (!d) return;
    if (open && !d.open) { d.showModal(); if (vid.current) vid.current.play().catch(() => {}); }
    if (!open && d.open) d.close();
  }, [open]);
  if (!ok) return null;
  const close = () => { if (vid.current) vid.current.pause(); setOpen(false); if (btn.current) btn.current.focus(); };
  return (
    <>
      <button ref={btn} type="button" className={'vt-play ' + className} onClick={() => setOpen(true)} aria-haspopup="dialog">
        <span className="vt-play-ic"><Icon name="play" /></span>
        <span><b>Watch the product tour</b><small>{PRODUCT_VIDEO.length}</small></span>
      </button>
      <dialog ref={dlg} className="vt-dialog" aria-label={PRODUCT_VIDEO.title} onClose={() => { if (vid.current) vid.current.pause(); setOpen(false); }} onClick={(e) => { if (e.target === dlg.current) close(); }}>
        <button type="button" className="vt-close" onClick={close} aria-label="Close video">
          <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true"><path d="m3 3 6 6M9 3 3 9" /></svg>
        </button>
        <video ref={vid} src={open ? PRODUCT_VIDEO.src : undefined} poster={PRODUCT_VIDEO.poster} controls playsInline preload="none" />
      </dialog>
    </>
  );
}

/* The video card on the home page: a poster with one play button. The video plays
   in place once PRODUCT_VIDEO.src is set; until then the button is static. */
export function ProductVideo() {
  const ok = useHasVideo();
  const [playing, setPlaying] = useState(false);
  const vid = useRef(null);
  // Start as soon as the player replaces the poster (the click is the user's gesture).
  useEffect(() => { if (playing && vid.current) vid.current.play().catch(() => {}); }, [playing]);
  return (
    <div className="pvid" data-reveal="">
      {playing ? (
        <video ref={vid} src={PRODUCT_VIDEO.src} poster={PRODUCT_VIDEO.poster} controls playsInline aria-label={PRODUCT_VIDEO.title} />
      ) : (
        <>
          <div className="pvid-poster" aria-hidden="true">
            <img className="th-light" src="/img/screen-overview-light.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" />
            <img className="th-dark" src="/img/screen-overview-dark.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" />
          </div>
          <div className="pvid-shade" aria-hidden="true" />
          <button type="button" className="pvid-play" disabled={!ok} onClick={() => setPlaying(true)} aria-label={'Play the ' + PRODUCT_VIDEO.title.toLowerCase()}>
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 4.5v15a1 1 0 0 0 1.5.86l12.5-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5Z" /></svg>
          </button>
          <div className="pvid-cap"><b>{PRODUCT_VIDEO.title}</b><span>{PRODUCT_VIDEO.length}</span></div>
        </>
      )}
    </div>
  );
}

/* Framed slot: a quiet tour of real console screens, with the play button on top
   once the video is in place. */
const SCREENS = [['overview', 'Overview'], ['detections', 'Detections'], ['investigation', 'Investigation'], ['agent', 'Agent profile']];
export default function VideoTour() {
  const ok = useHasVideo();
  const [i, setI] = useState(0);
  useEffect(() => {
    if (reduced()) return undefined;
    const id = setInterval(() => { if (!document.hidden) setI((n) => (n + 1) % SCREENS.length); }, 4200);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="vt-frame" data-reveal="">
      <div className="vt-chrome" aria-hidden="true"><i /><i /><i /><span>console.zenstra.ai</span></div>
      <div className="vt-stage">
        {SCREENS.map(([s], k) => (
          <div key={s} className={'vt-shot' + (k === i ? ' on' : '')} aria-hidden={k === 0 ? undefined : true}>
            <img className="th-light" src={'/img/screen-' + s + '-light.webp'} alt={k === 0 ? 'The Zenstra console' : ''} loading="lazy" width="1600" height="1000" />
            <img className="th-dark" src={'/img/screen-' + s + '-dark.webp'} alt={k === 0 ? 'The Zenstra console' : ''} loading="lazy" width="1600" height="1000" />
          </div>
        ))}
        <div className="vt-shade" aria-hidden="true" />
        {ok ? null : <div className="vt-cap" aria-hidden="true"><span className="vt-dot" />{SCREENS[i][1]}</div>}
        <VideoButton />
      </div>
    </div>
  );
}
