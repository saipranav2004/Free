/* The product video. To publish it:
     1. put the file at public/media/zenstra-product-tour.mp4 (H.264 MP4 plays everywhere)
     2. set src below to '/media/zenstra-product-tour.mp4' and length to its running
        time, for example '2 min'
     3. rebuild
   The home page shows a video card right after the hero; its play button starts the
   video in place once src is set (until then the card shows the poster and a static
   play button). The platform page's console section also gets a "Watch the product
   tour" button. */
export const PRODUCT_VIDEO = {
  src: null,
  poster: '/img/screen-overview-dark.webp',
  title: 'Zenstra product tour',
  length: 'Product walkthrough',
};
