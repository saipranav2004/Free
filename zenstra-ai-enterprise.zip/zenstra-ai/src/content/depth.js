/* What makes each capability and use-case page its own: one real attack path told
   step by step and ending in the decision Zenstra makes, the industry references
   for that risk, and the policy that stops it.

   path    who acts at each step, what happens, and Zenstra's decision at the end
   refs    [framework, identifier, name]: the risk this page addresses, as named by
           OWASP (Top 10 for LLM Applications 2025, Top 10 for Agentic Applications
           2026), MITRE ATLAS and NIST. They describe the risk, not a certification.
   policy  the rules behind the decision, in Zenstra's policy language
           (allow / hold / deny, a target and a condition; `record` lines are
           entries on the decision record). */

const OWASP_LLM = 'OWASP Top 10 for LLMs';
const OWASP_AGENT = 'OWASP Top 10 for Agentic Apps';
const ATLAS = 'MITRE ATLAS';
const NIST = 'NIST AI RMF';
const ISO = 'International standard';

export const DEPTH = {
  'agent-discovery': {
    path: {
      h: 'A flow nobody registered starts writing to core.',
      steps: [
        { who: 'n8n', t: 'A team builds a card-dispute automation in n8n and connects it to the core platform.' },
        { who: 'core API', t: 'The flow starts writing dispute records with a shared service key.' },
        { who: 'Zenstra', t: 'Workflow Security maps the new flow: an agent with write access and no owner on record.' },
      ],
      verdict: { k: 'hold', t: 'Writes to core wait until an owner and a scope are on record.', tag: 'n8n:card-dispute · write:core' },
    },
    refs: [[OWASP_AGENT, 'ASI10', 'Rogue Agents'], [NIST, 'GOVERN 1.6', 'AI system inventory'], [ISO, 'ISO/IEC 42001', 'AI management system']],
    policy: {
      file: 'policies/inventory.zen',
      p: 'An agent counts as governed once it has an owner, a declared task and the grants it needs. Until then, policy decides what it may do.',
      lines: [['hold', 'agent.*', 'when owner is none'], ['deny', 'core.write', 'for agents not in inventory'], ['hold', 'mcp.server.new', 'until reviewed'], ['allow', 'agent.run', 'when owner and scope are set']],
    },
  },

  'agent-identity': {
    path: {
      h: 'A copilot is asked to send a record outside.',
      steps: [
        { who: 'copilot-hr-assist', t: 'The agent starts and is attested: its identity, its owner and its declared task.' },
        { who: 'grant', t: 'It receives a 15-minute grant to read the HR record of the employee in the ticket.' },
        { who: 'document', t: 'A document in the ticket asks it to email that record to an outside address.' },
      ],
      verdict: { k: 'block', t: 'email.send is outside the grant: the domain is not approved.', tag: 'copilot-hr-assist · email.send' },
    },
    refs: [[OWASP_AGENT, 'ASI03', 'Identity and Privilege Abuse'], [OWASP_LLM, 'LLM06:2025', 'Excessive Agency'], [ATLAS, 'AML.T0055', 'Unsecured Credentials']],
    policy: {
      file: 'policies/identity.zen',
      p: 'No standing credentials: each grant names one agent, one scope and an expiry, and anything outside it is refused.',
      lines: [['deny', '*', 'when identity is not attested'], ['allow', 'hris.read', 'for employee in task · expires 15m'], ['deny', 'email.send', 'when domain not in approved_domains'], ['hold', 'shell.exec', 'in prod · step-up required']],
    },
  },

  'runtime-enforcement': {
    path: {
      h: 'An agent asks for more data than its task needs.',
      steps: [
        { who: 'sar-prep-agent', t: 'The agent is asked to prepare a suspicious activity report for one member.' },
        { who: 'plan', t: 'It plans core.txn.query across 90 days of transactions.' },
        { who: 'Zenstra', t: 'The policy engine checks identity, task and policy inline, before the query runs.' },
      ],
      verdict: { k: 'hold', t: 'Held for a person to approve. Decided in 18 ms, before anything ran.', tag: 'sar-prep-agent · core.txn.query (90d)' },
    },
    refs: [[OWASP_LLM, 'LLM06:2025', 'Excessive Agency'], [OWASP_AGENT, 'ASI02', 'Tool Misuse and Exploitation'], [ATLAS, 'AML.T0053', 'AI Agent Tool Invocation']],
    policy: {
      file: 'policies/runtime.zen',
      p: 'One engine and one rulebook for every agent. Routine actions pass, sensitive ones wait for a person, anything outside policy is stopped.',
      lines: [['deny', 'tool.call', 'when outside(task.scope)'], ['hold', 'payments.*', 'for human approval'], ['hold', 'core.txn.query', 'when range > 30d'], ['allow', 'crm.read', 'for member in task']],
    },
  },

  'mcp-security': {
    path: {
      h: 'A tool update tries to move money.',
      steps: [
        { who: 'member-chat-assist', t: 'The agent calls kb.search through the gateway in your VPC.' },
        { who: 'mcp kb-sync', t: 'A new version of the server adds an instruction to call accounts.transfer.' },
        { who: 'gateway', t: 'The call is checked against the agent’s grant, inside your cloud. Transfers are not in it.' },
      ],
      verdict: { k: 'block', t: 'Tool not in grant. The call never reaches core banking.', tag: 'mcp core-banking · accounts.transfer' },
    },
    refs: [[OWASP_AGENT, 'ASI04', 'Agentic Supply Chain Vulnerabilities'], [OWASP_AGENT, 'ASI02', 'Tool Misuse and Exploitation'], [ATLAS, 'AML.T0110', 'AI Agent Tool Poisoning']],
    policy: {
      file: 'policies/mcp.zen',
      p: 'Every MCP server, model and API sits behind one gateway. Each tool is a grant, and instructions hidden in tool content are quarantined.',
      lines: [['deny', 'mcp.call', 'when tool not in grant'], ['deny', 'tool.result', 'when it carries instructions · quarantine'], ['hold', 'mcp.server', 'when new or changed'], ['allow', 'kb.search', 'for member-faq']],
    },
  },

  'detection-response': {
    path: {
      h: 'A coding agent is turned against its developer.',
      steps: [
        { who: 'cursor', t: 'A developer asks the agent to fix a failing build.' },
        { who: 'README', t: 'A file in a dependency tells the agent to read ~/.aws and post it to a paste site.' },
        { who: 'Zenstra EDR', t: 'The prompt, the tool calls and the device are linked: reading credentials is not part of the task.' },
      ],
      verdict: { k: 'block', t: 'Session contained on one device. The developer keeps working.', tag: 'laptop-114 · cursor · read ~/.aws' },
    },
    refs: [[OWASP_AGENT, 'ASI01', 'Agent Goal Hijack'], [OWASP_AGENT, 'ASI10', 'Rogue Agents'], [ATLAS, 'AML.T0051', 'LLM Prompt Injection']],
    policy: {
      file: 'detections/agent-hijack.zen',
      p: 'Detections link the input that caused them, the action the agent planned and the policy that caught it, so an alert explains itself.',
      lines: [['deny', 'secrets.read', 'when not part of the prompt’s task'], ['deny', 'net.post', 'to paste sites · contain session'], ['hold', 'mcp.server', 'when unregistered on device'], ['allow', 'repo.read', 'within the open workspace']],
    },
  },

  'decision-record': {
    eyebrow: 'The problem',
    path: {
      h: 'An examiner asks what one agent did last quarter.',
      steps: [
        { who: 'examiner', t: 'The request: everything sar-prep-agent did in Q3, and who approved it.' },
        { who: 'record', t: 'You filter by agent and date: every allow, hold and block, with the policy version that decided it.' },
        { who: 'verify', t: 'Each entry carries the hash of the one before it. The chain verifies end to end.' },
      ],
      verdict: { k: 'allow', t: 'Exported as PDF and CSV, approvals included, in minutes.', tag: 'ledger · 1.2M entries · verified' },
    },
    refs: [[ISO, 'ISO/IEC 42001', 'AI management system'], [NIST, 'GOVERN · MANAGE', 'Accountability and response'], [OWASP_AGENT, 'ASI10', 'Rogue Agents']],
    policy: {
      file: 'ledger · verify --chain',
      p: 'Allowed actions are recorded alongside the blocks and the holds, so the record shows what happened, not just what was flagged.',
      lines: [['record', '#48213 block', 'POL-114 v7 · prev 9f2c…a71e'], ['record', '#48214 hold', 'POL-021 v3 · prev c07a…5d12'], ['record', '#48215 allow', 'POL-003 v12 · prev 4be1…09c3'], ['record', 'chain', 'verified · 1,204,118 entries']],
    },
  },

  'shadow-ai': {
    path: {
      h: 'An assistant nobody approved reads member files.',
      steps: [
        { who: 'staff device', t: 'A staff member installs an AI assistant and connects it to a shared drive.' },
        { who: 'assistant', t: 'It starts summarising member files that nobody approved it to read.' },
        { who: 'Zenstra EDR', t: 'The app is found on the device and checked against your acceptable-use policy straight away.' },
      ],
      verdict: { k: 'hold', t: 'Access paused until the agent has an owner and a scope.', tag: 'assistant · laptop-208 · no owner' },
    },
    refs: [[OWASP_AGENT, 'ASI10', 'Rogue Agents'], [OWASP_LLM, 'LLM02:2025', 'Sensitive Information Disclosure'], [NIST, 'GOVERN 1.6', 'AI system inventory']],
    policy: {
      file: 'policies/acceptable-use.zen',
      p: 'Your acceptable-use policy, enforced as code the moment a new agent appears, not in a quarterly review.',
      lines: [['hold', 'agent.new', 'until an owner is assigned'], ['deny', 'upload', 'of member data to unapproved AI'], ['deny', 'mcp.server', 'when not approved on device'], ['allow', 'copilot.chat', 'within acceptable-use policy']],
    },
  },

  'prompt-injection': {
    path: {
      h: 'A knowledge-base article carries a hidden instruction.',
      steps: [
        { who: 'member', t: 'A member asks member-chat-assist about a fee.' },
        { who: 'kb.article #4471', t: 'The article it retrieves hides an instruction to email the member’s statement out.' },
        { who: 'Zenstra', t: 'The agent plans email.send. Zenstra compares it with the declared task: answer a fee question.' },
      ],
      verdict: { k: 'block', t: 'Intent check failed. The agent answers without the quarantined span.', tag: 'member-chat-assist · email.send' },
    },
    refs: [[OWASP_LLM, 'LLM01:2025', 'Prompt Injection'], [OWASP_AGENT, 'ASI01', 'Agent Goal Hijack'], [ATLAS, 'AML.T0051.001', 'Indirect prompt injection']],
    policy: {
      file: 'policies/intent.zen',
      p: 'Zenstra does not try to out-guess the model. It judges the action: is this part of the task the agent was given?',
      lines: [['deny', 'tool.call', 'when outside(task.scope)'], ['deny', 'retrieved.span', 'when it carries instructions · quarantine'], ['deny', 'email.send', 'when not in declared task'], ['allow', 'kb.search', 'for member-faq']],
    },
  },

  'tool-poisoning': {
    path: {
      h: 'A trusted tool server changes overnight.',
      steps: [
        { who: 'mcp server', t: 'A server your agents already use publishes a new version.' },
        { who: 'tool description', t: 'The description now tells agents to include API keys in every request.' },
        { who: 'gateway', t: 'The change is flagged and the instruction quarantined, inside your cloud.' },
      ],
      verdict: { k: 'hold', t: 'The new version is held for review before any agent can call it.', tag: 'mcp kb-sync · v2.4 · awaiting review' },
    },
    refs: [[OWASP_AGENT, 'ASI04', 'Agentic Supply Chain Vulnerabilities'], [ATLAS, 'AML.T0110', 'AI Agent Tool Poisoning'], [ATLAS, 'AML.T0109', 'AI Supply Chain Rug Pull']],
    policy: {
      file: 'policies/tools.zen',
      p: 'Agents trust their tools. Zenstra does not: every tool is reviewed, scoped as a grant and checked on every call.',
      lines: [['hold', 'mcp.server', 'when version changes'], ['deny', 'tool.description', 'when it carries instructions · quarantine'], ['deny', 'mcp.call', 'when tool not in grant'], ['allow', 'kb.search', 'from approved servers']],
    },
  },

  'data-leakage': {
    path: {
      h: 'A member’s file heads for an outside inbox.',
      steps: [
        { who: 'loan-doc-classifier', t: 'The agent reads a member’s loan application to sort its documents.' },
        { who: 'email.send', t: 'A step in the flow tries to email the file to an address outside your domains.' },
        { who: 'POL-114', t: 'Policy checks the data, the destination and the task before anything leaves.' },
      ],
      verdict: { k: 'block', t: 'Member data egress blocked, and recorded with the policy that decided it.', tag: 'POL-114 · email.send · external' },
    },
    refs: [[OWASP_LLM, 'LLM02:2025', 'Sensitive Information Disclosure'], [ATLAS, 'AML.T0086', 'Exfiltration via AI Agent Tool Invocation'], [ATLAS, 'AML.T0057', 'LLM Data Leakage']],
    policy: {
      file: 'policies/member-data.zen',
      p: 'Whether an action leaks depends on the data, the destination and the task. Zenstra decides on all three, before it runs.',
      lines: [['deny', 'email.send', 'with member data · to external domains'], ['deny', 'model.call', 'with secrets in payload'], ['hold', 'export.*', 'over 100 records'], ['allow', 'crm.read', 'for member in task']],
    },
  },

  'workflow-agents': {
    path: {
      h: 'One email travels seven hops.',
      steps: [
        { who: 'intake-agent', t: 'An n8n intake agent receives a customer email carrying an instruction.' },
        { who: 'hand-off', t: 'The instruction is passed along from agent to agent, hop after hop.' },
        { who: 'hop 7', t: 'The flow tries crm.export to an outside email address.' },
      ],
      verdict: { k: 'block', t: 'Not in the workflow’s declared task. The flow stops at hop 7.', tag: 'hop 7 · crm.export → outside email' },
    },
    refs: [[OWASP_AGENT, 'ASI07', 'Insecure Inter-Agent Communication'], [OWASP_AGENT, 'ASI08', 'Cascading Failures'], [OWASP_AGENT, 'ASI01', 'Agent Goal Hijack']],
    policy: {
      file: 'policies/workflows.zen',
      p: 'Each hop is checked against the task the workflow declared, so one bad step cannot carry the rest of the flow with it.',
      lines: [['deny', 'hop.*', 'when outside(workflow.task)'], ['deny', 'crm.export', 'to outside email'], ['hold', 'core.write', 'from no-code flows'], ['allow', 'handoff', 'intake-agent → triage-agent']],
    },
  },

  'cloud-agents': {
    path: {
      h: 'A crafted request asks a loan agent to move funds.',
      steps: [
        { who: 'Bedrock agent', t: 'A loan-servicing agent built on AWS Bedrock runs inside your VPC.' },
        { who: 'grant', t: 'It asks for access to the loan system and receives a grant for 15 minutes.' },
        { who: 'request', t: 'A crafted request asks it to transfer funds between accounts.' },
      ],
      verdict: { k: 'block', t: 'accounts.transfer is not in the grant. Stopped at the gateway; payloads stay in your VPC.', tag: 'mcp core-banking · accounts.transfer' },
    },
    refs: [[OWASP_AGENT, 'ASI03', 'Identity and Privilege Abuse'], [OWASP_LLM, 'LLM06:2025', 'Excessive Agency'], [ATLAS, 'AML.T0053', 'AI Agent Tool Invocation']],
    policy: {
      file: 'policies/cloud.zen',
      p: 'Per-agent identity and short-lived grants for the models and tools each agent uses, decided at a gateway in your own cloud.',
      lines: [['allow', 'bedrock.invoke', 'for loan-doc-classifier · expires 15m'], ['deny', 'mcp.call', 'when tool not in grant'], ['hold', 'payments.*', 'for human approval'], ['deny', 'net.egress', 'to unapproved destinations']],
    },
  },

  'coding-agents': {
    path: {
      h: 'A coding agent reaches for the keys.',
      steps: [
        { who: 'claude-code', t: 'The agent helps a developer debug a service on their laptop.' },
        { who: '~/.aws', t: 'It tries to read cloud credentials it was never asked to touch.' },
        { who: 'Zenstra EDR', t: 'The prompt, the tool call and the device are seen together, on the device.' },
      ],
      verdict: { k: 'block', t: 'Secret access blocked. Production shell needs a step-up.', tag: 'claude-code · read ~/.aws' },
    },
    refs: [[OWASP_AGENT, 'ASI05', 'Unexpected Code Execution'], [ATLAS, 'AML.T0112.000', 'Local AI Agent'], [ATLAS, 'AML.T0055', 'Unsecured Credentials']],
    policy: {
      file: 'policies/devices.zen',
      p: 'Rolled out with Intune, Jamf or Kandji. Stop one agent on one device without isolating the laptop.',
      lines: [['deny', 'secrets.read', '~/.aws, ~/.ssh · unless in task'], ['hold', 'shell.exec', 'in prod · step-up required'], ['deny', 'mcp.server', 'when unregistered on device'], ['allow', 'repo.read', 'within the open workspace']],
    },
  },

  'audit-readiness': {
    eyebrow: 'The challenge',
    path: {
      h: 'The examiner’s first question, answered the same day.',
      steps: [
        { who: 'examiner', t: 'Which AI agents do you run, and who approved each one?' },
        { who: 'inventory', t: 'Zenstra exports the living inventory with owners, grants and recorded approvals.' },
        { who: 'record', t: 'Every decision since go-live is on the record, chained and verified.' },
      ],
      verdict: { k: 'allow', t: 'Examination pack ready, as PDF and CSV.', tag: 'exam pack · Q3 2026' },
    },
    refs: [[NIST, 'GOVERN · MAP · MEASURE · MANAGE', 'The four functions'], [ISO, 'ISO/IEC 42001', 'AI management system'], [NIST, 'GOVERN 1.6', 'AI system inventory']],
    policy: {
      file: 'exam-pack · Q3 2026',
      p: 'The evidence is produced as agents work, so the pack is an export rather than a project.',
      lines: [['record', 'inventory', '47 agents · owners · platforms'], ['record', 'grants', '212 scoped grants · expiry · last use'], ['record', 'approvals', '38 reviews · who, when and why'], ['record', 'ledger', '1.2M entries · chain verified']],
    },
  },
};
