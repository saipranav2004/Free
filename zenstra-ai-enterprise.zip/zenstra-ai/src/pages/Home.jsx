import { useRef } from 'react';
import A from '../components/A.jsx';
import { usePageFx } from '../lib/usePage.js';
import Intro from '../components/Intro.jsx';
import { ProductVideo } from '../components/VideoTour.jsx';
import { WorksWith, StatBand } from '../components/Motion.jsx';
import { useCasePath } from '../content/site.js';
import { Mark, Wordmark } from '../components/Logo.jsx';
import { WorkflowScene, GatewayScene, AnomalyScene } from '../components/Scenes.jsx';

const Arrow = () => (
  <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" /></svg>
);

/* The three products, one row each: what it is on the left, the product at work
   on the right (an explainer scene from Scenes.jsx). */
const PRODUCTS = [
  { id: 'workflow', name: 'Workflow Security', to: 'workflow-agents', p: 'Every hop in every agent workflow, checked against the task it was given, before the next step runs.', runs: 'n8n · Zapier · LangGraph · CrewAI · Copilot Studio' , scene: <WorkflowScene /> },
  { id: 'cloud', name: 'Cloud Security', to: 'cloud-agents', p: 'A gateway inside your cloud, in front of every MCP server, model and API your agents call. Payloads never leave.', runs: 'AWS · Azure · Google Cloud · Kubernetes' , scene: <GatewayScene variant="cloud" label="A Bedrock agent’s calls decided at the gateway in your VPC" /> },
  { id: 'edr', name: 'Zenstra EDR', to: 'coding-agents', p: 'Endpoint detection and response for AI agents. Sees the prompt, the tool call and the device together, and contains one agent in seconds.', runs: 'Windows · macOS · Intune · Jamf · Kandji' , scene: <AnomalyScene variant="edr" /> },
];

export default function Home() {
  const ref = useRef(null);
  usePageFx(ref);
  return (
      <>
        <Intro />
        <main id="main" data-page="home" ref={ref}>
        <section className="hero hero-ag" aria-labelledby="hero-h">
        <div className="wrap hero-ag-in">
        <div className="hero-ag-copy">
        <span className="hero-ag-logo" data-after=""><Mark className="hero-ag-mark" /><Wordmark className="hero-ag-word" /></span>
        <h1 className="display" id="hero-h" data-scan=""><span className="sr-only">Secure every agent. Verify every intent.</span><span className="scanline" aria-hidden="true"><span className="in">Secure every <span className="flip" data-switch="agent|bot" data-every="1500">agent</span>.</span><i className="bar"></i></span><span className="scanline" aria-hidden="true"><span className="in grad">Verify every intent.</span><i className="bar"></i></span></h1>
        <p className="sr-only">Zenstra checks every AI agent action before it runs, across your workflows, inside your cloud and on every device, and records why.</p>
        <div className="ctas" data-after=""><a href="#products" className="btn primary lg">Explore the platform{" "}<Arrow /></a><a href="#tour" className="btn secondary lg"><svg className="play-i" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 4.5v15a1 1 0 0 0 1.5.86l12.5-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5Z" /></svg>Watch the product tour</a></div>
        </div>
        </div>
        <div className="wrap">
        <WorksWith />
        </div>
        </section>
        <section className="sec tour-sec" id="tour" aria-labelledby="tour-h">
        <div className="wrap">
        <div className="sec-head center">
        <span className="eyebrow" data-reveal="">Product tour</span>
        <h2 className="h2" id="tour-h" data-reveal="">The agent makes decisions before anyone realises what’s happening.</h2>
        <p className="lede" data-reveal="">A short walkthrough of the Zenstra console, from the agents it finds to the decisions it records.</p>
        </div>
        <ProductVideo />
        </div>
        </section>
        <section className="sec" id="products" aria-labelledby="prod-h">
        <div className="wrap">
        <div className="sec-head">
        <span className="eyebrow" data-reveal="">The platform</span>
        <h2 className="h2" id="prod-h" data-reveal="">One platform.<br />Three ways in.</h2>
        <p className="lede" data-reveal="">Every product shares one agent inventory, one policy engine and one decision record.</p>
        </div>
        <div className="plist">
        {PRODUCTS.map((p, i) => (
          <article className="pitem" id={p.id} key={p.id} aria-labelledby={p.id + '-h'}>
          <div className="pitem-copy" data-reveal="">
          <h3 className="pitem-h" id={p.id + '-h'}>{p.name}</h3>
          <p>{p.p}</p>
          <span className="pitem-runs">{p.runs}</span>
          <A to={useCasePath(p.to)} className="pill-link" aria-label={'Explore ' + p.name}>Explore{" "}<Arrow /></A>
          </div>
          <div className="pitem-media scene" data-reveal="" data-delay="120">{p.scene}</div>
          </article>
        ))}
        </div>
        </div>
        </section>
        <section className="sec why-band" aria-labelledby="whyb-h">
        <div className="wrap why-band-in">
        <span className="overline" data-reveal="">Why Zenstra</span>
        <h2 className="h2" id="whyb-h" data-reveal="">Every AI agent is a new identity with real access.</h2>
        <A to="/why-zenstra" className="btn secondary lg" data-reveal="">Why Zenstra{" "}<Arrow /></A>
        </div>
        </section>
        <section className="sec" id="console" data-show="" aria-labelledby="con-h">
        <div className="wrap">
        <div className="sec-head split">
        <div style={{ display: "grid", gap: "20px" }}><span className="eyebrow" data-reveal="">The console</span><h2 className="h2" id="con-h" data-reveal="">Your entire agent fleet,<br />on one screen.</h2></div>
        <p className="lede" data-words="">Fleet, detections, investigations and the decision record, where your analysts already triage.</p>
        </div>
        <div className="show-grid">
        <div className="show-tabs" role="tablist" aria-label="Console screens" aria-orientation="vertical" data-reveal="">
        <button className="show-tab" role="tab" aria-selected="true" data-cap="Governed agents, open detections, blocked actions and approvals waiting."><b>Overview</b><span>Governed agents, open detections, blocked actions and approvals waiting.</span><i></i></button>
        <button className="show-tab" role="tab" aria-selected="false" data-cap="Detections ranked by severity, with the agent and the policy that caught them."><b>Detections</b><span>Detections ranked by severity, with the agent and the policy that caught them.</span><i></i></button>
        <button className="show-tab" role="tab" aria-selected="false" data-cap="An investigation that opens on the outcome, the blast radius and the agent run."><b>Investigation</b><span>An investigation that opens on the outcome, the blast radius and the agent run.</span><i></i></button>
        <button className="show-tab" role="tab" aria-selected="false" data-cap="One agent's identity, grants, baseline and history."><b>Agent profile</b><span>One agent's identity, grants, baseline and history.</span><i></i></button>
        </div>
        <div className="show-stage" data-reveal="">
        <div className="show-frame">
        <div className="show-bar"><i></i><i></i><i></i><span>console.zenstra.ai</span><span className="live">Live</span></div>
        <div className="show-view">
        <div className="show-slide"><img className="th-light" src="/img/screen-overview-light.webp" alt="Console overview with governed agents, detections, blocked actions and approvals" width="1600" height="1000" loading="lazy" decoding="async" /><img className="th-dark" src="/img/screen-overview-dark.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" /></div>
        <div className="show-slide"><img className="th-light" src="/img/screen-detections-light.webp" alt="Detections queue ranked by severity" width="1600" height="1000" loading="lazy" decoding="async" /><img className="th-dark" src="/img/screen-detections-dark.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" /></div>
        <div className="show-slide"><img className="th-light" src="/img/screen-investigation-light.webp" alt="Investigation showing outcome, blast radius and the agent run" width="1600" height="1000" loading="lazy" decoding="async" /><img className="th-dark" src="/img/screen-investigation-dark.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" /></div>
        <div className="show-slide"><img className="th-light" src="/img/screen-agent-light.webp" alt="Agent profile with identity, grants and behavior baseline" width="1600" height="1000" loading="lazy" decoding="async" /><img className="th-dark" src="/img/screen-agent-dark.webp" alt="" width="1600" height="1000" loading="lazy" decoding="async" /></div>
        <i className="show-scan" aria-hidden="true"></i>
        </div>
        </div>
        </div>
        <div className="show-caption"><span data-caption="" aria-live="polite"></span></div>
        </div>
        </div>
        </section>
        <section className="stats-sec" aria-label="Zenstra in numbers">
        <div className="wrap">
        <StatBand />
        </div>
        </section>
        <section className="band sec" aria-labelledby="cu-h">
        <div className="wrap cu-grid">
        <div style={{ display: "grid", gap: "22px", justifyItems: "start" }}>
        <span className="eyebrow" data-reveal="">For credit unions</span>
        <h2 className="h2" id="cu-h" data-reveal="">Ready for the examiner's first question.</h2>
        <p className="lede" data-reveal="">Core platforms, copilots, lending and fraud agents are already live. Zenstra gives every one an owner, a scope and a record your NCUA examiner can read.</p>
        <A to="/credit-unions" className="btn white" data-reveal="">Zenstra for credit unions{" "}<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"></path></svg></A>
        </div>
        <div className="vs" data-reveal="">
        <div className="vs-row"><div>The examiner asks</div><div>Vendor defaults</div><div className="y">With Zenstra</div></div>
        <div className="vs-row"><div className="q">Which agents do you run?</div><div className="n">Per platform, if at all</div><div className="y">Every agent, one inventory</div></div>
        <div className="vs-row"><div className="q">What can each one reach?</div><div className="n">Standing credentials</div><div className="y">Scoped, expiring grants</div></div>
        <div className="vs-row"><div className="q">How do you stop one?</div><div className="n">A switch per vendor</div><div className="y">One revocation, in seconds</div></div>
        <div className="vs-row"><div className="q">Show me what it did.</div><div className="n">Logs spread across vendors</div><div className="y">One tamper-evident record</div></div>
        </div>
        </div>
        </section>
        <section className="sec" id="trust" aria-labelledby="trust-h">
        <div className="wrap trust-row">
        <div style={{ display: "grid", gap: "18px", justifyItems: "start" }}>
        <span className="eyebrow" data-reveal="">Security & compliance</span>
        <h2 className="h3" id="trust-h" style={{ fontSize: "clamp(26px,2.6vw,36px)" }} data-reveal="">Audited the way you will audit us.</h2>
        <p className="lede" style={{ fontSize: "16.5px" }} data-reveal="">Independent audits every year, reports under NDA, and certificates you can verify with the issuing body.</p>
        <A to="/company#compliance" className="link" data-reveal="">Security & compliance{" "}<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"></path></svg></A>
        </div>
        <div>
        <div className="certs">
        <div className="cert" data-reveal=""><svg viewBox="0 0 54 54" aria-hidden="true"><circle className="o" cx="27" cy="27" r="25"></circle><circle className="d" cx="27" cy="27" r="21"></circle><circle className="i" cx="27" cy="27" r="17"></circle><text x="27" y="28" textAnchor="middle">SOC 2</text><text className="s" x="27" y="37" textAnchor="middle">TYPE II</text></svg><b>SOC 2 Type II</b><small>Security, availability, confidentiality</small></div>
        <div className="cert" data-reveal="" data-delay="70"><svg viewBox="0 0 54 54" aria-hidden="true"><circle className="o" cx="27" cy="27" r="25"></circle><circle className="d" cx="27" cy="27" r="21"></circle><circle className="i" cx="27" cy="27" r="17"></circle><text x="27" y="28" textAnchor="middle">ISO</text><text className="s" x="27" y="37" textAnchor="middle">27001</text></svg><b>ISO/IEC 27001</b><small>Information security</small></div>
        <div className="cert" data-reveal="" data-delay="140"><svg viewBox="0 0 54 54" aria-hidden="true"><circle className="o" cx="27" cy="27" r="25"></circle><circle className="d" cx="27" cy="27" r="21"></circle><circle className="i" cx="27" cy="27" r="17"></circle><text x="27" y="28" textAnchor="middle">ISO</text><text className="s" x="27" y="37" textAnchor="middle">42001</text></svg><b>ISO/IEC 42001</b><small>AI management system</small></div>
        <div className="cert" data-reveal="" data-delay="210"><svg viewBox="0 0 54 54" aria-hidden="true"><circle className="o" cx="27" cy="27" r="25"></circle><circle className="d" cx="27" cy="27" r="21"></circle><circle className="i" cx="27" cy="27" r="17"></circle><text x="27" y="28" textAnchor="middle">ISO</text><text className="s" x="27" y="37" textAnchor="middle">27701</text></svg><b>ISO/IEC 27701</b><small>Privacy information</small></div>
        </div>
        <p className="trust-note" data-reveal="">HIPAA and GDPR programmes · Reports under NDA · Security review pack on request</p>
        </div>
        </div>
        </section>
        <section aria-labelledby="cta-h" style={{ paddingBottom: "clamp(64px,7vw,104px)" }}>
        <div className="wrap">
        <div className="cta">
        <div className="stream" aria-hidden="true"></div>
        <div className="cta-inner">
        <span className="eyebrow" style={{ color: "#5cd2ff" }} data-reveal="">30-minute technical session</span>
        <h2 className="h2" id="cta-h" data-reveal="">Deploy agents your board can sign off on.</h2>
        <p data-reveal="">See Zenstra enforce a live policy against your own agent, in your own cloud.</p>
        <div className="ctas" data-reveal=""><A to="/demo" className="btn white lg">Request a demo{" "}<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"></path></svg></A></div>
        <p className="fine" data-reveal="">No agent rewrite · Runs in your cloud · Security review pack included</p>
        </div>
        </div>
        </div>
        </section>
        </main>
      </>
  );
}
