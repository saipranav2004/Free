import { useRef } from 'react';
import { usePageFx } from '../lib/usePage.js';
import { PageScene } from '../components/Scenes.jsx';
import { PageHero, Problem, AttackPath, FeatureRows, PolicyPanel, Grid, Related, Faq, NextSteps } from '../components/Sections.jsx';
import { DEPTH } from '../content/depth.js';

/* The template every capability and use-case page uses. What changes from page to
   page is the evidence: the real attack path, its industry references, the console
   screens and the policy that stops it (content/depth.js).
     capability: hero → problem → how it works → the policy → coverage → related → FAQ → next
     use case:   hero → the risk → how it is stopped (policy) → how it works → scenarios → … */
export default function Template({ page, kind, icon, slug }) {
  const ref = useRef(null);
  usePageFx(ref);
  const d = DEPTH[slug];
  const useCase = kind === 'use-case';
  // A page without an entry in depth.js still renders: the plain problem section, no policy.
  const brief = d ? <AttackPath eyebrow={d.eyebrow || (useCase ? 'The risk' : 'The problem')} problem={page.problem} path={d.path} refs={d.refs} /> : <Problem h={page.problem.h} p={page.problem.p} cards={page.problem.cards} />;
  const rows = <FeatureRows h={page.how.h} p={page.how.p} tabs={page.how.tabs} />;
  const policy = d ? <PolicyPanel policy={d.policy} title={useCase ? ['How it is', 'stopped.'] : undefined} /> : null;
  return (
    <main id="main" data-page="template" data-kind={kind} ref={ref}>
      <PageHero eyebrow={page.eyebrow} icon={icon} title={page.title} lede={page.lede} scene visual={<PageScene slug={slug} />} />
      {brief}
      {useCase ? <>{policy}{rows}</> : <>{rows}{policy}</>}
      <Grid eyebrow={page.grid.eyebrow} h={page.grid.h} items={page.grid.items} />
      <Related items={page.related} />
      <Faq items={page.faq} />
      <NextSteps />
    </main>
  );
}
