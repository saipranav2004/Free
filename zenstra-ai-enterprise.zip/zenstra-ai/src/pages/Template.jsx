import { useRef } from 'react';
import { usePageFx } from '../lib/usePage.js';
import { PageHero, HeroVisual, Problem, HowTabs, Grid, Related, Faq, NextSteps } from '../components/Sections.jsx';

/* The one template every capability and use-case page uses:
   hero → the problem → how Zenstra handles it → where it applies → related → FAQ →
   one closing call to action. Only what is specific to the page; the shared proof
   (numbers, certifications, works-with) lives on the home and platform pages. */
export default function Template({ page, kind, icon }) {
  const ref = useRef(null);
  usePageFx(ref);
  return (
    <main id="main" data-page="template" data-kind={kind} ref={ref}>
      <PageHero eyebrow={page.eyebrow} icon={icon} title={page.title} lede={page.lede} visual={<HeroVisual shot={page.shot} chips={page.chips} />} />
      <Problem h={page.problem.h} p={page.problem.p} cards={page.problem.cards} />
      <HowTabs h={page.how.h} p={page.how.p} tabs={page.how.tabs} />
      <Grid eyebrow={page.grid.eyebrow} h={page.grid.h} items={page.grid.items} />
      <Related items={page.related} />
      <Faq items={page.faq} />
      <NextSteps />
    </main>
  );
}
