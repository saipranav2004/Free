import { useRef } from 'react';
import A from '../components/A.jsx';
import Icon from '../components/Icon.jsx';
import Core from '../components/Core.jsx';
import { AgentMapScene, OwnerTreeScene } from '../components/Scenes.jsx';
import { Arrow, NextSteps } from '../components/Sections.jsx';
import { usePageFx, useCore } from '../lib/usePage.js';
import { capabilityPath } from '../content/site.js';

/* Why Zenstra: the case for the category and for Zenstra, told with the product.
   The exposure (the agent map), the answer (an owner and a scope), what changes,
   the core taken apart, what sets Zenstra apart and the platform in four parts. */
const EXPOSURE = [
  { icon: 'user', h: 'Created by anyone', p: 'No-code flows, copilots and coding agents are built by business teams and developers, not provisioned by IT.' },
  { icon: 'key', h: 'Holding real credentials', p: 'Tokens, API keys, OAuth apps, service accounts and MCP connections, many with standing, broad access.' },
  { icon: 'bolt', h: 'Acting without a person', p: 'They decide and act in seconds, inside the systems that move money and member data.' },
];

const BEFORE = [
  'Agents found after an incident, one platform at a time',
  'Standing keys and service accounts with broad scope',
  'Logs that show what happened, after it happened',
  'A separate switch in every vendor to stop one agent',
  'Evidence pulled together by hand for every exam',
];
const AFTER = [
  'One inventory of every agent, each with a named owner',
  'Grants scoped to the task that expire on their own',
  'Every action decided inline, at 18 ms p95, before it runs',
  'One revocation stops an agent everywhere, in seconds',
  'A tamper-evident record, exported as evidence',
];

const APART = [
  { h: 'Inline, not after the fact', p: 'Zenstra sits in the path of the action. Allow, hold or block is decided before the tool runs, not flagged in a log afterwards.' },
  { h: 'Intent, not only identity', p: 'Each action is checked against the task the agent was given, so a hijacked agent holding valid credentials is still stopped.' },
  { h: 'Inside your environment', p: 'The gateway runs in your VPC. Prompts and payloads never leave your cloud, and nothing in your agents is rewritten.' },
  { h: 'Evidence an examiner accepts', p: 'Every decision is chained to the one before it, with the policy version that made it, and exports as a report.' },
];

const PARTS = [
  { slug: 'agent-discovery', icon: 'radar', k: 'Discover', h: 'Every agent, with an owner', p: 'Agents, MCP servers and credentials across your platforms, in one inventory.' },
  { slug: 'runtime-enforcement', icon: 'gate', k: 'Decide', h: 'Every action, before it runs', p: 'Allow, hold for a person, or block, against identity, task and policy.' },
  { slug: 'detection-response', icon: 'pulse', k: 'Detect', h: 'Every anomaly, contained', p: 'Baselines per agent, and one agent stopped on one device in seconds.' },
  { slug: 'decision-record', icon: 'ledger', k: 'Prove', h: 'Every decision, on the record', p: 'A hash-chained record your auditors and examiners can verify.' },
];

export default function WhyZenstra() {
  const ref = useRef(null);
  usePageFx(ref);
  useCore(ref);
  return (
    <main id="main" data-page="why" ref={ref}>
      <section className="why-hero" aria-labelledby="hero-h">
        <div className="wrap">
          <div className="why-panel">
            <span className="eyebrow" data-after="">Why Zenstra</span>
            <h1 className="display" id="hero-h" data-scan="">
              <span className="scanline"><span className="in">Your agents act on their own.</span><i className="bar"></i></span>
              <span className="scanline"><span className="in grad">Someone has to decide first.</span><i className="bar"></i></span>
            </h1>
            <p className="lede" data-after="">AI agents now read your documents, hold your credentials and act in your core systems. Zenstra decides every action before it runs, and keeps the record that proves it.</p>
            <div className="ctas" data-after="">
              <a href="#exposure" className="btn white lg">Why it matters <Arrow /></a>
              <A to="/platform" className="btn glass lg">Platform overview</A>
            </div>
          </div>
        </div>
      </section>

      <section className="sec" id="exposure" aria-labelledby="exp-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">The challenge</span>
            <h2 className="h2" id="exp-h" data-reveal="">Every AI agent is a new identity with real access.</h2>
            <p className="lede" data-reveal="">Agents run in workflows, in your cloud and on laptops, connected to your systems by credentials most identity and data tools never see.</p>
          </div>
          <div className="why-stage" data-reveal=""><AgentMapScene /></div>
          <div className="why-facts">
            {EXPOSURE.map((f, i) => (
              <div className="why-fact" key={f.h} data-reveal="" data-delay={i * 90}>
                <span className="why-ic"><Icon name={f.icon} /></span>
                <h3>{f.h}</h3>
                <p>{f.p}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sec alt" aria-labelledby="own-h">
        <div className="wrap why-split">
          <div className="why-copy">
            <span className="overline" data-reveal="">Controlled access</span>
            <h2 className="h2" id="own-h" data-reveal="">Agent security starts with an owner and a scope.</h2>
            <p className="lede" data-reveal="">Zenstra ties every agent to the person it acts for, maps every credential it holds, and narrows each grant to the task in front of it.</p>
            <ul className="why-checks" data-reveal="">
              <li><Icon name="check" />Every agent has a named owner who answers for it.</li>
              <li><Icon name="check" />Every credential is mapped to the systems it reaches.</li>
              <li><Icon name="check" />Every grant is scoped to the task and expires on its own.</li>
            </ul>
            <A to={capabilityPath('agent-identity')} className="link" data-reveal="">Agent identity and access <Arrow /></A>
          </div>
          <div className="why-media" data-reveal="" data-delay="120"><OwnerTreeScene /></div>
        </div>
      </section>

      <section className="sec" aria-labelledby="ba-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">Challenge and solution</span>
            <h2 className="h2" id="ba-h" data-reveal="">What changes with Zenstra.</h2>
          </div>
          <div className="ba">
            <div className="ba-card before" data-reveal="">
              <h3>Without Zenstra</h3>
              <ul>{BEFORE.map((t) => <li key={t}><span className="ba-x" aria-hidden="true">✕</span>{t}</li>)}</ul>
            </div>
            <div className="ba-card after" data-reveal="" data-delay="100">
              <h3>With Zenstra</h3>
              <ul>{AFTER.map((t) => <li key={t}><span className="ba-y" aria-hidden="true">✓</span>{t}</li>)}</ul>
            </div>
          </div>
        </div>
      </section>

      <Core />

      <section className="sec" aria-labelledby="apart-h">
        <div className="wrap apart">
          <div className="apart-head">
            <span className="overline" data-reveal="">What sets Zenstra apart</span>
            <h2 className="h2" id="apart-h" data-reveal="">Built to decide, not only to watch.</h2>
            <p className="lede" data-reveal="">Most tools see an agent after it acts. Zenstra is in the path of every action, with the context to tell a helpful agent from a hijacked one.</p>
          </div>
          <ol className="apart-list">
            {APART.map((a, i) => (
              <li key={a.h} data-reveal="" data-delay={i * 70}>
                <span className="apart-n">{'0' + (i + 1)}</span>
                <div><h3>{a.h}</h3><p>{a.p}</p></div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="sec alt" aria-labelledby="parts-h">
        <div className="wrap">
          <div className="sec-head center">
            <span className="overline" data-reveal="">One platform</span>
            <h2 className="h2" id="parts-h" data-reveal="">Discover, decide, detect and prove, in one place.</h2>
          </div>
          <div className="parts">
            {PARTS.map((c, i) => (
              <A key={c.slug} to={capabilityPath(c.slug)} className="part" data-reveal="" data-delay={i * 80}>
                <span className="part-k"><Icon name={c.icon} />{c.k}</span>
                <h3>{c.h}</h3>
                <p>{c.p}</p>
                <span className="link">Learn more <Arrow /></span>
              </A>
            ))}
          </div>
        </div>
      </section>

      <NextSteps h="See Zenstra decide on your own agents." />
    </main>
  );
}
