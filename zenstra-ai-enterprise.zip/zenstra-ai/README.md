# Zenstra AI website

A React app (Vite and React Router). Every page is prerendered to static HTML at build time, so it loads complete and search engines can read it. React then hydrates it in the browser. Production serves only static files from nginx; Node is used only to build.

## Develop

```sh
npm ci            # install the exact versions in package-lock.json
npm run dev       # http://127.0.0.1:5173 with hot reload
```

## Build and preview

```sh
npm run build     # client build + server render + prerender → dist/
npm run preview   # serve dist/ like production: http://127.0.0.1:4173
```

## Test end to end

The tests use Playwright and run against the production build.

```sh
npm run build
npx playwright install chromium   # once, if no Chromium is installed
npm run test:e2e
```

They cover:
- **Pages:** every page renders, hydrates and loads its images, with no console errors and no sideways scrolling on desktop or phone. Every internal link and anchor resolves.
- **Accessibility:** axe finds no violations, in light and dark themes.
- **Context:** each page carries its own proof: a scene in the hero, an animation per row, the attack path with its OWASP / MITRE ATLAS / NIST references, and the policy behind it. Why Zenstra adds a dated incident timeline (each with its source); the platform page compares tool categories (not named products) in a table.
- **Motion:**
  - the one rolling row (home), nothing rolling on any other page, the scroll-drawn path and the pinned steps
  - the opening sequence and its timing
  - the home hero (mark, one centred line whose first word turns agent → bot → machine, no background field)
  - the product scenes: one per capability and use-case page, none repeated, each restarting when it comes into view
  - the product rows and their scenes
  - the Zenstra core canvas (on Why Zenstra)
  - the Why Zenstra page
  - tabs, FAQ
  - theme switching
  - the home mark, headline and hero buttons on a phone
  - reduced motion
- **Context:** every row animation is unique across the site, Zenstra figures appear only on the home page, third-party figures and incidents carry sources, breadcrumbs, the platform comparison table, no decorative numbering.
- **Navigation:** mega menus, the mobile menu, client-side navigation, the document head on each route, and hash links.
- **Demo form:** validation, success, the three failure paths, and the spam trap. FormSubmit is mocked, so no email is sent.

To test a running server instead, such as the Docker container, set `BASE_URL`:

```sh
BASE_URL=http://127.0.0.1:8080 npm run test:e2e
```

## Run it with Docker

```sh
docker build -t zenstra-ai .
docker run -d --name zenstra-ai -p 8080:8080 --read-only --tmpfs /tmp zenstra-ai
```

Open http://localhost:8080. Put HTTPS in front of the container with your load balancer, CDN or reverse proxy.

- **Clean URLs:** `/company` serves `company.html`, and `/platform/agent-identity` serves `platform/agent-identity.html`.
- **Errors and old links:** unknown paths get the 404 page with a 404 status. `/home.html` from the old site redirects to `/`.
- **Health check:** `GET /healthz` returns `ok`. The image also has a Docker `HEALTHCHECK`.
- **Security:**
  - nginx runs as a non-root user and works on a read-only filesystem.
  - Security headers, including a strict Content-Security-Policy with no inline scripts, are set in `nginx/security-headers.conf`.
- **Caching:** built assets have content hashes and are cached for a year; pages are revalidated on every visit.

## Where things are

| Path | What it is |
|---|---|
| `src/content/site.js` | The site map: capabilities, use cases, company links, and every route's title and description. The menus, footer, router, prerender and sitemap all read it. |
| `src/content/pages.js` | The copy for every capability and use-case page. |
| `src/content/depth.js` | What makes each of those pages its own: a real attack path ending in Zenstra's decision, the OWASP / MITRE ATLAS / NIST references for the risk, and the policy that stops it. |
| `src/content/media.js` | The product video setting (see below). |
| `src/pages/` | One component per page. `Template.jsx` is the shared layout for capability and use-case pages; `WhyZenstra.jsx` is the case for Zenstra (and carries the Zenstra core). |
| `src/components/` | Header and mega menus, footer, intro, video, the shared sections in `Sections.jsx` (including `NextSteps`, the one closing call to action on inner pages), `Motion.jsx` (`Marquee`, `StatBand`, `WorksWith`, `Integrations`, `ScrollPath`, `ScrollSteps`), `Scenes.jsx` (the product scenes, see below) and `Core.jsx` (the Zenstra core section). |
| `src/content/logos.js` | The marks of the platforms Zenstra works with (Simple Icons, CC0). Brands that withhold their marks are named in text. |
| `src/lib/` | Motion engines: the canvas engines (`fx5.js`), the Zenstra core (`core5.js`), text effects (`text.js`) and page motion (`pagefx.js`). Each page mounts them on load and removes them when you leave. |
| `src/styles/` | `v5.css` is the design system, `pages.css` holds page-specific styles, `enterprise.css` holds the menus, template and video, `scenes.css` the product scenes and `why.css` the Why Zenstra page, the home opening and the shared overline, before/after and numbered-list patterns. |
| `public/` | Images, `boot.js` (theme and intro, run before first paint) and anything served as-is. |
| `scripts/prerender.mjs` | Renders each route to HTML and writes `sitemap.xml` and `robots.txt`. |
| `scripts/serve.mjs` | Local server with the same clean-URL rules as nginx. |
| `tests/` | End-to-end tests. |
| `nginx/`, `Dockerfile` | The production image. |

### Design rules

- **Type:** Mona Sans for headlines, Inter for reading and labels, Geist Mono only for real code and data (policy lines, records, console chips).
- **Colour:** navy-black ink, slate body copy and a cool grey for alternating sections in the light theme; neutral darks in the dark theme. The brand blue is the only accent, used solid (no gradient text). Inside product scenes, green, amber and red mean allow, hold and block, and nothing else.
- **Numbers:** Zenstra's own figures (protected agents, threats blocked, policies, decision latency) appear once, on the home page; decision latency is also stated where it is the point (runtime enforcement, the gateway FAQ). Third-party figures carry a numbered source that links to the original (`StatBand` `sources`). Lists without an order carry icons or labels, never 01 / 02 / 03.
- **Calls to action:** the demo request sits in the header on every page and once at the end of each page. Heroes lead into the page instead of repeating it.
- **Motion:** one rolling row (the works-with marks on the home page). Product scenes play their story while on screen and loop; everything else holds still once it has arrived. With reduced motion, scenes show their final step.

### Adding a page

- **A capability or use case:** add it to `src/content/site.js`, its copy to `src/content/pages.js`, and its attack path, industry references and policy to `src/content/depth.js`, and its scene to `PageScene` in `src/components/Scenes.jsx`. The menu, footer, sitemap and prerender pick it up automatically.
- **A different kind of page:** add it to `ROUTES` in `site.js` and add a `<Route>` in `src/App.jsx`.

## Product scenes

`src/components/Scenes.jsx` holds small, stylised Zenstra screens and diagrams, each telling one product story a step at a time (after the explainer animations on astrix.security):

| Scene | Story | Used on |
|---|---|---|
| `AgentMapScene` | Agents, platforms and the credentials between them; two risky links flagged | Why Zenstra, Shadow AI |
| `OwnerTreeScene` | Owner → agents → credentials → systems → permissions, broad grants scoped | Why Zenstra |
| `PlatformScene` | Workflow, cloud and EDR feed one policy engine; allow, hold, block, recorded | Platform |
| `InventoryScene` | Sort by risk, find the unowned agent, assign an owner | Agent discovery |
| `GrantScene` | A broad request narrowed to the task, issued for 15 minutes, expired | Agent identity |
| `PolicyScene` | Build a hold-for-approval policy | Runtime enforcement |
| `GatewayScene` | Calls decided at the gateway (`mcp`, `poison`, `cloud`) | MCP security, Tool poisoning, Cloud agents, home |
| `AnomalyScene` | Baseline against this session, then contain (`edr`, `code`) | Detection and response, Coding agents, home |
| `LedgerScene` | Verify the chain, export evidence (`record`, `exam`) | Decision record, Audit readiness |
| `InjectionScene` | A hidden instruction in a document; the planned email blocked | Prompt injection |
| `WorkflowScene` | An instruction travels hop by hop until the hop that leaves | Workflow agents, home |
| `EgressScene` | A member file on its way to an outside address, blocked | Data leakage |

**Row animations.** Every "how it works" row on the capability and use-case pages has its own small animation (`src/components/Vignettes.jsx`), 42 in all, built from a few product UI forms: a table, coverage bars, a chain of steps, a side-by-side comparison, a document, a chat, a record card and a terminal. Each is filled with that row's own example, so no two rows show the same picture. `rowVisuals(slug)` returns a page's three; a new page needs an entry there. They share one fictional organisation (Northbank FCU, 63 agents on 6 platforms) so the numbers agree from page to page.

**Speed.** Scenes and row animations run at 1.5× their authored step times (`SPEED` in `Scenes.jsx`); the transitions in `scenes.css` are scaled to match, so the pointer, typing and bars stay in step.

**Capability cards.** The six cards on the platform page carry illustrative dashboards (`src/components/Illus.jsx`): a simple window with one or two big figures or a single chart, and one floating card with the point. They are drawn in HTML and CSS, follow the theme, and are not the real console.

How they work: the server renders the final step, so each story is readable without JavaScript. In the browser a scene restarts when it comes into view, plays forward, holds the last step and loops. The step is exposed as cumulative `k0 … kN` classes on the scene, so `scenes.css` reads as "from step 3 on, show this". Everything is sized in `em` against the scene's own width (container units), so a scene scales like an image. `PageScene` maps each capability and use-case slug to its scene; a new page needs an entry there.

## The product video

1. Put the file at `public/media/zenstra-product-tour.mp4` (H.264 MP4).
2. In `src/content/media.js`, set `src: '/media/zenstra-product-tour.mp4'` and `length` to its running time.
3. Rebuild.

The home page has a video card right after the hero (the hero's "Watch the product tour" button scrolls to it). Until `src` is set the card shows the console poster and a static play button; once set, the button plays the video in place.

## The demo form

`src/pages/Demo.jsx` sends requests through [FormSubmit](https://formsubmit.co) to `info@zenstra.ai`. No backend is needed, and nothing is stored in the browser.

- **Before launch:** submit the form once. FormSubmit then emails an "Activate Form" link to info@zenstra.ai. Click it, and from then on every request arrives in that inbox.
- **If delivery fails:** visitors are offered a prefilled email to send instead.
- **To change the address:** edit `ACTION` and `TO` in `Demo.jsx`.
- **To move to another form service:** update `connect-src` and `form-action` in `nginx/security-headers.conf` as well.
