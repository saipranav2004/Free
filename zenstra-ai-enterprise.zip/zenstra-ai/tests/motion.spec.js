import { test, expect } from '@playwright/test';
import { prep, ROUTES } from './helpers.js';

test('opening sequence: one line, the logo, then the page opens through the mark', async ({ page }) => {
  const errors = await prep(page, { intro: true });
  // Measured in the page from its very first frame: from every letter of the first
  // line being readable to the moment it starts to swap out.
  await page.addInitScript(() => {
    window.__introHold = new Promise((res) => {
      let tAll = 0;
      const loop = () => {
        const ls = [...document.querySelectorAll('.intro-word .sw:not(.out) .l')];
        if (!tAll && ls.length && ls.map((l) => l.textContent).join('') === 'workflow security' && ls.every((l) => +getComputedStyle(l).opacity > 0.5)) tAll = performance.now();
        if (tAll && document.querySelector('.intro-word .sw.out')) { res(performance.now() - tAll); return; }
        requestAnimationFrame(loop);
      };
      requestAnimationFrame(loop);
    });
  });
  await page.goto('/?intro=1');
  await expect(page.locator('html')).toHaveClass(/intro-play/);
  // "Zenstra for workflow security" appears as one line (never "Zenstra for" alone for long).
  const line = page.locator('.intro-line');
  await expect(line).toContainText('Zenstra for');
  const held = await page.evaluate(() => window.__introHold);
  // Fully readable for ~1.3 s; with its fade in and out the line is on screen ~1.5 s.
  expect(held, 'first line holds').toBeGreaterThan(1100);
  expect(held).toBeLessThan(2200);
  await page.waitForFunction(() => [...document.querySelectorAll('.intro-word .sw:not(.out) .l')].map((l) => l.textContent).join('') === 'EDR', null, { timeout: 8000 });
  // The wordmark image, not typed text.
  await expect(page.locator('.intro-logo .logo-word img').first()).toHaveAttribute('src', /zenstra-wordmark/);
  await expect(page.locator('html')).not.toHaveClass(/intro-play/, { timeout: 12000 });
  await expect(page.locator('.hero.hero-ready')).toHaveCount(1, { timeout: 5000 });
  await expect(page.locator('.hero h1')).toHaveClass(/scanned/);
  expect(errors).toEqual([]);
});

test('skipping the intro opens the page at once', async ({ page }) => {
  await prep(page, { intro: true });
  await page.goto('/?intro=1');
  await page.waitForTimeout(600);
  await page.keyboard.press('Enter');
  await expect(page.locator('html')).not.toHaveClass(/intro-play/, { timeout: 4000 });
});

test('the intro plays once per visit, and never when landing on another page', async ({ page }) => {
  await prep(page, { intro: true });
  await page.goto('/company');
  await expect(page.locator('html')).not.toHaveClass(/intro-play/);
  await page.goto('/');
  await expect(page.locator('html')).not.toHaveClass(/intro-play/);
});

test('home hero: the mark, one centred line and two calls to action over a quiet lens field', async ({ page }) => {
  const errors = await prep(page);
  await page.goto('/');
  await expect(page.locator('.hero.hero-ready')).toHaveCount(1, { timeout: 6000 });
  await expect(page.locator('.hero-ag-logo img').first()).toBeVisible();
  await expect(page.locator('.hero h1')).toHaveText(/Secure every agent\.\s*Verify every intent\./);
  await expect(page.locator('.hero [data-scan]')).toHaveClass(/scanned/);
  // Centred: the headline's middle sits on the page's middle.
  const box = await page.locator('.hero h1').boundingBox();
  const vw = page.viewportSize().width;
  expect(Math.abs(box.x + box.width / 2 - vw / 2)).toBeLessThan(24);
  await expect(page.locator('.hero .lens canvas')).toHaveCount(1);
  // The demo request lives in the header; the hero leads into the page.
  await expect(page.locator('.head a[href="/demo"]')).toBeVisible();
  await expect(page.locator('.hero .ctas a[href="#products"]')).toBeVisible();
  await expect(page.locator('.hero .ctas a[href="#tour"]')).toBeVisible();
  await expect(page.locator('.hero a[href="/demo"]')).toHaveCount(0);
  // The product video card follows the hero; its play button waits for the video file.
  await expect(page.locator('#tour .pvid-play')).toHaveCount(1);
  // The hero stays minimal: no floating chips over the field.
  await expect(page.locator('.hero .dchip')).toHaveCount(0);
  expect(errors).toEqual([]);
});

test('each product row plays its own product scene and links to its page', async ({ page }) => {
  const errors = await prep(page);
  await page.goto('/');
  await expect(page.locator('.pitem')).toHaveCount(3);
  const names = [];
  for (const id of ['workflow', 'cloud', 'edr']) {
    const row = page.locator('#' + id);
    await row.scrollIntoViewIfNeeded();
    const scn = row.locator('.pitem-media figure.scn');
    await expect(scn).toHaveCount(1);
    await expect(scn).toHaveAttribute('role', 'img');
    // In view, the story restarts and then moves on step by step.
    await expect(scn).toHaveClass(/\bk2\b/, { timeout: 6000 });
    names.push(await scn.evaluate((e) => [...e.classList].find((c) => /^scn-/.test(c))));
  }
  expect(new Set(names).size).toBe(3);
  await page.locator('#cloud .pill-link').click();
  await expect(page).toHaveURL(/\/use-cases\/cloud-agents$/);
  expect(errors).toEqual([]);
});

test('the Zenstra core, on Why Zenstra, draws and advances with scroll', async ({ page }) => {
  await prep(page);
  await page.goto('/why-zenstra');
  const stage = async () => page.locator('[data-core-t]').innerText();
  await page.locator('#core').scrollIntoViewIfNeeded();
  await page.waitForTimeout(800);
  const painted = await page.evaluate(() => {
    const c = document.querySelector('[data-core] canvas'); const g = c.getContext('2d');
    const d = g.getImageData(0, 0, c.width, c.height).data; let n = 0;
    for (let i = 3; i < d.length; i += 4 * 97) if (d[i] > 0) n++;
    return n;
  });
  expect(painted).toBeGreaterThan(50);
  const s1 = await stage();
  await page.evaluate(() => { const t = document.querySelector('.core-track'); window.scrollTo(0, t.getBoundingClientRect().top + window.scrollY + t.offsetHeight * 0.55); });
  await page.waitForTimeout(1200);
  expect(await stage()).not.toBe(s1);
});

test('console tabs switch screens; capability pages show the path, the rows and the policy', async ({ page }) => {
  await prep(page);
  await page.goto('/');
  await page.locator('#console').scrollIntoViewIfNeeded();
  await page.locator('.show-tab').nth(2).click();
  await expect(page.locator('.show-tab').nth(2)).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('.show-slide').nth(2)).toHaveClass(/\bon\b/);

  // Capability pages: the attack path, numbered feature rows and the policy behind it.
  await page.goto('/platform/runtime-enforcement');
  await expect(page.locator('.apath-v.hold')).toContainText('Held for a person to approve');
  await expect(page.locator('.apath-refs li')).toHaveCount(3);
  await expect(page.locator('#how .frow')).toHaveCount(3);
  await expect(page.locator('#how .frow h3').nth(1)).toHaveText('Allow, hold or block');
  await expect(page.locator('.pol-code .pl')).toHaveCount(4);
  await expect(page.locator('.pol-code .pl').first()).toContainText('deny');
});

test('every capability and use-case page tells its own story in a product scene', async ({ page }) => {
  test.setTimeout(90_000);
  const errors = await prep(page);
  const seen = new Map();
  for (const route of ROUTES.filter((r) => /^\/(platform\/|use-cases\/)/.test(r))) {
    await page.goto(route);
    const scn = page.locator('.phero figure.scn');
    await expect(scn, route).toHaveCount(1);
    const label = await scn.getAttribute('aria-label');
    expect(label, route).toBeTruthy();
    expect(seen.has(label), route + ' repeats ' + seen.get(label)).toBe(false);
    seen.set(label, route);
  }
  // A scene restarts when it comes into view and plays forward.
  await page.goto('/platform/runtime-enforcement');
  const scn = page.locator('.phero figure.scn');
  await expect(scn).not.toHaveClass(/\bk2\b/, { timeout: 3000 });
  await expect(scn).toHaveClass(/\bk3\b/, { timeout: 8000 });
  await expect(scn.locator('.scn-cur')).toBeVisible();
  expect(errors).toEqual([]);
});

test('Why Zenstra: the map, the owner tree, before and after, the core, and the platform', async ({ page }) => {
  const errors = await prep(page);
  await page.goto('/why-zenstra');
  await expect(page.locator('main h1')).toContainText('Your agents act on their own.');
  await expect(page.locator('figure.scn-map')).toHaveCount(1);
  await expect(page.locator('figure.scn-tree')).toHaveCount(1);
  await expect(page.locator('.ba-card')).toHaveCount(2);
  await expect(page.locator('.ba-card.after li')).toHaveCount(5);
  await expect(page.locator('#core [data-core-t]')).toHaveCount(1);
  await expect(page.locator('.parts .part')).toHaveCount(4);
  await expect(page.locator('main a[href="/demo"]')).toHaveCount(1);
  expect(errors).toEqual([]);
});

test('FAQ answers open and close', async ({ page }) => {
  await prep(page);
  await page.goto('/use-cases/shadow-ai');
  const d = page.locator('.faq details').first();
  await d.locator('summary').click();
  await expect(d).toHaveAttribute('open', '');
  await page.waitForTimeout(700);
  await d.locator('summary').click();
  await page.waitForTimeout(700);
  await expect(d).not.toHaveAttribute('open', '');
});

test('theme toggle switches and persists', async ({ page }) => {
  await prep(page, { theme: 'light' });
  await page.goto('/platform');
  await page.getByRole('button', { name: /light and dark/ }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
});

test.describe('reduced motion', () => {
  test.use({ contextOptions: { reducedMotion: 'reduce' } });
  test('content is fully visible without animation, the core is a still frame', async ({ page }) => {
    const errors = await prep(page, { intro: true });
    await page.goto('/?intro=1');
    await expect(page.locator('html')).not.toHaveClass(/intro-play/);
    await expect(page.locator('html')).toHaveClass(/reduce/);
    const hidden = await page.evaluate(() => [...document.querySelectorAll('[data-reveal],[data-after]')].filter((e) => getComputedStyle(e).opacity === '0').length);
    expect(hidden).toBe(0);
    await page.goto('/why-zenstra');
    await expect(page.locator('[data-core]')).toHaveClass(/core-static/);
    await page.goto('/platform/agent-discovery');
    const hidden2 = await page.evaluate(() => [...document.querySelectorAll('[data-reveal],[data-after]')].filter((e) => getComputedStyle(e).opacity === '0').length);
    expect(hidden2).toBe(0);
    // Scenes hold their final step, without a pointer.
    const scn = page.locator('.phero figure.scn');
    await scn.scrollIntoViewIfNeeded();
    await page.waitForTimeout(1500);
    await expect(scn).toHaveClass(/\bk5\b/);
    await expect(scn.locator('.scn-cur')).toBeHidden();
    expect(errors).toEqual([]);
  });
});
