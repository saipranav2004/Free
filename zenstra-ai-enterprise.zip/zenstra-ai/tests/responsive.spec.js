import { test, expect } from '@playwright/test';
import { ROUTES, prep, scrollThrough, noOverflow } from './helpers.js';

test('every page fits the screen without sideways scrolling', async ({ page }) => {
  test.setTimeout(120_000);
  const errors = await prep(page);
  for (const route of ROUTES) {
    await page.goto(route, { waitUntil: 'networkidle' });
    await scrollThrough(page);
    await noOverflow(page);
    await expect(page.locator('main h1'), route).toBeVisible();
  }
  expect(errors).toEqual([]);
});

test('the home announcement and hero buttons fit a phone on one line each', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'phone layout');
  await prep(page);
  await page.goto('/');
  const pill = await page.locator('.hero .announce').boundingBox();
  expect(pill.x + pill.width).toBeLessThanOrEqual(390);
  expect(pill.height).toBeLessThanOrEqual(40);
  for (const b of await page.locator('.hero .ctas .btn').all()) expect((await b.boundingBox()).height).toBeLessThanOrEqual(54);
});
