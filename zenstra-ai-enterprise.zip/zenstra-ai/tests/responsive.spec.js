import { test, expect } from '@playwright/test';
import { ROUTES, prep, scrollThrough, noOverflow } from './helpers.js';

test('every page fits the screen without sideways scrolling', async ({ page }) => {
  test.setTimeout(120_000);
  const errors = await prep(page);
  for (const route of ROUTES) {
    await page.goto(route, { waitUntil: 'networkidle' });
    await scrollThrough(page);
    await noOverflow(page);
    await expect(page.locator('main h1'), route).toBeVisible();
  }
  expect(errors).toEqual([]);
});

test('the home mark, headline and hero buttons fit a phone', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'phone layout');
  await prep(page);
  await page.goto('/');
  const logo = await page.locator('.hero-ag-logo').boundingBox();
  expect(logo.x).toBeGreaterThanOrEqual(0);
  expect(logo.x + logo.width).toBeLessThanOrEqual(page.viewportSize().width);
  const h1 = await page.locator('.hero h1').boundingBox();
  expect(h1.x + h1.width).toBeLessThanOrEqual(page.viewportSize().width);
  for (const b of await page.locator('.hero .ctas .btn').all()) expect((await b.boundingBox()).height).toBeLessThanOrEqual(54);
});
