import { test, expect } from '@playwright/test';
import { ROUTES, prep } from './helpers.js';

/* How each page carries its context: its own product pictures, figures only where
   they belong (and sourced when they are not Zenstra's), no decorative numbering. */
const DEEP = ROUTES.filter((r) => /^\/(platform\/|use-cases\/)/.test(r));

test('every "how it works" row on every capability and use-case page has its own animation', async ({ page }) => {
  test.setTimeout(120_000);
  const errors = await prep(page);
  const seen = new Map();
  for (const route of DEEP) {
    await page.goto(route);
    const rows = page.locator('#how .frow');
    await expect(rows, route).toHaveCount(3);
    await expect(page.locator('#how .frow-media figure.scn'), route).toHaveCount(3);
    // No console screenshot stands in for a row.
    await expect(page.locator('#how .frow-media .shot'), route).toHaveCount(0);
    for (const label of await page.locator('#how .frow-media figure.scn').evaluateAll((els) => els.map((e) => e.getAttribute('aria-label')))) {
      expect(seen.has(label), `${route} repeats a row from ${seen.get(label)}`).toBe(false);
      seen.set(label, route);
    }
    // Breadcrumbs lead back up.
    await expect(page.locator('.phero .crumbs a[href="/"]'), route).toHaveCount(1);
  }
  expect(seen.size).toBe(DEEP.length * 3);
  expect(errors).toEqual([]);
});

test('a row animation plays when it comes into view', async ({ page }) => {
  await prep(page);
  await page.goto('/use-cases/data-leakage');
  const scn = page.locator('#how .frow-media figure.scn').nth(1);
  await scn.scrollIntoViewIfNeeded();
  await expect(scn).not.toHaveClass(/\bk3\b/, { timeout: 3000 });
  await expect(scn).toHaveClass(/\bk3\b/, { timeout: 8000 });
});

test('Zenstra’s own figures appear once, on the home page', async ({ page }) => {
  await prep(page);
  for (const route of ROUTES) {
    await page.goto(route);
    const n = await page.locator('main').evaluate((m) => (m.innerText.match(/Threats blocked every month|Protected agents/g) || []).length);
    expect(n, route).toBe(route === '/' ? 2 : 0);
  }
});

test('third-party figures carry their sources', async ({ page }) => {
  await prep(page);
  await page.goto('/credit-unions');
  const marks = await page.locator('.stat-s').allInnerTexts();
  expect(marks.length).toBe(4);
  const src = page.locator('.stats-src li a');
  await expect(src).toHaveCount(3);
  for (const m of new Set(marks)) expect(+m).toBeLessThanOrEqual(3);
  for (const href of await src.evaluateAll((a) => a.map((x) => x.href))) expect(href).toMatch(/^https:\/\/(www\.)?(crnrstone|gartner)\.com\//);
});

test('Why Zenstra lists dated public incidents, each with a source', async ({ page }) => {
  await prep(page);
  await page.goto('/why-zenstra');
  const items = page.locator('.inc li');
  await expect(items).toHaveCount(5);
  for (let i = 0; i < 5; i++) {
    await expect(items.nth(i).locator('time')).toHaveText(/\w{3} 20\d\d/);
    await expect(items.nth(i).locator('a.inc-s')).toHaveAttribute('href', /^https:\/\//);
    await expect(items.nth(i).locator('a.inc-c')).toHaveAttribute('href', /^\/(platform|use-cases)\//);
  }
});

test('the platform compares approaches in a table, not repeated numbers', async ({ page }) => {
  await prep(page);
  await page.goto('/platform');
  const t = page.locator('table.cmp');
  await expect(t.locator('thead th')).toHaveCount(6);
  await expect(t.locator('tbody tr')).toHaveCount(5);
  await expect(t.locator('tbody td.z.m-yes')).toHaveCount(5);
  await expect(page.locator('.stats')).toHaveCount(0);
  // The console card is gone from the platform page.
  await expect(page.locator('#console')).toHaveCount(0);
});

test('no decorative 01 / 02 / 03 numbering on lists that have no order', async ({ page }) => {
  await prep(page);
  for (const route of ['/', '/why-zenstra', '/platform/agent-discovery', '/credit-unions', '/company']) {
    await page.goto(route);
    const n = await page.evaluate(() => [...document.querySelectorAll('main *')].filter((e) => e.children.length === 0 && /^0[1-9]( ·|$)/.test(e.textContent.trim())).length);
    expect(n, route).toBe(0);
  }
});

test('row animations run at 1.5× their authored speed', async ({ page }) => {
  await prep(page);
  await page.goto('/use-cases/data-leakage');
  const scn = page.locator('#how .frow-media figure.scn').nth(1);
  await scn.scrollIntoViewIfNeeded();
  await expect(scn).not.toHaveClass(/\bk1\b/, { timeout: 3000 });
  const t0 = Date.now();
  await expect(scn).toHaveClass(/\bk3\b/, { timeout: 6000 });
  // Authored 1200 + 1050 + 1050 ms to reach step 3; at 1.5× that is 2.2 s.
  expect(Date.now() - t0).toBeLessThan(3000);
});

test('the credit-union examination pack sits beside the headline, not below it', async ({ page, isMobile }) => {
  test.skip(isMobile, 'side by side on wide screens');
  await prep(page);
  await page.goto('/credit-unions');
  const copy = await page.locator('.hero-copy').boundingBox();
  const pack = await page.locator('.pack').boundingBox();
  expect(pack.x).toBeGreaterThan(copy.x + copy.width - 10);
  expect(pack.y).toBeLessThan(copy.y + copy.height / 2);
  expect(pack.y + pack.height).toBeGreaterThan(copy.y + copy.height / 2);
});

test('the header menu stays on one line between the phone menu and wide screens', async ({ page, isMobile }) => {
  test.skip(isMobile, 'desktop menu');
  await prep(page);
  for (const w of [1100, 1180, 1280]) {
    await page.setViewportSize({ width: w, height: 800 });
    await page.goto('/');
    const hs = await page.locator('.nav .nav-link').evaluateAll((l) => l.map((x) => x.getBoundingClientRect().height));
    expect(Math.max(...hs), String(w)).toBeLessThanOrEqual(40);
  }
});

test('capability cards show simple illustrated dashboards, not console screenshots', async ({ page }) => {
  await prep(page);
  await page.goto('/platform');
  await expect(page.locator('.capgrid .capcard')).toHaveCount(6);
  await expect(page.locator('.capgrid .capcard .il')).toHaveCount(6);
  await expect(page.locator('.capgrid img')).toHaveCount(0);
});
