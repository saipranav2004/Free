# NHI Backend API — merged build

> Start with **One backend** below: this tree now also carries the posture and
> genome APIs, the AWS integration APIs and the session-based refresh tokens of
> `nhi-backend-v1`. The sections after it describe the original discovery merge.

A hardened merge of the two candidate backends, validated against
`AWS-NHI Updated API.pdf` and against a real PostgreSQL instance.

**Base:** the `read.txt` tree — chosen because the tenant/account/region boundary is
enforced in one place (`internal/scope`), not re-implemented per endpoint.
**Harvested from:** the `b1.txt` tree — richer detail-tab payloads, concurrent dashboard
loading, and strict `time_range` handling, all re-expressed on top of the scoped base.

```
go build ./...            # clean
go vet ./...              # clean
go test ./...             # clean (also under -race)
```

---

## One backend: discovery, posture, genome and integrations

This build is the single NHI backend. It serves four APIs from one process,
behind one JWT and one tenant scope, on one port:

| Prefix (also under `/api`) | API | Code |
|---|---|---|
| `/api/v1/…` | Discovery and identity graph: login/refresh/logout/me, filters, settings, dashboard, identities, credentials, events, permission source, credential exposure | `internal/{handlers,services,repository}/v1`, `credential_exposure` |
| `/api/v1/integrations/aws…` | Connect AWS Account and exposed-credential enablement | `aws_integration_*`, `internal/awsconnect`, `internal/githubcheck` |
| `/api/v1/ispm/…` | ISPM posture dashboard API, 16 endpoints (`ISPM_posture_Dashboard_API_v2.md`) | `internal/*/postures`, `repository/clickhouse/posture_activity.go` |
| `/api/v1/genome/…` | NHI Genome: dashboard summary, identity pages, anomaly list and reviewer verdicts (`backend-nhi-genome.md` §4.1, §5.1–5.6, §6.1, §6.4; peer groups switched off for now) | `internal/*/genome`, `config/monitoring_clickhouse.go`, `docs/GENOME.md` |

Posture and genome keep their own prefixes because both have an `/identities`
API of their own; the discovery API keeps `/api/v1/identities`. Genome's
response `links` point at `/api/v1/genome/…`.

Scope: discovery and genome follow the user's saved account / region selection
(`<schema>.accounts`, `user_settings`). Posture reads what the posture worker
precomputed for the whole tenant (fleet score, trend, quick wins), so it covers
every account the worker scored and ignores that selection, as the posture API
document specifies; the tenant still comes only from the JWT.

### Sessions (from `nhi-backend-v1`)

Login starts a session: the access token carries its id (`jti`) and every
request checks that the session still exists and has not ended. Refresh tokens
are single-use and stay in the same session; reusing an old one ends every
session of that user. Logout ends the session, so its access token stops
working at once - on every API above, since they share the middleware.
Access tokens issued before `003_refresh_token_session.sql` have no session id
and are rejected, so users sign in again once after the upgrade.

### Migrations, in order

```sh
# nhi_db, once (all re-runnable)
psql "$DSN" -f migrations/global/001_auth_tenant_registry.sql
psql "$DSN" -f migrations/global/002_refresh_tokens.sql
psql "$DSN" -f migrations/global/003_refresh_token_session.sql   # sessions (nhi-backend-v1)
psql "$DSN" -f migrations/global/004_tenant_collector.sql        # AWS integration values on tenants

# every tenant schema (e.g. bimasugam)
psql "$DSN" -v schema=bimasugam -f migrations/tenant/001_user_settings.sql
psql "$DSN" -v schema=bimasugam -f migrations/tenant/004_accounts_regions_array.sql  # only converts an old one-row-per-region accounts table; no-op otherwise
psql "$DSN" -v schema=bimasugam -f migrations/tenant/002_register_global_region.sql  # after inventory data exists
psql "$DSN" -v schema=bimasugam -f migrations/tenant/003_aws_accounts.sql
```

The posture (`ispm_*`) and genome (`baselines`, `alerts`, `identity_risk_scores`,
`alert_feedback`, …) tables are written by their workers and are not created
here. The API writes only reviewer verdicts into `alert_feedback`.

### Configuration

`configs/config.yaml` plus `NHI_*` environment overrides (`.env.example`):
discovery ClickHouse (`NHI_CLICKHOUSE_*`, CloudTrail events, also used by
posture's activity tab), genome monitoring ClickHouse
(`NHI_MONITORING_CLICKHOUSE_*`, `log_events`), and the `aws_integration` block.
Each ClickHouse is optional; without it the dependent fields report
"unavailable" and everything else keeps working.

A Postman collection for the discovery API is in `docs/postman/`.

---

## Tenant architecture

One PostgreSQL database (`nhi_db`); tenants are separated by schema:

```
nhi_db (config: database)
  ├── nhi_global (config: database.schema)
  │     ├── tenants     tenant_id (uuid) → db_name  (db_name = the tenant's schema name)
  │     └── nhi_users   email, bcrypt hash, role, tenant_id, status, last_login_at
  └── <tenant schema>   e.g. tenant_a — name comes from the JWT, never from config
        └── identities, credentials, trust_edges, user_settings, …
```

Login validates the user in `nhi_global`, looks up the tenant's schema name, and issues a
JWT carrying `tenant_id` and `db_name` (the schema name). Every tenant query is
schema-qualified from `DataScope` (`resolved.QSchema()` / `resolved.Table("x")`);
`search_path` is never changed. Schema names are validated (`config.ValidateSchemaName`)
and quoted before use.

**One choke point.** Every data request resolves through `scope.Resolver.Resolve()`,
which returns a `DataScope` carrying the tenant's pool *and* the effective
`AccountIDs / Regions`:

```go
resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
// every repository entry point takes the scope, never a bare *sql.DB
rows, err := s.repo.List(ctx, resolved, filter)
// DataScope.Predicates("i") → i.account_id = ANY($1) AND i.region = ANY($2)
```

Because the repositories cannot be called without a `DataScope`, steps 3–7 of the
document's "Every Data API" flow are structurally impossible to skip.
`user_settings` appears in exactly one non-test file in the repository.

**No fallback.** `Manager.Tenant("")` returns `ErrTenantDBNotConfigured`. A tenant with no
`db_name` is an error, never a silent switch to another schema.

---

## What changed relative to the two inputs

### Correctness / security

| Change | Why |
|---|---|
| **Scoped graph traversal** (`internal/repository/v1/graph_scope.go`) | A graph BFS cannot be constrained by a SQL predicate: hop 2 walks out of the selected accounts. The traversal now prunes every hop against the caller's account/region before expanding the frontier, and fails closed on unparseable ARNs. |
| **`relationships` tab enabled** on both detail endpoints | It was implemented but gated off in `read.txt` ("disabled until graph scope is enforced") and enabled-but-unscoped in `b1.txt`. It is now both enabled and safe — 6/6 tabs per the document. |
| **De-duplicated BFS edges** | Found against the live database: `loadEdgesTouching` matches `source = ANY(frontier) OR target = ANY(frontier)`, so an edge was re-emitted on every hop that touched it. A depth-2 walk reported the same edge twice. |
| **Consolidated `errScopeRequired` sentinel** | Four repositories each built their own `fmt.Errorf("tenant scope is required")`, so callers could not use `errors.Is`. |
| **`page_size` capped at 100**, **`depth` bounded to 1–3** | The document's stated limits were not enforced; `depth` accepted any value and `page_size` was unbounded. |
| **Strict `?time_range=`** (ported from `b1.txt`) | `"banana"` used to silently become 90 days. It is now a 400 with an actionable message, and the response echoes a canonical label rather than raw client input. |
| **Dead legacy code removed** | 301 → 43 Go files. Removed the unrouted dashboard/inventory/credential-exposure packages, which also cleared a genuine `go vet` failure (`fmt.Sprintf` arity bug in `shared_credentials_repo.go`). |
| **`migrations/tenant/001` creates its schema** | It assumed the tenant schema already existed and failed on a fresh one. Run per schema: `psql -v schema=tenant_a -f …`. |

### Performance

**Concurrent dashboard overview.** The four independent loaders (KPIs, identity charts,
credential charts, growth charts) now run in parallel with first-error cancellation of the
remaining queries, instead of sequentially. They write disjoint fields of the response
struct, verified under `-race`.

### Tests

Unit coverage for the parts where a mistake is a tenant-isolation bug:

| Package | Covers |
|---|---|
| `internal/repository/v1` | ARN account/region parsing, scope allow/deny including fail-closed, edge pruning, frontier never leaving scope, BFS de-duplication |
| `internal/scope` | `Predicates()` / `QueryArgs()` shape, empty-scope safety |
| `internal/database` | Identifier quoting, `Tenant()` has no fallback, validation rejects injection attempts |
| `internal/config` | Unsafe schema identifiers (`ValidateSchemaName`), weak JWT secret, out-of-range expiry |
| `pkg/jwt` | Claim round-trip, tamper rejection, wrong-secret rejection, weak-secret rejection |
| `internal/routes` | All seven data endpoints return 401 without a token; 404/405 always return JSON |

---

### Integration tests against real databases

These skip unless pointed at a tenant (a SKIP means nothing was tested):

```bash
export NHI_TEST_TENANT_DB=<tenant schema name> NHI_TEST_TENANT_ID=<tenant uuid> NHI_TEST_USER_ID=<user email>
# ClickHouse comes from .env (NHI_CLICKHOUSE_*); use NHI_CLICKHOUSE_PROTOCOL=http|native
go test ./internal/repository/clickhouse ./internal/services/v1 ./internal/handlers/v1 -count=1 -v
```

They are read-only: every service and handler is exercised with ClickHouse,
without it, and with ClickHouse failing on every query.

## Running it locally

```bash
# 1. Postgres, then seed nhi_db with two tenant schemas
export PGHOST=127.0.0.1 PGPORT=5432 PGUSER=postgres
./scripts/seed_two_tenants.sh

# 2. Point configs/config.yaml at that Postgres and run
NHI_CONFIG_FILE=configs/config.yaml go run ./cmd/api-server

# 3. Verify the tenant guarantees end to end
./scripts/e2e_tenant_scope.sh          # 16 assertions
```

`scripts/test_schema.sql` is a stand-in for the scanner's schema, which this repository
does not own. It is only for local verification — column names were derived from the
queries in `internal/repository/v1`, so treat it as a harness, not as the real schema.

### Identity Event Graph — `GET /api/v1/identities/{id}/events`

A forensic view of one identity's CloudTrail events, one endpoint with nine
sections chosen by `?section=` (`timeline` (default), `detail`, `credentials`,
`resources`, `heatmap`, `sessions`, `errors`, `cross_account`, `ips`).

| Param | Notes |
|---|---|
| `time_range` | `1h`, `6h`, `24h` (default), `7d`, `30d`, `90d`, `custom` (+ `start_date`/`end_date`). Hour ranges exist only here; other endpoints are day-based. |
| `service`, `action`, `result`, `resource`, `source_ip`, `credential`, `read_write` | Filters, applied to every section. `errors` always shows failures, so `result`/`read_write` are ignored there. `credential` must be one of the identity's own credential ARNs. |
| `page`, `page_size` | `page_size` default 100, max 500 (above that is a 400); `page * page_size` ≤ 100000. |
| `event_id` | Required for `section=detail`. |

Behaviour worth knowing:

- Events come from ClickHouse `cloudtrail_events`, matched by the identity's ARN,
  its bound credentials' ARNs and access-key ids, and always limited to the tenant's
  accounts. Postgres (`identities`, `credentials`, `identity_credentials`) is read
  once per request to enrich events in memory; `effective_permissions` is read only
  for `detail` (the policy statement behind the call).
- Fields the table does not store (`service`, `resource_name`, `status`,
  `credential_*`, `binding_type`, `is_cross_account`, `session_name`) are derived.
  `is_cross_account` compares the account in the resource ARN with the identity's
  account; S3 ARNs have no account and are never cross-account. `geo_location` is
  always `null`.
- `credentials` also lists credentials Postgres does not know (for example a role
  assumed from another account), with blank name/type/binding.
- `sessions` are built in Go: a caller's events more than 30 minutes apart start a
  new session (at most 50,000 events are read; `truncated` says if more existed).
- If ClickHouse is disabled or a query fails the section is returned empty with
  `data_available: false` (HTTP 200), like the Activity tab.
- Every ClickHouse query has a 10 s ceiling. The driver's read timeout is
  `NHI_CLICKHOUSE_TIMEOUT_SECONDS` (default 5); set it to 10 to allow the full 10 s.
- 404 for an identity outside the user's account/region selection, and for a
  `detail` `event_id` that does not belong to this identity and tenant.

### CloudTrail activity (ClickHouse)

CloudTrail events live in ClickHouse (`cloudtrail_events`); Postgres no longer
stores `identity_usage`, `permission_usage` or `resources`, and the columns
`identities.last_activity_at`, `identities.cloudtrail_creator_arn` and
`credentials.last_used_at` are no longer written by the collector. The two
databases are joined **by ARN only** (never by UUID):

| ClickHouse | Matches |
|---|---|
| `session_issuer_arn` | `credentials.arn` (a role) |
| `caller_arn` | `identities.arn` (IAM users, root) or an assumed-role session |
| `access_key_id` | `credentials.name` where `credential_type = 'access_key'` |

- **Layout:** `internal/clickhouse` (connection), `internal/repository/clickhouse`
  (SQL, raw rows), `internal/repository/v1/activity_source.go` (the interface the
  repositories use), `internal/services/v1/activity_*.go` (cache, analytics, tab
  builders), `internal/services/v1/identity_resolver.go` (caller → identity).
- **Isolation:** every ClickHouse query is bound to all accounts of the tenant
  (`accounts` table), whatever the user ticked in Settings.
- **Degradation:** unset (`NHI_CLICKHOUSE_HOST` empty), unreachable or failing
  ClickHouse never turns a response into an error. Activity fields are `null` or
  empty and `activity_data_available` is `false`.
- **Lists and dashboard:** idle days, `min_idle_days`, sorting by
  `last_activity_at` / `idle_days` / `last_used_at` / `permission_utilization_pct`
  (and the default sorts) are applied in Go over one bulk ClickHouse lookup,
  cached for 5 minutes. Stale detection falls back to the creation date for
  items never seen in CloudTrail.
- **Windows:** "what a credential actually used" (permission utilisation, the
  permissions tab, the trust summary) looks back 90 days; the relationships tab's
  ACCESSES edges use the requested `time_range`; last-seen is unbounded.
- **Events:** the activity tabs take `page` and `page_size` (max 100, at most 1000
  events per request). Every event carries `caller_arn`, `caller_type` and, when it
  resolves to the inventory, `credential_id/name`, `identity_id/name` and
  `terminated`; events that match nothing keep the raw ARN. ACCESSES edges carry
  `call_count`.
- **Permission source (on demand):** `GET /api/v1/permission-source?credential_id=&event_source=&event_name=`
  returns the policy that granted one event (`policy_source`, `policy_type`,
  `effect`, `resource_arn`, `matched_action`; wildcards such as `ec2:Describe*`
  match, an exact Allow beats a wildcard or a Deny). Nothing matched gives
  `matched: false` and "Policy may have changed since this event".
- **Config:** `NHI_CLICKHOUSE_*` (see `.env.example`); `NHI_CLICKHOUSE_PROTOCOL`
  is `native` (TCP 9000/9440) or `http` (8123/8443).
- **Checking a deployment:** at start-up the server logs `clickhouse connected
  (host:port/db)` for the CloudTrail store and `monitoring clickhouse connected`
  (or why it is not) for the genome store. The server is the only program in
  this module (`cmd/api-server`).

### Endpoints

| # | Endpoint | Notes |
|---|---|---|
| — | `POST /api/v1/login`, `/api/auth/login` | bcrypt; rejects `status != 'active'`; updates `last_login_at`; returns a 1 h access `token` + 7 d `refresh_token` |
| — | `POST /api/v1/refresh`, `/api/auth/refresh` | body `{"refresh_token"}`; single-use (rotated); reuse of an old token revokes all of the user's sessions |
| — | `POST /api/v1/logout`, `/api/auth/logout` | body `{"refresh_token"}`; revokes it |
| 1a | `GET /api/v1/settings` | `user_settings` → `accounts.is_default` |
| 1b | `PUT /api/v1/settings` | upsert; JWT is unchanged |
| 2 | `GET /api/v1/filters` | all dropdown options |
| 3 | `GET /api/v1/dashboard/overview` | KPIs + 13 charts, loaded concurrently |
| 4 | `GET /api/v1/identities` | paginated (max 100), searchable, filterable, sortable |
| 5 | `GET /api/v1/identities/{id}?tab=` | overview, permissions, activity, relationships, credentials, raw |
| 6 | `GET /api/v1/credentials` | |
| 7 | `GET /api/v1/credentials/{id}?tab=` | overview, trust, activity, rotation, relationships, raw |
| 8 | `GET /api/v1/permission-source` | policy behind one CloudTrail event, looked up on demand |

---

## Connect AWS Account and exposed credentials (Integrations page)

Six endpoints back the console's Integrations page. They live in this service
(`internal/handlers/v1/aws_integration_handler.go`, service, repository,
`internal/awsconnect`, `internal/githubcheck`) and are mounted under both
`/api/v1` and `/api`. Reads are open to every signed-in user; changes need the
`admin` (or `super_admin`) role.

| Method | Path | What it does |
|---|---|---|
| GET | `/integrations/aws` | Setup values for this tenant, every connected account, `has_connected_account`, `exposure_enabled`, `can_manage` |
| POST | `/integrations/aws/verify` | `{role_arn, regions}` - runs the three checks, saves the account |
| PUT | `/integrations/aws/accounts/{id}/regions` | `{regions}` - regions a sync may read |
| PUT | `/integrations/aws/accounts/{id}/exposure` | `{github, codecommit, github_secret_arn}` - switch exposed-credential scanning on or off per platform |
| POST | `/integrations/aws/accounts/{id}/sync` | queue a discovery sync |
| DELETE | `/integrations/aws/accounts/{id}` | disconnect the account |

### Database

Apply once to `nhi_db` (both safe to run again; see "Migrations, in order"
above for the full list):

```sh
psql "$DSN" -f migrations/global/004_tenant_collector.sql            # nhi_global.tenants columns
psql "$DSN" -v schema=bimasugam -f migrations/tenant/003_aws_accounts.sql   # per tenant schema
```

`nhi_global.tenants` gains `domain_name`, `collector_aws_account_id` (our
account the customer's role trusts), `collector_external_id` (generated, unique,
never change it once used), `collector_event_bridge_arn` (our central bus) and
`collector_regions` (regions customers may choose; empty means all).

`<tenant schema>.aws_accounts` holds one row per customer AWS account:
`client_aws_account_id`, `client_role_arn`, `regions`, `external_id`,
`is_connected`, `account_status` (`pending` / `connected` / `action_needed`),
`github_connected`, `codecommit_connected`, plus check results, the GitHub
secret ARN, and the sync queue columns. An AWS account can belong to one tenant
only (checked across schemas under an advisory lock).

The scope table `<tenant schema>.accounts` (one row per account:
`tenant_id, account_id, regions text[], is_default`) is kept in step: a
connected account gets a row whose `regions` are the allowed regions plus
`global` (in the default scope; IAM roles and users are recorded under the
synthetic `global` region, so they show as soon as the account connects),
editing regions rewrites that array (keeping `global`), and removing the
account deletes the row. Dashboards, filters,
settings and ClickHouse isolation read that table, so a connected account shows
up everywhere.

Without the migrations the page answers 503 `AWS_PLATFORM_NOT_CONFIGURED`.

### Connection checks (verify)

| Check | How | Fix shown |
|---|---|---|
| Assume your role | `sts:AssumeRole` with the tenant's External ID | Check the trust policy / External ID |
| Read your account | `iam:ListRoles` (1 item) | Attach SecurityAudit + ViewOnlyAccess |
| Receive your events | allows the account on our bus, then looks for one of its events in the last `event_lookback_hours` (ClickHouse, else `event_log_group`) | Check the EventBridge rule target ARN |

One check per tenant at a time (429 `AWS_VERIFY_IN_PROGRESS`), 12 s budget.
Nothing is saved unless AssumeRole succeeds. The first full pass sets
`connected_at`, registers the scope rows and queues the first sync.

### Exposed credentials (GitHub / CodeCommit)

Only for an account that has connected. Each platform needs one extra grant on
the customer's existing role; the page shows the steps with their values filled in.

- **CodeCommit:** attach the AWS-managed `AWSCodeCommitReadOnly`, or an inline
  policy with `codecommit:ListRepositories, BatchGetRepositories, GetRepository,
  ListBranches, GetBranch, GetCommit, GetDifferences, GetBlob, GetFile,
  GetFolder, GitPull`. Checked by listing repositories in the account's regions
  and reading one repository's root folder.
- **GitHub:** a fine-grained token with *Contents: Read-only* (and
  *Metadata: Read-only*) stored in the customer's own Secrets Manager under a name
  starting with `github_secret_prefix` (`nhi/github`), and an inline policy on
  the role allowing `secretsmanager:GetSecretValue` and `DescribeSecret` on
  `arn:aws:secretsmanager:*:<account>:secret:nhi/github*` (plus `kms:Decrypt` if
  the secret uses a customer managed key). Checked by reading the secret through
  the role and calling GitHub (`/user`, `/user/repos`, one repository's
  contents). The token is never stored or logged; only the secret ARN is.

A platform is switched on only when its checks pass. `exposure_enabled` is
true when any account has one on; the console shows the exposed-credential
screens only then.

Secret scanner contract: scan CodeCommit where `codecommit_connected`, and the
GitHub token at `github_secret_arn` where `github_connected`, by assuming
`client_role_arn` with `external_id`.

### Sync contract (discovery worker)

The API only queues (`sync_status = 'queued'`). The worker claims one account
at a time per tenant schema:

```sql
UPDATE <schema>.aws_accounts SET sync_status = 'running', sync_started_at = now()
 WHERE client_aws_account_id = (
       SELECT client_aws_account_id FROM <schema>.aws_accounts
        WHERE sync_status = 'queued' ORDER BY sync_requested_at
        FOR UPDATE SKIP LOCKED LIMIT 1)
RETURNING client_aws_account_id, client_role_arn, external_id, regions;
```

It reads only `regions`, then sets `sync_status = 'succeeded', last_synced_at =
now(), last_sync_error = ''`, or `'failed'` with a short `last_sync_error`
(shown to the customer).

### AWS identity of this service

No AWS keys in config. The SDK default chain is used:

- **Production:** run the API as `NHIPlatformAssumer` (ECS task role / EC2
  instance profile) with `assume_assumer_role: false`.
- **Locally:** `AWS_PROFILE=<profile>` and `NHI_AWS_ASSUME_ASSUMER_ROLE=true`;
  the profile must be allowed to assume
  `arn:aws:iam::<collector_aws_account_id>:role/NHIPlatformAssumer`.

`NHIPlatformAssumer` needs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    { "Effect": "Allow", "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::*:role/NHIPlatformCollector" },
    { "Effect": "Allow",
      "Action": ["events:DescribeEventBus", "events:PutPermission", "events:RemovePermission"],
      "Resource": "arn:aws:events:<region>:<our account>:event-bus/<bus name>" },
    { "Effect": "Allow", "Action": "logs:FilterLogEvents",
      "Resource": "arn:aws:logs:<region>:<our account>:log-group:<event_log_group>:*" }
  ]
}
```

The last statement is only needed with `event_log_group`. Settings are under
`aws_integration` in `configs/config.yaml`, with `NHI_AWS_*` /
`NHI_GITHUB_API_URL` overrides (see `.env.example`). Each connected account adds
one statement to the bus policy (about 10 KB, roughly 100 accounts per bus).

### Errors

| HTTP | `error` | When |
|---|---|---|
| 400 | `INVALID_ROLE_ARN`, `INVALID_REGIONS`, `INVALID_SECRET_ARN`, `INVALID_ACCOUNT_ID`, `INVALID_REQUEST` | bad input |
| 403 | `FORBIDDEN` | not an admin |
| 404 | `AWS_ACCOUNT_NOT_FOUND` | not this tenant's account |
| 409 | `AWS_ACCOUNT_NOT_CONNECTED` | sync or exposure before the account has connected |
| 409 | `AWS_ACCOUNT_IN_USE` | account belongs to another tenant |
| 429 | `AWS_VERIFY_IN_PROGRESS` | a check is already running for this tenant |
| 503 | `AWS_PLATFORM_NOT_CONFIGURED` | migrations missing or the tenant row has no collector values |
| 503 | `AWS_UNAVAILABLE` | AWS unreachable, or this service has no AWS identity |

---


## Known gaps

- **Endpoint 7 `trust` / `rotation` payloads** are thinner than endpoint 5's.
  `b1.txt` had richer bodies; porting them is mechanical (same
  `(ctx, resolved, id)` signature) but was not completed here.
- **CloudTrail data depends on ClickHouse.** With ClickHouse unset or down every
  endpoint still answers from Postgres; the activity tabs are empty and the
  responses carry `activity_data_available: false` (see below).
- **Role-session attribution is only unit-tested.** The dev ClickHouse has no
  `session_issuer_arn` values, so resolving role sessions to identities, creator
  lookup and permission usage have fixture tests but no real-data test yet.
- **`scripts/test_schema.sql`** is a local harness, not the production schema.
