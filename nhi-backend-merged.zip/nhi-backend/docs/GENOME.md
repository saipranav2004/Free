# NHI Genome – Identities and anomaly APIs (backend-nhi-genome.md §4.1, §5.1–§5.6, §6.1, §6.4)

> Peer groups (§5.7 `…/peers` and the dashboard's `peer_group_outliers`) are
> switched off for now: the route, its code and the summary section were removed.

This is your latest backend (schema-per-tenant) **plus** the NHI Genome feature: the
behaviour-monitoring dashboard summary and all seven Identities endpoints. The feature sits in its
own `genome` packages (same pattern as `credential_exposure`) and is wired in
`internal/routes/routes.go` and `cmd/api-server/main.go`. Nothing else in the backend changed.

Everything is read directly from the tenant's PostgreSQL schema (resolved from the JWT `db_name`
through the existing `scope.Resolver` / `DataScope.Table(...)`) and from the research team's
ClickHouse `log_events` table (configured in `.env`). There is **no hardcoded data anywhere**: a
value is a query result, or `null` / `available:false` when the contract leaves it unconfirmed or
the store cannot be read.

---

## 1. One file per API, in every layer

| Endpoint | handler (`internal/handlers/genome`) | service (`internal/services/genome`) | repository (`internal/repository/genome`) | model (`internal/models/genome`) |
|---|---|---|---|---|
| `GET /api/v1/genome/dashboard/summary` (§4.1) | `dashboard_summary_handler.go` | `dashboard_summary_service.go` | `dashboard_summary_repo.go` | `dashboard_summary.go` |
| `GET /api/v1/genome/identities` (§5.1) | `identity_list_handler.go` | `identity_list_service.go` | `identity_list_repo.go` | `identity_list.go` |
| `GET /api/v1/genome/identities/{source_type}/{identity_name}` (§5.2) | `identity_summary_handler.go` | `identity_summary_service.go` | `identity_summary_repo.go` | `identity_summary.go` |
| `…/activity` (§5.3) | `identity_activity_handler.go` | `identity_activity_service.go` | `identity_activity_repo.go` | `identity_activity.go` |
| `…/genome` (§5.4) | `identity_genome_handler.go` | `identity_genome_service.go` | `identity_genome_repo.go` | `identity_genome.go` |
| `…/baseline` (§5.5) | `identity_baseline_handler.go` | `identity_baseline_service.go` | `identity_baseline_repo.go` | `identity_baseline.go` |
| `…/timeline` (§5.6) | `identity_timeline_handler.go` | `identity_timeline_service.go` | `identity_timeline_repo.go` | `identity_timeline.go` |
| `GET /api/v1/genome/anomalies` (§6.1), `POST …/anomalies/{alert_id}/feedback` (§6.4) | `anomalies_handler.go` | `anomalies_service.go` | `anomalies_repo.go` | `anomalies.go` |

Each `<api>_repo.go` holds **both** stores of that API: its PostgreSQL queries (tenant schema) and,
below a `ClickHouse log_events` divider, its ClickHouse queries. `activity` and `genome` are
ClickHouse-only, `baseline` / `timeline` / `dashboard/summary` are PostgreSQL-only.

Shared (non-API) files, kept deliberately small:

```
internal/handlers/genome/common.go            envelope {data, meta}, error body, query-param helpers
internal/handlers/genome/identity_route.go    {source_type}/{identity_name} path parsing, from/to window, error → HTTP mapping
internal/services/genome/identity_lookup.go   resolve one identity / the whole fleet inside the tenant scope
internal/services/genome/identity_normalizer.go  discovery row → monitoring key (contract §1.4)
internal/repository/genome/common.go          MonitoringKey + the "bind a list of keys into one query" helpers
internal/repository/genome/monitoring_events.go  ClickHouse connection wrapper + TotalCalls (shared by §5.2/§5.3/§5.4)
internal/config/monitoring_clickhouse.go      NHI_MONITORING_CLICKHOUSE_* loader
internal/routes/routes.go                     Genome*Handler fields + routes (same style as the existing routes)
cmd/api-server/main.go                        the "// NHI Genome" blocks (monitoring ClickHouse client + wiring)
```

No test files, no migrations, no writes: every endpoint is a GET that reads what is there. Empty
tables give `0` / empty lists / `null` (a legitimate "still learning" state), never invented values.

---

## 2. Configure & run (Windows / PowerShell)

1. **`.env`** – your own `.env` is included unchanged, with the monitoring ClickHouse block appended at
   the end. Host, port, protocol, database and table are already filled in; put in the two
   credentials you have:

   ```
   NHI_MONITORING_CLICKHOUSE_HOST=65.2.175.44
   NHI_MONITORING_CLICKHOUSE_PROTOCOL=http
   NHI_MONITORING_CLICKHOUSE_PORT=8123
   NHI_MONITORING_CLICKHOUSE_DATABASE=Bimasugam_ClickHouse
   NHI_MONITORING_CLICKHOUSE_TABLE=log_events
   NHI_MONITORING_CLICKHOUSE_USER=          <- fill in
   NHI_MONITORING_CLICKHOUSE_PASSWORD=      <- fill in
   NHI_MONITORING_CLICKHOUSE_SECURE=false
   NHI_MONITORING_CLICKHOUSE_TIMEOUT_SECONDS=5
   ```

   These are separate from the old `NHI_CLICKHOUSE_*` keys (CloudTrail store), which stay as they are.
   If the host is empty or unreachable the server still starts; every ClickHouse-backed field is `null`
   and the log says `monitoring clickhouse unavailable`. (`.env.example` has the same keys with empty
   values for the repo.)

2. **Build & run**

   ```powershell
   go build ./...
   go vet ./internal/... ./cmd/...
   go run .\cmd\api-server
   ```

   Startup log to look for: `monitoring clickhouse connected (65.2.175.44:8123/Bimasugam_ClickHouse.log_events)`.

---

## 3. Routes (all behind the existing JWT middleware, under `/api/v1/genome` and `/api/genome`)

> **Merged backend:** this service now runs inside the single NHI backend. The
> genome endpoints are mounted under the `/genome` prefix (`routes.GenomeBasePath`),
> because `/identities` and `/identities/{id}/…` belong to the discovery API. So
> `GET /identities` below is `GET /api/v1/genome/identities`, and so on. The
> discovery identity list at `GET /api/v1/identities` is unchanged.

| Method & path | Query parameters |
|---|---|
| `GET /dashboard/summary` | `from`, `to`, `source_type`, `account_id`, `region` |
| `GET /identities` (the contract §5.1 list) | `source_type`, `search`, `account_id`, `region`, `status`, `baseline=established\|learning`, `sort=risk_desc\|last_seen_desc\|name_asc`, `limit`, `cursor` |
| `GET /identities/{source_type}/{identity_name}` | `from`, `to` |
| `GET /identities/{source_type}/{identity_name}/activity` | `from`, `to`, `bucket=day\|hour`, `recent_limit`, `recent_cursor` |
| `GET /identities/{source_type}/{identity_name}/genome` | `from`, `to`, `limit` |
| `GET /identities/{source_type}/{identity_name}/baseline` | `limit` (versions) |
| `GET /identities/{source_type}/{identity_name}/timeline` | `limit`, `cursor` |
| `GET /anomalies` (§6.1) | `source_type` + `identity_name` (one identity), `search`, `dimension`, `state`, `review=pending\|reviewed`, `from`, `to`, `limit`, `cursor` |
| `POST /anomalies/{alert_id}/feedback` (§6.4) | body `{"decision":"malicious\|legitimate\|unknown","approved_for_baseline":false,"reason":"…"}` |

* `identity_name` must be URL-encoded (Postman: paste the ARN and let Postman encode it, or encode `/` as `%2F`).
* `limit` default 25, max 100; `cursor` is opaque – copy `meta.next_cursor` into the next request unchanged.
* `from` inclusive / `to` exclusive, ISO-8601 UTC; default window = last 14 days.
* Unknown query parameters → `400 VALIDATION_ERROR`; unknown identity → `404 IDENTITY_NOT_FOUND`;
  tenant scope/discovery failure → `503 STORE_UNAVAILABLE`; missing monitoring tables or ClickHouse → **200 with nulls**.
* `baseline=established` keeps identities whose behaviour baseline is active (the
  dashboard's "baselines established" count); `learning` keeps the rest.
* Anomalies are the tenant's `alerts` rows for identities in scope, newest first, with the
  triggering `log_events` row from ClickHouse and the latest reviewer verdict. `counts` gives
  `needs_review` / `reviewed` / `real_anomaly` / `false_positive` for the same filters.
* Feedback (analyst or admin; viewers get `403 FORBIDDEN`): the console's **Real anomaly** is
  `malicious`, **False positive** is `legitimate`, **Not sure** is `unknown`.
  `approved_for_baseline:true` (only with `legitimate`) asks the pipeline to learn the behaviour as
  normal. A second verdict on the same alert replaces the first. The verdict is stored in
  `alert_feedback` (keyed by source type and event id, reviewer = the signed-in email) and never
  changes `alerts.status`. `alert_feedback` is owned by the genome pipeline; without it the list
  reports `feedback_available:false` and a verdict returns `503 FEEDBACK_UNAVAILABLE`. Unknown
  alert → `404 ANOMALY_NOT_FOUND`; alert with no event to key the verdict on →
  `409 ANOMALY_NOT_REVIEWABLE`.
* The discovery API's `GET /api/v1/identities`, `GET /api/v1/identities/{id}` and
  `GET /api/v1/identities/{id}/events` are untouched and still routed.

---

## 4. Response shapes

Every response is `{ "data": ..., "meta": { "request_id", "generated_at", "next_cursor" } }`; errors are
`{ "error": { "code", "message", "request_id" } }` (contract §1.5).

**§5.1 `GET /identities`** → `data.items[]`, each item exactly:
`id, source_type, identity_name, display_name, workload_key, status, account_id, region, service_name,
role_type, role_arn, baseline{status,built_days,required_days}, risk{score,severity,status}, last_seen,
open_anomaly_count, provenance_confidence`. Page cursor in `meta.next_cursor`.

**§5.6 `…/timeline`** → `data.items[]`, newest first:

| `type` | `occurred_at` | `title` | `description` | `status` |
|---|---|---|---|---|
| `anomaly` (one per `alerts` row, any status) | `alerts.created_at` | `Anomaly detected` | `Dimension: <alerts.dimension>; <alerts.reason>` | `alerts.status` |
| `baseline_version_published` | `baseline_versions.published_at` | `Baseline version published` | `Version <n>` | – |
| `learning_started` | `baselines.first_seen_date` (midnight UTC) | `Learning started` | – | – |
| `baseline_established` | `baselines.active_since` | `Baseline established` | – | – |

---

## 5. Decisions where the contract says NEEDS CONFIRMATION (all reversible, each is one small block)

| Item | What the code does now |
|---|---|
| `provenance_confidence` in the list item | always `null` – §10.2 leaves the latest-vs-average rule unconfirmed |
| `model_confidence_percent` (baseline) | `null` / `available:false` – no source column |
| `status` filter | exact (case-insensitive) match on the raw `identities.status` of the latest snapshot; no mapping, no enum |
| `search` | case-insensitive substring over `identity_name`, `display_name`, `workload_key`, `service_name`, `role_arn` |
| `sort=name_asc` | `display_name` (case-insensitive), then id |
| list `data` wrapper | `data.items[]`, like the contract's other list endpoints (§5.6, §7.1) |
| timeline titles / descriptions | constant title per type (§10.3); the only metadata emitted for a version is its number – never `profile_json` |
| ClickHouse per identity | `last_seen` is read **only for the page** (for the whole filtered set only when `sort=last_seen_desc`); never the event history |

---

## 6. Verify the numbers in DBeaver

Replace `<schema>` with the tenant schema from your JWT `db_name`, `<st>`/`<name>` with the identity.

```sql
-- §5.1 baseline block
SELECT status, built_days, required_days FROM <schema>.baselines
 WHERE source_type = '<st>' AND identity_name = '<name>';

-- risk block (latest completed snapshot)
SELECT risk_score, severity, score_status FROM <schema>.identity_risk_scores
 WHERE source_type = '<st>' AND identity_name = '<name>' AND window_end <= now()
 ORDER BY window_end DESC, computed_at DESC LIMIT 1;

-- open_anomaly_count (list, header)
SELECT COUNT(*) FROM <schema>.alerts
 WHERE source_type = '<st>' AND identity_name = '<name>' AND status = 'open';


-- baseline data_points (§5.5)
SELECT SUM(event_count) FROM <schema>.daily_stats
 WHERE nhi_type = '<st>' AND identity_name = '<name>';

-- timeline rows
SELECT 'anomaly' AS type, created_at AS occurred_at, dimension, reason, status FROM <schema>.alerts
 WHERE source_type = '<st>' AND identity_name = '<name>'
UNION ALL
SELECT 'baseline_version_published', published_at, version::text, NULL, NULL FROM <schema>.baseline_versions
 WHERE source_type = '<st>' AND identity_name = '<name>'
UNION ALL
SELECT 'learning_started', first_seen_date::timestamptz, NULL, NULL, NULL FROM <schema>.baselines
 WHERE source_type = '<st>' AND identity_name = '<name>' AND first_seen_date IS NOT NULL
UNION ALL
SELECT 'baseline_established', active_since, NULL, NULL, NULL FROM <schema>.baselines
 WHERE source_type = '<st>' AND identity_name = '<name>' AND active_since IS NOT NULL
ORDER BY occurred_at DESC;
```

ClickHouse (DBeaver ClickHouse connection, one statement at a time):

```sql
-- total_calls / calls_in_window for the default 14-day window (§5.2, §5.3, §5.4)
SELECT uniqExact(event_id) FROM Bimasugam_ClickHouse.log_events
 WHERE source_type = '<st>' AND identity_name = '<name>'
   AND event_time >= now() - INTERVAL 14 DAY AND event_time < now();

-- last_seen (header, list)
SELECT max(event_time) FROM (
  SELECT event_id, argMax(event_time, ingested_at) AS event_time, argMax(is_resolved, ingested_at) AS is_resolved
  FROM Bimasugam_ClickHouse.log_events
  WHERE source_type = '<st>' AND identity_name = '<name>' GROUP BY event_id
) WHERE is_resolved = 1;

-- call volume per day (§5.3)
SELECT toStartOfDay(event_time) AS bucket, uniqExact(event_id) AS calls
  FROM Bimasugam_ClickHouse.log_events
 WHERE source_type = '<st>' AND identity_name = '<name>'
   AND event_time >= now() - INTERVAL 14 DAY AND event_time < now()
 GROUP BY bucket ORDER BY bucket;

-- typical actions (§5.4)
SELECT event_source, event_name, uniqExact(event_id) AS calls
  FROM Bimasugam_ClickHouse.log_events
 WHERE source_type = '<st>' AND identity_name = '<name>'
   AND event_time >= now() - INTERVAL 14 DAY AND event_time < now()
 GROUP BY event_source, event_name ORDER BY calls DESC LIMIT 25;
```

If `baselines` has a row under the identity's `workload_key` instead of its `identity_name`, the API
uses that row (the contract's shared-profile fallback) – query with the workload key in that case.

