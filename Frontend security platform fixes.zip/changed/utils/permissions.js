// Front-end permission helpers. These ONLY control UI visibility — the
// backend (OPA + @require_permission / @require_admin) is the real authority.

/**
 * Admin detection.
 *
 * Bug fix — the navbar showed "User" for a genuine administrator. The profile
 * payload (`GET /auth/me`) is not consistent about where the role lives: it may
 * arrive as `role: 'admin'`, `account_type: 'admin'`, `roles: ['admin']`,
 * `roles: [{ role_name: 'admin' }]`, or `is_admin: true` — and the registration
 * response uses BOTH `role` and `account_type`. The old check only looked at
 * `roles` (as strings) and `account_type`, so the very common `role: 'admin'`
 * shape fell through to the generic label. Every shape is recognised now.
 */
const ADMIN_WORDS = ['admin', 'administrator', 'root', 'rootadmin', 'root_admin', 'superadmin', 'super_admin', 'owner'];

/** Every role-ish token on a profile, lower-cased, from any payload shape. */
export function roleTokens(user) {
  if (!user) return [];
  const out = [];
  const push = (v) => {
    if (!v) return;
    if (typeof v === 'string') out.push(v.toLowerCase().trim());
    else if (Array.isArray(v)) v.forEach(push);
    else if (typeof v === 'object') push(v.role_name || v.name || v.role || v.slug);
  };
  push(user.role);
  push(user.roles);
  push(user.account_type);
  push(user.account_types);
  push(user.user_type);
  push(user.role_names);
  return out.filter(Boolean);
}

export function isAdmin(user) {
  if (!user) return false;
  if (user.is_admin === true || user.is_root === true || user.is_superuser === true) return true;
  return roleTokens(user).some((token) => ADMIN_WORDS.includes(token));
}

/**
 * The label to render in the navbar and profile panel.
 *
 * Prefers the tenant's own role name (so a custom role such as "Security
 * Analyst" is shown verbatim, title-cased) and only falls back to a generic
 * label when the profile genuinely carries no role at all.
 */
export function roleLabel(user) {
  if (!user) return 'Signed out';
  if (isAdmin(user)) {
    const tokens = roleTokens(user);
    const isRootAdmin = tokens.some((t) => t.includes('root')) || user.is_root === true;
    return isRootAdmin ? 'Root administrator' : 'Administrator';
  }
  const first = roleTokens(user)[0];
  if (!first) return 'User';
  // "security_analyst" / "security-analyst" → "Security analyst"
  const words = first.replace(/[_-]+/g, ' ').trim();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

export function hasRole(user, role) {
  if (!user) return false;
  const roles = user.roles || [];
  return roles.includes(role);
}

// Root / super-admin check. This ONLY controls UI visibility — the backend
// (`is_root_user` in integrations/oracle_db/config.py) is the real authority.
// The root admin is identified by IAM user id; the seeded id is
// b41250cc-84ae-4f19-adcf-c0bc32ebc91b.
export function isRoot(user) {
  if (!user) return false;
  const id = (user.id || user.sub || user.user_id || '').toString().toLowerCase();
  return id === 'b41250cc-84ae-4f19-adcf-c0bc32ebc91b';
}

// Simple capability gate used by RequirePermission route wrapper.
export function can(user, permission) {
  if (!user) return false;
  if (isAdmin(user)) return true;
  // Delegated permissions (populated by identity middleware) take over for
  // non-admin human users.
  const delegations = user.delegations || [];
  return delegations.some((d) =>
    Array.isArray(d.permissions) ? d.permissions.includes(permission) : false
  );
}
