/**
 * errors.js — the console's single source of user-facing error copy.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS EXISTS
 * ═══════════════════════════════════════════════════════════════════════════
 * Toasts and inline alerts were previously fed whatever the backend put in
 * `message`, which in an identity platform is a real problem: those strings
 * routinely carry tracebacks, SQL fragments, OPA rule paths, internal service
 * names and Python exception text. That is developer information leaking into
 * an operator's screen — noisy at best, an information-disclosure finding at
 * worst.
 *
 * So: the HTTP status decides the message. A backend string is only surfaced
 * when it passes `looksHuman()` — short, prose-like, and free of anything that
 * smells like internals. Everything else is replaced with the status-based
 * sentence. Detail is still available to engineers in the console (see
 * `logTechnicalDetail`), never in the UI.
 */

/** Fragments that mark a string as developer-facing, not operator-facing. */
const INTERNAL_MARKERS = [
  'traceback', 'stack trace', 'stacktrace', 'exception', 'errno', 'sqlalchemy',
  'psycopg', 'integrityerror', 'operationalerror', 'programmingerror',
  'keyerror', 'typeerror', 'valueerror', 'attributeerror', 'nonetype',
  'null pointer', 'undefined is not', 'cannot read propert',
  'select ', 'insert into', 'update set', 'duplicate key', 'constraint',
  'psql', 'ora-', 'werkzeug', 'flask', 'django', 'gunicorn', 'uwsgi',
  'file "', 'line ', '.py', '.js:', 'at async', 'axioserror',
  'econnrefused', 'enotfound', 'etimedout', 'socket hang up',
  'opa', 'rego', 'localhost:', '127.0.0.1', '0.0.0.0',
  '<!doctype', '<html', '{"', 'json', 'internal server',
];

/** Status → the sentence an administrator should actually read. */
const STATUS_COPY = {
  400: 'Some of the details submitted are not valid. Review the form and try again.',
  401: 'Your session has expired. Sign in again to continue.',
  403: 'You do not have permission to perform this action.',
  404: 'That item no longer exists, or it is not available to this account.',
  405: 'This action is not available on the current platform version.',
  408: 'The request took too long to complete. Please try again.',
  409: 'That change conflicts with the current state. Refresh and try again.',
  410: 'That item is no longer available.',
  413: 'The information submitted is too large to process.',
  422: 'Some of the details submitted could not be processed. Review the form and try again.',
  423: 'This item is locked and cannot be changed right now.',
  429: 'Too many requests. Wait a moment before trying again.',
  500: 'Something went wrong on our side. Please try again in a moment.',
  501: 'This action is not supported on the current platform version.',
  502: 'The service is temporarily unreachable. Please try again shortly.',
  503: 'The service is temporarily unavailable. Please try again shortly.',
  504: 'The service took too long to respond. Please try again shortly.',
};

const NETWORK_COPY =
  'Unable to reach the service. Check your connection and try again.';
const GENERIC_COPY = 'Something went wrong. Please try again.';

/**
 * Is this string safe and useful to show an operator?
 *
 * Deliberately strict: prose only, one or two sentences, no internals, no
 * identifiers, no punctuation soup. A borderline string is rejected — a clean
 * generic sentence always beats a leaked one.
 */
export function looksHuman(text) {
  if (typeof text !== 'string') return false;
  const value = text.trim();
  if (value.length < 4 || value.length > 160) return false;

  const lower = value.toLowerCase();
  if (INTERNAL_MARKERS.some((marker) => lower.includes(marker))) return false;

  // Braces, angle brackets and pipes indicate a payload or a log line.
  if (/[{}<>|\\]/.test(value)) return false;
  // A bare UUID or long token is an identifier, not a message.
  if (/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}/i.test(value)) return false;
  // Must read as words, not as a code path.
  if (!/[a-z]{3}/i.test(value)) return false;
  if (value.split(/\s+/).length < 2) return false;

  return true;
}

/** Optional, dev-only breadcrumb so engineers keep the real detail. */
export function logTechnicalDetail(scope, error) {
  if (!import.meta.env?.DEV) return;
  // eslint-disable-next-line no-console
  console.debug(`[${scope}]`, error?.response?.status ?? '', error?.response?.data ?? error);
}

/**
 * The message to show for a failed request.
 *
 * @param {unknown} error    an axios-style error
 * @param {string}  fallback context-specific copy, e.g. 'Could not attach the policy.'
 */
export function friendlyMessage(error, fallback) {
  const status = error?.response?.status;

  // A refused/blocked request never reached the service.
  if (error && !error.response && (error.request || error.code)) {
    return NETWORK_COPY;
  }

  // Prefer a backend sentence only when it is genuinely human-readable, and
  // never for 5xx — those messages are the ones that carry internals.
  const raw = pickRawMessage(error);
  if (status && status < 500 && looksHuman(raw)) return polish(raw);

  if (status && STATUS_COPY[status]) return STATUS_COPY[status];
  if (status && status >= 500) return STATUS_COPY[500];

  return fallback || GENERIC_COPY;
}

/** Pull whichever field the backend used, without judging it yet. */
function pickRawMessage(error) {
  const data = error?.response?.data;
  if (!data) return '';
  if (typeof data === 'string') return data;
  if (typeof data.message === 'string') return data.message;
  if (typeof data.error === 'string') return data.error;
  if (typeof data.detail === 'string') return data.detail;
  if (typeof data.error?.message === 'string') return data.error.message;
  return '';
}

/** Sentence-case, single space, trailing full stop. */
function polish(text) {
  const value = text.trim().replace(/\s+/g, ' ');
  const cased = value.charAt(0).toUpperCase() + value.slice(1);
  return /[.!?]$/.test(cased) ? cased : `${cased}.`;
}

/**
 * Attach a clean `userMessage` to an error. Called by the API clients so every
 * `catch (err) { toast.error(err.userMessage || '…') }` in the app is safe
 * without touching a single call site.
 */
export function attachUserMessage(error, fallback) {
  error.userMessage = friendlyMessage(error, fallback);
  return error;
}
