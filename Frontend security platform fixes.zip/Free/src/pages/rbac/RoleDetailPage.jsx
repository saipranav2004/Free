import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, UserPlus, FileLock2, Users, ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, Badge, SearchableCombobox } from '../../components/ui/primitives.jsx';
import { RolePicker } from '../../components/common/EntityPickers.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { classNames, extractList } from '../../utils/format.js';

/* ── Data-shape helpers ─────────────────────────────────────────────────────
   The role graph is served by two backend modules that disagree on envelope
   and key names, so every read is normalised here instead of at each call
   site (which is how the detail page ended up showing 0 users / 0 policies
   for roles the list page reported as populated). */

/** Flatten `{ role: {…} }` style envelopes; pass flat payloads through. */
const unwrapEntity = (payload, key) => {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return null;
  const inner = payload[key];
  return inner && typeof inner === 'object' && !Array.isArray(inner)
    ? { ...payload, ...inner }
    : payload;
};

/** First non-empty list among the candidates, tolerating every envelope shape. */
const firstList = (candidates, key) => {
  for (const candidate of candidates) {
    const list = extractList(candidate, key);
    if (list.length) return list;
  }
  return [];
};

/** Prefer a real list length; fall back to whichever count key the API sent. */
const resolveCount = (list, ...fallbacks) =>
  list.length || fallbacks.find((v) => typeof v === 'number') || 0;

/**
 * Premium Enterprise Role Detail Page.
 *
 * Bug fix: The authz role detail endpoint (GET /authz/roles/<id>) only returns
 * counts, not the actual user/policy arrays. The authz role-users and
 * role-policies endpoints lack GET handlers (only POST/DELETE). Instead, we
 * use the identity module's endpoint:
 *   GET /api/v1/identity/accounts/<account_id>/roles/<role_id>
 * which calls RoleService.get_role_with_users() and returns the full
 * user list + policy list in a single response.
 *
 * Features:
 *  - Searchable combobox for assigning users (enterprise pattern)
 *  - Searchable combobox for attaching policies (matching Assign User UX)
 *  - Summary stats row for quick visibility
 *  - Premium card design for assigned users and attached policies
 *  - Proper revoke/detach with correct IDs
 */
export default function RoleDetailPage() {
  const { roleId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  // ── Bug fix: Use identity endpoint which returns role WITH users + policies ──
  // The authz GET /roles/<id> only returns counts (no user/policy arrays).
  // The authz GET /roles/<id>/users has no GET handler (only POST).
  // The identity GET /accounts/<id>/roles/<id> returns everything in one call.
  const { accountId } = useAuth();

  // Bug fix: the page used to read a single identity endpoint and render
  // `data.users` / `data.policies` straight out of it. When that endpoint
  // answers with counts only (or before `accountId` resolves) both cards
  // rendered 0 even though the Roles list showed assignments. The role is now
  // assembled from every source that can answer, newest-wins, so the counts
  // here always agree with the list page:
  //   identity GET /accounts/<acc>/roles/<id>  → role + users[] + policies[]
  //   authz    GET /roles/<id>                 → role + *_count fields
  //   authz    GET /roles/<id>/users           → authoritative assignment list
  //   authz    GET /roles/<id>/policies        → authoritative attachment list
  const role = useResource(async () => {
    const [identityRes, authzRes, usersRes, policiesRes] = await Promise.allSettled([
      accountId ? identityApi.getRole(accountId, roleId) : Promise.resolve(null),
      rbacApi.getRole(roleId),
      rbacApi.listRoleUsers(roleId),
      rbacApi.listRolePolicies(roleId),
    ]);
    const ok = (r) => (r.status === 'fulfilled' ? r.value : null);
    const identityRole = unwrapEntity(ok(identityRes), 'role');
    const authzRole = unwrapEntity(ok(authzRes), 'role');
    if (!identityRole && !authzRole) throw new Error('Role could not be loaded.');

    const base = { ...(authzRole || {}), ...(identityRole || {}) };
    return {
      ...base,
      users: firstList(
        [ok(usersRes), identityRole?.users, base.users, base.assigned_users],
        'users'
      ),
      policies: firstList(
        [ok(policiesRes), identityRole?.policies, base.policies, base.attached_policies],
        'policies'
      ),
    };
  }, [accountId, roleId]);

  // All policies list (for the attach dropdown)
  const policies = useResource(() => pbacApi.listPolicies(), []);

  // Modal states
  const [userOpen, setUserOpen] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [disableOpen, setDisableOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // Form states
  const [userId, setUserId] = useState('');
  const [policyId, setPolicyId] = useState('');
  const [form, setForm] = useState({ description: '', parent_role_id: '' });

  // Destructive actions route through a confirmation, like everywhere else in
  // the console — revoke and detach previously fired on a single click.
  const [userToRevoke, setUserToRevoke] = useState(null);
  const [policyToDetach, setPolicyToDetach] = useState(null);

  /* The searchable pickers below are the shared SearchableCombobox primitive,
     which owns its own search/open/focus state. The page-level dropdown state
     this file used to carry was dead weight (and re-rendered the whole detail
     view on every keystroke), so it is gone. */

  // ── Users data for combobox ──
  const usersResource = useResource(
    () => (userOpen && accountId ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null),
    [userOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];

  // ── Policies data for combobox ──
  // Bug fix: this used to be `Array.isArray(policies.data) ? policies.data : []`,
  // so whenever listPolicies() answered with the `{ policies: [...] }` envelope
  // the picker was empty and no policy could ever be attached.
  const policiesList = extractList(policies.data, 'policies');

  // ── Role data extraction ──
  const data = role.data || {};

  // Bug fix: Extract users and policies from the identity endpoint response.
  // identity.services.RoleService.get_role_with_users() returns:
  //   { ..., users: [...], user_count: N, policies: [...] }
  const users = Array.isArray(data.users) ? data.users : [];
  const attachedPolicies = Array.isArray(data.policies) ? data.policies : [];

  // Counts shown in the summary row — a real list always wins, otherwise fall
  // back to whichever count key the backend provided.
  const userCount = resolveCount(
    users,
    data.assigned_users_count,
    data.user_count,
    data.users_count
  );
  const policyCount = resolveCount(
    attachedPolicies,
    data.attached_policies_count,
    data.policy_count,
    data.policies_count
  );

  // Never offer something that is already attached / assigned.
  const assignableUsers = usersList.filter(
    (u) => !users.some((assigned) => assigned.user_id === u.user_id)
  );
  const attachablePolicies = policiesList.filter(
    (p) => !attachedPolicies.some((attached) => attached.policy_id === p.policy_id)
  );

  const openEdit = () => {
    setForm({ description: data.description || '', parent_role_id: data.parent_role_id || '' });
    setEditOpen(true);
  };

  // Helper to reload every source after a mutation, so the cards, the counts
  // and the pickers all move together.
  const reloadAll = () => {
    role.reload();
    policies.reload();
  };

  const assignUser = async (e) => {
    e.preventDefault();
    if (!userId) { toast.error('Please select a user.'); return; }
    setBusy(true);
    try {
      await rbacApi.assignRoleToUser(roleId, userId);
      toast.success('Role assigned.');
      setUserOpen(false);
      setUserId('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not assign role.');
    } finally {
      setBusy(false);
    }
  };

  // Enterprise: revoke uses role_id + user_id via the RBAC endpoint.
  // The identity endpoint returns users without assignment_id, so we use
  // DELETE /api/v1/authz/roles/<role_id>/users/<user_id> (RoleUserDetailAPI).
  const confirmRevokeUser = async () => {
    const uid = userToRevoke?.user_id;
    if (!uid) { setUserToRevoke(null); return; }
    setBusy(true);
    try {
      await rbacApi.revokeRoleFromUserById(roleId, uid);
      toast.success('Role revoked.');
      setUserToRevoke(null);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not revoke role.');
    } finally {
      setBusy(false);
    }
  };

  const attachPolicy = async (e) => {
    e.preventDefault();
    if (!policyId) { toast.error('Please select a policy.'); return; }
    setBusy(true);
    try {
      await rbacApi.attachPolicyToRole(roleId, policyId);
      toast.success('Policy attached.');
      setPolicyOpen(false);
      setPolicyId('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach policy.');
    } finally {
      setBusy(false);
    }
  };

  // Detach uses role_id + policy_id via the RBAC endpoint.
  // The identity endpoint returns policies without role_policy_id, so we use
  // DELETE /api/v1/authz/roles/<role_id>/policies/<policy_id> (RolePolicyDetailAPI).
  const confirmDetachPolicy = async () => {
    const pid = policyToDetach?.policy_id;
    if (!pid) { setPolicyToDetach(null); return; }
    setBusy(true);
    try {
      await rbacApi.detachPolicyFromRoleById(roleId, pid);
      toast.success('Policy detached.');
      setPolicyToDetach(null);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not detach policy.');
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await rbacApi.updateRole(roleId, form);
      toast.success('Role updated.');
      setEditOpen(false);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not update role.');
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await rbacApi.disableRole(roleId);
      toast.success('Role disabled.');
      navigate('/rbac/roles');
    } catch (err) {
      toast.error(err.userMessage || 'Could not disable role.');
    } finally {
      setBusy(false);
      setDisableOpen(false);
    }
  };

  if (role.loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  if (role.error) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm font-semibold text-ink-900">This role could not be loaded.</p>
        <p className="mt-1 text-xs text-slate-500">{role.error}</p>
        <div className="mt-4 flex justify-center gap-2">
          <Button variant="secondary" onClick={() => navigate('/rbac/roles')}>Back to roles</Button>
          <Button onClick={() => role.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => navigate('/rbac/roles')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Roles
      </button>

      <PageHeader
        title={data.role_name}
        description={data.description}
        icon={<ShieldCheck className="h-5 w-5" />}
        actions={
          <>
            <Button variant="secondary" onClick={openEdit}>Edit</Button>
            <Button variant="danger" onClick={() => setDisableOpen(true)}>
              <Trash2 className="h-4 w-4" /> Disable
            </Button>
          </>
        }
      />

      {/* Enterprise: summary stats row for quick visibility */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-brand-50 p-2 text-brand-600">
            <Users className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Assigned Users</p>
            <p className="text-lg font-semibold text-ink-900">{userCount}</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
            <FileLock2 className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Attached Policies</p>
            <p className="text-lg font-semibold text-ink-900">{policyCount}</p>
          </div>
        </Card>
        {data.parent_role_id && (
          <Card className="flex items-center gap-3 p-4">
            <div className="rounded-lg bg-slate-100 p-2 text-slate-600">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Inherits From</p>
              <p className="text-sm font-medium text-ink-900">Parent role</p>
            </div>
          </Card>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* ── Assigned Users Card ── */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <Users className="h-4 w-4 text-brand-600" /> Assigned users
            </h3>
            <Button size="sm" onClick={() => setUserOpen(true)}>
              <UserPlus className="h-4 w-4" /> Assign
            </Button>
          </div>
          {role.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : users.length ? (
            <ul className="divide-y divide-line-soft">
              {users.map((u) => (
                <li key={u.user_id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-2xs font-semibold text-brand-700">
                      {u.username?.charAt(0)?.toUpperCase() || '?'}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{u.username}</p>
                      <p className="text-xs text-slate-400">{u.email}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    title="Revoke role"
                    onClick={() => setUserToRevoke(u)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <Users className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No users assigned</p>
              <p className="mt-1 text-xs text-slate-500">Assign users to grant this role's permissions.</p>
              <Button size="sm" className="mt-3" onClick={() => setUserOpen(true)}>
                <UserPlus className="h-4 w-4" /> Assign user
              </Button>
            </div>
          )}
        </Card>

        {/* ── Attached Policies Card ── */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <FileLock2 className="h-4 w-4 text-emerald-600" /> Attached policies
            </h3>
            <Button size="sm" onClick={() => setPolicyOpen(true)}>
              <Plus className="h-4 w-4" /> Attach
            </Button>
          </div>
          {role.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : attachedPolicies.length ? (
            <ul className="divide-y divide-line-soft">
              {attachedPolicies.map((p) => (
                <li key={p.policy_id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-2xs font-semibold text-slate-600">
                      <FileLock2 className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{p.policy_name}</p>
                      {p.description && <p className="text-xs text-slate-400">{p.description}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    title="Detach policy"
                    onClick={() => setPolicyToDetach(p)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <FileLock2 className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No policies attached</p>
              <p className="mt-1 text-xs text-slate-500">Attach policies to define what this role can access.</p>
              <Button size="sm" className="mt-3" onClick={() => setPolicyOpen(true)}>
                <Plus className="h-4 w-4" /> Attach policy
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* ── Effective permissions ──────────────────────────────────────────
          What this role actually grants, resolved from every attached policy
          document. Reviewers ask "what can this role do?" — answering it with
          a list of policy names is not an answer. */}
      <EffectivePermissions policies={attachedPolicies} />

      {/* ═══════════════════════════════════════════════════════════════════════
          MODALS
          ═══════════════════════════════════════════════════════════════════════ */}

      {/* ── Assign User Modal ── */}
      <Modal
        open={userOpen}
        onClose={() => { setUserOpen(false); setUserId(''); }}
        title="Assign user"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setUserOpen(false); setUserId(''); }}>Cancel</Button>
            <Button onClick={assignUser} loading={busy} disabled={!userId}>Assign</Button>
          </>
        }
      >
        <form onSubmit={assignUser} className="space-y-4">
          <SearchableCombobox
            label="User"
            required
            options={assignableUsers.map((u) => ({
              id: u.user_id,
              label: u.username || u.email || u.user_id,
              description: u.email,
              badge: u.status && u.status !== 'ACTIVE' ? u.status : undefined,
            }))}
            value={userId}
            onChange={(id) => setUserId(id || '')}
            loading={usersResource.loading}
            error={usersResource.error ? 'Failed to load the user directory.' : undefined}
            placeholder="Search users by name or email…"
            hint="Type to filter the tenant directory — the list narrows as you type."
            emptyMessage={usersList.length ? 'Every matching user already holds this role.' : 'No users match that name or email.'}
          />
        </form>
      </Modal>

      {/* ── Attach Policy Modal ── */}
      <Modal
        open={policyOpen}
        onClose={() => { setPolicyOpen(false); setPolicyId(''); }}
        title="Attach policy"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setPolicyOpen(false); setPolicyId(''); }}>Cancel</Button>
            <Button onClick={attachPolicy} loading={busy} disabled={!policyId}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attachPolicy} className="space-y-4">
          <SearchableCombobox
            label="Policy"
            required
            options={attachablePolicies.map((pol) => ({
              id: pol.policy_id,
              label: pol.policy_name,
              description: pol.description,
              badge: pol.is_system_policy ? 'SYSTEM' : undefined,
            }))}
            value={policyId}
            onChange={(id) => setPolicyId(id || '')}
            loading={policies.loading}
            placeholder="Search policies by name or description…"
            hint="Attaching a policy grants its permissions to every principal holding this role."
            emptyMessage={policiesList.length ? 'Every matching policy is already attached.' : 'No policies match that search.'}
          />
        </form>
      </Modal>

      {/* ── Edit Role Modal ── */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit role"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={saveEdit} loading={busy}>Save</Button>
          </>
        }
      >
        <form onSubmit={saveEdit} className="space-y-4">
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          <RolePicker
            label="Parent role"
            value={form.parent_role_id}
            onChange={(id) => setForm((f) => ({ ...f, parent_role_id: id || '' }))}
            excludeId={roleId}
            placeholder="Search roles to inherit from…"
            hint="Optional. Inherits every policy attached to the parent role."
          />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!userToRevoke}
        onClose={() => setUserToRevoke(null)}
        onConfirm={confirmRevokeUser}
        danger
        loading={busy}
        title="Revoke role"
        confirmLabel="Revoke role"
        message={`Remove this role from ${userToRevoke?.username || userToRevoke?.email || 'this user'}?`}
        detail="The user keeps access granted by other roles, groups or direct policy attachments."
      />

      <ConfirmDialog
        open={!!policyToDetach}
        onClose={() => setPolicyToDetach(null)}
        onConfirm={confirmDetachPolicy}
        danger
        loading={busy}
        title="Detach policy"
        confirmLabel="Detach policy"
        message={`Detach “${policyToDetach?.policy_name || 'this policy'}” from this role?`}
        detail="Every user holding this role loses the permissions the policy granted."
      />

      <ConfirmDialog
        open={disableOpen}
        onClose={() => setDisableOpen(false)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Disable role"
        message="Users assigned this role will lose its permissions."
      />
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   EffectivePermissions — resolves attached policy documents into the concrete
   action/resource pairs the role grants.

   Read-only: it calls the existing pbacApi.getPolicy detail endpoint once per
   attached policy and flattens the statements client-side. Deny statements are
   listed first because in a deny-overrides evaluator they are what actually
   decides an outcome.
   ═══════════════════════════════════════════════════════════════════════════ */
function parseStatements(policy) {
  const raw =
    policy?.policy_document ?? policy?.document ?? policy?.statements ?? policy?.policy ?? null;
  let parsed = raw;
  if (typeof raw === 'string') {
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = null;
    }
  }
  const list = parsed?.statements || parsed?.Statement || parsed?.statement || parsed;
  if (!list) return [];
  return Array.isArray(list) ? list : [list];
}

function normaliseStatement(stmt, policy) {
  const asArray = (v) => (v == null ? [] : Array.isArray(v) ? v : [v]);
  return {
    effect: String(stmt?.effect || stmt?.Effect || 'allow').toUpperCase(),
    actions: asArray(stmt?.actions ?? stmt?.action ?? stmt?.Action),
    resources: asArray(stmt?.resources ?? stmt?.resource ?? stmt?.Resource),
    hasCondition: !!(stmt?.condition || stmt?.Condition || stmt?.conditions),
    policyName: policy?.policy_name || policy?.name || 'Policy',
    policyId: policy?.policy_id,
  };
}

function EffectivePermissions({ policies = [] }) {
  const [state, setState] = useState({ loading: false, rows: [], failed: 0, ready: false });
  const key = policies.map((p) => p.policy_id).sort().join(',');

  useEffect(() => {
    let cancelled = false;
    if (!policies.length) {
      setState({ loading: false, rows: [], failed: 0, ready: true });
      return () => {};
    }
    setState((s) => ({ ...s, loading: true }));
    Promise.allSettled(policies.slice(0, 25).map((p) => pbacApi.getPolicy(p.policy_id)))
      .then((results) => {
        if (cancelled) return;
        const rows = [];
        let failed = 0;
        results.forEach((res, i) => {
          if (res.status !== 'fulfilled') {
            failed += 1;
            return;
          }
          const detail = res.value?.policy || res.value || {};
          const source = { ...policies[i], ...detail };
          parseStatements(detail).forEach((stmt) => rows.push(normaliseStatement(stmt, source)));
        });
        rows.sort((a, b) => (a.effect === b.effect ? 0 : a.effect === 'DENY' ? -1 : 1));
        setState({ loading: false, rows, failed, ready: true });
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const actionCount = state.rows.reduce((n, r) => n + Math.max(r.actions.length, 1), 0);

  return (
    <Card className="p-5">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
            <ShieldCheck className="h-4 w-4 text-slate-400" /> Effective permissions
          </h3>
          <p className="mt-0.5 text-xs text-slate-500">
            Resolved from {policies.length} attached polic{policies.length === 1 ? 'y' : 'ies'} — what a
            principal holding this role can actually do.
          </p>
        </div>
        {state.ready && state.rows.length > 0 && (
          <Badge tone="slate">{actionCount} action{actionCount === 1 ? '' : 's'}</Badge>
        )}
      </div>

      {state.loading ? (
        <div className="flex justify-center py-8">
          <Spinner className="h-5 w-5" />
        </div>
      ) : policies.length === 0 ? (
        <p className="py-6 text-center text-[13px] text-slate-500">
          No policies attached — this role grants nothing on its own.
        </p>
      ) : state.rows.length === 0 ? (
        <p className="py-6 text-center text-[13px] text-slate-500">
          The attached policies did not return readable statement documents.
        </p>
      ) : (
        <div className="overflow-hidden rounded-lg border border-line">
          <table className="min-w-full border-separate border-spacing-0 text-[13px]">
            <thead>
              <tr>
                {['Effect', 'Action', 'Resource', 'From policy'].map((h) => (
                  <th
                    key={h}
                    className="border-b border-line bg-slate-50/95 px-3 py-2 text-left text-2xs font-semibold uppercase tracking-[0.07em] text-slate-500"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {state.rows.map((row, i) =>
                (row.actions.length ? row.actions : ['*']).map((action, j) => (
                  <tr key={`${i}-${j}`} className="hover:bg-slate-50/70">
                    <td className="border-b border-line-soft px-3 py-1.5">
                      <Badge tone={row.effect === 'DENY' ? 'red' : 'green'}>{row.effect}</Badge>
                    </td>
                    <td className="border-b border-line-soft px-3 py-1.5 font-mono text-xs text-ink-900">
                      {action}
                      {row.hasCondition && (
                        <span className="ml-2 rounded bg-slate-100 px-1 py-0.5 text-3xs font-medium text-slate-500">
                          conditional
                        </span>
                      )}
                    </td>
                    <td className="border-b border-line-soft px-3 py-1.5 font-mono text-xs text-slate-600">
                      {row.resources.join(', ') || '*'}
                    </td>
                    <td className="border-b border-line-soft px-3 py-1.5 text-xs text-slate-500">
                      {row.policyName}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {state.failed > 0 && (
        <p className="mt-2 text-2xs text-amber-700">
          {state.failed} polic{state.failed === 1 ? 'y' : 'ies'} could not be read; the list above may be
          incomplete.
        </p>
      )}
    </Card>
  );
}
