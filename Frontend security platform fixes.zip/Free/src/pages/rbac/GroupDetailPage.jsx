import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, UserPlus, FileLock2, Users, ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import { Card, Button, Input, Spinner, SearchableCombobox } from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { extractList } from '../../utils/format.js';

/** First non-empty list among the candidates, tolerating every envelope shape. */
const firstList = (candidates, key) => {
  for (const candidate of candidates) {
    const list = extractList(candidate, key);
    if (list.length) return list;
  }
  return [];
};

/** Prefer a real list length; fall back to whichever count key the API sent. */
const resolveCount = (list, ...fallbacks) =>
  list.length || fallbacks.find((v) => typeof v === 'number') || 0;

/* Membership rows arrive either flat ({ user_id, username }) or wrapped
   ({ user: { … } }) depending on which route answered, so read both. */
const memberId = (m) => m?.user_id ?? m?.user?.user_id ?? m?.id;
const memberLabel = (m) => {
  if (!m) return '';
  const full = [m.first_name ?? m.user?.first_name, m.last_name ?? m.user?.last_name]
    .filter(Boolean)
    .join(' ')
    .trim();
  return (
    m.username || m.user?.username || full || m.email || m.user?.email || memberId(m) || 'Member'
  );
};
const memberEmail = (m) => m?.email ?? m?.user?.email ?? '';

/**
 * GroupDetailPage — View and manage a single group.
 *
 * Shows members and attached policies with full CRUD capabilities.
 * The attach/detach policy functionality matches RoleDetailPage exactly:
 *   - SearchableCombobox for selecting policies
 *   - Attach via rbacApi.attachPolicyToRole (backend group-policy association)
 *   - Detach via rbacApi.detachPolicyFromRoleById
 *   - List refreshes after every action
 */
export default function GroupDetailPage() {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { accountId } = useAuth();

  const group = useResource(
    () => accountId ? identityApi.getGroup(accountId, groupId) : Promise.resolve(null),
    [groupId, accountId]
  );

  // All policies list (for the attach dropdown)
  const policies = useResource(() => pbacApi.listPolicies(), []);

  // Bug fix: the attached-policy list was read from `group.data.policies`,
  // which the identity group endpoint does not return — so an attach never
  // showed up and the card stayed empty. Read the association from its own
  // endpoint, and fall back to whatever the group payload carries when a
  // deployment has not registered that route.
  const groupPolicies = useResource(
    () => rbacApi.listGroupPolicies(groupId).catch(() => null),
    [groupId]
  );

  // Bug fix: members were read only from the group payload, which does not
  // always include them — so the Members card and its count stayed empty even
  // right after a successful "Add member". The identity module exposes the
  // membership list on its own route; use it, and keep the group payload as a
  // fallback for deployments that inline members.
  const groupMembers = useResource(
    () =>
      accountId
        ? identityApi.listGroupMembers(accountId, groupId).catch(() => null)
        : Promise.resolve(null),
    [accountId, groupId]
  );

  // Modal states
  const [memberOpen, setMemberOpen] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [disableOpen, setDisableOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  // Destructive actions route through a confirmation, like everywhere else in
  // the console — previously remove-member and detach-policy fired instantly.
  const [memberToRemove, setMemberToRemove] = useState(null);
  const [policyToDetach, setPolicyToDetach] = useState(null);
  const [formErrors, setFormErrors] = useState({});

  // Form states
  const [userId, setUserId] = useState('');
  const [policyId, setPolicyId] = useState('');
  const [form, setForm] = useState({ group_name: '', description: '' });

  // Fetch users for the Add Member combobox
  const usersResource = useResource(
    () => memberOpen ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null,
    [memberOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];

  // Policies data for combobox.
  // Bug fix: this used to be `Array.isArray(policies.data) ? … : []`, so the
  // `{ policies: [...] }` envelope produced an empty picker and nothing could
  // be attached.
  const policiesList = extractList(policies.data, 'policies');

  // Group data extraction
  const data = group.data || {};

  // Members: dedicated endpoint first, then whatever the group payload carries.
  const members = firstList(
    [groupMembers.data, data.members, data.users, data.memberships],
    'members'
  );

  // Attached policies: dedicated endpoint first, then the group payload.
  const attachedPolicies = firstList(
    [groupPolicies.data, data.policies, data.attached_policies],
    'policies'
  );

  // Never offer a user who is already a member (the picker used to list them,
  // and adding one again failed with a duplicate error).
  const userOptions = usersList
    .filter((u) => !members.some((m) => memberId(m) === u.user_id))
    .map((u) => ({
      id: u.user_id,
      label: u.username || u.email || u.user_id,
      description: u.email,
      badge: u.status,
    }));

  const memberCount = resolveCount(members, data.member_count, data.members_count);
  const policyCount = resolveCount(
    attachedPolicies,
    data.attached_policies_count,
    data.policy_count
  );

  // Never offer a policy that is already attached, or a user already a member.
  const policyOptions = policiesList
    .filter((p) => !attachedPolicies.some((a) => (a.policy_id ?? a.id) === p.policy_id))
    .map((p) => ({
      id: p.policy_id,
      label: p.policy_name,
      description: p.description,
      badge: p.is_system_policy ? 'SYSTEM' : undefined,
    }));

  // Reload every source a mutation can touch, so the cards, the counts and the
  // pickers all move together.
  const reloadAll = () => {
    group.reload();
    groupPolicies.reload();
    groupMembers.reload();
  };

  const openEdit = () => {
    setForm({ group_name: data.group_name || '', description: data.description || '' });
    setFormErrors({});
    setEditOpen(true);
  };

  const addMember = async (e) => {
    e.preventDefault();
    if (!userId) { toast.error('Please select a user.'); return; }
    setBusy(true);
    try {
      await identityApi.addGroupMember(accountId, groupId, userId);
      toast.success('Member added.');
      setMemberOpen(false);
      setUserId('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not add member.');
    } finally {
      setBusy(false);
    }
  };

  const confirmRemoveMember = async () => {
    const uid = memberId(memberToRemove);
    if (!uid) { setMemberToRemove(null); return; }
    setBusy(true);
    try {
      await identityApi.removeGroupMember(accountId, groupId, uid);
      toast.success('Member removed.');
      setMemberToRemove(null);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not remove member.');
    } finally {
      setBusy(false);
    }
  };

  // ── Attach Policy ──
  // Bug fix: this used to POST the *group* id as `role_id` to the role-policy
  // attach route — a different object graph, so the association silently went
  // to the wrong place (or 4xx'd) and the card never updated. Use the group
  // route, and only fall back to the legacy call when the group route is not
  // registered, so nothing that worked before stops working.
  const attachPolicy = async (e) => {
    e.preventDefault();
    if (!policyId) { toast.error('Please select a policy.'); return; }
    setBusy(true);
    try {
      try {
        await rbacApi.attachPolicyToGroup(groupId, policyId);
      } catch (err) {
        const status = err?.response?.status;
        if (status === 404 || status === 405) await rbacApi.attachPolicyToRole(groupId, policyId);
        else throw err;
      }
      toast.success('Policy attached.');
      setPolicyOpen(false);
      setPolicyId('');
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach policy.');
    } finally {
      setBusy(false);
    }
  };

  // ── Detach Policy — mirrors attach, including the legacy fallback ──
  const confirmDetachPolicy = async () => {
    const pid = policyToDetach?.policy_id ?? policyToDetach?.id;
    if (!pid) { setPolicyToDetach(null); return; }
    setBusy(true);
    try {
      try {
        await rbacApi.detachPolicyFromGroup(groupId, pid);
      } catch (err) {
        const status = err?.response?.status;
        if (status === 404 || status === 405) await rbacApi.detachPolicyFromRoleById(groupId, pid);
        else throw err;
      }
      toast.success('Policy detached.');
      setPolicyToDetach(null);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not detach policy.');
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async (e) => {
    e.preventDefault();
    if (!form.group_name.trim()) {
      setFormErrors({ group_name: 'Group name is required.' });
      return;
    }
    setBusy(true);
    try {
      await identityApi.updateGroup(accountId, groupId, form);
      toast.success('Group updated.');
      setEditOpen(false);
      reloadAll();
    } catch (err) {
      toast.error(err.userMessage || 'Could not update group.');
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    try {
      await identityApi.deleteGroup(accountId, groupId);
      toast.success('Group deleted.');
      navigate('/rbac/groups');
    } catch (err) {
      toast.error(err.userMessage || 'Could not delete group.');
    } finally {
      setBusy(false);
      setDisableOpen(false);
    }
  };

  if (group.loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  if (group.error) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm font-semibold text-ink-900">This group could not be loaded.</p>
        <p className="mt-1 text-xs text-slate-500">{group.error}</p>
        <div className="mt-4 flex justify-center gap-2">
          <Button variant="secondary" onClick={() => navigate('/rbac/groups')}>Back to groups</Button>
          <Button onClick={() => group.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => navigate('/rbac/groups')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Groups
      </button>

      <PageHeader
        title={data.group_name}
        description={data.description}
        icon={<Users className="h-5 w-5" />}
        actions={
          <>
            <Button variant="secondary" onClick={openEdit}>Edit</Button>
            <Button variant="danger" onClick={() => setDisableOpen(true)}>
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
          </>
        }
      />

      {/* Enterprise: summary stats row */}
      <div className="mb-6 grid grid-cols-2 gap-4">
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-brand-50 p-2 text-brand-600">
            <Users className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Members</p>
            <p className="text-lg font-semibold text-ink-900">{memberCount}</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
            <FileLock2 className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Attached Policies</p>
            <p className="text-lg font-semibold text-ink-900">{policyCount}</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Members Card */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <Users className="h-4 w-4 text-brand-600" /> Members
            </h3>
            <Button size="sm" onClick={() => setMemberOpen(true)}>
              <UserPlus className="h-4 w-4" /> Add
            </Button>
          </div>
          {group.loading || groupMembers.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : members.length ? (
            <ul className="divide-y divide-line-soft">
              {members.map((m) => (
                <li key={memberId(m)} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-2xs font-semibold text-brand-700">
                      {memberLabel(m).charAt(0).toUpperCase()}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{memberLabel(m)}</p>
                      {memberEmail(m) && <p className="text-xs text-slate-400">{memberEmail(m)}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    title="Remove member"
                    onClick={() => setMemberToRemove(m)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <Users className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No members</p>
              <p className="mt-1 text-xs text-slate-500">Add users to this group.</p>
              <Button size="sm" className="mt-3" onClick={() => setMemberOpen(true)}>
                <UserPlus className="h-4 w-4" /> Add member
              </Button>
            </div>
          )}
        </Card>

        {/* Attached Policies Card (matches RoleDetailPage pattern exactly) */}
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold text-ink-900">
              <FileLock2 className="h-4 w-4 text-emerald-600" /> Attached policies
            </h3>
            <Button size="sm" onClick={() => setPolicyOpen(true)}>
              <Plus className="h-4 w-4" /> Attach
            </Button>
          </div>
          {group.loading || groupPolicies.loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
          ) : attachedPolicies.length ? (
            <ul className="divide-y divide-line-soft">
              {attachedPolicies.map((p) => (
                <li key={p.policy_id ?? p.id} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-2xs font-semibold text-slate-600">
                      <FileLock2 className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium text-ink-800">{p.policy_name || p.name || 'Policy'}</p>
                      {p.description && <p className="text-xs text-slate-400">{p.description}</p>}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    title="Detach policy"
                    onClick={() => setPolicyToDetach(p)}
                    className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100">
                <FileLock2 className="h-6 w-6 text-slate-400" />
              </div>
              <p className="text-sm font-medium text-ink-900">No policies attached</p>
              <p className="mt-1 text-xs text-slate-500">Attach policies to define what this group can access.</p>
              <Button size="sm" className="mt-3" onClick={() => setPolicyOpen(true)}>
                <Plus className="h-4 w-4" /> Attach policy
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          MODALS (matching RoleDetailPage pattern exactly)
          ═══════════════════════════════════════════════════════════════════════ */}

      {/* ── Add Member Modal ── */}
      <Modal
        open={memberOpen}
        onClose={() => { setMemberOpen(false); setUserId(''); }}
        title="Add member"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setMemberOpen(false); setUserId(''); }}>Cancel</Button>
            <Button onClick={addMember} loading={busy} disabled={!userId}>Add</Button>
          </>
        }
      >
        <form onSubmit={addMember} className="space-y-4">
          <SearchableCombobox
            label="User"
            required
            options={userOptions}
            value={userId}
            onChange={setUserId}
            loading={usersResource.loading}
            placeholder="Search users by name or email…"
            hint="Type to filter the tenant directory — the list narrows as you type."
            emptyMessage="No users match that name or email."
          />
        </form>
      </Modal>

      {/* ── Attach Policy Modal (matches RoleDetailPage exactly) ── */}
      <Modal
        open={policyOpen}
        onClose={() => { setPolicyOpen(false); setPolicyId(''); }}
        title="Attach policy"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setPolicyOpen(false); setPolicyId(''); }}>Cancel</Button>
            <Button onClick={attachPolicy} loading={busy} disabled={!policyId}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attachPolicy} className="space-y-4">
          <SearchableCombobox
            label="Policy"
            required
            options={policyOptions}
            value={policyId}
            onChange={setPolicyId}
            loading={policies.loading}
            placeholder="Search policies by name or description…"
            hint="Attaching a policy grants its permissions to every member of this group."
            emptyMessage={policiesList.length ? 'Every matching policy is already attached.' : 'No policies match that search.'}
          />
        </form>
      </Modal>

      {/* ── Edit Group Modal ── */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit group"
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={saveEdit} loading={busy}>Save</Button>
          </>
        }
      >
        <form onSubmit={saveEdit} className="space-y-4">
          <Input
            label="Group name"
            value={form.group_name}
            error={formErrors.group_name}
            onChange={(e) => {
              setForm((f) => ({ ...f, group_name: e.target.value }));
              setFormErrors({});
            }}
            required
          />
          <Input label="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
        </form>
      </Modal>

      <ConfirmDialog
        open={!!memberToRemove}
        onClose={() => setMemberToRemove(null)}
        onConfirm={confirmRemoveMember}
        danger
        loading={busy}
        title="Remove member"
        confirmLabel="Remove member"
        message={`Remove ${memberLabel(memberToRemove) || 'this user'} from this group?`}
        detail="The user keeps any access granted directly or through other groups."
      />

      <ConfirmDialog
        open={!!policyToDetach}
        onClose={() => setPolicyToDetach(null)}
        onConfirm={confirmDetachPolicy}
        danger
        loading={busy}
        title="Detach policy"
        confirmLabel="Detach policy"
        message={`Detach “${policyToDetach?.policy_name || policyToDetach?.name || 'this policy'}” from this group?`}
        detail="Every member loses the permissions this policy granted through the group."
      />

      <ConfirmDialog
        open={disableOpen}
        onClose={() => setDisableOpen(false)}
        onConfirm={disable}
        danger
        loading={busy}
        title="Delete group"
        message="This will permanently delete the group and remove all member and policy associations."
      />
    </div>
  );
}
