import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { authApi } from '../../lib/api/auth.js';
import { Button, Input, Card } from '../../components/ui/primitives.jsx';

export default function RegisterPage() {
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    confirm_password: '',
  });
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm_password) {
      toast.error('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      await authApi.register(form);
      toast.success('Account created. You can now sign in.');
      navigate('/login');
    } catch (err) {
      toast.error(err.userMessage || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-ink-900 to-ink-700 p-4">
      <Card className="w-full max-w-md p-6">
        <div className="mb-4 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500 text-white">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-semibold text-ink-900">Create your account</h1>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <Input label="Username" name="username" value={form.username} onChange={set('username')} required />
          <Input label="Email" type="email" name="email" value={form.email} onChange={set('email')} required />
          <Input label="Password" type="password" name="password" value={form.password} onChange={set('password')} required
            hint="Min 10 chars; upper, lower, digit & special." />
          <Input label="Confirm password" type="password" name="confirm_password" value={form.confirm_password} onChange={set('confirm_password')} required />
          <Button type="submit" className="w-full" loading={loading}>
            Register
          </Button>
        </form>
        <p className="mt-4 text-center text-sm text-slate-500">
          Already have an account?{' '}
          <Link to="/login" className="text-brand-600 hover:underline">
            Sign in
          </Link>
        </p>
      </Card>
    </div>
  );
}
