/**
 * RegisterTenantPage — public company (tenant) registration.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * LAYOUT — deliberately identical in density to LoginPage
 * ═══════════════════════════════════════════════════════════════════════════
 * This is the only screen a prospect sees before they have an account, so it
 * mirrors LoginPage exactly: `h-screen overflow-hidden`, navy #0f172a panel
 * with the grid overlay on the left, white panel with a `max-w-[320px]` card
 * on the right, same #0ea5e9 accent, same field and button classes. No new
 * colours, no new tokens, no new components — only the copy and the fields
 * differ. The whole page fits one viewport; nothing scrolls.
 *
 * CONTRACT
 *   POST /api/v1/identity/register   (identityApi.registerTenant)
 *   body: { company_name, domain, email, first_name, last_name }
 *
 *   → { admin:  { account_id, email, password, … },
 *       tenant: { account_id, company_name, domain, tenant_id, status },
 *       message: "…the password will NOT be shown again." }
 *
 * ONE-TIME CREDENTIALS
 * The root admin password is returned exactly once, so on success the six
 * required columns are written to a spreadsheet and downloaded automatically
 * (same XLSX pattern as the console's other credential exports). A manual
 * re-download stays available while the result is on screen.
 */
import { useState, useCallback } from 'react';
import {
  Building2, Globe, Mail, User, Lock, ShieldCheck, Download, CheckCircle2,
  AlertTriangle, ArrowLeft,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Logo } from '../../components/common/Logo.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { identityApi } from '../../lib/api/identity.js';
import { classNames } from '../../utils/format.js';

/** The six columns the credential workbook must contain, in this order. */
const CREDENTIAL_COLUMNS = ['account_id', 'email', 'password', 'company_name', 'domain', 'tenant_id'];

/**
 * Map a successful registration response onto the credential row. `admin`
 * carries the account + login identity, `tenant` the company record; each
 * value falls back to the sibling object so a flatter response still yields a
 * complete row.
 */
function toCredentialRow(res) {
  const body = res?.data && (res.data.admin || res.data.tenant) ? res.data : res;
  const admin = body?.admin || {};
  const tenant = body?.tenant || {};
  return {
    account_id: admin.account_id || tenant.account_id || '',
    email: admin.email || '',
    password: admin.password || '',
    company_name: tenant.company_name || '',
    domain: tenant.domain || '',
    tenant_id: tenant.tenant_id || '',
  };
}

/** Write the credential row to an .xlsx and trigger the browser download. */
function downloadCredentialsWorkbook(row) {
  const sheet = XLSX.utils.json_to_sheet([row], { header: CREDENTIAL_COLUMNS });
  sheet['!cols'] = CREDENTIAL_COLUMNS.map(() => ({ wch: 28 }));
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, 'Credentials');
  const safe = String(row.company_name || 'tenant').replace(/[^a-z0-9._-]+/gi, '_');
  XLSX.writeFile(book, `${safe}_root_admin_credentials.xlsx`);
}

/** Field definitions — `half` fields pair up on one row to keep the card short. */
const FIELDS = [
  { key: 'company_name', label: 'Company name', icon: Building2, placeholder: 'Acme Corporation', autoComplete: 'organization' },
  { key: 'domain', label: 'Domain', icon: Globe, placeholder: 'acme.com', autoComplete: 'url' },
  { key: 'email', label: 'Admin email', icon: Mail, placeholder: 'admin@acme.com', type: 'email', autoComplete: 'email' },
  { key: 'first_name', label: 'First name', icon: User, placeholder: 'Ada', autoComplete: 'given-name', half: true },
  { key: 'last_name', label: 'Last name', icon: User, placeholder: 'Lovelace', autoComplete: 'family-name', half: true },
];

// Shared input classes — copied verbatim from LoginPage so both screens are
// pixel-identical, with room on the left for the field icon.
const INPUT_BASE =
  'block w-full rounded-lg border bg-white py-2 pl-8 pr-3 text-[13px] text-[#0f172a] placeholder-slate-400 transition-all duration-150 focus:outline-none focus:ring-2';

export default function RegisterTenantPage() {
  const toast = useToast();

  const [form, setForm] = useState({
    company_name: '', domain: '', email: '', first_name: '', last_name: '',
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [submitError, setSubmitError] = useState(null);

  const set = (key) => (e) => {
    const { value } = e.target;
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((x) => ({ ...x, [key]: undefined }));
  };

  const validate = () => {
    const next = {};
    if (!form.company_name.trim()) next.company_name = 'Required';
    if (!form.domain.trim()) next.domain = 'Required';
    else if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(form.domain.trim())) next.domain = 'e.g. acme.com';
    if (!form.email.trim()) next.email = 'Required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) next.email = 'Enter a valid email';
    if (!form.first_name.trim()) next.first_name = 'Required';
    if (!form.last_name.trim()) next.last_name = 'Required';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (loading) return;
    setSubmitError(null);
    if (!validate()) return;

    setLoading(true);
    try {
      // Exact payload contract — five keys, trimmed, nothing else.
      const res = await identityApi.registerTenant({
        company_name: form.company_name.trim(),
        domain: form.domain.trim(),
        email: form.email.trim(),
        first_name: form.first_name.trim(),
        last_name: form.last_name.trim(),
      });

      const row = toCredentialRow(res);
      setCredentials(row);
      setSuccessMessage(
        res?.message ||
          res?.data?.message ||
          'Registration successful. Save these credentials securely — the password will NOT be shown again.'
      );

      // Automatic download: the password is issued exactly once.
      try {
        downloadCredentialsWorkbook(row);
        toast.success('Registered. Credentials spreadsheet downloaded.');
      } catch {
        toast.error('Registered, but the file could not download. Use “Download again”.');
      }
    } catch (err) {
      const message = err.userMessage || 'Registration failed. Please try again.';
      setSubmitError(message);
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  const redownload = useCallback(() => {
    if (!credentials) return;
    downloadCredentialsWorkbook(credentials);
    toast.success('Credentials downloaded again.');
  }, [credentials, toast]);

  return (
    <div className="h-screen overflow-hidden">
      <div className="flex h-screen w-screen flex-col md:flex-row">
        {/* ── Left marketing panel — same construction as LoginPage ── */}
        <div className="relative flex-1 bg-[#0f172a] p-6 text-white md:min-h-screen">
          <div
            className="absolute inset-0 opacity-[0.03]"
            aria-hidden="true"
            style={{
              backgroundImage: `
                linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px',
            }}
          />
          <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
            <div className="absolute -left-20 -top-20 h-96 w-96 rounded-full bg-[#0ea5e9]/10 blur-3xl" />
            <div className="absolute -bottom-32 -right-32 h-[500px] w-[500px] rounded-full bg-[#0ea5e9]/5 blur-3xl" />
          </div>

          <div className="relative z-10 flex h-full flex-col">
            <div className="mt-3">
              <div className="inline-flex items-center rounded-full bg-white/10 px-4 py-2 backdrop-blur-sm">
                <Logo size="lg" variant="clean" className="!h-18 !w-auto brightness-0 invert" />
              </div>
            </div>

            <h1 className="mt-4 text-4xl font-bold leading-tight md:text-5xl lg:text-[52px]">
              <span className="text-white">Register your</span>
              <br />
              <span className="text-[#0ea5e9]">company tenant</span>
            </h1>

            <p className="mt-2 max-w-md text-base leading-relaxed text-slate-300">
              One step provisions an isolated tenant and its root administrator. Users, roles
              and policies are created from inside the console.
            </p>

            <div className="mt-5 space-y-3">
              {[
                { icon: Building2, title: 'Isolated tenant boundary', sub: 'Your directory, policies and audit trail' },
                { icon: ShieldCheck, title: 'Root administrator provisioned', sub: 'Generated username and one-time password' },
                { icon: Lock, title: 'Credentials issued once', sub: 'Delivered as a spreadsheet, never shown again' },
              ].map((item) => (
                <div key={item.title} className="flex items-center gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0ea5e9]/20 backdrop-blur-sm">
                    <item.icon className="h-5 w-5 text-[#0ea5e9]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{item.title}</p>
                    <p className="text-xs text-slate-400">{item.sub}</p>
                  </div>
                </div>
              ))}
            </div>

            <p className="mt-auto pt-6 text-xs text-slate-500">
              © 2026 Deep Algorithms Solutions • IAM Control Center
            </p>
          </div>
        </div>

        {/* ── Right panel — compact card, exactly LoginPage's metrics ── */}
        <div className="flex flex-1 items-center justify-center bg-gradient-to-br from-slate-50 to-white p-3 md:p-5">
          <div className="w-full max-w-[320px]">
            <div className="mb-3 flex flex-col items-center text-center">
              <Logo size="xl" variant="topbar" className="!h-16 !w-auto" />
              <h2 className="mt-2.5 text-xl font-bold tracking-tight text-[#0f172a]">
                {credentials ? 'Tenant registered' : 'Create your tenant'}
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                {credentials
                  ? 'Save the credentials before you leave'
                  : 'Register a company and its root administrator'}
              </p>
            </div>

            {!credentials ? (
              <div className="rounded-xl border border-slate-200/70 bg-white p-4 shadow-[0_4px_20px_rgb(0,0,0,0.03)]">
                {submitError && (
                  <div className="mb-2.5 flex items-start gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-2.5 py-2 text-[11px] leading-snug text-rose-700">
                    <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0" />
                    <span>{submitError}</span>
                  </div>
                )}

                <form onSubmit={onSubmit} className="space-y-2.5" noValidate>
                  <div className="grid grid-cols-2 gap-2.5">
                    {FIELDS.map((field) => (
                      <div key={field.key} className={field.half ? 'col-span-1' : 'col-span-2'}>
                        <label
                          htmlFor={field.key}
                          className="mb-1 flex items-baseline justify-between text-[11px] font-semibold uppercase tracking-wide text-slate-500"
                        >
                          <span>{field.label}</span>
                          {errors[field.key] && (
                            <span className="text-[9.5px] font-medium normal-case tracking-normal text-rose-600">
                              {errors[field.key]}
                            </span>
                          )}
                        </label>
                        <div className="relative">
                          <field.icon className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                          <input
                            id={field.key}
                            name={field.key}
                            type={field.type || 'text'}
                            autoComplete={field.autoComplete}
                            value={form[field.key]}
                            onChange={set(field.key)}
                            placeholder={field.placeholder}
                            aria-invalid={errors[field.key] ? true : undefined}
                            className={classNames(
                              INPUT_BASE,
                              errors[field.key]
                                ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/15'
                                : 'border-slate-200 focus:border-[#0ea5e9] focus:ring-[#0ea5e9]/20'
                            )}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <p className="text-[10px] leading-snug text-slate-400">
                    A root administrator is created with a one-time password, downloaded as a
                    spreadsheet on success.
                  </p>

                  <button
                    type="submit"
                    disabled={loading}
                    className={classNames(
                      'flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2 text-[13px] font-semibold text-white transition-all duration-150',
                      loading
                        ? 'cursor-not-allowed bg-[#0ea5e9]/70'
                        : 'bg-gradient-to-r from-[#0ea5e9] to-[#0284c7] hover:from-[#0284c7] hover:to-[#0369a1] hover:shadow-md hover:shadow-[#0ea5e9]/25 active:scale-[0.98]'
                    )}
                  >
                    {loading ? (
                      <svg className="h-3.5 w-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <Building2 className="h-3.5 w-3.5" />
                    )}
                    {loading ? 'Registering…' : 'Register company'}
                  </button>
                </form>
              </div>
            ) : (
              /* ── Success: one-time credentials, height-capped so the page
                     still fits a single viewport ── */
              <div className="rounded-xl border border-slate-200/70 bg-white p-4 shadow-[0_4px_20px_rgb(0,0,0,0.03)]">
                <div className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-2">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                  <div>
                    <p className="text-[12px] font-semibold text-emerald-800">
                      Credentials downloaded — save them securely
                    </p>
                    <p className="mt-0.5 text-[10.5px] leading-snug text-emerald-700">{successMessage}</p>
                  </div>
                </div>

                <dl className="mt-2.5 max-h-[210px] divide-y divide-slate-100 overflow-y-auto rounded-lg border border-slate-200">
                  {CREDENTIAL_COLUMNS.map((key) => (
                    <div key={key} className="flex items-start justify-between gap-2 px-2.5 py-1.5">
                      <dt className="shrink-0 text-[9.5px] font-semibold uppercase tracking-wide text-slate-400">
                        {key.replace(/_/g, ' ')}
                      </dt>
                      <dd
                        className={classNames(
                          'min-w-0 break-all text-right text-[11px] font-medium text-[#0f172a]',
                          (key === 'password' || key.endsWith('_id')) && 'font-mono'
                        )}
                      >
                        {credentials[key] || '—'}
                      </dd>
                    </div>
                  ))}
                </dl>

                <div className="mt-2.5 space-y-1.5">
                  <button
                    type="button"
                    onClick={redownload}
                    className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[12px] font-medium text-[#0f172a] transition-all duration-150 hover:border-slate-300 hover:bg-slate-50 hover:shadow-sm active:scale-[0.98]"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download again
                  </button>
                  <a
                    href="/login"
                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#0ea5e9] to-[#0284c7] px-4 py-2 text-[13px] font-semibold text-white transition-all duration-150 hover:from-[#0284c7] hover:to-[#0369a1] hover:shadow-md hover:shadow-[#0ea5e9]/25 active:scale-[0.98]"
                  >
                    Continue to sign in
                  </a>
                </div>
              </div>
            )}

            <p className="mt-3 text-center text-[12px] text-slate-500">
              <a
                href="/login"
                className="inline-flex items-center gap-1 font-semibold text-[#0ea5e9] transition-colors hover:text-[#0284c7]"
              >
                <ArrowLeft className="h-3 w-3" />
                Back to sign in
              </a>
            </p>
            <p className="mt-2 text-center text-[10px] text-slate-400">
              Protected by your organization's IAM platform.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
