/**
 * PolicyEditorPage — the policy DETAIL page (`/pbac/policies/:policyId`) and the
 * new-policy screen (`/pbac/policies/new`).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS LAYOUT (research: Entra ID, Okta, CyberArk, BeyondTrust, Delinea)
 * ═══════════════════════════════════════════════════════════════════════════
 * Every high-end IAM/PAM console presents a policy the same way, because the
 * questions arrive in the same order:
 *
 *   1. WHAT is this?          → identity band: name, type, version, immutable id
 *   2. WHAT does it grant?    → an effect summary an auditor can read at a
 *                               glance (allow vs deny, actions, resources)
 *   3. HOW do I change it?    → statements as discrete, individually-labelled
 *                               cards — never one long undifferentiated form
 *   4. WHO is affected?       → blast radius (roles that inherit it) on the same
 *                               screen as the edit control
 *   5. Commit                 → a persistent action bar that states whether
 *                               there are unsaved changes
 *
 * So the page is: back link → identity header (with the save action) → metric
 * strip → tabs (Overview · Statements · Document · Usage) → sticky action bar.
 * The previous version put the form in a 2/3 column, the JSON preview and the
 * Save button in a side card, and rendered the usage panel as a stray third grid
 * child — three different hierarchies competing on one screen.
 *
 * Nothing about the API contract changed: the same pbacApi / rbacApi /
 * identityApi calls, the same document builder, the same validation.
 * Colours and controls come from the existing design system only.
 * ═══════════════════════════════════════════════════════════════════════════
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, Plus, Trash2, Code2, UserPlus, Link2, FileLock2, ShieldCheck,
  ShieldOff, ListChecks, Boxes, Copy, Check, AlertTriangle, Info, Layers,
} from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { pbacApi } from '../../lib/api/pbac.js';
import { rbacApi } from '../../lib/api/rbac.js';
import { identityApi } from '../../lib/api/identity.js';
import { useResource } from '../../hooks/useResource.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Card, Panel, Button, Input, Textarea, Spinner, Badge, SearchableCombobox, Tabs,
  StatCard, DescriptionList, InlineAlert, IconButton, SegmentedControl, EmptyState,
} from '../../components/ui/primitives.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ExpiryInput, toIsoExpiry, isPastExpiry } from '../../components/ui/ExpiryInput.jsx';
import { POLICY_DOCUMENT_VERSION } from '../../utils/constants.js';
import { extractList, formatDateTime, classNames } from '../../utils/format.js';

/* Wildcard is a first-class choice in a policy statement, so it belongs in the
   picker rather than forcing the operator back to free text. */
const WILDCARD_OPTION = {
  id: '*',
  label: 'All resources  (*)',
  description: 'Matches every resource ARN',
};

/** Statement.Resource is stored as a comma-joined string; the picker wants an array. */
const parseResources = (value) =>
  String(value || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

const joinResources = (list) => (Array.isArray(list) ? list.join(', ') : '');

/** Action is also comma-joined; split for counting / summary display. */
const parseActions = (value) =>
  String(value || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

const blankStatement = () => ({
  sid: '',
  effect: 'Allow',
  action: '',
  resource: '',
  condition: '',
});

const EFFECT_OPTIONS = [
  { value: 'Allow', label: 'Allow' },
  { value: 'Deny', label: 'Deny' },
];

/** Backend statement → form row. One converter for both load paths. */
const toFormStatement = (s) => ({
  sid: s.Sid || '',
  effect: s.Effect || 'Allow',
  action: Array.isArray(s.Action) ? s.Action.join(', ') : s.Action || '',
  resource: Array.isArray(s.Resource) ? s.Resource.join(', ') : s.Resource || '',
  condition: s.Condition ? JSON.stringify(s.Condition, null, 2) : '',
});

export default function PolicyEditorPage() {
  const { policyId } = useParams();
  const isEdit = !!policyId;
  const navigate = useNavigate();
  const toast = useToast();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState(POLICY_DOCUMENT_VERSION);
  const [statements, setStatements] = useState([blankStatement()]);
  const [rawMode, setRawMode] = useState(false);
  const [rawText, setRawText] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [attachOpen, setAttachOpen] = useState(false);
  const [attachForm, setAttachForm] = useState({ user_id: '', expires_at: '' });
  const [attaching, setAttaching] = useState(false);
  const [nameError, setNameError] = useState('');
  const [tab, setTab] = useState('overview');
  const [copied, setCopied] = useState(false);
  /** Immutable server-side facts (id, timestamps, type) shown in the identity band. */
  const [meta, setMeta] = useState(null);
  /** Serialised form state as last loaded/saved — drives the unsaved-changes bar. */
  const snapshotRef = useRef('');

  /* The principal picker below is the shared SearchableCombobox primitive,
     which owns its own search / open / focus state. */

  // Fetch all users for the attach-policy dropdown.
  // Reuses the same identityApi.listUsers endpoint that UsersPage uses.
  const { accountId } = useAuth();
  const usersResource = useResource(
    () => (attachOpen && accountId ? identityApi.listUsers({ account_id: accountId, page: 1, per_page: 100 }) : null),
    [attachOpen, accountId]
  );
  const usersList = usersResource.data?.users || [];

  /* ── Resource registry for the statement Resource picker ──────────────────
     Statements reference resources by ARN, and typing an ARN by hand is the
     easiest thing in this editor to get silently wrong. The registry
     (GET /api/v1/resources) is loaded once and offered as a searchable
     multi-select: policy documents legitimately list several resources, so the
     field is multi with select-all over the current filter. */
  const resourcesResource = useResource(() => pbacApi.listResources(), []);
  const registryResources = extractList(resourcesResource.data, 'resources');

  const resourceOptions = useMemo(() => {
    const opts = registryResources
      .filter((r) => r.resource_arn)
      .map((r) => ({
        id: r.resource_arn,
        label: r.resource_name || r.resource_arn,
        description: r.resource_arn,
        badge: r.is_active === false ? 'INACTIVE' : r.resource_type || undefined,
      }));
    return [WILDCARD_OPTION, ...opts];
  }, [registryResources]);

  /* An existing policy may reference an ARN that is no longer registered (or a
     pattern like `iam:user/*`). Those values must stay selectable, so they are
     appended as options rather than silently dropped when the form loads. */
  const optionsForStatement = (statement) => {
    const known = new Set(resourceOptions.map((o) => o.id));
    const extras = parseResources(statement.resource)
      .filter((arn) => !known.has(arn))
      .map((arn) => ({
        id: arn,
        label: arn,
        description: 'Not in the resource registry',
        badge: 'CUSTOM',
      }));
    return extras.length ? [...resourceOptions, ...extras] : resourceOptions;
  };

  useEffect(() => {
    if (!isEdit) {
      snapshotRef.current = JSON.stringify({
        name: '',
        description: '',
        version: POLICY_DOCUMENT_VERSION,
        statements: [blankStatement()],
      });
      return;
    }
    pbacApi
      .getPolicy(policyId)
      .then((res) => {
        // Tolerate both the flat payload and a { policy: {…} } envelope.
        const p = res?.policy && typeof res.policy === 'object' ? { ...res, ...res.policy } : res || {};
        setMeta(p);
        setName(p.policy_name || '');
        setDescription(p.description || '');
        const doc = p.policy_document || {};
        const nextVersion = doc.Version || POLICY_DOCUMENT_VERSION;
        setVersion(nextVersion);
        const stmts = Array.isArray(doc.Statement) ? doc.Statement : [];
        const rows = stmts.length ? stmts.map(toFormStatement) : [blankStatement()];
        setStatements(rows);
        snapshotRef.current = JSON.stringify({
          name: p.policy_name || '',
          description: p.description || '',
          version: nextVersion,
          statements: rows,
        });
      })
      .catch((err) => toast.error(err.userMessage || 'This policy could not be loaded.'))
      .finally(() => setLoading(false));
  }, [isEdit, policyId, toast]);

  const updateStatement = (i, key, value) =>
    setStatements((list) => list.map((s, idx) => (idx === i ? { ...s, [key]: value } : s)));
  const addStatement = () => setStatements((list) => [...list, blankStatement()]);
  const removeStatement = (i) =>
    setStatements((list) => {
      const next = list.filter((_, idx) => idx !== i);
      return next.length ? next : [blankStatement()];
    });
  const duplicateStatement = (i) =>
    setStatements((list) => {
      const copy = { ...list[i], sid: list[i].sid ? `${list[i].sid}-copy` : '' };
      const next = [...list];
      next.splice(i + 1, 0, copy);
      return next;
    });

  /**
   * Raw-JSON toggle.
   *
   * Bug fix (kept): `rawText` started empty and was never seeded, so switching
   * to "Raw JSON" showed a blank editor and saving from it threw
   * "Unexpected end of JSON input". Entering raw mode serialises the current
   * document into the textarea, and leaving it parses the JSON back into the
   * statement form (invalid JSON keeps the form untouched and says so).
   */
  const toggleRawMode = () => {
    if (!rawMode) {
      let seed = rawText;
      try {
        seed = JSON.stringify(buildDocument(), null, 2);
      } catch {
        seed = rawText || JSON.stringify({ Version: version, Statement: [] }, null, 2);
      }
      setRawText(seed);
      setRawMode(true);
      return;
    }
    try {
      const parsed = JSON.parse(rawText);
      const stmts = Array.isArray(parsed.Statement) ? parsed.Statement : [];
      setVersion(parsed.Version || version);
      setStatements(stmts.length ? stmts.map(toFormStatement) : [blankStatement()]);
      setRawMode(false);
    } catch {
      toast.error('The document is not valid JSON. Correct it before switching back to the form.');
    }
  };

  const buildDocument = () => {
    if (rawMode) {
      const parsed = JSON.parse(rawText);
      if (!Array.isArray(parsed.Statement) || parsed.Statement.length === 0)
        throw new Error('The document must include at least one statement.');
      return parsed;
    }
    const valid = statements.filter((s) => s.action.trim() && s.resource.trim());
    if (!valid.length) throw new Error('Add at least one statement with an action and a resource.');
    const Statement = valid.map((s) => {
      const toField = (v) =>
        v.includes(',') ? v.split(',').map((x) => x.trim()).filter(Boolean) : v.trim();
      const stmt = {
        Effect: s.effect,
        Action: toField(s.action),
        Resource: toField(s.resource),
      };
      if (s.sid.trim()) stmt.Sid = s.sid.trim();
      if (s.condition.trim()) {
        try {
          stmt.Condition = JSON.parse(s.condition);
        } catch {
          throw new Error('Each condition must be valid JSON.');
        }
      }
      return stmt;
    });
    return { Version: version, Statement };
  };

  const save = async () => {
    // A policy without a name is rejected by the API with an opaque 400, so
    // catch it here where the field can be highlighted.
    if (!name.trim()) {
      setNameError('Policy name is required.');
      setTab('overview');
      toast.error('Give the policy a name before saving.');
      return;
    }
    setNameError('');
    setSaving(true);
    try {
      const policy_document = buildDocument();
      const payload = { policy_name: name, description, policy_document };
      if (isEdit) await pbacApi.updatePolicy(policyId, payload);
      else await pbacApi.createPolicy(payload);
      toast.success(`Policy ${isEdit ? 'updated' : 'created'}.`);
      navigate('/pbac/policies');
    } catch (err) {
      /* `err.message` first would surface raw axios text ("Request failed with
         status code 500"); the sanitised copy always wins. A validation Error
         raised by buildDocument() carries no `userMessage`, so its own
         operator-readable sentence is still shown. */
      toast.error(err.userMessage || err.message || 'Could not save the policy.');
    } finally {
      setSaving(false);
    }
  };

  const attach = async (e) => {
    e.preventDefault();
    if (!attachForm.user_id) { toast.error('Select a user first.'); return; }
    // An expiry in the past would revoke the attachment the moment it is saved.
    if (isPastExpiry(attachForm.expires_at)) {
      toast.error('Choose an expiry date of today or later.');
      return;
    }
    setAttaching(true);
    try {
      await pbacApi.attachPolicyToUser({
        user_id: attachForm.user_id,
        policy_id: policyId,
        // Local control value → ISO 8601, centralised in ExpiryInput.
        expires_at: toIsoExpiry(attachForm.expires_at),
      });
      toast.success('Policy attached to user.');
      setAttachOpen(false);
      setAttachForm({ user_id: '', expires_at: '' });
    } catch (err) {
      toast.error(err.userMessage || 'Could not attach the policy.');
    } finally {
      setAttaching(false);
    }
  };

  /* ── Derived summary ──────────────────────────────────────────────────────
     Read from whichever editor is active, so the metric strip and the Overview
     summary always describe what would be saved right now. */
  const summary = useMemo(() => {
    let rows = statements;
    if (rawMode) {
      try {
        const parsed = JSON.parse(rawText);
        rows = (Array.isArray(parsed.Statement) ? parsed.Statement : []).map(toFormStatement);
      } catch {
        rows = [];
      }
    }
    const filled = rows.filter((s) => s.action.trim() || s.resource.trim());
    const allow = filled.filter((s) => String(s.effect).toLowerCase() === 'allow');
    const deny = filled.filter((s) => String(s.effect).toLowerCase() !== 'allow');
    const actions = new Set();
    const resources = new Set();
    filled.forEach((s) => {
      parseActions(s.action).forEach((a) => actions.add(a));
      parseResources(s.resource).forEach((r) => resources.add(r));
    });
    return {
      rows: filled,
      statementCount: filled.length,
      allowCount: allow.length,
      denyCount: deny.length,
      actionCount: actions.size,
      resourceCount: resources.size,
      conditional: filled.filter((s) => s.condition.trim()).length,
      wildcard: resources.has('*') || Array.from(actions).some((a) => a === '*' || a.endsWith(':*')),
    };
  }, [statements, rawMode, rawText]);

  const preview = useMemo(() => {
    try {
      return JSON.stringify(buildDocument(), null, 2);
    } catch (err) {
      return `// ${err.message || 'Complete the statements to preview the document.'}`;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statements, version, rawMode, rawText]);

  const dirty = useMemo(() => {
    if (!snapshotRef.current) return false;
    return (
      JSON.stringify({ name, description, version, statements }) !== snapshotRef.current
    );
  }, [name, description, version, statements]);

  const copyDocument = async () => {
    try {
      await navigator.clipboard.writeText(preview);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error('The document could not be copied. Select it and copy manually.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-8 w-8" />
      </div>
    );
  }

  const isSystemPolicy = !!(meta?.is_system_policy || meta?.policy_type === 'SYSTEM');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Info },
    { id: 'statements', label: 'Statements', icon: ListChecks, count: summary.statementCount },
    { id: 'document', label: 'Document', icon: Code2 },
    ...(isEdit ? [{ id: 'usage', label: 'Usage', icon: Link2 }] : []),
  ];

  return (
    <div className="pb-2">
      <button
        onClick={() => navigate('/pbac/policies')}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-ink-700"
      >
        <ArrowLeft className="h-4 w-4" /> Policies
      </button>

      {/* ── Identity band ──────────────────────────────────────────────────
          Name, type and immutable identifiers, exactly like a policy blade in
          Entra ID: what an operator quotes in a change ticket. */}
      <PageHeader
        title={isEdit ? name || 'Policy' : 'New policy'}
        description={
          isEdit
            ? description || 'No description. Add one so reviewers know why this policy exists.'
            : 'Define the allow and deny statements this policy contributes to every access decision.'
        }
        icon={<FileLock2 className="h-4.5 w-4.5" />}
        breadcrumbs={[
          { label: 'Access control' },
          { label: 'Policies', to: '/pbac/policies' },
          { label: isEdit ? name || 'Policy' : 'New policy' },
        ]}
        meta={
          <>
            <Badge tone={isSystemPolicy ? 'brand' : 'slate'}>
              {isSystemPolicy ? 'System policy' : 'Custom policy'}
            </Badge>
            <span className="inline-flex items-center gap-1.5">
              <Layers className="h-3.5 w-3.5 text-slate-400" />
              Version <span className="font-mono text-slate-600">{version}</span>
            </span>
            {isEdit && (
              <span className="inline-flex items-center gap-1.5">
                <FileLock2 className="h-3.5 w-3.5 text-slate-400" />
                <span className="font-mono text-slate-600">{policyId}</span>
              </span>
            )}
            {meta?.updated_at && (
              <span className="inline-flex items-center gap-1.5">
                Updated {formatDateTime(meta.updated_at)}
              </span>
            )}
          </>
        }
        actions={
          <>
            {isEdit && (
              <Button variant="secondary" onClick={() => setAttachOpen(true)}>
                <UserPlus className="h-4 w-4" /> Attach to user
              </Button>
            )}
            <Button onClick={save} loading={saving}>
              {isEdit ? 'Save changes' : 'Create policy'}
            </Button>
          </>
        }
      />

      {/* ── Metric strip ──────────────────────────────────────────────────
          The shape of the policy before its text: how many rules, how they
          split between allow and deny, and how wide the resource surface is. */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard
          label="Statements"
          value={summary.statementCount}
          hint={summary.conditional ? `${summary.conditional} conditional` : 'No conditions'}
          icon={ListChecks}
          tone="brand"
        />
        <StatCard
          label="Allow rules"
          value={summary.allowCount}
          hint={`${summary.actionCount} distinct action${summary.actionCount === 1 ? '' : 's'}`}
          icon={ShieldCheck}
          tone="green"
        />
        <StatCard
          label="Deny rules"
          value={summary.denyCount}
          hint={summary.denyCount ? 'Deny overrides allow' : 'None defined'}
          icon={ShieldOff}
          tone={summary.denyCount ? 'red' : 'slate'}
        />
        <StatCard
          label="Resources"
          value={summary.resourceCount}
          hint={summary.wildcard ? 'Includes a wildcard' : 'Explicitly scoped'}
          icon={Boxes}
          tone={summary.wildcard ? 'amber' : 'sky'}
        />
      </div>

      {summary.wildcard && (
        <InlineAlert tone="warning" title="This policy grants wildcard access" className="mt-4">
          A wildcard action or resource matches everything it covers, now and in future. Scope it to
          named resources where the intent is narrower.
        </InlineAlert>
      )}

      <Tabs tabs={tabs} active={tab} onChange={setTab} className="mt-5" />

      {/* ═══════════════════════════ OVERVIEW ═══════════════════════════ */}
      {tab === 'overview' && (
        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-12">
          <div className="xl:col-span-7">
            <Panel title="Definition" subtitle="How this policy is identified and described" icon={FileLock2}>
              <div className="space-y-4">
                <Input
                  label="Policy name"
                  value={name}
                  error={nameError}
                  onChange={(e) => {
                    setName(e.target.value);
                    setNameError('');
                  }}
                  required
                  placeholder="finance-read-only"
                  hint="Lowercase, hyphenated names read best in policy documents and audit trails."
                />
                <Textarea
                  label="Description"
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Why this policy exists and who it is intended for"
                  hint="Reviewers see this first during an access review."
                />
                <Input
                  label="Document version"
                  value={version}
                  onChange={(e) => setVersion(e.target.value)}
                  hint="Stamped into the saved document as `Version`."
                />
              </div>
            </Panel>
          </div>

          <div className="xl:col-span-5">
            <Panel title="Identifiers" subtitle="Immutable facts for change records" icon={Info} className="h-full">
              <DescriptionList
                columns={1}
                items={[
                  { label: 'Policy ID', value: isEdit ? policyId : 'Assigned on creation', mono: isEdit },
                  { label: 'Type', value: isSystemPolicy ? 'System (platform-managed)' : 'Custom' },
                  { label: 'Status', value: meta?.status || (isEdit ? 'Active' : 'Draft') },
                  { label: 'Created', value: meta?.created_at ? formatDateTime(meta.created_at) : '—' },
                  { label: 'Last updated', value: meta?.updated_at ? formatDateTime(meta.updated_at) : '—' },
                ]}
              />
            </Panel>
          </div>

          <div className="xl:col-span-12">
            <EffectSummary rows={summary.rows} onEdit={() => setTab('statements')} />
          </div>
        </div>
      )}

      {/* ═══════════════════════════ STATEMENTS ═══════════════════════════ */}
      {tab === 'statements' && (
        <div className="mt-4 space-y-3">
          <div className="flex flex-col gap-2 rounded-xl border border-line bg-white px-3 py-2.5 shadow-card sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-slate-500">
              Statements are evaluated together; a matching <span className="font-semibold text-ink-800">Deny</span>{' '}
              always wins over an allow.
            </p>
            <div className="flex shrink-0 items-center gap-2">
              <Button variant="secondary" size="sm" onClick={toggleRawMode}>
                <Code2 className="h-4 w-4" /> {rawMode ? 'Back to form' : 'Edit as JSON'}
              </Button>
              {!rawMode && (
                <Button size="sm" onClick={addStatement}>
                  <Plus className="h-4 w-4" /> Add statement
                </Button>
              )}
            </div>
          </div>

          {rawMode ? (
            <Card className="p-5">
              <Textarea
                label="Policy document"
                rows={18}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                className="font-mono text-xs"
                placeholder='{ "Version": "2025-01-01", "Statement": [ ... ] }'
                hint="Switch back to the form to edit statement by statement — the JSON is parsed on the way back."
              />
            </Card>
          ) : statements.length === 0 ? (
            <EmptyState
              icon={ListChecks}
              title="No statements yet"
              description="A policy grants nothing until it carries at least one statement."
              action={<Button onClick={addStatement}>Add the first statement</Button>}
            />
          ) : (
            statements.map((s, i) => {
              const deny = String(s.effect).toLowerCase() === 'deny';
              const incomplete = !s.action.trim() || !s.resource.trim();
              return (
                <Card key={i} className="overflow-hidden">
                  {/* Statement header: effect is the loudest thing on the row,
                      because it is what decides the outcome. */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line-soft bg-slate-50/70 px-4 py-2.5">
                    <div className="flex min-w-0 items-center gap-2.5">
                      <span
                        className={classNames(
                          'flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-3xs font-bold',
                          deny ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
                        )}
                      >
                        {i + 1}
                      </span>
                      <span className="truncate text-[13px] font-semibold text-ink-900">
                        {s.sid.trim() || `Statement ${i + 1}`}
                      </span>
                      {incomplete && <Badge tone="amber">Incomplete</Badge>}
                      {s.condition.trim() && <Badge tone="slate">Conditional</Badge>}
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <SegmentedControl
                        size="sm"
                        ariaLabel={`Effect for statement ${i + 1}`}
                        value={s.effect}
                        onChange={(v) => updateStatement(i, 'effect', v)}
                        options={EFFECT_OPTIONS}
                      />
                      <IconButton
                        icon={Copy}
                        title="Duplicate statement"
                        onClick={() => duplicateStatement(i)}
                      />
                      <IconButton
                        icon={Trash2}
                        title="Remove statement"
                        tone="danger"
                        onClick={() => removeStatement(i)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-2 sm:px-5">
                    <Input
                      label="Action"
                      value={s.action}
                      onChange={(e) => updateStatement(i, 'action', e.target.value)}
                      placeholder="iam:user:Read, iam:user:List"
                      hint="One or more permissions, comma separated. `iam:*` matches the whole service."
                      required
                    />
                    {/* Resource picker — real ARNs from the registry, never a
                        hand-typed string. */}
                    <SearchableCombobox
                      label="Resource"
                      multi
                      required
                      options={optionsForStatement(s)}
                      value={parseResources(s.resource)}
                      onChange={(list) => updateStatement(i, 'resource', joinResources(list))}
                      loading={resourcesResource.loading}
                      error={resourcesResource.error ? 'The resource registry could not be loaded.' : undefined}
                      placeholder="Select resources…"
                      searchPlaceholder="Search resources by name or ARN…"
                      hint="From the resource registry. Choose “All resources” for a wildcard."
                      emptyMessage="No resources match that search."
                    />
                    <Input
                      label="Statement ID (optional)"
                      value={s.sid}
                      onChange={(e) => updateStatement(i, 'sid', e.target.value)}
                      placeholder="AllowFinanceRead"
                      hint="A label that shows up in decision logs."
                    />
                    <Textarea
                      label="Condition (JSON, optional)"
                      rows={3}
                      value={s.condition}
                      onChange={(e) => updateStatement(i, 'condition', e.target.value)}
                      className="font-mono text-xs"
                      placeholder='{ "StringEquals": { "user.department": "engineering" } }'
                    />
                  </div>
                </Card>
              );
            })
          )}
        </div>
      )}

      {/* ═══════════════════════════ DOCUMENT ═══════════════════════════ */}
      {tab === 'document' && (
        <div className="mt-4">
          <Panel
            title="Generated policy document"
            subtitle="Exactly what will be stored and evaluated"
            icon={Code2}
            action={
              <>
                <Button variant="ghost" size="sm" onClick={copyDocument}>
                  {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? 'Copied' : 'Copy'}
                </Button>
                <Button variant="secondary" size="sm" onClick={toggleRawMode}>
                  <Code2 className="h-4 w-4" /> {rawMode ? 'Back to form' : 'Edit as JSON'}
                </Button>
              </>
            }
          >
            {rawMode ? (
              <Textarea
                rows={20}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                className="font-mono text-xs"
                placeholder='{ "Version": "2025-01-01", "Statement": [ ... ] }'
              />
            ) : (
              <pre className="max-h-[60vh] overflow-auto rounded-lg bg-ink-900 p-4 text-xs leading-relaxed text-emerald-200">
                {preview}
              </pre>
            )}
          </Panel>
        </div>
      )}

      {/* ═══════════════════════════ USAGE ═══════════════════════════ */}
      {tab === 'usage' && isEdit && (
        <div className="mt-4">
          <PolicyUsage policyId={policyId} />
        </div>
      )}

      {/* ── Action bar ────────────────────────────────────────────────────
          Persistent, and honest about state: an operator should never have to
          scroll to find out whether their edit is saved. */}
      <div className="sticky bottom-3 z-20 mt-5">
        <div className="flex flex-col gap-3 rounded-xl border border-line bg-white/95 px-4 py-3 shadow-popover backdrop-blur sm:flex-row sm:items-center sm:justify-between">
          <p className="flex items-center gap-2 text-xs text-slate-500">
            {dirty ? (
              <>
                <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber-500" />
                Unsaved changes — {summary.statementCount} statement
                {summary.statementCount === 1 ? '' : 's'} ready to save.
              </>
            ) : (
              <>
                <Check className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                {isEdit ? 'No changes since this policy was last saved.' : 'Nothing to save yet.'}
              </>
            )}
          </p>
          <div className="flex shrink-0 items-center gap-2">
            <Button variant="secondary" onClick={() => navigate('/pbac/policies')}>
              Cancel
            </Button>
            <Button onClick={save} loading={saving} disabled={isEdit && !dirty}>
              {isEdit ? 'Save changes' : 'Create policy'}
            </Button>
          </div>
        </div>
      </div>

      <Modal
        open={attachOpen}
        onClose={() => { setAttachOpen(false); setAttachForm({ user_id: '', expires_at: '' }); }}
        title="Attach policy to user"
        description="Grants these permissions directly to one principal, independent of roles."
        icon={UserPlus}
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => { setAttachOpen(false); setAttachForm({ user_id: '', expires_at: '' }); }}>Cancel</Button>
            <Button onClick={attach} loading={attaching} disabled={!attachForm.user_id}>Attach</Button>
          </>
        }
      >
        <form onSubmit={attach} className="space-y-4">
          {/* Type-ahead principal picker — same endpoint (identityApi.listUsers),
              one field: typing filters the directory list underneath it. */}
          <SearchableCombobox
            label="User"
            required
            options={usersList.map((u) => ({
              id: u.user_id,
              label: u.username || u.email || u.user_id,
              description: u.email,
              badge: u.status && u.status !== 'ACTIVE' ? u.status : undefined,
            }))}
            value={attachForm.user_id}
            onChange={(id) => setAttachForm((f) => ({ ...f, user_id: id || '' }))}
            loading={usersResource.loading}
            error={usersResource.error ? 'The user directory could not be loaded.' : undefined}
            placeholder="Search users by name or email…"
            hint="Type to filter the tenant directory."
            emptyMessage="No users match that name or email."
          />

          <ExpiryInput
            label="Expires at (optional)"
            value={attachForm.expires_at}
            onChange={(e) => setAttachForm((f) => ({ ...f, expires_at: e.target.value }))}
            hint="Leave empty for no expiry. Past dates are disabled."
          />
        </form>
      </Modal>
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   EffectSummary — the auditor's view of the policy.

   Reviewers do not read a form; they read a table of effect / action / resource.
   Deny rows are listed first because in a deny-overrides evaluator they are what
   actually decides an outcome. Read-only, derived from the current editor state.
   ═══════════════════════════════════════════════════════════════════════════ */
function EffectSummary({ rows = [], onEdit }) {
  const ordered = useMemo(() => {
    const withIndex = rows.map((r, i) => ({ ...r, i }));
    return withIndex.sort((a, b) => {
      const aDeny = String(a.effect).toLowerCase() === 'deny' ? 0 : 1;
      const bDeny = String(b.effect).toLowerCase() === 'deny' ? 0 : 1;
      return aDeny - bDeny || a.i - b.i;
    });
  }, [rows]);

  return (
    <Panel
      title="What this policy grants"
      subtitle="Every statement, deny rules first — the order a reviewer reads them in"
      icon={ShieldCheck}
      action={
        <Button variant="ghost" size="sm" onClick={onEdit}>
          Edit statements
        </Button>
      }
    >
      {ordered.length === 0 ? (
        <p className="py-6 text-center text-[13px] text-slate-500">
          No complete statements yet — this policy would grant nothing.
        </p>
      ) : (
        <div className="overflow-hidden rounded-lg border border-line">
          <table className="min-w-full border-separate border-spacing-0 text-[13px]">
            <thead>
              <tr>
                {['Effect', 'Action', 'Resource', 'Statement'].map((h) => (
                  <th
                    key={h}
                    className="border-b border-line bg-slate-50/95 px-3 py-2 text-left text-2xs font-semibold uppercase tracking-[0.07em] text-slate-500"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ordered.map((row) => {
                const deny = String(row.effect).toLowerCase() === 'deny';
                const actions = parseActions(row.action);
                return (actions.length ? actions : ['*']).map((action, j) => (
                  <tr key={`${row.i}-${j}`} className="hover:bg-slate-50/70">
                    <td className="border-b border-line-soft px-3 py-1.5">
                      {j === 0 && <Badge tone={deny ? 'red' : 'green'}>{deny ? 'DENY' : 'ALLOW'}</Badge>}
                    </td>
                    <td className="border-b border-line-soft px-3 py-1.5 font-mono text-xs text-ink-900">
                      {action}
                      {row.condition?.trim() && (
                        <span className="ml-2 rounded bg-slate-100 px-1 py-0.5 text-3xs font-medium text-slate-500">
                          conditional
                        </span>
                      )}
                    </td>
                    <td className="border-b border-line-soft px-3 py-1.5 font-mono text-xs text-slate-600">
                      {parseResources(row.resource).join(', ') || '*'}
                    </td>
                    <td className="border-b border-line-soft px-3 py-1.5 text-xs text-slate-500">
                      {row.sid?.trim() || `Statement ${row.i + 1}`}
                    </td>
                  </tr>
                ));
              })}
            </tbody>
          </table>
        </div>
      )}
    </Panel>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   PolicyUsage — "where is this policy used?"

   Disabling or editing a policy is a blast-radius decision, so the roles that
   depend on it belong on the same screen as the edit form. Read-only: it lists
   roles (existing endpoint) and asks each for its attachments, capped so the
   page never fires an unbounded number of requests.
   ═══════════════════════════════════════════════════════════════════════════ */
function PolicyUsage({ policyId }) {
  const [state, setState] = useState({ loading: true, roles: [], truncated: false });

  useEffect(() => {
    let cancelled = false;
    setState({ loading: true, roles: [], truncated: false });

    rbacApi
      .listRoles()
      .then((res) => {
        const all = extractList(res, 'roles');
        const scan = all.slice(0, 30);
        return Promise.allSettled(
          scan.map((role) =>
            rbacApi.listRolePolicies(role.role_id).then((rp) => ({ role, attachments: rp }))
          )
        ).then((results) => ({ results, truncated: all.length > scan.length }));
      })
      .then(({ results, truncated }) => {
        if (cancelled) return;
        const roles = [];
        results.forEach((r) => {
          if (r.status !== 'fulfilled') return;
          const { role, attachments } = r.value;
          const arr = extractList(attachments, 'policies').length
            ? extractList(attachments, 'policies')
            : extractList(attachments, 'role_policies');
          if (arr.some((a) => (a.policy_id || a.policy?.policy_id) === policyId)) roles.push(role);
        });
        setState({ loading: false, roles, truncated });
      })
      .catch(() => !cancelled && setState({ loading: false, roles: [], truncated: false }));

    return () => {
      cancelled = true;
    };
  }, [policyId]);

  return (
    <Panel
      title="Where this policy is used"
      subtitle="Roles that inherit these permissions today"
      icon={Link2}
      footer={
        state.truncated ? (
          <span className="text-2xs text-slate-400">
            Checked the first 30 roles. Narrow the role list to audit the rest.
          </span>
        ) : undefined
      }
    >
      {state.loading ? (
        <div className="flex justify-center py-8">
          <Spinner className="h-5 w-5" />
        </div>
      ) : state.roles.length === 0 ? (
        <p className="rounded-lg border border-line-soft bg-slate-50/70 px-3 py-2.5 text-xs text-slate-500">
          Not attached to any role. Changes here affect only direct user attachments.
        </p>
      ) : (
        <ul className="space-y-1.5">
          {state.roles.map((role) => (
            <li key={role.role_id}>
              <Link
                to={`/rbac/roles/${role.role_id}`}
                className="flex items-center justify-between gap-2 rounded-lg border border-line px-3 py-2 no-underline transition-colors hover:bg-slate-50 hover:no-underline"
              >
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-medium text-ink-900">
                    {role.role_name}
                  </span>
                  {role.description && (
                    <span className="block truncate text-2xs text-slate-500">{role.description}</span>
                  )}
                </span>
                {role.assigned_users_count != null && (
                  <Badge tone="slate">
                    {role.assigned_users_count} user{role.assigned_users_count === 1 ? '' : 's'}
                  </Badge>
                )}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Panel>
  );
}
