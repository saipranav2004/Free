import { useState, useMemo } from 'react';
import {
  Boxes, Plus, Trash2, RefreshCw, Link2, CheckCircle2, Ban, Copy, Server,
  Tag, Users2, Clock, ShieldCheck,
} from 'lucide-react';
import { useToast } from '../../context/ToastContext.jsx';
import { useResource } from '../../hooks/useResource.js';
import { pbacApi } from '../../lib/api/pbac.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Button, Input, Select, StatusBadge, EmptyState, Badge, Toolbar, SearchInput, IconButton,
  StatCard, SegmentedControl,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog.jsx';
import { formatDateTime, classNames } from '../../utils/format.js';

/**
 * ResourcesPage (ABAC) — the registry of protected resources referenced by
 * policies.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * API CONTRACT (top-level /api/v1/resources surface)
 * ═══════════════════════════════════════════════════════════════════════════
 *   GET    /api/v1/resources             → { pagination, resources: [ … ] }
 *   POST   /api/v1/resources/create      → { resource: { … } }
 *   DELETE /api/v1/resources/<id>
 *
 * Create body is sent EXACTLY as specified:
 *   { resource_name, resource_type, resource_arn, target_url,
 *     is_active, metadata: { env, team } }
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * UX MODEL (revised)
 * ═══════════════════════════════════════════════════════════════════════════
 * The previous table pushed eight columns across the viewport, so the field an
 * operator scans for first — is this resource live? — sat off-screen behind a
 * horizontal scrollbar. Registry tables in mature consoles (AWS resource
 * groups, GCP asset inventory) resolve this the same way, and so does this one:
 *
 *  · SUMMARY, then LIST. Three tiles quantify the registry before any row is
 *    read, and they derive from the loaded rows so create/delete move them.
 *  · IDENTITY COLUMN. Name, type and ARN are one cell — they are read together
 *    and never independently sorted.
 *  · STATUS SECOND. Immediately after identity, never scrolled: it is the field
 *    that decides whether anything else on the row matters. A status filter
 *    sits in the toolbar for the same reason.
 *  · EVERYTHING ELSE IS SECONDARY. Target, environment/team and provenance stay
 *    in the table but can be hidden per operator via the Columns chooser; the
 *    full record lives one click away instead of demanding width.
 *  · ROW CLICK OPENS THE RECORD. A details panel shows every field the API
 *    returns — including ids and metadata the table deliberately omits — with
 *    copy affordances for the two values that get pasted into policy documents.
 *  · BULK WORK IS FIRST-CLASS. Registries are cleaned up in batches, so rows
 *    are selectable with select-all and a contextual delete that reports
 *    per-resource outcomes rather than failing silently.
 */

/** Common resource types — free text is still allowed via the "Other" option. */
const RESOURCE_TYPES = ['application', 'api', 'dataset', 'database', 'service', 'storage'];

const EMPTY_FORM = {
  resource_name: '',
  resource_type: 'application',
  resource_type_other: '',
  resource_arn: '',
  target_url: '',
  is_active: true,
  env: '',
  team: '',
};

const STATUS_FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
];

/* ── Details panel ────────────────────────────────────────────────────────── */

function DetailRow({ label, children, mono = false }) {
  return (
    <div className="grid grid-cols-[130px_1fr] items-start gap-3 py-2">
      <dt className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-400">{label}</dt>
      <dd className={classNames('min-w-0 break-words text-[13px] text-ink-800', mono && 'font-mono text-xs')}>
        {children}
      </dd>
    </div>
  );
}

function CopyableValue({ value, onCopy }) {
  if (!value) return <span className="text-slate-400">—</span>;
  return (
    <span className="flex items-start gap-1.5">
      <span className="min-w-0 flex-1 break-all font-mono text-xs text-ink-800">{value}</span>
      <IconButton icon={Copy} title="Copy to clipboard" onClick={() => onCopy(value)} />
    </span>
  );
}

/**
 * ResourceDetails — the full record for one resource.
 *
 * Everything the API returns is shown here, which is what lets the table stay
 * narrow. ARN and target URL carry copy buttons because both are pasted
 * verbatim into policy documents and integration config.
 */
function ResourceDetails({ resource, onClose, onDelete, onCopy }) {
  if (!resource) return null;
  const meta = resource.metadata && typeof resource.metadata === 'object' ? resource.metadata : {};
  const extraMeta = Object.entries(meta).filter(([k]) => k !== 'env' && k !== 'team');

  return (
    <Modal
      open={!!resource}
      onClose={onClose}
      size="lg"
      title={resource.resource_name || 'Resource'}
      description="Full registry record for this protected resource."
      icon={Boxes}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
          <Button variant="danger" onClick={() => onDelete(resource)}>
            <Trash2 className="h-4 w-4" /> Delete resource
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={resource.is_active ? 'ACTIVE' : 'DISABLED'} />
          {resource.resource_type && <Badge tone="slate">{resource.resource_type}</Badge>}
          {meta.env && <Badge tone="brand">{meta.env}</Badge>}
        </div>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <ShieldCheck className="h-3.5 w-3.5" /> Policy identifiers
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <DetailRow label="ARN">
              <CopyableValue value={resource.resource_arn} onCopy={onCopy} />
            </DetailRow>
            <DetailRow label="Resource ID" mono>
              {resource.resource_id || '—'}
            </DetailRow>
          </dl>
        </section>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <Server className="h-3.5 w-3.5" /> Endpoint
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <DetailRow label="Target URL">
              {resource.target_url ? (
                <span className="flex items-start gap-1.5">
                  <a
                    href={resource.target_url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="min-w-0 flex-1 break-all text-[13px] text-brand-700 hover:text-brand-800"
                  >
                    {resource.target_url}
                  </a>
                  <IconButton
                    icon={Copy}
                    title="Copy target URL"
                    onClick={() => onCopy(resource.target_url)}
                  />
                </span>
              ) : (
                <span className="text-slate-400">—</span>
              )}
            </DetailRow>
            <DetailRow label="Evaluated">
              {resource.is_active
                ? 'Yes — included in access decisions'
                : 'No — registered but not evaluated'}
            </DetailRow>
          </dl>
        </section>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <Tag className="h-3.5 w-3.5" /> Metadata
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <DetailRow label="Environment">{meta.env || <span className="text-slate-400">—</span>}</DetailRow>
            <DetailRow label="Team">{meta.team || <span className="text-slate-400">—</span>}</DetailRow>
            {extraMeta.map(([key, value]) => (
              <DetailRow key={key} label={key.replace(/_/g, ' ')}>
                {typeof value === 'object' ? JSON.stringify(value) : String(value)}
              </DetailRow>
            ))}
          </dl>
        </section>

        <section>
          <h4 className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            <Clock className="h-3.5 w-3.5" /> Provenance
          </h4>
          <dl className="mt-1 divide-y divide-line-soft">
            <DetailRow label="Created">{formatDateTime(resource.created_at)}</DetailRow>
            <DetailRow label="Created by" mono>
              {resource.created_by || '—'}
            </DetailRow>
            {resource.updated_at && (
              <DetailRow label="Updated">{formatDateTime(resource.updated_at)}</DetailRow>
            )}
          </dl>
        </section>
      </div>
    </Modal>
  );
}

/* ── Page ─────────────────────────────────────────────────────────────────── */

export default function ResourcesPage() {
  const toast = useToast();
  const resources = useResource(() => pbacApi.listResources(), []);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);
  const [detailsOf, setDetailsOf] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);

  /* ── List response: { pagination, resources: [...] }, with tolerance for a
     bare array or a { data: { resources } } envelope from older builds. ── */
  const payload = resources.data;
  const data = Array.isArray(payload)
    ? payload
    : payload?.resources || payload?.data?.resources || [];

  /* Counts.
     `pagination.total` is the server's view across all pages, but it can lag a
     just-completed create/delete (or be absent entirely), and it must never
     read lower than the rows actually in hand — so take the larger of the two.
     Active / inactive are derived from the rows themselves, so every tile moves
     the moment `resources.reload()` lands after a create or a delete. */
  const total = Math.max(payload?.pagination?.total ?? 0, data.length);
  const activeCount = data.filter((r) => r.is_active).length;
  const inactiveCount = data.length - activeCount;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return data.filter((r) => {
      if (statusFilter === 'active' && !r.is_active) return false;
      if (statusFilter === 'inactive' && r.is_active) return false;
      if (!q) return true;
      return (
        r.resource_name?.toLowerCase().includes(q) ||
        r.resource_arn?.toLowerCase().includes(q) ||
        r.resource_type?.toLowerCase().includes(q) ||
        r.target_url?.toLowerCase().includes(q) ||
        r.metadata?.env?.toLowerCase().includes(q) ||
        r.metadata?.team?.toLowerCase().includes(q)
      );
    });
  }, [data, search, statusFilter]);

  const selectedResources = useMemo(
    () => data.filter((r) => selectedIds.includes(r.resource_id)),
    [data, selectedIds]
  );

  const copyValue = async (value) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success('Copied to clipboard.');
    } catch {
      toast.error('Clipboard is unavailable in this browser.');
    }
  };

  const set = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((x) => ({ ...x, [key]: undefined }));
  };

  const resolvedType = () =>
    (form.resource_type === '__other' ? form.resource_type_other : form.resource_type).trim();

  const validate = () => {
    const next = {};
    if (!form.resource_name.trim()) next.resource_name = 'Resource name is required.';
    if (!resolvedType()) next.resource_type_other = 'Resource type is required.';
    if (!form.resource_arn.trim()) next.resource_arn = 'ARN is required.';
    if (!form.target_url.trim()) next.target_url = 'Target URL is required.';
    else if (!/^https?:\/\/\S+$/i.test(form.target_url.trim())) {
      next.target_url = 'Enter a full URL, e.g. https://api.example.com';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  // ── Create ── POST /api/v1/resources/create, then refresh the table.
  const createResource = async (e) => {
    e.preventDefault();
    if (saving) return;
    if (!validate()) return;

    setSaving(true);
    try {
      const res = await pbacApi.createResource({
        resource_name: form.resource_name.trim(),
        resource_type: resolvedType(),
        resource_arn: form.resource_arn.trim(),
        target_url: form.target_url.trim(),
        is_active: !!form.is_active,
        metadata: {
          env: form.env.trim(),
          team: form.team.trim(),
        },
      });
      const created = res?.resource || res?.data?.resource;
      toast.success(
        created?.resource_name
          ? `Resource “${created.resource_name}” created.`
          : 'Resource created successfully.'
      );
      setOpen(false);
      setForm(EMPTY_FORM);
      setErrors({});
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not create resource.');
    } finally {
      setSaving(false);
    }
  };

  // ── Delete one ── DELETE /api/v1/resources/<resource_id>, then refresh.
  const removeResource = async () => {
    const resourceId = deleteTarget?.resource_id;
    if (!resourceId) {
      toast.error('This resource has no id — it cannot be deleted.');
      setDeleteTarget(null);
      return;
    }
    setBusy(true);
    try {
      await pbacApi.deleteResource(resourceId);
      toast.success('Resource deleted.');
      setDeleteTarget(null);
      setDetailsOf(null);
      setSelectedIds((ids) => ids.filter((id) => id !== resourceId));
      resources.reload();
    } catch (err) {
      toast.error(err.userMessage || 'Could not delete resource.');
    } finally {
      setBusy(false);
    }
  };

  /* ── Delete many ──
     Requests run in parallel and every outcome is reported: a partial failure
     in a batch is the one case where a single "done" toast would lie. */
  const removeSelected = async () => {
    const ids = selectedResources.map((r) => r.resource_id).filter(Boolean);
    if (!ids.length) {
      setBulkDeleteOpen(false);
      return;
    }
    setBusy(true);
    try {
      const results = await Promise.allSettled(ids.map((id) => pbacApi.deleteResource(id)));
      const failed = results.filter((r) => r.status === 'rejected').length;
      const ok = results.length - failed;
      if (ok) toast.success(`${ok} resource${ok === 1 ? '' : 's'} deleted.`);
      if (failed) toast.error(`${failed} resource${failed === 1 ? '' : 's'} could not be deleted.`);
      setBulkDeleteOpen(false);
      setSelectedIds([]);
      resources.reload();
    } finally {
      setBusy(false);
    }
  };

  const columns = [
    {
      id: 'resource_name',
      header: 'Resource',
      primary: true,
      sortable: true,
      render: (r) => (
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <Boxes className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate text-[13px] font-medium text-ink-900">{r.resource_name}</p>
              {r.resource_type && <Badge tone="slate">{r.resource_type}</Badge>}
            </div>
            <p className="truncate font-mono text-xs text-slate-500" title={r.resource_arn}>
              {r.resource_arn}
            </p>
          </div>
        </div>
      ),
    },
    {
      /* Status sits directly after identity and is never hideable — it is the
         field that decides whether the rest of the row matters. */
      id: 'status',
      header: 'Status',
      sortable: true,
      hideable: false,
      sortValue: (r) => (r.is_active ? 0 : 1),
      render: (r) => <StatusBadge status={r.is_active ? 'ACTIVE' : 'DISABLED'} />,
    },
    {
      id: 'target_url',
      header: 'Target',
      sortable: true,
      render: (r) =>
        r.target_url ? (
          <a
            href={r.target_url}
            target="_blank"
            rel="noreferrer noopener"
            onClick={(e) => e.stopPropagation()}
            className="inline-flex max-w-[200px] items-center gap-1.5 text-[13px] text-brand-700 hover:text-brand-800"
            title={r.target_url}
          >
            <Link2 className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            <span className="truncate">{r.target_url.replace(/^https?:\/\//, '')}</span>
          </a>
        ) : (
          <span className="text-slate-400">—</span>
        ),
    },
    {
      /* Environment and team read as one provenance fact, so they share a cell
         instead of costing two columns of width. */
      id: 'placement',
      header: 'Env / Team',
      sortValue: (r) => r.metadata?.env || '',
      render: (r) => {
        const env = r.metadata?.env;
        const team = r.metadata?.team;
        if (!env && !team) return <span className="text-slate-400">—</span>;
        return (
          <div className="flex min-w-0 flex-col gap-0.5">
            {env && <Badge tone="slate">{env}</Badge>}
            {team && (
              <span className="flex items-center gap-1 truncate text-xs text-slate-500">
                <Users2 className="h-3 w-3 shrink-0 text-slate-400" />
                {team}
              </span>
            )}
          </div>
        );
      },
    },
    {
      id: 'created_at',
      header: 'Created',
      sortable: true,
      hideOnMobile: true,
      render: (r) => (
        <div className="min-w-0">
          <p className="text-[13px] text-ink-800">{formatDateTime(r.created_at)}</p>
          {r.created_by && <p className="truncate text-xs text-slate-500">by {r.created_by}</p>}
        </div>
      ),
    },
    {
      id: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
          <IconButton
            icon={Trash2}
            title="Delete resource"
            tone="danger"
            onClick={() => setDeleteTarget(r)}
          />
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Registered resources"
        description="Protected resources available to attribute-based policy evaluation."
        icon={<Boxes className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Access control' }, { label: 'Resources (ABAC)' }]}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={resources.reload} loading={resources.loading}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button onClick={() => setOpen(true)}>
              <Plus className="h-4 w-4" /> Register resource
            </Button>
          </div>
        }
      />

      <div className="space-y-4">
        {/* Summary tiles — refreshed with the table after every mutation.
            Clicking one filters the table to that slice. */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <StatCard
            label="Total resources"
            value={total}
            icon={Boxes}
            tone="brand"
            loading={resources.loading}
            hint="Registered in this tenant"
            onClick={() => setStatusFilter('all')}
          />
          <StatCard
            label="Active"
            value={activeCount}
            icon={CheckCircle2}
            tone="green"
            loading={resources.loading}
            hint="Evaluated in access decisions"
            onClick={() => setStatusFilter('active')}
          />
          <StatCard
            label="Inactive"
            value={inactiveCount}
            icon={Ban}
            tone="slate"
            loading={resources.loading}
            hint="Registered but not evaluated"
            onClick={() => setStatusFilter('inactive')}
          />
        </div>

        <Toolbar
          right={
            <div className="flex items-center gap-2">
              <SegmentedControl
                size="sm"
                ariaLabel="Filter by status"
                value={statusFilter}
                onChange={setStatusFilter}
                options={STATUS_FILTERS}
              />
              <span className="text-2xs text-slate-500 tabular">
                {filtered.length} of {total} resource{total === 1 ? '' : 's'}
              </span>
            </div>
          }
        >
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search name, type, ARN, URL, env or team…"
          />
        </Toolbar>

        {/* Load failure is surfaced explicitly — an empty table would otherwise
            read as "no resources" when the request never succeeded. */}
        {resources.error && !resources.loading ? (
          <EmptyState
            icon={Boxes}
            title="Resources could not be loaded"
            description={resources.error}
            action={<Button onClick={resources.reload}>Retry</Button>}
          />
        ) : resources.loading || data.length > 0 ? (
          <DataTable
            columns={columns}
            data={filtered}
            loading={resources.loading}
            columnsStorageKey="iam-abac-resources-columns"
            getRowId={(r) => r.resource_id}
            onRowClick={(r) => setDetailsOf(r)}
            selectable
            selectedIds={selectedIds}
            onSelectionChange={setSelectedIds}
            bulkActions={
              <Button variant="danger" size="xs" onClick={() => setBulkDeleteOpen(true)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete selected
              </Button>
            }
            empty={{
              icon: Boxes,
              title: search ? `No resources match “${search}”` : 'No resources in this view',
              description:
                statusFilter === 'all'
                  ? 'Adjust the search to see more results.'
                  : 'Try the All filter to see every registered resource.',
              action: (
                <Button
                  variant="secondary"
                  onClick={() => {
                    setSearch('');
                    setStatusFilter('all');
                  }}
                >
                  Clear filters
                </Button>
              ),
            }}
          />
        ) : (
          <EmptyState
            icon={Boxes}
            title="No resources registered"
            description="Register an application or dataset so policies can reference it by ARN."
            action={<Button onClick={() => setOpen(true)}>Register resource</Button>}
          />
        )}
      </div>

      {/* ── Full record ── */}
      <ResourceDetails
        resource={detailsOf}
        onClose={() => setDetailsOf(null)}
        onDelete={(r) => {
          setDetailsOf(null);
          setDeleteTarget(r);
        }}
        onCopy={copyValue}
      />

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Register resource"
        description="The ARN is the identifier policies match on — keep it stable."
        icon={Boxes}
        size="form"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={createResource} loading={saving}>
              Register resource
            </Button>
          </>
        }
      >
        <form onSubmit={createResource} className="space-y-4" noValidate>
          <Input
            label="Resource name"
            value={form.resource_name}
            onChange={set('resource_name')}
            error={errors.resource_name}
            required
            placeholder="user-management-api"
          />
          <Select
            label="Resource type"
            value={form.resource_type}
            onChange={set('resource_type')}
            required
          >
            {RESOURCE_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
            <option value="__other">Other…</option>
          </Select>
          {form.resource_type === '__other' && (
            <Input
              label="Custom type"
              value={form.resource_type_other}
              onChange={set('resource_type_other')}
              error={errors.resource_type_other}
              placeholder="queue"
              required
            />
          )}
          <Input
            label="ARN"
            value={form.resource_arn}
            onChange={set('resource_arn')}
            error={errors.resource_arn}
            placeholder="iam:app/my-app"
            required
            className="font-mono"
          />
          <Input
            label="Target URL"
            value={form.target_url}
            onChange={set('target_url')}
            error={errors.target_url}
            placeholder="https://api.example.com"
            required
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Environment"
              value={form.env}
              onChange={set('env')}
              placeholder="production"
              hint="metadata.env"
            />
            <Input
              label="Team"
              value={form.team}
              onChange={set('team')}
              placeholder="platform"
              hint="metadata.team"
            />
          </div>
          <label className="flex items-center gap-2 text-[13px] text-ink-800">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={set('is_active')}
              className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
            />
            Active — evaluate this resource in access decisions
          </label>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={removeResource}
        danger
        loading={busy}
        title="Delete resource"
        confirmLabel="Delete resource"
        message={`“${deleteTarget?.resource_name || 'This resource'}” will be removed from the registry.`}
        detail="Policies referencing this ARN remain in place but stop matching. This cannot be undone."
      />

      <ConfirmDialog
        open={bulkDeleteOpen}
        onClose={() => setBulkDeleteOpen(false)}
        onConfirm={removeSelected}
        danger
        loading={busy}
        title="Delete selected resources"
        confirmLabel={`Delete ${selectedResources.length} resource${selectedResources.length === 1 ? '' : 's'}`}
        message={`${selectedResources.length} resource${selectedResources.length === 1 ? '' : 's'} will be removed from the registry.`}
        detail="Policies referencing these ARNs remain in place but stop matching. This cannot be undone."
      />
    </div>
  );
}
