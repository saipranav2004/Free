import { useState, useEffect, useRef, useCallback, Component } from 'react';
import {
  ScrollText,
  Filter,
  RotateCcw,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Download,
  Clock,
  X,
  Pause,
  Play,
  AlertTriangle,
} from 'lucide-react';
import { useResource } from '../../hooks/useResource.js';
import { identityAuditApi } from '../../lib/api/identityAudit.js';
import { PageHeader } from '../../components/common/PageHeader.jsx';
import {
  Card,
  Toolbar,
  SearchInput,
  IconButton,
  Button,
  Input,
  Select,
  Badge,
  StatCard,
  EmptyState,
} from '../../components/ui/primitives.jsx';
import { DataTable } from '../../components/ui/DataTable.jsx';
import { Modal } from '../../components/ui/Modal.jsx';
import { Pagination } from '../../components/common/Pagination.jsx';
import { formatDateTime, shortId, classNames } from '../../utils/format.js';

// ──────────────────────────────────────────────────────────────────────────────
// Error Boundary — catches render-time crashes so a broken child component
// doesn't unmount the entire React tree (which causes a blank page).
// ──────────────────────────────────────────────────────────────────────────────
class AuditErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error('[AuditLogsPage] Render error:', error, info?.componentStack);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-rose-300 bg-rose-50 px-6 py-20 text-center">
          <AlertTriangle className="mb-4 h-10 w-10 text-rose-500" />
          <p className="text-sm font-semibold text-rose-800">Audit Logs failed to render</p>
          <p className="mt-1.5 max-w-md text-sm text-rose-600">
            {this.state.error?.message || 'An unexpected error occurred.'}
          </p>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            className="mt-4 rounded-lg bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700"
          >
            Try again
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Constants & helpers
// ──────────────────────────────────────────────────────────────────────────────
const LOG_TYPE_TONE = { authn: 'sky', authz: 'brand' };

const EMPTY_META = { authn: { actions: [] }, authz: { actions: [] } };
const EMPTY_PAGINATION = { page: 1, page_size: 25, total: 0, total_pages: 1 };
const EMPTY_SUMMARY = { authn: 0, authz: 0, success: 0, failure: 0, total: 0 };

// ──────────────────────────────────────────────────────────────────────────────
// StatusPill — enterprise status badge with icon indicator
// ──────────────────────────────────────────────────────────────────────────────
function StatusPill({ status }) {
  if (!status) return <span className="text-xs text-slate-400">—</span>;
  const s = String(status).toUpperCase();
  const ok = s === 'SUCCESS' || s === 'ALLOW';
  const Icon = ok ? CheckCircle2 : XCircle;
  return (
    <Badge tone={ok ? 'green' : 'red'}>
      <span className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {status}
      </span>
    </Badge>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// DecisionPill — ALLOW/DENY badge for authorization decisions
// ──────────────────────────────────────────────────────────────────────────────
function DecisionPill({ decision }) {
  if (!decision) return <span className="text-xs text-slate-400">—</span>;
  const d = String(decision).toUpperCase();
  const allow = d === 'ALLOW';
  return (
    <Badge tone={allow ? 'green' : 'red'}>
      <span className="flex items-center gap-1">
        {allow ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
        {decision}
      </span>
    </Badge>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// FilterChip — active filter indicator with clear button
// ──────────────────────────────────────────────────────────────────────────────
function FilterChip({ label, value, onClear }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-2.5 py-1 text-xs font-medium text-brand-700 ring-1 ring-inset ring-brand-200">
      <span className="text-brand-500">{label}:</span>
      <span className="font-semibold">{value}</span>
      <button
        onClick={onClear}
        className="ml-0.5 rounded-full p-0.5 hover:bg-brand-100 transition-colors"
        aria-label={`Clear ${label} filter`}
      >
        <X className="h-3 w-3" />
      </button>
    </span>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Field — compact key/value display for detail modal
// ──────────────────────────────────────────────────────────────────────────────
function Field({ label, value, mono }) {
  return (
    <div>
      <p className="text-xs font-medium text-slate-500 mb-0.5">{label}</p>
      <p className={classNames('text-ink-900', mono && 'break-all font-mono text-xs')}>
        {value || '—'}
      </p>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// AuditLogsInner — the actual audit logs page content.
// Exported so the PAM page can embed it as a tab without duplicating code.
// ──────────────────────────────────────────────────────────────────────────────
export function AuditLogsInner() {
  // ── Filter state ──
  const [filters, setFilters] = useState({
    type: 'all', action: '', status: '', username: '', email: '', search: '', from: '', to: '',
  });
  const [applied, setApplied] = useState({
    type: 'all', action: '', status: '', username: '', email: '', search: '', from: '', to: '',
    page: 1, page_size: 25,
  });
  const [selected, setSelected] = useState(null);
  // Progressive disclosure: three filters are always visible, the rest fold away.
  const [showAdvanced, setShowAdvanced] = useState(false);

  // ── Auto-refresh state ──
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const autoRefreshRef = useRef(null);
  const logsRef = useRef(null);
  const metaResRef = useRef(null);

  // ── Filter helpers ──
  const updateFilter = useCallback((key, value) => {
    setFilters((f) => ({ ...f, [key]: value }));
    setApplied((a) => ({ ...a, [key]: value, page: 1 }));
  }, []);

  const applySearch = useCallback(() => {
    setApplied((a) => ({
      ...a,
      username: filters.username,
      email: filters.email,
      search: filters.search,
      page: 1,
    }));
  }, [filters.username, filters.email, filters.search]);

  const reset = useCallback(() => {
    const empty = { type: 'all', action: '', status: '', username: '', email: '', search: '', from: '', to: '' };
    setFilters(empty);
    setApplied({ ...empty, page: 1, page_size: 25 });
  }, []);

  const clearFilter = useCallback((key) => {
    const defaultValue = key === 'type' ? 'all' : '';
    setFilters((f) => ({ ...f, [key]: defaultValue }));
    setApplied((a) => ({ ...a, [key]: defaultValue, page: 1 }));
  }, []);

  // ── Fetch distinct actions for the dropdown ──
  const metaRes = useResource(() => identityAuditApi.meta(), []);
  const meta = metaRes?.data || EMPTY_META;
  const actionOptions = applied.type === 'authn'
    ? (meta?.authn?.actions || [])
    : applied.type === 'authz'
    ? (meta?.authz?.actions || [])
    : [...new Set([...(meta?.authn?.actions || []), ...(meta?.authz?.actions || [])])].sort();

  // ── Fetch audit logs ──
  const fetcher = useCallback(() => identityAuditApi.list({
    type: applied.type !== 'all' ? applied.type : undefined,
    action: applied.action || undefined,
    status: applied.status || undefined,
    username: applied.username || undefined,
    email: applied.email || undefined,
    search: applied.search || undefined,
    from: applied.from || undefined,
    to: applied.to || undefined,
    page: applied.page,
    page_size: applied.page_size,
  }), [applied.type, applied.action, applied.status, applied.username, applied.email,
       applied.search, applied.from, applied.to, applied.page, applied.page_size]);

  const logs = useResource(fetcher, [
    applied.type, applied.action, applied.status, applied.username, applied.email,
    applied.search, applied.from, applied.to, applied.page, applied.page_size,
  ]);

  // ── Keep refs in sync for auto-refresh (avoids stale closures) ──
  logsRef.current = logs;
  metaResRef.current = metaRes;

  // ── Auto-refresh effect (30-second interval) ──
  useEffect(() => {
    if (!autoRefresh) return;
    autoRefreshRef.current = setInterval(() => {
      logsRef.current?.reload?.();
      metaResRef.current?.reload?.();
      setLastUpdated(new Date());
    }, 30_000);
    return () => {
      if (autoRefreshRef.current) clearInterval(autoRefreshRef.current);
    };
  }, [autoRefresh]);

  // ── Tolerate multiple API response shapes ──
  const rawLogs = logs?.data;
  const items = Array.isArray(rawLogs)
    ? rawLogs
    : rawLogs?.items || rawLogs?.logs || rawLogs?.data || [];
  const pagination = logs?.data?.pagination || EMPTY_PAGINATION;
  const summary = logs?.data?.summary || EMPTY_SUMMARY;

  // ── Export CSV ──
  const exportCsv = useCallback(() => {
    if (!items?.length) return;
    const headers = ['Time', 'Type', 'User', 'Email', 'Action', 'Decision', 'Resource', 'Status', 'IP'];
    const rows = items.map((r) => [
      r?.created_at || '', r?.log_type || '', r?.username || r?.user_id || '', r?.email || '',
      r?.action || r?.event_type || '', r?.decision || '', r?.resource || r?.target_id || '',
      r?.status || '', r?.ip_address || '',
    ]);
    const csv = [headers, ...rows]
      .map((row) => row.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `audit-logs-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }, [items]);

  // ── Active filter chips ──
  const activeFilters = [];
  if (applied.type && applied.type !== 'all') activeFilters.push({ key: 'type', label: 'Type', value: applied.type.toUpperCase() });
  if (applied.action) activeFilters.push({ key: 'action', label: 'Action', value: applied.action });
  if (applied.status) activeFilters.push({ key: 'status', label: 'Status', value: applied.status });
  if (applied.username) activeFilters.push({ key: 'username', label: 'User', value: applied.username });
  if (applied.email) activeFilters.push({ key: 'email', label: 'Email', value: applied.email });
  if (applied.search) activeFilters.push({ key: 'search', label: 'Search', value: applied.search });
  if (applied.from) activeFilters.push({ key: 'from', label: 'From', value: applied.from });
  if (applied.to) activeFilters.push({ key: 'to', label: 'To', value: applied.to });

  // ── Table columns ──
  const columns = [
    {
      id: 'created_at',
      header: 'Time',
      render: (r) => <span className="whitespace-nowrap text-slate-600">{formatDateTime(r?.created_at)}</span>,
    },
    {
      id: 'log_type',
      header: 'Type',
      render: (r) => <Badge tone={LOG_TYPE_TONE[r?.log_type] || 'slate'}>{(r?.log_type || '').toUpperCase()}</Badge>,
    },
    {
      id: 'actor',
      header: 'User',
      render: (r) => (
        <div>
          <p className="font-medium text-ink-900">{r?.username || shortId(r?.user_id)}</p>
          {r?.email && <p className="text-xs text-slate-400">{r.email}</p>}
        </div>
      ),
    },
    {
      id: 'action',
      header: 'Action',
      render: (r) => <span className="font-mono text-sm text-ink-800">{r?.action || r?.event_type || '—'}</span>,
    },
    {
      id: 'decision',
      header: 'Decision',
      render: (r) => <DecisionPill decision={r?.decision} />,
    },
    {
      id: 'resource',
      header: 'Resource',
      render: (r) => (
        <span className="max-w-[200px] truncate text-sm text-slate-600" title={r?.resource || r?.target_id}>
          {r?.resource || r?.target_id || '—'}
        </span>
      ),
    },
    {
      id: 'status',
      header: 'Status',
      render: (r) => <StatusPill status={r?.status} />,
    },
    {
      id: 'ip',
      header: 'IP',
      render: (r) => <span className="text-xs text-slate-500">{r?.ip_address || '—'}</span>,
    },
  ];

  // ── Detail modal JSON ──
  let detailJson = null;
  if (selected?.details) {
    try {
      const parsed = typeof selected.details === 'string' ? JSON.parse(selected.details) : selected.details;
      detailJson = JSON.stringify(parsed, null, 2);
    } catch {
      detailJson = String(selected.details);
    }
  }

  // ── Render ──
  return (
    <div className="space-y-6">
      {/* Page header with actions */}
      <PageHeader
        title="Audit Logs"
        description="Authentication & authorization activity across the platform."
        icon={<ShieldAlert className="h-4.5 w-4.5" />}
        breadcrumbs={[{ label: 'Identity' }, { label: 'Audit logs' }]}
        actions={
          <>
            <Button
              variant={autoRefresh ? 'primary' : 'outline'}
              onClick={() => setAutoRefresh((v) => !v)}
            >
              {autoRefresh ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              {autoRefresh ? 'Auto-refresh on' : 'Auto-refresh'}
            </Button>
            <Button variant="outline" onClick={exportCsv} disabled={!items?.length}>
              <Download className="h-4 w-4" /> Export CSV
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                logs?.reload?.();
                metaRes?.reload?.();
                setLastUpdated(new Date());
              }}
            >
              <RotateCcw className="h-4 w-4" /> Refresh
            </Button>
          </>
        }
      />

      {/* Last updated timestamp */}
      {lastUpdated && (
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <Clock className="h-3 w-3" /> Last updated {lastUpdated.toLocaleTimeString()}
          {autoRefresh && <span className="text-brand-500">· refreshing every 30s</span>}
        </div>
      )}

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard label="Total" value={summary?.total ?? 0} icon={ScrollText} tone="brand" />
        <StatCard label="AuthN" value={summary?.authn ?? 0} icon={ShieldAlert} tone="slate" />
        <StatCard label="AuthZ" value={summary?.authz ?? 0} icon={ScrollText} tone="slate" />
        <StatCard label="Failures" value={summary?.failure ?? 0} icon={XCircle} tone="red" />
      </div>

      {/* Filter bar — primary controls always visible, the long tail folds away.
          Eight simultaneous filter fields read as a data-entry form, not a console. */}
      <Toolbar
        right={
          <>
            <Button variant="secondary" size="sm" onClick={() => setShowAdvanced((o) => !o)}>
              <Filter className="h-3.5 w-3.5" />
              {showAdvanced ? 'Fewer filters' : 'More filters'}
            </Button>
            <Button size="sm" onClick={applySearch}>Apply</Button>
            {activeFilters.length > 0 && (
              <Button variant="ghost" size="sm" onClick={reset}>Reset</Button>
            )}
          </>
        }
      >
        <SearchInput
          value={filters.search}
          onChange={(v) => setFilters((f) => ({ ...f, search: v }))}
          onSubmit={applySearch}
          placeholder="Search action, resource or details…"
          width="w-full sm:w-72"
        />
        <Select
          value={filters.type}
          onChange={(e) => updateFilter('type', e.target.value)}
          className="w-full sm:w-32"
          aria-label="Log type"
        >
          <option value="all">All types</option>
          <option value="authn">AuthN</option>
          <option value="authz">AuthZ</option>
        </Select>
        <Select
          value={filters.status}
          onChange={(e) => updateFilter('status', e.target.value)}
          className="w-full sm:w-36"
          aria-label="Status"
        >
          <option value="">Any status</option>
          <option value="SUCCESS">Success</option>
          <option value="FAILURE">Failure</option>
        </Select>
      </Toolbar>

      {showAdvanced && (
        <Card className="p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <Select label="Action" value={filters.action} onChange={(e) => updateFilter('action', e.target.value)}>
              <option value="">All actions</option>
              {(actionOptions || []).map((a) => (
                <option key={a} value={a}>{a}</option>
              ))}
            </Select>
            <Input
              label="Username"
              placeholder="username fragment"
              value={filters.username}
              onChange={(e) => setFilters((f) => ({ ...f, username: e.target.value }))}
              onKeyDown={(e) => e.key === 'Enter' && applySearch()}
            />
            <Input
              label="Email"
              placeholder="email fragment"
              value={filters.email}
              onChange={(e) => setFilters((f) => ({ ...f, email: e.target.value }))}
              onKeyDown={(e) => e.key === 'Enter' && applySearch()}
            />
            <Input label="From" type="date" value={filters.from} onChange={(e) => updateFilter('from', e.target.value)} />
            <Input label="To" type="date" value={filters.to} onChange={(e) => updateFilter('to', e.target.value)} />
          </div>
        </Card>
      )}

      {/* Active filter chips */}
      {activeFilters.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-500">Active filters:</span>
          {activeFilters.map((f) => (
            <FilterChip key={f.key} label={f.label} value={f.value} onClear={() => clearFilter(f.key)} />
          ))}
          <button
            onClick={reset}
            className="text-xs font-medium text-slate-400 hover:text-slate-600 transition-colors"
          >
            Clear all
          </button>
        </div>
      )}

      {/* Data table or error */}
      {logs?.error ? (
        <EmptyState
          icon={XCircle}
          title="Could not load audit logs"
          description={String(logs.error)}
        />
      ) : (
        <DataTable
          columns={columns}
          data={items || []}
          loading={logs?.loading || false}
          columnsStorageKey="iam-audit-columns"
          onRowClick={(r) => setSelected(r)}
          empty={{
            title: 'No audit events found',
            description: 'Try widening the filters or adjusting the date range.',
          }}
        />
      )}

      {/* Pagination */}
      <Pagination
        page={pagination?.page || 1}
        perPage={pagination?.page_size || 25}
        total={pagination?.total || 0}
        onPageChange={(p) => setApplied((a) => ({ ...a, page: p }))}
      />

      {/* Detail modal */}
      <Modal
        open={!!selected}
        onClose={() => setSelected(null)}
        size="lg"
        title={
          selected ? (
            <span className="flex items-center gap-2">
              <Badge tone={LOG_TYPE_TONE[selected?.log_type] || 'slate'}>
                {(selected?.log_type || '').toUpperCase()}
              </Badge>
              <span className="font-mono text-sm">{selected?.action || selected?.event_type}</span>
              <StatusPill status={selected?.status} />
            </span>
          ) : 'Audit event'
        }
        description={selected ? formatDateTime(selected?.created_at) : undefined}
      >
        {selected && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <Field label="User" value={selected?.username || '—'} />
              <Field label="Email" value={selected?.email || '—'} />
              <Field label="User ID" value={shortId(selected?.user_id)} mono />
              <Field label="Resource" value={selected?.resource || '—'} />
              <Field label="Account" value={shortId(selected?.account_id)} mono />
              <Field label="IP address" value={selected?.ip_address || '—'} mono />
              <Field label="Status" value={selected?.status || '—'} />
            </div>
            {selected?.user_agent && (
              <div>
                <p className="text-xs font-medium text-slate-500 mb-1">User agent</p>
                <p className="break-all rounded-lg bg-slate-50 p-2 text-xs text-slate-600">
                  {selected.user_agent}
                </p>
              </div>
            )}
            {selected?.decision && (
              <div>
                <p className="text-xs font-medium text-slate-500 mb-1">Decision</p>
                <DecisionPill decision={selected.decision} />
              </div>
            )}
            <div>
              <p className="text-xs font-medium text-slate-500 mb-1">Details</p>
              {detailJson ? (
                <pre className="max-h-72 overflow-auto rounded-lg bg-slate-900 p-3 text-xs leading-relaxed text-slate-100">
                  {detailJson}
                </pre>
              ) : (
                <p className="text-sm text-slate-400">No additional details captured.</p>
              )}
            </div>
            <p className="text-[11px] text-slate-300">Press Esc to close</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Default export — wraps inner component with ErrorBoundary so a crash in
// any child won't unmount the entire React tree (sidebar, topbar, etc.).
// ──────────────────────────────────────────────────────────────────────────────
export default function AuditLogsPage() {
  return (
    <AuditErrorBoundary>
      <AuditLogsInner />
    </AuditErrorBoundary>
  );
}
