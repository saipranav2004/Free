import { useAuth } from '../../context/AuthContext.jsx';
import { isAdmin } from '../../utils/permissions.js';
import { Spinner, EmptyState, Button } from '../ui/primitives.jsx';
import { ShieldAlert } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

/**
 * RequireAdmin — administrator-only route gate.
 *
 * Identity-provider federation changes how an entire tenant authenticates, so
 * the console exposes it to administrators only (`account_type === 'admin'`,
 * plus the equivalent shapes `isAdmin()` recognises: `role`, `roles[]`,
 * `is_admin`). Navigation entries for these areas are hidden as well — see
 * Topbar (product tabs) and Sidebar (contextual section) — this component is
 * the second line of defence for a bookmarked or hand-typed URL.
 *
 * Server-side authorisation remains the real authority; this only controls what
 * the UI offers, and it deliberately explains the outcome instead of bouncing
 * the operator to the dashboard with no feedback. No internal detail is shown.
 */
export function RequireAdmin({ children, area = 'This area' }) {
  const { user, bootstrapping } = useAuth();
  const navigate = useNavigate();

  // The profile is still re-hydrating; deciding now would flash a false denial.
  if (bootstrapping || !user) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-7 w-7" />
      </div>
    );
  }

  if (!isAdmin(user)) {
    return (
      <EmptyState
        icon={ShieldAlert}
        title="Administrator access required"
        description={`${area} is available to tenant administrators only. Ask an administrator if you need access to identity-provider federation.`}
        action={<Button onClick={() => navigate('/')}>Back to dashboard</Button>}
      />
    );
  }

  return children;
}
