/**
 * PamFilters — investigation filter bar for the audit log.
 *
 * Design decisions:
 *  · Decision (all / denied / success) is a segmented quick filter, not a
 *    dropdown: it is the filter analysts touch on every single visit.
 *  · Text search is Enter-to-apply so we never hammer the API per keystroke.
 *  · Advanced constraints (log type, date range) sit in one row on desktop and
 *    collapse behind a "More filters" disclosure on small screens.
 *  · Applied constraints are echoed back as removable chips — the filter state
 *    is always legible, and one click clears everything.
 */
import { useState, useCallback, useEffect } from 'react';
import { Filter, X, RotateCcw, XCircle, CheckCircle2, ChevronDown, SlidersHorizontal } from 'lucide-react';
import { Button, Input, Select, SearchInput, SegmentedControl } from '../ui/primitives.jsx';
import { classNames } from '../../utils/format.js';

function FilterChip({ label, value, onClear }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1 rounded-md bg-slate-100 py-0.5 pl-2 pr-1 text-2xs font-medium text-ink-700">
      <span className="text-slate-500">{label}</span>
      <span className="truncate font-semibold">{value}</span>
      <button
        type="button"
        onClick={onClear}
        className="rounded p-0.5 text-slate-400 transition-colors hover:bg-slate-200 hover:text-ink-800"
        aria-label={`Clear ${label} filter`}
      >
        <X className="h-3 w-3" />
      </button>
    </span>
  );
}

export function PamFilters({ filters, onFilterChange, onSearch, onReset, counts = {} }) {
  const [searchInput, setSearchInput] = useState(filters.search || '');
  const [advancedOpen, setAdvancedOpen] = useState(false);

  // Keep the local field in step when the parent resets filters.
  useEffect(() => {
    setSearchInput(filters.search || '');
  }, [filters.search]);

  const applySearch = useCallback(() => onSearch?.(searchInput), [searchInput, onSearch]);

  const active = [];
  if (filters.severity && filters.severity !== 'all') {
    active.push({ key: 'severity', label: 'Decision', value: filters.severity });
  }
  if (filters.type && filters.type !== 'all') {
    active.push({ key: 'type', label: 'Type', value: String(filters.type).toUpperCase() });
  }
  if (filters.from) active.push({ key: 'from', label: 'From', value: filters.from });
  if (filters.to) active.push({ key: 'to', label: 'To', value: filters.to });
  if (filters.search) active.push({ key: 'search', label: 'Search', value: filters.search });

  const clearFilter = useCallback(
    (key) => {
      const fallback = key === 'type' || key === 'severity' ? 'all' : '';
      onFilterChange?.(key, fallback);
      if (key === 'search') {
        setSearchInput('');
        onSearch?.('');
      }
    },
    [onFilterChange, onSearch]
  );

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <SegmentedControl
          ariaLabel="Decision"
          value={filters.severity || 'all'}
          onChange={(v) => onFilterChange?.('severity', v)}
          options={[
            { value: 'all', label: 'All' },
            { value: 'denied', label: 'Denied', icon: XCircle, count: counts.denied },
            { value: 'success', label: 'Success', icon: CheckCircle2, count: counts.success },
          ]}
        />

        <SearchInput
          value={searchInput}
          onChange={setSearchInput}
          onSubmit={applySearch}
          placeholder="Search principal, action or resource…"
          width="w-full sm:w-72"
        />

        <Button variant="secondary" size="sm" onClick={applySearch}>
          <Filter className="h-3.5 w-3.5" />
          Apply
        </Button>

        <button
          type="button"
          onClick={() => setAdvancedOpen((o) => !o)}
          className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-[12.5px] font-medium text-slate-600 ring-1 ring-inset ring-slate-300 transition-colors hover:bg-slate-50 lg:hidden"
        >
          <SlidersHorizontal className="h-3.5 w-3.5" />
          More filters
          <ChevronDown className={classNames('h-3.5 w-3.5 transition-transform', advancedOpen && 'rotate-180')} />
        </button>

        {active.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto"
            onClick={() => {
              onReset?.();
              setSearchInput('');
            }}
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset
          </Button>
        )}
      </div>

      <div
        className={classNames(
          'grid grid-cols-1 gap-3 sm:grid-cols-3 lg:flex lg:items-end lg:gap-3',
          advancedOpen ? 'grid' : 'hidden lg:flex'
        )}
      >
        <div className="lg:w-36">
          <Select
            label="Log type"
            value={filters.type || 'all'}
            onChange={(e) => onFilterChange?.('type', e.target.value)}
          >
            <option value="all">All types</option>
            <option value="authn">AuthN</option>
            <option value="authz">AuthZ</option>
          </Select>
        </div>
        <div className="lg:w-40">
          <Input
            label="From"
            type="date"
            value={filters.from || ''}
            onChange={(e) => onFilterChange?.('from', e.target.value)}
          />
        </div>
        <div className="lg:w-40">
          <Input
            label="To"
            type="date"
            value={filters.to || ''}
            onChange={(e) => onFilterChange?.('to', e.target.value)}
          />
        </div>
      </div>

      {active.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 border-t border-line-soft pt-2.5">
          <span className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-400">Applied</span>
          {active.map((f) => (
            <FilterChip key={f.key} label={f.label} value={f.value} onClear={() => clearFilter(f.key)} />
          ))}
        </div>
      )}
    </div>
  );
}
