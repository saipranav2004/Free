/**
 * primitives.jsx — the design system for the IAM / PAM console.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * DESIGN LANGUAGE
 * ═══════════════════════════════════════════════════════════════════════════
 * Structure comes from 1px hairline borders, not shadows. Elevation is
 * reserved for things that genuinely float (popovers, dialogs, toasts).
 * Colour is rationed: brand blue for primary actions and active state,
 * emerald / amber / rose only for status semantics, slate for everything else.
 *
 * Control geometry is fixed so that any two controls placed side by side line
 * up perfectly: xs 28px · sm 32px · md 36px · lg 40px, 8px radius.
 * Surfaces use a 12px radius.
 *
 * Every export here is API-compatible with the previous version of this file;
 * new components are additive.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { forwardRef, useState, useRef, useEffect, useCallback, useMemo, useId } from 'react';

import {
  Loader2, Search, ChevronDown, Check, X,
  Info, AlertTriangle, CheckCircle2, XCircle,
} from 'lucide-react';

import { classNames } from '../../utils/format.js';


/* ═══════════════════════════════════════════════════════════════════════════
   Button
   ═══════════════════════════════════════════════════════════════════════════ */

const BUTTON_VARIANTS = {
  primary:
    'bg-brand-600 text-white shadow-[0_1px_1px_rgba(13,20,36,0.10)] hover:bg-brand-700 active:bg-brand-800',
  secondary:
    'bg-white text-ink-700 ring-1 ring-inset ring-slate-300 shadow-[0_1px_1px_rgba(13,20,36,0.04)] hover:bg-slate-50 hover:ring-slate-400 active:bg-slate-100',
  outline:
    'bg-white text-brand-700 ring-1 ring-inset ring-brand-300 hover:bg-brand-50 active:bg-brand-100',
  subtle:
    'bg-slate-100 text-ink-700 hover:bg-slate-200/80 active:bg-slate-200',
  ghost:
    'bg-transparent text-slate-600 hover:bg-slate-100 hover:text-ink-800 active:bg-slate-200/70',
  danger:
    'bg-rose-600 text-white shadow-[0_1px_1px_rgba(13,20,36,0.10)] hover:bg-rose-700 active:bg-rose-800',
  'danger-ghost':
    'bg-transparent text-rose-600 hover:bg-rose-50 active:bg-rose-100',
  link: 'bg-transparent text-brand-700 hover:text-brand-800 hover:underline underline-offset-2 px-0',
};

const BUTTON_SIZES = {
  xs: 'h-7 gap-1 px-2 text-2xs',
  sm: 'h-8 gap-1.5 px-2.5 text-[12.5px]',
  md: 'h-9 gap-1.5 px-3.5 text-[13px]',
  lg: 'h-10 gap-2 px-4 text-sm',
};

const ICON_BUTTON_SIZES = {
  xs: 'h-7 w-7',
  sm: 'h-8 w-8',
  md: 'h-9 w-9',
  lg: 'h-10 w-10',
};

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled,
  className,
  type = 'button',
  block = false,
  ...props
}) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={classNames(
        'inline-flex shrink-0 select-none items-center justify-center whitespace-nowrap rounded-lg font-medium transition-colors duration-100',
        'focus-visible:outline-none',
        'disabled:pointer-events-none disabled:opacity-50',
        BUTTON_VARIANTS[variant] || BUTTON_VARIANTS.primary,
        BUTTON_SIZES[size] || BUTTON_SIZES.md,
        block && 'w-full',
        className
      )}
      {...props}
    >
      {loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
      {children}
    </button>
  );
}

/** Square icon-only button. Always pass a `title` (used as the tooltip + a11y name). */
export function IconButton({
  icon: Icon,
  title,
  variant = 'ghost',
  size = 'sm',
  tone,
  className,
  loading = false,
  disabled,
  ...props
}) {
  const tones = {
    danger: 'hover:bg-rose-50 hover:text-rose-600',
    success: 'hover:bg-emerald-50 hover:text-emerald-600',
    warning: 'hover:bg-amber-50 hover:text-amber-600',
    brand: 'hover:bg-brand-50 hover:text-brand-700',
  };
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      disabled={disabled || loading}
      className={classNames(
        'inline-flex shrink-0 items-center justify-center rounded-lg transition-colors duration-100',
        'focus-visible:outline-none',
        'disabled:pointer-events-none disabled:opacity-40',
        variant === 'ghost'
          ? 'text-slate-400 hover:bg-slate-100 hover:text-ink-700'
          : BUTTON_VARIANTS[variant] || BUTTON_VARIANTS.secondary,
        tone && tones[tone],
        ICON_BUTTON_SIZES[size] || ICON_BUTTON_SIZES.sm,
        className
      )}
      {...props}
    >
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        Icon && <Icon className={size === 'xs' ? 'h-3.5 w-3.5' : 'h-4 w-4'} />
      )}
    </button>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   Surfaces
   ═══════════════════════════════════════════════════════════════════════════ */

export function Card({ className, children, ...props }) {
  return (
    <div className={classNames('card', className)} {...props}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, action, icon: Icon, className }) {
  return (
    <div
      className={classNames(
        'flex items-start justify-between gap-4 border-b border-line-soft px-4 py-3 sm:px-5',
        className
      )}
    >
      <div className="flex min-w-0 items-center gap-2.5">
        {Icon && (
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <Icon className="h-3.5 w-3.5" />
          </span>
        )}
        <div className="min-w-0">
          <h3 className="truncate text-[13.5px] font-semibold text-ink-900">{title}</h3>
          {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="flex shrink-0 items-center gap-2">{action}</div>}
    </div>
  );
}

/**
 * Panel — a card with a standard header/body rhythm. The workhorse container
 * for dashboard widgets and page sections.
 */
export function Panel({
  title,
  subtitle,
  icon: Icon,
  action,
  footer,
  children,
  className,
  bodyClassName,
  flush = false,
}) {
  return (
    <section className={classNames('card flex flex-col overflow-hidden', className)}>
      {(title || action) && (
        <header className="flex items-start justify-between gap-3 border-b border-line-soft px-4 py-3 sm:px-5">
          <div className="flex min-w-0 items-center gap-2.5">
            {Icon && (
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                <Icon className="h-3.5 w-3.5" />
              </span>
            )}
            <div className="min-w-0">
              {title && (
                <h3 className="truncate text-[13.5px] font-semibold text-ink-900">{title}</h3>
              )}
              {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
            </div>
          </div>
          {action && <div className="flex shrink-0 items-center gap-1.5">{action}</div>}
        </header>
      )}
      <div
        className={classNames(
          'flex-1',
          !flush && 'px-4 py-4 sm:px-5',
          bodyClassName
        )}
      >
        {children}
      </div>
      {footer && (
        <footer className="border-t border-line-soft bg-slate-50/60 px-4 py-2.5 sm:px-5">
          {footer}
        </footer>
      )}
    </section>
  );
}

/**
 * Toolbar — the standard filter/action strip that sits above a table or list.
 * Left side: search + filters. Right side: counts + actions.
 */
export function Toolbar({ children, right, className }) {
  return (
    <div
      className={classNames(
        'flex flex-col gap-2.5 rounded-xl border border-line bg-white px-3 py-2.5 shadow-card sm:flex-row sm:items-center sm:justify-between sm:gap-3',
        className
      )}
    >
      <div className="flex flex-1 flex-wrap items-center gap-2">{children}</div>
      {right && <div className="flex shrink-0 flex-wrap items-center gap-2">{right}</div>}
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   Form controls
   ═══════════════════════════════════════════════════════════════════════════ */

/** Shared label / hint / error scaffold so every field aligns identically. */
export function Field({ label, htmlFor, hint, error, required, children, className }) {
  return (
    <div className={classNames('w-full', className)}>
      {label && (
        <label htmlFor={htmlFor} className="label-base">
          {label}
          {required && <span className="ml-0.5 text-rose-500">*</span>}
        </label>
      )}
      {children}
      {hint && !error && <p className="mt-1.5 text-xs leading-snug text-slate-500">{hint}</p>}
      {error && (
        <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-rose-600">
          <AlertTriangle className="h-3 w-3 shrink-0" />
          {error}
        </p>
      )}
    </div>
  );
}

export const Input = forwardRef(function Input(
  { label, error, hint, className, id, icon: Icon, suffix, required, ...props },
  ref
) {
  const inputId = id || props.name;
  return (
    <Field label={label} htmlFor={inputId} hint={hint} error={error} required={required}>
      <div className="relative">
        {Icon && (
          <Icon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        )}
        <input
          id={inputId}
          ref={ref}
          aria-invalid={error ? true : undefined}
          className={classNames(
            'input-base',
            Icon && 'pl-9',
            suffix && 'pr-9',
            error && 'border-rose-400 hover:border-rose-500 focus:border-rose-500',
            className
          )}
          {...props}
        />
        {suffix && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">
            {suffix}
          </span>
        )}
      </div>
    </Field>
  );
});

export const Textarea = forwardRef(function Textarea(
  { label, error, hint, className, id, rows = 4, required, ...props },
  ref
) {
  const inputId = id || props.name;
  return (
    <Field label={label} htmlFor={inputId} hint={hint} error={error} required={required}>
      <textarea
        id={inputId}
        ref={ref}
        rows={rows}
        aria-invalid={error ? true : undefined}
        className={classNames(
          'input-base',
          error && 'border-rose-400 focus:border-rose-500',
          className
        )}
        {...props}
      />
    </Field>
  );
});

export const Select = forwardRef(function Select(
  { label, error, hint, className, id, children, required, ...props },
  ref
) {
  const inputId = id || props.name;
  return (
    <Field label={label} htmlFor={inputId} hint={hint} error={error} required={required}>
      <select
        id={inputId}
        ref={ref}
        aria-invalid={error ? true : undefined}
        className={classNames(
          'input-base',
          error && 'border-rose-400 focus:border-rose-500',
          className
        )}
        {...props}
      >
        {children}
      </select>
    </Field>
  );
});

/**
 * SearchInput — the canonical search control. Debounce-free (controlled), with
 * a clear affordance and optional Enter-to-apply.
 */
export const SearchInput = forwardRef(function SearchInput(
  { value, onChange, onSubmit, placeholder = 'Search…', className, width = 'w-full sm:w-72', ...props },
  ref
) {
  return (
    <div className={classNames('relative', width, className)}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input
        ref={ref}
        type="search"
        role="searchbox"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange?.(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') onSubmit?.(value);
          if (e.key === 'Escape' && value) {
            e.stopPropagation();
            onChange?.('');
          }
        }}
        className="input-base pl-9 pr-8 [&::-webkit-search-cancel-button]:hidden"
        {...props}
      />
      {value ? (
        <button
          type="button"
          onClick={() => onChange?.('')}
          title="Clear search"
          aria-label="Clear search"
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      ) : null}
    </div>
  );
});

/** Switch — 36×20 track, matches the 8px control language. */
export function Switch({ checked, onChange, label, disabled, id }) {
  return (
    <button
      type="button"
      role="switch"
      id={id}
      aria-checked={!!checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange?.(!checked)}
      className={classNames(
        'relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors duration-150',
        'focus-visible:outline-none',
        checked ? 'bg-brand-600' : 'bg-slate-300 hover:bg-slate-400',
        disabled && 'cursor-not-allowed opacity-50'
      )}
    >
      <span
        className={classNames(
          'inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform duration-150',
          checked ? 'translate-x-[1.125rem]' : 'translate-x-0.5'
        )}
      />
      {label && <span className="sr-only">{label}</span>}
    </button>
  );
}

/**
 * SegmentedControl — 2–4 mutually exclusive options in one compact row.
 * Used for density, time range, and severity switches.
 */
export function SegmentedControl({ options = [], value, onChange, size = 'md', className, ariaLabel }) {
  const pad = size === 'sm' ? 'h-7 px-2 text-2xs' : 'h-8 px-2.5 text-[12.5px]';
  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className={classNames(
        'inline-flex items-center gap-0.5 rounded-lg border border-line bg-slate-100/80 p-0.5',
        className
      )}
    >
      {options.map((opt) => {
        const active = opt.value === value;
        const Icon = opt.icon;
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={active}
            title={opt.title || opt.label}
            onClick={() => onChange?.(opt.value)}
            className={classNames(
              'inline-flex items-center gap-1.5 rounded-[6px] font-medium transition-colors duration-100',
              'focus-visible:outline-none',
              pad,
              active
                ? 'bg-white text-ink-900 shadow-[0_1px_2px_rgba(13,20,36,0.08)]'
                : 'text-slate-500 hover:text-ink-800'
            )}
          >
            {Icon && <Icon className="h-3.5 w-3.5" />}
            {opt.label}
            {opt.count != null && (
              <span
                className={classNames(
                  'rounded-full px-1.5 py-px text-3xs font-semibold tabular',
                  active ? 'bg-slate-100 text-slate-600' : 'bg-white/70 text-slate-500'
                )}
              >
                {opt.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   Status & data display
   ═══════════════════════════════════════════════════════════════════════════ */

const BADGE_TONES = {
  slate: 'bg-slate-50 text-slate-700 ring-slate-300',
  brand: 'bg-brand-50 text-brand-700 ring-brand-200',
  green: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  amber: 'bg-amber-50 text-amber-700 ring-amber-200',
  red: 'bg-rose-50 text-rose-700 ring-rose-200',
  sky: 'bg-sky-50 text-sky-700 ring-sky-200',
  outline: 'bg-white text-slate-600 ring-slate-300',
};

const DOT_TONES = {
  slate: 'bg-slate-400',
  brand: 'bg-brand-500',
  green: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-rose-500',
  sky: 'bg-sky-500',
  outline: 'bg-slate-400',
};

export function Badge({ children, tone = 'slate', className, dot = false, mono = false }) {
  return (
    <span
      className={classNames(
        'inline-flex max-w-full items-center gap-1.5 rounded-md px-1.5 py-0.5 text-2xs font-medium ring-1 ring-inset',
        mono && 'font-mono tracking-tight',
        BADGE_TONES[tone] || BADGE_TONES.slate,
        className
      )}
    >
      {dot && (
        <span className={classNames('h-1.5 w-1.5 shrink-0 rounded-full', DOT_TONES[tone] || DOT_TONES.slate)} />
      )}
      <span className="truncate">{children}</span>
    </span>
  );
}

/** Status → tone map. One source of truth for lifecycle colour semantics. */
const STATUS_TONES = {
  ACTIVE: 'green',
  ENABLED: 'green',
  HEALTHY: 'green',
  ALLOW: 'green',
  SUCCESS: 'green',
  VERIFIED: 'green',
  CONNECTED: 'green',
  PENDING: 'sky',
  PENDING_VERIFICATION: 'sky',
  PROVISIONING: 'sky',
  LOCKED: 'amber',
  EXPIRED: 'amber',
  WARNING: 'amber',
  DEGRADED: 'amber',
  INACTIVE: 'slate',
  DISABLED: 'slate',
  ROTATED: 'slate',
  UNKNOWN: 'slate',
  DELETED: 'red',
  REVOKED: 'red',
  SUSPENDED: 'red',
  OFFBOARDED: 'red',
  FAILURE: 'red',
  DENY: 'red',
  ERROR: 'red',
};

/** Human-readable status label: PENDING_VERIFICATION → Pending verification. */
function humanizeStatus(status) {
  const s = String(status || '').trim();
  if (!s) return '—';
  const spaced = s.replace(/[_-]+/g, ' ').toLowerCase();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

export function StatusBadge({ status, className }) {
  if (!status) return <span className="text-xs text-slate-400">—</span>;
  const key = String(status).toUpperCase();
  return (
    <Badge tone={STATUS_TONES[key] || 'slate'} dot className={classNames('whitespace-nowrap', className)}>
      {humanizeStatus(status)}
    </Badge>
  );
}

export function Spinner({ className }) {
  return <Loader2 className={classNames('h-5 w-5 animate-spin text-brand-500', className)} />;
}

export function Skeleton({ className }) {
  return <div className={classNames('animate-pulse rounded-md bg-slate-100', className)} />;
}

/**
 * StatCard — a KPI tile. Quiet by default: the number leads, the icon is a
 * small monochrome marker, and the whole tile becomes a link when `onClick`
 * is supplied.
 */
export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  tone = 'brand',
  onClick,
  delta,
  loading = false,
  className,
}) {
  const tones = {
    brand: 'text-brand-600 bg-brand-50',
    green: 'text-emerald-600 bg-emerald-50',
    amber: 'text-amber-600 bg-amber-50',
    red: 'text-rose-600 bg-rose-50',
    sky: 'text-sky-600 bg-sky-50',
    slate: 'text-slate-500 bg-slate-100',
  };
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={classNames(
        'card group flex items-start justify-between gap-3 p-4 text-left transition-all duration-150',
        onClick && 'hover:border-brand-200 hover:shadow-raised focus-visible:outline-none',
        className
      )}
    >
      <div className="min-w-0">
        <p className="truncate text-2xs font-medium uppercase tracking-[0.07em] text-slate-500">{label}</p>
        {loading ? (
          <Skeleton className="mt-2 h-7 w-16" />
        ) : (
          <p className="mt-1 text-[22px] font-semibold leading-tight text-ink-900 tabular">
            {value ?? '—'}
          </p>
        )}
        {(hint || delta) && (
          <p className="mt-1 flex items-center gap-1.5 truncate text-xs text-slate-500">
            {delta}
            {hint}
          </p>
        )}
      </div>
      {Icon && (
        <span
          className={classNames(
            'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg',
            tones[tone] || tones.brand
          )}
        >
          <Icon className="h-4 w-4" />
        </span>
      )}
    </Tag>
  );
}

/**
 * SummaryBar — the console's standard way to present a set of related numbers
 * above a working list.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS REPLACES THE KPI-TILE STRIPS
 * ═══════════════════════════════════════════════════════════════════════════
 * Leading enterprise consoles do NOT stack a row of large KPI tiles above an
 * inventory list. Microsoft Entra ID's user blade, Okta's People page, AWS IAM's
 * Users list, CyberArk's PVWA account list and Datadog's facet panels converge
 * on the same three rules:
 *
 *   1. The set total belongs to the list itself — its title, or the pagination
 *      range ("1–20 of 348"). Repeating it in a large tile is redundant.
 *   2. A status breakdown is a FILTER, not a read-out: each figure is a facet
 *      that narrows the list, so the number and the action are one control.
 *   3. Large number tiles are reserved for analytical surfaces, where the number
 *      IS the content — not for a list page, where the table is.
 *
 * So this is one compact band, hairline-divided, roughly a third the height of
 * the tile strip it replaces: uppercase label, tabular figure, one line of
 * context. Pass `onSelect` and every cell becomes a facet — tinted with a
 * leading accent when active, the same language as the navigation's active row —
 * which also keeps the numbers honest, because clicking one shows the rows it
 * counted.
 *
 * Existing tokens only (card, line-soft, brand / emerald / amber / rose ramps).
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * @param {Array}    items     [{ id, label, value, hint, tone, icon }]
 * @param {string}   value     id of the active facet (only with onSelect)
 * @param {Function} onSelect  (id) => void — omit for a read-only band
 */
export function SummaryBar({
  items = [],
  value,
  onSelect,
  loading = false,
  className,
  ariaLabel = 'Summary',
}) {
  /* ── Skeletons on FIRST load only ────────────────────────────────────────
     `loading` used to swap every figure for a skeleton, so each poll, filter
     change and reload-after-mutation made the whole band flash — numbers the
     operator was reading vanished and came back, usually unchanged. Worse, a
     band that flickers to grey reads as "the data is gone", not "the data is
     being confirmed".

     After the first answer the band therefore KEEPS its last figures while the
     next response is in flight, dimmed and marked aria-busy. Only a band that
     has never resolved shows skeletons, because it has nothing to hold. */
  const settledOnce = useRef(false);
  if (!loading) settledOnce.current = true;
  const showSkeleton = loading && !settledOnce.current;
  const refreshing = loading && settledOnce.current;

  const numberTone = {
    default: 'text-ink-900',
    positive: 'text-emerald-700',
    warning: 'text-amber-700',
    danger: 'text-rose-700',
    muted: 'text-slate-600',
  };

  return (
    <div
      role={onSelect ? 'group' : undefined}
      aria-label={ariaLabel}
      aria-busy={refreshing || undefined}
      className={classNames(
        'card grid grid-cols-2 divide-x divide-y divide-line-soft overflow-hidden sm:flex sm:divide-y-0',
        refreshing && 'opacity-70 transition-opacity duration-150',
        className
      )}
    >
      {items.map((item) => {
        const active = !!onSelect && value === item.id;
        const Tag = onSelect ? 'button' : 'div';
        const Icon = item.icon;
        return (
          <Tag
            key={item.id ?? item.label}
            type={onSelect ? 'button' : undefined}
            onClick={onSelect ? () => onSelect(item.id) : undefined}
            aria-pressed={onSelect ? active : undefined}
            title={onSelect ? `Show ${String(item.label).toLowerCase()}` : undefined}
            className={classNames(
              'relative min-w-0 flex-1 px-4 py-3 text-left transition-colors duration-100',
              onSelect && 'hover:bg-slate-50/80 focus-visible:outline-none',
              active && 'bg-brand-50/60'
            )}
          >
            {/* Active facet marker — the 2px accent the navigation also uses. */}
            {active && <span className="absolute inset-x-0 top-0 h-[2px] bg-brand-600" />}
            <span className="flex items-center gap-1.5">
              {Icon && <Icon className="h-3 w-3 shrink-0 text-slate-400" />}
              <span className="truncate text-3xs font-semibold uppercase tracking-[0.09em] text-slate-500">
                {item.label}
              </span>
            </span>
            {showSkeleton ? (
              <Skeleton className="mt-1.5 h-5 w-12" />
            ) : (
              <span
                className={classNames(
                  'mt-0.5 block text-[19px] font-semibold leading-tight tabular',
                  numberTone[item.tone] || numberTone.default
                )}
              >
                {typeof item.value === 'number' ? item.value.toLocaleString() : item.value ?? '—'}
              </span>
            )}
            {item.hint && (
              <span className="mt-0.5 block truncate text-2xs text-slate-500">{item.hint}</span>
            )}
          </Tag>
        );
      })}
    </div>
  );
}

/** Compact metric row for use inside panels (label left, value right). */
export function MetricRow({ label, value, icon: Icon, tone, className }) {
  return (
    <div className={classNames('flex items-center justify-between gap-3 py-1.5', className)}>
      <span className="flex min-w-0 items-center gap-2 text-[13px] text-slate-500">
        {Icon && <Icon className="h-3.5 w-3.5 shrink-0 text-slate-400" />}
        <span className="truncate">{label}</span>
      </span>
      <span
        className={classNames(
          'shrink-0 text-[13px] font-semibold tabular',
          tone === 'danger' ? 'text-rose-600' : tone === 'warning' ? 'text-amber-600' : 'text-ink-900'
        )}
      >
        {value}
      </span>
    </div>
  );
}

/** Key/value list used in detail panels and review steps. */
export function DescriptionList({ items = [], columns = 2, className }) {
  return (
    <dl
      className={classNames(
        'grid gap-x-6 gap-y-4',
        columns === 1 ? 'grid-cols-1' : columns === 3 ? 'grid-cols-2 sm:grid-cols-3' : 'grid-cols-1 sm:grid-cols-2',
        className
      )}
    >
      {items.map((item) => (
        <div key={item.label} className={classNames('min-w-0', item.wide && 'sm:col-span-2')}>
          <dt className="text-2xs font-medium uppercase tracking-[0.07em] text-slate-400">{item.label}</dt>
          <dd
            className={classNames(
              'mt-1 text-[13px] text-ink-900',
              item.mono && 'break-all font-mono text-xs'
            )}
          >
            {item.value ?? '—'}
          </dd>
        </div>
      ))}
    </dl>
  );
}

/** Horizontal ranked bar — the workhorse of the analytics views. */
export function RankBar({ label, value, max, tone = 'brand', suffix, leading, title, onClick, actionHint }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  /** 
   * Restrained by default: ranked bars are neutral so that the one row that
   * carries risk (or the leader of the ranking) is the only coloured thing on
   * screen. Enterprise analytics reads as "mostly grey with one accent".
   */
  const tones = {
    brand: 'bg-brand-500',
    red: 'bg-rose-500',
    amber: 'bg-amber-400',
    slate: 'bg-slate-300',
    green: 'bg-emerald-500',
  };
  const Tag = onClick ? 'button' : 'div';

  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      title={onClick ? actionHint || `Investigate ${label}` : undefined}
      className={classNames(
        'group/rank block w-full text-left',
        onClick &&
        'rounded-md -mx-1.5 px-1.5 py-1 transition-colors hover:bg-slate-50 focus-visible:outline-none'
      )}
    >
      <div className="mb-1.5 flex items-center justify-between gap-3">
        <span className="flex min-w-0 items-center gap-2">
          {leading}
          <span
            className={classNames(
              'truncate text-[12.5px] text-ink-700',
              onClick && 'group-hover/rank:text-brand-800'
            )}
            title={title || label}
          >
            {label}
          </span>
        </span>
        <span className="shrink-0 text-[12.5px] font-semibold text-ink-900 tabular">
          {value?.toLocaleString?.() ?? value ?? 0}
          {suffix && <span className="ml-0.5 font-normal text-slate-400">{suffix}</span>}
        </span>
      </div>
      <div className="h-1 w-full overflow-hidden rounded-full bg-slate-100">
        <div
          className={classNames('h-full rounded-full transition-[width] duration-500 ease-out', tones[tone] || tones.brand)}
          style={{ width: `${Math.max(pct, 1.5)}%` }}
        />
      </div>
    </Tag>
  );
}

/** Inline banner for page-level notices. Restrained: tinted, hairline, no icon circus. */
export function InlineAlert({ tone = 'info', title, children, action, className, icon }) {
  const tones = {
    info: { wrap: 'border-brand-200 bg-brand-50/70', icon: 'text-brand-600', Icon: Info },
    success: { wrap: 'border-emerald-200 bg-emerald-50/70', icon: 'text-emerald-600', Icon: CheckCircle2 },
    warning: { wrap: 'border-amber-200 bg-amber-50/70', icon: 'text-amber-600', Icon: AlertTriangle },
    danger: { wrap: 'border-rose-200 bg-rose-50/70', icon: 'text-rose-600', Icon: XCircle },
  };
  const cfg = tones[tone] || tones.info;
  const Icon = icon || cfg.Icon;
  return (
    <div
      className={classNames(
        'flex flex-col gap-3 rounded-xl border px-4 py-3 sm:flex-row sm:items-center',
        cfg.wrap,
        className
      )}
      role={tone === 'danger' ? 'alert' : 'status'}
    >
      <Icon className={classNames('h-4 w-4 shrink-0', cfg.icon)} />
      <div className="min-w-0 flex-1">
        {title && <p className="text-[13px] font-semibold text-ink-900">{title}</p>}
        {children && <p className="text-xs leading-relaxed text-ink-700/80">{children}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, description, action, className, compact = false }) {
  return (
    <div
      className={classNames(
        'flex flex-col items-center justify-center rounded-xl border border-dashed border-line-strong bg-white text-center',
        compact ? 'px-6 py-10' : 'px-6 py-16',
        className
      )}
    >
      {Icon && (
        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-slate-400">
          <Icon className="h-5 w-5" />
        </div>
      )}
      <p className="text-[13.5px] font-semibold text-ink-900">{title}</p>
      {description && (
        <p className="mt-1.5 max-w-sm text-[13px] leading-relaxed text-slate-500">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/**
 * Tabs — underline tabs for in-page sections.
 * Horizontally scrollable on small screens (no wrapping, no overflow clipping).
 */
export function Tabs({ tabs = [], active, onChange, className }) {
  return (
    <div className={classNames('border-b border-line', className)}>
      <div className="no-scrollbar -mb-px flex gap-1 overflow-x-auto" role="tablist">
        {tabs.map((t) => {
          const isActive = active === t.id;
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              onClick={() => onChange?.(t.id)}
              className={classNames(
                'relative flex shrink-0 items-center gap-2 border-b-2 px-3 py-2.5 text-[13px] font-medium transition-colors duration-100',
                'focus-visible:outline-none',
                isActive
                  ? 'border-brand-600 text-brand-700'
                  : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-ink-800'
              )}
            >
              {Icon && <Icon className={classNames('h-4 w-4', isActive ? 'text-brand-600' : 'text-slate-400')} />}
              {t.label}
              {t.count != null && (
                <span
                  className={classNames(
                    'rounded-full px-1.5 py-px text-3xs font-semibold tabular',
                    isActive ? 'bg-brand-50 text-brand-700' : 'bg-slate-100 text-slate-500'
                  )}
                >
                  {t.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   SearchableCombobox — editable combobox (type-ahead)
   ═══════════════════════════════════════════════════════════════════════════
   Reworked to the WAI-ARIA editable-combobox pattern used by Entra ID, Okta
   and Google Cloud IAM people-pickers: the FIELD ITSELF is the text input, and
   typing filters the list underneath it live. There is no second search box
   inside the popover any more — one control, one place to type.

     · type            → opens the list and filters it as you type
     · ↑ ↓ Home End    → move through matches (aria-activedescendant)
     · Enter           → select the highlighted match
     · Esc             → close and restore the committed value
     · Tab / blur      → close; unmatched typing is discarded, never submitted
     · multi           → committed values become removable chips above the field

   The public API is unchanged: { options, value, onChange, multi, loading,
   label, placeholder, hint, error, disabled, emptyMessage, allowSelectAll }.
   ═══════════════════════════════════════════════════════════════════════════ */
export function SearchableCombobox({
  options = [],
  value,
  onChange,
  label,
  placeholder = 'Select…',
  searchPlaceholder,
  loading = false,
  error,
  hint,
  multi = false,
  disabled = false,
  className,
  emptyMessage = 'No matches found.',
  allowSelectAll = true,
  required,
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [typing, setTyping] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const [showAllChips, setShowAllChips] = useState(false);

  const rootRef = useRef(null);
  const inputRef = useRef(null);
  const listRef = useRef(null);
  const baseId = useId();
  const listboxId = `${baseId}-listbox`;

  const selectedIds = multi ? (Array.isArray(value) ? value : []) : [];
  const selectedSingle = !multi ? options.find((o) => o.id === value) : null;
  const selectedMulti = multi ? options.filter((o) => selectedIds.includes(o.id)) : [];

  /* Filtering happens on what the user is typing, never on the committed label. */
  const filtered = useMemo(() => {
    const q = typing ? query.trim().toLowerCase() : '';
    if (!q) return options;
    return options.filter(
      (opt) =>
        opt.label?.toLowerCase().includes(q) ||
        opt.description?.toLowerCase().includes(q) ||
        String(opt.id ?? '').toLowerCase().includes(q)
    );
  }, [options, query, typing]);

  useEffect(() => {
    setHighlight(0);
  }, [query, open]);

  // Keep the active option in view without touching page scroll.
  useEffect(() => {
    if (!open || !listRef.current) return;
    const el = listRef.current.querySelector(`[data-idx="${highlight}"]`);
    if (!el) return;
    const box = listRef.current;
    if (el.offsetTop < box.scrollTop) box.scrollTop = el.offsetTop;
    else if (el.offsetTop + el.offsetHeight > box.scrollTop + box.clientHeight) {
      box.scrollTop = el.offsetTop + el.offsetHeight - box.clientHeight;
    }
  }, [highlight, open]);

  const close = useCallback(() => {
    setOpen(false);
    setTyping(false);
    setQuery('');
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) close();
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open, close]);

  const commit = useCallback(
    (id) => {
      if (multi) {
        const current = Array.isArray(value) ? [...value] : [];
        const idx = current.indexOf(id);
        if (idx >= 0) current.splice(idx, 1);
        else current.push(id);
        onChange?.(current);
        setQuery('');
        setTyping(false);
        inputRef.current?.focus();
      } else {
        onChange?.(id);
        close();
        inputRef.current?.blur();
      }
    },
    [multi, value, onChange, close]
  );

  const clearAll = useCallback(
    (e) => {
      e?.stopPropagation();
      e?.preventDefault();
      onChange?.(multi ? [] : '');
      setQuery('');
      setTyping(false);
      inputRef.current?.focus();
    },
    [multi, onChange]
  );

  const selectAllFiltered = useCallback(() => {
    if (!multi) return;
    const current = Array.isArray(value) ? value : [];
    onChange?.(Array.from(new Set([...current, ...filtered.map((o) => o.id)])));
    inputRef.current?.focus();
  }, [multi, value, filtered, onChange]);

  const onKeyDown = (e) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        if (!open) setOpen(true);
        else setHighlight((h) => (h < filtered.length - 1 ? h + 1 : 0));
        break;
      case 'ArrowUp':
        e.preventDefault();
        if (!open) setOpen(true);
        else setHighlight((h) => (h > 0 ? h - 1 : filtered.length - 1));
        break;
      case 'Home':
        if (open) {
          e.preventDefault();
          setHighlight(0);
        }
        break;
      case 'End':
        if (open) {
          e.preventDefault();
          setHighlight(Math.max(0, filtered.length - 1));
        }
        break;
      case 'Enter':
        if (open && filtered[highlight]) {
          e.preventDefault();
          commit(filtered[highlight].id);
        }
        break;
      case 'Escape':
        if (open) {
          e.preventDefault();
          e.stopPropagation();
          close();
        }
        break;
      case 'Backspace':
        // Empty field + multi → remove the last chip, like a tag input.
        if (multi && !query && selectedIds.length) {
          e.preventDefault();
          onChange?.(selectedIds.slice(0, -1));
        }
        break;
      case 'Tab':
        if (open) close();
        break;
      default:
        break;
    }
  };

  const isSelected = (id) => (multi ? selectedIds.includes(id) : value === id);
  const allFilteredSelected =
    multi && filtered.length > 0 && filtered.every((o) => selectedIds.includes(o.id));

  const inputValue = typing ? query : multi ? '' : selectedSingle?.label || '';
  const visibleChips = showAllChips ? selectedMulti : selectedMulti.slice(0, 6);
  const hiddenChipCount = selectedMulti.length - visibleChips.length;

  const fieldPlaceholder = multi
    ? selectedMulti.length
      ? 'Add another…'
      : searchPlaceholder || placeholder
    : selectedSingle
      ? selectedSingle.label
      : searchPlaceholder || placeholder;

  return (
    <div className={classNames('w-full', className)} ref={rootRef}>
      {label && (
        <label htmlFor={`${baseId}-input`} className="label-base">
          {label}
          {required && <span className="ml-0.5 text-rose-500">*</span>}
        </label>
      )}

      {multi && selectedMulti.length > 0 && (
        <div className="mb-2 flex flex-wrap items-center gap-1.5">
          {visibleChips.map((opt) => (
            <span
              key={opt.id}
              className="inline-flex max-w-full items-center gap-1 rounded-md bg-slate-100 py-0.5 pl-2 pr-1 text-2xs font-medium text-ink-800 ring-1 ring-inset ring-line-strong"
            >
              <span className="truncate">{opt.label}</span>
              <button
                type="button"
                onClick={() => commit(opt.id)}
                title={`Remove ${opt.label}`}
                aria-label={`Remove ${opt.label}`}
                className="rounded p-0.5 text-slate-400 transition-colors hover:bg-slate-200 hover:text-ink-800"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
          {hiddenChipCount > 0 && (
            <button
              type="button"
              onClick={() => setShowAllChips(true)}
              className="text-2xs font-medium text-brand-700 hover:text-brand-800"
            >
              +{hiddenChipCount} more
            </button>
          )}
          {showAllChips && selectedMulti.length > 6 && (
            <button
              type="button"
              onClick={() => setShowAllChips(false)}
              className="text-2xs font-medium text-slate-500 hover:text-ink-700"
            >
              Show less
            </button>
          )}

          <button
            type="button"
            onClick={clearAll}
            className="ml-auto text-2xs font-medium text-slate-500 hover:text-rose-600"
          >
            Clear all
          </button>
        </div>
      )}

      <div className="relative">
        <div
          className={classNames(
            'flex items-center gap-1 rounded-lg border bg-white pl-3 pr-1.5 transition',
            // === TARGETED FIX: Completely kill blue focus ring on SearchableCombobox ===
            'outline-none focus:outline-none focus-visible:outline-none',
            '!ring-0 !ring-offset-0 focus-within:!ring-0 focus-within:!ring-offset-0',
            'focus:ring-0 focus-visible:ring-0 focus:ring-offset-0 focus-visible:ring-offset-0',
            'shadow-none focus-within:shadow-none',
            // ================================================================
            open
              ? 'border-slate-400'
              : 'border-slate-300 hover:border-slate-400',
            error && 'border-rose-400',
            disabled && 'cursor-not-allowed bg-slate-50 opacity-70'
          )}
        >
          <Search className="h-3.5 w-3.5 shrink-0 text-slate-400" />
          <input
            id={`${baseId}-input`}
            ref={inputRef}
            type="text"
            role="combobox"
            autoComplete="off"
            spellCheck="false"
            aria-expanded={open}
            aria-controls={listboxId}
            aria-autocomplete="list"
            aria-activedescendant={open && filtered[highlight] ? `${baseId}-opt-${highlight}` : undefined}
            disabled={disabled}
            value={inputValue}
            placeholder={fieldPlaceholder}
            onFocus={() => setOpen(true)}
            onClick={() => setOpen(true)}
            onChange={(e) => {
              setQuery(e.target.value);
              setTyping(true);
              setOpen(true);
            }}
            onKeyDown={onKeyDown}
            className={classNames(
              'min-h-[2.25rem] w-full border-0 bg-transparent py-2 text-[13px] text-ink-900 outline-none placeholder:text-slate-400',
              // === TARGETED FIX: Remove blue ring on the input itself ===
              'focus:outline-none focus:ring-0 focus:ring-offset-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:ring-offset-0 !ring-0 !ring-offset-0',
              !multi && selectedSingle && !typing && 'font-medium'
            )}
          />
          {!multi && selectedSingle && !disabled && (
            <button
              type="button"
              onClick={clearAll}
              title="Clear selection"
              aria-label="Clear selection"
              className="rounded p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            type="button"
            tabIndex={-1}
            disabled={disabled}
            aria-label={open ? 'Close options' : 'Show options'}
            onClick={() => {
              if (open) close();
              else {
                setOpen(true);
                inputRef.current?.focus();
              }
            }}
            className="rounded p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-ink-700"
          >
            <ChevronDown className={classNames('h-4 w-4 transition-transform', open && 'rotate-180')} />
          </button>
        </div>

        {open && (
          <div className="absolute left-0 right-0 top-full z-50 mt-1.5 overflow-hidden rounded-xl border border-line bg-white shadow-popover animate-pop-in">
            <div ref={listRef} id={listboxId} role="listbox" className="max-h-64 overflow-y-auto p-1">
              {loading ? (
                <div className="flex items-center justify-center gap-2 py-6">
                  <Spinner className="h-4 w-4" />
                  <span className="text-[13px] text-slate-500">Loading…</span>
                </div>
              ) : filtered.length === 0 ? (
                <p className="px-3 py-6 text-center text-[13px] text-slate-400">{emptyMessage}</p>
              ) : (
                filtered.map((opt, idx) => {
                  const active = isSelected(opt.id);
                  const isHighlighted = idx === highlight;
                  return (
                    <div
                      key={opt.id}
                      id={`${baseId}-opt-${idx}`}
                      role="option"
                      aria-selected={active}
                      data-idx={idx}
                      onMouseEnter={() => setHighlight(idx)}
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => commit(opt.id)}
                      className={classNames(
                        'flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 transition-colors',
                        isHighlighted ? 'bg-slate-100' : 'hover:bg-slate-50',
                        active && 'bg-brand-50 hover:bg-brand-50'
                      )}
                    >
                      {multi && (
                        <span
                          className={classNames(
                            'flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors',
                            active ? 'border-brand-600 bg-brand-600 text-white' : 'border-slate-300 bg-white'
                          )}
                        >
                          {active && <Check className="h-3 w-3" strokeWidth={3} />}
                        </span>
                      )}
                      {!multi &&
                        (opt.icon || (
                          <span className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-100 text-2xs font-semibold text-slate-600">
                            {opt.label?.charAt(0)?.toUpperCase() || '?'}
                          </span>
                        ))}
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="truncate text-[13px] font-medium text-ink-900">{opt.label}</span>
                          {opt.badge && <Badge tone="outline">{opt.badge}</Badge>}
                        </span>
                        {opt.description && (
                          <span className="mt-0.5 block truncate text-xs text-slate-500">{opt.description}</span>
                        )}
                      </span>
                      {!multi && active && <Check className="h-4 w-4 shrink-0 text-brand-600" />}
                    </div>
                  );
                })
              )}
            </div>

            <div className="flex items-center justify-between gap-3 border-t border-line-soft bg-slate-50/70 px-3 py-2">
              <span className="text-2xs text-slate-500">
                {multi
                  ? `${selectedIds.length} of ${options.length} selected`
                  : `${filtered.length} of ${options.length} ${options.length === 1 ? 'option' : 'options'}`}
              </span>
              {multi && allowSelectAll ? (
                <span className="flex items-center gap-3">
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={selectAllFiltered}
                    disabled={filtered.length === 0 || allFilteredSelected}
                    className="text-2xs font-semibold text-brand-700 transition-colors hover:text-brand-800 disabled:cursor-not-allowed disabled:text-slate-300"
                  >
                    {typing && query.trim() ? `Select ${filtered.length} matching` : 'Select all'}
                  </button>
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={clearAll}
                    disabled={selectedIds.length === 0}
                    className="text-2xs font-medium text-slate-500 transition-colors hover:text-rose-600 disabled:cursor-not-allowed disabled:text-slate-300"
                  >
                    Clear
                  </button>
                </span>
              ) : (
                <span className="text-2xs text-slate-400">↑↓ to navigate · ↵ to select</span>
              )}
            </div>
          </div>
        )}
      </div>

      {hint && !error && <p className="mt-1.5 text-xs text-slate-500">{hint}</p>}
      {error && (
        <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-rose-600">
          <AlertTriangle className="h-3 w-3 shrink-0" />
          {error}
        </p>
      )}
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   Checkbox — used for table row selection and multi-select lists.
   ═══════════════════════════════════════════════════════════════════════════ */
export function Checkbox({ checked = false, indeterminate = false, onChange, label, disabled, className }) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={indeterminate ? 'mixed' : checked}
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={(e) => {
        e.stopPropagation();
        onChange?.(!checked);
      }}
      className={classNames(
        'flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors',
        'focus-visible:outline-none',
        checked || indeterminate
          ? 'border-brand-600 bg-brand-600 text-white'
          : 'border-slate-300 bg-white hover:border-slate-400',
        disabled && 'cursor-not-allowed opacity-40',
        className
      )}
    >
      {indeterminate ? (
        <span className="h-[2px] w-2 rounded-full bg-white" />
      ) : checked ? (
        <Check className="h-3 w-3" strokeWidth={3} />
      ) : null}
    </button>
  );
}


/* ═══════════════════════════════════════════════════════════════════════════
   FormErrorSummary — dialog-level list of blocking errors.
   Toasts disappear; a long form needs its errors to stay on screen next to the
   fields that caused them, which is also what screen readers announce first.
   ═══════════════════════════════════════════════════════════════════════════ */
export function FormErrorSummary({ errors, title = 'Fix the following before continuing', className }) {
  const entries = Object.entries(errors || {}).filter(([, v]) => !!v);
  if (entries.length === 0) return null;
  return (
    <div
      role="alert"
      className={classNames('rounded-xl border border-rose-200 bg-rose-50/70 px-4 py-3', className)}
    >
      <p className="flex items-center gap-2 text-[13px] font-semibold text-rose-800">
        <AlertTriangle className="h-4 w-4 shrink-0" />
        {title}
      </p>
      <ul className="mt-1.5 list-disc space-y-0.5 pl-8 text-xs text-rose-700">
        {entries.map(([key, message]) => (
          <li key={key}>{message}</li>
        ))}
      </ul>
    </div>
  );
}