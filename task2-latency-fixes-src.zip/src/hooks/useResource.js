import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * useResource — the console's async-data hook for GET-style reads.
 *
 * Returns { data, loading, error, status, stale, loaded, reload }.
 * `fetcher` returns a promise (already unwrapped by the api client); `deps`
 * controls re-fetching, exactly as before.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TWO DEFECTS FIXED HERE — BOTH VISIBLE ON EVERY PAGE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. A FAILED REFRESH DESTROYED GOOD DATA.
 *    The catch branch set `data: null` unconditionally. Because most surfaces
 *    poll (PAM auto-refresh) or reload after every mutation, a single transient
 *    5xx wiped the table, every summary figure and every derived chart on the
 *    screen — replacing a correct picture with an empty one over a blip that
 *    would have healed on the next tick.
 *
 *    Now the last good payload SURVIVES a failed manual reload and is marked
 *    `stale: true`, so a page can keep showing what it has while saying the
 *    refresh did not land.
 *
 *    IMPORTANT — this is deliberately NOT applied when `deps` change. A deps
 *    change means the caller is asking about a DIFFERENT object (another user
 *    id, another page of results). Keeping the previous object's data after
 *    that request failed would attribute one record's data to another, which is
 *    worse than an empty state. On a key change the old behaviour is kept
 *    exactly: data is cleared. So `reload()` is resilient and navigation is
 *    still strict.
 *
 * 2. OVERLAPPING REQUESTS COULD RESOLVE OUT OF ORDER.
 *    The effect's cleanup cancelled a stale response, but `reload()` returned
 *    that cleanup to a caller which always discarded it — and click handlers
 *    are wired straight to it (`onClick={resource.reload}`). Two reloads in
 *    flight therefore raced, and a slow FIRST response could overwrite a fast
 *    SECOND one, leaving the screen showing older data than the user asked for.
 *
 *    Every request now carries a monotonic sequence number and only the newest
 *    one may write state. Unmount is guarded by the same check.
 *
 * NOTE ON `reload`: it is passed directly to onClick in several pages, so it
 * receives a MouseEvent as its first argument. It therefore takes NO parameters
 * — the "is this a key change?" distinction is carried internally instead of
 * through an argument that a DOM event would silently satisfy.
 */
export function useResource(fetcher, deps = []) {
  const [state, setState] = useState({
    loading: true,
    data: null,
    error: null,
    status: null,
    /** True when `data` is a previous payload kept after a failed refresh. */
    stale: false,
    /** True once any request for the current key has succeeded. */
    loaded: false,
  });

  /* Only the newest request may write state. Bumped on every run, so an older
     in-flight promise silently drops its result when it eventually resolves. */
  const seqRef = useRef(0);
  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  /* Held in a ref so both the deps-driven load and the stable `reload` always
     invoke the CURRENT render's fetcher without either of them having to be
     re-created on every render. */
  const runRef = useRef(null);
  runRef.current = (isKeyChange) => {
    const seq = seqRef.current + 1;
    seqRef.current = seq;
    const isCurrent = () => mountedRef.current && seqRef.current === seq;

    // Keep whatever is on screen while the request is in flight — the previous
    // behaviour, and what makes a refresh feel like a refresh rather than a
    // teardown.
    setState((s) => ({ ...s, loading: true, error: null }));

    Promise.resolve()
      .then(() => fetcher())
      .then((data) => {
        if (!isCurrent()) return;
        setState({
          loading: false,
          data,
          error: null,
          status: 200,
          stale: false,
          loaded: true,
        });
      })
      .catch((err) => {
        if (!isCurrent()) return;
        setState((s) => {
          const keepData = !isKeyChange && s.loaded;
          return {
            loading: false,
            // A failed REFRESH keeps the last good payload; a failed request for
            // a NEW key clears it (see the note above).
            data: keepData ? s.data : null,
            error: err?.userMessage || err?.message || 'Failed to load.',
            // Lets a page distinguish "you may not see this" (401/403) from
            // "the request failed" — they need different UI.
            status: err?.response?.status ?? null,
            stale: keepData,
            loaded: keepData,
          };
        });
      });
  };

  // Deps-driven load. Identity changes only when `deps` change, so the effect
  // below runs exactly when it used to.
  const loadForKey = useCallback(() => {
    runRef.current?.(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  /* Stable across renders: a page can put it in a dependency array or hand it
     to an interval without re-arming anything. */
  const reload = useCallback(() => {
    runRef.current?.(false);
  }, []);

  useEffect(() => {
    loadForKey();
  }, [loadForKey]);

  return { ...state, reload };
}
