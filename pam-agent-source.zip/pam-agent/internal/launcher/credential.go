// pam-agent/internal/launcher/credential.go
//
// Per-tool credential injection. The guiding rule: a password must never
// appear as a plain command-line argument, because argv is visible to every
// other process on the machine via `ps`/Task Manager/process-monitoring
// tools. Where the target tool supports it, we use an environment variable
// (still readable by another process running as the same OS user via
// /proc/<pid>/environ on Linux, but invisible to `ps` and to anything not
// running as that user — a real improvement, not a perfect one). Where a
// tool has no env-based auth, we write a short-lived temp file instead.
package launcher

import (
	"encoding/xml"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"

	"github.com/yourorg/pam-agent/internal/apiclient"
)

// writePgpassFile writes a libpq-format .pgpass line
// (host:port:database:user:password, with ':' and '\' escaped per the
// documented format) to a 0600 temp file and returns its path. psql reads
// this automatically via PGPASSFILE with no password prompt and nothing on
// its command line.
func writePgpassFile(tempDir, host, port, dbName, user, password string) (string, error) {
	if dbName == "" {
		dbName = "*"
	}
	line := strings.Join([]string{
		pgpassEscape(host), pgpassEscape(port), pgpassEscape(dbName),
		pgpassEscape(user), pgpassEscape(password),
	}, ":")

	f, err := os.CreateTemp(tempDir, "pam-agent-*.pgpass")
	if err != nil {
		return "", fmt.Errorf("failed to create temp pgpass file: %w", err)
	}
	defer f.Close()

	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp pgpass file: %w", err)
	}
	if _, err := f.WriteString(line + "\n"); err != nil {
		return "", fmt.Errorf("failed to write temp pgpass file: %w", err)
	}
	return f.Name(), nil
}

func pgpassEscape(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `:`, `\:`)
	return s
}

// mongoAuthSource decides which MongoDB database the credential is
// authenticated AGAINST, which is not necessarily the database being
// browsed. MongoDB stores users per-database, and a deployment's
// administrative users almost always live in "admin" while the data they
// work on lives elsewhere, so "connect to shop, authenticate against admin"
// is the normal shape rather than the exception. Getting this wrong does
// not fail at connect time, it fails later with a bare "Authentication
// failed" that looks like a wrong password.
//
// The resource's own extra_config["auth_source"] wins when an admin has set
// it. Otherwise this mirrors MongoDB's own default: the database named in
// the connection string, falling back to "admin" when none is named.
// Because writeMongoInitFile defaults an empty DatabaseName to "admin"
// before calling here, an unconfigured resource lands on "admin" either
// way.
//
// Shared by the mongosh path and the connection-string path below so the
// two cannot drift: the shell and the GUI must authenticate identically, or
// one works and the other reports a wrong password for the same resource.
func mongoAuthSource(resolved *apiclient.ResolvedLaunch, dbName string) string {
	if v, ok := resolved.ExtraConfig["auth_source"].(string); ok && v != "" {
		return v
	}
	if dbName == "" {
		return "admin"
	}
	return dbName
}

// writeMongoInitFile writes a small mongosh init script that opens an
// authenticated connection and assigns it to `db`, then returns its path.
// Invoked as `mongosh --shell <path>`: mongosh evaluates the file (running
// the connection logic, credential included) and then drops the operator
// into an interactive shell against the already-connected `db` — the
// command line itself only ever shows the temp file's path, never the
// credential.
func writeMongoInitFile(tempDir string, resolved *apiclient.ResolvedLaunch) (string, error) {
	dbName := resolved.DatabaseName
	if dbName == "" {
		dbName = "admin"
	}

	u := &url.URL{
		Scheme:   "mongodb",
		User:     url.UserPassword(resolved.AccountName, resolved.Password),
		Host:     fmt.Sprintf("%s:%d", resolved.Host, resolved.Port),
		Path:     "/" + dbName,
		RawQuery: "authSource=" + url.QueryEscape(mongoAuthSource(resolved, dbName)),
	}

	script := fmt.Sprintf(
		"var __pamConn = Mongo(%q);\ndb = __pamConn.getDB(%q);\nprint('PAM agent: connected to %s as %s');\n",
		u.String(), dbName, dbName, resolved.AccountName,
	)

	f, err := os.CreateTemp(tempDir, "pam-agent-*.mongo-init.js")
	if err != nil {
		return "", fmt.Errorf("failed to create temp mongo init file: %w", err)
	}
	defer f.Close()

	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp mongo init file: %w", err)
	}
	if _, err := f.WriteString(script); err != nil {
		return "", fmt.Errorf("failed to write temp mongo init file: %w", err)
	}
	return f.Name(), nil
}

// buildConnectionString is the best-effort GUI path — see the
// "connection_string_arg" case in BuildCommand for why this one mode is a
// deliberate, documented exception to "never in argv." It only understands
// the three URL-style schemes PAM's own connectors use (mongodb/postgresql/
// redis) — it is NOT a generic connection-string builder, and defaulting an
// unrecognized resource type to "mongodb://" would silently produce the
// wrong scheme rather than failing loudly. Anything else needs its own
// dedicated builder (see buildOracleConnectString below for why Oracle in
// particular can't just reuse this one).
func buildConnectionString(resolved *apiclient.ResolvedLaunch, dbName string) string {
	scheme := "mongodb"
	if resolved.ResourceType == "postgresql" {
		scheme = "postgresql"
	} else if resolved.ResourceType == "redis" {
		scheme = "redis"
	}

	u := &url.URL{
		Scheme: scheme,
		User:   url.UserPassword(resolved.AccountName, resolved.Password),
		Host:   resolved.Host + ":" + strconv.Itoa(resolved.Port),
	}
	if dbName != "" {
		u.Path = "/" + dbName
	}
	if scheme == "mongodb" {
		// Same authSource the mongosh path sets (see mongoAuthSource).
		// Without it, Compass authenticates against whatever database is
		// named in the path, so an admin-realm user browsing an
		// application database is rejected with "Authentication failed" —
		// the shell would connect fine against the identical resource,
		// which makes the GUI look broken rather than misconfigured.
		u.RawQuery = "authSource=" + url.QueryEscape(mongoAuthSource(resolved, dbName))
	}
	return u.String()
}

// buildOracleConnectString renders Oracle's classic EZCONNECT logon syntax
// — `username/password@host:port/service_name` — as used directly by
// sqlplus and SQLcl (Oracle's real command-line tools; the SQL Developer
// GUI does not accept a connect string as a launch argument at all, so this
// mode only helps for sqlplus/SQLcl-based templates). Deliberately NOT a
// case inside buildConnectionString: Oracle's syntax isn't a URL (no
// "oracle://" scheme, and it separates user/password with '/' rather than
// ':'), so bolting it onto the generic URL builder above would either
// panic or silently emit a string sqlplus can't parse.
//
// Same "never in argv" trade-off as connection_string_arg — see that case
// in BuildCommand. Unlike a URL, EZCONNECT has no escape mechanism for
// special characters at all, so rather than emit a connect string that
// would silently authenticate as the wrong identity (or just fail
// confusingly) if the stored credential contains '@', '/', or whitespace,
// this refuses outright and tells the operator why.
func buildOracleConnectString(resolved *apiclient.ResolvedLaunch, dbName string) (string, error) {
	if dbName == "" {
		return "", fmt.Errorf(
			"oracle_connect_string requires the resource's database_name to be set to the Oracle service name (or SID)")
	}
	if containsUnescapableChar(resolved.AccountName) || containsUnescapableChar(resolved.Password) {
		return "", fmt.Errorf(
			"the stored Oracle account name or password contains a character ('@', '/', or whitespace) " +
				"that EZCONNECT syntax cannot escape — store a credential without these characters, " +
				"or launch with credential_injection \"none\" and enter it manually")
	}
	return fmt.Sprintf("%s/%s@%s:%d/%s",
		resolved.AccountName, resolved.Password, resolved.Host, resolved.Port, dbName), nil
}

func containsUnescapableChar(s string) bool {
	return strings.ContainsAny(s, "@/ \t\n")
}

// clickhouseConfigXML mirrors the small subset of clickhouse-client's own
// --config-file XML schema needed to carry connection details + credential
// (https://clickhouse.com/docs/en/interfaces/cli — "Configuring" section):
// <config><user>...</user><password>...</password><host>...</host>
// <port>...</port></config>. Go's encoding/xml handles escaping, so a
// credential containing '&', '<', etc. can't corrupt the document.
type clickhouseConfigXML struct {
	XMLName  xml.Name `xml:"config"`
	User     string   `xml:"user"`
	Password string   `xml:"password"`
	Host     string   `xml:"host"`
	Port     int      `xml:"port"`
	Database string   `xml:"database,omitempty"`
}

// writeClickhouseConfigFile writes a 0600 temp clickhouse-client config
// file carrying the resolved credential, so `clickhouse-client
// --config-file <path>` connects fully authenticated with nothing on its
// command line. Same lifecycle as the pgpass/mongo-init-file temp files:
// per-session temp dir, cleaned up shortly after the tool exits.
func writeClickhouseConfigFile(tempDir string, resolved *apiclient.ResolvedLaunch) (string, error) {
	doc := clickhouseConfigXML{
		User:     resolved.AccountName,
		Password: resolved.Password,
		Host:     resolved.Host,
		Port:     resolved.Port,
		Database: resolved.DatabaseName,
	}

	raw, err := xml.MarshalIndent(doc, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to encode clickhouse-client config: %w", err)
	}

	f, err := os.CreateTemp(tempDir, "pam-agent-*.clickhouse-client.xml")
	if err != nil {
		return "", fmt.Errorf("failed to create temp clickhouse-client config file: %w", err)
	}
	defer f.Close()
	if err := f.Chmod(0o600); err != nil {
		return "", fmt.Errorf("failed to set permissions on temp clickhouse-client config file: %w", err)
	}
	if _, err := f.Write(append([]byte(xml.Header), raw...)); err != nil {
		return "", fmt.Errorf("failed to write temp clickhouse-client config file: %w", err)
	}
	return f.Name(), nil
}

// minioAliasEnvVar is the `mc` alias this launch pre-configures. `mc` reads
// MC_HOST_<alias> to learn an alias's endpoint+credential with no `mc alias
// set` step — that step would put the access/secret key on argv (visible via
// ps/Task Manager) AND permanently write them into the operator's own
// ~/.mc/config.json, which a PAM-brokered credential must never do (the next
// rotation would leave that config file holding a dead key, and the
// credential would outlive the session entirely). One fixed alias name is
// enough: each launch gets its own process/env, so there is no collision
// between concurrent sessions to different MinIO resources.
const minioAliasEnvVar = "MC_HOST_pam"

// buildMinIOAliasEnv renders the MC_HOST_pam value for a MinIO launch —
// scheme://accessKey:secretKey@host:port.
//
// BUGFIX: this used to build the value with net/url (url.UserPassword +
// url.URL.String()), which correctly percent-encodes a credential containing
// '@'/':' per RFC 3986 — the right thing for a real URL, and the wrong thing
// here. `mc` does NOT run its MC_HOST_<alias> value through a URL decoder:
// it locates the host by splitting on the LAST '@' and the user/pass by
// splitting the remainder on the FIRST ':', then uses those substrings
// completely raw. Confirmed live: a secret key containing '@' (e.g.
// "DasAdmin@123") got percent-encoded to "...%40123", which mc then signed
// requests with VERBATIM as the secret key ("DasAdmin%40123") instead of
// decoding it back — every request came back "SignatureDoesNotMatch" even
// though the credential itself was correct. mc's own last-'@'/first-':'
// split is exactly why this is safe to do raw: the host portion (an IP or
// hostname) will never itself contain '@', so however many '@' characters
// the secret key contains, the split still lands in the right place; and a
// MinIO/S3 access key never contains ':', so the first ':' always correctly
// separates it from a secret key that might contain ':' of its own.
//
// scheme comes from the resource's extra_config.use_ssl (set on the PAM
// resource, not guessed here) — an unset/missing value defaults to plain
// http, matching how MinIO is commonly run on a private/internal network;
// getting this wrong in either direction would silently connect over the
// wrong scheme instead of failing loudly.
func buildMinIOAliasEnv(resolved *apiclient.ResolvedLaunch) string {
	scheme := "http"
	if useSSL, _ := resolved.ExtraConfig["use_ssl"].(bool); useSSL {
		scheme = "https"
	}
	return fmt.Sprintf("%s=%s://%s:%s@%s:%d",
		minioAliasEnvVar, scheme, resolved.AccountName, resolved.Password, resolved.Host, resolved.Port)
}

// resolveInteractiveShell finds the operator's own interactive shell.
// `mc` (MinIO's CLI) has no REPL of its own — every invocation runs exactly
// one command and exits — so unlike psql/mongosh/redis-cli, the tool itself
// can't be the thing this launch execs. Instead the "minio_mc_shell"
// credential injection (see buildCommand) drops the operator into their own
// shell with MC_HOST_pam already exported, so every `mc ...` command they
// type is already authenticated. Windows always has cmd.exe on PATH; Unix
// honors $SHELL first (the operator's own configured shell) and falls back
// to bash, then the POSIX-guaranteed sh.
func resolveInteractiveShell() (string, error) {
	if runtime.GOOS == "windows" {
		if p, err := exec.LookPath("cmd"); err == nil {
			return p, nil
		}
		return "", fmt.Errorf("could not locate cmd.exe on PATH")
	}
	if sh := os.Getenv("SHELL"); sh != "" {
		if p, err := exec.LookPath(sh); err == nil {
			return p, nil
		}
	}
	for _, name := range []string{"bash", "sh"} {
		if p, err := exec.LookPath(name); err == nil {
			return p, nil
		}
	}
	return "", fmt.Errorf("could not locate an interactive shell (tried $SHELL, bash, sh)")
}

// CopyToClipboard puts text on the OS clipboard by shelling out to the
// platform's own built-in clipboard tool — same zero-third-party-dependency
// approach as everything else in this module (see discovery.go's doc
// comment on why reg.exe is used instead of a registry package). Best-effort
// by design: the caller (cmdLaunch, for CopyPasswordToClipboard) logs a
// failure and still opens the browser rather than blocking the whole launch
// over a clipboard write — the operator can always copy the password from
// PAM's own UI instead if this fails.
//
// Windows: clip.exe (present on every Windows install) reads stdin.
// macOS: pbcopy (present on every macOS install) reads stdin.
// Linux has no universal built-in, so this tries the common X11/Wayland
// clipboard tools in order and reports a clear error (naming all three) only
// if none of them are installed.
func CopyToClipboard(text string) error {
	var candidates [][]string
	switch runtime.GOOS {
	case "windows":
		candidates = [][]string{{"clip"}}
	case "darwin":
		candidates = [][]string{{"pbcopy"}}
	default:
		candidates = [][]string{
			{"xclip", "-selection", "clipboard"},
			{"xsel", "--clipboard", "--input"},
			{"wl-copy"},
		}
	}

	var tried []string
	for _, args := range candidates {
		path, err := exec.LookPath(args[0])
		if err != nil {
			tried = append(tried, args[0])
			continue
		}
		cmd := exec.Command(path, args[1:]...)
		cmd.Stdin = strings.NewReader(text)
		if err := cmd.Run(); err != nil {
			return fmt.Errorf("%s failed to copy to clipboard: %w", args[0], err)
		}
		return nil
	}
	return fmt.Errorf("no clipboard tool found (tried: %s)", strings.Join(tried, ", "))
}

// RemoveFiles deletes each path in files, best-effort. Called by main.go a
// few seconds after spawning the local process, giving it time to open/read
// them first. Deleting a file on Linux/macOS after a process has opened it
// is safe — the open file descriptor keeps working even after the directory
// entry is unlinked. Windows file-locking semantics differ (a still-open
// file may resist deletion); this is best-effort there and documented as
// such in the README.
func RemoveFiles(files []string) {
	for _, p := range files {
		if p == "" {
			continue
		}
		_ = os.Remove(p)
	}
}
