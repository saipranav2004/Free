pam-agent release binaries — for the backend's agent distribution folder
=======================================================================

WHAT THIS IS
  The five cross-compiled pam-agent executables the PAM console offers on its
  one-click enrolment page, plus the VERSION file the server reads.

WHERE IT GOES
  Unzip the CONTENTS of this archive directly into the directory you point
  PAM_AGENT_BINARY_DIR at — the files sit at the top level of that directory,
  not in a subfolder.

      unzip pam-agent-binaries-2026.09.25.zip -d /opt/pam/agents

  Then point the API at it and restart (or let it re-scan):

      PAM_AGENT_BINARY_DIR=/opt/pam/agents

  Leaving PAM_AGENT_BINARY_DIR unset disables agent distribution entirely —
  the console then shows no download buttons. That is the default.

THE FILENAMES ARE A CONTRACT, NOT A CONVENTION
  internal/agentdist/store.go parses pam-agent_<os>_<arch>[.exe] to build its
  target list. Renaming a file removes that platform from the console's picker
  silently — it is skipped with a log warning, not an error, so that a stray
  file in this directory cannot take out enrolment for everything else.

INTEGRITY
  The server computes each SHA-256 from the bytes on disk at scan time, and
  every generated install script verifies that digest before running the
  binary. Nothing here is trusted from a manifest. If you replace a binary,
  the server picks up the new digest on its next scan — there is no checksum
  file to keep in step.

CONTENTS
  pam-agent_windows_amd64.exe   Windows (64-bit)
  pam-agent_darwin_arm64        macOS (Apple Silicon)
  pam-agent_darwin_amd64        macOS (Intel)
  pam-agent_linux_amd64         Linux (x86-64)
  pam-agent_linux_arm64         Linux (ARM64)
  VERSION                       shown in the console beside each download

  Built with CGO disabled, -trimpath and -ldflags "-s -w", from
  agent/pam-agent/install/build-release.sh. Pure Go, no runtime dependencies.

NOT INCLUDED: Windows on ARM64
  The server already has a label for windows/arm64, but build-release.sh does
  not build it, so the console will not offer it. Add "windows/arm64" to that
  script's TARGETS line if you need it — nothing else has to change.

REBUILDING
  cd agent/pam-agent
  PAM_AGENT_VERSION=1.2.3 ./install/build-release.sh /opt/pam/agents
