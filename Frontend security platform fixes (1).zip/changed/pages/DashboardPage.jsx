/**
 * DashboardPage — the IAM control centre landing view.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * INFORMATION ARCHITECTURE
 * ═══════════════════════════════════════════════════════════════════════════
 * Enterprise identity consoles answer four questions, in this order:
 *
 *   1. "Is my tenant secure right now?"      → Security posture (scored)
 *   2. "What do I have to fix?"              → Attention required (ranked)
 *   3. "How big is my access surface?"       → Footprint KPIs
 *   4. "What just happened?"                 → Recent authorisation activity
 *
 * So the page reads top-left → down: posture and remediation share the fold,
 * the KPI strip quantifies the estate below it, and the activity feed plus
 * account context close the page. Nothing here is decorative: the previous
 * "Navigate" tile duplicated the sidebar and has been removed, and the
 * decorative clock is gone. Quick Actions stays removed, per requirements.
 *
 * Frontend only — every number comes from an existing API via useResource.
 * ═══════════════════════════════════════════════════════════════════════════
 */
import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, UsersRound, ShieldCheck, FileLock2, KeyRound, ArrowRight, Clock,
  Activity, Lock, CheckCircle2, XCircle, UserCog, RefreshCw, Fingerprint,
  ChevronRight, ShieldAlert, Gauge,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useResource } from '../hooks/useResource.js';
import { rbacApi } from '../lib/api/rbac.js';
import { pbacApi } from '../lib/api/pbac.js';
import { identityApi } from '../lib/api/identity.js';
import { sessionsApi } from '../lib/api/sessions.js';
import { identityAuditApi } from '../lib/api/identityAudit.js';
import { PageHeader } from '../components/common/PageHeader.jsx';
import {
  Panel, Button, Badge, StatCard, Skeleton, InlineAlert, MetricRow, IconButton,
} from '../components/ui/primitives.jsx';
import { isAdmin } from '../utils/permissions.js';
import { formatDateTime, formatRelative, classNames, extractList } from '../utils/format.js';

/* ── Posture model ─────────────────────────────────────────────────────────── */

function usePosture({ user, sessions, roles, groups, policies }) {
  return useMemo(() => {
    /* Bug fix — "0 roles" under Role-Based Access Control.
       These counts read `roles.roles.length` directly, so any other envelope
       the list endpoint can answer with (a bare array, or { data: { roles } })
       collapsed to 0 while the Roles page — which uses extractList — showed the
       real rows. All three counts now go through the same helper. */
    const activeSessions = Array.isArray(sessions) ? sessions.length : 0;
    const rolesCount = extractList(roles, 'roles').length;
    const groupsCount = extractList(groups, 'groups').length;
    const policiesCount = extractList(policies, 'policies').length;

    const controls = [
      {
        id: 'mfa',
        label: 'Multi-factor authentication',
        detail: user?.mfa_enabled ? 'Enabled on your account' : 'Password is the only factor',
        pass: !!user?.mfa_enabled,
        to: '/security/mfa',
        cta: user?.mfa_enabled ? 'Manage' : 'Enable MFA',
      },
      {
        id: 'sessions',
        label: 'Session hygiene',
        detail:
          activeSessions === 0
            ? 'No active sessions reported'
            : `${activeSessions} active session${activeSessions === 1 ? '' : 's'}`,
        pass: activeSessions > 0 && activeSessions < 10,
        to: '/security/sessions',
        cta: 'Review',
      },
      {
        id: 'rbac',
        label: 'Role-based access control',
        detail: `${rolesCount} role${rolesCount === 1 ? '' : 's'} · ${groupsCount} group${groupsCount === 1 ? '' : 's'}`,
        pass: rolesCount > 0 && groupsCount > 0,
        to: '/rbac/roles',
        cta: 'Configure',
      },
      {
        id: 'pbac',
        label: 'Policy-based access control',
        detail: `${policiesCount} polic${policiesCount === 1 ? 'y' : 'ies'} evaluated by the PDP`,
        pass: policiesCount > 0,
        to: '/pbac/policies',
        cta: 'Configure',
      },
    ];

    const passed = controls.filter((c) => c.pass).length;
    const score = controls.length ? Math.round((passed / controls.length) * 100) : 0;
    const level = score >= 75 ? 'good' : score >= 50 ? 'moderate' : 'critical';

    return { controls, passed, total: controls.length, score, level, activeSessions };
  }, [user, sessions, roles, groups, policies]);
}

const LEVEL_COPY = {
  good: { label: 'Healthy', tone: 'green', text: 'text-emerald-600', ring: '#059669' },
  moderate: { label: 'Needs attention', tone: 'amber', text: 'text-amber-600', ring: '#d97706' },
  critical: { label: 'Critical', tone: 'red', text: 'text-rose-600', ring: '#e11d48' },
};

/* ── Posture panel ─────────────────────────────────────────────────────────── */

function SecurityPosture({ posture, loading }) {
  const navigate = useNavigate();
  const cfg = LEVEL_COPY[posture.level];
  const circumference = 2 * Math.PI * 34;
  const dash = (posture.score / 100) * circumference;

  return (
    <Panel
      title="Security posture"
      subtitle="Baseline identity controls for this tenant"
      icon={Gauge}
      action={<Badge tone={cfg.tone} dot>{cfg.label}</Badge>}
      className="h-full"
    >
      <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
        {/* Score dial */}
        <div className="flex shrink-0 items-center gap-4">
          <div className="relative h-[84px] w-[84px]">
            <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
              <circle cx="40" cy="40" r="34" fill="none" stroke="#eef1f6" strokeWidth="8" />
              {!loading && (
                <circle
                  cx="40"
                  cy="40"
                  r="34"
                  fill="none"
                  stroke={cfg.ring}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${dash} ${circumference}`}
                  className="transition-[stroke-dasharray] duration-700 ease-out"
                />
              )}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              {loading ? (
                <Skeleton className="h-6 w-10" />
              ) : (
                <>
                  <span className={classNames('text-[20px] font-semibold leading-none tabular', cfg.text)}>
                    {posture.score}
                  </span>
                  <span className="mt-0.5 text-3xs font-medium uppercase tracking-[0.08em] text-slate-400">
                    score
                  </span>
                </>
              )}
            </div>
          </div>
          <div className="sm:hidden">
            <p className="text-[13px] font-semibold text-ink-900">
              {posture.passed} of {posture.total} controls passing
            </p>
          </div>
        </div>

        {/* Control checklist */}
        <ul className="min-w-0 flex-1 divide-y divide-line-soft">
          {posture.controls.map((control) => (
            <li key={control.id} className="flex items-center gap-3 py-2 first:pt-0 last:pb-0">
              {control.pass ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
              ) : (
                <XCircle className="h-4 w-4 shrink-0 text-rose-500" />
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium text-ink-900">{control.label}</p>
                <p className="truncate text-xs text-slate-500">{control.detail}</p>
              </div>
              <button
                type="button"
                onClick={() => navigate(control.to)}
                className="inline-flex shrink-0 items-center gap-0.5 rounded-md px-1.5 py-1 text-2xs font-semibold text-brand-700 transition-colors hover:bg-brand-50"
              >
                {control.cta}
                <ChevronRight className="h-3 w-3" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </Panel>
  );
}

/* ── Attention required ────────────────────────────────────────────────────── */

const SEVERITY = {
  high: { label: 'High', dot: 'bg-rose-500', badge: 'red' },
  medium: { label: 'Medium', dot: 'bg-amber-500', badge: 'amber' },
  low: { label: 'Low', dot: 'bg-sky-500', badge: 'sky' },
};

function AttentionPanel({ posture, totals, user }) {
  const navigate = useNavigate();

  const signals = useMemo(() => {
    const items = [];
    if (!user?.mfa_enabled) {
      items.push({
        severity: 'high',
        title: 'MFA not enabled for your account',
        description: 'Privileged administration without a second factor.',
        to: '/security/mfa',
        cta: 'Enable',
      });
    }
    if (posture.activeSessions > 5) {
      items.push({
        severity: 'medium',
        title: `${posture.activeSessions} concurrent sessions`,
        description: 'Revoke sessions you do not recognise.',
        to: '/security/sessions',
        cta: 'Review',
      });
    }
    if (totals.rolesCount === 0 && totals.groupsCount === 0) {
      items.push({
        severity: 'medium',
        title: 'No RBAC structure configured',
        description: 'Access cannot be granted consistently without roles or groups.',
        to: '/rbac/roles',
        cta: 'Configure',
      });
    }
    if (totals.policiesCount === 0) {
      items.push({
        severity: 'low',
        title: 'No PBAC policies defined',
        description: 'Fine-grained conditions are not being evaluated.',
        to: '/pbac/policies',
        cta: 'Create',
      });
    }
    if (totals.delegationsCount > 0) {
      items.push({
        severity: 'low',
        title: `${totals.delegationsCount} active delegation${totals.delegationsCount === 1 ? '' : 's'}`,
        description: 'Temporary access should be time-bound and reviewed.',
        to: '/identity/delegations',
        cta: 'Audit',
      });
    }
    return items;
  }, [posture.activeSessions, totals, user]);

  return (
    <Panel
      title="Attention required"
      subtitle={signals.length ? 'Ranked by security impact' : undefined}
      icon={ShieldAlert}
      action={signals.length > 0 && <Badge tone="amber">{signals.length}</Badge>}
      className="h-full"
      flush={signals.length > 0}
    >
      {signals.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50">
            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
          </span>
          <p className="mt-3 text-[13px] font-semibold text-ink-900">No open findings</p>
          <p className="mt-1 max-w-[220px] text-xs text-slate-500">
            Baseline controls are configured for this tenant.
          </p>
        </div>
      ) : (
        <ul className="divide-y divide-line-soft">
          {signals.map((signal, i) => {
            const sev = SEVERITY[signal.severity];
            return (
              <li key={i} className="flex items-start gap-3 px-4 py-3 sm:px-5">
                <span className={classNames('mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full', sev.dot)} />
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium leading-snug text-ink-900">{signal.title}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-slate-500">{signal.description}</p>
                </div>
                <Button variant="ghost" size="xs" onClick={() => navigate(signal.to)}>
                  {signal.cta}
                  <ArrowRight className="h-3 w-3" />
                </Button>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

/* ── Recent activity ──────────────────────────────────────────────────────── */

function decisionOf(event) {
  const decision = String(event?.decision || '').toUpperCase();
  const status = String(event?.status || '').toUpperCase();
  if (decision === 'DENY' || status === 'FAILURE') {
    return { tone: 'red', label: 'Denied', Icon: XCircle, wrap: 'bg-rose-50 text-rose-600' };
  }
  if (decision === 'ALLOW' || status === 'SUCCESS') {
    return { tone: 'green', label: 'Allowed', Icon: CheckCircle2, wrap: 'bg-emerald-50 text-emerald-600' };
  }
  return { tone: 'slate', label: 'Info', Icon: Activity, wrap: 'bg-slate-100 text-slate-500' };
}

function RecentActivity() {
  const navigate = useNavigate();
  const logs = useResource(() => identityAuditApi.list({ page: 1, page_size: 7 }), []);

  const raw = logs?.data;
  const items = Array.isArray(raw) ? raw : raw?.items || raw?.logs || raw?.data || [];

  return (
    <Panel
      title="Recent authorisation activity"
      icon={Activity}
      action={
        <>
          <IconButton
            icon={RefreshCw}
            title="Refresh activity"
            onClick={() => logs.reload?.()}
            loading={logs.loading}
          />
          <Button variant="ghost" size="sm" onClick={() => navigate('/pam')}>
            Open PAM
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </>
      }
      flush
      className="h-full"
    >
      {logs.loading ? (
        <div className="space-y-3 px-4 py-4 sm:px-5">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center gap-3">
              <Skeleton className="h-7 w-7 rounded-lg" />
              <Skeleton className="h-3.5 flex-1" />
              <Skeleton className="h-3 w-16" />
            </div>
          ))}
        </div>
      ) : logs.error ? (
        <div className="px-4 py-8 text-center sm:px-5">
          <p className="text-[13px] font-medium text-ink-800">Activity unavailable</p>
          <p className="mt-1 text-xs text-slate-500">{logs.error}</p>
          <Button variant="secondary" size="sm" className="mt-3" onClick={() => logs.reload?.()}>
            Retry
          </Button>
        </div>
      ) : items.length === 0 ? (
        <div className="px-4 py-10 text-center sm:px-5">
          <p className="text-[13px] font-medium text-ink-800">No recent events</p>
          <p className="mt-1 text-xs text-slate-500">
            Authorisation decisions will appear here as they are recorded.
          </p>
        </div>
      ) : (
        <ul className="divide-y divide-line-soft">
          {items.slice(0, 7).map((event, i) => {
            const d = decisionOf(event);
            return (
              <li key={event?.audit_id || i}>
                <button
                  type="button"
                  onClick={() => navigate('/pam')}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-slate-50 sm:px-5"
                >
                  <span
                    className={classNames(
                      'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg',
                      d.wrap
                    )}
                  >
                    <d.Icon className="h-3.5 w-3.5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate font-mono text-xs font-medium text-ink-900">
                        {event?.action || event?.event_type || 'security.event'}
                      </span>
                      <Badge tone={d.tone}>{d.label}</Badge>
                    </span>
                    <span className="mt-0.5 block truncate text-2xs text-slate-500">
                      {event?.username || event?.user_id || 'system'}
                      {event?.resource_name ? ` → ${event.resource_name}` : ''}
                    </span>
                  </span>
                  <span className="shrink-0 text-right text-2xs text-slate-400">
                    {formatDateTime(event?.created_at)}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </Panel>
  );
}

/* ── Account context ──────────────────────────────────────────────────────── */

function AccountPanel({ user, posture, accountId }) {
  const navigate = useNavigate();
  const admin = isAdmin(user);

  return (
    <Panel
      title="Your account"
      icon={Fingerprint}
      action={
        <Button variant="ghost" size="sm" onClick={() => navigate('/profile')}>
          Profile
        </Button>
      }
      className="h-full"
    >
      <div className="flex items-center gap-3 rounded-lg border border-line-soft bg-slate-50/70 p-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-2xs font-bold text-white">
          {(user?.username || user?.email || 'U').slice(0, 2).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold text-ink-900">{user?.username || '—'}</p>
          <p className="truncate text-2xs text-slate-500">{user?.email || '—'}</p>
        </div>
        <Badge tone={admin ? 'brand' : 'slate'}>{admin ? 'Admin' : user?.account_type || 'User'}</Badge>
      </div>

      <div className="mt-3 divide-y divide-line-soft">
        <MetricRow
          label="MFA"
          icon={Lock}
          value={
            <Badge tone={user?.mfa_enabled ? 'green' : 'amber'} dot>
              {user?.mfa_enabled ? 'Enabled' : 'Disabled'}
            </Badge>
          }
        />
        <MetricRow label="Active sessions" icon={KeyRound} value={posture.activeSessions} />
        <MetricRow
          label="Last sign-in"
          icon={Clock}
          value={user?.last_login_at ? formatRelative(user.last_login_at) : '—'}
        />
        {accountId && (
          <MetricRow
            label="Tenant"
            icon={ShieldCheck}
            value={<span className="font-mono text-2xs text-ink-800">{accountId}</span>}
          />
        )}
      </div>
    </Panel>
  );
}

/* ── Page ─────────────────────────────────────────────────────────────────── */

export default function DashboardPage() {
  const { user, accountId } = useAuth();
  const navigate = useNavigate();

  const groups = useResource(() => accountId ? identityApi.listGroups(accountId) : Promise.resolve({ groups: [] }), [accountId]);
  const roles = useResource(() => rbacApi.listRoles(), []);
  const policies = useResource(() => pbacApi.listPolicies(), []);
  const users = useResource(
    () =>
      accountId
        ? identityApi.listUsers({ account_id: accountId, per_page: 1 })
        : Promise.resolve({ users: [], pagination: { total: 0 } }),
    [accountId]
  );
  const sessions = useResource(() => sessionsApi.list(), []);
  const delegations = useResource(() => identityApi.listDelegations(), []);

  const coreLoading = groups.loading || roles.loading || policies.loading;
  const sessionsData = !sessions.loading && !sessions.error ? sessions.data : null;
  const delegationsData = delegations.data?.delegations || delegations.data || [];

  const posture = usePosture({
    user,
    sessions: sessionsData,
    roles: roles.data,
    groups: groups.data,
    policies: policies.data,
  });

  // Same envelope-tolerant resolution as usePosture above, so the KPI strip and
  // the posture checklist can never disagree with the Roles / Groups / Policies
  // pages. Every count re-derives on reload, so create and delete move them.
  const rolesCount = extractList(roles.data, 'roles').length;
  const groupsCount = extractList(groups.data, 'groups').length;
  const policiesCount = extractList(policies.data, 'policies').length;
  const delegationsCount = Array.isArray(delegationsData) ? delegationsData.length : 0;

  const totals = { rolesCount, groupsCount, policiesCount, delegationsCount };

  const kpis = [
    {
      label: 'Users',
      value: users.data?.pagination?.total ?? (users.loading ? null : '—'),
      icon: Users,
      tone: 'brand',
      to: '/identity/users',
      loading: users.loading,
    },
    {
      label: 'Sessions',
      value: posture.activeSessions,
      icon: KeyRound,
      tone: 'green',
      to: '/security/sessions',
      loading: sessions.loading,
    },
    {
      label: 'Roles',
      value: rolesCount,
      icon: ShieldCheck,
      tone: 'sky',
      to: '/rbac/roles',
      loading: roles.loading,
    },
    {
      label: 'Groups',
      value: groupsCount,
      icon: UsersRound,
      tone: 'slate',
      to: '/rbac/groups',
      loading: groups.loading,
    },
    {
      label: 'Policies',
      value: policiesCount,
      icon: FileLock2,
      tone: 'amber',
      to: '/pbac/policies',
      loading: policies.loading,
    },
    {
      label: 'Delegations',
      value: delegationsCount,
      icon: UserCog,
      tone: 'brand',
      to: '/identity/delegations',
      loading: delegations.loading,
    },
  ];

  const reloadAll = () => {
    groups.reload?.();
    roles.reload?.();
    policies.reload?.();
    users.reload?.();
    sessions.reload?.();
    delegations.reload?.();
  };

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${user?.username || 'administrator'}`}
        description="Tenant-wide identity posture, open findings and privileged activity."
        meta={
          <>
            {accountId && (
              <span className="inline-flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-slate-400" />
                Tenant <span className="font-mono text-slate-600">{accountId}</span>
              </span>
            )}
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-slate-400" />
              {posture.passed} of {posture.total} baseline controls passing
            </span>
          </>
        }
        actions={
          <>
            <Button variant="secondary" onClick={reloadAll} loading={coreLoading}>
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            {isAdmin(user) && (
              <Button onClick={() => navigate('/identity/users')}>
                <Users className="h-4 w-4" />
                Manage users
              </Button>
            )}
          </>
        }
      />

      <div className="space-y-4">
        {!user?.mfa_enabled && (
          <InlineAlert
            tone="warning"
            title="Multi-factor authentication is not enabled"
            action={
              <Button size="sm" onClick={() => navigate('/security/mfa')}>
                Enable MFA
              </Button>
            }
          >
            This administrator account is protected by a password alone, leaving it exposed to
            credential-based attacks.
          </InlineAlert>
        )}

        {/* Fold: posture + findings */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
          <div className="xl:col-span-8">
            <SecurityPosture posture={posture} loading={coreLoading} />
          </div>
          <div className="xl:col-span-4">
            <AttentionPanel posture={posture} totals={totals} user={user} />
          </div>
        </div>

        {/* Access footprint */}
        <section>
          <h2 className="mb-2 text-3xs font-semibold uppercase tracking-[0.1em] text-slate-400">
            Access footprint
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
            {kpis.map((kpi) => (
              <StatCard
                key={kpi.label}
                label={kpi.label}
                value={typeof kpi.value === 'number' ? kpi.value.toLocaleString() : kpi.value}
                icon={kpi.icon}
                tone={kpi.tone}
                loading={kpi.loading}
                onClick={() => navigate(kpi.to)}
              />
            ))}
          </div>
        </section>

        {/* Activity + account */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
          <div className="xl:col-span-8">
            <RecentActivity />
          </div>
          <div className="xl:col-span-4">
            <AccountPanel user={user} posture={posture} accountId={accountId} />
          </div>
        </div>
      </div>
    </div>
  );
}
