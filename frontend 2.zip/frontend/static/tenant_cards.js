/* Shared tenant-card rendering + wiring, used by both the Tenants wizard (single
   tenant, step 4) and the Overview page (all tenants). window.TC namespace. */
(function () {
  window.TC = window.TC || {};
  let MFA = { primary: [], stepup: [], modes: ["external", "idp"] };
  const seg = p => (p === 'entra' ? 'entraid' : p);
  TC.seg = seg;

  // inject shared card CSS once
  if (!document.getElementById('tc-style')) {
    const s = document.createElement('style'); s.id = 'tc-style';
    s.textContent = `
      .entered { background:#12151c; border:1px solid #232a36; border-radius:8px; padding:10px 14px; margin:0 0 12px; }
      .entered .kv { display:flex; gap:10px; margin:4px 0; font-size:13px; }
      .entered .kv span { min-width:110px; color:#8b97a8; } .entered code { color:#8fb4ff; word-break:break-all; }
      .gbox { margin-top:14px; padding-top:14px; border-top:1px solid #232a36; }
      .mfabox { margin-top:16px; padding-top:14px; border-top:1px solid #232a36; }
      .mfahead { font-size:13px; font-weight:600; margin-bottom:10px; }
      .mfagrid { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px,1fr)); gap:12px; }
      .mfagrid select, .gbox input { width:100%; padding:8px 10px; border:1px solid #2a3342; border-radius:4px;
        font-size:14px; font-family:inherit; color:#e7ecf3; background:#0f131b; }
      .mfagrid select:disabled { background:#1a1f29; color:#5b6472; }
      .repgrid { display:grid; grid-template-columns:auto auto; gap:2px 12px; margin:8px 0; font-size:13px; } .repgrid b { text-align:right; }
      .chip.err { background:#3a1620; color:#ff8a9b; }`;
    document.head.appendChild(s);
  }

  const optList = (list, sel) => list.map(x => `<option value="${x.name}" ${x.name===sel?'selected':''}>${x.label}</option>`).join('');
  const optModes = (modes, sel) => modes.map(x => `<option value="${x}" ${x===sel?'selected':''}>${x}</option>`).join('');

  TC.loadMfa = async function (apiBase) {
    try { MFA = await (await fetch(`${apiBase}/api/mfa-methods`)).json(); } catch (e) {}
    return MFA;
  };

  TC.card = function (t, apiBase, opts) {
    opts = opts || {};
    const mfa=t.mfa_method||'behaviour', mode=t.stepup_mode||'external', sm=t.stepup_method||'dummy_approve';
    const dep = t.deprecated || t.consent_state==='deprecated';
    const chip = dep ? '<span class="chip err">deprecated</span>'
                     : `<span class="chip ${t.consent_state==='adopted'?'ready':'planned'}">${t.consent_state}</span>`;
    const s = seg(t.platform), isG=(t.platform||'').toLowerCase()==='google';
    const details = opts.showDetails ? `<div class="entered">
        <div class="kv"><span>Domain</span><code>${t.verified_domain||'—'}</code></div>
        <div class="kv"><span>Display name</span><code>${t.display_name||'—'}</code></div>
        <div class="kv"><span>tenant_id</span><code>${t.tenant_id}</code></div>
        <div class="kv"><span>schema</span><code>${t.schema_name||'—'}</code></div>
        ${t.platform_id?`<div class="kv"><span>platform_id</span><code>${t.platform_id}</code></div>`:''}
      </div>` : '';
    return `<div class="cred" data-id="${t.tenant_id}" data-platform="${t.platform}">
      <div class="cred-head">
        <div>
          <div class="name">${t.display_name||t.tenant_id}</div>
          <div class="desc"><code>${t.verified_domain||'(no domain)'}</code> · ${t.platform}${opts.showDetails?'':` · schema <code>${t.schema_name||'—'}</code>`}</div>
        </div>
        <div class="fedbox">${chip}${isG?'':`<label class="switch"><input type="checkbox" class="fedtoggle" disabled><span class="slider"></span></label>`}</div>
      </div>
      <div class="cred-body">
        ${details}
        <div class="desc">SSO <code>${apiBase}/saml/${s}/${t.tenant_id}/sso</code>${isG?` · <a href="${apiBase}/saml/google/${t.tenant_id}/metadata" target="_blank">metadata</a>`:''}</div>
        <p class="fmsg msg"></p>
        ${isG?'':`
        <div class="gbox">
          <div class="field"><label>Graph client ID</label><input class="cid" type="text" placeholder="client id" autocomplete="off"></div>
          <div class="field"><label>Graph client secret <span class="hint">stored encrypted</span></label><input class="csec" type="password" placeholder="client secret" autocomplete="off"></div>
          <div class="btnrow">
            <button class="btn btn-test">Test connection</button>
            <button class="btn btn-ghost btn-save">Save credentials</button>
            <button class="btn btn-ghost btn-sync">Sync directory</button>
          </div>
          <div class="syncrep"></div>
          <p class="cmsg msg"></p>
        </div>`}
        <div class="mfabox">
          <div class="mfahead">MFA policy</div>
          <div class="mfagrid">
            <div class="field"><label>Primary method</label><select class="sel-mfa">${optList(MFA.primary, mfa)}</select></div>
            <div class="field"><label>Step-up mode</label><select class="sel-mode">${optModes(MFA.modes, mode)}</select></div>
            <div class="field"><label>Step-up method <span class="hint">idp mode only</span></label>
              <select class="sel-stepup" ${mode!=='idp'?'disabled':''}>${optList(MFA.stepup, sm)}</select></div>
          </div>
          <div class="btnrow"><button class="btn btn-ghost btn-mfa-save">Save MFA policy</button></div>
          <p class="mmsg msg"></p>
        </div>
      </div>
    </div>`;
  };

  TC.refreshFed = async function (tid, apiBase) {
    const c = document.querySelector(`.cred[data-id="${tid}"]`); if (!c) return;
    const toggle = c.querySelector('.fedtoggle'); if (!toggle) return;
    const fmsg = c.querySelector('.fmsg');
    try {
      const d = await (await fetch(`${apiBase}/api/tenants/${tid}/federation-status`)).json();
      if (d.has_synced) { toggle.disabled = false; }
      else { toggle.disabled = true; fmsg.textContent = 'Federation available after the first successful directory sync.'; }
      if (d.status) toggle.checked = d.status.authentication_type === 'Federated';
      else if (d.error && d.has_synced) fmsg.textContent = 'Federation: ' + String(d.error).slice(0,60);
    } catch (e) {}
  };

  TC.wire = function (apiBase) {
    document.querySelectorAll('.cred').forEach(c => {
      const id = c.dataset.id, fmsg = c.querySelector('.fmsg');
      const toggle = c.querySelector('.fedtoggle');
      if (toggle) toggle.addEventListener('change', async () => {
        const on = toggle.checked;
        if (on && !confirm('Turn federation ON? Converts the domain to Federated in Entra.')) { toggle.checked=false; return; }
        if (!on && !confirm('Turn federation OFF? Reverts to Managed.')) { toggle.checked=true; return; }
        fmsg.textContent = on ? 'Enabling…' : 'Reverting…'; fmsg.className='fmsg msg'; toggle.disabled=true;
        const d = await (await fetch(`${apiBase}/api/tenants/${id}/federation`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:on})})).json();
        toggle.disabled=false;
        if (!d.ok) { fmsg.textContent=`Failed: ${d.error}`; fmsg.className='fmsg msg err'; toggle.checked=!on; return; }
        fmsg.textContent = on ? `Federated. SSO: ${d.sso_url}` : 'Reverted to Managed.'; fmsg.className='fmsg msg ok';
      });

      const cid=c.querySelector('.cid'), csec=c.querySelector('.csec'), cmsg=c.querySelector('.cmsg');
      if (c.querySelector('.btn-test')) {
        c.querySelector('.btn-test').addEventListener('click', async () => {
          cmsg.textContent='Contacting Microsoft Graph…'; cmsg.className='cmsg msg';
          const d=await (await fetch(`${apiBase}/api/tenants/${id}/graph-test`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:cid.value.trim(),client_secret:csec.value.trim()})})).json();
          if (d.ok){cmsg.textContent=`Connected — ${d.sample_count} user(s).`;cmsg.className='cmsg msg ok';}
          else {cmsg.textContent=`Failed at ${d.stage||'request'}: ${d.detail||d.error||'unknown'}`;cmsg.className='cmsg msg err';}
        });
        c.querySelector('.btn-save').addEventListener('click', async () => {
          cmsg.textContent='Saving…'; cmsg.className='cmsg msg';
          const r=await fetch(`${apiBase}/api/tenants/${id}/graph-credentials`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:cid.value.trim(),client_secret:csec.value.trim()})});
          const d=await r.json();
          if (r.ok){cmsg.textContent='Saved (encrypted).';cmsg.className='cmsg msg ok';csec.value='';}
          else {cmsg.textContent=d.error||'Save failed.';cmsg.className='cmsg msg err';}
        });
        let poll=null;
        const renderJob=(j,rep)=>{ const done=(j.status==='succeeded'||j.status==='failed');
          cmsg.textContent=({queued:'Queued…',running:'Syncing…',succeeded:'Sync complete.',failed:'Sync failed.'}[j.status])||j.status;
          cmsg.className='cmsg msg'+(j.status==='succeeded'?' ok':j.status==='failed'?' err':'');
          rep.innerHTML=`<div class="repgrid"><span>Pulled</span><b>${j.pulled}</b><span>Stored</span><b>${j.local_upserts}</b><span>Backfilled</span><b>${j.backfilled}</b><span>Conflicts</span><b>${j.conflicts_count}</b><span>Errors</span><b>${j.errors_count}</b></div>`;
          if (done && j.status==='succeeded') TC.refreshFed(id, apiBase);
          return done; };
        c.querySelector('.btn-sync').addEventListener('click', async () => {
          const rep=c.querySelector('.syncrep'); cmsg.textContent='Starting…'; cmsg.className='cmsg msg'; rep.innerHTML='';
          const r=await fetch(`${apiBase}/api/tenants/${id}/sync`,{method:'POST'}); const d=await r.json();
          if (r.status===409){cmsg.textContent='A sync is already running.';cmsg.className='cmsg msg err';return;}
          if (!d.ok){cmsg.textContent=`Could not start: ${d.error||'unknown'}`;cmsg.className='cmsg msg err';return;}
          if (poll) clearInterval(poll);
          poll=setInterval(async ()=>{ const jd=await (await fetch(`${apiBase}/api/tenants/${id}/sync/${d.job_id}`)).json();
            if (jd.job && renderJob(jd.job, rep)) clearInterval(poll); }, 2000);
        });
      }

      const selMode=c.querySelector('.sel-mode'), selStepup=c.querySelector('.sel-stepup'), mmsg=c.querySelector('.mmsg');
      selMode.addEventListener('change', ()=>{ selStepup.disabled = selMode.value!=='idp'; });
      c.querySelector('.btn-mfa-save').addEventListener('click', async () => {
        mmsg.textContent='Saving MFA policy…'; mmsg.className='mmsg msg';
        const body={mfa_method:c.querySelector('.sel-mfa').value,stepup_mode:selMode.value,stepup_method:selStepup.value};
        try { const r=await fetch(`${apiBase}/api/tenants/${id}/mfa-config`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
          const d=await r.json();
          if (r.ok&&d.saved){mmsg.textContent=`Saved — primary ${d.mfa_method}, step-up ${d.stepup_mode}`+(d.stepup_mode==='idp'?` (${d.stepup_method})`:'')+'.';mmsg.className='mmsg msg ok';}
          else {mmsg.textContent=`Failed: ${d.error||r.status}`;mmsg.className='mmsg msg err';}
        } catch(e){ mmsg.textContent=`Failed: ${e}`; mmsg.className='mmsg msg err'; }
      });
    });
  };
})();
